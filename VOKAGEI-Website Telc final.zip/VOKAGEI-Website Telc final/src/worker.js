// Cloudflare Worker Backend for VOKAGEI (Google OAuth + D1 Progress Sync)

const SESSION_COOKIE = "vokagei_session";
const SESSION_MAX_AGE_SEC = 60 * 60 * 24 * 30; // 30 days
const GOOGLE_CERTS_URL = "https://www.googleapis.com/oauth2/v3/certs";

let cachedCerts = null;
let cachedCertsExpiry = 0;

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      ...extraHeaders,
    },
  });
}

function base64UrlToUint8Array(str) {
  const pad = "=".repeat((4 - (str.length % 4)) % 4);
  const base64 = (str + pad).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  return bytes;
}

function uint8ArrayToBase64Url(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function decodeJwtPart(part) {
  return JSON.parse(new TextDecoder().decode(base64UrlToUint8Array(part)));
}

async function getGoogleJwks() {
  const now = Date.now();
  if (cachedCerts && now < cachedCertsExpiry) return cachedCerts;
  const res = await fetch(GOOGLE_CERTS_URL);
  if (!res.ok) throw new Error("Failed to fetch Google public keys");
  const cacheControl = res.headers.get("Cache-Control") || "";
  const maxAgeMatch = cacheControl.match(/max-age=(\d+)/);
  const maxAgeMs = maxAgeMatch ? Number(maxAgeMatch[1]) * 1000 : 3600 * 1000;
  const body = await res.json();
  cachedCerts = body.keys || [];
  cachedCertsExpiry = now + maxAgeMs;
  return cachedCerts;
}

async function verifyGoogleIdToken(idToken, expectedClientId) {
  const parts = String(idToken || "").split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT format");

  const header = decodeJwtPart(parts[0]);
  const payload = decodeJwtPart(parts[1]);

  if (header.alg !== "RS256" || !header.kid) {
    throw new Error("Unsupported JWT algorithm");
  }

  const nowSec = Math.floor(Date.now() / 1000);
  if (!payload.exp || payload.exp < nowSec) {
    throw new Error("Google token expired");
  }
  if (payload.iss !== "https://accounts.google.com" && payload.iss !== "accounts.google.com") {
    throw new Error("Invalid token issuer");
  }
  if (payload.aud !== expectedClientId) {
    throw new Error("Token audience mismatch");
  }
  if (!payload.sub || !payload.email) {
    throw new Error("Missing user claims");
  }

  const keys = await getGoogleJwks();
  const jwk = keys.find((k) => k.kid === header.kid);
  if (!jwk) throw new Error("Matching Google public key not found");

  const cryptoKey = await crypto.subtle.importKey(
    "jwk",
    jwk,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["verify"]
  );

  const signingInput = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  const signature = base64UrlToUint8Array(parts[2]);
  const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", cryptoKey, signature, signingInput);
  if (!valid) throw new Error("Invalid Google token signature");

  return {
    id: payload.sub,
    email: payload.email,
    name: payload.name || payload.email.split("@")[0],
    picture: payload.picture || "",
  };
}

async function getHmacKey(secret) {
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}

async function signSessionToken(userId, secret) {
  const exp = Math.floor(Date.now() / 1000) + SESSION_MAX_AGE_SEC;
  const payloadStr = uint8ArrayToBase64Url(new TextEncoder().encode(JSON.stringify({ uid: userId, exp })));
  const key = await getHmacKey(secret);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payloadStr));
  return `${payloadStr}.${uint8ArrayToBase64Url(new Uint8Array(sig))}`;
}

async function verifySessionToken(token, secret) {
  if (!token || !secret) return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  try {
    const key = await getHmacKey(secret);
    const sigBytes = base64UrlToUint8Array(parts[1]);
    const valid = await crypto.subtle.verify("HMAC", key, sigBytes, new TextEncoder().encode(parts[0]));
    if (!valid) return null;
    const payload = JSON.parse(new TextDecoder().decode(base64UrlToUint8Array(parts[0])));
    if (!payload.uid || !payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload.uid;
  } catch {
    return null;
  }
}

function getCookieValue(request, name) {
  const cookieHeader = request.headers.get("Cookie") || "";
  for (const part of cookieHeader.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === name) return decodeURIComponent(rest.join("="));
  }
  return "";
}

function buildSessionCookie(value, maxAgeSec, requestUrl) {
  const isHttps = requestUrl.protocol === "https:";
  const attrs = [
    `${SESSION_COOKIE}=${encodeURIComponent(value)}`,
    "Path=/",
    `Max-Age=${maxAgeSec}`,
    "HttpOnly",
    "SameSite=Lax",
  ];
  if (isHttps) attrs.push("Secure");
  return attrs.join("; ");
}

async function getAuthenticatedUser(request, env) {
  const token = getCookieValue(request, SESSION_COOKIE);
  if (!token || !env.SESSION_SECRET || !env.DB) return null;
  const userId = await verifySessionToken(token, env.SESSION_SECRET);
  if (!userId) return null;
  const row = await env.DB.prepare("SELECT id, email, name, picture FROM users WHERE id = ?")
    .bind(userId)
    .first();
  return row || null;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // 1. Public Auth Config
    if (url.pathname === "/api/config" && request.method === "GET") {
      const clientId = env.GOOGLE_CLIENT_ID || "";
      const configured = Boolean(clientId && !clientId.startsWith("REPLACE_WITH_"));
      return json({ googleClientId: configured ? clientId : "" });
    }

    // 2. Google Sign-In
    if (url.pathname === "/api/auth/google" && request.method === "POST") {
      if (!env.DB || !env.SESSION_SECRET || !env.GOOGLE_CLIENT_ID) {
        return json({ error: "Backend nicht vollständig konfiguriert." }, 500);
      }
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "Ungültige Anfrage." }, 400);
      }
      try {
        const user = await verifyGoogleIdToken(body.credential, env.GOOGLE_CLIENT_ID);
        await env.DB.prepare(
          `INSERT INTO users (id, email, name, picture, last_login_at)
           VALUES (?, ?, ?, ?, datetime('now'))
           ON CONFLICT(id) DO UPDATE SET
             email = excluded.email,
             name = excluded.name,
             picture = excluded.picture,
             last_login_at = datetime('now')`
        )
          .bind(user.id, user.email, user.name, user.picture)
          .run();

        const sessionToken = await signSessionToken(user.id, env.SESSION_SECRET);
        return json(
          { user },
          200,
          { "Set-Cookie": buildSessionCookie(sessionToken, SESSION_MAX_AGE_SEC, url) }
        );
      } catch (err) {
        return json({ error: err.message || "Google-Anmeldung fehlgeschlagen." }, 401);
      }
    }

    // 3. Current User
    if (url.pathname === "/api/auth/me" && request.method === "GET") {
      const user = await getAuthenticatedUser(request, env);
      return json({ user });
    }

    // 4. Logout
    if (url.pathname === "/api/auth/logout" && request.method === "POST") {
      return json(
        { ok: true },
        200,
        { "Set-Cookie": buildSessionCookie("", 0, url) }
      );
    }

    // 5. Get Progress
    if (url.pathname === "/api/progress" && request.method === "GET") {
      const user = await getAuthenticatedUser(request, env);
      if (!user) return json({ error: "Nicht angemeldet." }, 401);
      const row = await env.DB.prepare("SELECT progress_json, updated_at FROM user_progress WHERE user_id = ?")
        .bind(user.id)
        .first();
      let progress = {};
      if (row && row.progress_json) {
        try {
          progress = JSON.parse(row.progress_json) || {};
        } catch {
          progress = {};
        }
      }
      return json({ progress, updatedAt: row?.updated_at || null });
    }

    // 6. Save Progress
    if (url.pathname === "/api/progress" && request.method === "PUT") {
      const user = await getAuthenticatedUser(request, env);
      if (!user) return json({ error: "Nicht angemeldet." }, 401);
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "Ungültige Daten." }, 400);
      }
      const progressObj = body && typeof body.progress === "object" && body.progress !== null ? body.progress : {};
      const serialized = JSON.stringify(progressObj);
      if (serialized.length > 512000) {
        return json({ error: "Fortschrittsdaten zu groß." }, 413);
      }
      await env.DB.prepare(
        `INSERT INTO user_progress (user_id, progress_json, updated_at)
         VALUES (?, ?, datetime('now'))
         ON CONFLICT(user_id) DO UPDATE SET
           progress_json = excluded.progress_json,
           updated_at = datetime('now')`
      )
        .bind(user.id, serialized)
        .run();

      return json({ ok: true });
    }

    // 7. Static Assets Fallback
    return env.ASSETS.fetch(request);
  },
};
