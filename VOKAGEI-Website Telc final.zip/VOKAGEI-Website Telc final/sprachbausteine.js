const MODULE_NAME = "sprachbausteine";
const partLinks = [...document.querySelectorAll(".reading-parts a")];
const topicPicker = document.querySelector(".topic-panel");
const topicSearch = document.querySelector("#topic-search");
const topicList = document.querySelector("#topic-list");
const topicCount = document.querySelector("#topic-count");
const topicEmpty = document.querySelector("#topic-empty");
const exercise = document.querySelector("#reading-exercise");
const narrowScreen = window.matchMedia("(max-width: 920px)");

const parts = sprachbausteineData;
const descriptions = {
  1: "Klicke auf jede Lücke (21–30) direkt im Text und wähle die passende Lösung (A, B oder C).",
  2: "Klicke auf jede Lücke (31–40) direkt im Text und wähle das passende Wort aus der Wortliste A–O.",
};
const selections = new Map();
const drafts = new Map();
let currentPart;
let currentTopic;

const popupDialog = document.createElement("dialog");
popupDialog.className = "option-popup-dialog";
popupDialog.innerHTML = `
  <div class="popup-head">
    <h3 id="popup-title">Lücke wählen</h3>
    <button type="button" class="popup-close">Schließen</button>
  </div>
  <div class="popup-list" id="popup-list"></div>
`;
document.body.append(popupDialog);
popupDialog.querySelector(".popup-close").addEventListener("click", () => popupDialog.close());
popupDialog.addEventListener("click", (e) => { if (e.target === popupDialog) popupDialog.close(); });

function openGapPopup(gapNum, choices, currentValue, usedValues, onPick) {
  popupDialog.querySelector("#popup-title").textContent = `Lücke ${gapNum} wählen`;
  const listEl = popupDialog.querySelector("#popup-list");
  listEl.replaceChildren();

  if (currentValue) {
    const clearBtn = document.createElement("button");
    clearBtn.type = "button";
    clearBtn.className = "popup-choice";
    clearBtn.innerHTML = `<span class="popup-choice-key">×</span><span>Auswahl aufheben</span>`;
    clearBtn.addEventListener("click", () => { onPick(""); popupDialog.close(); });
    listEl.append(clearBtn);
  }

  for (const [key, labelText] of choices) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "popup-choice";
    const isSelected = currentValue === key;
    const isUsedElsewhere = currentPart === 2 && !isSelected && usedValues.has(key);
    btn.setAttribute("aria-selected", String(isSelected));
    btn.disabled = isUsedElsewhere;
    const keySpan = document.createElement("span");
    keySpan.className = "popup-choice-key";
    keySpan.textContent = key.toUpperCase();
    const txtSpan = document.createElement("span");
    txtSpan.textContent = labelText;
    btn.append(keySpan, txtSpan);
    btn.addEventListener("click", () => {
      onPick(key);
      popupDialog.close();
    });
    listEl.append(btn);
  }
  popupDialog.showModal();
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function normalize(text) {
  return text.toLocaleLowerCase("de").replace(/ß/g, "ss")
    .normalize("NFD").replace(/\p{Diacritic}/gu, "");
}

function topicTitle(topic) {
  return topic.title.replace(/^Test\s+\S+\s*[–-]\s*/i, "");
}

function topicHash(part, id) {
  return `#teil-${part}/${id}`;
}

function gapNumbers(part) {
  return part === 1
    ? [21, 22, 23, 24, 25, 26, 27, 28, 29, 30]
    : [31, 32, 33, 34, 35, 36, 37, 38, 39, 40];
}

function topicQuestionCount() {
  return 10;
}

function updatePartProgressBars() {
  for (const link of partLinks) {
    const p = Number(link.hash.replace("#teil-", ""));
    const pct = VokageiProgress.getPartProgressPercent(MODULE_NAME, p, parts[p], topicQuestionCount);
    link.style.setProperty("--progress", `${pct}%`);
  }
}

function renderTopics() {
  const terms = normalize(topicSearch.value.trim()).split(/\s+/).filter(Boolean);
  const allTopics = parts[currentPart];
  const matches = allTopics.filter((topic) => {
    const searchText = normalize(`${topic.num} ${topic.id} ${topic.title} ${topic.category ?? ""}`);
    return terms.every((word) => /^\d+[a-z]?$/.test(word)
      ? topic.num.toLowerCase().startsWith(word) || String(topic.id).toLowerCase().startsWith(word)
      : searchText.includes(word));
  });
  const entries = matches.map((topic) => {
    const entry = element("li");
    const link = element("a");
    const idKey = String(topic.num || topic.id);
    link.href = topicHash(currentPart, idKey);
    link.dataset.topicId = idKey;
    const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, idKey, 10);
    link.style.setProperty("--progress", `${pct}%`);
    if (idKey === String(currentTopic.num || currentTopic.id)) link.setAttribute("aria-current", "location");
    link.append(element("span", "topic-number", idKey), element("span", "", topicTitle(topic)));
    entry.append(link);
    return entry;
  });
  topicList.replaceChildren(...entries);
  topicCount.textContent = `${matches.length} von ${allTopics.length} Themen`;
  topicEmpty.hidden = matches.length > 0;
  updatePartProgressBars();
}

function updateCurrentTopicProgressUI(draft) {
  const idKey = String(currentTopic.num || currentTopic.id);
  VokageiProgress.saveDraft(MODULE_NAME, currentPart, idKey, draft, 10);
  const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, idKey, 10);
  const activeLink = topicList.querySelector(`a[data-topic-id="${CSS.escape(idKey)}"]`);
  if (activeLink) activeLink.style.setProperty("--progress", `${pct}%`);
  updatePartProgressBars();
  return pct;
}

function getDraft() {
  const idKey = String(currentTopic.num || currentTopic.id);
  const key = topicHash(currentPart, idKey);
  if (!drafts.has(key)) {
    drafts.set(key, VokageiProgress.getDraft(MODULE_NAME, currentPart, idKey));
  }
  return drafts.get(key);
}

function getGapMeta(topic, gapNum) {
  if (currentPart === 1) {
    const qObj = topic.questions[String(gapNum)];
    const letters = ["a", "b", "c"];
    const choices = qObj.options.map((opt, idx) => [letters[idx], opt]);
    return {
      choices,
      correctKey: letters[qObj.answer],
      noteText: qObj.note || "",
    };
  }
  const ansObj = topic.answers[String(gapNum)];
  return {
    choices: Object.entries(topic.words),
    correctKey: ansObj.key.toLowerCase(),
    noteText: ansObj.note || "",
  };
}

function renderTest(topic) {
  const draft = getDraft();
  const wrapper = element("div", "exercise-layout single-col");
  const panel = element("form", "answer-panel");
  const body = element("div", "passage reading-scroll");

  const metaText = `${topic.category || "Sprachbausteine"}${topic.page ? ` · S. ${topic.page}` : ""}`;
  body.append(element("span", "passage-meta", metaText));

  const btnMap = new Map();
  const paragraphs = topic.text.split(/\n\n+/);
  const textEntry = element("section", "passage-entry");
  for (const para of paragraphs) {
    const p = element("p");
    const lines = para.split("\n");
    lines.forEach((line, lineIdx) => {
      if (lineIdx > 0) p.append(document.createElement("br"));
      const segments = line.split(/(\{\{\d+\}\})/g);
      for (const seg of segments) {
        const m = seg.match(/^\{\{(\d+)\}\}$/);
        if (m) {
          const gapNum = Number(m[1]);
          const btn = element("button", "gap-btn", `[${gapNum} · wählen]`);
          btn.type = "button";
          btn.dataset.gap = String(gapNum);
          btn.addEventListener("click", () => {
            const meta = getGapMeta(topic, gapNum);
            const used = new Set(draft.answers.values());
            const cur = draft.answers.get(gapNum) ?? "";
            openGapPopup(gapNum, meta.choices, cur, used, (picked) => {
              if (picked) draft.answers.set(gapNum, picked);
              else draft.answers.delete(gapNum);
              draft.graded = false;
              updateUI();
            });
          });
          btnMap.set(gapNum, btn);
          p.append(btn);
        } else if (seg) {
          p.append(document.createTextNode(seg));
        }
      }
    });
    textEntry.append(p);
  }
  body.append(textEntry);

  const wordBankItems = new Map();
  if (currentPart === 2 && topic.words) {
    const wbSection = element("section", "passage-entry");
    wbSection.append(element("h3", "", "Wortliste A–O"));
    const ul = element("ul", "word-bank");
    for (const [k, w] of Object.entries(topic.words)) {
      const li = element("li", "", `${k.toUpperCase()} · ${w}`);
      li.dataset.wordKey = k;
      wordBankItems.set(k, li);
      ul.append(li);
    }
    wbSection.append(ul);
    body.append(wbSection);
  }

  const feedbackSection = element("section", "passage-entry");
  feedbackSection.hidden = true;
  body.append(feedbackSection);

  const controls = element("div", "answer-controls");
  const submit = element("button", "cta model-cta", "Antworten prüfen");
  submit.type = "submit";
  const resetBtn = element("button", "secondary-cta", "Zurücksetzen");
  resetBtn.type = "button";
  const result = element("p", "set-result");
  result.setAttribute("role", "status");
  controls.append(submit, resetBtn, result);

  panel.append(body, controls);
  wrapper.append(panel);

  function updateUI() {
    const nums = gapNumbers(currentPart);
    const used = new Set(draft.answers.values());
    for (const [k, li] of wordBankItems.entries()) {
      if (used.has(k)) li.dataset.used = "true";
      else delete li.dataset.used;
    }

    let correctCount = 0;
    const fbLines = [];
    for (const gapNum of nums) {
      const meta = getGapMeta(topic, gapNum);
      const chosen = draft.answers.get(gapNum);
      const btn = btnMap.get(gapNum);
      const correct = chosen === meta.correctKey;
      if (correct) correctCount += 1;

      if (btn) {
        if (chosen) {
          const chosenWord = meta.choices.find(([k]) => k === chosen)?.[1] ?? chosen;
          btn.textContent = `[${gapNum} · ${chosenWord}]`;
          btn.dataset.filled = "true";
        } else {
          btn.textContent = `[${gapNum} · wählen]`;
          delete btn.dataset.filled;
        }
        if (draft.graded && chosen) {
          btn.dataset.state = correct ? "correct" : "incorrect";
        } else {
          delete btn.dataset.state;
        }
      }

      if (draft.graded) {
        const pLine = element("p", "answer-result");
        const sol = meta.choices.find(([k]) => k === meta.correctKey)?.[1] ?? "";
        const expl = meta.noteText ? ` — ${meta.noteText}` : "";
        if (!chosen) {
          pLine.textContent = `Lücke ${gapNum}: Noch unbeantwortet.`;
        } else {
          pLine.dataset.state = correct ? "correct" : "incorrect";
          pLine.textContent = correct
            ? `Lücke ${gapNum}: Richtig! (${meta.correctKey.toUpperCase()} · ${sol})${expl}`
            : `Lücke ${gapNum}: Richtige Antwort: ${meta.correctKey.toUpperCase()} · ${sol}${expl}`;
        }
        fbLines.push(pLine);
      }
    }

    if (draft.graded) {
      feedbackSection.hidden = false;
      feedbackSection.replaceChildren(element("h3", "", "Auswertung & Erklärungen"), ...fbLines);
    } else {
      feedbackSection.hidden = true;
      feedbackSection.replaceChildren();
    }

    const pct = updateCurrentTopicProgressUI(draft);
    controls.style.setProperty("--progress", `${pct}%`);
    result.textContent = draft.graded
      ? `${correctCount} von ${nums.length} richtig · ${nums.length - draft.answers.size} offen`
      : `${draft.answers.size} von ${nums.length} ausgefüllt`;
  }

  panel.addEventListener("submit", (e) => {
    e.preventDefault();
    draft.graded = true;
    updateUI();
  });
  resetBtn.addEventListener("click", () => {
    const idKey = String(currentTopic.num || currentTopic.id);
    draft.answers.clear();
    draft.graded = false;
    VokageiProgress.clearDraft(MODULE_NAME, currentPart, idKey);
    updateUI();
  });

  updateUI();
  return wrapper;
}

function renderExercise(focusHeading) {
  const idKey = String(currentTopic.num || currentTopic.id);
  const header = element("header", "exercise-heading");
  const titleWrap = element("div");
  const heading = element("h2", "", `Test ${idKey} – ${topicTitle(currentTopic)}`);
  heading.tabIndex = -1;
  titleWrap.append(heading, element("p", "", descriptions[currentPart]));
  header.append(titleWrap);
  exercise.replaceChildren(header, renderTest(currentTopic));
  if (focusHeading) heading.focus({ preventScroll: true });
}

function showLocation(focusHeading = false) {
  const route = location.hash.match(/^#teil-([12])(?:\/([a-z0-9]+))?$/i);
  const part = Number(route?.[1] ?? 1);
  const id = route?.[2]?.toLowerCase() ?? selections.get(part);
  const topic = parts[part].find((c) => String(c.num || c.id).toLowerCase() === id) ?? parts[part][0];
  if (part !== currentPart) {
    topicSearch.value = "";
    topicList.scrollTop = 0;
    for (const link of partLinks) {
      if (link.hash === `#teil-${part}`) link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    }
  }
  if (part === currentPart && topic === currentTopic) {
    if (focusHeading) exercise.querySelector("h2").focus({ preventScroll: true });
    return;
  }
  currentPart = part;
  currentTopic = topic;
  selections.set(part, String(topic.num || topic.id).toLowerCase());
  renderTopics();
  renderExercise(focusHeading);
  window.scrollTo({ top: 0, behavior: "instant" });
}

function navigate(event) {
  const link = event.target.closest("a");
  if (!link || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  const fromPicker = topicList.contains(link);
  if (location.hash !== link.hash) history.pushState(null, "", link.hash);
  if (fromPicker && narrowScreen.matches) topicPicker.open = false;
  showLocation(fromPicker);
}

if (narrowScreen.matches) topicPicker.open = false;
document.querySelector(".reading-parts").addEventListener("click", navigate);
topicList.addEventListener("click", navigate);
topicSearch.addEventListener("input", renderTopics);
window.addEventListener("hashchange", () => showLocation());
window.addEventListener("popstate", () => showLocation());
showLocation();
