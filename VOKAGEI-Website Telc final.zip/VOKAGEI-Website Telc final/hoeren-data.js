const hoerenData = {
  "1": [
    {
      "id": "1",
      "title": "Test 1 – In der Europäischen Union",
      "isVariant": false,
      "note": "PDF Seite 2 (S. 468). Richtig (+): 41, 42.",
      "questions": [
        {
          "num": 41,
          "text": "In der Europäischen Union verzeichnet man weniger jugendliche Arbeitslose.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Das Bundesarbeitsministerium bemüht sich um ausländische Arbeitnehmer bestimmter Berufe.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Die „Lange Nacht der Musik“ findet am Odeonsplatz in München statt.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Im „Tal der goldenen Mumien“ wurden bisher fast 10.000 Tote gefunden.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Die Gefahr schwerer Unwetter ist nun vorbei.",
          "answer": "-"
        }
      ],
      "code": "12"
    },
    {
      "id": "2",
      "title": "Test 2 – Unwetterschäden",
      "isVariant": false,
      "note": "PDF Seite 3 (S. 469). Richtig (+): 41, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Wegen Unwetterschäden wurden Urlauber in einer Notunterkunft untergebracht.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Sämtliche Waren der Firma Mirella wurden aus den Läden entfernt.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Das Arbeitsplatzangebot in der Bundesrepublik hat einen Tiefstand erreicht.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Am 21. Mai ist der Besuch der Sonderausstellung kostenlos.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Entlaufene Tiere verursachten einen Unfall auf der Autobahn.",
          "answer": "-"
        }
      ],
      "code": "14"
    },
    {
      "id": "3",
      "title": "Test 3 – Es ist nicht sicher",
      "isVariant": false,
      "note": "PDF Seite 4 (S. 470). Richtig (+): 41, 44. (Aufgabe 41 mit „nicht sicher“ statt „unklar“ in 3a).",
      "questions": [
        {
          "num": 41,
          "text": "Es ist nicht sicher, ob es erneut zu diesem Problem kommen kann.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Hamburgs Politiker befürworteten den Bau des Einkaufszentrums nicht.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Zwischen Frankreich und Deutschland wurde ein neuer Hochgeschwindigkeitszug in Betrieb genommen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Die Produkte von TipTop sind in Deutschland nicht mehr so gefragt.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Ingrid Thieme wird sich an der kommenden WM beteiligen.",
          "answer": "-"
        }
      ],
      "code": "14"
    },
    {
      "id": "3a",
      "title": "Test 3a – Es ist unklar (Variante)",
      "isVariant": true,
      "note": "PDF Seite 5 (S. 471). Richtig (+): 41, 44. Variante zu Test 3 (Aufgabe 41 umformuliert mit „unklar“).",
      "questions": [
        {
          "num": 41,
          "text": "Es ist unklar, ob das Problem noch einmal auftreten kann.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Hamburgs Politiker befürworteten den Bau des Einkaufszentrums nicht.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Zwischen Frankreich und Deutschland wurde ein neuer Hochgeschwindigkeitszug in Betrieb genommen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Die Produkte von TipTop sind in Deutschland nicht mehr so gefragt.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Ingrid Thieme wird sich an der kommenden WM beteiligen.",
          "answer": "-"
        }
      ],
      "code": "14"
    },
    {
      "id": "4",
      "title": "Test 4 – Erdbeben",
      "isVariant": false,
      "note": "PDF Seite 6 (S. 472). Richtig (+): 41, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Nach dem Erdbeben meldeten viele Bürger Schäden bei Polizei und Feuerwehr.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Eltern müssen sich neuerdings über den Impfschutz für ihre Kinder beraten lassen.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Verkehrsbehinderungen drohen in den nächsten Wochen besonders samstags und sonntags.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Pipelines tragen maßgeblich zur Umweltverschmutzung in Schleswig-Holstein bei.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Anfang nächster Woche ist mit einer erhöhten Ozonbelastung zu rechnen.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "5",
      "title": "Test 5 – Lufthansa",
      "isVariant": false,
      "note": "PDF Seite 7 (S. 473). Richtig (+): 42, 43. (Aufgabe 43: „Die Rahmenbedingungen in deutschen Pflegeheimen bedürfen dringend einer Änderung.“).",
      "questions": [
        {
          "num": 41,
          "text": "Die Deutsche Lufthansa hat ihre Führungsposition verloren.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Ein Bonner Sportverein zeigt der Öffentlichkeit sein Angebot.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Die Rahmenbedingungen in deutschen Pflegeheimen bedürfen dringend einer Änderung.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Durch moderne Wärmedämmung könnten die Heizkosten deutlich reduziert werden.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Das Nationale Olympische Komitee hat die Dopingsperre für Tom Sanders aufgehoben.",
          "answer": "-"
        }
      ],
      "code": "23"
    },
    {
      "id": "5a",
      "title": "Test 5a – Lufthansa (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 4 (Lufthansa - المعدل UP4) & Korrigiert PDF. Richtig (+): 42, 43 (Code 23).",
      "questions": [
        {
          "num": 41,
          "text": "Die Deutsche Lufthansa hat ihre Führungsposition verloren.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Ein Bonner Sportverein zeigt der Öffentlichkeit sein Angebot.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Die Rahmenbedingungen in deutschen Pflegeheimen bedürfen dringend einer Änderung. (Variante Korrigiert-PDF: Die Situation im Pflegesektor hat sich noch nicht verbessert.)",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Durch moderne Wärmedämmung könnten die Heizkosten deutlich reduziert werden.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Das Nationale Olympische Komitee hat die Dopingsperre für Tom Sanders aufgehoben.",
          "answer": "-"
        }
      ],
      "code": "23"
    },
    {
      "id": "5b",
      "title": "Test 5b – Die Piloten der Lufthansa (Variante)",
      "isVariant": true,
      "note": "PDF Seite 9 (S. 475). Richtig (+): 43, 45. Eigenständiger Nachrichtentest, im PDF als „5b“ nummeriert.",
      "questions": [
        {
          "num": 41,
          "text": "Die Piloten der Lufthansa kämpfen für eine bessere Bezahlung.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Das Gesundheitsministerium empfiehlt allen Bürgern eine Grippeimpfung.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Immer mehr Menschen besuchen den „Tag des offenen Denkmals“.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Die Mehrheit der deutschen Arbeitnehmer würde auch im Ausland arbeiten.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Bei den Fußballspielen gab es keinen Sieger.",
          "answer": "+"
        }
      ],
      "code": "35"
    },
    {
      "id": "6",
      "title": "Test 6 – Bierkonsum",
      "isVariant": false,
      "note": "PDF Seite 10 (S. 476). Richtig (+): 42, 44. (Aufgabe 41: „Der Bierkonsum steigt um 10 %.“; Aufgabe 44 im Passiv).",
      "questions": [
        {
          "num": 41,
          "text": "Der Bierkonsum steigt um 10 %.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Deutsche Einkommen liegen im europäischen Vergleich nur im Mittelfeld.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Es ist ein Ende des Bahnstreiks in Sicht.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Es wird Gewalt von Fußballfans auch in Deutschland befürchtet.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Die Leopoldina soll internationale Akademie werden.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "6a",
      "title": "Test 6a – Bierkonsum (Variante)",
      "isVariant": true,
      "note": "PDF Seite 11 (S. 477). Richtig (+): 42, 44. Variante zu Test 6 (Aufgabe 41 mit „Verbrauch von Bier“, Aufgabe 44 im Aktiv mit „Man befürchtet...“).",
      "questions": [
        {
          "num": 41,
          "text": "Der Verbrauch von Bier steigt um 10 %.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Deutsche Einkommen liegen im europäischen Vergleich nur im Mittelfeld.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Es ist ein Ende des Bahnstreiks in Sicht.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Man befürchtet auch in Deutschland Gewalt von Fußballfans.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Die Leopoldina soll internationale Akademie werden.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "7",
      "title": "Test 7 – Ein deutsches Schiff",
      "isVariant": false,
      "note": "PDF Seite 12 (S. 478). Richtig (+): 41, 42, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Ein deutsches Schiff ist am Südpol eingefroren, aber Menschen kamen nicht zu Schaden.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Die Firma Brain International ist in wirtschaftliche Schwierigkeiten geraten.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Die Europäische Union will Gesetze zur Kontrolle sozialer Netzwerke erlassen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Mit einem neuen Gesetz wollen die österreichischen Banken Sparkonten wieder attraktiver machen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Nach den Bürgermeisterwahlen in Bensheim bleibt die CDU weiterhin an der Regierung.",
          "answer": "+"
        }
      ],
      "code": "125"
    },
    {
      "id": "8",
      "title": "Test 8 – Frau Jürgens",
      "isVariant": false,
      "note": "PDF Seite 13 (S. 479). Richtig (+): 43, 44, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Frau Jürgens tritt wegen Streitigkeiten zurück.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Die Filme werden in den Kinos der Stadt gezeigt.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Der öffentliche Nahverkehr funktioniert noch nicht störungsfrei.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Wildes Camping ist im In- und Ausland nur bedingt zugelassen.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Die Temperaturen steigen in den nächsten Tagen an.",
          "answer": "+"
        }
      ],
      "code": "345"
    },
    {
      "id": "9",
      "title": "Test 9 – Die Fluggesellschaft",
      "isVariant": false,
      "note": "PDF Seite 14 (S. 480). Richtig (+): 41, 45. (Aufgabe 41: „Die Fluggesellschaft DL fliegt z. B. Rostock nicht mehr an.“).",
      "questions": [
        {
          "num": 41,
          "text": "Die Fluggesellschaft DL fliegt z. B. Rostock nicht mehr an.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Süßwaren werden in diesem Jahr günstiger angeboten, um Käufer zurückzugewinnen.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Die Sonnenstürme hatten keine negativen Auswirkungen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Einer der Kandidaten konnte die Mehrheit der Zuschauer für sich gewinnen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Das Tiefdruckgebiet „Helena“ kann morgen im Südwesten Deutschlands zu Verkehrsproblemen führen.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "9a",
      "title": "Test 9a – Die Fluggesellschaft (Variante)",
      "isVariant": true,
      "note": "PDF Seite 15 (S. 481). Richtig (+): 41, 45. Variante zu Test 9 (Aufgabe 41: „Kunden der Fluggesellschaft DL äußern Unzufriedenheit.“).",
      "questions": [
        {
          "num": 41,
          "text": "Kunden der Fluggesellschaft DL äußern Unzufriedenheit.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Die Preise von Süßwaren wurden dieses Jahr gesenkt, um Käufer zurückzugewinnen.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Die Sonnenstürme hatten keine negativen Auswirkungen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Einer der Kandidaten konnte die Mehrheit der Zuschauer auf seine Seite ziehen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Das Tiefdruckgebiet „Helena“ kann morgen im Südwesten Deutschlands Verkehrsprobleme verursachen.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "10",
      "title": "Test 10 – Vögel",
      "isVariant": false,
      "note": "PDF Seite 16 (S. 482). Richtig (+): 43, 44, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Viele Kunden würden für bessere Serviceleistungen der Paketdienste höhere Gebühren zahlen.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Nach dem Unfall konnten beide Schiffe ihre Fahrt nicht fortsetzen.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Europaweit gibt es immer weniger Vögel.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Die Polizei hat auf der Autobahn ein verbotenes Fahrzeug entdeckt.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Bei dem Festival konnte man Konzerte an verschiedenen Orten besuchen.",
          "answer": "+"
        }
      ],
      "code": "345"
    },
    {
      "id": "11",
      "title": "Test 11 – Die Wahlbeteiligungen",
      "isVariant": false,
      "note": "PDF Seite 17 (S. 483). Richtig (+): 41, 43.",
      "questions": [
        {
          "num": 41,
          "text": "Die Wahlbeteiligung in Deutschland nimmt wieder zu.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "150 Bauarbeiter müssen entlassen werden.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Bei der Sportveranstaltung wurden neue Bestzeiten aufgestellt.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Die Sicherheitslücke beim Online-Banking wurde noch nicht gefunden.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Kinder können in der Bücherei ihre eigenen Texte vorlesen.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "12",
      "title": "Test 12 – Die Stadt Friedrichsberg",
      "isVariant": false,
      "note": "PDF Seite 18 (S. 484). Richtig (+): 42, 43, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Die Stadt Friedrichsberg lädt zu einer Preisverleihung ein.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Die Alte Brücke ist zum Jahresbeginn wieder befahrbar.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Der Wanderer wurde verletzt in Sicherheit gebracht.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "In dem Unternehmen gibt es Kündigungen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Man kann nach einer Registrierung an einem Gruppenlauf teilnehmen.",
          "answer": "+"
        }
      ],
      "code": "235"
    },
    {
      "id": "13",
      "title": "Test 13 – In den Alpen",
      "isVariant": false,
      "note": "PDF Seite 19 (S. 485). Richtig (+): 42, 43. (In dieser Version ist Aufgabe 44 zur Pandafamilie Falsch (-)).",
      "questions": [
        {
          "num": 41,
          "text": "Die Wetterlage in den Alpen wird sich in den nächsten Tagen verbessern.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Die Fans des FC Neustadt waren von dem Sieg ihrer Mannschaft überrascht.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Erzieherinnen verlangen eine bessere Bezahlung.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Im Berliner Zoo gibt es eine große Pandafamilie.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Die Zahl der Deutschland-Urlauber ist rückläufig.",
          "answer": "-"
        }
      ],
      "code": "23"
    },
    {
      "id": "13a",
      "title": "Test 13a – In den Alpen (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 19 (in den Alpen - المعدل). Richtig (+): 42, 43, 45 (Code 235).",
      "questions": [
        {
          "num": 41,
          "text": "Die Wetterlage in den Alpen wird sich in den nächsten Tagen verbessern.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Die Fans, die das Spiel unterstützten, waren vom Sieg ihrer Mannschaft überrascht.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Eine Familie von Pandas kommt im Park an.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Urlaub in Deutschland ist mit weniger Kosten verbunden.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Erzieherinnen verlangen eine bessere Bezahlung.",
          "answer": "+"
        }
      ],
      "code": "235"
    },
    {
      "id": "14",
      "title": "Test 14 – Insel Bali",
      "isVariant": false,
      "note": "PDF Seite 21 (S. 487). Richtig (+): 44, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Auf der Insel Bali wurden neue Maßnahmen zur Müllentsorgung beschlossen.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "In Nordfrankreich wird nach einem entlaufenen Panther gesucht.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Die Mietervereinigung rät Mietern, die Betriebskosten nicht zu bezahlen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Der Sekthersteller hat die Pläne für sein Bauvorhaben geändert.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Die Löscharbeiten sind noch nicht abgeschlossen.",
          "answer": "+"
        }
      ],
      "code": "45"
    },
    {
      "id": "15",
      "title": "Test 15 – 50-Euro-Noten, Pflichtjahr in Landarztpraxis, Mars-Forschung in Mainz, Lehrerstellen & Schwarzarbeit [Code 3]",
      "isVariant": false,
      "note": "PDF Seite 22 (S. 488). Richtig (+): 43.",
      "questions": [
        {
          "num": 41,
          "text": "Die 50-Euro-Noten der Deutschen Bundesbank sind jetzt fälschungssicherer.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Der Ärzteverband hat gefordert, dass junge Ärzte in Zukunft ein Pflichtjahr in einer Landarztpraxis absolvieren müssen.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Wissenschaftler der Universität Mainz sind am Projekt zur Erforschung des Planeten Mars beteiligt.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Der Verband Bildung und Erziehung fordert 10.000 zusätzliche Lehrerstellen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Die Schwarzarbeit hat im vergangenen Jahr um 15 % zugenommen.",
          "answer": "-"
        }
      ],
      "code": "3"
    },
    {
      "id": "16",
      "title": "Test 16 – Das Schladminger",
      "isVariant": false,
      "note": "PDF Seite 23 (S. 489). Richtig (+): 41, 42, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Das Schladminger Skirennen fällt wieder aus.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Mehr Mädchen als Jungen leisten als pflegende Kinder und Jugendliche Betreuungsarbeit in den Familien.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Ein Grazer Wohnhaus brannte bei einem Großbrand komplett aus.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Alle bei Australien gestrandeten Wale sind verendet.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Insgesamt bleibt es mild.",
          "answer": "+"
        }
      ],
      "code": "125"
    },
    {
      "id": "17",
      "title": "Test 17 – Bei den Europawahlen",
      "isVariant": false,
      "note": "PDF Seite 24 (S. 490). Richtig (+): 43, 45. (Aufgabe 41 zu Linksparteien ist Falsch (-)).",
      "questions": [
        {
          "num": 41,
          "text": "Bei den Europawahlen haben die Linksparteien deutlich zugelegt.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Die Tarifverhandlungen haben sich aufgrund internationaler Einflussfaktoren verschärft.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Der Benzinpreis hat sich aufgrund internationaler Einflussfaktoren erhöht.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Die Rechtschreibreform in den deutschsprachigen Ländern wird abermals überarbeitet.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Bei einem S-Bahn-Unglück in München gab es zahlreiche Verletzte und einen hohen Sachschaden.",
          "answer": "+"
        }
      ],
      "code": "35"
    },
    {
      "id": "17a",
      "title": "Test 17a (Variante) – Europawahlen (CDU und CSU), Tarifverhandlungen, Benzinpreis, Rechtschreibreform & S-Bahn-Unglück in München [Code 135]",
      "isVariant": true,
      "note": "PDF Seite 25 (S. 491). Richtig (+): 41, 43, 45. Variante zu Test 17 (Aufgabe 41 zu CDU und CSU ist Richtig (+)).",
      "questions": [
        {
          "num": 41,
          "text": "Bei den Europawahlen haben die CDU und CSU fast die Hälfte aller Stimmen erhalten.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Die Tarifverhandlungen haben sich aufgrund internationaler Einflussfaktoren verschärft.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Der Benzinpreis hat sich aufgrund internationaler Einflussfaktoren erhöht.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Die Rechtschreibreform in den deutschsprachigen Ländern wird abermals überarbeitet.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Bei einem S-Bahn-Unglück in München gab es zahlreiche Verletzte und einen hohen Sachschaden.",
          "answer": "+"
        }
      ],
      "code": "135"
    },
    {
      "id": "18",
      "title": "Test 18 – Die Bundesländer",
      "isVariant": false,
      "note": "PDF Seite 26 (S. 492). Richtig (+): 41, 42, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Die Bundesländer sollen in Zukunft Geld für alternative Energien bekommen.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Wenn man im Internet etwas kaufen möchte, sollte man seine Identität nachweisen müssen.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Bei einem Überfall wurde ein Schiff gezwungen, Richtung Küste zu fahren.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Laut Tourismusminister soll man einen geplanten Urlaub auf Gran Canaria absagen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Es ist derzeit noch nicht entschieden, wie lange der Streik dauern soll.",
          "answer": "+"
        }
      ],
      "code": "125"
    },
    {
      "id": "19",
      "title": "Test 19 – Ein Treffen bei der Integrationsbeauftragten",
      "isVariant": false,
      "note": "PDF Seite 27 (S. 493). Richtig (+): 41, 43, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Ein Treffen bei der Integrationsbeauftragten soll dazu beitragen, die Integration von Migrantinnen und Migranten zu verbessern.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "In Teilen von Karlsruhe gab es am Mittwochabend vierzig Minuten lang keinen Strom.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Eine Untersuchung zum Essverhalten der Deutschen zeigt: Viele haben Gewichtsprobleme.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Chinas Polizei hilft Unwetteropfern.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Später Bestattungsritus für Mahatma Gandhi.",
          "answer": "+"
        }
      ],
      "code": "135"
    },
    {
      "id": "20",
      "title": "Test 20 – Bild am Sonntag",
      "isVariant": false,
      "note": "PDF Seite 28 (S. 494). Richtig (+): 41, 42, 43.",
      "questions": [
        {
          "num": 41,
          "text": "Laut BILD AM SONNTAG können in Zukunft nur Mieter, aber nicht Vermieter bestimmte Mietverträge schneller kündigen.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "In bestimmten Bundesländern sollen Wohnhäuser abgerissen werden, weil sie unbewohnt sind.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Sowohl die Waldbrände als auch die Hitzewelle in Griechenland sind zu Ende.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "In Kanada mussten die Bergungsarbeiten nach einem Tornado wegen erneuter Unwetterwarnungen eingestellt werden.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Bei einem Fährunglück in der Nähe von Gibraltar gab es nur Sachschaden.",
          "answer": "-"
        }
      ],
      "code": "123"
    },
    {
      "id": "21",
      "title": "Test 21 – Studentenparty in Frankreich",
      "isVariant": false,
      "note": "PDF Seite 29 (S. 495). Richtig (+): 43, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Bayern und Nordrhein-Westfalen erhalten zukünftig jedes Jahr 2,3 Milliarden Euro für den Bau neuer Autobahnen.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Wegen hoher Minustemperaturen findet in ganz Russland kein Unterricht statt.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Bei einer Studentenparty in Frankreich gibt es Tote und Verletzte.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Das Bundesfinanzministerium hat im letzten Jahr die Steuern gesenkt.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Die Regierung plant eine Änderung bei der Führerschein-Probezeit.",
          "answer": "+"
        }
      ],
      "code": "35"
    },
    {
      "id": "22",
      "title": "Test 22 – Deutsche Filmmuseum",
      "isVariant": false,
      "note": "PDF Seite 30 (S. 496). Richtig (+): 42, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Die Quote der Hochschulabsolventen in Deutschland ist auf den internationalen Durchschnittswert von 32 % angestiegen.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Berufspendler kritisieren unnötige Wartezeiten und Kosten der täglichen Fahrten.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Der Deutsche Bauernverband ist mit den diesjährigen Ernteerträgen im Allgemeinen zufrieden.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Das Deutsche Filmmuseum möchte die Besucherzahlen in Zukunft erhöhen.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Die Laufroute des Mainzer Gutenberg-Marathons führt traditionell nach Wiesbaden.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "23",
      "title": "Test 23 – Die Zahl der Arbeitslosen",
      "isVariant": false,
      "note": "PDF Seite 31 (S. 497). Richtig (+): 41, 42, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Die Zahl der Arbeitslosen in Deutschland hat sich im Mai verringert.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Mexiko und Russland wollen ihre Zusammenarbeit in den Bereichen Wirtschaft und Finanzen weiter vertiefen.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Der deutsche Einzelhandel ist mit den Ergebnissen des Sommerschlussverkaufs sehr zufrieden.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Der Präsident der Weltbank äußerte sich besorgt über die Entwicklungshilfe für die sogenannte „Dritte Welt“.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Bei einer Explosion im Erich-Kästner-Kinderdorf starben vier Jugendliche.",
          "answer": "-"
        }
      ],
      "code": "124"
    },
    {
      "id": "24",
      "title": "Test 24 – Konjunkturentwicklung negativ",
      "isVariant": false,
      "note": "PDF Seite 32 (S. 498). Richtig (+): 41, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Experten aus Bankenwelt und Wirtschaft sehen die Konjunkturentwicklung negativ.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Die Bundesregierung hat sich erneut gegen die Förderung von Eliteuniversitäten entschieden.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Beim Filmfestival in Cannes hat nach elf Jahren wieder ein deutscher Film den ersten Preis gewonnen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Das Internationale Olympische Komitee trifft sich in Lausanne, um über den Austragungsort für die Olympischen Spiele 2012 zu beraten.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "In Hessen gibt es ein Überangebot an Lehrstellen.",
          "answer": "-"
        }
      ],
      "code": "14"
    },
    {
      "id": "25",
      "title": "Test 25 – Internationale Konferenz",
      "isVariant": false,
      "note": "PDF Seite 33 (S. 499). Richtig (+): 41, 43.",
      "questions": [
        {
          "num": 41,
          "text": "Auf einer internationalen Konferenz in Bonn wurde beschlossen, weltweit verstärkt umweltfreundliche Energien zu nutzen.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Die Luftfahrtgesellschaft Adler stellt wieder Mitarbeiter ein.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "In Ulm beginnt heute der Katholikentag, ein großes christliches Laientreffen in Deutschland.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Die Bundesregierung hat zum Schutz jugendlicher Verbraucher eine Steuer auf alkoholhaltige Mischgetränke eingeführt.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "In Hagen gab es ein Sprengstoffunglück.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "26",
      "title": "Test 26 – Um Tickets zu gewinnen",
      "isVariant": false,
      "note": "PDF Seite 34 (S. 500). Richtig (+): 43, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Um Tickets zu gewinnen, muss man wissen, wann die Veranstaltung ist.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "In nur 11 Tagen spielte der Film „Jurassic World“ außerhalb der USA mehr als 700 Millionen Dollar ein.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "In Kärnten kann es aufgrund von starkem Gegenverkehr zu Verzögerungen kommen.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Aufgrund einer Kaltfront sinkt die Schneefallgrenze entlang der Alpennordseite knapp unter 2000 m herab.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Mit Frankreich gegen Kanada steht das erste Viertelfinale der Frauenfußball-WM fest.",
          "answer": "-"
        }
      ],
      "code": "34"
    },
    {
      "id": "27",
      "title": "Test 27 – Die tschechische Stadt Pilsen",
      "isVariant": false,
      "note": "PDF Seite 35 (S. 501). Richtig (+): 41, 42.",
      "questions": [
        {
          "num": 41,
          "text": "Die tschechische Stadt Pilsen ist europäische Kulturhauptstadt 2015.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "In der Nähe von St. Veit an der Glan gab es einen Autounfall mit einem Toten.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Den Film „Everest“ kann man schon jetzt in allen europäischen Kinos sehen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Nach Gewittern wird es im Nordwesten Österreichs wieder wärmer.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Wassermänner haben in dieser Woche rundum Glück in Beruf, Gesundheit und Liebe.",
          "answer": "-"
        }
      ],
      "code": "12"
    },
    {
      "id": "28",
      "title": "Test 28 – Laut Statistischem Bundesamt",
      "isVariant": false,
      "note": "PDF Seite 36 (S. 502). Richtig (+): 41, 44, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Laut Statistischem Bundesamt müssen junge Leute mit fehlenden Berufserfahrungen häufig ein zeitlich begrenztes Arbeitsverhältnis eingehen.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Auf der Autobahn Richtung Stuttgart kam es zum Unfall, weil das Tempolimit überschritten wurde.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Die chinesische Botschaft in München wählte die Namen für die zwei Pandabären aus.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Sowohl Asien als auch Europa tragen zur Verschmutzung der Meere durch Plastikmüll bei.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Das neuartige Ampelsystem zur Verbesserung der Sicherheit von Fußgängern befindet sich aktuell in der Testphase.",
          "answer": "+"
        }
      ],
      "code": "145"
    },
    {
      "id": "29",
      "title": "Test 29 – In Frankfurt haben Manager",
      "isVariant": false,
      "note": "PDF Seite 37 (S. 503). Richtig (+): 41, 42, 43.",
      "questions": [
        {
          "num": 41,
          "text": "München wurde wieder zur Stadt mit der höchsten Lebensqualität in Deutschland gewählt.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "In Frankfurt haben Manager darüber diskutiert, was Unternehmen tun müssen, um zukünftig weiterhin erfolgreich zu sein.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Nach Worten des Ministers fördert mobiles Arbeiten das Wirtschaftswachstum und die Produktivität.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Da es im Sommer in Katar zu heiß ist, sind die europäischen Fußballclubs mit der Entscheidung der FIFA, die WM 2022 im Winter austragen zu lassen, zufrieden.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Das Wetter bleibt in den nächsten Tagen kühl und unbeständig.",
          "answer": "-"
        }
      ],
      "code": "123"
    },
    {
      "id": "30",
      "title": "Test 30 – Für die Polizei in Berlin",
      "isVariant": false,
      "note": "PDF Seite 38 (S. 504). Richtig (+): 41, 42, 44, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Innenstädte werden immer weniger interessant.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Für die Polizei in Berlin gab es einen schwierigen Fall.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Der Düsseldorfer Flughafen möchte bald neue Flugziele anbieten.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Musiker gaben ein Konzert für einen guten Zweck.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Deutsche Wintersportler sind bei den Olympischen Spielen erfolgreich.",
          "answer": "+"
        }
      ],
      "code": "1245"
    },
    {
      "id": "31",
      "title": "Test 31 – Die Sprecherin ist verheiratet",
      "isVariant": false,
      "note": "PDF Seite 39 (S. 505). Richtig (+): 41, 43, 44. (Aufgabenstellung: „Sie hören nun fünf kurze Texte“).",
      "questions": [
        {
          "num": 41,
          "text": "Die Sprecherin möchte allein leben und machen können, was sie will.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Der Sprecher wohnt mit seiner Partnerin in einer großen Wohnung.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Die Sprecherin ist verheiratet und hat zwei Kinder.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Der Sprecher ist geschieden und lebt mit seiner Tochter bei einer anderen Familie.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Die Sprecherin wollte nie viele Kinder haben.",
          "answer": "-"
        }
      ],
      "code": "134"
    },
    {
      "id": "32",
      "title": "Test 32 – Bei der Sportveranstaltung",
      "isVariant": false,
      "note": "PDF Seite 40 (S. 506). Richtig (+): 42, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Die ÖBB wollen ihre Kooperation mit den Schweizer Bundesbahnen (SBB) ausbauen.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Aufgrund eines Unfalls kam es zu einem Großaufgebot von Einsatzwägen.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Baden bereitet den Antrag für die Aufnahme als „Kleine historische Stadt“ vor.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Bei der Sportveranstaltung „Stilecht“ sind Fahrräder aller Arten vertreten.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "In den nächsten Wochen sind österreichweit starke Niederschläge zu erwarten.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "33",
      "title": "Test 33 – Das Bundesfamilienministerium",
      "isVariant": false,
      "note": "PDF Seite 41 (S. 507). Richtig (+): 42, 44. Entspricht dem Deckblatt-Hinweis „-Sheinenwege (24)“.",
      "questions": [
        {
          "num": 41,
          "text": "In Zukunft wird es schwieriger sein, Bauvorhaben des Bundes – wie Autobahnen oder Schienenwege – zu verhindern.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Eine weitere Verlängerung der Lebensarbeitszeit würde keine ernsthaften sozialen Probleme verursachen.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Der auf der Nordsee in Seenot geratene Fischkutter ist inzwischen gefunden worden.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Das Bundesfamilienministerium betrachtet den Ausbau der Familienpolitik als abgeschlossen.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Für Kinder, die sich im Kindergarten beim Spielen verletzen, haftet nicht automatisch die Einrichtung.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "34",
      "title": "Test 34 – Meeresküsten",
      "isVariant": false,
      "note": "PDF Seite 42 (S. 508). Richtig (+): 42, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Laut einer Studie wurden seit Jahresbeginn in Deutschland und China deutlich mehr Autos verkauft.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "An den deutschen Meeresküsten soll in Zukunft mehr Windkraft produziert werden.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Jede Polizeidienststelle kann ab sofort selbst entscheiden, welche Tätowierungen ihre Bewerberinnen und Bewerber haben dürfen.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Durch Luftverschmutzung und Ascheregen sind im Osten Australiens zahlreiche Tiere ums Leben gekommen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Ein aufmerksamer Nachbar verhindert den geplanten Einbruch in ein Wohnhaus.",
          "answer": "+"
        }
      ],
      "code": "25"
    },
    {
      "id": "35",
      "title": "Test 35 – Bauern warnen",
      "isVariant": false,
      "note": "PDF Seite 43 (S. 509). Richtig (+): 42, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Spektakulärer Drogenfund: Polizei entdeckt Kokain auf einem Frachtschiff.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Bauern warnen: Zu viel Umweltschutz gefährdet die Existenz vieler Bauernhöfe.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Verschiedene Verkehrsverbände einigen sich mit der Automobilindustrie auf ein Tempolimit.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Deutliche Unterschiede bei den Gehältern zwischen ost- und westdeutschen Bundesländern.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Ein Raucher hat einen Brand in einem mehrstöckigen Wohnhaus verursacht.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "36",
      "title": "Test 36 – Nach Ansicht mancher",
      "isVariant": false,
      "note": "PDF Seite 44 (S. 510). Richtig (+): 42, 44.",
      "questions": [
        {
          "num": 41,
          "text": "Die Waldbrände in Südkalifornien sind noch nicht unter Kontrolle.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Nach Ansicht mancher Politiker führt eine Reduzierung der Arbeitszeit unweigerlich zu einem Verlust an Wohlstand.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Deutschland und Frankreich wollen ihre wirtschaftliche Zusammenarbeit verbessern.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "In verschiedenen Berufszweigen sind noch Lehrstellen frei.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Die DDR-Sportlerin Katja Kaiser erhielt vom Nationalen Olympischen Komitee Schmerzensgeld.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "37",
      "title": "Test 37 – Der Bau",
      "isVariant": false,
      "note": "Hören B2 neu 2026 S. 2 & S. 47 („Der Bau: 135“). Richtig (+): 41, 43, 45 (Code 135). (Für die ältere Deckblatt-Variante mit Code 134 siehe Test 37a).",
      "questions": [
        {
          "num": 41,
          "text": "Der Bau des höchsten Gebäudes der Welt in Dubai hat eine Milliarde Dollar gekostet.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Nach der Aussage der Bundesbank wirkt sich die abkühlende US-Konjunktur auffallend auf die deutsche Industrie aus.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Die niedersächsischen Grünen haben vor, viel Geld in die Bereiche Klimaschutz und Bildung zu stecken.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Der Freiburger FC hat das Finale verloren.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Am Nachmittag herrscht Windstille und die Temperaturen steigen im Norden und Nordosten auf 2 bis 7 Grad, im Westen und Südwesten auf 6 bis 11 Grad.",
          "answer": "+"
        }
      ],
      "code": "135"
    },
    {
      "id": "37a",
      "title": "Test 37a – Der Bau (Variante)",
      "isVariant": true,
      "note": "Variante laut altem Deckblatt (Korrigiert Mai 2025: „Der Bau 134“). Richtig (+): 41, 43, 44 (Code 134). (In Hören B2 neu 2026 S. 47 ist der Code 135 → siehe Test 37).",
      "questions": [
        {
          "num": 41,
          "text": "Der Bau des höchsten Gebäudes der Welt in Dubai hat eine Milliarde Dollar gekostet.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Nach der Aussage der Bundesbank wirkt sich die abkühlende US-Konjunktur auffallend auf die deutsche Industrie aus.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Die niedersächsischen Grünen haben vor, viel Geld in die Bereiche Klimaschutz und Bildung zu stecken.",
          "answer": "+"
        },
        {
          "num": 44,
          "text": "Der Freiburger FC hat das Finale verloren.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Am Nachmittag herrscht Windstille und die Temperaturen steigen im Norden und Nordosten auf 2 bis 7 Grad, im Westen und Südwesten auf 6 bis 11 Grad.",
          "answer": "-"
        }
      ],
      "code": "134"
    },
    {
      "id": "38",
      "title": "Test 38 – Bio-Siegels",
      "isVariant": false,
      "note": "PDF Seite 46 (S. 512). Richtig (+): 41, 45.",
      "questions": [
        {
          "num": 41,
          "text": "Die Verwendung des Bio-Siegels ist streng geregelt.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Die EU-Agrarminister vertreten unterschiedliche Positionen.",
          "answer": "-"
        },
        {
          "num": 43,
          "text": "Der S-Bahn-Betrieb in Berlin verlief störungsfrei.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Neue Regelungen zur Gasförderung wurden beschlossen.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Die EU-Kommission kritisiert die Stickstoffdioxid-Werte in deutschen Städten.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "39",
      "title": "Test 39 – Vier Tage pro Woche",
      "isVariant": false,
      "note": "PDF Seite 47 (S. 513). Richtig (+): 41, 42.",
      "questions": [
        {
          "num": 41,
          "text": "Viele Angestellte würden gern nur vier Tage pro Woche arbeiten.",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "In handwerklichen Berufen gibt es zurzeit viele freie Stellen.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Der Online-Kauf von Fahrzeugen gewinnt an Beliebtheit.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Das Tourismus-Geschäft in Deutschland kämpft dieses Jahr mit Verlusten.",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "In Düsseldorf wurden neue Bürogebäude errichtet.",
          "answer": "-"
        }
      ],
      "code": "12"
    },
    {
      "id": "F1",
      "title": "Test F1 – Das Bundesfamilienministerium (Variante)",
      "isVariant": true,
      "note": "Deckblatt-Vermerk auf PDF Seite 1 (S. 467): „-Sheinenwege (24)“ -> Aussagen 2 und 4 (42, 44) sind Richtig (+). Vollständig enthalten als Test 33 (PDF Seite 41).",
      "questions": [
        {
          "num": 41,
          "text": "In Zukunft wird es schwieriger sein, Bauvorhaben des Bundes – wie Autobahnen oder Schienenwege – zu verhindern.",
          "answer": "-"
        },
        {
          "num": 42,
          "text": "Eine weitere Verlängerung der Lebensarbeitszeit würde keine ernsthaften sozialen Probleme verursachen.",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Der auf der Nordsee in Seenot geratene Fischkutter ist inzwischen gefunden worden.",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Das Bundesfamilienministerium betrachtet den Ausbau der Familienpolitik als abgeschlossen.",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Für Kinder, die sich im Kindergarten beim Spielen verletzen, haftet nicht automatisch die Einrichtung.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "F2",
      "title": "Fehlende Fragen 2 (Deckblatt) – Manche Deutsche (125)",
      "isVariant": true,
      "note": "Deckblatt-Vermerk auf PDF Seite 1 (S. 467): „-Mansche deutsch (125)“ -> Aussagen 1, 2 und 5 (41, 42, 45) sind Richtig (+), Aussagen 3 und 4 (43, 44) sind Falsch (-). Fragetexte im PDF nicht abgedruckt.",
      "questions": [
        {
          "num": 41,
          "text": "Manche Deutsche (Aussage 41 laut Deckblatt-Lösungsschlüssel 125: Richtig).",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Aussage 42 zum Test „Manche Deutsche“ (laut Deckblatt-Lösungsschlüssel 125: Richtig).",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Aussage 43 zum Test „Manche Deutsche“ (laut Deckblatt-Lösungsschlüssel 125: Falsch).",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Aussage 44 zum Test „Manche Deutsche“ (laut Deckblatt-Lösungsschlüssel 125: Falsch).",
          "answer": "-"
        },
        {
          "num": 45,
          "text": "Aussage 45 zum Test „Manche Deutsche“ (laut Deckblatt-Lösungsschlüssel 125: Richtig).",
          "answer": "+"
        }
      ],
      "code": "125"
    },
    {
      "id": "F3",
      "title": "Fehlende Fragen 3 (Deckblatt) – Erdbeeren (1245)",
      "isVariant": true,
      "note": "Deckblatt-Vermerk auf PDF Seite 1 (S. 467): „-Erdbeeren (1245)“ -> Aussagen 1, 2, 4 und 5 (41, 42, 44, 45) sind Richtig (+), Aussage 3 (43) ist Falsch (-). Fragetexte im PDF nicht abgedruckt.",
      "questions": [
        {
          "num": 41,
          "text": "Erdbeeren (Aussage 41 laut Deckblatt-Lösungsschlüssel 1245: Richtig).",
          "answer": "+"
        },
        {
          "num": 42,
          "text": "Aussage 42 zum Test „Erdbeeren“ (laut Deckblatt-Lösungsschlüssel 1245: Richtig).",
          "answer": "+"
        },
        {
          "num": 43,
          "text": "Aussage 43 zum Test „Erdbeeren“ (laut Deckblatt-Lösungsschlüssel 1245: Falsch).",
          "answer": "-"
        },
        {
          "num": 44,
          "text": "Aussage 44 zum Test „Erdbeeren“ (laut Deckblatt-Lösungsschlüssel 1245: Richtig).",
          "answer": "+"
        },
        {
          "num": 45,
          "text": "Aussage 45 zum Test „Erdbeeren“ (laut Deckblatt-Lösungsschlüssel 1245: Richtig).",
          "answer": "+"
        }
      ],
      "code": "1245"
    }
  ],
  "2": [
    {
      "id": "1",
      "title": "Test 1 – Mallorca",
      "isVariant": false,
      "note": "Deckblatt-Hinweis (S. 1): „Fehlende Fragen: -Die Zahl deutschen (347)“ → Richtig (+) bei der 3., 4. und 7. Aufgabe (48, 49, 52).",
      "questions": [
        {
          "num": 46,
          "text": "Die Zahl der deutschen Mallorca-Urlauber hat nur leicht abgenommen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Nach Professor Kirsch achten die Deutschen bei der Wahl ihrer Urlaubsreisen nicht besonders auf die Kosten.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Einige Einheimische auf Mallorca haben begonnen, sich gegen das Vordringen der deutschen Sprache zu wehren.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Auf Mallorca wird der Staat wegen der Umweltbelastungen zur Kasse bitten.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Viele Deutsche haben jetzt Rumänien und Ungarn als Reiseziel entdeckt.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Professor Kirsch weist auf günstige Angebote für Golfspieler am Plattensee hin.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Bulgarien hat sich als Urlaubsland sehr positiv entwickelt.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Viele Westdeutsche meiden Bulgarien, weil die Einreisemodalitäten abschreckend sind.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Seit Ende der neunziger Jahre geben die Deutschen mehr Geld für den Urlaub aus.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Durch die Vielzahl aktiver Senioren entsteht eine höhere Nachfrage nach Abenteuerreisen in ferne Länder.",
          "answer": "-"
        }
      ],
      "code": "347"
    },
    {
      "id": "1a",
      "title": "Test 1a – Mallorca (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 1 (abweichende Formulierung bei Aufgabe 49).",
      "questions": [
        {
          "num": 46,
          "text": "Die Zahl der deutschen Mallorca-Urlauber hat nur leicht abgenommen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Nach Professor Kirsch achten die Deutschen bei der Wahl ihrer Urlaubsreisen nicht besonders auf die Kosten.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Einige Einheimische auf Mallorca haben begonnen, sich gegen das Vordringen der deutschen Sprache zu wehren.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Für den Einbruch des Tourismus auf Mallorca sind verschiedene Faktoren verantwortlich.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Viele Deutsche haben jetzt Rumänien und Ungarn als Reiseziel entdeckt.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Professor Kirsch weist auf günstige Angebote für Golfspieler am Plattensee hin.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Bulgarien hat sich als Urlaubsland sehr positiv entwickelt.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Viele Westdeutsche meiden Bulgarien, weil die Einreisemodalitäten abschreckend sind.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Seit Ende der neunziger Jahre geben die Deutschen mehr Geld für den Urlaub aus.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Durch die Vielzahl aktiver Senioren entsteht eine höhere Nachfrage nach Abenteuerreisen in ferne Länder.",
          "answer": "-"
        }
      ],
      "code": "347"
    },
    {
      "id": "2",
      "title": "Test 2 – In dem Restaurant",
      "isVariant": false,
      "note": "Auf der Seite grün markiert: 46, 48, 49, 53, 54 (+). Deckblatt-Hinweis (S. 1): „Fehlende Fragen: - Im restaurant (134789)“ entspricht den Aufgaben 46, 48, 49, 52, 53, 54.",
      "questions": [
        {
          "num": 46,
          "text": "In dem Restaurant gab es einen Wasserschaden.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Anton Laurito ist bei seinen Großeltern aufgewachsen.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Im Haus der Großeltern lebten auch andere Kinder.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Der Stress störte den Studiogast während der Ausbildung nicht.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Bei neuen Mitarbeitern legt Anton Laurito am meisten Wert auf viel Erfahrung.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Aussehen und Geschmack der Speisen haben für den Koch den gleichen Stellenwert.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "In der Essschule können Kinder kochen lernen.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Anton Laurito lehnt Fastfood nicht grundsätzlich ab.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Der Koch hat eine gesunde Einstellung zum Thema Wettbewerb.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Zuhause probiert er gerne komplizierte Gerichte aus.",
          "answer": "-"
        }
      ],
      "code": "13489"
    },
    {
      "id": "2a",
      "title": "Test 2a – In dem Restaurant (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 49 (#4) & S. 52 Hinweis: Wenn dieser Hörtext zusammen mit dem Lesetext „in den Alpen“ vorkommt, lautet der Code 134789 → Richtig (+): 46, 48, 49, 52, 53, 54.",
      "questions": [
        {
          "num": 46,
          "text": "In dem Restaurant gab es einen Wasserschaden.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Anton Laurito ist bei seinen Großeltern aufgewachsen.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Im Haus der Großeltern lebten auch andere Kinder.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Der Stress störte den Studiogast während der Ausbildung nicht.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Bei neuen Mitarbeitern legt Anton Laurito am meisten Wert auf viel Erfahrung.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Aussehen und Geschmack der Speisen haben für den Koch den gleichen Stellenwert.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "In der Essschule können Kinder kochen lernen.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Anton Laurito lehnt Fastfood nicht grundsätzlich ab.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Der Koch hat eine gesunde Einstellung zum Thema Wettbewerb.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Zuhause probiert er gerne komplizierte Gerichte aus.",
          "answer": "-"
        }
      ],
      "code": "134789"
    },
    {
      "id": "3",
      "title": "Test 3 – Suza Hotop",
      "isVariant": false,
      "note": "Aufgabe 52 („plant im Vorfeld genau“) ist hier Falsch (-); in Variante 3a („plant nie ganz genau“) Richtig (+).",
      "questions": [
        {
          "num": 46,
          "text": "Für die Autorin Suza Hotop ist Schreiben Freude und Anstrengung zugleich.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Suza begann im Alter von zwölf Jahren mit ihrem Buch „Jenseits von Zaram“.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Am Anfang dachte Suza nicht daran, ihre Geschichte zu veröffentlichen.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Zuerst stellte Suza Auszüge ihrer Geschichte ins Internet.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Begeisterte Nutzer stellten den Kontakt zu einem Verlag her.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Suza beschreibt bewusst Personen aus ihrem eigenen Umfeld.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Die Autorin plant im Vorfeld genau, was in der Geschichte passieren wird.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Suza folgt beim Schreiben keinen besonderen Vorbildern.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Die junge Frau gab während des Radiointerviews eine Leseprobe.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Suza braucht immer Ruhe, um schreiben zu können.",
          "answer": "-"
        }
      ],
      "code": "1348"
    },
    {
      "id": "3a",
      "title": "Test 3a – Suza Hotop (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 3: Bei Aufgabe 52 steht „plant nie ganz genau“, daher ist 52 hier Richtig (+).",
      "questions": [
        {
          "num": 46,
          "text": "Für die Autorin Suza Hotop ist Schreiben Freude und Anstrengung zugleich.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Suza begann im Alter von zwölf Jahren mit ihrem Buch „Jenseits von Zaram“.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Am Anfang dachte Suza nicht daran, ihre Geschichte zu veröffentlichen.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Zuerst stellte Suza Auszüge ihrer Geschichte ins Internet.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Begeisterte Nutzer stellten den Kontakt zu einem Verlag her.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Suza beschreibt bewusst Personen aus ihrem eigenen Umfeld.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Die Autorin plant nie ganz genau, was in der Geschichte passieren wird.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Suza folgt beim Schreiben keinen besonderen Vorbildern.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Die junge Frau gab während des Radiointerviews eine Leseprobe.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Suza braucht immer Ruhe, um schreiben zu können.",
          "answer": "-"
        }
      ],
      "code": "13478"
    },
    {
      "id": "4",
      "title": "Test 4 – Julia",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Julia hatte an einem Schüleraustausch kein Interesse.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Die Lehrer in Julias Schule weigerten sich, mit dem Austauschschüler Englisch zu sprechen.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Frankreich ist als Aufenthaltsland bei Au-pairs nicht sehr gefragt.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Julia hatte auch darüber nachgedacht, in die Schweiz zu fahren.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Julia empfiehlt, mit der Gastfamilie einen Vertrag zu schließen.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Zu Beginn der Au-pair-Bewegung schickten Familien ihre Kinder zum Sprachunterricht in die Schweiz.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Julia ist der Meinung, dass die Vermittlungskosten zu hoch sind.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Julia verbrachte mit den Kindern auch Zeit in Paris.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Es gab am Anfang Momente, in denen sich Julia der Gastfamilie nicht zugehörig fühlte.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Julia lernt im Sprachkurs mehr Französisch als durch den Kontakt mit der Gastfamilie.",
          "answer": "-"
        }
      ],
      "code": "13458"
    },
    {
      "id": "5",
      "title": "Test 5 – Carina",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Der Berufseinstieg ist in anderen Ländern nicht leicht.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Carina ist ihr Beruf wichtiger als ihr Privatleben.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Carina hat sich der Agentur mit einem Film präsentiert.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Carina musste für einen Film ihr Gewicht stark verändern.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Carina macht lieber gefühlvolle Filme als Action-Filme.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Wegen der vielen Fehlstunden hatte Carina Probleme mit dem Direktor der Schule.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Carinas Eltern haben ihre Tochter von Anfang an unterstützt.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Carina findet den Wechsel zwischen Schule und Drehterminen nicht leicht.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Bei Dialogen darf man auch selbst etwas erfinden.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Carina empfiehlt, sich andere Schauspieler im Theater und in Filmen anzusehen.",
          "answer": "+"
        }
      ],
      "code": "134890"
    },
    {
      "id": "5a",
      "title": "Test 5a – Carina (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 5 (abweichende Formulierung bei Aufgabe 48 und 49).",
      "questions": [
        {
          "num": 46,
          "text": "Der Berufseinstieg ist in anderen Ländern nicht leicht.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Carina ist ihr Beruf wichtiger als ihr Privatleben.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Carina hat bei der Agentur mit einem Videofilm Interesse geweckt.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Carina hat für einen Film eine Diät gemacht.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Carina macht lieber gefühlvolle Filme als Action-Filme.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Wegen der vielen Fehlstunden hatte Carina Probleme mit dem Direktor der Schule.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Carinas Eltern haben ihre Tochter von Anfang an unterstützt.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Carina findet den Wechsel zwischen Schule und Drehterminen nicht leicht.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Bei Dialogen darf man auch selbst etwas erfinden.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Carina empfiehlt, sich andere Schauspieler im Theater und in Filmen anzusehen.",
          "answer": "+"
        }
      ],
      "code": "134890"
    },
    {
      "id": "6",
      "title": "Test 6 – Frau Schenk",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Frau Schenk hat kurze blondierte Haare.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Angie ist der Künstlername von Frau Schenk.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Frau Schenk lebt seit etwas mehr als zwei Jahren in Bayern.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Der Interviewer hat keine guten Erinnerungen an seine Aufenthalte in Jugendherbergen.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Auch in der modernen Jugendherberge von Frau Schenk gibt es Schlafräume mit mehr als zehn Betten.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Nur bei Schulklassen achtet man auf Geschlechtertrennung in den Schlafräumen.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Das Angebot an Speisen wird auf die Wünsche der Gäste zugeschnitten.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Schüler aus ländlichen Regionen sind meist unproblematische Gäste.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Das Reiten zählt zu dem Sportprogramm der Jugendherberge.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Frau Schenk muss für ihre Dienstwohnung 800 € bezahlen.",
          "answer": "-"
        }
      ],
      "code": "14678"
    },
    {
      "id": "6a",
      "title": "Test 6a – Frau Schenk (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 6 (abweichende Formulierung bei den Aufgaben 51–54).",
      "questions": [
        {
          "num": 46,
          "text": "Frau Schenk hat kurze blondierte Haare.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Angie ist der Künstlername von Frau Schenk.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Frau Schenk lebt seit etwas mehr als zwei Jahren in Bayern.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Der Interviewer hat keine guten Erinnerungen an seine Aufenthalte in Jugendherbergen.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Auch in der modernen Jugendherberge von Frau Schenk gibt es Schlafräume mit mehr als zehn Betten.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Mädchen und Jungen müssen in verschiedenen Schlafräumen schlafen.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "In der Jugendherberge wird das Essen den Wünschen der Gästegruppen angepasst.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Schüler aus ländlichen Regionen verhalten sich in der Regel anständig.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Reiten ist Teil des Sportangebots der Jugendherberge.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Frau Schenk muss für ihre Dienstwohnung 800 € bezahlen.",
          "answer": "-"
        }
      ],
      "code": "14678"
    },
    {
      "id": "7",
      "title": "Test 7 – Herr Karimov",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Herr Karimov hat vor sechs Jahren die Internetplattform ZEITPLAN gegründet.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Die Mitglieder bekommen für ihre Hilfe ein Stundenguthaben.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Herr Karimov hatte ein eigenes Handwerksunternehmen.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Nach dem Umzug aufs Land war er auf die Hilfe der Nachbarn angewiesen.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Manchmal erwarten Mitglieder keine Gegenleistung für ihre Arbeit.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Meistens brauchen alleinstehende Frauen Herrn Karimovs Hilfe.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Viele Menschen sehen in ZEITPLAN eine Konkurrenz zu Handwerksbetrieben.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Herr Karimov erledigt nicht so gerne Büroarbeit.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Wer sich bei der Nachbarschaftshilfe einbringen möchte, muss sich persönlich vorstellen.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Herr Karimov brauchte vorübergehend einen Chauffeur.",
          "answer": "+"
        }
      ],
      "code": "25890"
    },
    {
      "id": "8",
      "title": "Test 8 – Nadine Wagner",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Nadine Wagner ist gerade erst von ihrer Weltreise zurückgekehrt.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Sie hatte vor der Weltreise einige Zweifel und Bedenken.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Die Journalistin ist während ihrer Reise auch geflogen.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Sie hat für dieses Abenteuer ihre Stelle gekündigt.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Ihre Freunde waren unterschiedlicher Meinung über ihr Vorhaben.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "In Tadschikistan hat sie eine Zeit lang andere Motorradfahrer begleitet.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Sie hat auf der Reise ihr ganzes Erspartes aufgebracht.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Nadine Wagner hat auf der Reise gelegentlich gearbeitet.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Sie hat am meisten ihre eigene Wohnung vermisst.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Nach ihrer Rückkehr musste sie nicht lange nach einer neuen Arbeit suchen.",
          "answer": "+"
        }
      ],
      "code": "235680"
    },
    {
      "id": "9",
      "title": "Test 9 – Markus",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Markus ist schon während des Studiums an eine amerikanische Universität gegangen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Markus wollte in einem besonders erfolgreichen Team mitarbeiten.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Um eine Stelle in einer amerikanischen Forschergruppe zu bekommen, muss man viel Glück haben.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Markus befindet sich zwischen Ausbildung und Beruf.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Das Studium in Bonn hat Markus sehr gut auf den Auslandsaufenthalt vorbereitet.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Markus hatte nach der Ankunft in den USA sehr viele Schwierigkeiten.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Markus ist immer noch sehr nervös in der fremden Umgebung.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Markus ist mit den Arbeitsbedingungen zufrieden.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Markus befürwortet es nicht, dass sich Studenten in den USA früh auf ihren zukünftigen Beruf festlegen müssen.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Für Markus ist es ein Vorteil, dass man in Deutschland Referate und Vorträge halten muss.",
          "answer": "+"
        }
      ],
      "code": "24580"
    },
    {
      "id": "9a",
      "title": "Test 9a – Markus (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 63 (Markus المعدل, Code 24580). Richtig (+): 47, 49, 50, 53, 55.",
      "questions": [
        {
          "num": 46,
          "text": "Markus ist schon während des Studiums an eine amerikanische Universität gegangen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Markus wollte in einem besonders erfolgreichen Team mitarbeiten.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Um eine Stelle in einer amerikanischen Forschergruppe zu bekommen, muss man viel Glück haben.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Markus befindet sich zwischen Ausbildung und Beruf.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Markus profitiert in Amerika von Erfahrungen, die er während des Studiums gesammelt hat. (PDF: Markus profitiert im Amrika von erfahrung die während studiert sammelt.)",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Markus hatte nach der Ankunft in den USA sehr viele Schwierigkeiten. (PDF S. 63 Druckzeile 51: Markus profitiert im amrika von erfahrung die während studium sammelt.)",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Markus ist immer noch sehr nervös in der fremden Umgebung.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Markus ist mit den Arbeitsbedingungen zufrieden.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Markus befürwortet es nicht, dass sich Studenten in den USA früh auf ihren zukünftigen Beruf festlegen müssen.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Für Markus ist es ein Vorteil, dass man in Deutschland Referate und Vorträge halten muss.",
          "answer": "+"
        }
      ],
      "code": "24580"
    },
    {
      "id": "10",
      "title": "Test 10 – Professor Steiner",
      "isVariant": false,
      "note": "In Test 10 sind die Aufgaben 47, 51, 53, 54, 55 grün markiert (+).",
      "questions": [
        {
          "num": 46,
          "text": "Professor Steiner ist heute gar nicht mehr nervös, wenn er moderieren muss.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Steiner vermittelt den Studierenden nicht nur theoretisches Wissen, sondern fordert auch, dass es praktisch angewendet wird.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Steiners Hobby ist es, experimentelle Filme zu machen.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Journalisten sollten heute auf einzelne Medien spezialisiert sein.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Sportjournalist zu werden, ist nach Steiners Ansicht heute fast ausgeschlossen.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Journalisten sollten Lust haben, etwas zu entdecken.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Steiner musste wegen einer Verletzung mit dem Fußballspielen aufhören.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Steiner hat während seines Journalistik-Studiums für das ZDF Fußballspiele moderiert.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Steiner ist es wichtig, als Moderator den Sportlern gegenüber neutral zu bleiben.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Steiner rät Abiturienten dazu, verschiedene berufliche Möglichkeiten auszuprobieren.",
          "answer": "+"
        }
      ],
      "code": "26890"
    },
    {
      "id": "10a",
      "title": "Test 10a – Professor Steiner (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 10 (abweichende Formulierung bei den Aufgaben 47, 50, 53, 55; auf dieser Seite sind 47, 54, 55 grün markiert).",
      "questions": [
        {
          "num": 46,
          "text": "Professor Steiner ist heute gar nicht mehr nervös, wenn er moderieren muss.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Steiner möchte, dass die Studierenden das Gelernte auch in der Praxis anwenden können.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Steiners Hobby ist es, experimentelle Filme zu machen.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Journalisten sollten heute auf einzelne Medien spezialisiert sein.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Nach Steiners Ansicht ist der Berufswunsch Sportjournalist heutzutage unrealistisch.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Journalisten sollten Lust haben, etwas zu entdecken.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Steiner musste wegen einer Verletzung mit dem Fußballspielen aufhören.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Steiner hat während seines Journalistik-Studiums für das ZDF Fußballspiele kommentiert.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Steiner ist es wichtig, als Moderator den Sportlern gegenüber neutral zu bleiben.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Steiner rät Abiturienten dazu, verschiedene berufliche Möglichkeiten zu testen.",
          "answer": "+"
        }
      ],
      "code": "290"
    },
    {
      "id": "11",
      "title": "Test 11 – Herr Gasser",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Herr Gasser und Frau Janke haben zusammen Urlaub im Gebirge gemacht.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Josef Gasser ist ein gebürtiger Tiroler.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Die Bergbauern können kaum vom Verkauf ihrer Produkte leben.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Auch heute werden die steilen Hänge noch manuell bearbeitet.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Josef Gasser findet, dass man die Berglandschaft sich selbst überlassen sollte.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Eva Janke begeistert sich immer noch für Flugreisen.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Ihren ersten Einsatz auf der Alm hat Frau Janke abgebrochen.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Für Frau Janke ist der Erholungswert trotz der Anstrengung sehr hoch.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Almhelferinnen und -helfer können vielfältige Aufgaben übernehmen.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Über die Dauer des Aufenthalts kann man frei entscheiden.",
          "answer": "+"
        }
      ],
      "code": "34890"
    },
    {
      "id": "12",
      "title": "Test 12 – Vanessa",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Vanessa versucht, so viele Orte wie möglich zu besuchen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Mit den Arbeitsbedingungen in der Werbeagentur war Vanessa unzufrieden.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Wenn Vanessa unter Menschen ist, schadet das manchmal ihrer Konzentration.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Die Sicherheit, die eine feste Stelle bietet, bedeutet Vanessa nicht viel.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Vanessa ist sich sicher, dass sie nie mehr als Angestellte arbeiten möchte.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Dass sie immer wieder neue Auftraggeber suchen muss, hat für Vanessa auch Vorteile.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Vanessas Eltern würden auch gerne öfter verreisen.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Es fiel Vanessa leicht, sich von persönlichen Gegenständen zu trennen.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Vanessa glaubt, dass man in Zukunft in mehr Berufen ortsunabhängig arbeiten kann.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Auch wer ortsunabhängig arbeitet, sollte nicht zu oft den Ort wechseln.",
          "answer": "+"
        }
      ],
      "code": "234680"
    },
    {
      "id": "13",
      "title": "Test 13 – Roland",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Roland Wünschmann arbeitet Vollzeit als Fußballtrainer bei Viktoria Köln.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Viktoria Köln möchte nicht nur gegen Mannschaften aus der Verbandsliga spielen.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Zu Beginn dieser Saison hat ein Spieler Viktoria Köln verlassen.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Neue Spieler kommen bei Viktoria Köln immer aus der eigenen Jugendmannschaft.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Die Mannschaft von Viktoria Köln hat Schwächen in der Abwehr.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Roland Wünschmann wagt die Prognose, dass in dieser Saison der 1. FC Mönchengladbach Meister wird.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Roland Wünschmann kann seinen Beruf und sein Ehrenamt als Fußballtrainer problemlos miteinander vereinbaren.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Auch die Frau von Roland Wünschmann engagiert sich im Fußball.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Der Vereinsvorstand schätzt Herrn Wünschmanns Arbeit.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Roland Wünschmann ist mit der bisherigen Nachwuchsförderung des Vereins zufrieden.",
          "answer": "+"
        }
      ],
      "code": "234790"
    },
    {
      "id": "13a",
      "title": "Test 13a – Roland (Variante)",
      "isVariant": true,
      "note": "Variante a zu Test 13 (abweichende Formulierung bei den Aufgaben 46, 47 und 55; grün markiert sind 48, 49, 52, 54).",
      "questions": [
        {
          "num": 46,
          "text": "Roland Wünschmann spielt selbst bei Viktoria Köln Fußball.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Viktoria Köln möchte am Ende der Spielsaison aufsteigen.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Zu Beginn dieser Saison hat ein Spieler Viktoria Köln verlassen.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Neue Spieler kommen bei Viktoria Köln immer aus der eigenen Jugendmannschaft.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Die Mannschaft von Viktoria Köln hat Schwächen in der Abwehr.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Roland Wünschmann wagt die Prognose, dass in dieser Saison der 1. FC Mönchengladbach Meister wird.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Roland Wünschmann kann seinen Beruf und sein Ehrenamt als Fußballtrainer miteinander vereinbaren.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Auch die Frau von Roland Wünschmann engagiert sich im Fußball.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Der Vereinsvorstand schätzt Herrn Wünschmanns Arbeit.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Roland Wünschmann ist mit der bisherigen Nachwuchsförderung des Vereins noch nicht voll zufrieden.",
          "answer": "-"
        }
      ],
      "code": "3479"
    },
    {
      "id": "13b",
      "title": "Test 13b – Roland (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 49 (#22) & S. 70 (Roland – in einer höheren Liga, Code 235890). Richtig (+): 47, 48, 50, 53, 54, 55.",
      "questions": [
        {
          "num": 46,
          "text": "Roland Wünschmann spielt selbst bei Viktoria Köln Fußball.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Viktoria Köln spielt seit Beginn der Saison in einer höheren Liga.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Die meisten Spieler der Mannschaft haben schon in der letzten Saison bei Viktoria Köln gespielt.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Neuzugänge kommen bei Viktoria Köln meist aus ganz unterschiedlichen Mannschaften.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Die Mannschaft von Viktoria Köln möchte in dieser Saison neue Spieltaktiken ausprobieren.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Roland Wünschmann wagt die Prognose, dass in dieser Saison der 1. FC Mönchengladbach Meister wird.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Roland Wünschmann empfindet sein Ehrenamt oft als Belastung.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Roland Wünschmanns Frau engagiert sich für denselben Verein.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Herr Wünschmann und der Vereinsvorstand sind meistens einer Meinung.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Roland Wünschmann hofft auf Verbesserungen in der Nachwuchsförderung.",
          "answer": "+"
        }
      ],
      "code": "235890"
    },
    {
      "id": "14",
      "title": "Test 14 – Mirjam Pressler",
      "isVariant": false,
      "note": "Aufgabe 48 („als Erste Anne Frank ins Deutsche übersetzt“) ist hier Falsch (-); in Variante 14a („über Anne Frank gearbeitet“) Richtig (+).",
      "questions": [
        {
          "num": 46,
          "text": "Mirjam Pressler freut sich, in Kürze die Doktorwürde der Universität Groningen zu erhalten.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Sie arbeitet auch als Übersetzerin.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Sie hat als Erste Anne Frank ins Deutsche übersetzt.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Sie macht jedes Jahr Urlaub in einem Ferienhaus bei Venedig.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Wenn sie an ihre Kindheit denkt, denkt sie an den Krieg.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Der Kontakt zu ihren Pflegeeltern war sehr gut.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Ihre Werke haben oft biografische Züge.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Ihre erste Lektüre war ein Roman, der in Petersburg spielt.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Als Kind las sie immer im Keller des Hauses.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Ihre Pflegemutter wollte nicht, dass sie Tagebuch schreibt.",
          "answer": "+"
        }
      ],
      "code": "12570"
    },
    {
      "id": "14a",
      "title": "Test 14a – Mirjam Pressler (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 14: Bei Aufgabe 48 steht „Sie hat über Anne Frank gearbeitet.“, daher ist 48 hier Richtig (+).",
      "questions": [
        {
          "num": 46,
          "text": "Mirjam Pressler freut sich, in Kürze die Doktorwürde der Universität Groningen zu erhalten.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Sie arbeitet auch als Übersetzerin.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Sie hat über Anne Frank gearbeitet.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Sie macht jedes Jahr Urlaub in einem Ferienhaus bei Venedig.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Wenn sie an ihre Kindheit denkt, denkt sie an den Krieg.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Der Kontakt zu ihren Pflegeeltern war sehr gut.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Ihre Werke haben oft biografische Züge.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Ihre erste Lektüre war ein Roman, der in Petersburg spielt.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Als Kind las sie immer im Keller des Hauses.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Ihre Pflegemutter wollte nicht, dass sie Tagebuch schreibt.",
          "answer": "+"
        }
      ],
      "code": "123570"
    },
    {
      "id": "15",
      "title": "Test 15 – Die TU Dresden",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Die TU Dresden ist eine kleine Universität.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "An der TU Dresden kann man nur technische Fächer studieren.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Ältere Studierende kümmern sich um neue Studierende.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Man erreicht die Neustadt nicht mit öffentlichen Verkehrsmitteln.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Jens ist nicht sicher, ob er nach dem Studium einen interessanten Job bekommt.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Studienanfänger können noch zwischen Bachelor und Diplom wählen.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Mit dem Semesterticket dürfen Studierende öffentliche Verkehrsmittel in Dresden nutzen.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Für Studienanfänger gibt es die Möglichkeit, bestimmte Grundkenntnisse aufzufrischen.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Im Studium gibt es keine Gruppenarbeit.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "An der TU Dresden kann man auch außergewöhnliche Sportarten treiben.",
          "answer": "+"
        }
      ],
      "code": "35780"
    },
    {
      "id": "16",
      "title": "Test 16 – Tournee-Koch für Musiker (Ole) [Code 1234689]",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Zu Beginn der Sendung hatte der Reporter ein exklusives Frühstücksrezept erwartet.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Ole hat sich vor 17 Jahren selbstständig gemacht.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Davor hatte er eine Lehre als Koch absolviert.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Er bevorzugt Gerichte ohne Fleisch.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Ole sieht wie ein Punker aus.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Er kocht für Musiker, die auf Tournee sind.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Zuletzt hat er für die Band „Die Prinzen“ gekocht.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Ole nimmt eine komplette Kücheneinrichtung mit auf Tournee.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Er macht sich über den Sender lustig, weil der Reporter bei englischen Wörtern nachfragt.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Die Musiker müssen immer essen, was auf den Tisch kommt.",
          "answer": "-"
        }
      ],
      "code": "1234689"
    },
    {
      "id": "17",
      "title": "Test 17 – Herr Scherer",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Herr Scherer wird an seinem Arbeitsplatz interviewt.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Herr Scherer probt jede Woche zweimal mit dem Kirchenchor.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Herr Scherer hat wechselnde Arbeitszeiten.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Verspätungen gehen häufig auf das Konto undisziplinierter Fahrgäste.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Herr Scherer und seine Kollegen verkaufen keine Fahrscheine mehr.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Alkoholisierte Fahrgäste verursachen zunehmend Probleme.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Die Verkehrsbetriebe haben ein eigenes Schwimmbad.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Die Klimatisierung der Busse ist bei hohen Temperaturen nicht ausreichend.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Herr Scherer hat bei der Bundeswehr eine Ausbildung zum Automechaniker gemacht.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Herr Scherer hat bei der Post 15 Jahre in Nachtschicht gearbeitet.",
          "answer": "+"
        }
      ],
      "code": "340"
    },
    {
      "id": "18",
      "title": "Test 18 – Die Deutschen machen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Die Deutschen machen zurzeit gerne bis zu drei Wochen oder mehr Urlaub.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Viele Wellness-Hotels befinden sich in Großstädten.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Wellness-Angebote gibt es vor allem in Hotels der gehobenen Kategorie.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Die von den Hotels angebotenen „Pakete“ enthalten in der Regel Vollpension.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "In den Hotels kann man auch schwimmen und in die Sauna gehen.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Die Gäste nehmen die Sportangebote kaum wahr.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Oft bieten die Hotels auch kulturelle Rahmenprogramme wie Stadtführungen und Opernbesuche an.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Frauen kommen fast immer in Begleitung ihrer Ehemänner.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Die Hotels haben besondere Angebote für Männer.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Mitglieder von Krankenkassen können die Hotels kostenlos besuchen.",
          "answer": "-"
        }
      ],
      "code": "359"
    },
    {
      "id": "19",
      "title": "Test 19 – Franz Schumacher",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Franz Schumacher handelt nicht nur mit Produkten aus eigenem Anbau.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Herr Schumacher lässt sich auch von anderen Bauern Produkte liefern.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Auf dem Markt sind schon viele Besucher unterwegs.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Die große Mehrheit der Kunden von Herrn Schumacher sind Stammkunden.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Herr Schumacher ist auf die Pfälzer Kartoffeln besonders stolz.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Franz Schumacher hat keine hohe Meinung vom „Fachhändlerverein vom Rathausplatz“.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Herr Schumacher kommt morgens sehr früh auf den Markt, um sich einen guten Platz für seinen Stand zu sichern.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Herr Schumacher hat seit über 20 Jahren einen Stand auf dem Landauer Markt.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Herr Schumacher trägt eine Mütze, um sich vor Kälte zu schützen.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Herr Schumacher möchte in Zukunft einen Verkaufsstand in einer Markthalle eröffnen.",
          "answer": "+"
        }
      ],
      "code": "124680"
    },
    {
      "id": "20",
      "title": "Test 20 – Frau Pesina",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Frau Pesina ist die Chefin des Kosmos Kinos.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Von Hanau nach Frankfurt braucht man weniger als eine halbe Stunde.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Die Gründung des Kinos vor 100 Jahren war eher ein Zufall.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Der Großonkel baute sofort einen separaten Kinosaal.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Nach ihrem Großonkel leitete gleich Frau Pesina das Kino.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Manchmal denkt sie, es wäre besser gewesen, die sichere Stelle bei der Bank zu behalten.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "In dem Kino gibt es heute außer der Schwägerin und den beiden Schwestern auch noch weitere Mitarbeiter.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Der Arbeitsalltag im Kino läuft immer völlig reibungslos ab.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Frau Pesina entscheidet immer allein, was im Kosmos Kino läuft.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Manchmal gibt es in dem Kino ein spezielles Programm für Frauen.",
          "answer": "+"
        }
      ],
      "code": "12370"
    },
    {
      "id": "21",
      "title": "Test 21 – Herr Werner",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Auf dem Gipfel der Zugspitze liegt ungefähr ein Meter Schnee.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Man kann derzeit auf der Zugspitze Ski fahren.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Auch in Garmisch-Partenkirchen selbst hat es geschneit.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "In der kommenden Woche erwartet man für die Zugspitzregion freundliches Wetter.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Am Sonntag wird ein Gottesdienst auf einer Bergstation abgehalten.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Die Zugspitze kann man momentan wegen des Nebels nicht erkennen.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Die Urlauber in Garmisch-Partenkirchen haben bei jedem Wetter genügend Möglichkeiten zur Freizeitgestaltung.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Herr Werner erwartet keine Wetterbesserung.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Auch in früheren Jahren hat es im Juni und August geschneit.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Herr Werner ist mit seinem Arbeitsplatz zufrieden.",
          "answer": "+"
        }
      ],
      "code": "145790"
    },
    {
      "id": "22",
      "title": "Test 22 – Wohnmobil",
      "isVariant": false,
      "note": "Vgl. Test 31 (dort leicht geänderte Reihenfolge bei 46–49 und Verneinung bei 52).",
      "questions": [
        {
          "num": 46,
          "text": "Der Hauptpreis des Gewinnspiels ist ein rund vierwöchiger Urlaub in Spanien.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Sie können in der Sendung auch schöne Bildbände über verschiedene Länder gewinnen.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Thomas Schilp vertritt einen großen Wohnmobilhändler.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Für das Wohnmobil Camper 500F benötigt man einen Zusatzführerschein.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Wohnmobile für Reisen in Europa sollte man erst am Urlaubsort mieten.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Reisende mit Wohnmobilen schätzen ihre Unabhängigkeit.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Auf Luxus muss man im Wohnwagen auch heute nicht verzichten.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Wer den Urlaub mit dem Wohnmobil erst einmal ausprobieren will, sollte ein gebrauchtes Fahrzeug kaufen.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Deutsche zahlen für ein Wohnmobil durchschnittlich 200.000 Euro.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Der Mietpreis für ein Wohnmobil hängt von der Jahreszeit ab.",
          "answer": "-"
        }
      ],
      "code": "1678"
    },
    {
      "id": "23",
      "title": "Test 23 – Straßenkinder – Die Kinder (Kids)",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Frau Edler arbeitete früher für die Verkehrsbetriebe Leipzig.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Zum ersten Mal wurde sie in Frankfurt mit dem Problem der Straßenkinder konfrontiert.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Zu Anfang kümmerte sie sich um obdachlose Erwachsene.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Sie hat den Straßenkindern immer Geld gegeben.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Die Kinder (Kids) wollten nach Meinung von Frau Edler Zigaretten kaufen.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Sie hat mit den Kindern in leer stehenden Häusern übernachtet.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Die Kolleginnen hatten anfangs kein Verständnis für ihr Engagement.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Die Zahl der Kinder, die an den Weihnachtsfeiern teilnehmen, ist seit 1990 stark gesunken.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Sie sammelt noch heute bei den früheren Kollegen Geld für die Straßenkinder.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Mit einer Büchse herumzulaufen, ist ihr manchmal peinlich.",
          "answer": "-"
        }
      ],
      "code": "1235679"
    },
    {
      "id": "24",
      "title": "Test 24 – Familie – Eltern",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Fast 11.500 Kinder leben nicht bei ihren leiblichen Eltern.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Früher wurden Fälle von Gewalt in der Familie oft nicht bekannt.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Kinder werden nicht sofort von ihren Familien getrennt.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Materielle Unterstützung wie Elektrogeräte kann keine Hilfe sein.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Die Nachmittagsbetreuung für die ältesten Kinder ist kostenlos.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "In Skandinavien gibt es eine bessere Familienvorsorge.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Früher lernte man Erziehung an Modellsituationen in der Großfamilie.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Der Kontakt zwischen Kindern und leiblichen Eltern wird möglichst erhalten.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Es gibt spezielle WGs für Jugendliche, die nicht bei ihren Eltern leben.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Herr Blaschitz bittet die Hörer um Unterstützung.",
          "answer": "+"
        }
      ],
      "code": "12367890"
    },
    {
      "id": "25",
      "title": "Test 25 – Revolution Day",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Am 24. April ist der Fashion Revolution Day.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Der Anlass für den Fashion Revolution Day ist der Einsturz des Fabrikgebäudes in Bangladesch.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Nur wenige Menschen wurden beim Einsturz schwer verletzt.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "An diesem Tag wird nur schwarze Kleidung getragen.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Eine Näherin verdient dort ca. 20 Cent.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Die Clean Clothes Kampagne fordert bereits seit Jahren einen existenzsichernden Lohn.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Faire Mode ist im Geschäft teurer, weil größere Serien produziert werden.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Eine andere Attraktion ist das Filmscreening des Films „Traceable“.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Nach dem Film ist die Veranstaltung zu Ende.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Weitere Informationen können auf der Webseite traceable.org abgerufen werden.",
          "answer": "-"
        }
      ],
      "code": "12568"
    },
    {
      "id": "26",
      "title": "Test 26 – Bicycle",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Das ist ein Interview mit dem Restaurant „Bicycle“.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Gert Kronheimer ist der alleinige Gründer von „Bicycle“.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "„Bicycle“ bietet Arbeitsplätze für junge Leute, die schon länger arbeitslos sind.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "„Bicycle“ gibt es schon seit 1926.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Anlass für die Gründung von „Bicycle“ war die steigende Arbeitslosigkeit Anfang der 80er Jahre.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Gert Kronheimer findet, dass das Fahrrad für junge Leute interessant ist.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Das Fahrrad ist heute leider sehr unpopulär geworden.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Bei „Bicycle“ kann man nur Vollzeit arbeiten.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Bei „Bicycle“ werden im Jahr ungefähr 10.000 Fahrräder repariert.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Sibylle Hartung ist nur eine Assistentin und keine Expertin für technische Fragen.",
          "answer": "-"
        }
      ],
      "code": "369"
    },
    {
      "id": "27",
      "title": "Test 27 – Die Radiosendung",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Die Radiosendung stellt wöchentlich Leute aus ganz Deutschland vor.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Eva Küpper läuft im Training wenigstens einmal pro Woche auch über die Marathondistanz.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Ihren Job als Bankangestellte würde Eva Küpper gerne kündigen.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Nach der Ausbildung hat Eva Küpper ihren Lebensstil radikal verändert.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Eva Küpper kommt ursprünglich aus München.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Eva Küpper gefallen Dauerläufe in der Stadt genauso gut wie in den Bergen.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Während eines Ultramarathons wechselt Eva Küpper die Laufschuhe dreimal.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Die spezielle Uhr ist für Eva Küpper nicht nur im Training, sondern auch im Wettkampf wichtig.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Solange der Körper gesund ist, will Eva Küpper weiterhin Ultramarathons laufen.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Nach dem Berlin-Marathon kann Eva Küpper dem Lauf-Club offiziell beitreten.",
          "answer": "-"
        }
      ],
      "code": "24589"
    },
    {
      "id": "28",
      "title": "Test 28 – Psychische Erkrankungen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Weniger als zehn Prozent der Fehltage am Arbeitsplatz sind auf psychische Erkrankungen zurückzuführen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Betroffene Arbeitnehmer sprechen relativ offen über ihre psychischen Probleme.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Auch Arbeitslosigkeit ist ein Risikofaktor für psychische Probleme.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Schlechte Stimmung am Arbeitsplatz ist die Hauptursache für psychische Erkrankungen.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Menschen, die zu wenig zu tun haben, versuchen, das nicht zu zeigen.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Menschen, die am Arbeitsplatz wenig zu tun haben, sind besonders zufrieden.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Internet und Smartphone können einen Einfluss auf die Psyche haben.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Wem seine Arbeit Spaß macht, der kann eher mehr leisten.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Bei Managern ist das Risiko für psychische Erkrankungen unter allen Berufsgruppen am höchsten.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Für die psychische Gesundheit ist es besser, arbeitslos zu sein, als eine nur durchschnittlich interessante Arbeit zu finden.",
          "answer": "-"
        }
      ],
      "code": "34578"
    },
    {
      "id": "29",
      "title": "Test 29 – Herr Kemper",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Herr Kemper arbeitet aus Dankbarkeit für die Hilfe, die er früher bekommen hat, ehrenamtlich.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Der Tierschutz hat für Herrn Kemper oberste Priorität.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Herr Kemper hat zuerst handwerkliche Arbeiten im Tierheim gemacht.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Herr Kemper hat es abgelehnt, Reinigungsarbeiten zu übernehmen.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Alle Helferinnen und Helfer arbeiten mehrmals in der Woche im Tierheim.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Greta hat angefangen, ehrenamtlich zu arbeiten, weil sie zu Hause Langeweile hatte.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Herr Kemper hat einer jungen Frau geholfen, ihren beruflichen Weg zu finden.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Herr Kemper findet, dass sich jeder Mensch ehrenamtlich engagieren sollte.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Herr Kemper hat auch Verständnis für Menschen, die sich nicht ehrenamtlich engagieren.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Herr Kemper wohnt in einem Haus, in dem Tierhaltung verboten ist.",
          "answer": "+"
        }
      ],
      "code": "136790"
    },
    {
      "id": "30",
      "title": "Test 30 – Frau Hahn",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Der Journalist spricht mit einer Kundin im Kaufhaus.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Frau Hahn hat ihren Beruf im Kaufhaus Brück gelernt.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Frau Hahn wollte schon als Kind Verkäuferin im Kaufhaus Brück werden.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Frau Hahn fand es wichtig, nette Kollegen zu haben.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Frau Hahns Mann arbeitet jetzt in demselben Kaufhaus wie sie.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Der Mann von Frau Hahn hat als Schuhverkäufer gearbeitet.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Das Kaufhaus Brück wird nach der Schließung abgerissen.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Frau Hahn findet es wichtig, in einem schönen Haus zu arbeiten.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Die neuen Inhaber hätten das Kaufhaus gerne weitergeführt.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Frau Hahn will nicht in einem anderen Kaufhaus arbeiten.",
          "answer": "+"
        }
      ],
      "code": "24680"
    },
    {
      "id": "31",
      "title": "Test 31 – Wohnmobil",
      "isVariant": false,
      "note": "Vgl. Test 22: Hier steht bei Aufgabe 52 „Auf Luxus muss man im Wohnwagen auch heute noch verzichten.“ (daher Falsch, -).",
      "questions": [
        {
          "num": 46,
          "text": "In der Sendung von Bayern 3 können Sie u. a. ein Zelt gewinnen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Für das Wohnmobil Camper 500F benötigt man einen Zusatzführerschein.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Der Hauptpreis des Gewinnspiels ist ein vierwöchiger Urlaub in Spanien.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Sie können in der Sendung auch Bildbände über verschiedene Länder gewinnen.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Wohnmobile für Reisen in Europa sollte man erst am Urlaubsort mieten.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Reisende mit Wohnmobilen schätzen ihre Unabhängigkeit.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Auf Luxus muss man im Wohnwagen auch heute noch verzichten.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Wer den Urlaub mit dem Wohnmobil erst einmal ausprobieren will, sollte ein gebrauchtes Fahrzeug kaufen.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Deutsche zahlen für ein Wohnmobil durchschnittlich 200.000 Euro.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Der Mietpreis für ein Wohnmobil hängt von der Jahreszeit ab.",
          "answer": "-"
        }
      ],
      "code": "368"
    },
    {
      "id": "32",
      "title": "Test 32 – Lisa Eisenberg",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Lisa Eisenberg war aus beruflichen Gründen in den USA.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Während einer Reise entschied sich Lisa Eisenberg für einen beruflichen Neuanfang.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Lisa Eisenbergs Geschäftsidee stieß in ihrem Bekanntenkreis auf Skepsis.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Lisa Eisenberg hat sich auf regionale Speisen spezialisiert.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "In der Mittagszeit erzielt Lisa Eisenberg den Großteil ihres Umsatzes.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Lisa Eisenberg muss nicht mehr aktiv nach Kunden suchen.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Lisa Eisenberg bietet für Firmen täglich auch abends Gerichte an.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Es ist für Lisa Eisenberg leicht, ein geeignetes Fahrzeug zu finden.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Lisa Eisenberg hat als Studentin nebenbei in der Gastronomie gearbeitet.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "In den nächsten Monaten wird Lisa Eisenberg einen zweiten Wagen kaufen.",
          "answer": "-"
        }
      ],
      "code": "23468"
    },
    {
      "id": "33",
      "title": "Test 33 – Frau Makeba",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Meron Makeba hat schon in Ghana Leichtathletik gemacht.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Frau Makeba ist mit ihrem Ergebnis bei der WM sehr zufrieden.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Frau Makeba hat im vergangenen Jahr ihre Eltern in Ghana besucht.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Das Publikum hat bei der WM die Sportler aller Nationen unterstützt.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Frau Makeba trifft selten andere Sportler aus Ghana.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Für Frau Makeba ist Ghana noch immer ihre Heimat.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Wegen ihres Migrationshintergrundes hatte Frau Makeba keine Schwierigkeiten.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Anfangs war Frau Makeba in ihrem Verein die einzige Migrantin.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Frau Makeba glaubt nicht, dass man aufgrund der Herkunft in bestimmten Sportarten bevorzugt wird.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Frau Makebas Erfahrungen im privaten Bereich unterscheiden sich stark von denen im Sport.",
          "answer": "+"
        }
      ],
      "code": "4590"
    },
    {
      "id": "34",
      "title": "Test 34 – Thomas",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Nach seinem Studium hat Thomas Hirschbaum zuerst im IT-Bereich gearbeitet.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Er hat den Managementbereich in seiner Firma gegründet.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Es hat ihm gefallen, Verantwortung für sein 50-köpfiges Team zu haben.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Seine Eltern haben erwartet, dass er einmal mehr Geld verdient als sie.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Seit seinem Start ins Berufsleben hatte er keine Freizeit mehr.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Er hat sich oft nicht gut gefühlt, wenn er an seine Familie dachte.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Nach seinem 40. Geburtstag hatte er den Wunsch, mal einen Monat Urlaub zu machen.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Sein Chef war sofort mit dem Vorschlag einverstanden, die Arbeit anders zu organisieren.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Wie sein Kollege arbeitet Thomas Hirschbaum jetzt halbtags.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Trotzdem steht die Arbeit für ihn an oberster Stelle.",
          "answer": "-"
        }
      ],
      "code": "139"
    },
    {
      "id": "35",
      "title": "Test 35 – Bibliothek",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Astrid Nowak hat ihr ganzes Berufsleben in der Stadtbibliothek verbracht.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Die meisten Besucher/innen der Stadtbibliothek wollen Medien ausleihen.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Viele halten sich gern in den attraktiven Räumen der Bibliothek auf.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Die Bibliothek bietet ihre Dienstleistungen seit Jahren auch sonntags an.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Die vielfältigen Angebote der Bibliothek sind gratis nutzbar.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Ein Angebotsschwerpunkt sind Informationsmedien für jüngere Leute.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Man kann in der Bibliothek auch elektronische Geräte mieten.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Heute finden nur Kurse aus dem Bereich Medien und Technik statt.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Es gibt einen Raum, in dem man mit anderen zusammen moderne technische Werkzeuge ausprobieren kann.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Die Bibliotheken in Deutschland werden genauso häufig genutzt wie Kinos oder Museen.",
          "answer": "-"
        }
      ],
      "code": "2359"
    },
    {
      "id": "36",
      "title": "Test 36 – Eisschwimmen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Mit der Gründung der Eisschwimmervereinigung wollte Elias Wunderlich dem Eisschwimmen unter anderem zu einem offiziellen Status verhelfen.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Das Eisschwimmen hat Elias Wunderlich durch den Austausch mit anderen Sportlern entdeckt.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Die Ärzte sind sich einig, dass Eisschwimmen die Gesundheit fördert.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Nur durchtrainierte Menschen sollten Eisschwimmen betreiben.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Für den Einstieg in den Eisschwimmsport ist der Winterbeginn der beste Zeitpunkt.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Elias Wunderlich hält sich strikt an seine eigenen Empfehlungen.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Warmhaltendes Fett wird auch durch die Reaktion des Körpers auf Kälte erzeugt.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Bei Wettbewerben ist schützende Ganzkörperbekleidung vorgesehen.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Elias Wunderlich nimmt an Wettbewerben teil, um zu siegen.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Laut Elias Wunderlich kann Eisschwimmen zur Abhängigkeit führen.",
          "answer": "+"
        }
      ],
      "code": "35690"
    },
    {
      "id": "37",
      "title": "Test 37 – Beim Wettkampf",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 46,
          "text": "Beim Wettkampf auf Sylt gibt es mehr Zuschauer als bei anderen Surf-Wettkämpfen.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "Die Wind-Bedingungen sind auf Sylt sehr unberechenbar.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Herr Dunderbeck ist noch immer so fit wie früher.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Im Freestyle hat er schon starke Gegner, die viel jünger sind als er.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Beim Slalom muss er auch mit starken Gegnern rechnen.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Sein Hobby ist es, solche Strände zu suchen, wo sich im Windsurfen noch niemand ausprobiert hat.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Er hat ständig Angst vor den Haien.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Seine Kinder haben noch ein bisschen Angst vor dem Wasser, obwohl er sie schon aufs Brett gesetzt hatte.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Falls er auf Sylt siegen würde, würde er dies zuerst gerne mit seinen Freunden feiern.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Er hat zwei Kinder und sie gehen mit ihm auf Reisen.",
          "answer": "-"
        }
      ],
      "code": "1246"
    },
    {
      "id": "38",
      "title": "Test 38 – Sie – Frau Kiddar",
      "isVariant": false,
      "note": "Hören B2 neu 2026 S. 96 (Sie - Frau Kiddar الاساسي, Code 23670). Richtig (+): 47, 48, 51, 52, 55.",
      "questions": [
        {
          "num": 46,
          "text": "Sie kommt aus Düsseldorf.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Sie lebt jetzt in Malta.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Sie ist aktiv und engagiert in Malta.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Sie möchte nach Vancouver umziehen.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Sie genießt es, das ganze Jahr im Mittelmeer zu baden.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Der Moderator kennt die Temperatur des Mittelmeers im Winter nicht.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Der Moderator denkt, in Malta gibt es drei Amtssprachen.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Die Malteser waren konservativ und zurückhaltend.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Sie plante, die maltesische Sprache zu lernen.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Malteser kommen aus verschiedenen Religionen.",
          "answer": "+"
        }
      ],
      "code": "23670"
    },
    {
      "id": "38a",
      "title": "Test 38a – Sie – Frau Kiddar (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 97 (Sie - Frau Kiddar تعديل, Code 24589). Geänderte Reihenfolge der Aussagen 49–55! Richtig (+): 47, 49, 50, 53, 54.",
      "questions": [
        {
          "num": 46,
          "text": "Sie kommt aus Düsseldorf.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Sie lebt jetzt in Malta.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Sie ist aktiv und engagiert in Malta.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Sie genießt es, das ganze Jahr im Mittelmeer zu baden.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Der Moderator kennt die Temperatur des Mittelmeers im Winter nicht.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Der Moderator denkt, in Malta gibt es drei Amtssprachen.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Die Malteser waren konservativ und zurückhaltend.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Malteser kommen aus verschiedenen Religionen.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Sie plante, die maltesische Sprache zu lernen.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Sie möchte nach Vancouver umziehen.",
          "answer": "-"
        }
      ],
      "code": "24589"
    },
    {
      "id": "38b",
      "title": "Test 38b – Sie – Frau Kiddar (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 98 (Sie - Frau Kiddar تعديل -2, Code 23679). Richtig (+): 47, 48, 51, 52, 54.",
      "questions": [
        {
          "num": 46,
          "text": "Frau Kiddar stammt aus Düsseldorf.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "Sie lebt heute auf Malta.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Sie ist auf Malta beruflich tätig.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Frau Kiddar möchte gerne bald nach Valletta ziehen.",
          "answer": "-"
        },
        {
          "num": 50,
          "text": "Sie genießt es, das ganze Jahr über im Mittelmeer zu baden.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Der Moderator weiß nicht, wie viel Grad das Mittelmeer im Winter hat.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Frau Kiddar weist darauf hin, dass die Einwohner Maltas ursprünglich aus verschiedenen Regionen stammten.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Die Malteser haben sich ihr gegenüber aber zurückhaltend, ja misstrauisch verhalten.",
          "answer": "-"
        },
        {
          "num": 54,
          "text": "Der Moderator denkt, dass es auf Malta drei Amtssprachen gibt.",
          "answer": "+"
        },
        {
          "num": 55,
          "text": "Frau Kiddar plant, bald die maltesische Sprache zu lernen.",
          "answer": "-"
        }
      ],
      "code": "23679"
    },
    {
      "id": "39",
      "title": "Test 39 – Die Ausbildung",
      "isVariant": false,
      "note": [
        "Hören B2 neu 2026 S. 49 (#50) & S. 99 (Code 124680). Richtig (+): 46, 47, 49, 51, 53, 55. (Für den alternativen Bild-Code 34578 auf S. 99 siehe Test 39a)."
      ],
      "questions": [
        {
          "num": 46,
          "text": "Viele befürchten, dass es durch das neue Gesetz zu weiteren Mittelkürzungen kommt.",
          "answer": "+"
        },
        {
          "num": 47,
          "text": "In Zukunft werden weniger Erzieherinnen gebraucht als heute.",
          "answer": "+"
        },
        {
          "num": 48,
          "text": "Künftig soll es mehr Krippenplätze für Kinder unter drei Jahren geben.",
          "answer": "-"
        },
        {
          "num": 49,
          "text": "Der Besuch von Kindergärten soll kostenlos werden.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Die Mehrheit der Kleinkinder wird auch weiterhin zu Hause betreut werden.",
          "answer": "-"
        },
        {
          "num": 51,
          "text": "Bei Bedarf setzt die Sprachförderung im vierten Lebensjahr ein.",
          "answer": "+"
        },
        {
          "num": 52,
          "text": "Deutsche Kinder haben keinen Anspruch auf staatliche Sprachförderung.",
          "answer": "-"
        },
        {
          "num": 53,
          "text": "Im Elternhaus wird die Sprachförderung der Kinder immer häufiger vernachlässigt.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Herr Teichmann sieht in Bezug auf Sprachförderung auch auf Seiten der Politik Handlungsbedarf.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Die Ausbildung der Erzieherinnen soll künftig an Hochschulen angesiedelt sein.",
          "answer": "+"
        }
      ],
      "code": "124680"
    },
    {
      "id": "39a",
      "title": "Test 39a – Die Ausbildung (Variante)",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 99 (Bild-Code „Die Ausbildung 34578“ bzw. Korrigiert-PDF S. 564). Richtig (+): 48, 49, 50, 52, 53 (Code 34578).",
      "questions": [
        {
          "num": 46,
          "text": "Viele befürchten, dass es durch das neue Gesetz zu weiteren Mittelkürzungen kommt.",
          "answer": "-"
        },
        {
          "num": 47,
          "text": "In Zukunft werden weniger Erzieherinnen gebraucht als heute.",
          "answer": "-"
        },
        {
          "num": 48,
          "text": "Künftig soll es mehr Krippenplätze für Kinder unter drei Jahren geben.",
          "answer": "+"
        },
        {
          "num": 49,
          "text": "Der Besuch von Kindergärten soll kostenlos werden.",
          "answer": "+"
        },
        {
          "num": 50,
          "text": "Die Mehrheit der Kleinkinder wird auch weiterhin zu Hause betreut werden.",
          "answer": "+"
        },
        {
          "num": 51,
          "text": "Bei Bedarf setzt die Sprachförderung im vierten Lebensjahr ein.",
          "answer": "-"
        },
        {
          "num": 52,
          "text": "Deutsche Kinder haben keinen Anspruch auf staatliche Sprachförderung.",
          "answer": "+"
        },
        {
          "num": 53,
          "text": "Im Elternhaus wird die Sprachförderung der Kinder immer häufiger vernachlässigt.",
          "answer": "+"
        },
        {
          "num": 54,
          "text": "Herr Teichmann sieht in Bezug auf Sprachförderung auch auf Seiten der Politik Handlungsbedarf.",
          "answer": "-"
        },
        {
          "num": 55,
          "text": "Die Ausbildung der Erzieherinnen soll künftig an Hochschulen angesiedelt sein.",
          "answer": "-"
        }
      ],
      "code": "34578"
    }
  ],
  "3": [
    {
      "id": "1",
      "title": "Test 1 – Telefon",
      "isVariant": false,
      "note": "Deckblatt-Hinweis (S. 565) – Fehlende Fragen: -Schlagminger (15 → 56, 60 Richtig [+]), -Neu Autobahn (34 → 58, 59 Richtig [+]), -Konzert Juli (13 → 56, 58 Richtig [+]).",
      "questions": [
        {
          "num": 56,
          "text": "Bei der Deutschen Telefon KG bekommen Sie nur Auskunft zu Telefonapparaten dieses Unternehmens.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Im Rahmen des „BR3 Aquarena Weekends“ in Starnberg können Sie jeden Abend ein Feuerwerk betrachten.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Die Trierer Domorganisten spielen am 6. Juli in Michelstadt.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Während des Musikfestivals „Sound of Frankfurt“ ist die Benutzung der U- und S-Bahnen gebührenfrei.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Sie haben eine ungültige Servicenummer gewählt und werden daher automatisch weiterverbunden.",
          "answer": "-"
        }
      ],
      "code": "1"
    },
    {
      "id": "2",
      "title": "Test 2 – Musikfestivals",
      "isVariant": false,
      "note": "Aussage 56 ist rot unterstrichen (Unterschied zu Variante 2a). Aussage 60 ist im Scan nach „Die Autobahn \"AS\" ist Zwischen Baden-“ abgeschnitten (vollständiger Satz siehe Variante 2a). Entspricht dem Deckblatt-Hinweis „Konzert Juli (13)“ (56 und 58 Richtig).",
      "questions": [
        {
          "num": 56,
          "text": "Während des Musikfestivals „Sound of Frankfurt“ gibt es verbilligte Fahrkarten für alle öffentlichen Verkehrsmittel.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Sie gehen am 3. Juli ins Konzert, weil Sie die beiden Leipziger Klaviervirtuosen hören möchten.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Am Wochenende können Sie sich in Naumburg über die Bekämpfung von Krankheiten bei Apfelbäumen informieren.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Im Handwerksmuseum werden Kleidungsstücke ausgestellt.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Die Autobahn A5 ist zwischen Baden-Baden und Rastatt in beiden Richtungen gesperrt.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "2a",
      "title": "Test 2a – Musikfestivals (Mietwagen) (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 2: Aussage 56 ist rot unterstrichen (Mietwagen-Buchung unter Nummer 3223 statt Musikfestival „Sound of Frankfurt“); Aussage 60 ist hier vollständig abgedruckt.",
      "questions": [
        {
          "num": 56,
          "text": "Geschäftsreisende werden gebeten, Mietwagen unter der Nummer 3223 zu buchen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Sie gehen am 3. Juli ins Konzert, weil Sie die beiden Leipziger Klaviervirtuosen hören möchten.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Am Wochenende können Sie sich in Naumburg über die Bekämpfung von Krankheiten bei Apfelbäumen informieren.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Im Handwerksmuseum werden Kleidungsstücke ausgestellt.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Die Autobahn A5 ist zwischen Baden-Baden und Rastatt in beiden Richtungen gesperrt.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "3",
      "title": "Test 3 – Fahrschule",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Bei der Fahrschule kann man sich über das Internet anmelden.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die Anruferin ist im Hinblick auf die Abfahrtszeit flexibel.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Für den Halb-Marathon kann man sich noch am Sonntag registrieren lassen.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Bei dem Flug nach Mallorca ändert sich die Abflugzeit.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "In Halle D wird aus E-Books vorgelesen.",
          "answer": "-"
        }
      ],
      "code": "14"
    },
    {
      "id": "4",
      "title": "Test 4 – Im Süden Deutschlands – regnen",
      "isVariant": false,
      "note": "In Aussage 56 ist „regnen“ rot unterstrichen (vgl. Variante 4a mit „mit Schnee“).",
      "questions": [
        {
          "num": 56,
          "text": "Im Süden Deutschlands wird es nachmittags regnen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die Busse verkehren zu anderen Zeiten als die Regionalzüge.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Auf der A3 von Würzburg nach Frankfurt gibt es aufgrund eines Unfalls eine Vollsperrung.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Wenn Sie über Ihre Autoversicherung sprechen wollen, müssen Sie die 1 wählen.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Ihr Bekannter ist jederzeit telefonisch zu erreichen.",
          "answer": "-"
        }
      ],
      "code": "14"
    },
    {
      "id": "4a",
      "title": "Test 4a – Im Süden Deutschlands – Schnee (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 4: In Aussage 56 ist „mit Schnee“ rot unterstrichen; Aussagen 57–60 betreffen andere Hörtexte (Lösung: 56 und 60 Richtig [+]).",
      "questions": [
        {
          "num": 56,
          "text": "Morgen muss man im Süden Deutschlands mit Schnee rechnen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die zwei Jungen sind von zu Hause weggelaufen.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Am Samstag können Sie einen Mitarbeiter der Firma anrufen.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Wegen einer Demonstration ist es verboten, in die Nürnberger Altstadt zu fahren.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Die historische elektrische Eisenbahn wird im Dezember wie gewohnt fahren.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "5",
      "title": "Test 5 – Internet",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Sie können im Internet prüfen, ob Ihre aktuelle Bestellung schon unterwegs ist.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Man kann für die Nachtveranstaltung noch Karten im Internet kaufen.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Die Teilnahme an der Party im Burghof kostet nichts.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "In Bamberg kann man in der nächsten Woche besonders günstig Mitglied in einem Sportverein werden.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Wer ein wichtiges Anliegen hat, soll eine andere Nummer wählen.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "6",
      "title": "Test 6 – Ehrenamts",
      "isVariant": false,
      "note": "In Aussage 60 ist „muss“ rot unterstrichen (vgl. Variante 6a mit „sollte“).",
      "questions": [
        {
          "num": 56,
          "text": "Man kann am „Tag des Ehrenamts“ probeweise mithelfen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die Skateboard-Vorführung fällt dieses Mal aus.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Vor Passwort-Programmen wird gewarnt.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Es wird empfohlen, mit dem Fahrrad zum Volkspark zu fahren.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Wenn man das Training ausprobieren möchte, muss man vorher Bescheid sagen.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "6a",
      "title": "Test 6a – Ehrenamts (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 6: Aussage 59 lautet „Fahrräder direkt am Volkspark zu parken“; in Aussage 60 ist „sollte“ rot unterstrichen (statt „muss“).",
      "questions": [
        {
          "num": 56,
          "text": "Man kann am „Tag des Ehrenamts“ probeweise mithelfen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die Skateboard-Vorführung fällt dieses Mal aus.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Vor Passwort-Programmen wird gewarnt.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Es wird empfohlen, Fahrräder direkt am Volkspark zu parken.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Wenn man das Training ausprobieren möchte, sollte man vorher Bescheid sagen.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "7",
      "title": "Test 7 – Demonstration",
      "isVariant": false,
      "note": "Hören B2 neu 2026 S. 100 (#25) & S. 110 („Demonstration: 24“). Richtig (+): 57, 59 (Code 24). (Für die ältere PDF-Variante mit Code 25 siehe Test 7a).",
      "questions": [
        {
          "num": 56,
          "text": "Die Demonstration findet in Frankfurt vor der Alten Oper statt.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "In der kommenden Saison wird eine Symphonie von Mahler aufgeführt.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Die Weltmeisterschaften im Eiskunstlauf finden in der Dortmunder Helmut-Körnig-Halle statt.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Die Autobahn A980 ist mit Schneeketten zu befahren.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Für die Vermittlung einer Mitfahrgelegenheit per E-Mail erhebt „fahre mit“ keine Gebühren.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "7a",
      "title": "Test 7a – Demonstration (Variante)",
      "isVariant": true,
      "note": "Variante aus Korrigiert-PDF Mai 2025 („Demonstration: 25“). Richtig (+): 57, 60 (Code 25). (In Hören B2 neu 2026 S. 110 ist der Code 24 → siehe Test 7).",
      "questions": [
        {
          "num": 56,
          "text": "Die Demonstration findet in Frankfurt vor der Alten Oper statt.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "In der kommenden Saison wird eine Symphonie von Mahler aufgeführt.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Die Weltmeisterschaften im Eiskunstlauf finden in der Dortmunder Helmut-Körnig-Halle statt.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Die Autobahn A980 ist mit Schneeketten zu befahren.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Für die Vermittlung einer Mitfahrgelegenheit per E-Mail erhebt „fahre mit“ keine Gebühren.",
          "answer": "+"
        }
      ],
      "code": "25"
    },
    {
      "id": "8",
      "title": "Test 8 – Im August",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Im August gibt es jeden Tag eine Aufführung.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Zur Station Grünberg kommen Sie mit der U-Bahn-Linie 68.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "In weniger dringlichen Fällen soll man eine Nachricht hinterlassen.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Am Mittwoch und Donnerstag können Sie Sachspenden vorbeibringen.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Nur an den Nachmittagen wird eine hohe Verkehrsdichte erwartet.",
          "answer": "-"
        }
      ],
      "code": "34"
    },
    {
      "id": "9",
      "title": "Test 9 – Am Wochenanfang",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Am Wochenanfang soll man einen Aufenthalt im Freien vermeiden.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Abends ist das Risiko, einen Wildunfall zu haben, am größten.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Man kann bei dem Fest an verschiedenen Orten Musik hören.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "In dringenden Fällen können Sie die Firma ab Montag erreichen.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Am Abend werden Verkehrsbehinderungen erwartet.",
          "answer": "-"
        }
      ],
      "code": "123"
    },
    {
      "id": "10",
      "title": "Test 10 – Fundbüro",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Sie müssen nicht persönlich beim Fundbüro nachfragen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die Wettervorhersage können Sie nach den Mittagsnachrichten hören.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Sie dürfen Ihr Rad spontan im Zug mitnehmen.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Am Donnerstag sehen Sie das deutsche Team im Halbfinale.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Während der Sperrung kann man die üblichen Bushaltestellen benutzen.",
          "answer": "+"
        }
      ],
      "code": "125"
    },
    {
      "id": "11",
      "title": "Test 11 – Ausgang",
      "isVariant": false,
      "note": "In Aussage 56 ist „Ausgang 26 kommen“ rot unterstrichen. Variante 11a enthält dieselben Aussagen in umgekehrter Reihenfolge (60 → 56).",
      "questions": [
        {
          "num": 56,
          "text": "Sie sollen zum Ausgang 26 kommen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Um die zuständige Abteilung zu erreichen, müssen Sie die 3 wählen.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Bei der Service-Nummer bekommen Sie Karten für eine Führung.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Sie können sich am Sonntag um ein Uhr bewerben.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "In der Bäckerstraße dürfen Sie nicht fahren.",
          "answer": "+"
        }
      ],
      "code": "145"
    },
    {
      "id": "11a",
      "title": "Test 11a – Ausgang (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 11: Umgekehrte Reihenfolge der Aussagen 56–60 gegenüber Test 11 (Lösung: 56, 57 und 60 Richtig [+]). In Aussage 60 ist „Ausgang 26 kommen“ rot unterstrichen.",
      "questions": [
        {
          "num": 56,
          "text": "In der Bäckerstraße dürfen Sie nicht fahren.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Sie können sich am Sonntag um ein Uhr bewerben.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Bei der Service-Nummer bekommen Sie Karten für eine Führung.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Um die zuständige Abteilung zu erreichen, müssen Sie die 3 wählen.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Sie sollen zum Ausgang 26 kommen.",
          "answer": "+"
        }
      ],
      "code": "125"
    },
    {
      "id": "12",
      "title": "Test 12 – Blutspenden",
      "isVariant": false,
      "note": "Vier Aussagen sind Richtig (+): 56, 58, 59 und 60.",
      "questions": [
        {
          "num": 56,
          "text": "Ihre Tochter kann am Freitag verschiedene Sportarten testen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Sie können sich im Internet zum Blutspenden anmelden.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Heute müssen Sie auf den Bus ausweichen.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Sie müssen das Bad früher verlassen.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Für einen Termin müssen Sie anrufen.",
          "answer": "+"
        }
      ],
      "code": "1345"
    },
    {
      "id": "13",
      "title": "Test 13 – Reitturniers",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Besucher des Reitturniers sollten möglichst Parkplätze außerhalb des Turniergeländes nutzen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Das Open-Air-Gospelkonzert wird live im Radio übertragen.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Bei der Berliner Museumsnacht können Sie mit einer Sonderbuslinie bequem jedes Museum erreichen.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Wegen Glätte ist die A5 zwischen Mannheim und Frankfurt in beide Richtungen voll gesperrt.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Hotelreservierungen in Dresden sind ausschließlich telefonisch möglich.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "14",
      "title": "Test 14 – Delikatessen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Bis 14 Uhr können Sie Delikatessen aus verschiedenen Ländern kaufen.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Bis zum Start können Sie mit Ihrem Handy telefonieren.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Vorführungen mit Tieren werden nicht geboten.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Am Wochenende können Sie Musik im Schloss Mirabell hören.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Sie können Frau Dr. Schneider am Samstagabend anrufen.",
          "answer": "-"
        }
      ],
      "code": "234"
    },
    {
      "id": "15",
      "title": "Test 15 – In Raum C23",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "In Raum C23 trägt ein bekannter Schriftsteller etwas vor.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Wenn Ihre Software nicht funktioniert, erhalten Sie über das Internet Unterstützung.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "In der Stadtbibliothek präsentiert heute eine Hochschule ihr Angebot vor allem für Berufstätige.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Im Internet finden Sie auch Angebote für spezielle Zielgruppen.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Wenn man Dienstag oder Donnerstag jemanden persönlich sprechen möchte, braucht man einen Termin.",
          "answer": "-"
        }
      ],
      "code": "2"
    },
    {
      "id": "16",
      "title": "Test 16 – Wanderung",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Nach einer Großdemonstration liegen in Frankfurt Gegenstände auf den Straßen.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Wer bei der Wanderung keinen Rucksack mitnehmen will, kann unterwegs etwas zu essen und zu trinken bekommen.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Bei der Volkshochschule Tübingen kann man sich für alle Kurse problemlos per E-Mail anmelden.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Im Klassikfunk kann man ab 20.15 Uhr CDs mit Musik von Verdi bestellen.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Kinder können während der Sommerferien im Römerkastell Saalburg übernachten.",
          "answer": "-"
        }
      ],
      "code": "2"
    },
    {
      "id": "17",
      "title": "Test 17 – Die Gruppe Die Prinzen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Die Gruppe „Die Prinzen“ tritt am 23. Juni in Kiel auf.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Der Frankfurter JPMorgan Chase Corporate Challenge Lauf beginnt in der Nähe der Alten Oper.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Die Prager Nacht findet im Regensburger Dom statt.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Auf der A3 Frankfurt Richtung Würzburg ist zwischen Offenbach und Seligenstadt ein Stau.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Der Anbieter „Call & Call“ verbindet Sie kostenlos mit Ihrem Gesprächspartner.",
          "answer": "-"
        }
      ],
      "code": "14"
    },
    {
      "id": "18",
      "title": "Test 18 – Spätestens in Hannover",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Sie müssen spätestens in Hannover in den hinteren Zugteil umsteigen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Wenn Sie für das Radio eine Geschichte über Ihren eigenen 18. Geburtstag schreiben, müssen Sie bei der Party keinen Eintritt bezahlen.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Ihrer Freundin geht es nicht gut.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Auf dem Festival wird auch Musik von Beethoven gespielt.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Sie können das Eisbärbaby jederzeit im Freien beobachten.",
          "answer": "-"
        }
      ],
      "code": "123"
    },
    {
      "id": "19",
      "title": "Test 19 – Für das Konzert mit Romano",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Der Software-Service von Macrohard steht rund um die Uhr zur Verfügung.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Für das Konzert mit Romano Castelli gibt es noch Karten ab 200 Euro.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Über den neuen Tarif von T-Upline können Sie sich im Internet informieren.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Weil das Schwerpunktthema „Japan“ lautet, treten im Park des Museums für Völkerkunde in diesem Jahr nur japanische Musiker auf.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Bei dem Festival gibt es nicht nur folkloristische Unterhaltung, sondern auch kulinarische Spezialitäten aus dem In- und Ausland.",
          "answer": "+"
        }
      ],
      "code": "35"
    },
    {
      "id": "20",
      "title": "Test 20 – Bayern Radio",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Beim Informationsdienst der Telekom können Sie sich auch über Aktienkurse informieren.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "In Hanau findet am Nachmittag ein Kindermaskenball statt.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Sie erfahren ausschließlich im Internet, ob Sie gewonnen haben.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Am Freitag müssen Sie in den Mittelgebirgen mit vielen Pollen rechnen.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Bayern Radio hat computergestützte Fahrschulprogramme getestet.",
          "answer": "+"
        }
      ],
      "code": "145"
    },
    {
      "id": "21",
      "title": "Test 21 – Gartenausstellung KöGa",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Die Parade der Kulturen wird mit einem Feuerwerk eröffnet.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Zum Skateboard-Treffen am 31. Oktober soll man verkleidet erscheinen.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Bei der Gartenausstellung KöGa kann man Gartenzwerge kaufen.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Die Autobahn A2 Richtung Hannover ist zwischen Rheda-Wiedenbrück und Oelde gesperrt.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Für handvermittelte Telefongespräche ins Ausland müssen Sie die 613 30 30 30 wählen.",
          "answer": "-"
        }
      ],
      "code": "234"
    },
    {
      "id": "22",
      "title": "Test 22 – Den Opel-Zoo",
      "isVariant": false,
      "note": "In Aussage 58 fehlt am Zeilenanfang im Scan „Am 8.“ vor „und 9. Juli kann man den Opel-Zoo nachts besuchen.“",
      "questions": [
        {
          "num": 56,
          "text": "Am Donnerstag ist in der Uckermark mit Birkenpollen zu rechnen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die Führung durch Frankfurts Hochhäuser beginnt am Messeturm.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Am 8. und 9. Juli kann man den Opel-Zoo nachts besuchen.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Für die Wanderung zur Ronneburg sollte man unbedingt genügend Verpflegung mitnehmen.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Auf der A7 Ulm – Füssen ist der linke Fahrstreifen gesperrt.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "23",
      "title": "Test 23 – Der Christkindlesmarkt in Nürnberg",
      "isVariant": false,
      "note": "Vier Aussagen sind Richtig (+): 56, 57, 59 und 60.",
      "questions": [
        {
          "num": 56,
          "text": "Der Christkindlesmarkt in Nürnberg hat einen speziellen Geschenk-Dienst für Kinder im Programm.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Auf dem deutsch-französischen Bauernmarkt in Hochspeyer gibt es ökologische Projekte.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "In Heilsheim gibt es heute Abend einen Jodelkurs.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Auf der A5 gibt es hinter Karlsruhe mehrere Behinderungen.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Ihr Computer fährt nicht mehr hoch. Sie müssen die 70 17 17 wählen, um bei Computer World Hilfe zu bekommen.",
          "answer": "+"
        }
      ],
      "code": "1245"
    },
    {
      "id": "24",
      "title": "Test 24 – Das Geschäft für österreichische Spezialitäten",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Das Geschäft für österreichische Spezialitäten befindet sich in Check-in-2.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Fortgeschrittene Schüler, Studenten, Profis und Lehrkräfte haben die Möglichkeit zu unterrichten.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Interessenten können auf der Messe nur Bestellungen aufgeben.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Alle Studierenden müssen ab dem Wintersemester Studiengebühren bezahlen.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Der Bürgermeister eröffnet das Fest.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "25",
      "title": "Test 25 – Alle Flüge der Fluglinie",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Das Restaurant hat bis 23 Uhr geöffnet.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Alle Flüge der Fluglinie AirMer sind für heute und morgen gestrichen.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Auf alle Möbel gibt es heute und morgen einen Preisnachlass von bis zu 70 %.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Der Schickmarkt hat ab Freitagvormittag geöffnet.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Der Intercity nach Bregenz fällt aufgrund eines technischen Gebrechens aus.",
          "answer": "-"
        }
      ],
      "code": "2"
    },
    {
      "id": "26",
      "title": "Test 26 – Auto gewinnen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Der Regionalzug nach Bruck an der Mur um 7:15 Uhr wird nicht fahren.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Man kann ein Auto gewinnen, wenn man alle 9 Gewinnzahlen sammelt.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Nächste Woche gibt es Äpfel zum Preis von unter 1 €.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Der Intercity nach München fährt immer von Bahnsteig 2.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Der Eintritt ins Kunterbunt-Kindermuseum ist am Eröffnungstag gratis.",
          "answer": "+"
        }
      ],
      "code": "25"
    },
    {
      "id": "27",
      "title": "Test 27 – Die Fahrradtouren von Berlin",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Die Fahrradtouren von „Berlin auf zwei Rädern“ können nicht nur privat, sondern auch im beruflichen Kontext gebucht werden.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Straßen in Passau sind durch das starke Unwetter heute noch bis vier Uhr blockiert.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Sitzplatzreservierungen im ICE sind wegen technischer Probleme in den Wagen 24–38 ungültig.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Selma schlägt vor, die Verabredung auf Samstag zu verschieben.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Die lange Nacht der Architektur ist kostenlos, wenn man sich vorher online anmeldet.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "28",
      "title": "Test 28 – Die Literaturmesse für Kleinverleger",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Die Literaturmesse für Kleinverleger findet zum ersten Mal statt.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Bei dem Wettkampf machte Saskia Winzer alles richtig.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Am Samstag ist den ganzen Tag mit Sonne zu rechnen.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Das Theaterstück wird zum ersten Mal am Stadttheater aufgeführt.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Während des Unterhaltungsprogramms gibt es auch Kinderbetreuung.",
          "answer": "+"
        }
      ],
      "code": "5"
    },
    {
      "id": "29",
      "title": "Test 29 – Fußballspiels im Ostpark",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Die Übertragung des Fußballspiels im Ostpark findet bei jedem Wetter statt.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Wer sich für den Newsletter registriert, kann jeden Monat etwas gewinnen.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Alle Besucher des Schwimmbads dürfen heute im Restaurant kostenlos etwas trinken.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Wegen einer technischen Störung ist der Onlineshop weder telefonisch noch per E-Mail erreichbar.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Am Familiensonntag dürfen Kinder kostenlos ins Museum.",
          "answer": "-"
        }
      ],
      "code": "12"
    },
    {
      "id": "30",
      "title": "Test 30 – Das Treffen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Das Treffen ist am Donnerstag.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Das Wetter bleibt schlecht und regnerisch; am Sonntagnachmittag leichte Wetterbesserung.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Die Firma ist direkt an der S-Bahn-Station.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Das Restaurant bietet Kaffee für 2 Euro 50 und Kuchen für 2 Euro.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Sprachprogramme für Deutsch gibt es in derselben Abteilung wie Computerspiele.",
          "answer": "+"
        }
      ],
      "code": "125"
    },
    {
      "id": "31",
      "title": "Test 31 – Im Frankfurter Zoo",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Im Frankfurter Zoo kann man Großkatzen in einer naturnahen Umgebung erleben.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Bei dem deutsch-französischen Fest werden Gaumenfreuden aus Deutschland und Frankreich angeboten.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Auf der Autobahn A7 zwischen Hamburg und Flensburg ist ein Stau wegen mehrerer Unfälle.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Wer anruft, kann über die Vergabe des Preises mitentscheiden.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Telefonische Beratungen werden an allen Werktagen auch nachmittags angeboten.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "32",
      "title": "Test 32 – Für ein Konzert morgen",
      "isVariant": false,
      "note": "In Aussage 57 ist „in der ganzen Stadt“ rot unterstrichen (Lösung in Test 32: 56 und 58 Richtig [+]; vgl. Variante 32a mit Lösung 57 und 59 Richtig [+]).",
      "questions": [
        {
          "num": 56,
          "text": "Für ein Konzert morgen Abend kann man noch im Internet Karten kaufen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Heute ist das Busfahren in der ganzen Stadt umsonst.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Bei dem Filmfestival werden internationale Kinderfilme gezeigt.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Das Busunternehmen Schneider kündigt neue Fernbusverbindungen an.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Man kann eine kostenlose Probestunde vereinbaren.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "32a",
      "title": "Test 32a – Für ein Konzert morgen (Variante)",
      "isVariant": true,
      "note": "Variante zu Test 32: Aussage 57 lautet „Man kann mit dem Bus gratis zum Fest fahren.“ (rot unterstrichen); Lösung in Variante 32a: 57 und 59 Richtig (+).",
      "questions": [
        {
          "num": 56,
          "text": "Für ein Konzert morgen Abend kann man noch im Internet Karten kaufen.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Man kann mit dem Bus gratis zum Fest fahren.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Bei dem Filmfestival werden internationale Kinderfilme gezeigt.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Das Busunternehmen Schneider kündigt neue Fernbusverbindungen an.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Man kann sich für eine kostenlose Probestunde anmelden.",
          "answer": "-"
        }
      ],
      "code": "24"
    },
    {
      "id": "33",
      "title": "Test 33 – Buchhandlung",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Sie hören den Anrufbeantworter einer Buchhandlung.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Beim Jubiläumsfest im Schloss kann man selbst Musik machen.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Wer gerne und lange tanzt, sollte in Kulmbach vorbeischauen.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Sie können sich für alle Kurse auch über das Internet registrieren.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Internationale Künstler treten an verschiedenen Plätzen in Esens auf.",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "34",
      "title": "Test 34 – ohne Frankfurt (Fest vormittags besuchen, Die Wiese beginnt um 8 Uhr, Jugendliche 13,50 €) [Code 13]",
      "isVariant": false,
      "note": "Hören B2 neu 2026 S. 100 (#43) & S. 137 oben („ohne frankfurt: 56-58 / code: 13“). Richtig (+): 56, 58 (Code 13).",
      "questions": [
        {
          "num": 56,
          "text": "Heute kann man vormittags das Fest besuchen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Die Wiese beginnt um 8 Uhr.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Eintrittskarten für Jugendliche kosten 13,50 €.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Die Fahrkarte ist in bestimmten Zügen gültig.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Am Sonntag können Kinder ein Theaterstück anschauen.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "34a",
      "title": "Test 34a (Variante – Mit Frankfurt, Seite 137) – Fest vormittags, Verkauf ab 9 Uhr morgens [Code 135]",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 137 unten („Mit frankfurt: 56-58-60 / code: 135“). Richtig (+): 56, 58, 60 (Code 135).",
      "questions": [
        {
          "num": 56,
          "text": "Heute kann man vormittags das Fest besuchen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Der Verkauf beginnt um 9 Uhr morgens.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Eintrittskarten für Jugendliche kosten 13,50 €. (PDF: € 13,50 kosten Jugendliche Eintrittskarten für)",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Die Fahrkarte ist in bestimmten Zügen gültig.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Am Sonntag können Kinder ein Theaterstück anschauen.",
          "answer": "+"
        }
      ],
      "code": "135"
    },
    {
      "id": "34b",
      "title": "Test 34b (Variante – Mit Frankfurt, Deckblatt-Code 134) – Fest vormittags, Verkauf ab 9 Uhr morgens [Code 134]",
      "isVariant": true,
      "note": "Hören B2 neu 2026 S. 100 Deckblatt (#44 „Mit frankfurt: 134“). Richtig (+): 56, 58, 59 (Code 134).",
      "questions": [
        {
          "num": 56,
          "text": "Heute kann man vormittags das Fest besuchen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Der Verkauf beginnt um 9 Uhr morgens.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Eintrittskarten für Jugendliche kosten 13,50 €. (PDF: € 13,50 kosten Jugendliche Eintrittskarten für)",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Die Fahrkarte ist in bestimmten Zügen gültig.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Am Sonntag können Kinder ein Theaterstück anschauen.",
          "answer": "-"
        }
      ],
      "code": "134"
    },
    {
      "id": "35",
      "title": "Test 35 – Ein Teil der kostenlosen",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Der IC 865 fährt heute nicht nach Hamburg, sondern nur bis Bonn.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Ein Teil der kostenlosen Veranstaltungen beim Literaturfest findet an spannenden Orten in der Stadt statt.",
          "answer": "+"
        },
        {
          "num": 58,
          "text": "Die Firma Sanitärbedarf Frieder & Hansen ist sechs Tage die Woche für Anfragen erreichbar.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Bewohner des Musikerviertels müssen am Donnerstagnachmittag für zwei Stunden zu Hause bleiben.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Zum Valentinstag gibt es heute eine spezielle Beratung für Schmuck und Kosmetikartikel.",
          "answer": "-"
        }
      ],
      "code": "23"
    },
    {
      "id": "36",
      "title": "Test 36 – Auf der Viktoriabrücke",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Die nächtlichen Temperaturen gehen in der ganzen Region auf null Grad zurück.",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "An der Abendkasse sind die Karten für das Konzert der Gruppe Sing Slow günstiger als im Vorverkauf.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Auf der Viktoriabrücke kann wegen Bauarbeiten stadteinwärts nur eine Fahrbahn genutzt werden.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Wenn man den Eindruck hat, man hat zu viel für den Strom bezahlt, wählt man die 2.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Beim Fest in Bergheim finden Darbietungen von internationalen Theatergruppen statt.",
          "answer": "-"
        }
      ],
      "code": "34"
    },
    {
      "id": "37",
      "title": "Test 37 – Die Buchpräsentation",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Die Buchpräsentation beginnt laut Programm in 30 Minuten.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Patienten, die zu einer Nachbehandlung kommen, werden zu Schalter 3 gebeten.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Dienstags gibt es für einen Friseurbesuch zu Hause ein Sonderangebot.",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Die Führungen im Tierpark beginnen in der Kassazone.",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Die Besucher werden zum Mitmachen eingeladen.",
          "answer": "+"
        }
      ],
      "code": "145"
    },
    {
      "id": "38",
      "title": "Test 38 – Beim Klassik-Radio",
      "isVariant": false,
      "note": "",
      "questions": [
        {
          "num": 56,
          "text": "Beim Klassik-Radio kann man Karten für ein Konzert in Frankfurt gewinnen.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Für den Engelberg-Lauf in Miltenberg ist eine frühzeitige Anmeldung erforderlich.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Der Radiosender Bayern 1 informiert auf seiner Website über das Sommernachtsfest.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Auf der A3 hat es in der Nähe von Erlangen einen Unfall gegeben.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Funk-Mobil bietet Dienstleistungen für Autofahrer an.",
          "answer": "-"
        }
      ],
      "code": "13"
    },
    {
      "id": "F1",
      "title": "Deckblatt-Vermerk 1 – Schladminger (15)",
      "isVariant": true,
      "note": "Deckblatt-Vermerk auf PDF Seite 565: „-Schlagminger (15)“ → Aussagen 1 und 5 (Aufgaben 56 und 60) sind Richtig (+), Aufgaben 57, 58, 59 sind Falsch (–).",
      "questions": [
        {
          "num": 56,
          "text": "Schladminger (Aufgabe 56 laut Deckblatt-Lösungsschlüssel 15: Richtig [+])",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Aufgabe 57 zum Hörtext „Schladminger“ (laut Deckblatt-Lösungsschlüssel 15: Falsch [–])",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Aufgabe 58 zum Hörtext „Schladminger“ (laut Deckblatt-Lösungsschlüssel 15: Falsch [–])",
          "answer": "-"
        },
        {
          "num": 59,
          "text": "Aufgabe 59 zum Hörtext „Schladminger“ (laut Deckblatt-Lösungsschlüssel 15: Falsch [–])",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Aufgabe 60 zum Hörtext „Schladminger“ (laut Deckblatt-Lösungsschlüssel 15: Richtig [+])",
          "answer": "+"
        }
      ],
      "code": "15"
    },
    {
      "id": "F2",
      "title": "Deckblatt-Vermerk 2 – Neue Autobahn (34)",
      "isVariant": true,
      "note": "Deckblatt-Vermerk auf PDF Seite 565: „-Neu Autobahn (34)“ → Aussagen 3 und 4 (Aufgaben 58 und 59) sind Richtig (+), Aufgaben 56, 57, 60 sind Falsch (–).",
      "questions": [
        {
          "num": 56,
          "text": "Neue Autobahn (Aufgabe 56 laut Deckblatt-Lösungsschlüssel 34: Falsch [–])",
          "answer": "-"
        },
        {
          "num": 57,
          "text": "Aufgabe 57 zum Hörtext „Neue Autobahn“ (laut Deckblatt-Lösungsschlüssel 34: Falsch [–])",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Aufgabe 58 zum Hörtext „Neue Autobahn“ (laut Deckblatt-Lösungsschlüssel 34: Richtig [+])",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Aufgabe 59 zum Hörtext „Neue Autobahn“ (laut Deckblatt-Lösungsschlüssel 34: Richtig [+])",
          "answer": "+"
        },
        {
          "num": 60,
          "text": "Aufgabe 60 zum Hörtext „Neue Autobahn“ (laut Deckblatt-Lösungsschlüssel 34: Falsch [–])",
          "answer": "-"
        }
      ],
      "code": "34"
    },
    {
      "id": "F3",
      "title": "Test F3 – Musikfestivals (Variante)",
      "isVariant": true,
      "note": "Deckblatt-Vermerk auf PDF Seite 565: „-Konzert Juli (13)“ → Aussagen 1 und 3 (Aufgaben 56 und 58) sind Richtig (+). Entspricht außerdem Test 2 / 2a (Konzert am 6. Juli).",
      "questions": [
        {
          "num": 56,
          "text": "Während des Musikfestivals „Sound of Frankfurt“ gibt es verbilligte Fahrkarten für alle öffentlichen Verkehrsmittel.",
          "answer": "+"
        },
        {
          "num": 57,
          "text": "Sie gehen am 3. Juli ins Konzert, weil Sie die beiden Leipziger Klaviervirtuosen hören möchten.",
          "answer": "-"
        },
        {
          "num": 58,
          "text": "Am Wochenende können Sie sich in Naumburg über die Bekämpfung von Krankheiten bei Apfelbäumen informieren.",
          "answer": "+"
        },
        {
          "num": 59,
          "text": "Im Handwerksmuseum werden Kleidungsstücke ausgestellt.",
          "answer": "-"
        },
        {
          "num": 60,
          "text": "Die Autobahn A5 ist zwischen Baden-Baden und Rastatt in beiden Richtungen gesperrt.",
          "answer": "-"
        }
      ],
      "code": "13"
    }
  ]
};
