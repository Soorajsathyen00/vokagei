const schreibenData = {
  "1": [
    {
      "id": "1",
      "title": "Test 1 – Bewerbungstraining der Profes-Akademie",
      "page": 1,
      "ziel": {
        "de": "Ich wollte meine Bewerbungsunterlagen verbessern und sicherer in Vorstellungsgesprächen werden.",
        "en": "I wanted to improve my application documents and feel more confident in job interviews."
      },
      "vorteil": {
        "de": "Angekündigt waren ein vollständiges Training von Lebenslauf bis Bewerbungsgespräch, praktische Rollenspiele, Videoaufnahmen zur Selbstkontrolle sowie Gruppen- oder Einzeltraining nach Wunsch.",
        "en": "The advertisement promised complete training from CV writing to job interviews, practical role plays, video recordings for self-review, and group or individual sessions by choice."
      },
      "items": [
        {
          "promise": {
            "de": "komplettes Training vom Lebenslauf bis zum Bewerbungsgespräch",
            "en": "complete training from CV to job interview"
          },
          "complaint": {
            "de": "Der Kurs bestand überwiegend aus allgemeinen Vorträgen statt aus praktischen Übungen.",
            "en": "The course consisted mostly of general lectures instead of practical exercises."
          }
        },
        {
          "promise": {
            "de": "praktische Rollenspiele",
            "en": "practical role plays"
          },
          "complaint": {
            "de": "Die angekündigten Rollenspiele fanden nur selten statt.",
            "en": "The advertised role plays took place only rarely."
          }
        },
        {
          "promise": {
            "de": "Video-Aufnahmen zur Selbstkontrolle",
            "en": "video recordings for self-review"
          },
          "complaint": {
            "de": "Obwohl Videoaufnahmen angekündigt waren, wurde keine Übung aufgenommen.",
            "en": "Although video recordings were advertised, no exercise was recorded."
          }
        },
        {
          "promise": {
            "de": "Gruppen- oder Einzeltraining nach Wunsch",
            "en": "group or individual training by choice"
          },
          "complaint": {
            "de": "Auf individuelle Fragen zu meinem Lebenslauf erhielt ich kaum hilfreiche Rückmeldungen.",
            "en": "I received hardly any useful feedback on individual questions about my CV."
          }
        }
      ]
    },
    {
      "id": "2",
      "title": "Test 2 – Aufenthalt im City Club Hotel",
      "page": 2,
      "ziel": {
        "de": "Ich wollte eine günstige, abwechslungsreiche Woche in Berlin mit anderen jungen Leuten verbringen.",
        "en": "I wanted to spend an affordable, varied week in Berlin with other young people."
      },
      "vorteil": {
        "de": "Die Anzeige versprach All-inclusive-Verpflegung mit Frühstück, Abendessen, Lunchpaket und Getränken, große Zimmer mit Bad, TV und WLAN, einen Pool auf der Dachterrasse, Freizeitangebote und Ausflüge.",
        "en": "The advertisement promised all-inclusive meals with breakfast, dinner, a packed lunch and drinks, large rooms with a bathroom, TV and Wi-Fi, a rooftop pool, leisure facilities and excursions."
      },
      "items": [
        {
          "promise": {
            "de": "Frühstück, Abendessen, Lunchpaket und Getränke inklusive",
            "en": "breakfast, dinner, packed lunch and drinks included"
          },
          "complaint": {
            "de": "Das Lunchpaket und mehrere im Preis enthaltene Getränke wurden uns zusätzlich berechnet.",
            "en": "We were charged extra for the packed lunch and several drinks that were supposed to be included."
          }
        },
        {
          "promise": {
            "de": "große Zimmer mit Bad, TV und WLAN",
            "en": "large rooms with bathroom, TV and Wi-Fi"
          },
          "complaint": {
            "de": "Das Zimmer war deutlich kleiner als angekündigt und das WLAN funktionierte kaum.",
            "en": "The room was much smaller than advertised and the Wi-Fi barely worked."
          }
        },
        {
          "promise": {
            "de": "Schwimmbad auf der Dachterrasse",
            "en": "rooftop swimming pool"
          },
          "complaint": {
            "de": "Der Pool auf der Dachterrasse war während unseres gesamten Aufenthalts geschlossen.",
            "en": "The rooftop pool was closed throughout our stay."
          }
        },
        {
          "promise": {
            "de": "Fitnesscenter, Klettergarten, Disko und Ausflüge",
            "en": "fitness centre, climbing garden, disco and excursions"
          },
          "complaint": {
            "de": "Das angekündigte Fitnesscenter, der Klettergarten und die Ausflüge standen nicht zur Verfügung.",
            "en": "The advertised fitness centre, climbing garden and excursions were not available."
          }
        }
      ]
    },
    {
      "id": "3",
      "title": "Test 3 – Sprachpaket \"Deutsch? Na klar!\"",
      "page": 3,
      "ziel": {
        "de": "Ich wollte von zu Hause aus mein Deutsch verbessern und zugleich flexibel lernen.",
        "en": "I wanted to improve my German from home while studying flexibly."
      },
      "vorteil": {
        "de": "Für 59,95 Euro wurden ein Online-Zugang, eine Zusatz-DVD und ein Arbeitsbuch mit 15 modernen Lektionen, Fotos und Videos sowie Online-Hilfe durch Sprachtrainer beworben.",
        "en": "For 59.95 euros, the offer included online access, an additional DVD and a workbook with 15 modern lessons, photos and videos, plus online help from language trainers."
      },
      "items": [
        {
          "promise": {
            "de": "Online-Sprachpaket mit Zugang, DVD und Arbeitsbuch",
            "en": "online language package with access, DVD and workbook"
          },
          "complaint": {
            "de": "Der Online-Zugang ließ sich trotz mehrfacher Versuche nicht freischalten.",
            "en": "I could not activate the online access despite trying several times."
          }
        },
        {
          "promise": {
            "de": "15 moderne Lektionen mit Fotos und Videos",
            "en": "15 modern lessons with photos and videos"
          },
          "complaint": {
            "de": "Die Lektionen enthielten deutlich weniger Fotos und Videos als in der Anzeige angekündigt.",
            "en": "The lessons contained far fewer photos and videos than advertised."
          }
        },
        {
          "promise": {
            "de": "besser Deutsch sprechen und schreiben",
            "en": "improve spoken and written German"
          },
          "complaint": {
            "de": "Das Arbeitsbuch fehlte in meiner Lieferung und die DVD war beschädigt.",
            "en": "The workbook was missing from my delivery and the DVD was damaged."
          }
        },
        {
          "promise": {
            "de": "Sprachtrainer helfen online bei Übungen",
            "en": "language trainers help with exercises online"
          },
          "complaint": {
            "de": "Auf meine Fragen zu den Übungen antwortete kein Sprachtrainer.",
            "en": "No language trainer answered my questions about the exercises."
          }
        }
      ]
    },
    {
      "id": "4",
      "title": "Test 4 – Deutsch-Intensivkurs in der Waldschule",
      "page": 4,
      "ziel": {
        "de": "Ich wollte meine Deutschkenntnisse in einem zweiwöchigen Intensivkurs verbessern und dabei in einer ruhigen Umgebung lernen.",
        "en": "I wanted to improve my German in a two-week intensive course and study in a quiet setting."
      },
      "vorteil": {
        "de": "Angekündigt waren qualifizierte Lehrkräfte, höchstens sechs Lernende pro Gruppe, moderne Unterrichtstechnik mit einem internetfähigen Computer pro Person und ein Wohnheim direkt neben der Schule.",
        "en": "The advertisement promised qualified teachers, no more than six learners per group, modern classroom technology with an internet-enabled computer for each person, and a residence hall next to the school."
      },
      "items": [
        {
          "promise": {
            "de": "qualifizierte Deutschlehrer",
            "en": "qualified German teachers"
          },
          "complaint": {
            "de": "In meiner Lerngruppe waren deutlich mehr als sechs Teilnehmende.",
            "en": "There were considerably more than six participants in my class."
          }
        },
        {
          "promise": {
            "de": "Gruppen mit höchstens sechs Teilnehmenden",
            "en": "groups of no more than six participants"
          },
          "complaint": {
            "de": "Der Unterricht wurde oft von wechselnden Lehrkräften gehalten und war wenig intensiv.",
            "en": "Classes were often taught by substitute teachers and were not very intensive."
          }
        },
        {
          "promise": {
            "de": "moderne Technik und ein Computer mit Internet pro Person",
            "en": "modern technology and one internet computer per person"
          },
          "complaint": {
            "de": "Die Computer waren veraltet und der Internetzugang fiel regelmäßig aus.",
            "en": "The computers were outdated and internet access regularly failed."
          }
        },
        {
          "promise": {
            "de": "freundliches Wohnheim direkt neben der Schule",
            "en": "welcoming residence hall next to the school"
          },
          "complaint": {
            "de": "Das Wohnheim war nicht freundlich oder ruhig; außerdem war mein Zimmer nicht sauber.",
            "en": "The residence hall was neither welcoming nor quiet, and my room was not clean."
          }
        }
      ]
    },
    {
      "id": "5",
      "title": "Test 5 – Fahrschule Himmel",
      "page": 5,
      "ziel": {
        "de": "Ich wollte meinen Führerschein schnell und preiswert machen und einen passenden Kurs wählen.",
        "en": "I wanted to get my driving licence quickly and affordably and choose a suitable course."
      },
      "vorteil": {
        "de": "Beworben wurden helle, klimatisierte Räume, moderne Fahrzeuge, Kurse nach Wahl, Angebote auch auf Englisch, Russisch oder Chinesisch und ein Paket mit Anmeldung, zwölf Sonderfahrten, sechs Fahrstunden sowie Prüfungsanmeldungen.",
        "en": "The advertisement promoted bright, air-conditioned classrooms, modern vehicles, courses of choice, lessons in English, Russian or Chinese, and a package including registration, twelve special drives, six driving lessons and exam bookings."
      },
      "items": [
        {
          "promise": {
            "de": "schnell und preiswert zum Führerschein",
            "en": "get a driving licence quickly and affordably"
          },
          "complaint": {
            "de": "Der Führerschein kostete am Ende deutlich mehr als der beworbene günstige Paketpreis.",
            "en": "In the end, the driving course cost much more than the advertised low package price."
          }
        },
        {
          "promise": {
            "de": "helle, klimatisierte Unterrichtsräume",
            "en": "bright, air-conditioned classrooms"
          },
          "complaint": {
            "de": "Das Fahrschulauto war alt und entsprach nicht den angekündigten modernen Fahrzeugen.",
            "en": "The driving-school car was old and did not match the advertised modern vehicles."
          }
        },
        {
          "promise": {
            "de": "modernste Fahrzeuge",
            "en": "state-of-the-art vehicles"
          },
          "complaint": {
            "de": "Der Unterrichtsraum war weder hell noch klimatisiert.",
            "en": "The classroom was neither bright nor air-conditioned."
          }
        },
        {
          "promise": {
            "de": "Paket mit zwölf Sonderfahrten, sechs Fahrstunden und Prüfungsanmeldungen",
            "en": "package with twelve special drives, six lessons and exam bookings"
          },
          "complaint": {
            "de": "Für die angekündigten Fahrstunden und Prüfungsanmeldungen wurden mir zusätzliche Gebühren berechnet.",
            "en": "I was charged extra for the advertised driving lessons and exam bookings."
          }
        }
      ]
    },
    {
      "id": "6",
      "title": "Test 6 – Fitness-Online-Studio",
      "page": 6,
      "ziel": {
        "de": "Ich wollte trotz wenig Zeit regelmäßig trainieren und meine Fitness oder Beweglichkeit verbessern.",
        "en": "Despite having little time, I wanted to exercise regularly and improve my fitness or flexibility."
      },
      "vorteil": {
        "de": "Beworben wurden flexibles Training jederzeit und überall, Videos von Sportwissenschaftlern, professionelle Anleitung zur richtigen Ausführung, Programme für Einsteiger und Fortgeschrittene sowie eine kostenlose Probewoche.",
        "en": "The advertisement promised flexible training anytime and anywhere, videos by sports scientists, professional guidance on correct form, programmes for beginners and advanced users, and a free trial week."
      },
      "items": [
        {
          "promise": {
            "de": "flexibel trainieren, wann und wo man möchte",
            "en": "train flexibly whenever and wherever desired"
          },
          "complaint": {
            "de": "Mehrere Trainingsvideos ließen sich auf meinem Gerät nicht abspielen.",
            "en": "Several workout videos would not play on my device."
          }
        },
        {
          "promise": {
            "de": "Videos von Sportwissenschaftlern mit Fokus auf korrekte Ausführung",
            "en": "sports-scientist videos focused on correct form"
          },
          "complaint": {
            "de": "Die Übungen wurden nicht ausreichend erklärt, sodass ich die richtige Ausführung nicht erkennen konnte.",
            "en": "The exercises were not explained sufficiently, so I could not tell how to perform them correctly."
          }
        },
        {
          "promise": {
            "de": "Programme für Einsteiger und Fortgeschrittene",
            "en": "programmes for beginners and advanced users"
          },
          "complaint": {
            "de": "Das gebuchte Programm passte nicht zu meinem angegebenen Trainingsniveau.",
            "en": "The programme I booked did not match the training level I had selected."
          }
        },
        {
          "promise": {
            "de": "individuelle Ernährungspläne und eine kostenlose Probewoche",
            "en": "personal nutrition plans and a free trial week"
          },
          "complaint": {
            "de": "Nach der kostenlosen Woche wurde der Beitrag abgebucht, obwohl ich mein Angebot rechtzeitig kündigen wollte.",
            "en": "The fee was charged after the free week although I tried to cancel the offer in time."
          }
        }
      ]
    },
    {
      "id": "7",
      "title": "Test 7 – Fotokurs im Studio \"Shooting Werkstatt\"",
      "page": 7,
      "ziel": {
        "de": "Ich wollte meine Fototechnik verbessern und mehr über Bildbearbeitung und Bildpräsentation lernen.",
        "en": "I wanted to improve my photography technique and learn more about image editing and presenting photographs."
      },
      "vorteil": {
        "de": "Angekündigt waren ein erfahrener Pressefotograf, individuelle Antworten auf Fragen, Einblicke in Bildbearbeitung und Bildpräsentation sowie fachlich geleitete Wochenendexkursionen; der Kurs sollte sieben Termine mit höchstens zehn Personen umfassen.",
        "en": "The advertisement promised an experienced press photographer, individual answers to questions, instruction in image editing and presentation, and expert-led weekend excursions; the course was to have seven sessions with no more than ten participants."
      },
      "items": [
        {
          "promise": {
            "de": "erfahrener Pressefotograf als Kursleiter",
            "en": "experienced press photographer as instructor"
          },
          "complaint": {
            "de": "Die Kurstermine wurden kurzfristig geändert, sodass ich an mehreren Stunden nicht teilnehmen konnte.",
            "en": "The course dates were changed at short notice, so I could not attend several sessions."
          }
        },
        {
          "promise": {
            "de": "Einführung in Bildbearbeitung und Bildpräsentation",
            "en": "instruction in image editing and presentation"
          },
          "complaint": {
            "de": "Der Kurs behandelte Bildbearbeitung und Bildpräsentation kaum.",
            "en": "The course hardly covered image editing or presentation."
          }
        },
        {
          "promise": {
            "de": "individuelle Antworten auf Fragen",
            "en": "individual answers to questions"
          },
          "complaint": {
            "de": "Der Kursleiter ging nicht auf individuelle Fragen ein.",
            "en": "The instructor did not address individual questions."
          }
        },
        {
          "promise": {
            "de": "fachlich geleitete Wochenendexkursionen",
            "en": "expert-led weekend excursions"
          },
          "complaint": {
            "de": "Die angekündigten Exkursionen unter fachlicher Leitung fanden nicht statt.",
            "en": "The advertised expert-led excursions did not take place."
          }
        }
      ]
    },
    {
      "id": "8",
      "title": "Test 8 – Hollandblumen-Onlineshop",
      "page": 8,
      "ziel": {
        "de": "Ich wollte zu einem besonderen Anlass frische Blumen oder ein geschmackvolles Geschenk zuverlässig an eine andere Person schicken lassen.",
        "en": "For a special occasion, I wanted to have fresh flowers or a tasteful gift reliably delivered to someone else."
      },
      "vorteil": {
        "de": "Angekündigt waren Blumen direkt vom Gärtner mit Qualitätskontrolle, deutschlandweite Lieferung mit Frische-Garantie zu einem selbst gewählten Zeitpunkt und Ort sowie Grußkarten und Dekorationen.",
        "en": "The advertisement promised flowers directly from growers with quality checks, nationwide delivery with a freshness guarantee at a time and place of the customer’s choice, and greeting cards and decorations."
      },
      "items": [
        {
          "promise": {
            "de": "Blumen direkt vom Gärtner und strenge Qualitätskontrolle",
            "en": "flowers directly from growers and strict quality checks"
          },
          "complaint": {
            "de": "Die Blumen waren nicht frisch und stammten offenbar nicht aus der angekündigten Qualitätskontrolle.",
            "en": "The flowers were not fresh and apparently had not passed the advertised quality check."
          }
        },
        {
          "promise": {
            "de": "Frische-Garantie",
            "en": "freshness guarantee"
          },
          "complaint": {
            "de": "Ein Teil der Lieferung war verwelkt und entsprach nicht der Frische-Garantie.",
            "en": "Some of the delivery was wilted and did not meet the freshness guarantee."
          }
        },
        {
          "promise": {
            "de": "Lieferung zu selbst gewähltem Zeitpunkt und Ort",
            "en": "delivery at a time and place chosen by the customer"
          },
          "complaint": {
            "de": "Die Blumen kamen nicht zum von mir gewählten Zeitpunkt an.",
            "en": "The flowers did not arrive at the time I had chosen."
          }
        },
        {
          "promise": {
            "de": "Erreichbarkeit von Montag bis Samstag",
            "en": "availability from Monday to Saturday"
          },
          "complaint": {
            "de": "Während der angekündigten Servicezeiten war die Hotline nicht erreichbar.",
            "en": "The hotline could not be reached during the advertised service hours."
          }
        }
      ]
    },
    {
      "id": "9",
      "title": "Test 9 – Konzertreise mit Konzertreisen Schneider KG",
      "page": 9,
      "ziel": {
        "de": "Ich wollte mein Lieblingskonzert besuchen und die Reise gemeinsam mit anderen Musikbegeisterten genießen.",
        "en": "I wanted to attend a concert I love and enjoy the trip with other music fans."
      },
      "vorteil": {
        "de": "Die Anzeige versprach moderne Reisebusse mit Abfahrten in vielen Städten, Unterkunft im gewünschten Zimmertyp, Essen auf Wunsch, Eintrittskarten und eine Reiseleitung bei Fragen oder Problemen.",
        "en": "The advertisement promised modern coaches departing from many cities, accommodation in the chosen room type, meals if requested, concert tickets, and a tour guide to help with questions or problems."
      },
      "items": [
        {
          "promise": {
            "de": "moderne Reisebusse mit Abfahrten in vielen Städten",
            "en": "modern coaches departing from many cities"
          },
          "complaint": {
            "de": "Der Bus fuhr deutlich später als geplant ab und wir kamen erst nach Konzertbeginn an.",
            "en": "The coach left much later than planned and we arrived after the concert had started."
          }
        },
        {
          "promise": {
            "de": "Unterkunft im gewählten Zimmer-Typ",
            "en": "accommodation in the selected room type"
          },
          "complaint": {
            "de": "Die gebuchte Unterkunft entsprach nicht dem vereinbarten Zimmertyp.",
            "en": "The accommodation did not match the room type I had booked."
          }
        },
        {
          "promise": {
            "de": "Essen auf Wunsch inklusive",
            "en": "meals included on request"
          },
          "complaint": {
            "de": "Das bestellte Essen war nicht organisiert und ich musste mich selbst darum kümmern.",
            "en": "The meal I had ordered was not arranged, so I had to find food myself."
          }
        },
        {
          "promise": {
            "de": "Eintrittskarte und Reiseleitung bei Fragen oder Problemen",
            "en": "ticket and tour guide for questions or problems"
          },
          "complaint": {
            "de": "Der Reiseleiter reagierte auf meine Beschwerde nicht hilfreich und kümmerte sich nicht um das Problem.",
            "en": "The tour guide did not respond helpfully to my complaint and did not address the problem."
          }
        }
      ]
    },
    {
      "id": "10",
      "title": "Test 10 – NATUR PUR Kosmetik-Party",
      "page": 10,
      "ziel": {
        "de": "Ich wollte hautgerechte Naturkosmetik kennenlernen, Produkte ausprobieren und mich fachkundig beraten lassen.",
        "en": "I wanted to discover natural cosmetics suited to my skin, try the products and receive expert advice."
      },
      "vorteil": {
        "de": "Angekündigt waren Naturkosmetik mit pflanzlichen Rohstoffen, vegetarische und auf Anfrage vegane Produkte, mehrfach sehr gute Testergebnisse, hauttypgerechte Beratung, Produktproben, interessante Preise und Rabattaktionen.",
        "en": "The invitation promoted natural cosmetics made with plant-based ingredients, vegetarian and on request vegan products, repeated top test ratings, advice tailored to skin type, product samples, attractive prices and discounts."
      },
      "items": [
        {
          "promise": {
            "de": "Naturkosmetik mit pflanzlichen Rohstoffen",
            "en": "natural cosmetics with plant-based ingredients"
          },
          "complaint": {
            "de": "Die Produkte enthielten keine natürlichen Pflanzenextrakte, obwohl sie als Naturkosmetik beworben wurden.",
            "en": "The products contained no natural plant extracts, although they were advertised as natural cosmetics."
          }
        },
        {
          "promise": {
            "de": "vegetarische und auf Anfrage vegane Produkte",
            "en": "vegetarian and vegan products on request"
          },
          "complaint": {
            "de": "Trotz meiner Anfrage konnte ich kein veganes Produkt kaufen.",
            "en": "Despite my request, I could not buy a vegan product."
          }
        },
        {
          "promise": {
            "de": "Beratung passend zum Hauttyp",
            "en": "advice tailored to skin type"
          },
          "complaint": {
            "de": "Die Beratung berücksichtigte meinen Hauttyp und meine Fragen kaum.",
            "en": "The advice barely took my skin type or questions into account."
          }
        },
        {
          "promise": {
            "de": "Produktproben und attraktive Rabattaktionen",
            "en": "product samples and attractive discounts"
          },
          "complaint": {
            "de": "Die angekündigten Proben und Rabattaktionen wurden auf der Party nicht angeboten.",
            "en": "The advertised samples and discounts were not offered at the party."
          }
        }
      ]
    },
    {
      "id": "11",
      "title": "Test 11 – prima-app.net",
      "page": 11,
      "ziel": {
        "de": "Ich wollte kostenlose oder preiswerte Apps, Sportübertragungen, Filme und aktuelle Informationen auf meinem Smartphone nutzen.",
        "en": "I wanted to use free or low-cost apps, sports broadcasts, films and current information on my smartphone."
      },
      "vorteil": {
        "de": "Beworben wurden viele Apps, Live-Sport, Filme, aktuelle Sportergebnisse und Schlagzeilen, Witze, schneller Zugang zu sozialen Medien und sofortiger, unbegrenzter Zugang; ein kleiner Monatsbeitrag war im Kleingedruckten erwähnt.",
        "en": "The advertisement promoted many apps, live sports, films, current scores and headlines, jokes, quick access to social media and immediate unlimited access; a small monthly fee was mentioned in the fine print."
      },
      "items": [
        {
          "promise": {
            "de": "kostenlose Apps für das Handy",
            "en": "free apps for mobile phones"
          },
          "complaint": {
            "de": "Für die als kostenlos beworbenen Apps wurde ein höherer Monatsbeitrag verlangt als erwartet.",
            "en": "A higher monthly fee than expected was charged for the apps advertised as free."
          }
        },
        {
          "promise": {
            "de": "Sport-Live-Sendungen und Filme",
            "en": "live sports broadcasts and films"
          },
          "complaint": {
            "de": "Die angekündigten Sportübertragungen und Filme ließen sich nicht abspielen.",
            "en": "The advertised sports broadcasts and films would not play."
          }
        },
        {
          "promise": {
            "de": "aktuelle Sportergebnisse und Schlagzeilen",
            "en": "current sports results and headlines"
          },
          "complaint": {
            "de": "Die Sportergebnisse und Schlagzeilen waren nicht aktuell.",
            "en": "The sports results and headlines were not up to date."
          }
        },
        {
          "promise": {
            "de": "sofortiger, unbegrenzter Zugang gegen einen geringen Monatsbeitrag",
            "en": "immediate unlimited access for a small monthly fee"
          },
          "complaint": {
            "de": "Mein Zugang war entgegen der Anzeige begrenzt und mehrere Angebote waren gesperrt.",
            "en": "Contrary to the advertisement, my access was limited and several services were blocked."
          }
        }
      ]
    },
    {
      "id": "12",
      "title": "Test 12 – Salz- und Pfeffermühlen \"Salpiper\"",
      "page": 12,
      "ziel": {
        "de": "Ich wollte hochwertige, ansprechend gestaltete und leicht zu reinigende Mühlen mit stufenlos einstellbarem Mahlgrad kaufen.",
        "en": "I wanted to buy high-quality, attractive and easy-to-clean mills with an adjustable grinding level."
      },
      "vorteil": {
        "de": "Beworben wurden Glas und hochwertiger Kunststoff, ein verschleiß- und korrosionsfreies Keramikmahlwerk, stufenlose Einstellung, keine Mahlspuren auf dem Tisch, spülmaschinengeeignete Pflege und zehn Jahre Garantie auf das Mahlwerk.",
        "en": "The advertisement promoted glass and high-quality plastic, a wear- and corrosion-resistant ceramic grinder, continuous adjustment, no grinding residue on the table, dishwasher-safe care and a ten-year warranty on the grinder."
      },
      "items": [
        {
          "promise": {
            "de": "hochwertige Mühlen aus Glas und Kunststoff",
            "en": "high-quality mills made of glass and plastic"
          },
          "complaint": {
            "de": "Die Mühlen aus Glas und Kunststoff bekamen schon nach kurzer Zeit Risse.",
            "en": "The glass and plastic mills developed cracks after only a short time."
          }
        },
        {
          "promise": {
            "de": "Keramikmahlwerk: härter als Stahl, verschleiß- und korrosionsfrei",
            "en": "ceramic grinder: harder than steel, wear- and corrosion-resistant"
          },
          "complaint": {
            "de": "Das Keramikmahlwerk verschliss schnell und blockierte bereits nach kurzer Benutzung.",
            "en": "The ceramic grinder wore out quickly and jammed after only a short period of use."
          }
        },
        {
          "promise": {
            "de": "stufenlose Einstellung von fein bis grob",
            "en": "continuous adjustment from fine to coarse"
          },
          "complaint": {
            "de": "Der Mahlgrad ließ sich nicht stufenlos einstellen und sprang zwischen grob und fein.",
            "en": "The grind could not be adjusted continuously and jumped between coarse and fine."
          }
        },
        {
          "promise": {
            "de": "keine Mahlspuren auf dem Tisch und zehn Jahre Garantie auf das Mahlwerk",
            "en": "no grinding residue on the table and a ten-year grinder warranty"
          },
          "complaint": {
            "de": "Beim Mahlen blieben trotz der Zusage Rückstände auf dem Tisch zurück.",
            "en": "Despite the promise, grinding residue was left on the table."
          }
        }
      ]
    },
    {
      "id": "13",
      "title": "Test 13 – Tagesfahrt \"Kultur und Kulinarik\"",
      "page": 13,
      "ziel": {
        "de": "Ich wollte einen entspannten Tagesausflug mit guter Verpflegung, netter Gesellschaft und interessanten Sehenswürdigkeiten machen.",
        "en": "I wanted a relaxing day trip with good food, friendly company and interesting sights."
      },
      "vorteil": {
        "de": "Die Anzeige versprach eine angenehme Busfahrt, Frühstücksbuffet, unbegrenzte Berliner Spezialitäten zum Mittagessen, freie Kuchen- und Tortenauswahl sowie Besuche von Kirchen, Klöstern, Burgen oder Schlössern mit Erklärungen und Pausen.",
        "en": "The advertisement promised a pleasant coach trip, a breakfast buffet, all-you-can-eat Berlin specialities for lunch, a choice of cakes, and visits to churches, monasteries, castles or palaces with explanations and breaks."
      },
      "items": [
        {
          "promise": {
            "de": "frisches, reichhaltiges Frühstücksbuffet",
            "en": "fresh, generous breakfast buffet"
          },
          "complaint": {
            "de": "Die Fahrt war nicht angenehm, weil der Bus stark verschmutzt war.",
            "en": "The journey was not pleasant because the coach was very dirty."
          }
        },
        {
          "promise": {
            "de": "Berliner Spezialitäten zum Mittagessen, so viel man essen kann",
            "en": "all-you-can-eat Berlin specialities for lunch"
          },
          "complaint": {
            "de": "Beim Mittagessen gab es keine unbegrenzte Auswahl an Berliner Spezialitäten.",
            "en": "At lunch, there was no unlimited selection of Berlin specialities."
          }
        },
        {
          "promise": {
            "de": "Kuchen und Torten zur freien Auswahl",
            "en": "a free choice of cakes and pastries"
          },
          "complaint": {
            "de": "Die angekündigten Kuchen und Torten standen nicht zur freien Auswahl.",
            "en": "The advertised cakes and pastries were not freely available to choose from."
          }
        },
        {
          "promise": {
            "de": "Besichtigungen mit Erklärungen und passenden Pausen",
            "en": "sightseeing with explanations and suitable breaks"
          },
          "complaint": {
            "de": "Zu den Sehenswürdigkeiten gab es kaum Erklärungen und die angekündigten Pausen fehlten.",
            "en": "There were hardly any explanations of the sights and the promised breaks were missing."
          }
        }
      ]
    },
    {
      "id": "14",
      "title": "Test 14 – Fahrradtour bei \"Radel dich munter e.V.\"",
      "page": 14,
      "ziel": {
        "de": "Ich wollte mich regelmäßig bewegen, eine geführte Radtour ausprobieren und Fragen zu Sport und Gesundheit stellen.",
        "en": "I wanted to exercise regularly, try a guided bike tour and ask questions about sport and health."
      },
      "vorteil": {
        "de": "Beworben wurden freundliche Trainer, Antworten auf Fragen zu Sport und Gesundheit, moderne Leihräder, tägliche Abendtouren sowie Wochenendtouren; eine Stunde kostete 5 Euro oder die Mitgliedschaft 25 Euro im Monat.",
        "en": "The advertisement promised friendly trainers, answers to questions about sport and health, modern bicycles for use, evening rides every day and weekend rides; one hour cost 5 euros or membership cost 25 euros per month."
      },
      "items": [
        {
          "promise": {
            "de": "freundliche Trainer begleiten die Touren",
            "en": "friendly trainers accompany the rides"
          },
          "complaint": {
            "de": "Der Trainer war unfreundlich und begleitete die Gruppe nicht zuverlässig.",
            "en": "The trainer was unfriendly and did not reliably accompany the group."
          }
        },
        {
          "promise": {
            "de": "moderne Fahrräder stehen bereit",
            "en": "modern bicycles are provided"
          },
          "complaint": {
            "de": "Das bereitgestellte Fahrrad war alt und nicht modern.",
            "en": "The bicycle provided was old and not modern."
          }
        },
        {
          "promise": {
            "de": "einstündige Touren mit Trainer",
            "en": "one-hour rides with a trainer"
          },
          "complaint": {
            "de": "Die Tour dauerte deutlich kürzer als die angekündigte Stunde.",
            "en": "The ride lasted considerably less than the advertised hour."
          }
        },
        {
          "promise": {
            "de": "Trainer beantworten Fragen zu Sport und Gesundheit",
            "en": "trainers answer questions about sport and health"
          },
          "complaint": {
            "de": "Auf meine Fragen zu Sport und Gesundheit reagierte der Trainer ungeduldig und gab keine hilfreichen Antworten.",
            "en": "The trainer responded impatiently to my questions about sport and health and gave no useful answers."
          }
        }
      ]
    },
    {
      "id": "15",
      "title": "Test 15 – Wohnungsbesichtigung Am Berg 22 – Service (Aufgabe R12b)",
      "page": 15,
      "ziel": {
        "de": "Ich suchte eine bezahlbare Wohnung in Offenbach mit passenden Räumen und wollte mich bei einer Besichtigung über Kosten und Bedingungen informieren.",
        "en": "I was looking for an affordable home in Offenbach with suitable rooms and wanted to learn about costs and conditions at a viewing."
      },
      "vorteil": {
        "de": "Angekündigt waren eine kürzlich komplett sanierte Anlage, Zwei- bis Vierzimmerwohnungen mit Bad, Gäste-WC und Balkon oder Gartenanteil, Informationen zu Preisen, Vertragsbedingungen, Kaution und Energieeffizienz sowie Makler für weitere Fragen; Besichtigungen waren sonntags ohne Anmeldung möglich.",
        "en": "The advertisement promised a recently renovated complex, two- to four-room flats with a bathroom, guest toilet and balcony or garden, information on prices, contract terms, deposit and energy efficiency, and agents available for questions; viewings were available on Sundays without an appointment."
      },
      "items": [
        {
          "promise": {
            "de": "Besichtigung sonntags ohne Anmeldung",
            "en": "Sunday viewings without an appointment"
          },
          "complaint": {
            "de": "Obwohl die Besichtigung sonntags ohne Anmeldung möglich sein sollte, war kein Makler vor Ort.",
            "en": "Although Sunday viewings were supposed to be available without an appointment, no agent was on site."
          }
        },
        {
          "promise": {
            "de": "Wohnungen mit Bad, Gäste-WC und Balkon oder Gartenanteil",
            "en": "flats with bathroom, guest toilet and balcony or garden"
          },
          "complaint": {
            "de": "In der Wohnung fehlten das angekündigte Gäste-WC und der Balkon oder Gartenanteil.",
            "en": "The flat lacked the advertised guest toilet and balcony or garden area."
          }
        },
        {
          "promise": {
            "de": "kürzlich komplett sanierte Wohnanlage",
            "en": "recently fully renovated residential complex"
          },
          "complaint": {
            "de": "Die Wohnanlage war entgegen der Anzeige nicht vollständig saniert.",
            "en": "Contrary to the advertisement, the residential complex was not fully renovated."
          }
        },
        {
          "promise": {
            "de": "Makler erklären Preise, Vertragsbedingungen, Kaution und Energieeffizienz",
            "en": "agents explain prices, contract terms, deposit and energy efficiency"
          },
          "complaint": {
            "de": "Der Makler konnte mir die angekündigten Informationen zu Kosten und Vertragsbedingungen nicht geben.",
            "en": "The agent could not give me the promised information about costs and contract terms."
          }
        }
      ]
    },
    {
      "id": "16",
      "title": "Test 16 – Wohnungsbesichtigung Am Berg 22 – Angebot (Aufgabe R15)",
      "page": 16,
      "ziel": {
        "de": "Ich wollte wegen der hohen Mieten in Frankfurt eine preisgünstige Wohnung in Offenbach finden und das Angebot vor Ort prüfen.",
        "en": "Because rents in Frankfurt were high, I wanted to find an affordable flat in Offenbach and inspect the offer in person."
      },
      "vorteil": {
        "de": "Beworben wurden eine neu sanierte Anlage, Wohnungen mit zwei bis vier Zimmern, Bad, Gäste-WC und Balkon oder Gartenanteil, 150 verfügbare Wohnungen, Erläuterungen zu Kosten, Vertragsbedingungen, Kaution und Energieeffizienz sowie Besichtigungen ohne Anmeldung am Sonntag.",
        "en": "The advertisement promoted a newly renovated complex, flats with two to four rooms, a bathroom, guest toilet and balcony or garden, 150 available flats, explanations of costs, contract terms, deposit and energy efficiency, and Sunday viewings without an appointment."
      },
      "items": [
        {
          "promise": {
            "de": "neu sanierte Anlage",
            "en": "newly renovated complex"
          },
          "complaint": {
            "de": "Die Anlage war entgegen der Anzeige nicht neu saniert.",
            "en": "Contrary to the advertisement, the complex was not newly renovated."
          }
        },
        {
          "promise": {
            "de": "150 verfügbare Wohnungen",
            "en": "150 available flats"
          },
          "complaint": {
            "de": "Keine der angekündigten 150 Wohnungen stand bei der Besichtigung zur Verfügung.",
            "en": "None of the advertised 150 flats was available to view."
          }
        },
        {
          "promise": {
            "de": "Wohnungen mit Bad, Gäste-WC und Balkon oder Gartenanteil",
            "en": "flats with bathroom, guest toilet and balcony or garden"
          },
          "complaint": {
            "de": "Die gezeigte Wohnung hatte weder das angekündigte Gäste-WC noch einen Balkon oder Gartenanteil.",
            "en": "The flat shown had neither the advertised guest toilet nor a balcony or garden area."
          }
        },
        {
          "promise": {
            "de": "Makler erklären Kosten, Vertragsbedingungen, Kaution und Energieeffizienz",
            "en": "agents explain costs, contract terms, deposit and energy efficiency"
          },
          "complaint": {
            "de": "Der Makler erklärte die Kosten, Vertragsbedingungen und Energieeffizienz nicht ausreichend.",
            "en": "The agent did not adequately explain the costs, contract terms and energy efficiency."
          }
        }
      ]
    },
    {
      "id": "17",
      "title": "Test 17 – Online-Geschenke-Service Müller",
      "page": 17,
      "ziel": {
        "de": "Ich wollte ein Geburtstagsgeschenk bequem online bestellen und es schön verpackt pünktlich zustellen lassen.",
        "en": "I wanted to order a birthday gift conveniently online and have it delivered on time in attractive wrapping."
      },
      "vorteil": {
        "de": "Beworben wurden eine große Auswahl in bester Qualität, hochwertiges Geschenkpapier, eine persönliche Glückwunschkarte auf Wunsch, pünktliche Lieferung und kostenloser Versand.",
        "en": "The advertisement promised a wide selection of top-quality gifts, high-quality wrapping paper, a personal greeting card on request, on-time delivery and free shipping."
      },
      "items": [
        {
          "promise": {
            "de": "große Auswahl an Geschenken in bester Qualität",
            "en": "wide selection of gifts in top quality"
          },
          "complaint": {
            "de": "Der Artikel war beschädigt und hatte nicht die angekündigte gute Qualität.",
            "en": "The item was damaged and was not of the advertised high quality."
          }
        },
        {
          "promise": {
            "de": "hochwertiges Geschenkpapier",
            "en": "high-quality gift wrapping"
          },
          "complaint": {
            "de": "Das Geschenk war nicht in hochwertigem Geschenkpapier verpackt.",
            "en": "The gift was not wrapped in high-quality gift wrapping."
          }
        },
        {
          "promise": {
            "de": "persönliche Glückwunschkarte auf Wunsch",
            "en": "personal greeting card on request"
          },
          "complaint": {
            "de": "Die persönliche Glückwunschkarte fehlte im Paket.",
            "en": "The personal greeting card was missing from the package."
          }
        },
        {
          "promise": {
            "de": "pünktliche Lieferung und kostenloser Versand",
            "en": "on-time delivery and free shipping"
          },
          "complaint": {
            "de": "Das Paket kam verspätet an und entgegen der Anzeige wurden Versandkosten berechnet.",
            "en": "The package arrived late and, contrary to the advertisement, shipping costs were charged."
          }
        }
      ]
    },
    {
      "id": "18",
      "title": "Test 18 – Schmelzkäse \"Alpengeschmack\"",
      "page": 18,
      "ziel": {
        "de": "Ich wollte einen vielseitigen Käse kaufen, den ich zum Kochen, Überbacken und für Brot verwenden kann.",
        "en": "I wanted to buy a versatile cheese for cooking, baking dishes and serving with bread."
      },
      "vorteil": {
        "de": "Auf der Verpackung wurden vielseitige Verwendung, eine feinwürzige Note, zehn einzeln verpackte Scheiben und eine Mindesthaltbarkeit von 24 Tagen im ungeöffneten Zustand angegeben.",
        "en": "The package described versatile uses, a delicately savoury flavour, ten individually wrapped slices and a minimum shelf life of 24 days unopened."
      },
      "items": [
        {
          "promise": {
            "de": "„Die Reinheit der Natur auf Ihrem Teller“",
            "en": "“The purity of nature on your plate”"
          },
          "complaint": {
            "de": "In dem Käse befanden sich Fremdkörper, obwohl auf der Verpackung mit „Reinheit der Natur“ geworben wurde.",
            "en": "The cheese contained foreign objects, although the package advertised “the purity of nature”."
          }
        },
        {
          "promise": {
            "de": "vielseitig in der Küche verwendbar",
            "en": "versatile use in the kitchen"
          },
          "complaint": {
            "de": "Der Käse ließ sich wegen eines unangenehmen Geruchs nicht vielseitig verwenden.",
            "en": "Because of an unpleasant smell, the cheese could not be used in the advertised variety of ways."
          }
        },
        {
          "promise": {
            "de": "zehn einzeln verpackte Scheiben",
            "en": "ten individually wrapped slices"
          },
          "complaint": {
            "de": "Die einzeln verpackten Scheiben waren beschädigt und nicht hygienisch verschlossen.",
            "en": "The individually wrapped slices were damaged and not hygienically sealed."
          }
        },
        {
          "promise": {
            "de": "ungeöffnet mindestens 24 Tage haltbar",
            "en": "keeps for at least 24 days unopened"
          },
          "complaint": {
            "de": "Der Käse war bereits vor Ablauf der angegebenen 24 Tage verdorben.",
            "en": "The cheese had spoiled before the stated 24-day shelf life had passed."
          }
        }
      ]
    },
    {
      "id": "19",
      "title": "Test 19 – Smartphone-Flatrate bei DasSchnellste.net",
      "page": 19,
      "ziel": {
        "de": "Ich wollte zu einem niedrigen monatlichen Preis unbegrenzt telefonieren und surfen und dabei von Schutz und Kundendienst profitieren.",
        "en": "I wanted unlimited calls and data at a low monthly price, along with security protection and customer support."
      },
      "vorteil": {
        "de": "Angekündigt waren unbegrenztes Datenvolumen und Telefonate innerhalb des Landes, kostenlose SMS, bis zu 5 GB Online-Speicher, Spam- und Virenschutz, kostenloser telefonischer Kundendienst sowie ein Neukundenbonus von 15 Euro.",
        "en": "The advertisement promised unlimited data and domestic calls, free texts, up to 5 GB of online storage, spam and virus protection, free phone support and a 15-euro new-customer bonus."
      },
      "items": [
        {
          "promise": {
            "de": "unbegrenztes Datenvolumen, Telefonate und kostenlose SMS",
            "en": "unlimited data, calls and free texts"
          },
          "complaint": {
            "de": "Obwohl unbegrenztes Datenvolumen, Telefonate und kostenlose SMS versprochen wurden, wurde meine Verbindung begrenzt und es fielen Zusatzkosten an.",
            "en": "Although unlimited data, calls and free texts were promised, my connection was limited and extra charges were added."
          }
        },
        {
          "promise": {
            "de": "bis zu 5 GB Online-Speicher und Spam-/Virenschutz",
            "en": "up to 5 GB online storage and spam/virus protection"
          },
          "complaint": {
            "de": "Der Online-Speicher und der angekündigte Spam- und Virenschutz funktionierten nicht.",
            "en": "The online storage and advertised spam and virus protection did not work."
          }
        },
        {
          "promise": {
            "de": "kostenloser Kundendienst für sämtliche Probleme",
            "en": "free customer service for all problems"
          },
          "complaint": {
            "de": "Der kostenlose Kundendienst war während der angegebenen Zeiten nicht erreichbar.",
            "en": "The free customer service could not be reached during the stated hours."
          }
        },
        {
          "promise": {
            "de": "15 Euro Bonus für Neukunden",
            "en": "15-euro bonus for new customers"
          },
          "complaint": {
            "de": "Der versprochene Neukundenbonus von 15 Euro wurde nicht gutgeschrieben.",
            "en": "The promised 15-euro new-customer bonus was not credited."
          }
        }
      ]
    },
    {
      "id": "20",
      "title": "Test 20 – Erhalt des Spielplatzes vor dem Wohnhaus",
      "page": 20,
      "ziel": {
        "de": "Ich schreibe, weil ich den geplanten Abriss des Spielplatzes verhindern und eine kinderfreundliche Lösung für die Hausgemeinschaft erreichen möchte.",
        "en": "I am writing because I want to prevent the planned playground demolition and find a child-friendly solution for the residents."
      },
      "vorteil": {
        "de": "In diesem Schreiben gibt es keine Anzeige mit Produktversprechen. Die Wohnungsverwaltung teilt mit, dass der Spielplatz am 30. des Monats abgerissen und durch einen Parkplatz ersetzt werden soll.",
        "en": "This task has no advertisement with product promises. The property management says the playground will be demolished on the 30th of the month and replaced by a car park."
      },
      "items": [
        {
          "promise": {
            "de": "Die Verwaltung behauptet, fast alle Mieter bräuchten Parkplätze dringender als den Spielplatz.",
            "en": "Management claims nearly all tenants need parking more urgently than the playground."
          },
          "complaint": {
            "de": "Viele Anwohner brauchen den Parkplatz nicht dringender als den Spielplatz.",
            "en": "Many residents do not need the car park more urgently than the playground."
          }
        },
        {
          "promise": {
            "de": "Die Verwaltung behauptet, nur wenige Familien nutzten den Spielplatz.",
            "en": "Management claims only a few families use the playground."
          },
          "complaint": {
            "de": "Mehr als fünf Familien nutzen den Spielplatz regelmäßig.",
            "en": "More than five families use the playground regularly."
          }
        },
        {
          "promise": {
            "de": "Laut Mitteilung könnten Kinder den Spielplatz in der Masch-Allee nutzen.",
            "en": "The notice says children could use the playground on Masch-Allee."
          },
          "complaint": {
            "de": "Der Spielplatz in der Masch-Allee ist für kleine Kinder nicht sicher und leicht erreichbar.",
            "en": "The playground on Masch-Allee is not safely and easily accessible for young children."
          }
        },
        {
          "promise": {
            "de": "Die Verwaltung kündigt den Beginn der Arbeiten am 30. des Monats an.",
            "en": "Management announces that work will begin on the 30th of the month."
          },
          "complaint": {
            "de": "Der Abriss wurde kurzfristig für den 30. angekündigt, ohne die Anwohner vorher anzuhören.",
            "en": "The demolition was announced at short notice for the 30th without consulting residents beforehand."
          }
        }
      ]
    },
    {
      "id": "21",
      "title": "Test 21 – Sprachaufenthalt in einer Gastfamilie (SZH-Sprachreisen)",
      "page": 21,
      "ziel": {
        "de": "Ich wollte während eines vierwöchigen Aufenthalts Deutsch in einer Gastfamilie lernen und die Sprache im Alltag anwenden.",
        "en": "During a four-week stay, I wanted to learn German with a host family and use the language in everyday life."
      },
      "vorteil": {
        "de": "Beworben wurden ausgewählte Gastfamilien mit mindestens einer Lehrkraft oder Kursleitung, qualifizierte Anleitung, sofortige Übungsmöglichkeiten, organisierte Freizeitgestaltung nach Interessen, Aufenthalte von zwei bis acht Wochen und 20 Prozent Rabatt.",
        "en": "The advertisement promised selected host families with at least one teacher or course leader, qualified instruction, immediate opportunities to practise, leisure activities tailored to interests, stays of two to eight weeks and a 20 percent discount."
      },
      "items": [
        {
          "promise": {
            "de": "Gastfamilien mit mindestens einer Lehrkraft oder Kursleitung",
            "en": "host families with at least one teacher or course leader"
          },
          "complaint": {
            "de": "In meiner Gastfamilie gab es entgegen der Anzeige keine Lehrkraft und keinen Kursleiter.",
            "en": "Contrary to the advertisement, there was no teacher or course leader in my host family."
          }
        },
        {
          "promise": {
            "de": "qualifizierte Anleitung und sofortige Sprachpraxis",
            "en": "qualified guidance and immediate language practice"
          },
          "complaint": {
            "de": "Während des Aufenthalts fand kein strukturierter Sprachunterricht statt.",
            "en": "There were no structured language lessons during the stay."
          }
        },
        {
          "promise": {
            "de": "Freizeitgestaltung passend zu den eigenen Interessen",
            "en": "leisure activities tailored to personal interests"
          },
          "complaint": {
            "de": "Die angekündigte Freizeitgestaltung wurde nicht organisiert und meine Interessen wurden nicht berücksichtigt.",
            "en": "The promised leisure activities were not organised and my interests were not considered."
          }
        },
        {
          "promise": {
            "de": "Aufenthalte von zwei bis acht Wochen und 20 Prozent Rabatt",
            "en": "stays of two to eight weeks and a 20 percent discount"
          },
          "complaint": {
            "de": "Der vereinbarte Rabatt wurde nicht von der Rechnung abgezogen.",
            "en": "The agreed discount was not deducted from the bill."
          }
        }
      ]
    },
    {
      "id": "22",
      "title": "Test 22 – Smartphone-Vertrag der Welt-Tele GmbH",
      "page": 22,
      "ziel": {
        "de": "Ich wollte für einen niedrigen monatlichen Preis sofort unbegrenzt im Internet surfen und telefonieren können.",
        "en": "I wanted to browse the internet and make calls immediately with unlimited data at a low monthly price."
      },
      "vorteil": {
        "de": "Die Anzeige versprach einen Vertrag für 9,98 Euro im Monat plus 4,98 Euro monatliche Zuzahlung, unbegrenztes Datenvolumen und sofortige Einrichtung, damit man sofort telefonieren und surfen kann.",
        "en": "The advertisement promised a plan for 9.98 euros per month plus a 4.98-euro monthly charge, unlimited data and immediate activation so customers could call and browse right away."
      },
      "items": [
        {
          "promise": {
            "de": "Vertrag für 9,98 Euro im Monat plus 4,98 Euro Zuzahlung",
            "en": "plan for 9.98 euros per month plus a 4.98-euro charge"
          },
          "complaint": {
            "de": "Statt der beworbenen Monatskosten wurden mir höhere Beträge abgebucht.",
            "en": "Higher amounts were charged instead of the advertised monthly price."
          }
        },
        {
          "promise": {
            "de": "unbegrenztes Datenvolumen",
            "en": "unlimited data"
          },
          "complaint": {
            "de": "Mein Datenvolumen wurde begrenzt, obwohl es als unbegrenzt beworben wurde.",
            "en": "My data allowance was limited although it was advertised as unlimited."
          }
        },
        {
          "promise": {
            "de": "unbegrenzt im Internet surfen und telefonieren",
            "en": "unlimited internet browsing and calls"
          },
          "complaint": {
            "de": "Ich kann mit dem Vertrag nicht unbegrenzt im Internet surfen und telefonieren.",
            "en": "I cannot browse the internet and make calls without limits under this plan."
          }
        },
        {
          "promise": {
            "de": "sofortige Einrichtung des Vertrags",
            "en": "immediate activation of the plan"
          },
          "complaint": {
            "de": "Der Vertrag wurde auch nach zwei Monaten nicht sofort eingerichtet.",
            "en": "Even after two months, the plan had not been activated immediately."
          }
        }
      ]
    },
    {
      "id": "23",
      "title": "Test 23 – Freizeitbad Meeresrauschen",
      "page": 47,
      "ziel": {
        "de": "Ich wollte mit meiner Familie einen erholsamen Tag im Freizeitbad verbringen.",
        "en": "I wanted to spend a relaxing day at the leisure pool with my family."
      },
      "vorteil": {
        "de": "Die Anzeige versprach ein Erlebnisbad mit Sole-Thermalbad, großzügiger Saunalandschaft und Erlebnisgastronomie.",
        "en": "The advertisement promised a leisure pool with a thermal brine bath, a spacious sauna area and experience dining."
      },
      "items": [
        {
          "promise": {
            "de": "Erlebnisbad mit Thermal-Solebad",
            "en": "leisure pool with thermal brine bath"
          },
          "complaint": {
            "de": "Das Sole-Thermalbad war geschlossen.",
            "en": "The thermal brine bath was closed."
          }
        },
        {
          "promise": {
            "de": "großzügige Saunalandschaft",
            "en": "spacious sauna area"
          },
          "complaint": {
            "de": "Die Saunalandschaft war kleiner als angekündigt und mehrere Bereiche waren gesperrt.",
            "en": "The sauna area was smaller than advertised and several areas were closed."
          }
        },
        {
          "promise": {
            "de": "Erlebnisgastronomie",
            "en": "experience dining"
          },
          "complaint": {
            "de": "In der Erlebnisgastronomie gab es kaum Speisen und Getränke.",
            "en": "There were hardly any food or drinks at the experience restaurant."
          }
        },
        {
          "promise": {
            "de": "Urlaub vom Alltag für die ganze Familie",
            "en": "a break from everyday life for the whole family"
          },
          "complaint": {
            "de": "Das Personal reagierte auf unsere Fragen unfreundlich.",
            "en": "The staff responded rudely to our questions."
          }
        }
      ]
    },
    {
      "id": "24",
      "title": "Test 24 – Baumeister-Betten: Bett und Komfortmatratze",
      "page": 48,
      "ziel": {
        "de": "Ich wollte besser schlafen und ein passendes Bett mit Komfortmatratze zu einem günstigen Preis kaufen.",
        "en": "I wanted to sleep better and buy a suitable bed with a comfort mattress at a good price."
      },
      "vorteil": {
        "de": "Beworben wurden Probeliegen in Showrooms, eine große Auswahl an Betten, Lattenrosten und Matratzen zu Sonderpreisen sowie die Mitnahme der alten Matratze auf Wunsch.",
        "en": "The ad promoted showroom tryouts, a wide selection of beds, slatted frames and mattresses at special prices, and removal of the old mattress on request."
      },
      "items": [
        {
          "promise": {
            "de": "Probeliegen in Showrooms",
            "en": "try out beds in showrooms"
          },
          "complaint": {
            "de": "Die gelieferte Matratze war unbequem und entsprach nicht der angekündigten Komfortqualität.",
            "en": "The delivered mattress was uncomfortable and did not meet the advertised comfort standard."
          }
        },
        {
          "promise": {
            "de": "große Auswahl an Betten und Matratzen",
            "en": "wide choice of beds and mattresses"
          },
          "complaint": {
            "de": "Der beworbene Sonderpreis wurde an der Kasse nicht gewährt.",
            "en": "The advertised special price was not applied at checkout."
          }
        },
        {
          "promise": {
            "de": "Sonderpreise wegen Lagerräumung",
            "en": "special prices due to warehouse clearance"
          },
          "complaint": {
            "de": "Die bestellte Größe war nicht verfügbar, obwohl sie in der Auswahl stand.",
            "en": "The ordered size was unavailable although it was listed among the options."
          }
        },
        {
          "promise": {
            "de": "Mitnahme der alten Matratze auf Wunsch",
            "en": "old mattress removal on request"
          },
          "complaint": {
            "de": "Für die Mitnahme der alten Matratze wurden unerwartete zusätzliche Kosten verlangt.",
            "en": "Unexpected extra charges were demanded for taking away the old mattress."
          }
        }
      ]
    },
    {
      "id": "25",
      "title": "Test 25 – Umzug mit Bühler",
      "page": 46,
      "ziel": {
        "de": "Ich wollte stressfrei in eine andere Stadt umziehen und den Umzug einem zuverlässigen Fachunternehmen überlassen.",
        "en": "I wanted to move to another city without stress and entrust the move to a reliable professional company."
      },
      "vorteil": {
        "de": "Angekündigt waren Ein- und Auspacken, Möbelmontage, Transport durch professionelle Helfer und ein Festpreis.",
        "en": "The ad promised packing and unpacking, furniture assembly, transport by professional movers and a fixed price."
      },
      "items": [
        {
          "promise": {
            "de": "Ein- und Auspacken aller Haushaltsgegenstände",
            "en": "packing and unpacking household items"
          },
          "complaint": {
            "de": "Mehrere Gegenstände wurden trotz des versprochenen Ein- und Auspackservice nicht ausgepackt.",
            "en": "Several items were not unpacked despite the promised packing and unpacking service."
          }
        },
        {
          "promise": {
            "de": "Möbelabbau und -aufbau",
            "en": "disassembly and assembly of furniture"
          },
          "complaint": {
            "de": "Möbel wurden beschädigt, obwohl ein fachgerechter Umzug zugesagt war.",
            "en": "Furniture was damaged despite the promised professional move."
          }
        },
        {
          "promise": {
            "de": "professionelle Umzugshelfer",
            "en": "professional movers"
          },
          "complaint": {
            "de": "Am Ende wurden zusätzliche Kosten berechnet, obwohl ein Festpreis vereinbart war.",
            "en": "Extra costs were charged at the end although a fixed price had been agreed."
          }
        },
        {
          "promise": {
            "de": "alles zum Festpreis",
            "en": "everything at a fixed price"
          },
          "complaint": {
            "de": "Die Umzugshelfer kamen verspätet und arbeiteten nicht sorgfältig.",
            "en": "The movers arrived late and did not work carefully."
          }
        }
      ]
    },
    {
      "id": "26",
      "title": "Test 26 – Umzug mit Feingerber",
      "page": 44,
      "ziel": {
        "de": "Ich wollte meinen Umzug mit fachlicher Unterstützung planen und die Arbeiten zuverlässig erledigen lassen.",
        "en": "I wanted professional help planning my move and the work completed reliably."
      },
      "vorteil": {
        "de": "Die Anzeige nannte Beratung und Besichtigung vor Ort, wahlweise Selbstpacken oder einen stressfreien Packservice, Möbelmontage, Geräteanschluss und Endreinigung.",
        "en": "The ad offered consultation and an on-site visit, a choice between packing yourself or a full packing service, furniture assembly, appliance connection and final cleaning."
      },
      "items": [
        {
          "promise": {
            "de": "Beratung und Besichtigung vor Ort",
            "en": "consultation and on-site inspection"
          },
          "complaint": {
            "de": "Vor dem Umzug fand entgegen der Ankündigung keine Besichtigung statt.",
            "en": "Contrary to the promise, no site visit took place before the move."
          }
        },
        {
          "promise": {
            "de": "Wahl zwischen Selbstpacken und Packservice",
            "en": "choice between packing yourself and a packing service"
          },
          "complaint": {
            "de": "Der gebuchte Packservice wurde nur teilweise durchgeführt.",
            "en": "The booked packing service was only partly carried out."
          }
        },
        {
          "promise": {
            "de": "Möbelmontage und Geräteanschluss",
            "en": "furniture assembly and appliance connection"
          },
          "complaint": {
            "de": "Möbel wurden nicht wie angekündigt auf- und abgebaut.",
            "en": "Furniture was not assembled and disassembled as advertised."
          }
        },
        {
          "promise": {
            "de": "Endreinigung",
            "en": "final cleaning"
          },
          "complaint": {
            "de": "Die Endreinigung und der Anschluss der Geräte fehlten.",
            "en": "The final cleaning and appliance connections were not provided."
          }
        }
      ]
    },
    {
      "id": "27",
      "title": "Test 27 – Versand-Apotheke sanpharma24",
      "page": 42,
      "ziel": {
        "de": "Ich wollte Medikamente und ein Kosmetikprodukt bequem online und ohne Versandkosten bestellen.",
        "en": "I wanted to order medicine and a cosmetic product conveniently online without shipping costs."
      },
      "vorteil": {
        "de": "Angekündigt waren portofreie Bestellungen, Lieferung innerhalb von höchstens drei Werktagen an eine Wunschadresse in Deutschland und Sonderangebote.",
        "en": "The ad promised postage-free orders, delivery within no more than three working days to a chosen address in Germany, and special offers."
      },
      "items": [
        {
          "promise": {
            "de": "bequem online und portofrei bestellen",
            "en": "convenient online orders with no postage"
          },
          "complaint": {
            "de": "Für meine Bestellung wurden Versandkosten berechnet.",
            "en": "Shipping costs were charged for my order."
          }
        },
        {
          "promise": {
            "de": "Lieferung innerhalb von höchstens drei Werktagen",
            "en": "delivery within no more than three working days"
          },
          "complaint": {
            "de": "Die Lieferung kam deutlich später als innerhalb von drei Werktagen an.",
            "en": "The delivery arrived well after the promised three working days."
          }
        },
        {
          "promise": {
            "de": "Lieferung an die Wunschadresse in Deutschland",
            "en": "delivery to a chosen address in Germany"
          },
          "complaint": {
            "de": "Das Paket wurde an eine andere Adresse geliefert.",
            "en": "The package was delivered to a different address."
          }
        },
        {
          "promise": {
            "de": "günstige Sonderangebote",
            "en": "low special offers"
          },
          "complaint": {
            "de": "Der beworbene Sonderpreis wurde nicht berechnet.",
            "en": "The advertised special price was not applied."
          }
        }
      ]
    },
    {
      "id": "28",
      "title": "Test 28 – Fahrrad-Meister: neues Fahrrad",
      "page": 49,
      "ziel": {
        "de": "Ich wollte ein neues Fahrrad für meinen Alltag kaufen und dabei fachkundig beraten werden.",
        "en": "I wanted to buy a new bicycle for everyday use and receive expert advice."
      },
      "vorteil": {
        "de": "Die Anzeige bot eine große Auswahl an Fahrradtypen und Marken, reduzierte Vorjahresmodelle, Zubehör und Reparaturen in der eigenen Werkstatt.",
        "en": "The ad offered a wide choice of bicycle types and brands, discounted previous-year models, accessories and repairs in its own workshop."
      },
      "items": [
        {
          "promise": {
            "de": "große Auswahl an Marken und Fahrradtypen",
            "en": "wide choice of brands and bicycle types"
          },
          "complaint": {
            "de": "Das Fahrrad war mangelhaft und musste kurz nach dem Kauf repariert werden.",
            "en": "The bicycle was defective and needed repair soon after purchase."
          }
        },
        {
          "promise": {
            "de": "reduzierte Vorjahresmodelle",
            "en": "discounted previous-year models"
          },
          "complaint": {
            "de": "Das gekaufte Modell war nicht das reduzierte Vorjahresmodell aus der Anzeige.",
            "en": "The model sold was not the discounted previous-year model described in the ad."
          }
        },
        {
          "promise": {
            "de": "Zubehör für Fahrräder",
            "en": "bicycle accessories"
          },
          "complaint": {
            "de": "Der Verkäufer nahm sich keine Zeit für eine Beratung zur passenden Fahrradart.",
            "en": "The salesperson did not take time to advise me on the right type of bicycle."
          }
        },
        {
          "promise": {
            "de": "Reparaturen in der eigenen Werkstatt",
            "en": "repairs in the company workshop"
          },
          "complaint": {
            "de": "Die Werkstatt konnte den angekündigten Reparaturservice nicht zeitnah anbieten.",
            "en": "The workshop could not provide the advertised repair service promptly."
          }
        }
      ]
    },
    {
      "id": "29",
      "title": "Test 29 – Freizeitverein Mainz",
      "page": 35,
      "ziel": {
        "de": "Ich wollte am Wochenende neue Leute kennenlernen und regelmäßig an abwechslungsreichen Aktivitäten teilnehmen.",
        "en": "I wanted to meet new people at weekends and take part in varied activities regularly."
      },
      "vorteil": {
        "de": "Der Verein versprach mindestens zwei verschiedene Angebote pro Woche, Aktivitäten aus Sport und Kultur sowie Möglichkeiten, neue Leute kennenzulernen.",
        "en": "The club promised at least two different activities a week, sports and cultural events, and opportunities to meet new people."
      },
      "items": [
        {
          "promise": {
            "de": "mindestens zwei verschiedene Angebote pro Woche",
            "en": "at least two different activities per week"
          },
          "complaint": {
            "de": "In meiner ersten Zeit als Mitglied fand kaum eine der angekündigten Aktivitäten statt.",
            "en": "During my first weeks as a member, hardly any of the advertised activities took place."
          }
        },
        {
          "promise": {
            "de": "Sport- und Kulturangebote",
            "en": "sports and cultural activities"
          },
          "complaint": {
            "de": "Es gab nicht wie versprochen mindestens zwei unterschiedliche Angebote pro Woche.",
            "en": "There were not at least two different activities a week as promised."
          }
        },
        {
          "promise": {
            "de": "Wanderungen, Ausflüge und Fahrradtouren",
            "en": "hikes, outings and bicycle tours"
          },
          "complaint": {
            "de": "Die Veranstaltungen waren schlecht organisiert und begannen verspätet.",
            "en": "The events were poorly organised and started late."
          }
        },
        {
          "promise": {
            "de": "neue Leute kennenlernen",
            "en": "meet new people"
          },
          "complaint": {
            "de": "Obwohl neue Kontakte angekündigt waren, wurde ich bei den Treffen kaum einbezogen.",
            "en": "Although opportunities to meet people were advertised, I was hardly included at the events."
          }
        }
      ]
    },
    {
      "id": "30",
      "title": "Test 30 – T&W-Elektronikversicherung",
      "page": 60,
      "ziel": {
        "de": "Ich wollte die Reparatur- oder Ersatzkosten für ein teures Haushaltsgerät absichern.",
        "en": "I wanted to insure the repair or replacement costs of an expensive household appliance."
      },
      "vorteil": {
        "de": "Die Versicherung versprach Schutz für viele Haushaltsgeräte, Erstattung bis zu 3.000 Euro je Gerät, Übernahme von Reparatur- oder Wiederbeschaffungskosten und eine schnelle, unkomplizierte Bearbeitung.",
        "en": "The insurer promised cover for many household devices, reimbursement up to 3,000 euros per device, payment of repair or replacement costs, and quick, straightforward handling."
      },
      "items": [
        {
          "promise": {
            "de": "Schutz für viele Haushaltsgeräte",
            "en": "cover for many household appliances"
          },
          "complaint": {
            "de": "Mein versicherter Schaden wurde trotz vollständiger Unterlagen abgelehnt.",
            "en": "My insured claim was rejected despite complete documentation."
          }
        },
        {
          "promise": {
            "de": "bis zu 3.000 Euro je Gerät",
            "en": "up to 3,000 euros per device"
          },
          "complaint": {
            "de": "Die Bearbeitung dauerte lange, obwohl eine schnelle Regulierung versprochen wurde.",
            "en": "The claim took a long time to process although quick handling was promised."
          }
        },
        {
          "promise": {
            "de": "Übernahme von Reparatur- oder Wiederbeschaffungskosten",
            "en": "payment of repair or replacement costs"
          },
          "complaint": {
            "de": "Die Versicherung erstattete die Reparaturkosten nicht.",
            "en": "The insurer did not reimburse the repair costs."
          }
        },
        {
          "promise": {
            "de": "schnelle und unkomplizierte Regulierung",
            "en": "quick and straightforward claim handling"
          },
          "complaint": {
            "de": "Auf meine telefonische und schriftliche Nachfrage erhielt ich keine klare Auskunft.",
            "en": "I received no clear information after contacting the insurer by phone and in writing."
          }
        }
      ]
    },
    {
      "id": "31",
      "title": "Test 31 – Skiurlaub im Skiclub 2100",
      "page": 64,
      "ziel": {
        "de": "Ich wollte eine günstige Skiwoche mit Unterkunft, Verpflegung und passenden Freizeitangeboten verbringen.",
        "en": "I wanted to spend an affordable ski week with accommodation, meals and suitable leisure activities."
      },
      "vorteil": {
        "de": "Das Angebot versprach ein großes Vierbettzimmer mit Bad und TV, drei Mahlzeiten und Getränke, Skilift, Skischule, Animation sowie Ausflüge.",
        "en": "The offer promised a large four-bed room with bathroom and TV, three meals and drinks, a ski lift, ski school, entertainment and excursions."
      },
      "items": [
        {
          "promise": {
            "de": "großes Vierbettzimmer mit Bad und TV",
            "en": "large four-bed room with bathroom and TV"
          },
          "complaint": {
            "de": "Das Zimmer war klein und hatte weder ein eigenes Bad noch einen Fernseher.",
            "en": "The room was small and had neither a private bathroom nor a television."
          }
        },
        {
          "promise": {
            "de": "drei Mahlzeiten und freie Getränke",
            "en": "three meals and free drinks"
          },
          "complaint": {
            "de": "Die Mahlzeiten waren knapp und die Getränke mussten extra bezahlt werden.",
            "en": "The meals were insufficient and drinks had to be paid for separately."
          }
        },
        {
          "promise": {
            "de": "Skilift und Skischule",
            "en": "ski lift and ski school"
          },
          "complaint": {
            "de": "Die angekündigte Skischule war geschlossen.",
            "en": "The advertised ski school was closed."
          }
        },
        {
          "promise": {
            "de": "Animation und Ausflüge",
            "en": "entertainment and excursions"
          },
          "complaint": {
            "de": "Animation und Ausflüge fanden nicht statt.",
            "en": "The entertainment and excursions did not take place."
          }
        }
      ]
    },
    {
      "id": "32",
      "title": "Test 32 – Wochenendkurs im Baumarkt: Tapezieren und Streichen",
      "page": 66,
      "ziel": {
        "de": "Ich wollte in kurzer Zeit praktische Grundlagen zum Tapezieren und Streichen lernen.",
        "en": "I wanted to learn practical basics of wallpapering and painting in a short time."
      },
      "vorteil": {
        "de": "Angekündigt waren höchstens acht Teilnehmende, praktische Übungen mit Material, Tipps eines erfahrenen Kursleiters und Kenntnisse zu Werkzeug, Vorbereitung und Streichtechniken.",
        "en": "The ad promised no more than eight participants, practical exercises with materials, tips from an experienced instructor, and guidance on tools, preparation and painting techniques."
      },
      "items": [
        {
          "promise": {
            "de": "höchstens acht Teilnehmende",
            "en": "no more than eight participants"
          },
          "complaint": {
            "de": "In der Gruppe waren deutlich mehr als acht Personen.",
            "en": "There were considerably more than eight people in the group."
          }
        },
        {
          "promise": {
            "de": "viele praktische Übungen mit Material",
            "en": "many practical exercises with materials"
          },
          "complaint": {
            "de": "Wir konnten kaum praktisch üben, obwohl praktische Übungen angekündigt waren.",
            "en": "We could hardly practise although hands-on exercises were advertised."
          }
        },
        {
          "promise": {
            "de": "Tipps vom erfahrenen Kursleiter",
            "en": "tips from an experienced instructor"
          },
          "complaint": {
            "de": "Der Kursleiter gab keine hilfreichen Tipps zu Werkzeug und Vorbereitung.",
            "en": "The instructor gave no useful advice on tools and preparation."
          }
        },
        {
          "promise": {
            "de": "Werkzeug, Vorbereitung und Streichtechniken lernen",
            "en": "learn about tools, preparation and painting techniques"
          },
          "complaint": {
            "de": "Die Materialien waren unvollständig und mehrere angekündigte Themen wurden ausgelassen.",
            "en": "The materials were incomplete and several advertised topics were omitted."
          }
        }
      ]
    },
    {
      "id": "33",
      "title": "Test 33 – Octavian-Therme mit Hotel und Frühstück",
      "page": 73,
      "ziel": {
        "de": "Ich wollte ein erholsames Wochenende verbringen und Therme und Hotel bequem miteinander verbinden.",
        "en": "I wanted a relaxing weekend combining a spa visit and a hotel stay."
      },
      "vorteil": {
        "de": "Das Paket versprach zwei Übernachtungen, Tageskarte für die Therme, Frühstücksbuffet, Obst auf dem Zimmer und kostenlosen Parkplatz.",
        "en": "The package promised two nights, a day pass to the spa, a breakfast buffet, fruit in the room and free parking."
      },
      "items": [
        {
          "promise": {
            "de": "zwei Übernachtungen im Hotel",
            "en": "two hotel nights"
          },
          "complaint": {
            "de": "Das Zimmer war nicht komfortabel und bot nicht die angekündigte Ruhe.",
            "en": "The room was not comfortable and did not provide the promised peace and quiet."
          }
        },
        {
          "promise": {
            "de": "Tageskarte für die Therme",
            "en": "day pass to the spa"
          },
          "complaint": {
            "de": "Das Frühstücksbuffet war sehr klein und wurde nicht rechtzeitig aufgefüllt.",
            "en": "The breakfast buffet was very limited and was not replenished in time."
          }
        },
        {
          "promise": {
            "de": "Frühstücksbuffet und frisches Obst im Zimmer",
            "en": "breakfast buffet and fresh fruit in the room"
          },
          "complaint": {
            "de": "Die Tageskarte für die Therme war nicht im Paket enthalten.",
            "en": "The spa day pass was not included in the package."
          }
        },
        {
          "promise": {
            "de": "kostenloser Parkplatz",
            "en": "free parking"
          },
          "complaint": {
            "de": "Für den Parkplatz wurden zusätzliche Gebühren verlangt.",
            "en": "Additional fees were charged for parking."
          }
        }
      ]
    },
    {
      "id": "34",
      "title": "Test 34 – Freizeitpark Märchenland",
      "page": 87,
      "ziel": {
        "de": "Ich wollte mit meiner Familie einen abwechslungsreichen Kurzurlaub mit Übernachtung und Freizeitparkbesuch verbringen.",
        "en": "I wanted to spend a varied short break with my family, including an overnight stay and a theme park visit."
      },
      "vorteil": {
        "de": "Das Angebot versprach eine Übernachtung im Vier-Sterne-Hotel, Frühstücksbuffet und eine Tageskarte mit Shows und Fahrgeschäften.",
        "en": "The offer promised one night in a four-star hotel, a breakfast buffet and a day ticket including shows and rides."
      },
      "items": [
        {
          "promise": {
            "de": "Übernachtung im Vier-Sterne-Hotel",
            "en": "stay in a four-star hotel"
          },
          "complaint": {
            "de": "Das Hotelzimmer entsprach nicht dem angekündigten Vier-Sterne-Standard.",
            "en": "The hotel room did not meet the advertised four-star standard."
          }
        },
        {
          "promise": {
            "de": "Frühstücksbuffet",
            "en": "breakfast buffet"
          },
          "complaint": {
            "de": "Das Frühstücksbuffet war unvollständig und wurde kaum aufgefüllt.",
            "en": "The breakfast buffet was incomplete and was hardly replenished."
          }
        },
        {
          "promise": {
            "de": "Tageskarte für den Freizeitpark",
            "en": "day ticket to the theme park"
          },
          "complaint": {
            "de": "Mehrere Fahrgeschäfte und Shows waren trotz des Tickets geschlossen.",
            "en": "Several rides and shows were closed despite being included in the ticket."
          }
        },
        {
          "promise": {
            "de": "alle Shows und Fahrgeschäfte inklusive",
            "en": "all shows and rides included"
          },
          "complaint": {
            "de": "Die zugesagte Kinderermäßigung wurde bei der Rechnung nicht berücksichtigt.",
            "en": "The promised child discount was not applied to the bill."
          }
        }
      ]
    },
    {
      "id": "35",
      "title": "Test 35 – Bahnreise nach Berlin",
      "page": 100,
      "ziel": {
        "de": "Ich wollte Berlin bequem mit der Bahn entdecken und ein organisiertes Programm genießen.",
        "en": "I wanted to discover Berlin comfortably by train and enjoy an organised itinerary."
      },
      "vorteil": {
        "de": "Die Reise versprach Fahrt erster Klasse mit Schlafsesseln, Snacks und Getränken, zwei Hotelübernachtungen mit Frühstück sowie Stadtrundfahrt und Zoobesuch.",
        "en": "The trip promised first-class train travel with reclining seats, snacks and drinks, two hotel nights with breakfast, a city tour and a zoo visit."
      },
      "items": [
        {
          "promise": {
            "de": "Anreise erster Klasse mit Schlafsesseln",
            "en": "first-class travel with reclining seats"
          },
          "complaint": {
            "de": "Die Fahrt fand nicht in der angekündigten ersten Klasse statt.",
            "en": "The trip was not in the advertised first class."
          }
        },
        {
          "promise": {
            "de": "Getränke und Snacks inklusive",
            "en": "drinks and snacks included"
          },
          "complaint": {
            "de": "Schlafsitze, Snacks oder Getränke fehlten während der Zugfahrt.",
            "en": "Reclining seats, snacks or drinks were missing during the train journey."
          }
        },
        {
          "promise": {
            "de": "zwei Übernachtungen mit Frühstück",
            "en": "two nights with breakfast"
          },
          "complaint": {
            "de": "Das Hotel entsprach nicht der Beschreibung und das Frühstück war mangelhaft.",
            "en": "The hotel did not match its description and the breakfast was poor."
          }
        },
        {
          "promise": {
            "de": "Stadtrundfahrt und Zoobesuch",
            "en": "city tour and zoo visit"
          },
          "complaint": {
            "de": "Stadtrundfahrt oder Zoobesuch fielen aus, obwohl sie im Programm standen.",
            "en": "The city tour or zoo visit was cancelled although it was listed in the itinerary."
          }
        }
      ]
    },
    {
      "id": "36",
      "title": "Test 36 – Pauschalreise: Reisebüro Sonnenschein",
      "page": 55,
      "ziel": {
        "de": "Ich wollte spontan verreisen und eine Pauschalreise mit Hotel, Transfer und Reiseleitung buchen.",
        "en": "I wanted to travel spontaneously and book a package holiday with hotel, transfer and a tour guide."
      },
      "vorteil": {
        "de": "Die Anzeige bot Last-Minute-Reisen, bis zu 50 Prozent Rabatt und Pauschalreisen mit Flug, Hotel, Transfer und Reiseleitung.",
        "en": "The ad offered last-minute holidays, discounts of up to 50 percent, and package trips with flight, hotel, transfer and tour guide."
      },
      "items": [
        {
          "promise": {
            "de": "Last-Minute-Reisen weltweit",
            "en": "last-minute trips worldwide"
          },
          "complaint": {
            "de": "Im Hotel war bei unserer Ankunft kein Zimmer frei.",
            "en": "There was no room available at the hotel when we arrived."
          }
        },
        {
          "promise": {
            "de": "bis zu 50 Prozent Rabatt",
            "en": "discounts of up to 50 percent"
          },
          "complaint": {
            "de": "Der Reiseleiter kümmerte sich nicht um eine Ersatzunterkunft.",
            "en": "The tour guide did not arrange alternative accommodation."
          }
        },
        {
          "promise": {
            "de": "Kreuzfahrten und All-inclusive-Urlaub",
            "en": "cruises and all-inclusive holidays"
          },
          "complaint": {
            "de": "Die versprochene Ermäßigung wurde nicht berücksichtigt.",
            "en": "The promised discount was not applied."
          }
        },
        {
          "promise": {
            "de": "Pauschalreisen mit Flug, Hotel, Transfer und Reiseleitung",
            "en": "package trips with flight, hotel, transfer and tour guide"
          },
          "complaint": {
            "de": "Transfer oder weitere gebuchte Leistungen waren schlecht organisiert.",
            "en": "The transfer or other booked services were poorly organised."
          }
        }
      ]
    },
    {
      "id": "37",
      "title": "Test 37 – Zeitschriften-Abonnentenservice",
      "page": 75,
      "ziel": {
        "de": "Ich wollte regelmäßig eine Zeitschrift erhalten und von bequemer Lieferung sowie einem angekündigten Begrüßungsgeschenk profitieren.",
        "en": "I wanted to receive a magazine regularly and benefit from convenient delivery and the advertised welcome gift."
      },
      "vorteil": {
        "de": "Angekündigt waren über 100 Titel, regelmäßige kostenlose Postlieferung, keine verpasste Ausgabe, eine Lieferunterbrechung auf Wunsch, Preisvorteil gegenüber dem Einzelkauf und ein Begrüßungsgeschenk.",
        "en": "The ad promised over 100 titles, regular free postal delivery, no missed issues, delivery suspension on request, savings compared with individual purchases and a welcome gift."
      },
      "items": [
        {
          "promise": {
            "de": "über 100 Zeitschriftentitel",
            "en": "over 100 magazine titles"
          },
          "complaint": {
            "de": "Mehrere Ausgaben kamen verspätet oder gar nicht an.",
            "en": "Several issues arrived late or did not arrive at all."
          }
        },
        {
          "promise": {
            "de": "kostenlose regelmäßige Postlieferung",
            "en": "free regular postal delivery"
          },
          "complaint": {
            "de": "Trotz kostenloser Lieferung wurden mir Versandkosten berechnet.",
            "en": "I was charged postage despite the promise of free delivery."
          }
        },
        {
          "promise": {
            "de": "keine verpasste Ausgabe und Lieferunterbrechung auf Wunsch",
            "en": "no missed issues and delivery suspension on request"
          },
          "complaint": {
            "de": "Der abgebuchte Betrag war höher als der angekündigte Abonnementpreis.",
            "en": "The amount debited was higher than the advertised subscription price."
          }
        },
        {
          "promise": {
            "de": "Preisvorteil und Begrüßungsgeschenk",
            "en": "price advantage and welcome gift"
          },
          "complaint": {
            "de": "Das versprochene Begrüßungsgeschenk wurde nicht mitgeschickt.",
            "en": "The promised welcome gift was not sent."
          }
        }
      ]
    },
    {
      "id": "38",
      "title": "Test 38 – Partyservice Francke",
      "page": 79,
      "ziel": {
        "de": "Ich wollte für eine wichtige Familienfeier das Essen und den Service zuverlässig organisieren lassen.",
        "en": "I wanted to arrange food and service reliably for an important family celebration."
      },
      "vorteil": {
        "de": "Angekündigt waren Essen und Getränke nach Wunsch, zuverlässiger professioneller Service, verschiedene Buffets, Geschirrverleih, Servicepersonal und Dekoration für Veranstaltungen bis zu 150 Personen.",
        "en": "The ad promised food and drinks to order, reliable professional service, different buffets, tableware rental, serving staff and decorations for events of up to 150 people."
      },
      "items": [
        {
          "promise": {
            "de": "Essen und Getränke nach Wunsch",
            "en": "food and drinks to order"
          },
          "complaint": {
            "de": "Das Essen kam verspätet und war nicht mehr warm.",
            "en": "The food arrived late and was no longer warm."
          }
        },
        {
          "promise": {
            "de": "zuverlässiger professioneller Service",
            "en": "reliable professional service"
          },
          "complaint": {
            "de": "Das bestellte Buffet entsprach nicht der vereinbarten Auswahl.",
            "en": "The buffet did not match the agreed selection."
          }
        },
        {
          "promise": {
            "de": "Buffets, Geschirrverleih und Servicepersonal",
            "en": "buffets, tableware rental and serving staff"
          },
          "complaint": {
            "de": "Das angekündigte Geschirr oder Servicepersonal fehlte.",
            "en": "The promised tableware or serving staff were missing."
          }
        },
        {
          "promise": {
            "de": "Raum- und Tischdekoration für bis zu 150 Personen",
            "en": "room and table decorations for up to 150 people"
          },
          "complaint": {
            "de": "Die Dekoration und der Aufbau wurden nicht wie vereinbart erledigt.",
            "en": "The decorations and setup were not completed as agreed."
          }
        }
      ]
    },
    {
      "id": "39",
      "title": "Test 39 – Seminar Badrenovierung: Baumarkt Haus- und Heim",
      "page": 96,
      "ziel": {
        "de": "Ich wollte mein Badezimmer selbst renovieren und dafür fachliche Anleitung sowie praktische Tipps erhalten.",
        "en": "I wanted to renovate my bathroom myself and receive professional guidance and practical advice."
      },
      "vorteil": {
        "de": "Das Seminar versprach Informationen von Profis, eine gemeinsam erstellte Bauzeichnung, praktische Übungen, Übungsmaterial und Komplettverpflegung an zwei Tagen.",
        "en": "The seminar promised expert information, a jointly prepared building plan, practical exercises, practice materials and full catering over two days."
      },
      "items": [
        {
          "promise": {
            "de": "Informationen von Fachleuten",
            "en": "information from professionals"
          },
          "complaint": {
            "de": "Der Seminarleiter erklärte die Materialien nicht verständlich.",
            "en": "The instructor did not explain the materials clearly."
          }
        },
        {
          "promise": {
            "de": "Bauzeichnung nach eigenen Wünschen",
            "en": "building plan tailored to your wishes"
          },
          "complaint": {
            "de": "Die versprochenen praktischen Übungen fanden kaum statt.",
            "en": "The promised practical exercises hardly took place."
          }
        },
        {
          "promise": {
            "de": "praktische Tipps und Übungen Schritt für Schritt",
            "en": "practical advice and step-by-step exercises"
          },
          "complaint": {
            "de": "Es wurde keine Bauzeichnung nach meinen Wünschen erstellt.",
            "en": "No building plan was prepared according to my wishes."
          }
        },
        {
          "promise": {
            "de": "Übungsmaterial und Komplettverpflegung",
            "en": "practice materials and full catering"
          },
          "complaint": {
            "de": "Übungsmaterial oder Verpflegung fehlten trotz Ankündigung.",
            "en": "Practice materials or meals were missing despite being advertised."
          }
        }
      ]
    },
    {
      "id": "40",
      "title": "Test 40 – Gemeinschaftsgarten am Wohnhaus",
      "page": 81,
      "ziel": {
        "de": "Ich wollte den Gemeinschaftsgarten weiter nutzen und den Nachbarn einen Ort zum Treffen und Grillen erhalten.",
        "en": "I wanted to keep using the shared garden and preserve a place for neighbours to meet and barbecue."
      },
      "vorteil": {
        "de": "Im Schreiben kündigt die Wohnungsverwaltung an, den Garten zu schließen und stattdessen einen kostenpflichtigen Parkplatz zu bauen.",
        "en": "The housing management’s letter announces that the garden will be closed and replaced by a paid car park."
      },
      "items": [
        {
          "promise": {
            "de": "Der Gemeinschaftsgarten wird von Mietern genutzt.",
            "en": "The shared garden is used by tenants."
          },
          "complaint": {
            "de": "Ich bin gegen die Schließung, weil viele Mieter den Garten regelmäßig nutzen.",
            "en": "I oppose the closure because many tenants use the garden regularly."
          }
        },
        {
          "promise": {
            "de": "Die Verwaltung begründet die Schließung mit geringer Nutzung.",
            "en": "Management justifies the closure by saying it is rarely used."
          },
          "complaint": {
            "de": "Ein kostenpflichtiger Parkplatz ist kein gleichwertiger Ersatz für den Gemeinschaftsgarten.",
            "en": "A paid car park is not an equivalent replacement for the shared garden."
          }
        },
        {
          "promise": {
            "de": "Statt des Gartens soll ein Parkplatz entstehen.",
            "en": "A car park is planned in place of the garden."
          },
          "complaint": {
            "de": "Die Verwaltung sollte den Müll nach dem Grillen besser organisieren, statt den Garten zu schließen.",
            "en": "Management should organise rubbish disposal after barbecues better instead of closing the garden."
          }
        },
        {
          "promise": {
            "de": "Der neue Parkplatz soll monatlich 60 Euro kosten.",
            "en": "The new car park is to cost 60 euros per month."
          },
          "complaint": {
            "de": "Ich bitte darum, den Beschluss zu überdenken und gemeinsam eine bessere Lösung zu finden.",
            "en": "I ask you to reconsider the decision and find a better solution together."
          }
        }
      ]
    }
  ],
  "2": [
    {
      "id": "1",
      "title": "Test 1 – So verwendest du die Bausteine & B2-Briefvorlage",
      "type": "guide",
      "guide_de": "In deiner Vorlage passt das Ziel in den Satz „Ich habe mich dafür entschieden, weil ich mir davon … versprochen hatte.“ Ergänze danach einen konkreten Vorteil aus der Anzeige. Bei einer Beschwerde nimmst du den positiven Anzeigensatz und drehst ihn direkt um. Passe Zahlen, Zeiten und persönliche Umstände an die Aufgabe an.",
      "guide_en": "In your template, the goal fits into the sentence “I chose this because I expected … from it.” Then add one concrete advantage from the ad. For a complaint, take the positive ad statement and turn it around directly. Adapt numbers, times and personal details to the task.",
      "note_de": "Die Beschwerden sind plausible Beispielideen zum Üben, keine Tatsachen aus den Anzeigen. Beim Spielplatz (20) und beim Gemeinschaftsgarten (40) gibt es keine Anzeige; dort steht eine Aussage aus dem Schreiben.",
      "template_sections": [
        {
          "num": 1,
          "heading": "Einleitung & Anlass (Grund des Schreibens)",
          "de": "Sehr geehrte Damen und Herren,\n\nhiermit möchte ich mich über [Angebot / Kurs / Aufenthalt] beschweren. Ich habe mich für Ihr Angebot entschieden, weil ich mir davon [Ziel einsetzen] versprochen hatte.",
          "en": "Dear Sir or Madam,\n\nI am writing to complain about [offer / course / stay]. I chose your offer because I expected [insert goal] from it.",
          "question": "Welcher Konnektor leitet im Einleitungssatz das persönliche Ziel grammatikalisch korrekt ein?",
          "options": {
            "a": "weil ich mir davon … versprochen hatte (Nebensatz mit Verb am Ende)",
            "b": "denn ich mir davon … versprochen hatte (Hauptsatz mit Verb am Ende)",
            "c": "trotzdem ich mir davon … versprochen hatte"
          },
          "answer": "a",
          "explanation": "Nach der Konjunktion ‚weil‘ steht das konjugierte Hilfsverb (‚hatte‘) am Satzende."
        },
        {
          "num": 2,
          "heading": "Vorteil aus der Anzeige nennen",
          "de": "In Ihrer Anzeige wurden insbesondere [Vorteil aus der Anzeige einsetzen] hervorgehoben. Leider entsprach die Realität überhaupt nicht Ihren Versprechungen.",
          "en": "Your advertisement particularly highlighted [insert advantage from the ad]. Unfortunately, reality did not match your promises at all.",
          "question": "Wie verbindet man das Werbeversprechen elegant mit der Kritik auf B2-Niveau?",
          "options": {
            "a": "In Ihrer Anzeige wurde … versprochen. Leider entsprach die Realität nicht Ihren Angaben.",
            "b": "Ihre Anzeige war falsch und alles war schlecht.",
            "c": "Weil die Anzeige gut war, obwohl es schlecht war."
          },
          "answer": "a",
          "explanation": "Sachlicher, formeller Nominal- und Passivstil (‚wurde … versprochen‘, ‚entsprach nicht Ihren Angaben‘) bringt in der telc B2-Prüfung volle Punktzahl."
        },
        {
          "num": 3,
          "heading": "Hauptteil: Vier Beschwerdepunkte verknüpfen",
          "de": "Erstens bestand [Beschwerde 1]. Zweitens [Beschwerde 2]. Darüber hinaus musste ich feststellen, dass [Beschwerde 3]. Erschwerend kam hinzu, dass [Beschwerde 4].",
          "en": "First, [Complaint 1]. Second, [Complaint 2]. Furthermore, I had to realize that [Complaint 3]. To make matters worse, [Complaint 4].",
          "question": "Welche Redemittel strukturieren mehrere Kritikpunkte im Beschwerdebrief besonders klar?",
          "options": {
            "a": "Erstens … / Zweitens … / Darüber hinaus musste ich feststellen, dass … / Erschwerend kam hinzu, dass …",
            "b": "Und dann … / Und auch … / Und noch etwas …",
            "c": "Trotzdem … / Deshalb … / Folglich …"
          },
          "answer": "a",
          "explanation": "Abwechslungsreiche Aufzählungs- und steigernde Konnektoren (‚Darüber hinaus‘, ‚Erschwerend kam hinzu‘) zeigen sicheren B2-Ausdruck."
        },
        {
          "num": 4,
          "heading": "Schluss: Forderung & Fristsetzung",
          "de": "Aus diesen Gründen fordere ich Sie auf, mir einen Teil der Kosten zurückzuerstatten. Ich sehe Ihrer schriftlichen Stellungnahme innerhalb von 14 Tagen entgegen.\n\nMit freundlichen Grüßen",
          "en": "For these reasons, I request a partial refund of the costs. I look forward to your written response within 14 days.\n\nSincerely",
          "question": "Was gehört zwingend in den Schlussteil eines formellen telc B2-Beschwerdebriefs?",
          "options": {
            "a": "Eine konkrete Forderung (z. B. Rückerstattung/Entschädigung) sowie eine höfliche Bitte um Rückmeldung mit Grußformel",
            "b": "Nur der Vorname und die Telefonnummer ohne Grußformel",
            "c": "Eine Wiederholung aller Sätze aus der Einleitung"
          },
          "answer": "a",
          "explanation": "Ein formeller Beschwerdebrief schließt immer mit einer nachvollziehbaren Forderung, der Bitte um Stellungnahme und der Grußformel ‚Mit freundlichen Grüßen‘."
        }
      ]
    },
    {
      "id": "2",
      "title": "Test 2 – Master Prompt zum Wiederverwenden",
      "type": "master",
      "master_lines": [
        "Master Prompt zum Wiederverwenden",
        "Kopiere den folgenden Prompt und füge das gewünschte Thema oder PDF hinzu:",
        "MASTER PROMPT: TELC B2 BESCHWERDE-STUDY GUIDE",
        "Use the supplied PDF as the source and inspect every page from beginning to end. Identify every distinct TELC B2",
        "complaint-letter task (Beschwerde); do not stop at search snippets or sample pages. Record source page numbers so",
        "the coverage can be checked. Exclude applications, information requests and other letter types unless the task itself is a",
        "complaint.",
        "For each complaint topic, create exactly these three sections:",
        "1. Ziel - explain what the writer hoped to achieve by choosing the offer or, for a complaint without an advertisement, why",
        "the writer objects. Write one natural B1-B2 German sentence and an accurate English translation.",
        "2. Vorteil aus der Anzeige - state only benefits or promises actually printed in that topic's advertisement. If there is no",
        "advertisement, explicitly say so and summarize the relevant notice without presenting it as an advertised advantage.",
        "Write German and English.",
        "3. Vier mögliche Beschwerden - give exactly four distinct, realistic example complaint points. For each point, first quote or",
        "closely paraphrase one specific positive benefit or promise from the advertisement, then directly turn that promise into",
        "the matching problem. Show the pair clearly as \"Ankündigung/Versprechen -> mögliche Beschwerde\". Keep each",
        "complaint easy to adapt to a B1-B2 letter template. Write the promise and complaint in German and provide an accurate",
        "English translation for both. Clearly label the complaint as an example idea, not as a fact stated in the advertisement.",
        "Keep each topic specific to its own source advertisement. Do not invent advertised benefits, guarantees, prices or",
        "conditions. Make each complaint the direct negative counterpart of the benefit paired with it, so the learner can choose a",
        "promise and immediately write the related problem. Use natural, exam-appropriate B1-B2 German, preferably short full",
        "sentences or reusable sentence chunks. Do not write long model letters. If a complaint task has no advertisement,",
        "explain this and pair relevant statements from the notice with a reasonable objection instead; do not pretend they are",
        "advertised benefits.",
        "Organize the material with a consistent heading and compact, easy-to-revise layout for each topic. Add a short guide",
        "explaining where to insert the Ziel, one relevant advertised advantage and selected complaints in the learner's existing",
        "template. Identify the source PDF. Include this complete master prompt at the end of the PDF and also provide it",
        "separately. Before delivering, verify that all complaint tasks in the full source are represented, that each topic has exactly",
        "the three requested sections and four complaint ideas, and that every German item has an English translation."
      ],
      "template_sections": [
        {
          "num": 1,
          "heading": "Abschnitt 1 im Master-Prompt: Ziel (Goal)",
          "de": "Erklärt in einem natürlichen B1–B2-Satz (Deutsch + Englisch), was die schreibende Person mit dem Angebot erreichen wollte.",
          "en": "Explains in one natural B1–B2 sentence (German + English) what the writer hoped to achieve by choosing the offer.",
          "question": "Welche Funktion erfüllt Abschnitt 1 (‚Ziel‘) in jedem der 40 Beschwerde-Themen?",
          "options": {
            "a": "Er formuliert die persönliche Erwartung bzw. das Ziel der buchenden Person auf Deutsch und Englisch",
            "b": "Er listet nur Preise aus dem Katalog auf",
            "c": "Er enthält die Unterschrift des Prüfers"
          },
          "answer": "a",
          "explanation": "Das ‚Ziel‘ beantwortet die Frage, warum man sich ursprünglich für das Angebot entschieden hat."
        },
        {
          "num": 2,
          "heading": "Abschnitt 2 im Master-Prompt: Vorteil aus der Anzeige",
          "de": "Nennt ausschließlich Vorteile und Versprechen, die tatsächlich im jeweiligen Anzeigentext stehen (Deutsch + Englisch).",
          "en": "States only benefits or promises actually printed in that topic's advertisement (German + English).",
          "question": "Worauf achtet Abschnitt 2 (‚Vorteil aus der Anzeige‘) laut Master-Prompt besonders?",
          "options": {
            "a": "Es werden nur tatsächlich in der Vorlage genannte Vorteile zusammengefasst, ohne eigene Fakten zu erfinden",
            "b": "Man erfindet beliebige Preise und Garantien",
            "c": "Man lässt die englische Übersetzung weg"
          },
          "answer": "a",
          "explanation": "Der Vorteil bezieht sich exakt auf die Angaben der jeweiligen Prüfungsanzeige."
        },
        {
          "num": 3,
          "heading": "Abschnitt 3 im Master-Prompt: Vier mögliche Beschwerden",
          "de": "Jeder der 4 Punkte stellt einem konkreten Versprechen aus der Anzeige direkt das passende Problem gegenüber (Ankündigung/Versprechen → mögliche Beschwerde).",
          "en": "Each of the 4 points pairs one specific promise from the ad directly with the matching problem (Promise → Possible Complaint).",
          "question": "Wie werden die vier Beschwerdepunkte im Study Guide gebildet?",
          "options": {
            "a": "Jedes positive Versprechen aus der Anzeige wird direkt in das passende Gegenproblem umgewandelt",
            "b": "Es werden vier identische Sätze wiederholt",
            "c": "Es werden nur Stichwörter ohne Verben notiert"
          },
          "answer": "a",
          "explanation": "Durch das Prinzip ‚Ankündigung → Gegenproblem‘ kann man in der Prüfung zu jedem Leitpunkt sofort einen fehlerfreien Satz bilden."
        }
      ]
    }
  ]
};
