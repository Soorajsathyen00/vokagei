const VOKAGEI_STORAGE_KEY = "vokagei_progress_v1";

const VokageiProgress = (() => {
  let state = {};
  try {
    const raw = localStorage.getItem(VOKAGEI_STORAGE_KEY);
    if (raw) state = JSON.parse(raw) || {};
  } catch (e) {
    state = {};
  }

  let currentUser = null;
  let googleClientId = "";
  let syncTimer = null;
  let authDialog = null;
  let gsiLoaded = false;

  function save() {
    try {
      localStorage.setItem(VOKAGEI_STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      // ignore storage quota errors
    }
  }

  function scheduleCloudSync() {
    if (!currentUser || location.protocol === "file:") return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(async () => {
      try {
        await fetch("/api/progress", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ progress: state }),
        });
      } catch {
        // ignore offline sync errors
      }
    }, 450);
  }

  function mergeRemoteProgress(remote) {
    if (!remote || typeof remote !== "object") return false;
    let changed = false;
    for (const [k, rem] of Object.entries(remote)) {
      if (!rem || typeof rem !== "object") continue;
      const loc = state[k];
      const remAns = rem.answered ?? Object.keys(rem.answers || {}).length;
      const locAns = loc ? (loc.answered ?? Object.keys(loc.answers || {}).length) : -1;
      if (!loc || remAns > locAns || (remAns === locAns && rem.graded && !loc.graded)) {
        state[k] = rem;
        changed = true;
      }
    }
    if (changed) {
      save();
      window.dispatchEvent(new Event("storage"));
    }
    return changed;
  }

  function testKey(moduleName, part, id) {
    return `${moduleName}:teil-${part}/${id}`;
  }

  function getDraft(moduleName, part, id) {
    const key = testKey(moduleName, part, id);
    const saved = state[key];
    const answers = new Map();
    if (saved && saved.answers && typeof saved.answers === "object") {
      for (const [k, v] of Object.entries(saved.answers)) {
        answers.set(Number.isNaN(Number(k)) ? k : Number(k), v);
      }
    }
    return {
      answers,
      graded: Boolean(saved?.graded),
      noteText: saved?.noteText ?? "",
    };
  }

  function saveDraft(moduleName, part, id, draft, totalQuestions) {
    const key = testKey(moduleName, part, id);
    const answersObj = {};
    for (const [k, v] of draft.answers.entries()) {
      if (v !== undefined && v !== "") answersObj[k] = v;
    }
    const answeredCount = Object.keys(answersObj).length;
    state[key] = {
      answers: answersObj,
      graded: Boolean(draft.graded),
      noteText: draft.noteText ?? "",
      answered: answeredCount,
      total: totalQuestions,
    };
    save();
    scheduleCloudSync();
  }

  function clearDraft(moduleName, part, id) {
    const key = testKey(moduleName, part, id);
    delete state[key];
    save();
    scheduleCloudSync();
  }

  function getTestProgressPercent(moduleName, part, id, totalQuestions) {
    const key = testKey(moduleName, part, id);
    const saved = state[key];
    if (!saved || !totalQuestions) return 0;
    const answered = saved.answered ?? Object.keys(saved.answers || {}).length;
    return Math.min(100, Math.round((answered / totalQuestions) * 100));
  }

  function getPartProgressPercent(moduleName, part, topics, getTopicQuestionCount) {
    if (!topics || !topics.length) return 0;
    let totalQ = 0;
    let answeredQ = 0;
    for (const topic of topics) {
      const qCount = getTopicQuestionCount(topic);
      totalQ += qCount;
      const saved = state[testKey(moduleName, part, topic.id)];
      if (saved) {
        const ans = saved.answered ?? Object.keys(saved.answers || {}).length;
        answeredQ += Math.min(qCount, ans);
      }
    }
    if (!totalQ) return 0;
    if (answeredQ === 0) return 0;
    if (answeredQ >= totalQ) return 100;
    return Math.max(4, Math.round((answeredQ / totalQ) * 100));
  }

  function getModuleSummary(moduleName, totalTestsFallback) {
    const prefix = `${moduleName}:`;
    let completedTests = 0;
    let startedTests = 0;
    let answeredTotal = 0;
    for (const [k, v] of Object.entries(state)) {
      if (k.startsWith(prefix) && v) {
        const ans = v.answered ?? Object.keys(v.answers || {}).length;
        const tot = v.total || 1;
        if (ans > 0) {
          startedTests += 1;
          answeredTotal += ans;
        }
        if (ans >= tot && tot > 0) {
          completedTests += 1;
        }
      }
    }
    let percent = 0;
    if (totalTestsFallback > 0) {
      if (completedTests >= totalTestsFallback) {
        percent = 100;
      } else if (completedTests > 0 || startedTests > 0) {
        const effective = completedTests + (startedTests - completedTests) * 0.5;
        percent = Math.min(99, Math.max(6, Math.round((effective / totalTestsFallback) * 100)));
      }
    }
    return { completedTests, startedTests, answeredTotal, totalTests: totalTestsFallback, percent };
  }

  function syncStickyOffsets() {
    const page = document.querySelector(".reading-page") || document.documentElement;
    const header = document.querySelector(".site-header");
    const partsBar = document.querySelector(".reading-parts");
    const heading = document.querySelector(".exercise-heading");
    if (header) {
      page.style.setProperty("--sticky-nav-h", `${Math.ceil(header.getBoundingClientRect().height)}px`);
    }
    if (partsBar && partsBar.offsetParent !== null) {
      page.style.setProperty("--sticky-parts-h", `${Math.ceil(partsBar.getBoundingClientRect().height)}px`);
    } else {
      page.style.setProperty("--sticky-parts-h", "0px");
    }
    if (heading) {
      page.style.setProperty("--sticky-heading-h", `${Math.ceil(heading.getBoundingClientRect().height)}px`);
    }
  }

  function initStickyObserver() {
    syncStickyOffsets();
    window.addEventListener("resize", syncStickyOffsets);
    window.addEventListener("load", syncStickyOffsets);
    if (typeof ResizeObserver !== "undefined") {
      const ro = new ResizeObserver(syncStickyOffsets);
      const header = document.querySelector(".site-header");
      const partsBar = document.querySelector(".reading-parts");
      if (header) ro.observe(header);
      if (partsBar) ro.observe(partsBar);
    }
    const ex = document.querySelector("#reading-exercise");
    if (ex && typeof MutationObserver !== "undefined") {
      const mo = new MutationObserver(() => requestAnimationFrame(syncStickyOffsets));
      mo.observe(ex, { childList: true });
    }
  }

  function initMobileNav() {
    const header = document.querySelector(".site-header");
    const toggle = document.querySelector(".menu-toggle");
    const nav = document.querySelector("#main-nav");
    if (!header || !toggle || !nav) return;

    function closeMenu() {
      header.classList.remove("nav-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Menü öffnen");
    }

    toggle.addEventListener("click", () => {
      const isOpen = header.classList.toggle("nav-open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      toggle.setAttribute("aria-label", isOpen ? "Menü schließen" : "Menü öffnen");
    });

    nav.addEventListener("click", (e) => {
      if (e.target.closest("a, button")) closeMenu();
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && header.classList.contains("nav-open")) closeMenu();
    });

    window.addEventListener("resize", () => {
      if (window.innerWidth > 768 && header.classList.contains("nav-open")) closeMenu();
    });
  }

  function updateAuthButtons() {
    document.querySelectorAll("[data-auth-btn], [data-feature='login']").forEach((btn) => {
      btn.replaceChildren();
      if (currentUser) {
        btn.classList.add("auth-user-btn");
        if (currentUser.picture) {
          const img = document.createElement("img");
          img.src = currentUser.picture;
          img.alt = "";
          img.className = "auth-avatar";
          img.referrerPolicy = "no-referrer";
          btn.append(img);
        }
        const firstName = (currentUser.name || currentUser.email || "Konto").split(" ")[0];
        const span = document.createElement("span");
        span.textContent = firstName;
        btn.append(span);
      } else {
        btn.classList.remove("auth-user-btn");
        btn.textContent = "Login";
      }
    });
  }

  function loadGoogleGsiScript() {
    if (gsiLoaded || document.querySelector('script[src*="accounts.google.com/gsi/client"]')) {
      return Promise.resolve();
    }
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://accounts.google.com/gsi/client";
      s.async = true;
      s.defer = true;
      s.onload = () => { gsiLoaded = true; resolve(); };
      s.onerror = () => reject(new Error("Google Sign-In konnte nicht geladen werden."));
      document.head.append(s);
    });
  }

  async function syncAfterLogin() {
    try {
      const res = await fetch("/api/progress");
      if (res.ok) {
        const data = await res.json();
        mergeRemoteProgress(data.progress);
        await fetch("/api/progress", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ progress: state }),
        });
      }
    } catch {
      // ignore
    }
  }

  function ensureAuthDialog() {
    if (authDialog) return authDialog;
    authDialog = document.createElement("dialog");
    authDialog.className = "feature-dialog auth-dialog";
    authDialog.setAttribute("aria-labelledby", "auth-dialog-title");
    authDialog.innerHTML = `
      <div class="auth-dialog-head">
        <h2 id="auth-dialog-title">Konto &amp; Synchronisierung</h2>
        <button type="button" class="auth-close-x" aria-label="Schließen">×</button>
      </div>
      <div id="auth-dialog-body"></div>
    `;
    document.body.append(authDialog);
    authDialog.querySelector(".auth-close-x").addEventListener("click", () => authDialog.close());
    authDialog.addEventListener("click", (e) => { if (e.target === authDialog) authDialog.close(); });
    return authDialog;
  }

  async function renderAuthDialogBody() {
    const dlg = ensureAuthDialog();
    const body = dlg.querySelector("#auth-dialog-body");
    body.replaceChildren();

    if (currentUser) {
      const profile = document.createElement("div");
      profile.className = "auth-profile";
      if (currentUser.picture) {
        const img = document.createElement("img");
        img.src = currentUser.picture;
        img.alt = "";
        img.className = "auth-profile-pic";
        img.referrerPolicy = "no-referrer";
        profile.append(img);
      }
      const info = document.createElement("div");
      const nameEl = document.createElement("strong");
      nameEl.textContent = currentUser.name;
      const emailEl = document.createElement("p");
      emailEl.textContent = currentUser.email;
      emailEl.className = "auth-email";
      info.append(nameEl, emailEl);
      profile.append(info);

      const note = document.createElement("p");
      note.className = "auth-status";
      note.textContent = "Dein Lernfortschritt wird automatisch mit deinem Google-Konto synchronisiert.";

      const signOutBtn = document.createElement("button");
      signOutBtn.type = "button";
      signOutBtn.className = "dialog-close auth-signout";
      signOutBtn.textContent = "Abmelden";
      signOutBtn.addEventListener("click", async () => {
        try { await fetch("/api/auth/logout", { method: "POST" }); } catch {}
        currentUser = null;
        updateAuthButtons();
        dlg.close();
      });

      body.append(profile, note, signOutBtn);
      return;
    }

    const intro = document.createElement("p");
    intro.textContent = "Melde dich mit Google an, um deinen Lernfortschritt auf allen Geräten zu speichern.";
    body.append(intro);

    if (location.protocol === "file:" || !googleClientId) {
      const warn = document.createElement("p");
      warn.className = "auth-status";
      warn.textContent = location.protocol === "file:"
        ? "Google-Anmeldung ist aktiv, sobald die Seite über deine Cloudflare-URL (https://*.workers.dev) geöffnet wird. Lokal wird dein Fortschritt im Browser gespeichert."
        : "Google-Anmeldung ist bereit: Hinterlege deine GOOGLE_CLIENT_ID in wrangler.jsonc, um den Button zu aktivieren.";
      body.append(warn);
      return;
    }

    const btnHost = document.createElement("div");
    btnHost.className = "auth-google-wrap";
    const statusEl = document.createElement("p");
    statusEl.className = "auth-status";
    body.append(btnHost, statusEl);

    try {
      await loadGoogleGsiScript();
      if (window.google?.accounts?.id) {
        window.google.accounts.id.initialize({
          client_id: googleClientId,
          callback: async (response) => {
            statusEl.textContent = "Anmeldung läuft …";
            try {
              const res = await fetch("/api/auth/google", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ credential: response.credential }),
              });
              const data = await res.json();
              if (!res.ok) throw new Error(data.error || "Anmeldung fehlgeschlagen.");
              currentUser = data.user;
              updateAuthButtons();
              await syncAfterLogin();
              renderAuthDialogBody();
            } catch (err) {
              statusEl.textContent = err.message || "Fehler bei der Anmeldung.";
            }
          },
        });
        window.google.accounts.id.renderButton(btnHost, {
          theme: "outline",
          size: "large",
          text: "signin_with",
          shape: "pill",
          width: 280,
          locale: "de",
        });
      }
    } catch (err) {
      statusEl.textContent = err.message;
    }
  }

  function openAuthDialog() {
    const dlg = ensureAuthDialog();
    renderAuthDialogBody();
    dlg.showModal();
  }

  async function initAuth() {
    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-auth-btn], [data-feature='login']");
      if (!btn) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      openAuthDialog();
    }, true);

    if (location.protocol === "file:") {
      updateAuthButtons();
      return;
    }

    try {
      const [cfgRes, meRes] = await Promise.all([fetch("/api/config"), fetch("/api/auth/me")]);
      if (cfgRes.ok) {
        const cfg = await cfgRes.json();
        googleClientId = cfg.googleClientId || "";
      }
      if (meRes.ok) {
        const me = await meRes.json();
        currentUser = me.user || null;
      }
      updateAuthButtons();
      if (currentUser) {
        await syncAfterLogin();
      }
    } catch {
      updateAuthButtons();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      initStickyObserver();
      initMobileNav();
      initAuth();
    });
  } else {
    initStickyObserver();
    initMobileNav();
    initAuth();
  }

  return {
    getDraft,
    saveDraft,
    clearDraft,
    getTestProgressPercent,
    getPartProgressPercent,
    getModuleSummary,
    syncStickyOffsets,
    openAuthDialog,
  };
})();
