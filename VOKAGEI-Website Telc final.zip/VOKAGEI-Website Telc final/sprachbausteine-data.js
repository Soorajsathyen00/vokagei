const sprachbausteineData = {
  "1": [
    {
      "id": "1",
      "num": "1",
      "page": 355,
      "isVariant": false,
      "title": "Deutschkurs in Leipzig (Frau Szabo)",
      "category": "Formeller Brief / Sprachschule",
      "text": "Sehr geehrte Frau Szabo,\n\nvielen Dank für Ihr Interesse {{21}} unseren Deutschkursen. Anbei erhalten Sie das angeforderte Anmeldeformular, das Sie bitte ausgefüllt an uns zurückschicken.\n\nMit der Anmeldung überweisen Sie bitte eine Anzahlung {{22}} von € 200,– auf unser Konto. Die Kontoverbindung finden Sie unten auf dem Anmeldeformular. {{23}} besserer Einschätzung Ihrer Vorkenntnisse haben wir einen Einstufungstest beigelegt. Wenn Sie die Testbögen ausfüllen und mit der Anmeldung an uns zurücksenden, helfen Sie uns bei der Kursplanung. Ein mündlicher Test wird sich am ersten Unterrichtstag in unserer Schule {{24}}. Damit sind wir in der Lage, den für Sie angemessenen Kurs auszuwählen.\n\nAußerdem finden Sie in den Unterlagen einen Fragebogen {{25}} Ihrer Freizeitinteressen. Wir werden uns bemühen, Ihnen den Aufenthalt in Leipzig so angenehm {{26}} möglich zu gestalten.\n\nSchließlich füllen Sie bitte das grüne Unterkunftsblatt aus. Sie können wählen zwischen einem 3-Sterne-Hotel, {{27}} Privatunterkunft in einer deutschen Gastfamilie oder der Unterkunft in einem Studentenwohnheim. Letzteres ist nur in den Semesterferien der Universität – in der Regel vom 15.2. bis 15.4. und vom 15.7. bis 15.10. – möglich. Geben Sie bitte auch Ihre Verpflegungswünsche – Frühstück oder Halbpension – an. Beachten Sie aber, dass im Studentenwohnheim nur Selbstverpflegung möglich ist.\n\n{{28}} Ihre Anmeldung bei uns eingegangen ist, erhalten Sie eine Anmeldebestätigung und einen Stadtplan mit Wegbeschreibung, {{29}} Sie den Weg zu uns ohne Umstände finden. Die Adresse Ihrer Unterkunft erhalten Sie ca. 2 Wochen vor Kursbeginn.\n\n{{30}} weitere Fragen steht Ihnen unser Sekretariat gerne montags bis freitags von 8 bis 18 Uhr zur Verfügung.\n\nMit freundlichen Grüßen\nGerhard Dietz\nDirektor",
      "questions": {
        "21": {
          "options": [
            "an",
            "bei",
            "in"
          ],
          "answer": 0,
          "note": "Feste Präposition: Interesse an (+ Dativ)."
        },
        "22": {
          "options": [
            "in Betrag",
            "in Höhe",
            "in Summe"
          ],
          "answer": 1,
          "note": "Feste Wendung: eine Anzahlung / ein Betrag in Höhe von ..."
        },
        "23": {
          "options": [
            "Für",
            "Zur",
            "Zwecks"
          ],
          "answer": 2,
          "note": "„Zwecks“ steht mit Genitiv ohne Artikel („zwecks besserer Einschätzung“); bei „zur“ müsste es „zur besseren Einschätzung“ heißen."
        },
        "24": {
          "options": [
            "angeschlossen",
            "anschließen",
            "anschließen an"
          ],
          "answer": 1,
          "note": "Futur I mit Modal-/Hilfsverb „wird“ + Infinitiv am Satzende: „wird sich ... anschließen“."
        },
        "25": {
          "options": [
            "anlässlich",
            "bezüglich",
            "mittels"
          ],
          "answer": 1,
          "note": "Präposition mit Genitiv: „bezüglich Ihrer Freizeitinteressen“ (= in Bezug auf)."
        },
        "26": {
          "options": [
            "als",
            "wenn",
            "wie"
          ],
          "answer": 2,
          "note": "Vergleich im Positiv: „so angenehm wie möglich“."
        },
        "27": {
          "options": [
            "ein",
            "einem",
            "einer"
          ],
          "answer": 2,
          "note": "Dativ feminin Singular nach „zwischen“: „zwischen einem Hotel, einer Privatunterkunft oder der Unterkunft“."
        },
        "28": {
          "options": [
            "Sobald",
            "Sofort",
            "Sooft"
          ],
          "answer": 0,
          "note": "Temporale Konjunktion für einen Nebensatz: „Sobald Ihre Anmeldung eingegangen ist, ...“."
        },
        "29": {
          "options": [
            "dafür",
            "damit",
            "dazu"
          ],
          "answer": 1,
          "note": "Finalsatz (Zweck/Ziel): „..., damit Sie den Weg finden.“"
        },
        "30": {
          "options": [
            "Bei",
            "Für",
            "Zu"
          ],
          "answer": 1,
          "note": "Mit Akkusativ („weitere Fragen“): „Für weitere Fragen steht Ihnen ... zur Verfügung“ (bei „Bei“ müsste Dativ Plural „weiteren Fragen“ stehen)."
        }
      }
    },
    {
      "id": "1a",
      "num": "1a",
      "page": 356,
      "isVariant": true,
      "title": "Deutschkurs in Leipzig (Frau Szabo – Variante 1a)",
      "category": "Formeller Brief / Sprachschule",
      "text": "Sehr geehrte Frau Szabo,\n\nvielen Dank für Ihr Interesse an unseren Deutschkursen. {{21}} erhalten Sie das angeforderte Anmeldeformular, das Sie bitte ausgefüllt an uns zurückschicken.\n\nMit der Anmeldung überweisen Sie bitte eine Anzahlung {{22}} von € 200,– auf unser Konto. Die Kontoverbindung finden Sie unten auf dem Anmeldeformular. {{23}} genaueren Einschätzung Ihrer Vorkenntnisse haben wir einen Einstufungstest beigelegt. Wenn Sie die Testbögen ausfüllen und mit der Anmeldung an uns zurücksenden, helfen Sie uns bei der Kursplanung. Am ersten Unterrichtstag wird in unserer Schule auch ein mündlicher Test {{24}}. Damit sind wir in der Lage, den für Sie angemessenen Kurs auszuwählen.\n\nAußerdem finden Sie in den Unterlagen einen Fragebogen {{25}} Ihrer Freizeitinteressen, denn wir werden uns bemühen, Ihnen den Aufenthalt in Leipzig {{26}} angenehm zu gestalten.\n\nSchließlich füllen Sie bitte das grüne Unterkunftsblatt aus. Sie können wählen zwischen einem 3-Sterne-Hotel, {{27}} Privatunterkunft in einer deutschen Gastfamilie oder der Unterkunft in einem Studentenwohnheim. Letzteres ist nur in den Semesterferien der Universität – in der Regel vom 15.2. bis 15.4. und vom 15.7. bis 15.10. – möglich. Geben Sie bitte auch Ihre Verpflegungswünsche – Frühstück oder Halbpension – an. Beachten Sie aber, dass im Studentenwohnheim nur Selbstverpflegung möglich ist.\n\n{{28}} Ihre Anmeldung bei uns eingegangen ist, erhalten Sie eine Anmeldebestätigung und einen Stadtplan mit Wegbeschreibung, {{29}} Sie den Weg zu uns ohne Umstände finden. Die Adresse Ihrer Unterkunft erhalten Sie ca. 2 Wochen vor Kursbeginn.\n\n{{30}} weitere Fragen steht Ihnen unser Sekretariat gerne montags bis freitags von 8 bis 18 Uhr zur Verfügung.\n\nMit freundlichen Grüßen\nGerhard Dietz\nDirektor",
      "questions": {
        "21": {
          "options": [
            "Anbei",
            "Dabei",
            "Vorbei"
          ],
          "answer": 0,
          "note": "„Anbei“ bedeutet „beiliegend / im Anhang dieses Schreibens“."
        },
        "22": {
          "options": [
            "in Betrag",
            "in Höhe",
            "in Summe"
          ],
          "answer": 1,
          "note": "Feste Wendung: „eine Anzahlung in Höhe von € 200,–“."
        },
        "23": {
          "options": [
            "Für",
            "Zur",
            "Zwecks"
          ],
          "answer": 1,
          "note": "Wegen der schwachen Adjektivendung „-en“ („genaueren Einschätzung“) steht hier „Zur“ (= Zu der + Dativ)."
        },
        "24": {
          "options": [
            "durchführen",
            "stattfinden",
            "veranstalten"
          ],
          "answer": 1,
          "note": "Aktiv-Intransitiv mit Subjekt „ein mündlicher Test“: „Ein Test wird stattfinden“."
        },
        "25": {
          "options": [
            "anlässlich",
            "bezüglich",
            "mittels"
          ],
          "answer": 1,
          "note": "„bezüglich Ihrer Freizeitinteressen“ (= hinsichtlich / in Bezug auf)."
        },
        "26": {
          "options": [
            "möglich",
            "möglicherweise",
            "möglichst"
          ],
          "answer": 2,
          "note": "Adverb vor Adjektiv: „möglichst angenehm“ (= so angenehm wie möglich)."
        },
        "27": {
          "options": [
            "ein",
            "einem",
            "einer"
          ],
          "answer": 2,
          "note": "Dativ feminin Singular nach „zwischen“: „einer Privatunterkunft“."
        },
        "28": {
          "options": [
            "Sobald",
            "Sofort",
            "Sooft"
          ],
          "answer": 0,
          "note": "Temporale Nebensatzkonjunktion: „Sobald Ihre Anmeldung eingegangen ist“."
        },
        "29": {
          "options": [
            "dafür",
            "damit",
            "dazu"
          ],
          "answer": 1,
          "note": "Finalsatz mit „damit“."
        },
        "30": {
          "options": [
            "Bei",
            "Für",
            "Zu"
          ],
          "answer": 1,
          "note": "„Für weitere Fragen“ (Akkusativ Plural ohne „-n“ am Adjektiv)."
        }
      }
    },
    {
      "id": "2",
      "num": "2",
      "page": 357,
      "isVariant": false,
      "title": "Sommerreise mit Interrail (Lieber Igor)",
      "category": "Persönliche E-Mail / Reiseplanung",
      "text": "Lieber Igor,\n\nvielen Dank für deine Nachricht, {{21}} die ich mich sehr gefreut habe. Es ist echt eine tolle Idee, im Sommer gemeinsam zu verreisen! Aber möchtest du wirklich mit dem Auto fahren? Ich würde lieber die Bahn nehmen, denn das ist umweltfreundlicher und {{22}} noch billiger. Momentan bin ich nämlich mal wieder etwas knapp bei Kasse.\n\nWir könnten doch eine Interrail-Tour machen. Mit einem Global Pass können wir in 30 europäischen Ländern Zug {{23}}, und zwar wann und wohin auch immer – allerdings nicht bei uns in Deutschland. Hier müssen wir extra zahlen. Aber wir haben es ja von mir aus nicht allzu weit bis zur Grenze. {{24}} wir noch keine 26 Jahre alt sind, können wir den Pass ausgesprochen günstig bekommen. Der Preis hängt {{25}} ab, wie lange wir unterwegs sein wollen.\n\nWenn du lieber nur ein einziges Land bereisen möchtest, schlage ich vor, nach Frankreich zu fahren. Dann nämlich würden wir für ein Interrail-Ticket sogar noch weniger zahlen. Ich habe auch schon mit meiner Tante in Marseille {{26}} und sie hat gleich vorgeschlagen, {{27}} wir einige Tage bei ihr verbringen. Meine Cousins Jérôme und Matthieu, die in Paris studieren, haben Semesterferien und werden auch dort sein. Die beiden würden {{28}} freuen, mit uns um die Häuser zu ziehen, und könnten uns sicherlich die angesagtesten Clubs der Stadt zeigen. Wegen {{29}} Sprachkenntnisse brauchst du dir nicht den Kopf zu zerbrechen, denn die beiden sprechen ziemlich gut Deutsch.\n\nWas hältst du davon? Hast du noch andere Vorschläge? Ich freue mich {{30}} schon sehr auf unsere gemeinsame Reise!\n\nBis bald\nThomas",
      "questions": {
        "21": {
          "options": [
            "mit",
            "über",
            "wegen"
          ],
          "answer": 1,
          "note": "sich freuen über (+ Akkusativ) für etwas bereits Geschehenes."
        },
        "22": {
          "options": [
            "außerdem",
            "sonst",
            "weiterhin"
          ],
          "answer": 0,
          "note": "„außerdem“ fügt ein weiteres Argument hinzu (= darüber hinaus)."
        },
        "23": {
          "options": [
            "fahren",
            "kommen",
            "nehmen"
          ],
          "answer": 0,
          "note": "Ohne Artikel heißt es „Zug fahren“ (aber: „einen/den Zug nehmen“)."
        },
        "24": {
          "options": [
            "Da",
            "Darum",
            "Deshalb"
          ],
          "answer": 0,
          "note": "Kausale Nebensatzkonjunktion mit Verbendstellung: „Da wir noch keine 26 Jahre alt sind, ...“."
        },
        "25": {
          "options": [
            "dadurch",
            "damit",
            "davon"
          ],
          "answer": 2,
          "note": "abhängen von -> Pronominaladverb „davon ab, wie lange ...“."
        },
        "26": {
          "options": [
            "besprochen",
            "gesprochen",
            "versprochen"
          ],
          "answer": 1,
          "note": "mit jemandem sprechen -> „mit meiner Tante gesprochen“."
        },
        "27": {
          "options": [
            "als",
            "dass",
            "wenn"
          ],
          "answer": 1,
          "note": "Objektsatz nach „vorschlagen“: „vorgeschlagen, dass wir ... verbringen“."
        },
        "28": {
          "options": [
            "euch",
            "sich",
            "uns"
          ],
          "answer": 1,
          "note": "Reflexivpronomen 3. Person Plural („Die beiden würden sich freuen“)."
        },
        "29": {
          "options": [
            "das",
            "der",
            "die"
          ],
          "answer": 1,
          "note": "Präposition „wegen“ + Genitiv Plural: „wegen der Sprachkenntnisse“."
        },
        "30": {
          "options": [
            "bestenfalls",
            "jedenfalls",
            "keinesfalls"
          ],
          "answer": 1,
          "note": "„jedenfalls“ = auf jeden Fall."
        }
      }
    },
    {
      "id": "3",
      "num": "3",
      "page": 358,
      "isVariant": false,
      "title": "Wochenendausflug zum Amselsee (Hallo Maria)",
      "category": "Persönliche E-Mail / Ausflug",
      "text": "Hallo Maria,\n\nbevor wieder der Arbeitsalltag beginnt, schicke ich dir {{21}} rasch einige Zeilen, um dir von unserem Wochenende zu erzählen. Es ist so schade, dass du {{22}} deiner Grippe nicht dabei sein konntest! Wir haben dich alle sehr vermisst.\n\n{{23}} auf Mirko sind alle mit dem Zug angereist und wir haben uns schon am Bahnhof getroffen. Nachdem wir unser Gepäck abgestellt {{24}}, haben wir gleich einen Rundgang durch den Ort gemacht. Lilo wusste viel Interessantes zu erzählen. Sie lebt ja schon einige Jahre dort und hat sich {{25}} ausgezeichnete Fremdenführerin erwiesen. Besonders beeindruckt hat uns der wunderschöne Park, in dem gerade die Rhododendren blühten. Eine wahre Pracht! Das hätte dir auch gefallen!\n\nSpäter sind wir zum Amselsee gewandert, den man in kurzer Zeit vom Ort aus erreicht. Dort haben wir eine Bootsfahrt über den See gemacht. Vom Boot aus hat man einen wunderbaren Blick auf die beeindruckende Felsenlandschaft. Am Abend stand dann die Felsenbühne {{26}} dem Programm.\n\nDie Wanderung am nächsten Tag war {{27}} schön anstrengend, aber wunderbar. {{28}} alle ziemlich erschöpft waren, haben wir nach dem Abendessen noch lange zusammengesessen und über alte Zeiten geplaudert. Am nächsten Morgen nach unserem gemeinsamen Frühstück waren wir uns einig, dass wir bald wieder zusammen einen Ausflug machen {{29}}. Und nächstes Mal musst du unbedingt dabei sein!\n\nIm Anhang schicke ich dir einige Fotos. Wie du siehst, war unser Treffen wirklich lustig! Ich hoffe, dass es dir {{30}} schon wieder besser geht.\n\nLiebe Grüße von uns allen\nCem",
      "questions": {
        "21": {
          "options": [
            "momentan",
            "noch",
            "weiterhin"
          ],
          "answer": 1,
          "note": "„noch rasch“ = schnell noch vor Beginn des Arbeitsalltags."
        },
        "22": {
          "options": [
            "deswegen",
            "wegen",
            "weil"
          ],
          "answer": 1,
          "note": "Präposition mit Genitiv/Dativ: „wegen deiner Grippe“."
        },
        "23": {
          "options": [
            "Abgesehen",
            "Außer",
            "Bis"
          ],
          "answer": 2,
          "note": "Feste Verbindung mit „auf“: „Bis auf Mirko“ (= alle außer Mirko)."
        },
        "24": {
          "options": [
            "haben",
            "hatten",
            "hätten"
          ],
          "answer": 1,
          "note": "Vorzeitigkeit nach „Nachdem“ mit Hauptsatz im Perfekt/Präteritum -> Plusquamperfekt „abgestellt hatten“."
        },
        "25": {
          "options": [
            "als",
            "für",
            "zur"
          ],
          "answer": 0,
          "note": "Feste Wendung: „sich als ... erweisen“."
        },
        "26": {
          "options": [
            "auf",
            "in",
            "zu"
          ],
          "answer": 0,
          "note": "Feste Wendung: „auf dem Programm stehen“."
        },
        "27": {
          "options": [
            "absolut",
            "ganz",
            "vollkommen"
          ],
          "answer": 1,
          "note": "Umgangssprachliche Wendung: „ganz schön anstrengend“ (= ziemlich anstrengend)."
        },
        "28": {
          "options": [
            "Obwohl",
            "Trotzdem",
            "Ungeachtet"
          ],
          "answer": 0,
          "note": "Konzessiver Nebensatz mit Verbendstellung: „Obwohl alle ziemlich erschöpft waren, ...“."
        },
        "29": {
          "options": [
            "durften",
            "konnten",
            "sollten"
          ],
          "answer": 2,
          "note": "Vorschlag/Empfehlung: „dass wir bald wieder einen Ausflug machen sollten“."
        },
        "30": {
          "options": [
            "inzwischen",
            "während",
            "zwischen"
          ],
          "answer": 0,
          "note": "Temporaladverb: „inzwischen“ (= mittlerweile)."
        }
      }
    },
    {
      "id": "4",
      "num": "4",
      "page": 359,
      "isVariant": false,
      "title": "Eingelebt in Frankfurt (Liebe Ida)",
      "category": "Persönliche E-Mail / Umzug & Beruf",
      "text": "Liebe Ida,\n\nnun ist es schon drei Monate her, dass ich nach Frankfurt gezogen bin. Es hat ziemlich lange gedauert, bis ich mich hier eingelebt habe. Am Anfang hatte ich mich auch gar nicht {{21}} die neue Stelle und das Leben in der Stadt gefreut. Dass ich für meine neue Arbeitsstelle umgezogen war, hatte mich eine Zeitlang sogar ein bisschen geärgert. Ich {{22}} ja auch täglich mit dem Zug fahren können, statt mir eine Wohnung in der Nähe der Firma zu suchen. Zuerst habe ich {{23}} in meiner neuen Wohnung auch gar nicht richtig wohlgefühlt. Aber nachdem ich meine Umzugskartons {{24}}, konnte ich endlich die Stadt richtig erkunden.\n\nSeit einiger Zeit gefällt es mir in Frankfurt nun richtig gut. Das liegt vor allem {{25}}, dass ich eine neue Freundin gefunden habe. Annabelle wohnt in derselben Straße wie ich und wir haben uns auf einem Flohmarkt in unserem Stadtviertel kennengelernt. Sie hat dort ihre alten Bücher verkauft. Als wir {{26}} ins Gespräch kamen, haben wir festgestellt, dass wir ähnliche Interessen und Hobbys teilen: Sie mag ebenfalls ausgefallene Mode und moderne Kunst und wir gehen nun regelmäßig zusammen ins Schwimmbad.\n\nMein Leben sieht nun also ganz anders aus {{27}} noch vor drei Monaten. Mit meiner neuen Stelle bin ich auch zufrieden, {{28}} ich oft Überstunden machen muss. Dafür herrscht jedoch ein angenehmes Betriebsklima {{29}} uns in der Abteilung.\n\nJetzt habe ich viel von mir erzählt, aber Dich noch gar nicht gefragt, wie es Dir {{30}} geht. Gibt es etwas Neues bei Dir? Ich freue mich auf Deine nächste Mail!\n\nHerzliche Grüße\nDeine Emilia",
      "questions": {
        "21": {
          "options": [
            "an",
            "auf",
            "wegen"
          ],
          "answer": 1,
          "note": "sich freuen auf (+ Akkusativ) = Vorfreude auf die neue Stelle."
        },
        "22": {
          "options": [
            "habe",
            "hätte",
            "würde"
          ],
          "answer": 1,
          "note": "Irrealis der Vergangenheit mit Modalverb: „Ich hätte ... fahren können“."
        },
        "23": {
          "options": [
            "dich",
            "uns",
            "mich"
          ],
          "answer": 2,
          "note": "Reflexivpronomen 1. Person Singular: „ich habe mich wohlgefühlt“."
        },
        "24": {
          "options": [
            "ausgepackt habe",
            "ausgepackt hatte",
            "auspackte"
          ],
          "answer": 1,
          "note": "Nach „nachdem“ + Hauptsatz im Präteritum („konnte“) steht Plusquamperfekt: „ausgepackt hatte“."
        },
        "25": {
          "options": [
            "daran",
            "darauf",
            "darin"
          ],
          "answer": 0,
          "note": "Feste Verbindung: „Das liegt daran, dass ...“."
        },
        "26": {
          "options": [
            "einander",
            "gegeneinander",
            "miteinander"
          ],
          "answer": 2,
          "note": "„miteinander ins Gespräch kommen“."
        },
        "27": {
          "options": [
            "als",
            "denn",
            "wenn"
          ],
          "answer": 0,
          "note": "Nach „anders“ steht die Vergleichspartikel „als“: „ganz anders aus als noch vor drei Monaten“."
        },
        "28": {
          "options": [
            "obwohl",
            "trotzdem",
            "während"
          ],
          "answer": 0,
          "note": "Konzessivsatz mit Verbendstellung: „..., obwohl ich oft Überstunden machen muss“."
        },
        "29": {
          "options": [
            "bei",
            "mit",
            "zu"
          ],
          "answer": 0,
          "note": "Orts-/Gruppenangabe: „bei uns in der Abteilung“."
        },
        "30": {
          "options": [
            "eigentlich",
            "hoffentlich",
            "sicherlich"
          ],
          "answer": 0,
          "note": "Gesprächspartikel in Fragen: „wie es Dir eigentlich geht“."
        }
      }
    },
    {
      "id": "5",
      "num": "5",
      "page": 360,
      "isVariant": false,
      "title": "Sommerjob im Hotel „Seeblick“ (Liebe Andrea)",
      "category": "Persönliche E-Mail / Jobsuche",
      "text": "Liebe Andrea,\n\nvielen Dank für deine Nachricht. Entschuldige bitte, dass ich {{21}} jetzt antworte, aber ich konnte gestern meinen Laptop nicht verwenden. Ich hatte ihn zu Peter gebracht, damit er mir ein neues Betriebssystem installiert. Jetzt funktioniert alles {{22}}, so dass ich endlich meine Fotos sortieren konnte. Peter und ich haben uns die Fotos von deinem letzten Besuch hier angesehen. Es war so lustig, du musst bald wieder mal {{23}} uns kommen.\n\nNun zu deiner Nachricht: Du suchst also einen Sommerjob im Bereich Touristik und wolltest wissen, ob ich einen Tipp für dich habe. Ich habe mich hier ein wenig umgehört, {{24}} du bist ziemlich spät dran mit deiner Suche. Nur das Hotel „Seeblick“ sucht noch jemanden für die Rezeption. Man braucht keine {{25}} Berufserfahrung; nur Englisch ist zwingende Voraussetzung, eine {{26}} Fremdsprache wäre noch besser. Das wäre für Juli und August, fünf Tage in der Woche. Du musst dich allerdings sehr bald {{27}}, am besten noch heute. Die Kontaktperson findest du auf der Webseite des Hotels. {{28}} kenne ich die Hotelbesitzer nicht persönlich, sonst hätte ich mich natürlich sofort für dich eingesetzt.\n\nIch werde {{29}} wieder im Kinder-Feriencamp arbeiten. Eigentlich wollte ich dieses Jahr ins Ausland, aber dann habe ich mich doch {{30}}, hier zu bleiben. Meine Mutter hat sich noch nicht richtig von ihrer Operation erholt, und ich lasse sie ungern allein.\n\nAlso bewirb dich gleich – es wäre toll, wenn wir uns im Sommer viel sehen könnten. Falls es nicht klappt, hoffe ich doch, dass du uns bald besuchen kommst!\n\nIn der Zwischenzeit alles Liebe\nSophia",
      "questions": {
        "21": {
          "options": [
            "erst",
            "gleich",
            "zuerst"
          ],
          "answer": 0,
          "note": "„erst jetzt“ (= später als erwartet, nicht früher)."
        },
        "22": {
          "options": [
            "am besten",
            "bestenfalls",
            "bestens"
          ],
          "answer": 2,
          "note": "Elativadverb „bestens“ (= sehr gut / hervorragend)."
        },
        "23": {
          "options": [
            "bei",
            "mit",
            "zu"
          ],
          "answer": 2,
          "note": "Richtungsangabe bei Personen: „zu uns kommen“."
        },
        "24": {
          "options": [
            "aber",
            "denn",
            "oder"
          ],
          "answer": 0,
          "note": "Gegensatz: „Ich habe mich umgehört, aber du bist ziemlich spät dran“."
        },
        "25": {
          "options": [
            "besondere",
            "geringe",
            "gute"
          ],
          "answer": 0,
          "note": "„keine besondere Berufserfahrung“ (= keine spezielle Erfahrung nötig)."
        },
        "26": {
          "options": [
            "künftige",
            "nächste",
            "weitere"
          ],
          "answer": 2,
          "note": "„eine weitere Fremdsprache“ (= noch eine zusätzliche Fremdsprache)."
        },
        "27": {
          "options": [
            "anwerben",
            "bewerben",
            "umwerben"
          ],
          "answer": 1,
          "note": "Reflexiv: „sich bewerben“."
        },
        "28": {
          "options": [
            "Bedauerlich",
            "Leider",
            "Schade"
          ],
          "answer": 1,
          "note": "Satzadverb im Vorfeld vor dem finiten Verb: „Leider kenne ich ...“."
        },
        "29": {
          "options": [
            "deshalb",
            "trotzdem",
            "übrigens"
          ],
          "answer": 2,
          "note": "Themenwechsel/Zusatzinfo: „Ich werde übrigens wieder im Kinder-Feriencamp arbeiten.“"
        },
        "30": {
          "options": [
            "ausgemacht",
            "beschlossen",
            "entschieden"
          ],
          "answer": 2,
          "note": "Reflexiv: „sich entscheiden“ („habe ich mich doch entschieden“; „beschließen“ ist nicht reflexiv)."
        }
      }
    },
    {
      "id": "5a",
      "num": "5a",
      "page": 361,
      "isVariant": true,
      "title": "Sommerjob im Hotel „Seeblick“ (Liebe Andrea – Variante 5a)",
      "category": "Persönliche E-Mail / Jobsuche",
      "text": "Liebe Andrea,\n\nvielen Dank für deine Nachricht. Entschuldige bitte, dass ich {{21}} jetzt antworte, aber ich konnte gestern meinen Laptop nicht verwenden. Ich hatte ihn zu Peter gebracht, damit er mir ein neues Betriebssystem installiert. Jetzt funktioniert alles {{22}}, so dass ich endlich meine Fotos sortieren konnte. Peter und ich haben uns die Fotos von deinem letzten Besuch hier angesehen. Es war so lustig, du musst bald wieder mal {{23}} uns kommen.\n\nNun zu deiner Nachricht: Du suchst also einen Sommerjob im Bereich Touristik und wolltest wissen, ob ich einen Tipp für dich habe. Ich habe mich hier ein wenig umgehört, aber du bist {{24}} spät dran mit deiner Suche. Nur das Hotel „Seeblick“ sucht noch jemanden für die Rezeption. Man braucht keine {{25}} Berufserfahrung; nur Englisch ist zwingende Voraussetzung, eine {{26}} Fremdsprache wäre noch besser. Das wäre für Juli und August, fünf Tage in der Woche. Du musst dich allerdings sehr bald {{27}}, am besten noch heute. Die Kontaktperson findest du auf der Webseite des Hotels. Leider kenne ich die Hotelbesitzer nicht persönlich, {{28}} hätte ich mich natürlich sofort für dich eingesetzt.\n\nIch werde {{29}} wieder im Kinder-Feriencamp arbeiten. Eigentlich wollte ich dieses Jahr ins Ausland, aber dann habe ich mich doch {{30}}, hier zu bleiben. Meine Mutter hat sich noch nicht richtig von ihrer Operation erholt, und ich lasse sie ungern allein.\n\nAlso bewirb dich gleich – es wäre toll, wenn wir uns im Sommer viel sehen könnten. Falls es nicht klappt, hoffe ich doch, dass du uns bald besuchen kommst!\n\nIn der Zwischenzeit alles Liebe\nSophia",
      "questions": {
        "21": {
          "options": [
            "erst",
            "gleich",
            "zuerst"
          ],
          "answer": 0,
          "note": "„erst jetzt“ (= nicht früher als jetzt)."
        },
        "22": {
          "options": [
            "am besten",
            "bestenfalls",
            "bestens"
          ],
          "answer": 2,
          "note": "„alles funktioniert bestens“ (= einwandfrei)."
        },
        "23": {
          "options": [
            "bei",
            "mit",
            "zu"
          ],
          "answer": 2,
          "note": "„zu uns kommen“."
        },
        "24": {
          "options": [
            "fast",
            "ungefähr",
            "ziemlich"
          ],
          "answer": 2,
          "note": "Gradpartikel vor Adjektiv: „ziemlich spät dran“."
        },
        "25": {
          "options": [
            "besondere",
            "geringe",
            "gute"
          ],
          "answer": 0,
          "note": "„keine besondere Berufserfahrung“."
        },
        "26": {
          "options": [
            "künftige",
            "nächste",
            "weitere"
          ],
          "answer": 2,
          "note": "„eine weitere Fremdsprache“."
        },
        "27": {
          "options": [
            "anwerben",
            "bewerben",
            "umwerben"
          ],
          "answer": 1,
          "note": "„sich bewerben“."
        },
        "28": {
          "options": [
            "außerdem",
            "damals",
            "sonst"
          ],
          "answer": 2,
          "note": "Irreale Folge mit Konjunktiv II: „..., sonst (= andernfalls) hätte ich mich für dich eingesetzt.“"
        },
        "29": {
          "options": [
            "deshalb",
            "trotzdem",
            "übrigens"
          ],
          "answer": 2,
          "note": "„übrigens“ leitet eine beiläufige Zusatzinformation ein."
        },
        "30": {
          "options": [
            "ausgemacht",
            "beschlossen",
            "entschieden"
          ],
          "answer": 2,
          "note": "Reflexiv: „ich habe mich doch entschieden“."
        }
      }
    },
    {
      "id": "6",
      "num": "6",
      "page": 362,
      "isVariant": false,
      "title": "Redaktionsschluss der Vereinszeitung",
      "category": "Rundschreiben / Redaktion",
      "text": "Liebe Autorinnen und Autoren,\n\nWeihnachten ist nicht mehr weit, und bevor wir uns alle in die wohlverdienten Feiertage verabschieden, möchte ich euch noch einmal an den Redaktionsschluss für unsere Vereinszeitung erinnern, den wir für den 10. Januar festgelegt haben. {{21}} ihr alle wisst, kann Claudia, unsere fleißige Layouterin, sich erst dann an die Arbeit machen, wenn alle Texte und Bilder {{22}}. Die fertige Datei muss bis spätestens 22. Januar in der Druckerei sein, damit das Heft pünktlich zum 1. Februar fertig sein kann. Ein gutes Layout ist auch {{23}} Interesse der Autorinnen und Autoren. Ist es schlecht, schenkt man dem Artikel automatisch weniger Beachtung. Liefert also bitte eure Beiträge rechtzeitig {{24}}.\n\nFür die Bildbearbeitung ist wie immer Florian zuständig. Bitte die Bilder im TIF- oder im JPG-Format liefern und bitte den Bildnachweis anführen, wenn die Bilder nicht von euch selbst stammen. Für eure eigenen Bilder liegt das Copyright natürlich {{25}} euch.\n\nLeider sind die Verkaufszahlen unserer Vereinszeitung im letzten Jahr {{26}} zurückgegangen. Deshalb möchten wir euch alle noch einmal herzlich {{27}} bitten, nur Themen zu wählen, die unsere Vereinsmitglieder betreffen und sie auch wirklich {{28}}. Das heißt nicht, {{29}} man große Themen wie Politik oder Gesellschaft nicht behandeln kann, aber sie sollten leserfreundlich verpackt sein. Wir verstehen uns ausdrücklich {{30}} unabhängige Zeitung und möchten uns keinen Maulkorb umhängen lassen. Trotzdem sollten die Beiträge im Rahmen sachlicher Meinungsäußerungen bleiben.\n\nIn diesem Sinne freut sich die Redaktion auf zahlreiche Artikel!\n\nBeste Grüße und viel Erfolg\nEure Redaktion",
      "questions": {
        "21": {
          "options": [
            "Wie",
            "Was",
            "Wann"
          ],
          "answer": 0,
          "note": "Einleitender Vergleichssatz: „Wie ihr alle wisst, ...“."
        },
        "22": {
          "options": [
            "vorliegen",
            "unterliegen",
            "liegen lassen"
          ],
          "answer": 0,
          "note": "„vorliegen“ = vorhanden / eingereicht sein."
        },
        "23": {
          "options": [
            "von",
            "ohne",
            "im"
          ],
          "answer": 2,
          "note": "Feste Wendung: „im Interesse (+ Genitiv) sein“."
        },
        "24": {
          "options": [
            "zu",
            "ein",
            "ab"
          ],
          "answer": 2,
          "note": "Trennbares Verb: „etwas (rechtzeitig) abliefern“."
        },
        "25": {
          "options": [
            "mit",
            "für",
            "bei"
          ],
          "answer": 2,
          "note": "Feste Wendung: „das Copyright liegt bei jemandem“."
        },
        "26": {
          "options": [
            "unerschütterlich",
            "stark",
            "fest"
          ],
          "answer": 1,
          "note": "Kollokation: „stark zurückgehen“."
        },
        "27": {
          "options": [
            "deswegen",
            "darum",
            "dafür"
          ],
          "answer": 1,
          "note": "bitten um -> Pronominaladverb „darum bitten, ... zu ...“."
        },
        "28": {
          "options": [
            "besprechen",
            "aussprechen",
            "ansprechen"
          ],
          "answer": 2,
          "note": "jemanden ansprechen = jemanden interessieren / bei jemandem Anklang finden."
        },
        "29": {
          "options": [
            "ob",
            "dass",
            "damit"
          ],
          "answer": 1,
          "note": "Objektsatz: „Das heißt nicht, dass ...“."
        },
        "30": {
          "options": [
            "sowie",
            "als ob",
            "als"
          ],
          "answer": 2,
          "note": "sich verstehen als = sich betrachten/begreifen als."
        }
      }
    },
    {
      "id": "7",
      "num": "7",
      "page": 363,
      "isVariant": false,
      "title": "Au-pair-Aufenthalt ab September (Familie Geissler / Dippold)",
      "category": "Formeller/Halbformeller Brief / Au-pair",
      "text": "Liebe Familie Geissler,\n\nvielen Dank für Ihre Antwort {{21}} meine Bewerbung als Au-pair-Mädchen. Danke schön auch für die Fotos von den Kindern. Ich bin schon sehr gespannt und freue mich sehr, Ihre Familie im September kennenzulernen!\n\nIm Juni schließe ich meine Schulausbildung {{22}} und möchte auch noch mein Deutsch {{23}} verbessern. Dafür werde ich im Sommer noch einen Sprachkurs an einer Sommerschule in meiner Heimat {{24}}. Anschließend fahre ich mit meiner Familie für drei Wochen in Urlaub ans Meer.\n\nIch habe noch eine Frage {{25}} Sie. Sie schreiben, dass Sie für die Weihnachtsferien einen Skiurlaub planen, bei dem ich mitfahren kann, wenn ich möchte. Ich habe aber keine Ski und Skibekleidung. Kann ich mir diese Sachen bei {{26}} ausleihen? In meiner Heimat werde ich sie kaum jemals wieder brauchen. Aber ich bin immer offen für Neues und möchte das Skilaufen gern einmal ausprobieren.\n\nDanke schön, {{27}} Sie mich am Flughafen abholen kommen. Ich habe meinen Flug nach Frankfurt {{28}} gebucht. Am 2.9. werde ich sehr früh in Frankfurt landen, nämlich um 5:15 Uhr. Ich schlage {{29}}, dass wir uns erst gegen 7:30 Uhr in einem Café treffen. Vielleicht komme ich ja mit Verspätung oder muss länger auf mein Gepäck warten. Dann müssen Sie nicht so früh da sein.\n\nBitte schreiben Sie mir, wenn Sie noch etwas über mich wissen möchten! Ich schicke einige Fotos mit der Mail, damit die Kinder schon ein bisschen {{30}} von mir sehen.\n\nViele Grüße\nIhre Asja",
      "questions": {
        "21": {
          "options": [
            "wegen",
            "von",
            "auf"
          ],
          "answer": 2,
          "note": "Feste Präposition: „eine Antwort auf (+ Akkusativ)“."
        },
        "22": {
          "options": [
            "zu",
            "aus",
            "ab"
          ],
          "answer": 2,
          "note": "Trennbares Verb: „eine Ausbildung abschließen“."
        },
        "23": {
          "options": [
            "kaum",
            "fast",
            "ein bisschen"
          ],
          "answer": 2,
          "note": "„mein Deutsch ein bisschen verbessern“."
        },
        "24": {
          "options": [
            "unterrichten",
            "machen",
            "lernen"
          ],
          "answer": 1,
          "note": "Kollokation: „einen Sprachkurs machen / besuchen“."
        },
        "25": {
          "options": [
            "über",
            "für",
            "an"
          ],
          "answer": 2,
          "note": "Feste Präposition: „eine Frage an jemanden haben“."
        },
        "26": {
          "options": [
            "irgendwo",
            "irgendjemandem",
            "irgendetwas"
          ],
          "answer": 1,
          "note": "Nach „bei“ folgt Dativ einer Person: „bei irgendjemandem ausleihen“."
        },
        "27": {
          "options": [
            "falls",
            "dass",
            "dafür"
          ],
          "answer": 1,
          "note": "„Danke schön, dass Sie mich abholen kommen.“"
        },
        "28": {
          "options": [
            "schon",
            "noch",
            "bevor"
          ],
          "answer": 0,
          "note": "„Ich habe meinen Flug schon (= bereits) gebucht.“"
        },
        "29": {
          "options": [
            "zu",
            "vor",
            "nach"
          ],
          "answer": 1,
          "note": "Trennbares Verb: „vorschlagen“ -> „Ich schlage vor, dass ...“."
        },
        "30": {
          "options": [
            "weniger",
            "viel",
            "mehr"
          ],
          "answer": 2,
          "note": "„ein bisschen mehr von mir sehen“."
        }
      }
    },
    {
      "id": "8",
      "num": "8",
      "page": 364,
      "isVariant": false,
      "title": "Bewerbung im Antiquitätengeschäft (Herr Dr. Dobromil)",
      "category": "Bewerbungsschreiben",
      "text": "Sehr geehrter Herr Dr. Dobromil,\n\nmit {{21}} Interesse habe ich Ihr Stellenangebot in der Essener Zeitung gelesen, {{22}} Sie eine Teilzeit-Mitarbeiterin in Ihrem Antiquitätengeschäft suchen. Es reizt mich, eine verantwortungsvolle Aufgabe in einem so renommierten Geschäft wie dem {{23}} übernehmen {{24}}.\n\nNach dem Abitur am Kreisgymnasium in Velbert begann ich eine dreijährige Schreinerlehre {{25}} der Firma Eichelbohrer & Co und besuchte die Kreisberufsschule in Velbert. Nach erfolgreichem Abschluss meiner Berufsausbildung arbeitete ich {{26}} bei Stutz & Partner – Möbeldesign in Düsseldorf. Danach schrieb ich mich an der Fachhochschule Köln im Fachbereich Möbeldesign ein und {{27}} meine Liebe zu antiquarischen Möbelstücken. Meine Spezialität ist das stilgenaue Restaurieren und Aufarbeiten antiquarischer Möbel, insbesondere aus dem Biedermeier und dem Jugendstil. Aufgrund meiner Berufserfahrung und meines Studiums konnte ich umfangreiche Kenntnisse erwerben, {{28}} Möbelstile und die Herstellungskunst in den verschiedensten Epochen {{29}} in Nord- als auch in Südeuropa angeht.\n\nMein Studium lässt mir genügend Zeit, eine Teilzeitstelle zu übernehmen, die darüber hinaus meinen beruflichen Fähigkeiten und Neigungen entspricht. Aus diesem Grund habe ich mich entschlossen, {{30}}, und bewerbe mich um die von Ihnen angebotene Teilzeitstelle.\n\nIch freue mich auf ein persönliches Gespräch.\n\nMit freundlichen Grüßen\nSabina Holzinger",
      "questions": {
        "21": {
          "options": [
            "allergrößte",
            "allergrößtem",
            "allergrößten"
          ],
          "answer": 1,
          "note": "Starke Adjektivdeklination im Dativ Singular Neutrum ohne Artikel nach „mit“: „mit allergrößtem Interesse“."
        },
        "22": {
          "options": [
            "an dem",
            "auf dem",
            "in dem"
          ],
          "answer": 2,
          "note": "Relativsatz zu „Stellenangebot“: „in dem Sie ... suchen“."
        },
        "23": {
          "options": [
            "Ihrem",
            "Ihren",
            "Ihres"
          ],
          "answer": 1,
          "note": "Gehobenes substantiviertes Possessivpronomen nach bestimmtem Artikel im Dativ: „wie dem Ihren“ (= Ihrem Geschäft)."
        },
        "24": {
          "options": [
            "können",
            "könnte",
            "zu können"
          ],
          "answer": 2,
          "note": "Infinitivkonstruktion nach „Es reizt mich, ... übernehmen zu können“."
        },
        "25": {
          "options": [
            "an",
            "bei",
            "mit"
          ],
          "answer": 1,
          "note": "Ausbildung/Arbeit bei einer Firma: „bei der Firma Eichelbohrer & Co“."
        },
        "26": {
          "options": [
            "ein Jahr lang",
            "durch ein Jahr",
            "seit einem Jahr"
          ],
          "answer": 0,
          "note": "Abgeschlossener Zeitraum in der Vergangenheit: „ein Jahr lang“."
        },
        "27": {
          "options": [
            "entdeckte",
            "erfand",
            "merkte"
          ],
          "answer": 0,
          "note": "Kollokation: „seine Liebe zu etwas entdecken“."
        },
        "28": {
          "options": [
            "das",
            "was",
            "welches"
          ],
          "answer": 1,
          "note": "Feste Wendung: „was ... angeht“ (= was ... betrifft)."
        },
        "29": {
          "options": [
            "sowohl ... als auch",
            "teils ... teils",
            "weder ... noch"
          ],
          "answer": 0,
          "note": "Doppelkonjunktion: „sowohl in Nord- als auch in Südeuropa“."
        },
        "30": {
          "options": [
            "auf Ihre Anzeige antworten",
            "auf Ihre Anzeige zu antworten",
            "um auf Ihre Anzeige zu antworten"
          ],
          "answer": 1,
          "note": "Nach „sich entschließen“ folgt ein einfacher Infinitivsatz mit „zu“: „auf Ihre Anzeige zu antworten“."
        }
      }
    },
    {
      "id": "8a",
      "num": "8a",
      "page": 365,
      "isVariant": true,
      "title": "Bewerbung im Antiquitätengeschäft (Herr Dr. Moosberger – Variante 8a)",
      "category": "Bewerbungsschreiben",
      "text": "Sehr geehrter Herr Dr. Moosberger,\n\nmit {{21}} Interesse habe ich Ihr Stellenangebot in der Essener Zeitung gelesen, {{22}} dem Sie eine Teilzeit-Mitarbeiterin in Ihrem Antiquitätengeschäft suchen. Es reizt mich, eine verantwortungsvolle Aufgabe in einem {{23}} renommierten Geschäft wie dem Ihrigen übernehmen {{24}}.\n\nNach dem Abitur am Kreisgymnasium in Velbert {{25}} ich eine dreijährige Schreinerlehre bei der Firma Eichelbohrer & Co und besuchte die Kreisberufsschule in Velbert. Nach erfolgreichem Abschluss meiner Berufsausbildung arbeitete ich {{26}} bei Stutz & Partner – Möbeldesign in Düsseldorf. Danach schrieb ich mich an der Fachhochschule Köln im Fachbereich Möbeldesign ein und {{27}} meine Liebe zu antiquarischen Möbelstücken. Meine Spezialität ist das stilgenaue Restaurieren und Aufarbeiten antiquarischer Möbel, insbesondere aus dem Biedermeier und dem Jugendstil. {{28}} meiner Berufstätigkeit und meines Studiums konnte ich umfangreiche Kenntnisse erwerben, was Möbelstile und die Herstellungskunst in den verschiedensten Epochen {{29}} in Nord- als auch in Südeuropa angeht.\n\nMein Studium lässt mir genügend Zeit, eine Teilzeitstelle zu übernehmen, die darüber hinaus meinen beruflichen Fähigkeiten und Neigungen entspricht. Aus diesem Grund habe ich mich entschlossen, {{30}}, und bewerbe mich um die von Ihnen angebotene Teilzeitstelle.\n\nIch freue mich auf ein persönliches Gespräch.\n\nMit freundlichen Grüßen\nSabine Holzinger",
      "questions": {
        "21": {
          "options": [
            "allergrößte",
            "allergrößtem",
            "allergrößten"
          ],
          "answer": 1,
          "note": "Dativ Neutrum Singular ohne Artikel: „mit allergrößtem Interesse“."
        },
        "22": {
          "options": [
            "an",
            "auf",
            "in"
          ],
          "answer": 2,
          "note": "„in dem Sie eine Teilzeit-Mitarbeiterin suchen“."
        },
        "23": {
          "options": [
            "als",
            "so",
            "wie"
          ],
          "answer": 1,
          "note": "Vergleich: „in einem so renommierten Geschäft wie ...“."
        },
        "24": {
          "options": [
            "können",
            "könnte",
            "zu können"
          ],
          "answer": 2,
          "note": "Infinitiv mit „zu“ nach „Es reizt mich“."
        },
        "25": {
          "options": [
            "begann",
            "beging",
            "belief"
          ],
          "answer": 0,
          "note": "Präteritum von „beginnen“: „begann ich eine dreijährige Schreinerlehre“."
        },
        "26": {
          "options": [
            "durch ein Jahr",
            "ein Jahr lang",
            "seit einem Jahr"
          ],
          "answer": 1,
          "note": "Zeitdauer in der Vergangenheit: „ein Jahr lang“."
        },
        "27": {
          "options": [
            "entdeckte",
            "erfand",
            "merkte"
          ],
          "answer": 0,
          "note": "„entdeckte meine Liebe zu ...“."
        },
        "28": {
          "options": [
            "Dabei",
            "Inzwischen",
            "Während"
          ],
          "answer": 2,
          "note": "Präposition mit Genitiv: „Während meiner Berufstätigkeit und meines Studiums“."
        },
        "29": {
          "options": [
            "sowohl ... als auch",
            "teils ... teils",
            "weder ... noch"
          ],
          "answer": 0,
          "note": "„sowohl in Nord- als auch in Südeuropa“."
        },
        "30": {
          "options": [
            "auf Ihre Anzeige antworten",
            "auf Ihre Anzeige zu antworten",
            "um auf Ihre Anzeige zu antworten"
          ],
          "answer": 1,
          "note": "Infinitivsatz mit „zu“ nach „sich entschließen“."
        }
      }
    },
    {
      "id": "9",
      "num": "9",
      "page": 366,
      "isVariant": false,
      "title": "Neue Arbeit in einer Baumschule (Liebe Corinna)",
      "category": "Persönliche E-Mail / Berufsstart",
      "text": "Liebe Corinna,\n\nes tut mir wirklich leid, {{21}} ich dir seit Ewigkeiten nicht mehr geschrieben habe. Aber du weißt ja: Ich habe seit drei Monaten eine neue Arbeit. Und da hatte ich gar keine Zeit, mich mit etwas anderem zu {{22}} als mit der neuen Arbeit. Es hat mich wirklich überrascht, wie schnell ich nach dem Abschluss meiner Ausbildung etwas gefunden habe. Dabei haben alle immer nur gesagt: „Gärtner? Die gibt es {{23}} wie Sand am Meer, wie willst du da so schnell einen Job finden?“\n\nIch arbeite jetzt in einer Baumschule. Wir kultivieren und verkaufen Obstbäume, {{24}} an die Obstbauern der näheren Umgebung. Die Arbeit macht mir großen Spaß, es ist andererseits aber ein bisschen anstrengend, acht Stunden am Tag körperlich – {{25}} im Freien – zu arbeiten. Und leider {{26}} ich fast eine dreiviertel Stunde mit dem Zug fahren, um an meinen Arbeitsplatz zu kommen. Wenn ich dann am Abend nach Hause komme, bin ich so müde, dass ich eigentlich nur noch fernsehen oder Musik hören kann. Ich habe im Moment nur {{27}} Lust, etwas zu unternehmen, aber ich bin mir sicher: Sie {{28}} wieder.\n\nWie geht es dir denn? Du müsstest doch jetzt auch bald mit deiner Ausbildung fertig sein, oder? Hast du schon damit angefangen, dich bei verschiedenen Arbeitgebern zu bewerben? Oder {{29}} du dir noch ein bisschen Zeit damit? Ich würde dir in jedem Fall raten: Fang so früh wie {{30}} mit den Bewerbungen an, je früher, desto besser. Du weißt ja, was unser Klassenlehrer in der Realschule immer gesagt hat: Gut Ding will Weile haben.\n\nSo, jetzt muss ich aufhören und ins Bett gehen, damit ich morgen wieder fit bin.\n\nMach’s gut, bis bald\ndein Richard",
      "questions": {
        "21": {
          "options": [
            "dass",
            "ob",
            "weil"
          ],
          "answer": 0,
          "note": "Subjektsatz/Objektsatz nach „es tut mir leid, dass ...“."
        },
        "22": {
          "options": [
            "bedienen",
            "beeilen",
            "beschäftigen"
          ],
          "answer": 2,
          "note": "sich beschäftigen mit (+ Dativ)."
        },
        "23": {
          "options": [
            "bloß",
            "doch",
            "nur"
          ],
          "answer": 1,
          "note": "Modalpartikel „doch“ bei bekannten Tatsachen: „Die gibt es doch wie Sand am Meer“."
        },
        "24": {
          "options": [
            "außerdem",
            "insbesondere",
            "jedoch"
          ],
          "answer": 1,
          "note": "Hervorhebung der Hauptzielgruppe: „insbesondere (= vor allem) an die Obstbauern“."
        },
        "25": {
          "options": [
            "übermächtig",
            "übermäßig",
            "überwiegend"
          ],
          "answer": 2,
          "note": "„überwiegend im Freien“ (= meistens / hauptsächlich draußen)."
        },
        "26": {
          "options": [
            "darf",
            "muss",
            "soll"
          ],
          "answer": 1,
          "note": "Notwendigkeit: „Und leider muss ich ... fahren“."
        },
        "27": {
          "options": [
            "gering",
            "knapp",
            "wenig"
          ],
          "answer": 2,
          "note": "Unflektiert vor unzählbarem Nomen: „nur wenig Lust“."
        },
        "28": {
          "options": [
            "kommt",
            "läuft",
            "steht"
          ],
          "answer": 0,
          "note": "Die Lust „kommt wieder“ (= kehrt zurück)."
        },
        "29": {
          "options": [
            "brauchst",
            "hast",
            "lässt"
          ],
          "answer": 2,
          "note": "Feste Wendung mit Dativ-Reflexivpronomen „dir“: „sich Zeit lassen mit etwas“."
        },
        "30": {
          "options": [
            "kürzlich",
            "möglich",
            "üblich"
          ],
          "answer": 1,
          "note": "Feste Wendung: „so früh wie möglich“."
        }
      }
    },
    {
      "id": "9a",
      "num": "9a",
      "page": 367,
      "isVariant": true,
      "title": "Neue Arbeit in einer Baumschule (Liebe Corinna – Variante 9a)",
      "category": "Persönliche E-Mail / Berufsstart",
      "text": "Liebe Corinna,\n\nes tut mir wirklich leid, {{21}} ich dir seit Ewigkeiten nicht mehr geschrieben habe. Aber du weißt ja: Ich habe seit drei Monaten eine neue Arbeit. Und da hatte ich gar keine Zeit, mich mit etwas anderem zu {{22}} als mit der neuen Arbeit. Es hat mich wirklich überrascht, wie schnell ich nach dem Abschluss meiner Ausbildung etwas gefunden habe. Dabei haben alle immer nur gesagt: „Gärtner? Die gibt es {{23}} wie Sand am Meer, wie willst du da so schnell einen Job finden?“\n\nIch arbeite jetzt in einer Baumschule. Wir kultivieren und verkaufen Obstbäume, {{24}} an die Obstbauern der näheren Umgebung. Die Arbeit macht mir großen Spaß, es ist andererseits aber ein bisschen anstrengend, acht Stunden am Tag körperlich – {{25}} im Freien – zu arbeiten. Und leider muss ich {{26}} eine dreiviertel Stunde mit dem Zug fahren, um an meinen Arbeitsplatz zu kommen. Wenn ich dann am Abend nach Hause komme, bin ich so müde, dass ich eigentlich nur noch fernsehen oder Musik hören kann. Ich habe im Moment nur {{27}} Lust, etwas zu unternehmen, aber ich bin mir sicher: Sie {{28}} wieder.\n\nWie geht es dir denn? Du müsstest doch jetzt auch bald mit deiner Ausbildung fertig sein, oder? Hast du schon damit angefangen, dich bei verschiedenen Arbeitgebern zu bewerben? Oder {{29}} du dir noch ein bisschen Zeit damit? Ich würde dir in jedem Fall raten: Fang so früh wie {{30}} mit den Bewerbungen an, je früher, desto besser. Du weißt ja, was unser Klassenlehrer in der Realschule immer gesagt hat: Gut Ding will Weile haben.\n\nSo, jetzt muss ich aufhören und ins Bett gehen, damit ich morgen wieder fit bin.\n\nMach’s gut, bis bald\ndein Richard",
      "questions": {
        "21": {
          "options": [
            "dass",
            "ob",
            "weil"
          ],
          "answer": 0,
          "note": "„es tut mir wirklich leid, dass ...“."
        },
        "22": {
          "options": [
            "bedienen",
            "beeilen",
            "beschäftigen"
          ],
          "answer": 2,
          "note": "„sich mit etwas beschäftigen“."
        },
        "23": {
          "options": [
            "bloß",
            "doch",
            "nur"
          ],
          "answer": 1,
          "note": "Modalpartikel „doch“."
        },
        "24": {
          "options": [
            "außerdem",
            "insbesondere",
            "jedoch"
          ],
          "answer": 1,
          "note": "„insbesondere an die Obstbauern“."
        },
        "25": {
          "options": [
            "übermächtig",
            "übermäßig",
            "überwiegend"
          ],
          "answer": 2,
          "note": "„überwiegend im Freien“."
        },
        "26": {
          "options": [
            "fast",
            "nahe",
            "ziemlich"
          ],
          "answer": 0,
          "note": "Vor Zeit-/Mengenangaben: „fast (= beinahe) eine dreiviertel Stunde“."
        },
        "27": {
          "options": [
            "gering",
            "knapp",
            "wenig"
          ],
          "answer": 2,
          "note": "„nur wenig Lust“."
        },
        "28": {
          "options": [
            "kommt",
            "läuft",
            "steht"
          ],
          "answer": 0,
          "note": "„Sie (die Lust) kommt wieder.“"
        },
        "29": {
          "options": [
            "brauchst",
            "hast",
            "lässt"
          ],
          "answer": 2,
          "note": "„Oder lässt du dir noch ein bisschen Zeit damit?“"
        },
        "30": {
          "options": [
            "kürzlich",
            "möglich",
            "üblich"
          ],
          "answer": 1,
          "note": "„so früh wie möglich“."
        }
      }
    },
    {
      "id": "10",
      "num": "10",
      "page": 368,
      "isVariant": false,
      "title": "Urlaubskarte & Stellenwechsel (Lieber Justus / Johannes)",
      "category": "Persönliche E-Mail / Urlaub & Beruf",
      "text": "Lieber Justus,\n\nvielen Dank für deine Urlaubskarte, {{21}} die ich mich wirklich sehr gefreut habe! Ich wusste {{22}} nicht, dass ihr gerne wandern geht. Oder habt ihr das jetzt zum ersten Mal gemacht? Als Kind war ich mit meinen Eltern mal wandern, aber mir hat das damals nicht {{23}} gefallen. Ich war auch noch klein und hatte keine Lust, so lange zu laufen. Heute fahre ich lieber an den Strand und mache einen schönen Badeurlaub. Den ganzen Tag lesen, in der Sonne liegen, ab und zu mal ins Wasser gehen – {{24}} habe ich schon im Alltag genug Stress.\n\nDabei fällt mir ein: Wie ist eigentlich deine neue Stelle? Du arbeitest doch jetzt in dieser internationalen Baufirma, oder? Bist du jetzt schneller im Büro als früher oder ist die Firma sogar noch weiter {{25}} als deine alte? Du musstest ja immer ziemlich lange fahren, daran erinnere ich mich noch gut!\n\nIch denke im Moment auch darüber nach, die Stelle zu {{26}}. Mein Chef und meine Kollegen sind zwar total nett und die Bezahlung ist auch gut, aber ich mache fast jeden Tag das Gleiche – und das jetzt schon seit über zehn Jahren. Ehrlich {{27}} langweile ich mich in den letzten Monaten immer häufiger und würde gerne noch mal etwas Neues ausprobieren. Deshalb mache ich ab dem {{28}} Monat erst mal eine Weiterbildung, sonst hätte ich wohl nicht so gute Chancen, eine neue Stelle zu bekommen. Schließlich wird es auch immer schwieriger, {{29}} älter man ist. Die meisten Arbeitgeber wollen doch lieber jüngere Angestellte.\n\nWie {{30}} es, wenn wir uns demnächst treffen würden? Wir könnten in diesem neuen Restaurant in der Innenstadt essen gehen. Melde dich doch einfach mal wieder!\n\nViele Grüße\nRichard",
      "questions": {
        "21": {
          "options": [
            "an",
            "für",
            "über"
          ],
          "answer": 2,
          "note": "sich freuen über (+ Akkusativ)."
        },
        "22": {
          "options": [
            "daher",
            "gar",
            "sicher"
          ],
          "answer": 1,
          "note": "Verstärkung der Verneinung: „gar nicht“ (= überhaupt nicht)."
        },
        "23": {
          "options": [
            "besonders",
            "einfach",
            "kaum"
          ],
          "answer": 0,
          "note": "„nicht besonders gefallen“ (= nicht sonderlich gut gefallen)."
        },
        "24": {
          "options": [
            "allerdings",
            "außerdem",
            "schließlich"
          ],
          "answer": 2,
          "note": "Begründung: „schließlich habe ich schon im Alltag genug Stress“."
        },
        "25": {
          "options": [
            "ab",
            "abgerückt",
            "entfernt"
          ],
          "answer": 2,
          "note": "„noch weiter entfernt als deine alte“."
        },
        "26": {
          "options": [
            "ändern",
            "verwechseln",
            "wechseln"
          ],
          "answer": 2,
          "note": "Kollokation: „die Stelle / den Job wechseln“."
        },
        "27": {
          "options": [
            "gesagt",
            "sagend",
            "zu sagen"
          ],
          "answer": 0,
          "note": "Feste Redewendung: „Ehrlich gesagt ...“."
        },
        "28": {
          "options": [
            "kommende",
            "kommendem",
            "kommenden"
          ],
          "answer": 2,
          "note": "Schwache Deklination nach „ab dem“ (Dativ Maskulinum): „ab dem kommenden Monat“."
        },
        "29": {
          "options": [
            "als",
            "je",
            "weil"
          ],
          "answer": 1,
          "note": "Proportionaler Vergleich: „immer schwieriger, je älter man ist“."
        },
        "30": {
          "options": [
            "ist",
            "war",
            "wäre"
          ],
          "answer": 2,
          "note": "Höflicher Vorschlag im Konjunktiv II: „Wie wäre es, wenn ...“."
        }
      }
    },
    {
      "id": "10a",
      "num": "10a",
      "page": 369,
      "isVariant": true,
      "title": "Urlaubskarte & Stellenwechsel (Lieber Johannes – Variante 10a)",
      "category": "Persönliche E-Mail / Urlaub & Beruf",
      "text": "Lieber Johannes,\n\nvielen Dank für deine Urlaubskarte, {{21}} die ich mich wirklich sehr gefreut habe! Ich wusste {{22}} nicht, dass ihr gerne wandern geht. Oder habt ihr das jetzt zum ersten Mal gemacht? Als Kind war ich mit meinen Eltern mal wandern, aber mir hat das damals nicht {{23}} gefallen. Ich war auch noch klein und hatte keine Lust, so lange zu laufen. Heute fahre ich lieber an den Strand und mache einen schönen Badeurlaub. Den ganzen Tag lesen, in der Sonne liegen, ab und zu mal ins Wasser gehen – {{24}} habe ich schon im Alltag genug Stress.\n\nDabei fällt mir ein: Wie ist eigentlich deine neue Stelle? Du arbeitest doch jetzt in dieser internationalen Baufirma, oder? Bist du jetzt schneller im Büro als früher oder ist die Firma sogar noch weiter {{25}} als deine alte? Du musstest ja immer ziemlich lange fahren, daran erinnere ich mich noch gut!\n\nIch denke im Moment auch darüber nach, die Stelle zu {{26}}. Mein Chef und meine Kollegen sind zwar total nett und die Bezahlung ist auch gut, aber ich mache fast jeden Tag das Gleiche – und das jetzt schon seit über zehn Jahren. Ehrlich {{27}} langweile ich mich in den letzten Monaten immer häufiger und würde gerne noch mal etwas Neues ausprobieren. Deshalb mache ich ab dem {{28}} Monat erst mal eine Weiterbildung, sonst hätte ich wohl nicht so gute Chancen, eine neue Stelle zu bekommen. Schließlich wird es auch immer schwieriger, {{29}} älter man ist. Die meisten Arbeitgeber wollen doch lieber jüngere Angestellte.\n\nWie {{30}} es, wenn wir uns demnächst treffen würden? Wir könnten in diesem neuen Restaurant in der Innenstadt essen gehen. Melde dich doch einfach mal wieder!\n\nViele Grüße\nRichard",
      "questions": {
        "21": {
          "options": [
            "an",
            "für",
            "über"
          ],
          "answer": 2,
          "note": "sich freuen über (+ Akkusativ)."
        },
        "22": {
          "options": [
            "daher",
            "gar",
            "sicher"
          ],
          "answer": 1,
          "note": "„Ich wusste gar nicht, dass ...“."
        },
        "23": {
          "options": [
            "besonders",
            "einfach",
            "kaum"
          ],
          "answer": 0,
          "note": "„nicht besonders gefallen“."
        },
        "24": {
          "options": [
            "allerdings",
            "außerdem",
            "schließlich"
          ],
          "answer": 2,
          "note": "„schließlich habe ich schon im Alltag genug Stress“."
        },
        "25": {
          "options": [
            "weg",
            "abgerückt",
            "entfernt"
          ],
          "answer": 2,
          "note": "„weiter entfernt“."
        },
        "26": {
          "options": [
            "ändern",
            "verwechseln",
            "wechseln"
          ],
          "answer": 2,
          "note": "„die Stelle wechseln“."
        },
        "27": {
          "options": [
            "gesagt",
            "sagend",
            "zu sagen"
          ],
          "answer": 0,
          "note": "„Ehrlich gesagt“."
        },
        "28": {
          "options": [
            "kommende",
            "kommendem",
            "kommenden"
          ],
          "answer": 2,
          "note": "„ab dem kommenden Monat“."
        },
        "29": {
          "options": [
            "als",
            "je",
            "weil"
          ],
          "answer": 1,
          "note": "„immer schwieriger, je älter man ist“."
        },
        "30": {
          "options": [
            "ist",
            "war",
            "wäre"
          ],
          "answer": 2,
          "note": "„Wie wäre es, wenn ...“."
        }
      }
    },
    {
      "id": "11",
      "num": "11",
      "page": 370,
      "isVariant": false,
      "title": "Studium und Nebenjob in der Kneipe (Hallo Ferdinand)",
      "category": "Persönliche E-Mail / Studium",
      "text": "Hallo Ferdinand,\n\nnun habe ich mich schon so lange nicht bei dir gemeldet – das tut mir wirklich leid! Ich hatte in den vergangenen Monaten viel Stress, weil ich ja nun studiere und nebenbei noch arbeiten muss, {{21}} meine Miete und alles andere bezahlen zu können. Zum Glück macht mir mein Nebenjob wenigstens Spaß. Ich weiß nicht, {{22}} ich das sonst durchhalten würde. Vielleicht habe ich dir schon erzählt, dass ich abends und am Wochenende in einer Kneipe in der Küche helfe. Das ist zwar oft sehr anstrengend, {{23}} andererseits ist dauernd was los, es wird nicht langweilig, und meine Kollegen sind total nett. Erinnerst du dich noch an unsere Zeit in der Grundschule? Mit acht Jahren wollte ich ja {{24}} Kellnerin werden, weil man da Trinkgeld bekommt. Naja, jetzt bin ich in der Küche gelandet, knapp daneben ist auch vorbei ;)\n\nWas macht denn deine Ausbildung? Wenn ich {{25}} nicht täusche, bist du ja in einem halben Jahr schon fertig, oder? Das ist ja nicht mehr lang! Neulich habe ich übrigens Tina und Kevin hier in der Nähe der Uni getroffen – die waren ja schon ein Paar, {{26}} wir noch in die Schule gegangen sind, und jetzt wollen sie tatsächlich heiraten!\n\nWie sehen denn deine Pläne für die {{27}} Wochenenden aus? Wir könnten uns ja vielleicht mal wieder treffen und in Ruhe quatschen – hättest du Lust {{28}}? In meiner Straße hat vor einem Monat ein nettes kleines Café aufgemacht, die haben nicht nur sehr leckere Kuchen, {{29}} auch einige kleine Gerichte zu wirklich günstigen Preisen. Wäre das was {{30}} dich? Mail mir doch einfach, wenn du magst, ich würde mich freuen.\n\nViele Grüße\nNadine",
      "questions": {
        "21": {
          "options": [
            "anstatt",
            "ohne",
            "um"
          ],
          "answer": 2,
          "note": "Finalsatz mit Infinitiv: „um ... bezahlen zu können“."
        },
        "22": {
          "options": [
            "dass",
            "ob",
            "während"
          ],
          "answer": 1,
          "note": "Indirekter Fragesatz nach „Ich weiß nicht, ob ...“."
        },
        "23": {
          "options": [
            "aber",
            "denn",
            "und"
          ],
          "answer": 0,
          "note": "Konzessive Struktur: „zwar ..., aber andererseits ...“."
        },
        "24": {
          "options": [
            "bestimmt",
            "unbedingt",
            "völlig"
          ],
          "answer": 1,
          "note": "Starker Wunsch: „wollte ich ja unbedingt Kellnerin werden“."
        },
        "25": {
          "options": [
            "dich",
            "mich",
            "sich"
          ],
          "answer": 1,
          "note": "Reflexivpronomen 1. Person Singular: „Wenn ich mich nicht täusche“."
        },
        "26": {
          "options": [
            "als",
            "wenn",
            "wie"
          ],
          "answer": 0,
          "note": "Zeitraum in der Vergangenheit: „als wir noch in die Schule gegangen sind“."
        },
        "27": {
          "options": [
            "baldigen",
            "kommenden",
            "vergangenen"
          ],
          "answer": 1,
          "note": "Zukünftige Wochenenden: „für die kommenden Wochenenden“."
        },
        "28": {
          "options": [
            "danach",
            "darüber",
            "dazu"
          ],
          "answer": 2,
          "note": "Lust haben auf/zu -> „hättest du Lust dazu?“"
        },
        "29": {
          "options": [
            "aber",
            "oder",
            "sondern"
          ],
          "answer": 2,
          "note": "Doppelkonjunktion: „nicht nur ..., sondern auch ...“."
        },
        "30": {
          "options": [
            "für",
            "gegen",
            "ohne"
          ],
          "answer": 0,
          "note": "Umgangssprachlich: „Wäre das was für dich?“"
        }
      }
    },
    {
      "id": "11a",
      "num": "11a",
      "page": 371,
      "isVariant": true,
      "title": "Studium und Nebenjob in der Kneipe (Hallo Philipp – Variante 11a)",
      "category": "Persönliche E-Mail / Studium",
      "text": "Hallo Philipp,\n\nnun habe ich mich schon so lange nicht bei dir gemeldet – das tut mir wirklich leid! Ich hatte in den vergangenen Monaten viel Stress, weil ich ja nun studiere und nebenbei noch arbeiten muss, {{21}} meine Miete und alles andere bezahlen zu können. Zum Glück macht mir mein Nebenjob wenigstens Spaß. Ich weiß nicht, {{22}} ich das sonst durchhalten würde. Vielleicht habe ich dir schon erzählt, dass ich abends und am Wochenende in einer Kneipe in der Küche helfe. Das ist zwar oft sehr anstrengend, {{23}} andererseits ist dauernd was los, es wird nicht langweilig, und meine Kollegen sind total nett. Erinnerst du dich noch an unsere Zeit in der Grundschule? Mit acht Jahren wollte ich ja {{24}} Kellnerin werden, weil man da Trinkgeld bekommt. Naja, jetzt bin ich in der Küche gelandet, knapp daneben ist auch vorbei ;)\n\nWas macht denn deine Ausbildung? Wenn ich {{25}} nicht täusche, bist du ja in einem halben Jahr schon fertig, oder? Das ist ja nicht mehr lang! Neulich habe ich übrigens Tina und Kevin hier in der Nähe der Uni getroffen – die waren ja schon ein Paar, {{26}} wir noch in die Schule gegangen sind, und jetzt wollen sie tatsächlich heiraten!\n\nWie sehen denn deine Pläne für die {{27}} Wochenenden aus? Wir könnten uns ja vielleicht mal wieder treffen und in Ruhe quatschen – hättest du Lust {{28}}? In meiner Straße hat vor einem Monat ein nettes kleines Café aufgemacht, die haben sehr leckere Kuchen, {{29}} auch einige kleine Gerichte zu wirklich günstigen Preisen. Wäre das was für dich? Mail mir doch {{30}}, wenn du magst, ich würde mich freuen.\n\nViele Grüße\nNadine",
      "questions": {
        "21": {
          "options": [
            "damit",
            "für",
            "um"
          ],
          "answer": 2,
          "note": "Finalsatz mit Infinitiv: „um ... bezahlen zu können“."
        },
        "22": {
          "options": [
            "wenn",
            "wie",
            "wo"
          ],
          "answer": 1,
          "note": "Indirekter Fragesatz der Art und Weise: „Ich weiß nicht, wie ich das sonst durchhalten würde.“"
        },
        "23": {
          "options": [
            "damit",
            "denn",
            "doch"
          ],
          "answer": 2,
          "note": "Gegensatz nach „zwar“: „zwar ..., doch (= aber) andererseits ...“."
        },
        "24": {
          "options": [
            "bestimmt",
            "unbedingt",
            "völlig"
          ],
          "answer": 1,
          "note": "„wollte ich ja unbedingt Kellnerin werden“."
        },
        "25": {
          "options": [
            "dich",
            "mich",
            "sich"
          ],
          "answer": 1,
          "note": "„Wenn ich mich nicht täusche“."
        },
        "26": {
          "options": [
            "als",
            "da",
            "wenn"
          ],
          "answer": 0,
          "note": "„als wir noch in die Schule gegangen sind“."
        },
        "27": {
          "options": [
            "jetzigen",
            "kommenden",
            "letzten"
          ],
          "answer": 1,
          "note": "„für die kommenden Wochenenden“."
        },
        "28": {
          "options": [
            "danach",
            "darüber",
            "dazu"
          ],
          "answer": 2,
          "note": "„hättest du Lust dazu?“"
        },
        "29": {
          "options": [
            "als",
            "ebenso",
            "oder"
          ],
          "answer": 1,
          "note": "Aufzählung ohne „nicht nur“: „die haben sehr leckere Kuchen, ebenso (= außerdem/genauso) auch einige kleine Gerichte“."
        },
        "30": {
          "options": [
            "einen",
            "einfach",
            "einzig"
          ],
          "answer": 1,
          "note": "Aufforderungspartikel: „Mail mir doch einfach, wenn du magst“."
        }
      }
    },
    {
      "id": "12",
      "num": "12",
      "page": 372,
      "isVariant": false,
      "title": "Glückwünsche zum Baby & beruflicher Wiedereinstieg (Liebe Paola)",
      "category": "Persönliche E-Mail / Familie & Beruf",
      "text": "Liebe Paola,\n\nvielen Dank für deine Nachricht und die vielen schönen Fotos. Eure Laura ist wirklich niedlich! Ich hoffe, dass wir {{21}} bald kennenlernen. Aber ich weiß, wie anstrengend die erste Zeit mit einem Baby sein kann. {{22}} warten wir lieber noch etwas, bevor wir euch besuchen. Sagt uns einfach Bescheid, {{23}} euch ein Treffen lieb wäre. Eine kleine Überraschung für eure Laura steht {{24}} jeden Fall bereit.\n\nBei uns gibt es auch einige Veränderungen. Elijah ist diesen Herbst eingeschult worden. Er kommt mit allem gut zurecht und hat auch schon Freundschaften geschlossen. Lea geht nun in den Kindergarten. {{25}} diesem Jahr sind hier im Ort Grundschule und Kindergarten in demselben Gebäudekomplex untergebracht. Das kommt uns sehr gelegen.\n\nNun ist es vormittags sehr still bei uns im Haus. Ich überlege mir, {{26}} ich nicht wieder anfangen soll, halbtags zu arbeiten. In meinen alten Beruf als Krankenschwester möchte ich aber nicht zurück, denn ich kann mir gar nicht {{27}}, wie ich den Schichtdienst im Krankenhaus und die Kinderbetreuung unter einen Hut bringen soll. Wahrscheinlich bewerbe ich mich bei einer Arztpraxis oder der Verwaltung einer Krankenkasse. Was hältst du {{28}}? Fällt dir vielleicht eine Tätigkeit ein, bei der meine Ausbildung {{29}} Krankenschwester von Vorteil wäre?\n\nWie dem auch {{30}} – ich wünsche euch viel Glück und Freude mit eurem Baby. Wenn du irgendwelche Tipps brauchst, kannst du mich jederzeit anrufen. Im Anhang schicke ich dir ein paar Fotos vom Schulanfang. Ich freue mich schon darauf, euch bald wiederzusehen.\n\nLiebe Grüße\nSarah",
      "questions": {
        "21": {
          "options": [
            "ihr",
            "Sie",
            "sie"
          ],
          "answer": 2,
          "note": "Personalpronomen Akkusativ feminin Singular für „Eure Laura“: „dass wir sie bald kennenlernen“."
        },
        "22": {
          "options": [
            "Deshalb",
            "Obwohl",
            "Trotzdem"
          ],
          "answer": 0,
          "note": "Folgerung: „Deshalb warten wir lieber noch etwas“."
        },
        "23": {
          "options": [
            "bis",
            "dann",
            "wann"
          ],
          "answer": 2,
          "note": "Indirekter Fragesatz nach Zeitpunkt: „wann euch ein Treffen lieb wäre“."
        },
        "24": {
          "options": [
            "auf",
            "im",
            "in"
          ],
          "answer": 0,
          "note": "Feste Wendung: „auf jeden Fall“."
        },
        "25": {
          "options": [
            "Seit",
            "Vom",
            "Zum"
          ],
          "answer": 0,
          "note": "Beginn in der Vergangenheit bis in die Gegenwart: „Seit diesem Jahr“."
        },
        "26": {
          "options": [
            "ob",
            "obwohl",
            "ohnehin"
          ],
          "answer": 0,
          "note": "Indirekter Fragesatz nach „überlegen“: „Ich überlege mir, ob ...“."
        },
        "27": {
          "options": [
            "verstellen",
            "vorstellen",
            "zustellen"
          ],
          "answer": 1,
          "note": "sich (Dat.) etwas vorstellen = sich etwas denken/ausmalen können."
        },
        "28": {
          "options": [
            "dafür",
            "damit",
            "davon"
          ],
          "answer": 2,
          "note": "halten von -> „Was hältst du davon?“"
        },
        "29": {
          "options": [
            "als",
            "wie",
            "zu"
          ],
          "answer": 0,
          "note": "Berufsbezeichnung mit „als“: „meine Ausbildung als Krankenschwester“."
        },
        "30": {
          "options": [
            "hätte",
            "sei",
            "wäre"
          ],
          "answer": 1,
          "note": "Feste idiomatische Wendung im Konjunktiv I: „Wie dem auch sei“."
        }
      }
    },
    {
      "id": "13",
      "num": "13",
      "page": 373,
      "isVariant": false,
      "title": "Einladung nach Köln (Lieber David)",
      "category": "Persönlicher Brief / Besuch",
      "text": "Lieber David,\n\nwas für eine schöne Überraschung, dass Du nach Deutschland kommst. Und {{21}} schöner ist es, dass Du uns besuchen willst, {{22}} Du in München zu tun hast und wir in Köln wohnen, was ja nicht so nah ist.\n\nDu bist jederzeit herzlich willkommen. Wir können für Dich ein interessantes Wochenende organisieren. Du kannst Dir den Kölner Dom {{23}} und noch ein paar andere Sehenswürdigkeiten. Und natürlich {{24}} wir genug Zeit für Gespräche haben. Die Briefe, die wir sonst schreiben, können persönliche Gespräche ja nicht ersetzen.\n\nMach dir keine Sorgen über Deinen Ausflug nach Köln. Schreib uns kurz, an welchem Tag und um welche Uhrzeit Du am Hauptbahnhof {{25}}. Wir holen Dich dort mit dem Auto ab, so dass Du Dir keine Gedanken über Bus und Straßenbahn machen musst. Warte einfach am Bahnsteig auf uns, {{26}} wir uns verspäten sollten.\n\nZu Hause erwartet Dich ein Gästezimmer. Es ist das Zimmer unseres Sohnes, der schon seit Jahren eine eigene Wohnung hat. Wir benutzen es {{27}} für ihn, wenn er zu Besuch kommt, aber auch für andere Gäste. Es wird Dir bestimmt gefallen. Wir können dann alte Erinnerungen {{28}}. Wir haben sehr viele Fotos gemacht, {{29}} wir bei Dir zu Besuch waren. Kaum zu glauben, dass inzwischen schon drei Jahre vergangen sind. Es ist in dieser Zeit viel geschehen; aber {{30}} Dich überraschen ...\n\nWir wünschen Dir eine gute Reise und freuen uns auf Deinen Besuch.\n\nViele Grüße\nKarl und Monika",
      "questions": {
        "21": {
          "options": [
            "ganz",
            "noch",
            "zwar"
          ],
          "answer": 1,
          "note": "Steigerung vor Komparativ: „noch schöner“."
        },
        "22": {
          "options": [
            "jedoch",
            "obwohl",
            "trotzdem"
          ],
          "answer": 1,
          "note": "Konzessiver Nebensatz mit Verbendstellung: „obwohl Du in München zu tun hast“."
        },
        "23": {
          "options": [
            "anschauen",
            "überschauen",
            "vorschauen"
          ],
          "answer": 0,
          "note": "sich (Dat.) etwas anschauen = besichtigen."
        },
        "24": {
          "options": [
            "konnten",
            "sollten",
            "wollen"
          ],
          "answer": 2,
          "note": "Absicht für das gemeinsame Wochenende: „Und natürlich wollen (bzw. sollten) wir genug Zeit für Gespräche haben.“"
        },
        "25": {
          "options": [
            "ankommen wirst",
            "anzukommen wirst",
            "wirst ankommen"
          ],
          "answer": 0,
          "note": "Nebensatz im Futur I: Infinitiv + konjugiertes Hilfsverb am Ende („ankommen wirst“)."
        },
        "26": {
          "options": [
            "falls",
            "für den Fall",
            "im Fall"
          ],
          "answer": 0,
          "note": "Konditionale Konjunktion: „falls wir uns verspäten sollten“."
        },
        "27": {
          "options": [
            "neulich",
            "seitdem",
            "vormals"
          ],
          "answer": 1,
          "note": "„seitdem“ (= seit er ausgezogen ist)."
        },
        "28": {
          "options": [
            "auffrischen",
            "aufholen",
            "aufsparen"
          ],
          "answer": 0,
          "note": "Feste Kollokation: „alte Erinnerungen auffrischen“."
        },
        "29": {
          "options": [
            "als",
            "wann",
            "wo"
          ],
          "answer": 0,
          "note": "Einmaliges Ereignis in der Vergangenheit: „als wir bei Dir zu Besuch waren“."
        },
        "30": {
          "options": [
            "geh",
            "komm",
            "lass"
          ],
          "answer": 2,
          "note": "Feste Wendung im Imperativ: „lass Dich überraschen!“"
        }
      }
    },
    {
      "id": "13a",
      "num": "13a",
      "page": 374,
      "isVariant": true,
      "title": "Einladung nach Köln (Lieber David – Variante 13a)",
      "category": "Persönlicher Brief / Besuch",
      "text": "Lieber David,\n\nwas für eine schöne Überraschung, dass Du nach Deutschland kommst. Und {{21}} schöner ist es, dass Du uns besuchen willst, {{22}} Du in München zu tun hast und wir in Köln wohnen, was ja nicht so nah ist.\n\nDu bist jederzeit herzlich willkommen. Wir können für Dich ein interessantes Wochenende organisieren. Du kannst Dir den Kölner Dom {{23}} und noch ein paar andere Sehenswürdigkeiten. Und natürlich {{24}} wir genug Zeit für Gespräche haben. Die Briefe, die wir sonst schreiben, können persönliche Gespräche ja nicht ersetzen.\n\nMach dir keine Sorgen über Deinen Ausflug nach Köln. Schreib uns kurz, an welchem Tag und um welche Uhrzeit Du am Hauptbahnhof {{25}}. Wir holen Dich dort mit dem Auto ab, so dass Du Dir keine Gedanken über Bus und Straßenbahn machen musst. Warte einfach am Bahnsteig auf uns, {{26}} wir uns verspäten sollten.\n\nZu Hause erwartet Dich ein Gästezimmer. Es ist das Zimmer unseres Sohnes, der schon seit Jahren eine eigene Wohnung hat. Wir benutzen es {{27}} für ihn, wenn er zu Besuch kommt, aber auch für andere Gäste. Es wird Dir bestimmt gefallen. Wir können dann alte Erinnerungen {{28}}. Wir haben sehr viele Fotos gemacht, {{29}} wir bei Dir zu Besuch waren. {{30}} zu glauben, dass inzwischen schon drei Jahre vergangen sind. Es ist in dieser Zeit viel geschehen; aber lass Dich überraschen ...\n\nWir wünschen Dir eine gute Reise und freuen uns auf Deinen Besuch.\n\nViele Grüße\nKarl und Monika",
      "questions": {
        "21": {
          "options": [
            "ganz",
            "noch",
            "zwar"
          ],
          "answer": 1,
          "note": "„Und noch schöner ist es“."
        },
        "22": {
          "options": [
            "jedoch",
            "obwohl",
            "trotzdem"
          ],
          "answer": 1,
          "note": "„obwohl Du in München zu tun hast“."
        },
        "23": {
          "options": [
            "anschauen",
            "überschauen",
            "vorschauen"
          ],
          "answer": 0,
          "note": "„den Kölner Dom anschauen“."
        },
        "24": {
          "options": [
            "konnten",
            "sollten",
            "wollten"
          ],
          "answer": 1,
          "note": "Unter den Optionen (konnten / sollten / wollten) passt für die Zukunft nur „sollten“."
        },
        "25": {
          "options": [
            "ankommen wirst",
            "anzukommen wirst",
            "wirst ankommen"
          ],
          "answer": 0,
          "note": "Verbendstellung im Nebensatz: „ankommen wirst“."
        },
        "26": {
          "options": [
            "falls",
            "für den Fall",
            "im Fall"
          ],
          "answer": 0,
          "note": "„falls wir uns verspäten sollten“."
        },
        "27": {
          "options": [
            "neulich",
            "seitdem",
            "vormals"
          ],
          "answer": 1,
          "note": "„Wir benutzen es seitdem für ihn“."
        },
        "28": {
          "options": [
            "auffrischen",
            "aufholen",
            "aufsparen"
          ],
          "answer": 0,
          "note": "„alte Erinnerungen auffrischen“."
        },
        "29": {
          "options": [
            "als",
            "wann",
            "wo"
          ],
          "answer": 0,
          "note": "„als wir bei Dir zu Besuch waren“."
        },
        "30": {
          "options": [
            "Fast",
            "Kaum",
            "Wohl"
          ],
          "answer": 1,
          "note": "Feste Wendung: „Kaum zu glauben, dass ...“."
        }
      }
    },
    {
      "id": "14",
      "num": "14",
      "page": 375,
      "isVariant": false,
      "title": "Abschied vor dem Umzug nach Dubai (Liebe Lara)",
      "category": "Persönlicher Brief / Umzug ins Ausland",
      "text": "Liebe Lara,\n\nbitte verzeih mir, dass ich erst jetzt auf {{21}} Brief antworte. Ich hatte in den letzten Wochen praktisch keine freie Minute und kam einfach nicht dazu, dir zu schreiben. Jetzt aber tue ich es, {{22}} du wirklich tolle Neuigkeiten mitzuteilen hast. Schon immer hast du von großen Abenteuern und Reisen in die Ferne geträumt. Ich weiß {{23}} gut, wie wir uns als Gymnasiasten fremde Länder ausgemalt haben. Nun verschlägt es dich und deine Familie also nach Dubai – und du sagst unserem Land für einige Zeit Adieu. Ich weiß, dass mit dieser Versetzung für dich ein Traum in Erfüllung geht. {{24}} deinen Neubeginn wünschen Peter und ich dir alles Gute. Wir freuen uns auch sehr, dass ihr alle gesund und munter seid und hoffen, dass das so bleibt.\n\nBei uns geht mehr oder weniger alles seinen gewohnten Gang. Robert gefällt es gut auf seiner {{25}} Stelle. Er muss sich einfach noch einarbeiten. Lorenz ist jetzt 15. Du weißt {{26}}, was das heißt. Er hält sich für den Größten und macht uns viele Schwierigkeiten. Aber irgendwann geht auch das vorüber. Sandra ist jetzt auch schon in der dritten Klasse und bringt gute Noten nach Hause. {{27}} sind wir natürlich stolz.\n\nEs {{28}} schön, wenn wir uns vor deiner Abreise noch einmal treffen würden. Vielleicht findet ihr {{29}} der Umzugsvorbereitungen noch Zeit. Wie wäre es mit einem gemeinsamen Sonntagsbrunch in unserem Garten? Bitte melde dich doch, damit wir etwas abmachen {{30}}.\n\nLiebe Grüße\ndeine Vanessa",
      "questions": {
        "21": {
          "options": [
            "dein",
            "deine",
            "deinen"
          ],
          "answer": 2,
          "note": "antworten auf (+ Akkusativ Maskulinum): „auf deinen Brief“."
        },
        "22": {
          "options": [
            "denn",
            "obwohl",
            "weil"
          ],
          "answer": 2,
          "note": "Kausaler Nebensatz mit Verbendstellung („mitzuteilen hast“): „weil“."
        },
        "23": {
          "options": [
            "noch",
            "schon",
            "weiterhin"
          ],
          "answer": 0,
          "note": "Erinnerung an früher: „Ich weiß noch gut, wie ...“."
        },
        "24": {
          "options": [
            "Für",
            "Vor",
            "Zu"
          ],
          "answer": 0,
          "note": "„Für deinen Neubeginn wünschen wir dir alles Gute“ (Akkusativ „deinen Neubeginn“)."
        },
        "25": {
          "options": [
            "neue",
            "neuen",
            "neuer"
          ],
          "answer": 1,
          "note": "Dativ feminin Singular nach Possessivartikel „seiner“: „auf seiner neuen Stelle“."
        },
        "26": {
          "options": [
            "bloß",
            "ja",
            "mal"
          ],
          "answer": 1,
          "note": "Modalpartikel „ja“ verweist auf gemeinsames Wissen: „Du weißt ja, was das heißt.“"
        },
        "27": {
          "options": [
            "Damit",
            "Darauf",
            "Darüber"
          ],
          "answer": 1,
          "note": "stolz sein auf (+ Akkusativ) -> „Darauf sind wir natürlich stolz.“"
        },
        "28": {
          "options": [
            "ist",
            "wäre",
            "würde"
          ],
          "answer": 1,
          "note": "Konjunktiv II: „Es wäre schön, wenn ...“."
        },
        "29": {
          "options": [
            "aufgrund",
            "trotz",
            "wegen"
          ],
          "answer": 1,
          "note": "Konzessive Präposition: „trotz der Umzugsvorbereitungen noch Zeit finden“."
        },
        "30": {
          "options": [
            "können",
            "könnten",
            "konnten"
          ],
          "answer": 0,
          "note": "Finalsatz im Präsens: „damit wir etwas abmachen können“."
        }
      }
    },
    {
      "id": "15",
      "num": "15",
      "page": 376,
      "isVariant": false,
      "title": "Einladung nach Steyr (Liebe Lina, lieber Florian)",
      "category": "Persönliche E-Mail / Einladung & Stadtbesichtigung",
      "text": "Liebe Lina, lieber Florian,\n\nnun sind wir schon einige Monate in unserer neuen Wohnung, und ihr habt uns noch immer nicht besucht. Ihr {{21}} doch endlich unser neues Heim und unsere kleine Stadt kennenlernen. Deshalb möchten wir euch {{22}} das verlängerte Wochenende Anfang Juni einladen. Wenn ihr am Donnerstagabend anreist, haben wir drei ganze Tage zur Verfügung. Wohnen könnt ihr natürlich {{23}} uns. Emma fährt im Juni in Urlaub, und sie überlässt euch gern ihr Zimmer.\n\nDie Stadt Steyr hat {{24}} zu bieten. Wir können eine Führung durch die historische Altstadt machen, die romantischen Innenhöfe besichtigen und auf {{25}} Turm der Stadtpfarrkirche steigen. Da geht es über 228 Stufen 60 Meter hinauf. Bei einem längeren Rundgang {{26}} auch die wunderbare Schlossbibliothek und das Tapetenzimmer zu besichtigen. Besonders interessant ist die Runde durch den Wehrgraben, {{27}} man an den alten Bauten den Wandel der Industrie nachvollziehen kann. {{28}} erfährt man alles über die Eisenindustrie, die den Reichtum der Stadt begründet hat.\n\nAußerdem finden an {{29}} Wochenende die jährlichen Literaturtage statt. Bei dieser Veranstaltung präsentieren zeitgenössische Autorinnen und Autoren ihre Neuerscheinungen. Die Lesungen finden zum Großteil in den prächtigen Arkadenhöfen statt. Die Stimmung dort ist wirklich eine ganz besondere. Lina, das wäre doch was für dich, oder?\n\nAuch die Umgebung kann {{30}} sehen lassen. Praktisch vor den Toren der Stadt beginnt der Nationalpark Kalkalpen. Dort kann man wunderbar wandern und Rad fahren. Ihr könnt in der Stadt auch Räder ausleihen.\n\nWir hoffen sehr, dass ihr noch keine Pläne für das Wochenende habt und zu uns kommen könnt.\n\nViele liebe Grüße und hoffentlich bis bald!\nChiara und Mark",
      "questions": {
        "21": {
          "options": [
            "dürft",
            "könnt",
            "sollt"
          ],
          "answer": 2,
          "note": "Freundliche Aufforderung: „Ihr sollt doch endlich unser neues Heim kennenlernen.“"
        },
        "22": {
          "options": [
            "an",
            "für",
            "in"
          ],
          "answer": 1,
          "note": "Zeitraum im Akkusativ („das verlängerte Wochenende“): „für das verlängerte Wochenende einladen“."
        },
        "23": {
          "options": [
            "bei",
            "unter",
            "zu"
          ],
          "answer": 0,
          "note": "Ortsangabe bei Personen: „bei uns wohnen“."
        },
        "24": {
          "options": [
            "einige",
            "einigen",
            "einiges"
          ],
          "answer": 2,
          "note": "Indefinitpronomen Neutrum: „hat einiges (= viel Interessantes) zu bieten“."
        },
        "25": {
          "options": [
            "dem",
            "den",
            "der"
          ],
          "answer": 1,
          "note": "Richtung (wohin?) -> Akkusativ Maskulinum: „auf den Turm steigen“."
        },
        "26": {
          "options": [
            "ist",
            "sind",
            "waren"
          ],
          "answer": 1,
          "note": "Subjekt im Plural („die Schlossbibliothek und das Tapetenzimmer“): „sind ... zu besichtigen“."
        },
        "27": {
          "options": [
            "wann",
            "wie",
            "wo"
          ],
          "answer": 2,
          "note": "Relativadverb für einen Ort („durch den Wehrgraben, wo man ...“)."
        },
        "28": {
          "options": [
            "Dabei",
            "Daneben",
            "Darin"
          ],
          "answer": 0,
          "note": "„Dabei“ (= bei dieser Runde / Gelegenheit)."
        },
        "29": {
          "options": [
            "dies",
            "diesem",
            "dieses"
          ],
          "answer": 1,
          "note": "Dativ Neutrum Singular nach „an“: „an diesem Wochenende“."
        },
        "30": {
          "options": [
            "man",
            "sich",
            "Sie"
          ],
          "answer": 1,
          "note": "Feste Redewendung: „etwas kann sich sehen lassen“ (= ist sehr ansehnlich/beeindruckend)."
        }
      }
    },
    {
      "id": "16",
      "num": "16",
      "page": 377,
      "isVariant": false,
      "title": "Urlaub im Allgäu mit der Gastfamilie (Liebe Vanessa)",
      "category": "Persönlicher Brief / Au-pair-Alltag",
      "text": "Liebe Vanessa,\n\ndanke für deinen Brief, {{21}} ich mich total gefreut habe. Du fragst dich bestimmt, warum du schon drei Wochen {{22}} von mir gehört hast, oder? Ich war mit meiner Gastfamilie in Urlaub. Vierzehn Tage im Allgäu – mit den Kindern Stefan, Anja und Karina. Du weißt {{23}} selbst, wie anstrengend es ist, wenn man ständig drei kleine Kinder um sich hat, die pausenlos unterhalten werden möchten. {{24}} ist es übrigens in deiner Au-pair-Familie mit der kleinen Dorothea?\n\nDas Allgäu liegt in Süddeutschland am Fuß {{25}} Alpen. Wir sind fast jeden Tag gewandert, immer bergauf und bergab. Den Kindern und mir haben ständig die Füße weh {{26}}, doch meine Gasteltern, Herr und Frau Zimmer, sind einfach immer weitergelaufen. Die Deutschen lieben es nämlich, in der Natur spazieren zu gehen, bis sie vor Erschöpfung {{27}}. Unterwegs haben wir manchmal an einer sogenannten „Wassertretstelle“ Rast gemacht. Das sind kleine Wasserbecken, die oft mitten im Wald liegen. Durch das Becken fließt ein Bach mit eiskaltem Wasser, das direkt von den Bergen kommt. Stell {{28}} vor, alle Wanderer ziehen ihre Schuhe und Strümpfe aus und laufen durch dieses Becken. Als ich meinen Fuß in dieses kalte Wasser getaucht hatte, dachte ich, dass ich gleich sterben muss.\n\nAm Wochenende haben wir alle Minigolf gespielt. Dabei muss ein Golfball mit einem Schläger in ein etwa zehn Meter entferntes Loch geschlagen werden. Aber vor dem Loch gibt es {{29}} Menge Hindernisse: Gräben, kleine Hügel, Tunnel. Der Spieler, dessen Ball mit den wenigsten Schlägen im Loch ankommt, hat gewonnen. Die Kinder wollten gar nicht mehr {{30}} aufhören.\n\nJetzt muss ich aber Schluss machen, die Kinder warten auf ihr Abendessen, denn die Zimmers sind heute nicht da: Sie wandern mal wieder.\n\nViele Grüße\ndeine Mercedes",
      "questions": {
        "21": {
          "options": [
            "an den",
            "auf dem",
            "über den"
          ],
          "answer": 2,
          "note": "sich freuen über (+ Akkusativ): „deinen Brief, über den ich mich gefreut habe“."
        },
        "22": {
          "options": [
            "nichts mehr",
            "noch nicht",
            "keines"
          ],
          "answer": 0,
          "note": "„warum du schon drei Wochen nichts mehr (im PDF: nicht mehr) von mir gehört hast“."
        },
        "23": {
          "options": [
            "doch",
            "eben",
            "überhaupt"
          ],
          "answer": 0,
          "note": "Modalpartikel „doch“ appelliert an gemeinsame Erfahrung: „Du weißt doch selbst ...“."
        },
        "24": {
          "options": [
            "Wann",
            "Was",
            "Wie"
          ],
          "answer": 2,
          "note": "Frage nach dem Befinden/Zustand: „Wie ist es übrigens in deiner Au-pair-Familie?“"
        },
        "25": {
          "options": [
            "der",
            "die",
            "von"
          ],
          "answer": 0,
          "note": "Genitiv Plural: „am Fuß der Alpen“."
        },
        "26": {
          "options": [
            "gelaufen",
            "getan",
            "geworden"
          ],
          "answer": 1,
          "note": "Partizip II von „wehtun“: „haben die Füße wehgetan / weh getan“."
        },
        "27": {
          "options": [
            "durchfallen",
            "umfallen",
            "wegfallen"
          ],
          "answer": 1,
          "note": "Redewendung: „vor Erschöpfung umfallen“."
        },
        "28": {
          "options": [
            "dich",
            "dir",
            "mal"
          ],
          "answer": 1,
          "note": "Dativ-Reflexivpronomen beim Imperativ: „Stell dir vor!“"
        },
        "29": {
          "options": [
            "alle",
            "ganze",
            "jede"
          ],
          "answer": 2,
          "note": "Feste Wendung: „jede Menge Hindernisse“ (= sehr viele)."
        },
        "30": {
          "options": [
            "dabei",
            "damit",
            "davon"
          ],
          "answer": 1,
          "note": "aufhören mit -> Pronominaladverb „damit aufhören“."
        }
      }
    },
    {
      "id": "17",
      "num": "17",
      "page": 378,
      "isVariant": false,
      "title": "Zusage zur Hochzeitseinladung (Liebe Maria, lieber Timur)",
      "category": "Persönlicher Brief / Hochzeitseinladung",
      "text": "Liebe Maria, lieber Timur,\n\nherzlichen Dank für die Einladung zu eurem Hochzeitsfest! Nachdem wir gestern aus dem Urlaub zurückgekommen {{21}}, haben wir euren Brief und die Einladungskarte im Briefkasten entdeckt. {{22}} gibt es nicht viel zu überlegen: Natürlich kommen wir sehr gerne! Wir freuen uns sehr {{23}} euch, dass ihr nun endlich diesen Schritt wagt. Es ist eine geniale Idee, {{24}} in der Türkei als auch in Österreich zu feiern. So können alle Freunde und {{25}} dabei sein. Wir hoffen, dass wir einige {{26}} alten Freunde wiedersehen werden.\n\nIhr habt geschrieben, dass Timurs Eltern und seine Schwestern auch in Österreich sein werden. Endlich lernen wir auch Timurs Familie kennen! Und wie schön, dass ihr in Marias Heimatdorf im Mühlviertel feiert! Wir erinnern uns noch oft an die langen Partynächte, die wir dort {{27}} Jugendliche gemeinsam verbracht haben.\n\nNun überlegen wir, {{28}} wir nicht gleich ein Hotelzimmer für einige Tage buchen sollten. Ihr habt ja sicher mit den Vorbereitungen alle Hände voll zu {{29}}. Dann können wir am Freitag wandern gehen. Am Samstag ist dann euer Fest und am Sonntag {{30}} wir die Gelegenheit, vor der Abreise noch gemütlich zusammen zu frühstücken. In welchem Hotel habt ihr eure Verwandten untergebracht? Seid ihr auch in einem Hotel, oder übernachtet ihr bei deinen Eltern, Maria? Nun, das können wir alles noch später besprechen.\n\nVorerst freuen wir uns einfach nur auf euch und euer Fest. Noch einmal vielen Dank für die Einladung und bis bald!\n\nYasmin & Peter",
      "questions": {
        "21": {
          "options": [
            "seien",
            "sind",
            "waren"
          ],
          "answer": 1,
          "note": "Im PDF-Schlüssel ist B) „sind“ markiert (umgangssprachlich Perfekt nach „nachdem“, da der Hauptsatz im Perfekt steht; standardsprachlich auch „waren“)."
        },
        "22": {
          "options": [
            "Da",
            "Das",
            "Dass"
          ],
          "answer": 0,
          "note": "„Da gibt es nicht viel zu überlegen“ (= Hierbei / In diesem Fall)."
        },
        "23": {
          "options": [
            "an",
            "auf",
            "für"
          ],
          "answer": 2,
          "note": "„Wir freuen uns sehr für euch, dass ...“ (= Mitfreude)."
        },
        "24": {
          "options": [
            "je ... desto",
            "sowohl ... als auch",
            "weder ... noch"
          ],
          "answer": 1,
          "note": "„sowohl in der Türkei als auch in Österreich“."
        },
        "25": {
          "options": [
            "Verwandte",
            "Verwandten",
            "Verwandter"
          ],
          "answer": 0,
          "note": "Parallel zu „Freunde“: „alle Freunde und Verwandte“."
        },
        "26": {
          "options": [
            "unsere",
            "unseren",
            "unserer"
          ],
          "answer": 2,
          "note": "Partitiver Genitiv Plural nach „einige“: „einige unserer alten Freunde“."
        },
        "27": {
          "options": [
            "als",
            "für",
            "wie"
          ],
          "answer": 0,
          "note": "„als Jugendliche“ (= in unserer Jugendzeit)."
        },
        "28": {
          "options": [
            "dass",
            "falls",
            "ob"
          ],
          "answer": 2,
          "note": "Indirekter Fragesatz nach „überlegen“: „überlegen wir, ob ...“."
        },
        "29": {
          "options": [
            "bereiten",
            "machen",
            "tun"
          ],
          "answer": 2,
          "note": "Feste Redewendung: „alle Hände voll zu tun haben“."
        },
        "30": {
          "options": [
            "hätten",
            "könnten",
            "sollten"
          ],
          "answer": 0,
          "note": "Konjunktiv II von „haben“: „hätten wir die Gelegenheit“."
        }
      }
    },
    {
      "id": "18",
      "num": "18",
      "page": 379,
      "isVariant": false,
      "title": "Zum ersten Mal Ski gefahren (Lieber Ramon)",
      "category": "Persönliche E-Mail / Wintersport",
      "text": "Lieber Ramon,\n\nich muss dir unbedingt etwas erzählen: Ich bin heute das erste Mal in meinem Leben Ski gefahren, {{21}} ich mir das bisher nie zugetraut hatte. Meine Freundin Lisa hat mich eingeladen, einige Tage mit ihr und ihren Eltern in den Bergen zu verbringen. Und bevor ich ankam, {{22}} sie schon einen individuellen Skikurs für mich gebucht! Du kannst dir vorstellen, wie mich das überrascht hat! Ich {{23}} es mir schon anders überlegen, aber Lisa wollte nichts {{24}} hören.\n\nHeute Morgen ging es dann los. {{25}} war ich ziemlich aufgeregt, andererseits habe ich mich auch unheimlich gefreut. Mit der Skilehrerin habe ich mich gleich gut verstanden. Sie hat mich abgeholt und mir {{26}} geholfen, im Sportgeschäft Schuhe, Skier, Stöcke und einen Helm für mich {{27}}. Dann hat mir die Skilehrerin einige {{28}} Dinge erklärt. Ich war anfangs sehr unsicher, mit der Zeit ließ das aber nach. Die Kinder im Zwergerlkurs scheinen {{29}} Gegensatz zu mir überhaupt keine Angst zu haben.\n\nDas Schlimmste am ersten Tag war der Schlepplift. Erst habe ich den Lift einige Male verpasst, dann bin ich hingefallen. Irgendwie habe ich es dann doch noch geschafft. Und zum Schluss bin ich mit der Lehrerin sogar eine leichte Piste runtergefahren.\n\nMorgen habe ich wieder zwei Stunden. Ich habe jetzt schon Muskelkater und mir tut alles weh! Ich weiß gar nicht, {{30}} ich das schaffen soll. Ich werde dich über meine Fortschritte auf dem Laufenden halten :)\n\nBis bald und liebe Grüße\nSamira",
      "questions": {
        "21": {
          "options": [
            "obwohl",
            "trotz",
            "während"
          ],
          "answer": 0,
          "note": "Konzessivsatz mit Verbendstellung: „obwohl ich mir das bisher nie zugetraut hatte“."
        },
        "22": {
          "options": [
            "hat",
            "hatte",
            "hätte"
          ],
          "answer": 1,
          "note": "Vorzeitigkeit in der Vergangenheit („bevor ich ankam“): Plusquamperfekt „hatte ... gebucht“."
        },
        "23": {
          "options": [
            "konnte",
            "sollte",
            "wollte"
          ],
          "answer": 2,
          "note": "Absicht in der Vergangenheit: „Ich wollte es mir schon anders überlegen“."
        },
        "24": {
          "options": [
            "dafür",
            "damit",
            "davon"
          ],
          "answer": 2,
          "note": "Feste Wendung: „nichts davon hören wollen“."
        },
        "25": {
          "options": [
            "Einerseits ... andererseits",
            "Weder ... noch",
            "Zwar ... aber"
          ],
          "answer": 0,
          "note": "Zweiteilige Konjunktion mit Inversion in beiden Teilsätzen: „Einerseits war ich ..., andererseits habe ich ...“."
        },
        "26": {
          "options": [
            "dabei",
            "davon",
            "dazu"
          ],
          "answer": 0,
          "note": "helfen bei -> Pronominaladverb „mir dabei geholfen, ... auszusuchen“."
        },
        "27": {
          "options": [
            "aussuchen",
            "ausgesucht",
            "auszusuchen"
          ],
          "answer": 2,
          "note": "Infinitiv mit „zu“ bei trennbarem Verb: „auszusuchen“."
        },
        "28": {
          "options": [
            "grundlegende",
            "grundlegenden",
            "grundlegender"
          ],
          "answer": 0,
          "note": "Nach „einige“ im Akkusativ Plural starke Adjektivdeklination: „einige grundlegende Dinge“."
        },
        "29": {
          "options": [
            "am",
            "im",
            "zum"
          ],
          "answer": 1,
          "note": "Feste Verbindung: „im Gegensatz zu mir“."
        },
        "30": {
          "options": [
            "dass",
            "ob",
            "wie"
          ],
          "answer": 2,
          "note": "„Ich weiß gar nicht, wie ich das schaffen soll.“"
        }
      }
    },
    {
      "id": "18a",
      "num": "18a",
      "page": 380,
      "isVariant": true,
      "title": "Zum ersten Mal Ski gefahren (Lieber Thomas – Variante 18a)",
      "category": "Persönliche E-Mail / Wintersport",
      "text": "Lieber Thomas,\n\nich muss dir unbedingt etwas erzählen: Ich bin heute das erste Mal in meinem Leben Ski gefahren, {{21}} ich mir das bisher nie zugetraut hatte. Meine Freundin Lisa hat mich eingeladen, einige Tage mit ihr und ihren Eltern in den Bergen zu verbringen. Und bevor ich ankam, {{22}} sie schon einen individuellen Skikurs für mich gebucht! Du kannst dir vorstellen, wie mich das überrascht hat! Ich {{23}} es mir schon anders überlegen, aber Lisa wollte nichts {{24}} hören.\n\nHeute Morgen ging es dann los. {{25}} war ich ziemlich aufgeregt, andererseits habe ich mich auch unheimlich gefreut. Mit der Skilehrerin habe ich mich gleich gut verstanden. Sie hat mich abgeholt und mir {{26}} geholfen, im Sportgeschäft Schuhe, Skier, Stöcke und einen Helm für mich {{27}}. Dann hat mir die Skilehrerin einige {{28}} Dinge erklärt. Ich war anfangs sehr unsicher, mit der Zeit ließ das aber nach. Die Kinder im Zwergerlkurs scheinen {{29}} Gegensatz zu mir überhaupt keine Angst zu haben.\n\nDas Schlimmste am ersten Tag war der Schlepplift. Erst habe ich den Lift einige Male verpasst, dann bin ich hingefallen. Irgendwie habe ich es dann doch noch geschafft. Und zum Schluss bin ich mit der Lehrerin sogar eine leichte Piste runtergefahren.\n\nMorgen habe ich wieder zwei Stunden. Ich habe jetzt schon Muskelkater und mir tut alles weh! Ich weiß gar nicht, {{30}} ich das schaffen soll. Ich werde dich über meine Fortschritte auf dem Laufenden halten :)\n\nBis bald und liebe Grüße\nSamira",
      "questions": {
        "21": {
          "options": [
            "obwohl",
            "trotz",
            "während"
          ],
          "answer": 0,
          "note": "Konzessiver Nebensatz: „obwohl ich mir das bisher nie zugetraut hatte“."
        },
        "22": {
          "options": [
            "hat",
            "hatte",
            "hätte"
          ],
          "answer": 1,
          "note": "Plusquamperfekt für Vorzeitigkeit: „hatte ... gebucht“."
        },
        "23": {
          "options": [
            "konnte",
            "sollte",
            "wollte"
          ],
          "answer": 2,
          "note": "„Ich wollte es mir schon anders überlegen“."
        },
        "24": {
          "options": [
            "dafür",
            "damit",
            "davon"
          ],
          "answer": 2,
          "note": "„Lisa wollte nichts davon hören.“"
        },
        "25": {
          "options": [
            "Einerseits ... andererseits",
            "Weder ... noch",
            "Zwar ... aber"
          ],
          "answer": 0,
          "note": "„Einerseits war ich ..., andererseits habe ich ...“."
        },
        "26": {
          "options": [
            "dabei",
            "davon",
            "dazu"
          ],
          "answer": 0,
          "note": "„mir dabei geholfen“."
        },
        "27": {
          "options": [
            "aussuchen",
            "ausgesucht",
            "auszusuchen"
          ],
          "answer": 2,
          "note": "Infinitiv mit „zu“: „auszusuchen“."
        },
        "28": {
          "options": [
            "grundlegende",
            "grundlegenden",
            "grundlegender"
          ],
          "answer": 0,
          "note": "„einige grundlegende Dinge“."
        },
        "29": {
          "options": [
            "am",
            "im",
            "zum"
          ],
          "answer": 1,
          "note": "„im Gegensatz zu mir“."
        },
        "30": {
          "options": [
            "dass",
            "ob",
            "wie"
          ],
          "answer": 2,
          "note": "„Ich weiß gar nicht, wie ich das schaffen soll.“"
        }
      }
    },
    {
      "id": "19",
      "num": "19",
      "page": 381,
      "isVariant": false,
      "title": "Abschiedsgeschenk zur Pensionierung (Hallo Judith / Lina)",
      "category": "E-Mail unter Kollegen / Büro",
      "text": "Hallo Judith,\n\nwir haben uns ja lange nicht gesehen. Ich hoffe, du hattest einen richtig schönen Urlaub in Kroatien! Danke auch für deine Urlaubskarte! Die hat mich echt neidisch gemacht; ich habe ja erst im September Urlaub.\n\n{{21}} rufst du heute schon deine E-Mails ab und liest diese Nachricht von mir! Wir, als das gesamte Team, möchten {{22}} unserer Kollegin Elena zu ihrer Pensionierung gemeinsam etwas zum Abschied schenken. Ihre Abschiedsfeier ist ja {{23}} übermorgen abends im großen Konferenzraum unserer Firma. Bist du {{24}} einverstanden, dass wir ihr zusammen einen Gutschein und einen Blumenstrauß schenken? Jeder zahlt etwa 10 € dazu. Ich denke, das ist angemessen. Du erinnerst dich: {{25}} wir das letzte Mal gesammelt hatten, gab es Beschwerden wegen der Höhe des Betrags. Aber möglicherweise hast du eine bessere Idee.\n\nMichael und ich gehen dann nachmittags {{26}} in der Stadt einkaufen. Die Glückwunschkarte für Elena könntest du dann übermorgen noch {{27}} vor der Feier unterschreiben. Wir treffen uns ja alle vorher und gehen gemeinsam hin.\n\nIn der Firma war heute nicht viel los. Aber in den letzten 14 Tagen hatten viele Kollegen Urlaub, {{28}} ich sehr viel zu tun hatte. Es gibt übrigens auch {{29}} neue Entwicklungen in der Firma, von denen ich dir dann übermorgen erzählen kann.\n\nWahrscheinlich bist du nach der langen Fahrt sehr müde. Schlaf dich morgen gut aus; wir sehen uns dann auf Elenas Feier! Ich wünsche dir heute einen {{30}} Tag ...\n\nLiebe Grüße\nCosima",
      "questions": {
        "21": {
          "options": [
            "Zuversichtlich",
            "Möglichst",
            "Hoffentlich"
          ],
          "answer": 2,
          "note": "Satzadverb zum Ausdruck einer Hoffnung: „Hoffentlich rufst du heute schon deine E-Mails ab!“"
        },
        "22": {
          "options": [
            "vermutlich",
            "nämlich",
            "bestimmt"
          ],
          "answer": 1,
          "note": "Begründende Partikel „nämlich“ erklärt, warum die E-Mail heute wichtig ist."
        },
        "23": {
          "options": [
            "schon",
            "fast",
            "beinahe"
          ],
          "answer": 0,
          "note": "„Ihre Abschiedsfeier ist ja schon (= bereits) übermorgen.“"
        },
        "24": {
          "options": [
            "damit",
            "dafür",
            "dadurch"
          ],
          "answer": 0,
          "note": "einverstanden sein mit -> „Bist du damit einverstanden, dass ...“."
        },
        "25": {
          "options": [
            "Wenn",
            "Wann",
            "Als"
          ],
          "answer": 2,
          "note": "Einmaliges Ereignis in der Vergangenheit („das letzte Mal“): „Als wir das letzte Mal gesammelt hatten“."
        },
        "26": {
          "options": [
            "zueinander",
            "voneinander",
            "miteinander"
          ],
          "answer": 2,
          "note": "„miteinander“ (= zusammen / gemeinsam)."
        },
        "27": {
          "options": [
            "vor kurzem",
            "kürzlich",
            "kurz"
          ],
          "answer": 2,
          "note": "Zeitangabe: „kurz vor der Feier“."
        },
        "28": {
          "options": [
            "weshalb",
            "insofern",
            "deshalb"
          ],
          "answer": 0,
          "note": "Weiterführender Nebensatz mit Verbendstellung („zu tun hatte“): „weshalb“."
        },
        "29": {
          "options": [
            "vollkommen",
            "sämtlich",
            "erschöpfend"
          ],
          "answer": 0,
          "note": "Adverb vor Adjektiv: „vollkommen (= völlig) neue Entwicklungen“."
        },
        "30": {
          "options": [
            "passenden",
            "bequemen",
            "angenehmen"
          ],
          "answer": 2,
          "note": "Feste Grußformel: „Ich wünsche dir einen angenehmen Tag.“"
        }
      }
    },
    {
      "id": "20",
      "num": "20",
      "page": 382,
      "isVariant": false,
      "title": "Abschlussprüfung in Deutsch (Liebe Agnieszka)",
      "category": "Persönlicher Brief / Sprachprüfung & Au-pair",
      "text": "Liebe Agnieszka,\n\njetzt ist es schon bald ein halbes Jahr {{21}}, dass ich dir das letzte Mal geschrieben habe. Bitte denke jetzt nicht, dass ich dich vergessen habe. Aber, wie du ja schon weißt, stehe ich vor der Abschlussprüfung in Deutsch und das bedeutet jede Menge Arbeit und Stress.\n\nStell dir vor, ausgerechnet jetzt, nur zwei Wochen vor der Prüfung, ist unsere Lehrerin, Frau Reuter, {{22}}. Sie liegt sogar im Krankenhaus und kommt erst wieder zurück, {{23}} unsere Prüfung schon längst vorbei ist. Ihre Vertretung, Frau Eichhorn, ist {{24}} sehr nett, aber sie hat gerade erst mit dem Unterrichten angefangen und noch keine Erfahrung. Das macht uns alle ein bisschen unsicher. Aber in zwei Wochen ist hoffentlich alles geschafft. Und dann {{25}} ich alle Bücher und Hefte in die Ecke legen und erst einmal ein paar Tage gar nichts tun. {{26}} freue ich mich schon riesig. Wenn du Zeit und Lust hast, kannst du mich doch besuchen kommen und wir können zusammen etwas unternehmen. Wir wollten doch schon lange Bad Homburg besuchen und im Taunus wandern. Was hältst du {{27}}?\n\nWas macht deine Au-pair-Familie? Musst du immer noch so viel Hausarbeit machen? Hören „deine“ Kinder auf dich oder tanzen sie {{28}} noch immer auf der Nase herum, wie du in deinem letzten Brief geschrieben hast? Es ist bestimmt nicht so leicht, einen zweijährigen Jungen und ein vierjähriges Mädchen den ganzen Tag {{29}}. Aber ich kenne dich: Du hast gute Ideen und bestimmt hast du schon einen Weg gefunden, {{30}} du mit den Kindern zurechtkommst.\n\nSo, jetzt muss ich mich wieder an meine Prüfungsvorbereitung machen, sonst wird mir die Zeit zu knapp. Ich grüße dich ganz herzlich und wünsche dir alles Gute.\n\nBis bald\nDeine Louise",
      "questions": {
        "21": {
          "options": [
            "her",
            "hin",
            "vorbei"
          ],
          "answer": 0,
          "note": "Feste Zeitangabe: „es ist ein halbes Jahr her, dass ...“."
        },
        "22": {
          "options": [
            "erkrankt",
            "gekränkt",
            "kränklich"
          ],
          "answer": 0,
          "note": "Zustandsänderung: „ist erkrankt“ (= krank geworden)."
        },
        "23": {
          "options": [
            "als",
            "da",
            "wenn"
          ],
          "answer": 2,
          "note": "Zukünftiger Zeitpunkt: „kommt erst wieder zurück, wenn unsere Prüfung vorbei ist“."
        },
        "24": {
          "options": [
            "nicht nur ... sondern",
            "teils ... teils",
            "zwar ... aber"
          ],
          "answer": 2,
          "note": "Konzessive Verbindung: „ist zwar sehr nett, aber sie hat ...“."
        },
        "25": {
          "options": [
            "werde",
            "wollte",
            "würde"
          ],
          "answer": 0,
          "note": "Futur I für festen Plan nach der Prüfung: „Und dann werde ich ... legen“."
        },
        "26": {
          "options": [
            "Dafür",
            "Danach",
            "Darauf"
          ],
          "answer": 2,
          "note": "sich freuen auf (Zukünftiges) -> „Darauf freue ich mich schon riesig.“"
        },
        "27": {
          "options": [
            "darüber",
            "davon",
            "dazu"
          ],
          "answer": 1,
          "note": "halten von -> „Was hältst du davon?“"
        },
        "28": {
          "options": [
            "dich",
            "dir",
            "sich"
          ],
          "answer": 1,
          "note": "Redewendung mit Dativ: „jemandem (dir) auf der Nase herumtanzen“."
        },
        "29": {
          "options": [
            "beschäftigen lassen",
            "beschäftigt zu sein",
            "zu beschäftigen"
          ],
          "answer": 2,
          "note": "Infinitiv mit „zu“ nach „Es ist nicht so leicht, ... zu beschäftigen“."
        },
        "30": {
          "options": [
            "weshalb",
            "wie",
            "wo"
          ],
          "answer": 1,
          "note": "Art und Weise: „einen Weg gefunden, wie du mit den Kindern zurechtkommst“."
        }
      }
    },
    {
      "id": "20a",
      "num": "20a",
      "page": 383,
      "isVariant": true,
      "title": "Abschlussprüfung in Deutsch (Liebe Anna – Variante 20a)",
      "category": "Persönlicher Brief / Sprachprüfung & Au-pair",
      "text": "Liebe Anna,\n\njetzt ist schon bald ein halbes Jahr {{21}}, seit ich dir das letzte Mal geschrieben habe. Bitte denke jetzt nicht, dass ich dich vergessen habe. Aber, wie du ja schon weißt, stehe ich vor der Abschlussprüfung in Deutsch und das bedeutet jede Menge Arbeit und Stress.\n\nStell dir vor, ausgerechnet jetzt, nur zwei Wochen vor der Prüfung, ist unsere Lehrerin, Frau Reuter, {{22}} erkrankt. Sie liegt sogar im Krankenhaus und kommt erst wieder zurück, {{23}} unsere Prüfung schon längst vorbei ist. Ihre Vertretung, Frau Eichhorn, ist {{24}} sehr nett, aber sie hat gerade erst mit dem Unterrichten angefangen und noch keine Erfahrung. Das macht uns alle ein bisschen unsicher. Aber in zwei Wochen ist hoffentlich alles geschafft. Und dann {{25}} ich alle Bücher und Hefte in die Ecke legen und erst einmal ein paar Tage gar nichts tun. {{26}} freue ich mich schon riesig. Wenn du Zeit und Lust hast, kannst du mich doch besuchen kommen und wir können zusammen etwas unternehmen. Wir wollten doch schon lange Bad Homburg besuchen und im Taunus wandern. Was hältst du {{27}}?\n\nWas macht deine Au-pair-Familie? Musst du immer noch so viel Hausarbeit machen? Hören deine Kinder auf dich oder tanzen sie dir immer noch {{28}} der Nase herum, wie du in deinem letzten Brief geschrieben hast? Es ist bestimmt nicht so leicht, einen zweijährigen Jungen und ein vierjähriges Mädchen den ganzen Tag {{29}}. Aber ich kenne dich: Du hast gute Ideen und bestimmt hast du schon einen Weg gefunden, wie du mit den Kindern {{30}}.\n\nSo, jetzt muss ich mich wieder an meine Prüfungsvorbereitung machen, sonst wird mir die Zeit zu knapp. Ich grüße dich ganz herzlich und wünsche dir alles Gute.\n\nBis bald\nDeine Marta",
      "questions": {
        "21": {
          "options": [
            "vergangen",
            "vergehend",
            "vergingen"
          ],
          "answer": 0,
          "note": "Perfekt mit „ist“: „ist ein halbes Jahr vergangen, seit ...“."
        },
        "22": {
          "options": [
            "gleich",
            "plötzlich",
            "sofort"
          ],
          "answer": 1,
          "note": "„ist plötzlich (= unerwartet) erkrankt“."
        },
        "23": {
          "options": [
            "als",
            "da",
            "wenn"
          ],
          "answer": 2,
          "note": "Temporaler Nebensatz (Zukunft/Gegenwart): „wenn unsere Prüfung vorbei ist“."
        },
        "24": {
          "options": [
            "sondern",
            "sowohl",
            "zwar"
          ],
          "answer": 2,
          "note": "„ist zwar sehr nett, aber ...“."
        },
        "25": {
          "options": [
            "werde",
            "wollte",
            "würde"
          ],
          "answer": 0,
          "note": "Futur I: „dann werde ich ... legen“."
        },
        "26": {
          "options": [
            "Damit",
            "Darauf",
            "Davon"
          ],
          "answer": 1,
          "note": "sich freuen auf -> „Darauf freue ich mich“."
        },
        "27": {
          "options": [
            "darüber",
            "davon",
            "dazu"
          ],
          "answer": 1,
          "note": "„Was hältst du davon?“"
        },
        "28": {
          "options": [
            "an",
            "auf",
            "in"
          ],
          "answer": 1,
          "note": "Redewendung: „jemandem auf der Nase herumtanzen“."
        },
        "29": {
          "options": [
            "beschäftigen lassen",
            "beschäftigt zu sein",
            "zu beschäftigen"
          ],
          "answer": 2,
          "note": "Infinitivsatz mit „zu“: „zu beschäftigen“."
        },
        "30": {
          "options": [
            "zurechtkamst",
            "zurechtkommst",
            "zurechtzukommen"
          ],
          "answer": 1,
          "note": "Konjugiertes Verb im Präsens im Nebensatz („wie du ... zurechtkommst“)."
        }
      }
    },
    {
      "id": "21",
      "num": "21",
      "page": 384,
      "isVariant": false,
      "title": "Grüße aus Berlin nach Peking (Hallo Leon)",
      "category": "Persönliche E-Mail / Alltag & Konzert",
      "text": "Betreff: Grüße {{21}} Berlin\n\nHallo Leon,\n\nvielen Dank für deine letzte Mail aus Peking! Du arbeitest ja jetzt schon seit einem halben Jahr in China – unglaublich, wie schnell die Zeit vergeht.\n\nLeider hatte ich in den letzten drei Wochen keine Zeit, dir zu antworten, weil ich viel zu tun hatte. Aber jetzt berichte ich dir, {{22}} alles los war.\n\nAlso, im Büro haben wir derzeit viel Stress, {{23}} drei Kollegen im Urlaub sind und eine weitere Kollegin seit zwei Wochen krank ist. Jetzt müssen wir mit fünf Leuten die Arbeit erledigen, die sonst neun Leute machen. Ich weiß wirklich nicht, wer diese Urlaubsplanung gemacht hat. Hoffentlich {{24}} das in Zukunft besser organisiert.\n\nAbends waren Carmen und ich dann ein paarmal aus. Wir waren zum Beispiel bei einem Konzert von „Belasco“. Kennst du die Band? Eigentlich war ich an dem Abend ganz schön kaputt und {{25}} am liebsten zuhause geblieben, aber ich hatte Carmen die Karten zum Geburtstag geschenkt. Da {{26}} ich ja schlecht auf dem Sofa sitzen bleiben! Im Nachhinein muss ich sagen: Ein Glück, dass wir zu dem Konzert gegangen sind, {{27}} es war einfach nur super!\n\nAn den letzten beiden Wochenenden hatten wir dann auch noch Familienfeiern: Erst hatte meine ältere Schwester Geburtstag und hat groß gefeiert, dann hat ein Cousin geheiratet und uns eingeladen. {{28}} war zwar schön, aber auch anstrengend. Ich bin froh, dass wir für die kommenden Wochenenden {{29}} keine Pläne haben.\n\nDas war’s erst mal von mir. Melde dich doch wieder, ich freue mich {{30}} deine nächste E-Mail!\n\nViele Grüße sendet dir\nFabian",
      "questions": {
        "21": {
          "options": [
            "ab",
            "aus",
            "von"
          ],
          "answer": 1,
          "note": "Herkunft bei Städten in Grußzeilen: „Grüße aus Berlin“."
        },
        "22": {
          "options": [
            "wann",
            "was",
            "wäre"
          ],
          "answer": 1,
          "note": "Feste Wendung: „was alles los war“."
        },
        "23": {
          "options": [
            "da",
            "indem",
            "obwohl"
          ],
          "answer": 0,
          "note": "Kausaler Nebensatz: „da (= weil) drei Kollegen im Urlaub sind“."
        },
        "24": {
          "options": [
            "ist",
            "wird",
            "würde"
          ],
          "answer": 1,
          "note": "Vorgangspassiv: „Hoffentlich wird das in Zukunft besser organisiert.“"
        },
        "25": {
          "options": [
            "bin",
            "war",
            "wäre"
          ],
          "answer": 2,
          "note": "Irrealer Wunsch in der Vergangenheit: „wäre am liebsten zuhause geblieben“."
        },
        "26": {
          "options": [
            "konnte",
            "musste",
            "sollte"
          ],
          "answer": 0,
          "note": "„Da konnte ich ja schlecht auf dem Sofa sitzen bleiben!“"
        },
        "27": {
          "options": [
            "aber",
            "denn",
            "sondern"
          ],
          "answer": 1,
          "note": "Kausale Hauptsatzkonjunktion (Position 0): „denn es war einfach nur super!“"
        },
        "28": {
          "options": [
            "Beide",
            "Beiden",
            "Beides"
          ],
          "answer": 2,
          "note": "Zusammenfassendes Neutrum Singular (mit Verb „war“): „Beides war zwar schön“."
        },
        "29": {
          "options": [
            "erst",
            "noch",
            "schon"
          ],
          "answer": 1,
          "note": "„noch keine Pläne haben“."
        },
        "30": {
          "options": [
            "auf",
            "für",
            "über"
          ],
          "answer": 0,
          "note": "sich freuen auf (+ Akkusativ) für Zukünftiges: „auf deine nächste E-Mail“."
        }
      }
    },
    {
      "id": "22",
      "num": "22",
      "page": 385,
      "isVariant": false,
      "title": "Studium und WG-Leben in München (Liebe Karin)",
      "category": "Persönliche E-Mail / Studium & Familie",
      "text": "Liebe Karin,\n\nvielen Dank für deine letzte E-Mail! Ich habe mich wirklich sehr gefreut zu lesen, dass es dir in München so gut gefällt. Endlich kannst du auch das studieren, {{21}} du möchtest – das ist doch super! Wie ist es {{22}} so an der Uni dort? Hast du schon neue Leute kennengelernt? Und wie sieht deine Woche aus? Hast du viele Veranstaltungen? Musst du zuhause auch {{23}} viel lernen? Jobbst du eigentlich noch nebenbei? Du siehst, ich habe jede Menge Fragen an dich!\n\nDeshalb würde ich deine Einladung wirklich gerne {{24}} und dich demnächst in München besuchen kommen. Im Moment habe ich noch nicht so viel Zeit, weil ich mich viel {{25}} Jonas kümmern muss – er ist ja erst sechs Monate alt – und Thomas leider keinen Urlaub nehmen kann. Aber {{26}} er frei hat, komme ich mal für ein, zwei Tage zu dir. Ich bin ja so gespannt, wie du wohnst! In einer Wohngemeinschaft zu leben, ist bestimmt toll, {{27}} es mal Streit gibt. Aber du hast ja geschrieben, dass deine beiden Mitbewohnerinnen sehr nett sind und ihr euch alle gut versteht. Das freut mich wirklich {{28}} dich!\n\nBei mir gibt es gar nicht viel Neues. Wir hatten {{29}} mal überlegt, in eine größere Wohnung zu ziehen, aber die Mieten sind ja hier in Köln recht hoch und wir {{30}} uns nicht zu viel zumuten – also bleiben wir lieber erst mal in dieser Wohnung. Umziehen kann man ja auch später noch.\n\nAlso, meld’ dich doch mal wieder!\n\nLiebe Grüße\nHeike",
      "questions": {
        "21": {
          "options": [
            "das",
            "was",
            "welches"
          ],
          "answer": 1,
          "note": "Nach demonstrativem „das“ folgt das Relativpronomen „was“: „das studieren, was du möchtest“."
        },
        "22": {
          "options": [
            "denn",
            "doch",
            "mal"
          ],
          "answer": 0,
          "note": "Abtönungspartikel in Fragen: „Wie ist es denn so an der Uni dort?“"
        },
        "23": {
          "options": [
            "dazu",
            "noch",
            "sogar"
          ],
          "answer": 1,
          "note": "„auch noch viel lernen“ (= zusätzlich zu den Veranstaltungen)."
        },
        "24": {
          "options": [
            "abnehmen",
            "annehmen",
            "nehmen"
          ],
          "answer": 1,
          "note": "Kollokation: „eine Einladung annehmen“."
        },
        "25": {
          "options": [
            "für",
            "über",
            "um"
          ],
          "answer": 2,
          "note": "sich kümmern um (+ Akkusativ)."
        },
        "26": {
          "options": [
            "bevor",
            "bis",
            "sobald"
          ],
          "answer": 2,
          "note": "Temporale Konjunktion: „sobald er frei hat“."
        },
        "27": {
          "options": [
            "wenn",
            "auch wenn",
            "wenn auch"
          ],
          "answer": 1,
          "note": "Konzessiver Nebensatz: „auch wenn (= selbst wenn) es mal Streit gibt“."
        },
        "28": {
          "options": [
            "an",
            "über",
            "für"
          ],
          "answer": 2,
          "note": "„Das freut mich wirklich für dich!“"
        },
        "29": {
          "options": [
            "demnächst",
            "neulich",
            "noch nicht"
          ],
          "answer": 1,
          "note": "Vergangenheit (Plusquamperfekt „hatten überlegt“): „neulich“ (= vor kurzem)."
        },
        "30": {
          "options": [
            "müssen",
            "sollen",
            "wollen"
          ],
          "answer": 2,
          "note": "Eigener Entschluss: „wir wollen uns finanziell nicht zu viel zumuten“."
        }
      }
    },
    {
      "id": "22a",
      "num": "22a",
      "page": 386,
      "isVariant": true,
      "title": "Studium und WG-Leben in München (Liebe Karin – Variante 22a)",
      "category": "Persönliche E-Mail / Studium & Familie",
      "text": "Liebe Karin,\n\nvielen Dank für deine letzte E-Mail! Ich habe mich wirklich sehr gefreut zu lesen, dass es dir in München so gut gefällt. Endlich kannst du auch das studieren, {{21}} du möchtest – das ist doch super! Wie ist es {{22}} so an der Uni dort? Hast du schon neue Leute kennengelernt? Und wie sieht deine Woche aus? Hast du viele Veranstaltungen? Musst du zuhause auch {{23}} viel lernen? Jobbst du eigentlich noch {{24}}? Du siehst, ich habe jede Menge Fragen an dich!\n\nDeshalb würde ich deine Einladung wirklich gerne {{25}} und dich demnächst in München besuchen kommen. Im Moment habe ich noch nicht so viel Zeit, weil ich mich viel um Jonas kümmern muss – er ist ja erst sechs Monate alt – und Thomas leider keinen Urlaub nehmen kann. Aber {{26}} er frei hat, komme ich mal für ein, zwei Tage zu dir. Ich bin ja so gespannt, wie du wohnst! In einer Wohngemeinschaft zu leben, ist bestimmt toll, {{27}} es mal Streit gibt. Aber du hast ja geschrieben, dass deine beiden Mitbewohnerinnen sehr nett sind und {{28}} euch alle gut versteht. Das freut mich wirklich für dich!\n\nBei mir gibt es gar nicht viel Neues. Wir hatten {{29}} mal überlegt, in eine größere Wohnung zu ziehen, aber die Mieten sind ja hier in Köln recht hoch und wir {{30}} uns nicht zu viel zumuten – also bleiben wir lieber erst mal in dieser Wohnung. Umziehen kann man ja auch später noch.\n\nAlso, meld’ dich doch mal wieder!\n\nLiebe Grüße\nHeike",
      "questions": {
        "21": {
          "options": [
            "das",
            "was",
            "welches"
          ],
          "answer": 1,
          "note": "„das studieren, was du möchtest“."
        },
        "22": {
          "options": [
            "denn",
            "doch",
            "mal"
          ],
          "answer": 0,
          "note": "„Wie ist es denn so an der Uni dort?“"
        },
        "23": {
          "options": [
            "dazu",
            "noch",
            "sogar"
          ],
          "answer": 1,
          "note": "„auch noch viel lernen“."
        },
        "24": {
          "options": [
            "neben",
            "nebenbei",
            "nebenan"
          ],
          "answer": 1,
          "note": "Adverb: „nebenbei jobben“ (= neben dem Studium arbeiten)."
        },
        "25": {
          "options": [
            "abnehmen",
            "nehmen",
            "annehmen"
          ],
          "answer": 2,
          "note": "„eine Einladung annehmen“."
        },
        "26": {
          "options": [
            "bevor",
            "bis",
            "sobald"
          ],
          "answer": 2,
          "note": "„Aber sobald er frei hat, ...“."
        },
        "27": {
          "options": [
            "wenn",
            "auch wenn",
            "wenn auch"
          ],
          "answer": 1,
          "note": "„auch wenn es mal Streit gibt“."
        },
        "28": {
          "options": [
            "euch",
            "ihr",
            "sich"
          ],
          "answer": 1,
          "note": "Subjektpronomen 2. Person Plural: „dass ... ihr euch alle gut versteht“."
        },
        "29": {
          "options": [
            "demnächst",
            "neulich",
            "noch nicht"
          ],
          "answer": 1,
          "note": "„Wir hatten neulich mal überlegt“."
        },
        "30": {
          "options": [
            "müssen",
            "sollen",
            "wollen"
          ],
          "answer": 2,
          "note": "„und wir wollen uns nicht zu viel zumuten“."
        }
      }
    },
    {
      "id": "23",
      "num": "23",
      "page": 387,
      "isVariant": false,
      "title": "Vorabinformationen zur Dresden-Reise (Frau Melchior)",
      "category": "Formeller Geschäftsbrief / Reisebüro",
      "text": "Sehr geehrte Frau Melchior,\n\nvielen Dank für Ihr Schreiben vom letzten Dienstag, {{21}} Sie um nähere Informationen zu der geplanten Dresden-Reise im kommenden Juni gebeten haben. {{22}} unser Programmheft erst in zwei Wochen fertig ist, gebe ich Ihnen schon einmal ein paar Vorabinformationen.\n\nDie Reise findet in der Zeit vom 3. bis 8. Juni statt. Die Anreise erfolgt mit der Bahn. {{23}} sind Sie im Hotel Corona, das {{24}} in der Stadtmitte befindet. Ihnen stehen Einzel- oder Doppelzimmer mit Bad zur Verfügung. Der Reisepreis beträgt 650 € im Doppel- sowie 950 € im Einzelzimmer, jeweils mit Frühstück.\n\nDas eigentliche Programm der Reise startet am 4. Juni mit einer Stadtrundfahrt, in deren Verlauf Ihnen alle wichtigen Sehenswürdigkeiten {{25}} werden. Am Nachmittag werden Sie den Zwinger mit seiner umfangreichen Sammlung an Bildern, Porzellan und Skulpturen besuchen. Für den Abend ist ein Besuch {{26}} Semper-Oper geplant, wo am Abend Mozarts „Zauberflöte“ aufgeführt wird.\n\nAm 5. Juni machen Sie einen Ausflug zu dem vor den Toren der Stadt liegenden barocken Schloss Pillnitz, dessen Park {{27}} seine exotischen Pflanzen berühmt ist. Während der halbstündigen Busfahrt fahren Sie über die berühmte Elbbrücke „Blaues Wunder“. Am 6. Juni geht es in das Residenzschloss mit dem Grünen Gewölbe. Darin befinden sich über 3000 Werke der Goldschmiede- und Juwelierkunst. Am Abend geht es in die wiederaufgebaute Frauenkirche. Hier erwartet Sie ein Konzert mit Musik von Johann Sebastian Bach.\n\nDer 7. Juni {{28}} zu Ihrer freien Verfügung. Vielleicht möchten Sie einen Einkaufsbummel machen oder an einer Fahrt in die nahe gelegene Sächsische Schweiz {{29}}.\n\nIch hoffe, dass Ihnen diese Vorabinformationen einen Überblick über die geplante Reise {{30}}. Nähere Informationen enthält dann unser Programmheft, in dem Sie auch die genauen Abfahrts- und Ankunftszeiten finden.\n\nMit freundlichen Grüßen\nJasmin Krämer\nReisedienst Krämer",
      "questions": {
        "21": {
          "options": [
            "für das",
            "in dem",
            "von dem"
          ],
          "answer": 1,
          "note": "Relativsatz zu „Schreiben“: „in dem Sie ... gebeten haben“."
        },
        "22": {
          "options": [
            "Da",
            "Wann",
            "Wenn"
          ],
          "answer": 0,
          "note": "Kausale Konjunktion: „Da (= Weil) unser Programmheft erst in zwei Wochen fertig ist“."
        },
        "23": {
          "options": [
            "Untergebracht",
            "Verbracht",
            "Zugebracht"
          ],
          "answer": 0,
          "note": "„im Hotel untergebracht sein“ (= dort wohnen/logieren)."
        },
        "24": {
          "options": [
            "man",
            "sich",
            "Sie"
          ],
          "answer": 1,
          "note": "Reflexivverb: „sich befinden“."
        },
        "25": {
          "options": [
            "geschaut",
            "gesehen",
            "gezeigt"
          ],
          "answer": 2,
          "note": "Passiv mit Dativ („Ihnen“): „Ihnen alle wichtigen Sehenswürdigkeiten gezeigt werden“."
        },
        "26": {
          "options": [
            "der",
            "die",
            "von"
          ],
          "answer": 0,
          "note": "Genitiv feminin Singular: „ein Besuch der Semper-Oper“."
        },
        "27": {
          "options": [
            "für",
            "mit",
            "wegen"
          ],
          "answer": 0,
          "note": "Feste Präposition: „berühmt sein für (+ Akkusativ)“."
        },
        "28": {
          "options": [
            "fällt",
            "liegt",
            "steht"
          ],
          "answer": 2,
          "note": "Feste Funktionsverbgefüge: „zur freien Verfügung stehen“."
        },
        "29": {
          "options": [
            "beteiligen",
            "fahren",
            "teilnehmen"
          ],
          "answer": 2,
          "note": "teilnehmen an (+ Dativ) ohne Reflexivpronomen (bei „beteiligen“ müsste „sich“ stehen)."
        },
        "30": {
          "options": [
            "verschaffen",
            "vermachen",
            "schaffen"
          ],
          "answer": 0,
          "note": "Feste Kollokation: „jemandem einen Überblick verschaffen“."
        }
      }
    },
    {
      "id": "24",
      "num": "24",
      "page": 388,
      "isVariant": false,
      "title": "Sprachurlaube in Deutschland und Österreich (Frau Goronska)",
      "category": "Formeller Geschäftsbrief / Sprachreisen",
      "text": "Sehr geehrte Frau Goronska,\n\nvielen Dank für Ihre Anfrage vom 12. September bezüglich unserer Sprachurlaube in Deutschland und Österreich. Unsere Organisation unterhält insgesamt zehn Schulen, acht {{21}} in Deutschland und zwei in Österreich, an {{22}} Sie ausnahmslos sowohl Ihr Deutsch verbessern als auch an einem anspruchsvollen Kultur- und Freizeitprogramm teilnehmen können.\n\nDer Sprachunterricht findet in der Regel {{23}} fünf Tagen pro Woche statt, jeweils in der Zeit von 9 bis 13 und von 15 bis 17 Uhr. {{24}} ist kein Nachmittagsunterricht. Das Kursangebot umfasst alle Niveaustufen. Die Mindestdauer für einen Kurs beträgt zwei Wochen, Sie können jedoch auch vier, sechs oder acht Wochen bleiben. Zu Beginn {{25}} wird ein Einstufungstest durchgeführt, mit {{26}} Hilfe wir herausfinden, welcher Kurs für Sie der geeignete ist. Nach Abschluss Ihres Aufenthaltes erhalten Sie eine Teilnahmebescheinigung. Selbstverständlich können Sie bei uns Tests auf allen Niveaustufen von A1 bis C1 ablegen und erhalten, {{27}} Sie den Test bestehen, ein international anerkanntes Zertifikat.\n\nHinsichtlich unseres Kultur- und Freizeitprogramms gibt es verschiedene Wahlmöglichkeiten, die {{28}} vor Ort angeboten werden. Dazu zählen Ausflüge in die nähere Umgebung, Museums- und Theaterbesuche und vieles mehr.\n\nWas die Übernachtung am Kursort angeht, können Sie zwischen einer Unterbringung in einer Gastfamilie und der Unterkunft in einfachen Hotels wählen. Im Unterkunftspreis {{29}} jeweils Halbpension eingeschlossen, das heißt Frühstück und Mittagessen. Bitte teilen Sie uns mit, wenn Sie bestimmte Lebensmittel ausschließen, z. B. vegetarisch essen oder {{30}}.\n\nAlles Weitere entnehmen Sie bitte dem beiliegenden Katalog. Bei weiteren Fragen sind wir gerne für Sie da.\n\nMit freundlichen Grüßen\nNatalie Spengler",
      "questions": {
        "21": {
          "options": [
            "dabei",
            "daraus",
            "davon"
          ],
          "answer": 2,
          "note": "Teilmenge: „insgesamt zehn Schulen, acht davon in Deutschland“."
        },
        "22": {
          "options": [
            "denen",
            "die",
            "den"
          ],
          "answer": 0,
          "note": "Relativpronomen im Dativ Plural nach „an“: „an denen Sie ...“."
        },
        "23": {
          "options": [
            "an",
            "durch",
            "in"
          ],
          "answer": 0,
          "note": "Zeitangabe bei Tagen: „an fünf Tagen pro Woche“."
        },
        "24": {
          "options": [
            "Jeder Mittwoch",
            "Mittwochs",
            "Zum Mittwoch"
          ],
          "answer": 1,
          "note": "Wiederkehrender Wochentag als Adverb: „Mittwochs“."
        },
        "25": {
          "options": [
            "jedem Kurs",
            "jeden Kurs",
            "jedes Kurses"
          ],
          "answer": 2,
          "note": "Genitiv Maskulinum Singular nach „Zu Beginn“: „Zu Beginn jedes Kurses“."
        },
        "26": {
          "options": [
            "der",
            "deren",
            "dessen"
          ],
          "answer": 2,
          "note": "Relativpronomen im Genitiv Singular Maskulinum (Bezug auf „ein Einstufungstest“): „mit dessen Hilfe“."
        },
        "27": {
          "options": [
            "obwohl",
            "wenn",
            "wobei"
          ],
          "answer": 1,
          "note": "Bedingungssatz: „wenn (= falls) Sie den Test bestehen“."
        },
        "28": {
          "options": [
            "Ihnen",
            "Sie",
            "Euch"
          ],
          "answer": 0,
          "note": "Dativ der höflichen Anrede: „die Ihnen vor Ort angeboten werden“."
        },
        "29": {
          "options": [
            "hat",
            "ist",
            "wird"
          ],
          "answer": 1,
          "note": "Zustandspassiv: „ist jeweils Halbpension eingeschlossen“."
        },
        "30": {
          "options": [
            "eine Diät halten müssen",
            "müssen eine Diät halten",
            "müssen halten eine Diät"
          ],
          "answer": 0,
          "note": "Nebensatz mit „wenn“ -> konjugiertes Modalverb „müssen“ steht ganz am Ende."
        }
      }
    },
    {
      "id": "25",
      "num": "25",
      "page": 389,
      "isVariant": false,
      "title": "Studienreise einer Schulklasse nach Frankfurt (Herr Martini)",
      "category": "Formeller Geschäftsbrief / Schüleraustausch",
      "text": "Sehr geehrter Herr Martini,\n\nvielen Dank für Ihre Anfrage vom 16. Juni {{21}} der Studienreise Ihrer Schulklasse nach Frankfurt am Main im {{22}} Oktober.\n\nDie Unterkunft bei deutschen Gastfamilien ist prinzipiell möglich. Die Familien werden von uns sorgfältig {{23}} strengen Kriterien ausgewählt, die Sie in der beiliegenden Informationsbroschüre auf den Seiten 15 bis 17 finden. Pro Gastfamilie können ein oder zwei Schülerinnen bzw. Schüler untergebracht werden. Unsere Gastfamilien {{24}} Halbpension, d. h. in der Regel Frühstück und Abendessen, an. Alle Familien wohnen im näheren Umkreis der Schule, {{25}} der Weg von der Unterkunft zum Unterricht innerhalb von maximal 10 Minuten zu Fuß zurückgelegt werden kann.\n\nZweimal pro Woche ist die Teilnahme am Schulunterricht Ihrer Partnerschule in Frankfurt, der Heinrich-Böll-Schule, in den Fächern Geografie, Kunst und Deutsch vorgesehen. Die Unterrichtssprache ist Deutsch. {{26}} Schülerinnen und Schülern der Partnerschule wird das Freizeit- und Kulturprogramm durchgeführt.\n\nDazu gehört z. B. {{27}} der Gemäldegalerie „Städel“, des Museums für Kunsthandwerk und des Deutschen Postmuseums. Auch ein Besuch beim Hessischen Rundfunk {{28}}. Jeweils dienstags und freitags werden Kulturabende veranstaltet, an denen die verschiedenen Aspekte und Unterschiede der deutschen und der italienischen Kultur {{29}} werden sollen.\n\nWeitere Informationen finden Sie in der beiliegenden Broschüre. Wir hoffen, dass Sie und Ihre Klasse einen erlebnisreichen und unvergesslichen Aufenthalt in Frankfurt {{30}} werden. Bei weiteren Fragen setzen Sie sich bitte mit uns in Verbindung.\n\nMit freundlichen Grüßen\nSibylle Lauterbacher\nStiftung Schüleraustausch Frankfurt",
      "questions": {
        "21": {
          "options": [
            "an",
            "von",
            "zu"
          ],
          "answer": 2,
          "note": "„eine Anfrage zu (+ Dativ)“ (= bezüglich der Studienreise)."
        },
        "22": {
          "options": [
            "ankommenden",
            "gekommenen",
            "kommenden"
          ],
          "answer": 2,
          "note": "Zeitangabe für den nächsten Oktober: „im kommenden Oktober“."
        },
        "23": {
          "options": [
            "aus",
            "mit",
            "nach"
          ],
          "answer": 2,
          "note": "Feste Präposition: „nach strengen Kriterien auswählen“."
        },
        "24": {
          "options": [
            "bieten",
            "fordern",
            "nehmen"
          ],
          "answer": 0,
          "note": "Trennbares Verb „anbieten“: „bieten Halbpension ... an“."
        },
        "25": {
          "options": [
            "so dass",
            "weil",
            "wenn"
          ],
          "answer": 0,
          "note": "Konsekutivsatz (Folge): „..., so dass der Weg ... zurückgelegt werden kann“."
        },
        "26": {
          "options": [
            "Gemeinsam mit",
            "Verbunden von",
            "Zusammen neben"
          ],
          "answer": 0,
          "note": "„Gemeinsam mit Schülerinnen und Schülern der Partnerschule“."
        },
        "27": {
          "options": [
            "die Ansicht",
            "der Besuch",
            "das Betrachten"
          ],
          "answer": 1,
          "note": "„der Besuch der Gemäldegalerie“."
        },
        "28": {
          "options": [
            "hat geplant",
            "ist geplant",
            "wird geplant haben"
          ],
          "answer": 1,
          "note": "Zustandspassiv: „ist geplant“."
        },
        "29": {
          "options": [
            "besprochen",
            "gesprochen",
            "versprochen"
          ],
          "answer": 0,
          "note": "Transitives Verb (im Passiv): „Aspekte und Unterschiede sollen besprochen werden“."
        },
        "30": {
          "options": [
            "haben",
            "hatten",
            "hätten"
          ],
          "answer": 0,
          "note": "Futur I („haben werden“): „einen unvergesslichen Aufenthalt haben werden“."
        }
      }
    },
    {
      "id": "25a",
      "num": "25a",
      "page": 390,
      "isVariant": true,
      "title": "Studienreise einer Schulklasse nach Frankfurt (Herr Martini – Variante 25a)",
      "category": "Formeller Geschäftsbrief / Schüleraustausch",
      "text": "Sehr geehrter Herr Martini,\n\nvielen Dank für Ihre Anfrage vom 16. Juni zu der Studienreise {{21}} Schulklasse nach Frankfurt am Main im {{22}} Oktober.\n\nDie Unterkunft bei deutschen Gastfamilien ist prinzipiell möglich. Die Familien werden von uns sorgfältig {{23}} strengen Kriterien ausgewählt, die Sie in der beiliegenden Informationsbroschüre auf den Seiten 15 bis 17 finden. Pro Gastfamilie können ein oder zwei Schülerinnen bzw. Schüler untergebracht werden. Unsere Gastfamilien {{24}} Halbpension, d. h. in der Regel Frühstück und Abendessen, an. Alle Familien wohnen im näheren Umkreis der Schule, {{25}} der Weg von der Unterkunft zum Unterricht innerhalb von maximal 10 Minuten zu Fuß zurückgelegt werden kann.\n\nZweimal pro Woche ist die Teilnahme am Schulunterricht Ihrer Partnerschule in Frankfurt, der Heinrich-Böll-Schule, in den Fächern Geografie, Kunst und Deutsch vorgesehen. Die Unterrichtssprache ist Deutsch. {{26}} Schülerinnen und Schülern der Partnerschule wird das Freizeit- und Kulturprogramm durchgeführt.\n\nDazu gehört z. B. {{27}} der Gemäldegalerie „Städel“, des Museums für Kunsthandwerk und des Deutschen Postmuseums. Auch ein Besuch beim Hessischen Rundfunk {{28}}. Jeweils dienstags und freitags werden Kulturabende veranstaltet, an denen die verschiedenen Aspekte und Unterschiede der deutschen und der italienischen Kultur {{29}} werden sollen.\n\nWeitere Informationen finden Sie in der beiliegenden Broschüre. Wir hoffen, dass Sie und Ihre Klasse einen erlebnisreichen und unvergesslichen Aufenthalt in Frankfurt {{30}} werden. Bei weiteren Fragen setzen Sie sich bitte mit uns in Verbindung.\n\nMit freundlichen Grüßen\nSibylle Lauterbacher\nStiftung Schüleraustausch Frankfurt",
      "questions": {
        "21": {
          "options": [
            "Seiner",
            "Deiner",
            "Ihrer"
          ],
          "answer": 2,
          "note": "Höfliche Anrede im Genitiv feminin Singular: „zu der Studienreise Ihrer Schulklasse“."
        },
        "22": {
          "options": [
            "ankommenden",
            "gekommenen",
            "kommenden"
          ],
          "answer": 2,
          "note": "„im kommenden Oktober“."
        },
        "23": {
          "options": [
            "aus",
            "mit",
            "nach"
          ],
          "answer": 2,
          "note": "„nach strengen Kriterien ausgewählt“."
        },
        "24": {
          "options": [
            "bieten",
            "fordern",
            "nehmen"
          ],
          "answer": 0,
          "note": "„bieten Halbpension ... an“."
        },
        "25": {
          "options": [
            "so dass",
            "weil",
            "wenn"
          ],
          "answer": 0,
          "note": "„so dass der Weg ... zurückgelegt werden kann“."
        },
        "26": {
          "options": [
            "Gemeinsam mit",
            "Verbunden von",
            "Zusammen neben"
          ],
          "answer": 0,
          "note": "„Gemeinsam mit Schülerinnen und Schülern“."
        },
        "27": {
          "options": [
            "die Ansicht",
            "der Besuch",
            "das Betrachten"
          ],
          "answer": 1,
          "note": "„der Besuch der Gemäldegalerie“."
        },
        "28": {
          "options": [
            "hat geplant",
            "ist geplant",
            "wird geplant haben"
          ],
          "answer": 1,
          "note": "„ist geplant“."
        },
        "29": {
          "options": [
            "besprochen",
            "gesprochen",
            "versprochen"
          ],
          "answer": 0,
          "note": "„besprochen werden sollen“."
        },
        "30": {
          "options": [
            "haben",
            "hatten",
            "hätten"
          ],
          "answer": 0,
          "note": "„einen unvergesslichen Aufenthalt haben werden“."
        }
      }
    },
    {
      "id": "26",
      "num": "26",
      "page": 391,
      "isVariant": false,
      "title": "Neue Stelle als Pressereferentin beim Fichte-Verlag (Liebe Lina)",
      "category": "Persönliche E-Mail / Berufseinstieg",
      "text": "Liebe Lina,\n\nvielen Dank für deine E-Mail! Ich hoffe sehr, dass du bei deiner Suche {{21}} einer größeren Wohnung bald Erfolg hast.\n\nBei mir gibt es gute Neuigkeiten: Seit einem Monat arbeite ich als Pressereferentin beim Fichte-Verlag in München. Ich denke noch oft {{22}}, wie wir uns während des Studiums über unsere Berufswünsche und Zukunftspläne unterhalten haben. In einem Verlag zu arbeiten {{23}} schon damals mein Traum. Ich kann kaum glauben, dass es tatsächlich geklappt hat. Denn die Stellensuche nach dem Studium war ziemlich schwierig. {{24}} hatte ich einen guten Abschluss, aber ich {{25}} trotzdem unzählige Bewerbungen schreiben und habe mich Tag für Tag durch {{26}} Stellenbörsen geklickt. Dabei habe ich dann die Ausschreibung des Fichte-Verlags entdeckt: Für die Presseabteilung {{27}} eine Junior-Referentin gesucht, und zwar in Vollzeit und so schnell wie möglich.\n\nEigentlich rechnete ich mir {{28}} großen Chancen aus. Einerseits hatte ich ja schon viele Praktika in diesem Bereich gemacht. Andererseits dachte ich, dass die Stelle auch für Bewerber mit mehr Berufserfahrung interessant sein könnte. Aber ich hatte Glück und bekam eine Einladung {{29}} einem Vorstellungsgespräch. An diesem Tag war ich natürlich ziemlich aufgeregt, aber es lief sehr gut. Zehn Tage später hatte ich die Zusage im Briefkasten.\n\nIn den ersten Wochen im Verlag habe ich viel Neues gelernt und die Kollegen sind sehr freundlich. Das Einzige, {{30}} mich stört, sind die vielen Überstunden, aber daran werde ich mich wohl gewöhnen müssen.\n\nSo viel für heute. Ich freue mich, bald wieder von dir zu hören.\n\nViele Grüße",
      "questions": {
        "21": {
          "options": [
            "an",
            "nach",
            "von"
          ],
          "answer": 1,
          "note": "Feste Präposition: „die Suche nach (+ Dativ)“."
        },
        "22": {
          "options": [
            "danach",
            "daran",
            "darüber"
          ],
          "answer": 1,
          "note": "denken an -> Pronominaladverb „daran denken, wie ...“."
        },
        "23": {
          "options": [
            "war",
            "wäre",
            "würde"
          ],
          "answer": 0,
          "note": "Indikativ Präteritum für reale Vergangenheit: „war schon damals mein Traum“."
        },
        "24": {
          "options": [
            "Andererseits",
            "Weder",
            "Zwar"
          ],
          "answer": 2,
          "note": "Konzessive Struktur: „Zwar hatte ich einen guten Abschluss, aber ...“."
        },
        "25": {
          "options": [
            "mochte",
            "musste",
            "wollte"
          ],
          "answer": 1,
          "note": "Notwendigkeit: „aber ich musste trotzdem unzählige Bewerbungen schreiben“."
        },
        "26": {
          "options": [
            "verschiedene",
            "verschiedenen",
            "verschiedener"
          ],
          "answer": 0,
          "note": "Nach „durch“ (+ Akkusativ Plural ohne Artikel) starke Deklination: „durch verschiedene Stellenbörsen“."
        },
        "27": {
          "options": [
            "hatte",
            "war",
            "wurde"
          ],
          "answer": 2,
          "note": "Vorgangspassiv Präteritum: „wurde eine Junior-Referentin gesucht“."
        },
        "28": {
          "options": [
            "keine",
            "keinen",
            "keiner"
          ],
          "answer": 0,
          "note": "Akkusativ Plural: „sich (Dat.) keine großen Chancen ausrechnen“."
        },
        "29": {
          "options": [
            "in",
            "mit",
            "zu"
          ],
          "answer": 2,
          "note": "Feste Präposition: „eine Einladung zu (+ Dativ)“."
        },
        "30": {
          "options": [
            "was",
            "welches",
            "wo"
          ],
          "answer": 0,
          "note": "Nach substantiviertem Adjektiv im Neutrum („Das Einzige“) steht „was“."
        }
      }
    },
    {
      "id": "26a",
      "num": "26a",
      "page": 392,
      "isVariant": true,
      "title": "Neue Stelle als Pressereferentin beim Fichte-Verlag (Liebe Lina – Variante 26a)",
      "category": "Persönliche E-Mail / Berufseinstieg",
      "text": "Liebe Lina,\n\nvielen Dank für deine E-Mail! Ich hoffe sehr, dass du bei deiner Suche {{21}} einer größeren Wohnung bald Erfolg hast.\n\nBei mir gibt es gute Neuigkeiten: Seit einem Monat arbeite ich als Pressereferentin beim Fichte-Verlag in München. Ich denke noch oft {{22}}, wie wir uns während des Studiums über unsere Berufswünsche und Zukunftspläne unterhalten haben. In einem Verlag zu arbeiten {{23}} schon damals mein Traum. Ich kann kaum glauben, dass es tatsächlich geklappt hat. Denn die Stellensuche nach dem Studium war ziemlich schwierig. {{24}} hatte ich einen guten Abschluss, aber ich {{25}} trotzdem unzählige Bewerbungen schreiben und habe mich Tag für Tag durch {{26}} Stellenbörsen geklickt. Dabei habe ich dann die Ausschreibung des Fichte-Verlags entdeckt: Für die Presseabteilung {{27}} eine Junior-Referentin gesucht, und zwar in Vollzeit und so schnell wie möglich.\n\nEigentlich rechnete ich mir {{28}} großen Chancen aus. Einerseits hatte ich ja schon viele Praktika in diesem Bereich gemacht. Andererseits dachte ich, dass die Stelle auch für Bewerber mit mehr Berufserfahrung interessant sein könnte. Aber ich hatte Glück und bekam eine Einladung {{29}} einem Vorstellungsgespräch. An diesem Tag war ich natürlich ziemlich aufgeregt, aber es lief sehr gut. Zehn Tage später hatte ich die Zusage im Briefkasten.\n\nIn den ersten Wochen im Verlag habe ich viel Neues gelernt und die Kollegen sind sehr freundlich. Das Einzige, {{30}} mich stört, sind die vielen Überstunden, aber daran werde ich mich wohl gewöhnen müssen.\n\nSo viel für heute. Ich freue mich, bald wieder von dir zu hören.\n\nViele Grüße",
      "questions": {
        "21": {
          "options": [
            "an",
            "nach",
            "von"
          ],
          "answer": 1,
          "note": "„Suche nach einer größeren Wohnung“."
        },
        "22": {
          "options": [
            "danach",
            "daran",
            "darüber"
          ],
          "answer": 1,
          "note": "„Ich denke noch oft daran, wie ...“."
        },
        "23": {
          "options": [
            "war",
            "wäre",
            "würde"
          ],
          "answer": 0,
          "note": "„war schon damals mein Traum“."
        },
        "24": {
          "options": [
            "Andererseits",
            "Weder",
            "Zwar"
          ],
          "answer": 2,
          "note": "„Zwar hatte ich ..., aber ...“."
        },
        "25": {
          "options": [
            "mochte",
            "musste",
            "wollte"
          ],
          "answer": 1,
          "note": "„aber ich musste trotzdem unzählige Bewerbungen schreiben“."
        },
        "26": {
          "options": [
            "kleinen",
            "klein",
            "kleinem"
          ],
          "answer": 1,
          "note": "Hinweis zur Vorlage S. 392: Im PDF-Abdruck von 26a stehen hier „Kleinen / Klein / Kleinem“ (aus „von klein auf“), wobei B markiert ist; inhaltlich gehört wie in Test 26 „verschiedene“ in die Lücke."
        },
        "27": {
          "options": [
            "hatte",
            "war",
            "wurde"
          ],
          "answer": 2,
          "note": "„wurde eine Junior-Referentin gesucht“."
        },
        "28": {
          "options": [
            "keine",
            "keinen",
            "keiner"
          ],
          "answer": 0,
          "note": "„rechnete ich mir keine großen Chancen aus“."
        },
        "29": {
          "options": [
            "in",
            "mit",
            "zu"
          ],
          "answer": 2,
          "note": "„eine Einladung zu einem Vorstellungsgespräch“."
        },
        "30": {
          "options": [
            "was",
            "welches",
            "wo"
          ],
          "answer": 0,
          "note": "„Das Einzige, was mich stört“."
        }
      }
    },
    {
      "id": "27",
      "num": "27",
      "page": 393,
      "isVariant": false,
      "title": "Erholungsurlaub auf Helgoland (Liebe Sandra)",
      "category": "Persönliche E-Mail / Urlaub",
      "text": "Liebe Sandra,\n\naus Helgoland sende ich dir herzliche Grüße! Vielleicht überrascht es {{21}}, dass ich Urlaub auf einer Nordseeinsel mache. Sonst zieht es mich ja immer in den Süden. Ehrlich gesagt, noch vor kurzem hätte ich auch nicht gedacht, dass ein Urlaub ganz ohne Partyleben das Richtige für mich sein {{22}}. Aber ich hatte in den letzten Monaten auf der Arbeit viel Stress und wünsche mir im Moment vor allem Ruhe. Wenn man sich {{23}} der Hektik des Alltags erholen möchte, ist Helgoland jedenfalls genau der richtige Ort. Man kann an den Strand gehen, baden oder einfach mal gar nichts unternehmen. Das Klima ist mild und nicht zu heiß, was ich {{24}} sehr angenehm empfinde. Es gibt weder Fabriken noch Autoverkehr und somit auch keine Luftverschmutzung.\n\nHelgoland besteht eigentlich {{25}} zwei Inseln, einer Felseninsel und einer kleineren Sandinsel, die per Fähre zu erreichen {{26}}. Man kann dort Seehunde und Kegelrobben beobachten. Ich glaube, es gibt kaum einen anderen Ort auf der Welt, wo man wild {{27}} Tiere so gut aus der Nähe beobachten kann. Viele Touristen bleiben übrigens nur {{28}} Stunden auf der Insel. {{29}} die Tagesausflügler wieder abgefahren sind, kehrt Stille ein. Nachts kann man hier wirklich gut schlafen, weil man nur ein bisschen Wellenrauschen hört.\n\nWas gibt es bei dir denn Neues? Du hast ja mal gesagt, dass du gern umziehen {{30}}. Wie sieht es aus? Hast du schon mit der Wohnungssuche begonnen? Ich freue mich, bald wieder von dir zu hören!\n\nViele Grüße\nDorothée",
      "questions": {
        "21": {
          "options": [
            "dich",
            "dir",
            "sich"
          ],
          "answer": 0,
          "note": "überraschen regiert den Akkusativ: „überrascht es dich“."
        },
        "22": {
          "options": [
            "könnte",
            "möchte",
            "müsste"
          ],
          "answer": 0,
          "note": "Möglichkeit im Konjunktiv II: „das Richtige für mich sein könnte“."
        },
        "23": {
          "options": [
            "mit",
            "von",
            "vor"
          ],
          "answer": 1,
          "note": "Feste Präposition: „sich erholen von (+ Dativ)“."
        },
        "24": {
          "options": [
            "als",
            "für",
            "wie"
          ],
          "answer": 0,
          "note": "Feste Verbindung: „etwas als (+ Adjektiv) empfinden“."
        },
        "25": {
          "options": [
            "aus",
            "in",
            "zu"
          ],
          "answer": 0,
          "note": "bestehen aus (+ Dativ) = sich zusammensetzen aus."
        },
        "26": {
          "options": [
            "hat",
            "ist",
            "wird"
          ],
          "answer": 1,
          "note": "sein + zu + Infinitiv (Passiversatz): „die per Fähre zu erreichen ist“."
        },
        "27": {
          "options": [
            "lebende",
            "lebenden",
            "lebender"
          ],
          "answer": 0,
          "note": "Partizip I als Adjektiv im Akkusativ Plural ohne Artikel: „wild lebende Tiere“."
        },
        "28": {
          "options": [
            "wenige",
            "weniger",
            "wenigen"
          ],
          "answer": 0,
          "note": "Akkusativ Plural ohne Artikel: „nur wenige Stunden“."
        },
        "29": {
          "options": [
            "Sobald",
            "Sofern",
            "Somit"
          ],
          "answer": 0,
          "note": "Temporale Konjunktion: „Sobald (= Wenn) die Tagesausflügler wieder abgefahren sind“."
        },
        "30": {
          "options": [
            "dürftest",
            "könntest",
            "würdest"
          ],
          "answer": 2,
          "note": "Wunsch mit „gern“: „dass du gern umziehen würdest“."
        }
      }
    },
    {
      "id": "28",
      "num": "28",
      "page": 394,
      "isVariant": false,
      "title": "Rücken- und Kreuzschmerzen (Liebe Jutta)",
      "category": "Persönlicher Brief / Gesundheit",
      "text": "Liebe Jutta,\n\nschon so lange habe ich dir nicht geschrieben, ich hatte aber {{21}} einen triftigen Grund. Ich habe das Schreiben {{22}} meiner Krankheit vernachlässigt. Ich hatte fürchterliche Rücken- und Kreuzschmerzen, ich habe aber die richtige Untersuchung immer wieder {{23}}. Ich habe immer nur einige Medikamente eingenommen, die für kurze Zeit zwar geholfen haben, aber die Schmerzen kamen immer zurück. Schließlich konnte ich {{24}} richtig schlafen und mich so natürlich auch bei der Arbeit nicht konzentrieren.\n\nMein Arzt hat mich ins Krankenhaus zu einigen Untersuchungen {{25}}. Die sind anstrengend gewesen und haben ziemlich lange gedauert. Die Lage ist aber nicht so schlimm. Da ich zu viel bei der Arbeit sitze und dazu noch ein paar Kilo {{26}} habe, ist meine Wirbelsäule belastet. Zum Glück muss ich aber nicht operiert werden. Ich gehe jetzt einige Monate lang {{27}} Behandlung. Einige Behandlungen sind schon {{28}} mir und sie scheinen wirksam zu sein. Ich hoffe, dass sich mein Zustand auch weiterhin verbessern wird. Dann werde ich bald wieder gesund.\n\nFrüher war ich bei einem Naturheilpraktiker, der {{29}} auch geraten hat, mich mehr zu bewegen. Ich glaube, es ist höchste Zeit, damit anzufangen. So könnte ich wenigstens auch etwas abnehmen, was mir {{30}} schaden würde.\n\nSo weit für heute, schreib mir bald.\n\nHerzliche Grüße\ndeine Anna",
      "questions": {
        "21": {
          "options": [
            "darauf",
            "dafür",
            "dazu"
          ],
          "answer": 1,
          "note": "ein Grund für etwas -> „ich hatte aber dafür einen triftigen Grund“."
        },
        "22": {
          "options": [
            "statt",
            "wegen",
            "während"
          ],
          "answer": 1,
          "note": "Kausale Präposition: „wegen meiner Krankheit“."
        },
        "23": {
          "options": [
            "verschieben",
            "verschiebten",
            "verschoben"
          ],
          "answer": 2,
          "note": "Partizip II von „verschieben“ im Perfekt: „immer wieder verschoben“."
        },
        "24": {
          "options": [
            "nicht mehr",
            "sogar nicht",
            "noch nicht"
          ],
          "answer": 0,
          "note": "„Schließlich konnte ich nicht mehr richtig schlafen.“"
        },
        "25": {
          "options": [
            "geschickt",
            "eingewiesen",
            "nachgewiesen"
          ],
          "answer": 1,
          "note": "Fachbegriff Medizin: „jemanden ins Krankenhaus einweisen“."
        },
        "26": {
          "options": [
            "Übergewicht",
            "Gleichgewicht",
            "Gleichgültigkeit"
          ],
          "answer": 0,
          "note": "„ein paar Kilo Übergewicht haben“."
        },
        "27": {
          "options": [
            "zur",
            "auf",
            "unter anderem"
          ],
          "answer": 0,
          "note": "„zur Behandlung gehen“ (= zu der Behandlung)."
        },
        "28": {
          "options": [
            "über",
            "vor",
            "hinter"
          ],
          "answer": 2,
          "note": "„hinter mir sein/liegen“ (= bereits absolviert sein)."
        },
        "29": {
          "options": [
            "vor allem",
            "unter anderem",
            "gar nicht"
          ],
          "answer": 1,
          "note": "„der unter anderem auch geraten hat, ...“."
        },
        "30": {
          "options": [
            "eigentlich",
            "überhaupt",
            "gar nicht"
          ],
          "answer": 2,
          "note": "„was mir gar nicht schaden würde“."
        }
      }
    },
    {
      "id": "29",
      "num": "29",
      "page": 395,
      "isVariant": false,
      "title": "Aktivitäten und Studienreisen des Kulturbunds (Herr Wenzel)",
      "category": "Formeller Informationsbrief / Kulturverein",
      "text": "Sehr geehrter Herr Wenzel,\n\nvielen Dank {{21}} Ihre Anfrage bezüglich der Aktivitäten des Kulturbunds. Unser Hauptanliegen ist es, das kulturelle Leben zu bereichern und kulturelle Initiativen zu fördern. Für unsere Mitglieder findet einmal im Monat – und zwar {{22}} am ersten Montag – ein kultureller Abend in unserer Geschäftsstelle in der Villa Emilia statt. Jeder Abend ist einem bestimmten kulturellen Aspekt {{23}}, von der Dichtung über die Musik bis hin zum Theater.\n\nDarüber hinaus besuchen wir regelmäßig Theateraufführungen innerhalb Deutschlands und haben dazu mehrere {{24}} Treffen. Von besonderem Interesse dürften für die {{25}} unserer Mitglieder unsere Studienreisen sein. Diese führen beispielsweise {{26}} der Route deutscher Dichter von Frankfurt nach Weimar, nach Salzburg und vieles mehr.\n\nIn diesem Jahr bieten wir übrigens eine ganz besondere Reise an: {{27}} den Spuren Tschaikowskis nach Russland. Alle von uns veranstalteten Reisen werden von sachkundigen Musik- oder Literaturwissenschaftlern begleitet, mit {{28}} Hilfe Sie Ihr kulturelles Wissen erweitern können. Auch bei der Wahl der Verkehrsmittel und Unterkünfte wird auf besonderen Komfort geachtet.\n\nEin besonderer Service ist der Kartentausch. Wenn Sie Theaterkarten besitzen, aber nicht nutzen wollen, können Sie diese bei uns gegen andere Karten umtauschen, {{29}} dies organisatorisch möglich ist.\n\nDer Preis für die Mitgliedschaft beträgt 200 Euro pro Jahr für eine Einzelperson bzw. 300 Euro für eine Doppelmitgliedschaft (zwei Personen, z. B. Ehepaare, Freunde etc.). Unsere Geschäftsstelle ist von Montag bis Freitag von 9 bis 12 und von 14 bis 17 Uhr {{30}} und steht Ihnen für Fragen gern zur Verfügung. Ein Anmeldeformular liegt diesem Schreiben bei.\n\nIn kultureller Verbundenheit grüßen wir Sie herzlich\nSabine Sänger\nKulturbund",
      "questions": {
        "21": {
          "options": [
            "auf",
            "für",
            "wegen"
          ],
          "answer": 1,
          "note": "danken / vielen Dank für (+ Akkusativ)."
        },
        "22": {
          "options": [
            "jeden",
            "jedoch",
            "jeweils"
          ],
          "answer": 2,
          "note": "Distributives Adverb: „und zwar jeweils am ersten Montag“."
        },
        "23": {
          "options": [
            "gedacht",
            "geeignet",
            "gewidmet"
          ],
          "answer": 2,
          "note": "Mit Dativ („einem bestimmten kulturellen Aspekt“): „ist ... gewidmet“."
        },
        "24": {
          "options": [
            "vorbereitende",
            "vorbereitend",
            "vorbereiteten"
          ],
          "answer": 0,
          "note": "Partizip I als Adjektiv im Akkusativ Plural nach „mehrere“ (starke Deklination): „mehrere vorbereitende Treffen“."
        },
        "25": {
          "options": [
            "am meisten",
            "meisten",
            "meistens"
          ],
          "answer": 1,
          "note": "Substantiviertes Superlativ-Adjektiv nach „die“: „für die meisten unserer Mitglieder“."
        },
        "26": {
          "options": [
            "entlang",
            "gegenüber",
            "während"
          ],
          "answer": 0,
          "note": "Präposition: „entlang der Route“."
        },
        "27": {
          "options": [
            "auf",
            "hinter",
            "neben"
          ],
          "answer": 0,
          "note": "Feste Wendung: „auf den Spuren (+ Genitiv)“."
        },
        "28": {
          "options": [
            "der",
            "deren",
            "dessen"
          ],
          "answer": 1,
          "note": "Relativpronomen im Genitiv Plural (Bezug auf „Wissenschaftlern“): „mit deren Hilfe“."
        },
        "29": {
          "options": [
            "sofern",
            "sogar",
            "sogleich"
          ],
          "answer": 0,
          "note": "Konditionale Konjunktion: „sofern (= falls) dies organisatorisch möglich ist“."
        },
        "30": {
          "options": [
            "erhältlich",
            "erreichbar",
            "wirksam"
          ],
          "answer": 1,
          "note": "Eine Geschäftsstelle ist zu bestimmten Uhrzeiten „erreichbar“."
        }
      }
    },
    {
      "id": "30",
      "num": "30",
      "page": 396,
      "isVariant": false,
      "title": "Krise beim Schulpraktikum im Sportstudium (Hi Jens)",
      "category": "Persönliche E-Mail / Studium & Praktikum",
      "text": "Hi Jens,\n\ndanke für Deine Mail, schön, von Dir zu hören! Ich freu mich, dass es Dir so gut geht – in einer fremden Stadt ganz neu anzufangen ist ja doch nicht so ohne. Dieses Mal will ich Dich nicht wieder so ewig auf meine Antwort warten {{21}} und schreibe entgegen meinen sonstigen Gewohnheiten gleich zurück ;-).\n\nNicht zuletzt, {{22}} ich gern noch mehr über Deinen neuen Job {{23}} Fußballtrainer für Kinder erfahren möchte. Ich wusste gar nicht, {{24}} Du so fußballbegeistert bist! Früher warst Du doch in einer Handballmannschaft, oder? Wie kommst Du denn mit den Kindern klar, hast Du da nicht ständig Probleme mit der Disziplin? Und wie alt sind die Kinder, die Du trainierst, genau?\n\nIch frage, weil ich in meinem Sportunterricht zurzeit {{25}} viel Stress habe. Du hast ja noch mitbekommen, dass ich ein Sportstudium angefangen habe, oder? Tja, an der Uni lief bisher auch alles glatt, aber {{26}} Schulpraktikum habe ich es einfach nicht geschafft, mich bei einer Gruppe von zwanzig 14-jährigen Jungs {{27}}. Die waren total laut und haben nur das gemacht, {{28}} sie wollten. Die Stunde endete in einem {{29}} Chaos.\n\nDeshalb hab ich im Moment eine mittelgroße Krise und kann {{30}} gar nicht mehr vorstellen, Lehrer zu werden. Aber vielleicht hast Du ja ein paar Tipps und Kniffe für mich, wie man sich bei einem Haufen pubertierender Jungs Gehör verschaffen kann?\n\nBitte schreib mir schnell zurück!\n\nAlso hoffentlich bis bald\nDein etwas verzweifelter Matthias",
      "questions": {
        "21": {
          "options": [
            "gelassen",
            "lassen",
            "ließ"
          ],
          "answer": 1,
          "note": "Infinitiv nach Modalverb „will“: „will ich Dich nicht warten lassen“."
        },
        "22": {
          "options": [
            "denn",
            "weil",
            "wenn"
          ],
          "answer": 1,
          "note": "Kausaler Nebensatz mit Verbendstellung: „Nicht zuletzt, weil ich ... erfahren möchte.“"
        },
        "23": {
          "options": [
            "als",
            "für",
            "wie"
          ],
          "answer": 0,
          "note": "Beruf/Funktion: „Deinen neuen Job als Fußballtrainer“."
        },
        "24": {
          "options": [
            "dass",
            "ob",
            "wann"
          ],
          "answer": 0,
          "note": "Objektsatz nach „Ich wusste gar nicht, dass ...“."
        },
        "25": {
          "options": [
            "eigentlich",
            "unbedingt",
            "ziemlich"
          ],
          "answer": 2,
          "note": "Gradpartikel: „ziemlich viel Stress“."
        },
        "26": {
          "options": [
            "beim",
            "in",
            "während"
          ],
          "answer": 0,
          "note": "„beim (= bei dem) Schulpraktikum“."
        },
        "27": {
          "options": [
            "durchsetzen",
            "durchzusetzen",
            "zu durchsetzen"
          ],
          "answer": 1,
          "note": "Infinitiv mit „zu“ bei trennbarem Verb: „durchzusetzen“."
        },
        "28": {
          "options": [
            "das",
            "was",
            "welches"
          ],
          "answer": 1,
          "note": "Relativpronomen nach „das“: „nur das gemacht, was sie wollten“."
        },
        "29": {
          "options": [
            "totalem",
            "totalen",
            "totales"
          ],
          "answer": 1,
          "note": "Nach unbestimmtem Artikel im Dativ („einem“) schwache Endung „-en“: „in einem totalen Chaos“."
        },
        "30": {
          "options": [
            "mich",
            "mir",
            "sich"
          ],
          "answer": 1,
          "note": "sich (Dativ) etwas vorstellen: „kann mir gar nicht mehr vorstellen“."
        }
      }
    },
    {
      "id": "31",
      "num": "31",
      "page": 397,
      "isVariant": false,
      "title": "Prüfung bestanden & Wochenendtrip nach London (Liebe Daniela)",
      "category": "Persönlicher Brief / Prüfung & Reise",
      "text": "Liebe Daniela,\n\nich habe schon ein ganz schlechtes Gewissen, denn {{21}} wollte ich dir schon vor zwei Monaten schreiben. Aber du weißt ja, wie das ist: Wenn man sich auf eine Prüfung vorbereitet, hat {{22}} überhaupt keine Zeit mehr für seine Hobbys – alles dreht sich nur noch ums Lernen.\n\nNun habe ich es aber geschafft: Gestern war die Prüfung und ich bin zuversichtlich, dass ich sie bestanden habe. Mein Freund, mit {{23}} Hilfe es mir überhaupt nur möglich war, diese ganze Zeit zu {{24}}, hat mich für heute Abend in ein tolles Restaurant eingeladen. Danach gehen wir auch noch tanzen.\n\nIn deinem letzten Brief hast du mich gefragt, {{25}} ich Lust hätte, mit dir zusammen ein Wochenende in London zu verbringen. Natürlich habe ich Lust! Nach dem ganzen Stress der letzten Wochen fände ich es super, mal ein paar Tage lang mit einer Freundin etwas Tolles zu {{26}}. London ist eine wunderbare Stadt, ich habe schon {{27}} viele Berichte darüber gelesen. Ich würde mich besonders {{28}} die Tate Gallery und das Filmmuseum interessieren.\n\nMach {{29}} einfach ein paar Vorschläge, wann du Zeit hast. Ich bin sicher, dass wir {{30}} auf ein Wochenende einigen können. In der Zwischenzeit drucke ich schon mal ein paar Angebote aus dem Internet aus: preiswerte Flüge, ein schönes und günstiges Hotel für uns usw. Ich freue mich schon auf deinen nächsten Brief.\n\nHerzliche Grüße\nAndrea",
      "questions": {
        "21": {
          "options": [
            "außerdem",
            "eigentlich",
            "überhaupt"
          ],
          "answer": 1,
          "note": "„denn eigentlich (= ursprünglich) wollte ich dir schon vor zwei Monaten schreiben“."
        },
        "22": {
          "options": [
            "er",
            "es",
            "man"
          ],
          "answer": 2,
          "note": "Wiederaufnahme des Indefinitpronomens aus dem Wenn-Satz: „Wenn man ..., hat man ...“."
        },
        "23": {
          "options": [
            "der",
            "dessen",
            "seiner"
          ],
          "answer": 1,
          "note": "Relativpronomen im Genitiv Maskulinum Singular („Mein Freund, mit dessen Hilfe ...“)."
        },
        "24": {
          "options": [
            "übersetzen",
            "überstehen",
            "übertragen"
          ],
          "answer": 1,
          "note": "„eine schwierige Zeit überstehen“ (= durchhalten / bewältigen)."
        },
        "25": {
          "options": [
            "dass",
            "falls",
            "ob"
          ],
          "answer": 2,
          "note": "Indirekte Entscheidungsfrage nach „gefragt“: „ob ich Lust hätte“."
        },
        "26": {
          "options": [
            "verbringen",
            "verplanen",
            "unternehmen"
          ],
          "answer": 2,
          "note": "Kollokation: „etwas Tolles unternehmen“."
        },
        "27": {
          "options": [
            "ganz",
            "recht",
            "zwar"
          ],
          "answer": 0,
          "note": "Verstärkung vor „viele“: „ganz viele Berichte“."
        },
        "28": {
          "options": [
            "auf",
            "für",
            "in"
          ],
          "answer": 1,
          "note": "Feste Präposition: „sich interessieren für (+ Akkusativ)“."
        },
        "29": {
          "options": [
            "bestimmt",
            "doch",
            "sicher"
          ],
          "answer": 1,
          "note": "Freundliche Aufforderungspartikel im Imperativsatz: „Mach doch einfach ein paar Vorschläge!“"
        },
        "30": {
          "options": [
            "euch",
            "uns",
            "sich"
          ],
          "answer": 1,
          "note": "Reflexivpronomen 1. Person Plural: „dass wir uns ... einigen können“."
        }
      }
    },
    {
      "id": "32",
      "num": "32",
      "page": 398,
      "isVariant": false,
      "title": "Einladung als Referentin zum Anti-Raucher-Tag (Frau Stein)",
      "category": "Formeller Geschäftsbrief / Veranstaltung",
      "text": "Sehr geehrte Frau Stein,\n\nanlässlich {{21}} über die gesundheitlichen Folgen des Rauchens bei Jugendlichen vergangene Woche im Rahmen der Jugend-Gesundheitswoche in Kassel habe ich ja schon kurz mit Ihnen gesprochen. Heute möchte ich anfragen, {{22}} Sie bereit wären, auch hier bei uns in Marburg zu sprechen.\n\nIm Rahmen eines groß angelegten Projekts an den Schulen findet im Juli ein Anti-Raucher-Tag in der Stadthalle statt. Die Veranstaltung beinhaltet {{23}} Vorträge als auch Workshops und Diskussionsforen und dauert von 9 Uhr {{24}} 18 Uhr. Da Sie eine anerkannte Gesundheitsexpertin sind, {{25}} Themen gerade junge Leute ansprechen und Ihre Vorträge sehr anschaulich sind, würden wir Sie gerne als {{26}} in unser Programm aufnehmen. Die Länge Ihres Vortrags sollte 30 Minuten nicht überschreiten. Im Anschluss an Ihren Vortrag möchten wir interessierten Jugendlichen die Möglichkeit geben, mit Ihnen über das Thema der gesundheitlichen Folgen des Rauchens {{27}}.\n\nSelbstverständlich stehen Ihnen alle modernen Techniken wie Computer oder ein Laptop mit Beamer {{28}}. Bitte teilen Sie uns mit, ob Sie noch andere Hilfsmittel benötigen. Wenn Sie Arbeitsblätter kopieren wollen, schicken Sie uns bitte diese {{29}} vorher zu, damit wir die Kopien für Sie anfertigen können.\n\nWir rechnen {{30}}, dass unsere Veranstaltung von etwa 1000 Jugendlichen aus der gesamten Region besucht werden wird. Ihre Teilnahme an der Veranstaltung wäre eine Bereicherung unseres Programms. Über Ihre Zusage würden wir uns daher sehr freuen.\n\nMit freundlichen Grüßen\nKarl-Heinz Hartung",
      "questions": {
        "21": {
          "options": [
            "Ihres Vortrags",
            "Ihrem Vortrag",
            "Ihren Vortrag"
          ],
          "answer": 0,
          "note": "Präposition „anlässlich“ regiert den Genitiv: „anlässlich Ihres Vortrags“."
        },
        "22": {
          "options": [
            "wenn",
            "ob",
            "dass"
          ],
          "answer": 1,
          "note": "Indirekter Fragesatz nach „anfragen“: „ob Sie bereit wären“."
        },
        "23": {
          "options": [
            "und ... und",
            "sowohl ... als auch",
            "zwar ... aber"
          ],
          "answer": 1,
          "note": "„sowohl Vorträge als auch Workshops“."
        },
        "24": {
          "options": [
            "bis zu",
            "bis vor",
            "bis"
          ],
          "answer": 2,
          "note": "Uhrzeitspanne: „von 9 Uhr bis 18 Uhr“."
        },
        "25": {
          "options": [
            "denen",
            "deren",
            "die"
          ],
          "answer": 1,
          "note": "Relativpronomen im Genitiv feminin Singular („eine Gesundheitsexpertin, deren Themen ...“)."
        },
        "26": {
          "options": [
            "Vortragende",
            "Vorgetragene",
            "Vortrag"
          ],
          "answer": 0,
          "note": "Substantiviertes Partizip I für eine Referentin: „als Vortragende“."
        },
        "27": {
          "options": [
            "geredet haben",
            "zu sprechen",
            "sprechen"
          ],
          "answer": 1,
          "note": "Infinitivsatz nach „die Möglichkeit geben, ... zu sprechen“."
        },
        "28": {
          "options": [
            "zur Verfügung",
            "zu Hilfe",
            "zum Benutzen"
          ],
          "answer": 0,
          "note": "Funktionsverbgefüge: „zur Verfügung stehen“."
        },
        "29": {
          "options": [
            "eines Tages",
            "für einen Tag",
            "ein paar Tage"
          ],
          "answer": 2,
          "note": "Zeitangabe vor „vorher“: „ein paar Tage vorher“."
        },
        "30": {
          "options": [
            "dabei",
            "damit",
            "dafür"
          ],
          "answer": 1,
          "note": "rechnen mit -> Pronominaladverb „Wir rechnen damit, dass ...“."
        }
      }
    },
    {
      "id": "33",
      "num": "33",
      "page": 399,
      "isVariant": false,
      "title": "Tipps gegen Prüfungsangst & Abschlussparty (Lieber Markus)",
      "category": "Persönliche E-Mail / Prüfungserfolg",
      "text": "Lieber Markus,\n\nvielen Dank für deine letzte Mail mit den tollen Tipps gegen Prüfungsangst! Die waren wirklich mehr als hilfreich. Besonders locker war ich natürlich trotzdem nicht. Vor Prüfungen gestresst zu sein, ist ja {{21}} ganz normal, denke ich. Und stell dir vor, jetzt habe ich die Prüfung {{22}} mir und auch schon das Ergebnis, mit dem ich mehr als zufrieden bin. Die schriftliche Prüfung habe ich mit „sehr gut“ {{23}} und die mündliche mit „gut“. Ich hatte mich {{24}} auch wirklich gut darauf vorbereitet. Nur am Anfang in der mündlichen Prüfung hatte ich ein totales Blackout und es dauerte etwas, bis ich {{25}} wieder gefangen hatte.\n\n{{26}} ich das Zeugnis bekomme, bewerbe ich mich hier im Ort {{27}} einer großen Firma. Ich bin eigentlich ganz zuversichtlich, dass es klappt. Mal sehen, {{28}} mich da dann so erwartet. Aber jetzt brauche ich erst mal Abstand von {{29}} ganzen Lernerei.\n\nZwei Dinge sind geplant: Eine große Party, und {{30}} am 14. Juni, und danach eine kurze Reise in die Schweiz zum Bergsteigen. Hast du Lust, auf die Party zu kommen? Ich würde mich sehr freuen.\n\nLieben Gruß\nAlina",
      "questions": {
        "21": {
          "options": [
            "wohl",
            "doch",
            "sogar"
          ],
          "answer": 0,
          "note": "Modalpartikel für Vermutung/Zustimmung: „ist ja wohl ganz normal“."
        },
        "22": {
          "options": [
            "hinter",
            "hinten",
            "hinunter"
          ],
          "answer": 0,
          "note": "Feste Wendung: „die Prüfung hinter sich (Dat.) haben“."
        },
        "23": {
          "options": [
            "gepasst",
            "bestehen",
            "bestanden"
          ],
          "answer": 2,
          "note": "Perfekt: „habe ich mit ‚sehr gut‘ bestanden“."
        },
        "24": {
          "options": [
            "ja",
            "also",
            "wohl"
          ],
          "answer": 0,
          "note": "Modalpartikel „ja“ für bekannte/einleuchtende Begründung: „Ich hatte mich ja auch wirklich gut darauf vorbereitet.“"
        },
        "25": {
          "options": [
            "mir",
            "mich",
            "meins"
          ],
          "answer": 1,
          "note": "Reflexivverb im Akkusativ: „sich wieder fangen“ (= die Fassung wiedergewinnen)."
        },
        "26": {
          "options": [
            "Seit",
            "Nachdem",
            "Sobald"
          ],
          "answer": 2,
          "note": "Temporale Konjunktion mit Präsens für Zukünftiges: „Sobald ich das Zeugnis bekomme“."
        },
        "27": {
          "options": [
            "um",
            "bei",
            "an"
          ],
          "answer": 1,
          "note": "sich bewerben bei (+ Dativ für Firma/Institution; „um“ stünde bei der Stelle)."
        },
        "28": {
          "options": [
            "was",
            "wer",
            "wen"
          ],
          "answer": 0,
          "note": "Indirekter Fragesatz (Subjekt, Sache): „was mich da dann so erwartet“."
        },
        "29": {
          "options": [
            "der",
            "dem",
            "das"
          ],
          "answer": 0,
          "note": "Dativ feminin Singular nach „von“: „von der ganzen Lernerei“."
        },
        "30": {
          "options": [
            "dann",
            "zwar",
            "auch"
          ],
          "answer": 1,
          "note": "Präzisierung: „und zwar am 14. Juni“."
        }
      }
    },
    {
      "id": "34",
      "num": "34",
      "page": 400,
      "isVariant": false,
      "title": "Praktikum in Wilhelmshaven an der Nordsee (Liebe Laura)",
      "category": "Persönlicher Brief / Praktikum",
      "text": "Liebe Laura,\n\nseit drei Wochen bin ich jetzt schon in Deutschland. Mein Praktikum bei der Firma Intermarketing macht mir großen Spaß und ich habe schon viele Dinge gelernt, von {{21}} man an der Berufsschule bestenfalls am Rande hört. Mein Chef ist sehr geduldig mit mir. Besonders in den ersten beiden Wochen war {{22}} mühevoll, an einem fremden Computer zu sitzen und mit all den neuen unbekannten Programmen zu arbeiten. Aber nun habe ich mich {{23}} gewöhnt und muss meinen Chef kaum noch um Rat fragen.\n\nAn das Wetter hier in Wilhelmshaven muss ich mich aber noch gewöhnen. Denn obwohl wir Sommer haben, bläst hier immer ein ordentlicher Wind – eine steife Brise, wie man hier sagt – von der Nordsee her. Man muss ständig {{24}} Pullover dabeihaben, sonst kann man hier auch im August eine Gänsehaut bekommen. Mein Chef sagt dann immer, gegen die steife Brise {{25}} man einen Grog trinken, das ist heißer Tee mit Rum, aber das mag ich nicht.\n\nIn der Firma habe ich Marion kennengelernt. Sie ist wie ich Praktikantin, aber sie ist Deutsche und kommt aus {{26}} Wilhelmshaven. Sie hat mir schon ein bisschen von der Gegend gezeigt und mir die Sehenswürdigkeiten der Stadt vorgestellt. Besonders der Hafen mit {{27}} Containerschiffen und den vielen Seemöwen, die unablässig um {{28}} herumkreisen, hat es mir angetan. Nach der Arbeit verbringen wir hier oft ein oder zwei Stunden in {{29}} der Cafés – oder Teehäuser, denn die Leute hier trinken viel mehr Tee als Kaffee.\n\nManchmal bekomme ich aber schon Heimweh. Dann denke ich auch an dich und daran, dass wir uns bald {{30}}. Es gibt so viel zu erzählen. Melde dich. Warte nicht so lange wie ich, bis du mir schreibst.\n\nHerzliche Grüße\nAlexandra",
      "questions": {
        "21": {
          "options": [
            "dem",
            "denen",
            "deren"
          ],
          "answer": 1,
          "note": "Relativpronomen im Dativ Plural nach „von“ (Bezug auf „viele Dinge“): „von denen man ... hört“."
        },
        "22": {
          "options": [
            "man",
            "es",
            "–"
          ],
          "answer": 1,
          "note": "Formales Subjekt (Korrelat zum Infinitivsatz): „war es mühevoll, ... zu sitzen“."
        },
        "23": {
          "options": [
            "darauf",
            "dazu",
            "daran"
          ],
          "answer": 2,
          "note": "sich gewöhnen an -> Pronominaladverb „habe ich mich daran gewöhnt“."
        },
        "24": {
          "options": [
            "einen",
            "ein",
            "einer"
          ],
          "answer": 0,
          "note": "Akkusativ Maskulinum Singular: „einen Pullover dabeihaben“."
        },
        "25": {
          "options": [
            "müsse",
            "musste",
            "brauche"
          ],
          "answer": 0,
          "note": "Indirekte Rede nach „Mein Chef sagt“ im Konjunktiv I: „müsse man einen Grog trinken“."
        },
        "26": {
          "options": [
            "der Nähe",
            "die Nähe",
            "der Nähe von"
          ],
          "answer": 2,
          "note": "Vor Städtenamen ohne Artikel steht „von“: „aus der Nähe von Wilhelmshaven“."
        },
        "27": {
          "options": [
            "den großen",
            "großem",
            "dem großen"
          ],
          "answer": 0,
          "note": "Dativ Plural nach „mit“: „mit den großen Containerschiffen“."
        },
        "28": {
          "options": [
            "den Schiffen",
            "die Schiffe",
            "die Schiffen"
          ],
          "answer": 1,
          "note": "Präposition „um“ regiert den Akkusativ Plural: „um die Schiffe herumkreisen“."
        },
        "29": {
          "options": [
            "eins",
            "einem",
            "ein"
          ],
          "answer": 1,
          "note": "Dativ Neutrum nach „in“ (Wo?): „in einem der Cafés“."
        },
        "30": {
          "options": [
            "wiederzusehen brauchen",
            "müssen wiedersehen",
            "wiedersehen müssen"
          ],
          "answer": 2,
          "note": "Nebensatz mit „dass“: Infinitiv + konjugiertes Modalverb am Ende („wiedersehen müssen“)."
        }
      }
    },
    {
      "id": "35",
      "num": "35",
      "page": 401,
      "isVariant": false,
      "title": "Zimmer in einer Berufstätigen-WG (Hallo Rahim)",
      "category": "Persönliche E-Mail / Wohnungssuche & WG",
      "text": "Hallo Rahim,\n\nvielen Dank für deine Mail und deine Fragen zu dem Zimmer in unserer WG. Wir freuen uns {{21}} dein Interesse an dem Zimmer und beantworten dir gerne alles.\n\nDie Wohnung befindet {{22}} im dritten Stock eines Altbaus. Sie hat zwei Badezimmer, die wir gemeinschaftlich nutzen, und eine sehr gut ausgestattete Küche – inklusive Spülmaschine. Wir haben außerdem einen großen Balkon, {{23}} man bei gutem Wetter eine super Aussicht hat. Das Zimmer, das zu vermieten ist, kann nach eigenen Wünschen gestaltet {{24}}. Es ist 28 qm groß und nicht möbliert.\n\nWir sind übrigens keine Studenten-WG, sondern eine „Berufstätigen-WG“. Mein Mitbewohner Johannes ist Sozialarbeiter und ich beschäftige mich beruflich {{25}} der Entwicklung von Lernsoftware. Unsere Freizeitinteressen sind teilweise recht unterschiedlich. Johannes liebt Sport aller Art und ist viel unterwegs, {{26}} ich meinen Feierabend gern auf dem Sofa ausklingen lasse. Wir kochen aber oft zusammen und machen auch mal einen Spieleabend. Generell geht es bei uns eher ruhig zu. Abends trinken wir {{27}} gerne mal ein Gläschen Wein mit Freunden, aber große Partys feiern wir hier fast nie. Wir wünschen uns einen Mitbewohner, {{28}} Lebensstil zu unserem passt. Ein Nichtraucher wäre super, aber mit einem Raucher, der zum Rauchen auf den Balkon geht, könnten wir auch gut leben.\n\nSchön, dass du anbietest vorbeizukommen, {{29}} wir uns persönlich kennenlernen können. Morgen klappt es allerdings leider nicht. Wenn ich eher {{30}}, dass du dann in der Stadt bist, hätte ich mir Zeit freigehalten, aber so habe ich den Tag schon verplant. Könntest du vielleicht auch am Sonntag?\n\nViele Grüße\nTill",
      "questions": {
        "21": {
          "options": [
            "für",
            "über",
            "wegen"
          ],
          "answer": 1,
          "note": "sich freuen über (+ Akkusativ): „über dein Interesse“."
        },
        "22": {
          "options": [
            "man",
            "sich",
            "uns"
          ],
          "answer": 1,
          "note": "Reflexivverb: „Die Wohnung befindet sich ...“."
        },
        "23": {
          "options": [
            "auf der",
            "für den",
            "von dem"
          ],
          "answer": 2,
          "note": "Relativsatz zu „einen großen Balkon“ (Maskulinum): „von dem (aus) man eine super Aussicht hat“."
        },
        "24": {
          "options": [
            "werden",
            "wurden",
            "würden"
          ],
          "answer": 0,
          "note": "Passiv-Infinitiv nach Modalverb „kann“: „kann gestaltet werden“."
        },
        "25": {
          "options": [
            "an",
            "in",
            "mit"
          ],
          "answer": 2,
          "note": "sich beschäftigen mit (+ Dativ)."
        },
        "26": {
          "options": [
            "anstatt",
            "sondern",
            "während"
          ],
          "answer": 2,
          "note": "Adversative Nebensatzkonjunktion (Gegenüberstellung): „während ich meinen Feierabend ... ausklingen lasse“."
        },
        "27": {
          "options": [
            "entweder",
            "sowohl",
            "zwar"
          ],
          "answer": 2,
          "note": "Konzessive Verbindung: „zwar ..., aber ...“."
        },
        "28": {
          "options": [
            "denen",
            "dessen",
            "seinen"
          ],
          "answer": 1,
          "note": "Relativpronomen im Genitiv Maskulinum Singular („einen Mitbewohner, dessen Lebensstil ...“)."
        },
        "29": {
          "options": [
            "damit",
            "deswegen",
            "indem"
          ],
          "answer": 0,
          "note": "Finalsatz (Zweck): „damit wir uns persönlich kennenlernen können“."
        },
        "30": {
          "options": [
            "gewusst habe",
            "gewusst hätte",
            "wüsste"
          ],
          "answer": 1,
          "note": "Irrealer Bedingungssatz der Vergangenheit (Konjunktiv II Plusquamperfekt): „Wenn ich eher gewusst hätte ..., hätte ich mir Zeit freigehalten.“"
        }
      }
    },
    {
      "id": "36",
      "num": "36",
      "page": 402,
      "isVariant": false,
      "title": "Reklamation eines tragbaren CD-Players (Brauckmann Versand)",
      "category": "Formelles Reklamationsschreiben",
      "text": "Brauckmann Versand\nDorotheenplatz 8\n04109 Leipzig\n\nReklamation\n\nSehr geehrte Damen und Herren,\n\nvor zwei {{21}} habe ich bei Ihnen einen tragbaren CD-Player bestellt und erhalten. Leider muss ich {{22}} heute mitteilen, dass er kaputt ist. Die CDs wurden von Anfang an nicht richtig eingezogen. Man {{23}} die Taste mehrmals drücken, erst dann funktionierte das Gerät. Jetzt lässt es sich gar nicht mehr öffnen.\n\nAuf dem Gerät sind {{24}} vier Monate Garantie. Ich schicke Ihnen {{25}} das Gerät zurück, Garantiekarte und Rechnung sind beigefügt.\n\nIch darf Sie bitten, das Gerät entweder zu reparieren {{26}} umzutauschen. Falls das nicht möglich ist, würde ich Sie {{27}} Erstattung des Kaufpreises bitten.\n\nIn sechs Wochen kehre ich in {{28}} Heimat zurück, d. h. ich verlasse Deutschland. Ich möchte das Gerät natürlich gern {{29}}. Daher wäre ich Ihnen dankbar, wenn Sie die Angelegenheit möglichst umgehend klären und {{30}} dann benachrichtigen würden.\n\nIn der Hoffnung auf eine positive Nachricht\n\nMit freundlichen Grüßen",
      "questions": {
        "21": {
          "options": [
            "Monaten",
            "Monate",
            "Monats"
          ],
          "answer": 0,
          "note": "Präposition „vor“ (temporal) + Dativ Plural („mit -n“): „vor zwei Monaten“."
        },
        "22": {
          "options": [
            "ihnen",
            "Ihnen",
            "Sie"
          ],
          "answer": 1,
          "note": "jemandem (Dativ) etwas mitteilen -> Großschreibung der Höflichkeitsform „Ihnen“."
        },
        "23": {
          "options": [
            "müssen",
            "muss",
            "musste"
          ],
          "answer": 2,
          "note": "Präteritum passend zu „wurden ... eingezogen“ und „funktionierte“: „Man musste ... drücken“."
        },
        "24": {
          "options": [
            "endlich",
            "noch",
            "schon"
          ],
          "answer": 1,
          "note": "Verbleibende Garantiezeit: „sind noch vier Monate Garantie“."
        },
        "25": {
          "options": [
            "denn",
            "deshalb",
            "weshalb"
          ],
          "answer": 1,
          "note": "Kausaladverb im Hauptsatz: „Ich schicke Ihnen deshalb das Gerät zurück.“"
        },
        "26": {
          "options": [
            "oder",
            "sondern",
            "sonst"
          ],
          "answer": 0,
          "note": "Zweiteilige Konjunktion: „entweder ... oder ...“."
        },
        "27": {
          "options": [
            "für",
            "um",
            "wegen"
          ],
          "answer": 1,
          "note": "Feste Präposition: „jemanden bitten um (+ Akkusativ)“."
        },
        "28": {
          "options": [
            "meine",
            "meinem",
            "meiner"
          ],
          "answer": 0,
          "note": "Richtung (wohin?) -> „in“ + Akkusativ feminin Singular: „in meine Heimat zurückkehren“."
        },
        "29": {
          "options": [
            "mitgenommen",
            "mitnehmen",
            "mitnehme"
          ],
          "answer": 1,
          "note": "Infinitiv am Satzende nach Modalverb „möchte“: „möchte ... mitnehmen“."
        },
        "30": {
          "options": [
            "mich",
            "dich",
            "mir"
          ],
          "answer": 0,
          "note": "jemanden (Akkusativ) benachrichtigen -> „mich dann benachrichtigen würden“."
        }
      }
    },
    {
      "id": "37",
      "num": "37",
      "page": 403,
      "isVariant": false,
      "title": "Mit sechzig Jahren noch Italienisch lernen (Liebe Anna)",
      "category": "Persönlicher Brief / Sprachenlernen im Alter",
      "text": "Liebe Anna,\n\ndanke für deinen lieben Brief, {{21}} ich letzte Woche erhalten habe. Ich freue mich sehr, dass es dir gut geht und dass du einen schönen Urlaub in Verona verbracht {{22}}. Bestimmt wirst du jetzt öfter nach Italien reisen, wo doch dein Enkel dort die Frau fürs Leben gefunden hat und schon im September heiraten wird.\n\nDu hast {{23}} gefragt, was ich davon halte, wenn du in deinem Alter noch Italienisch lernst. Sicherlich sind wir beide nicht mehr die Allerjüngsten, {{24}} zum Sprachenlernen sind wir bestimmt {{25}} jung genug. Was sind schon sechzig Jahre?\n\nSieh mal: Als Chefsekretärin in deiner Firma sprichst du fließend Englisch und Französisch, du hast mit fünfzig noch gelernt, wie man einen Computer {{26}}. Und heute bist du eine Computerspezialistin! Willst du, dass der „Computer“ in deinem Kopf einrostet, bloß weil du Angst hast, mit sechzig noch etwas Neues {{27}}?\n\nNein, zu alt ist man nie! Lernen hält geistig fit und du kannst obendrein deine neuen Kenntnisse ganz praktisch {{28}}. Du hast doch immer von deinen Reiseplänen erzählt: Florenz, Rom, Neapel! Und die Freundin deines Enkels ist doch Italienerin.\n\n{{29}} du mich fragst, dann geh in den nächsten Italienischkurs und lerne diese Sprache. Und kümmere dich nicht um dein (oder besser gesagt unser) Alter. Denn auch ich habe angefangen, eine Sprache zu lernen: Seit zwei Wochen besuche ich zweimal pro Woche einen Russischkurs an der Volkshochschule. Das macht einen Riesenspaß.\n\nJetzt muss ich aber aufhören, ich muss {{30}} gleich in den Kurs. Bis bald – und viele Grüße an deinen Enkel und seine Verlobte.\n\nDeine Karin",
      "questions": {
        "21": {
          "options": [
            "das",
            "den",
            "der"
          ],
          "answer": 1,
          "note": "Relativpronomen im Akkusativ Maskulinum Singular („deinen lieben Brief, den ich ... erhalten habe“)."
        },
        "22": {
          "options": [
            "bist",
            "hast",
            "warst"
          ],
          "answer": 1,
          "note": "Perfekt von „verbringen“ wird mit „haben“ gebildet: „verbracht hast“."
        },
        "23": {
          "options": [
            "mich",
            "mir",
            "sich"
          ],
          "answer": 0,
          "note": "jemanden (Akkusativ) fragen: „Du hast mich gefragt“."
        },
        "24": {
          "options": [
            "doch",
            "obwohl",
            "sondern"
          ],
          "answer": 0,
          "note": "Koordinierende Konjunktion (= aber): „..., doch zum Sprachenlernen sind wir ...“."
        },
        "25": {
          "options": [
            "erst",
            "noch",
            "schon"
          ],
          "answer": 1,
          "note": "„bestimmt noch jung genug“."
        },
        "26": {
          "options": [
            "bearbeitet",
            "bedient",
            "bewirkt"
          ],
          "answer": 1,
          "note": "Kollokation: „einen Computer / ein Gerät bedienen“."
        },
        "27": {
          "options": [
            "lernen",
            "lernen müssen",
            "zu lernen"
          ],
          "answer": 2,
          "note": "Infinitivgruppe nach „Angst haben, ... zu lernen“."
        },
        "28": {
          "options": [
            "einsetzen",
            "fortsetzen",
            "übersetzen"
          ],
          "answer": 0,
          "note": "Kenntnisse praktisch „einsetzen“ (= anwenden / nutzen)."
        },
        "29": {
          "options": [
            "Ob",
            "Wann",
            "Wenn"
          ],
          "answer": 2,
          "note": "Konditionalsatz: „Wenn du mich fragst, dann ...“."
        },
        "30": {
          "options": [
            "also",
            "kaum",
            "nämlich"
          ],
          "answer": 2,
          "note": "Nachgeschobene Begründung: „ich muss nämlich gleich in den Kurs“."
        }
      }
    },
    {
      "id": "38",
      "num": "38",
      "page": 404,
      "isVariant": false,
      "title": "Psychologie-Studium an einer Fernuniversität (Liebe Meike)",
      "category": "Persönliche E-Mail / Fernstudium & Beruf",
      "text": "Liebe Meike,\n\nvielen Dank für deine Mail! Es freut mich, dass du dich in Bremen wohlfühlst und mit deiner {{21}} Arbeit zufrieden bist. Auch ich habe eine Menge zu erzählen. Du weißt ja, wie unzufrieden ich in letzter Zeit oft war. {{22}} ich einen neuen Chef habe, hat sich in der Firma viel verändert: Die Arbeitsatmosphäre ist schlechter geworden und ich muss viele Überstunden machen. Daher habe ich oft {{23}} nachgedacht, ob ein beruflicher Neuanfang das Richtige für mich wäre.\n\nNun, inzwischen habe ich den ersten Schritt unternommen: Ich habe {{24}} an einer Fernuniversität für ein Psychologie-Studium eingeschrieben. {{25}} ich zuerst einige Bedenken hatte, bin ich nun sehr froh über meine Entscheidung. Anfangs war ich mir nicht sicher, ob ich nebenberuflich ein Studium schaffen {{26}}. Schließlich muss ich ja auch noch meinen Lebensunterhalt verdienen. Außerdem hatte ich Angst, dass mir das Lernen nicht mehr so leichtfallen würde {{27}} früher.\n\nDas Studium macht mir wirklich Spaß. Allerdings habe ich es unterschätzt, wie viel Zeit die Vorbereitungen in Anspruch {{28}}. Manchmal fehlt mir beim Fernunterricht der direkte Austausch mit Kommilitonen, denn den Lernstoff arbeite ich meistens alleine zu Hause durch. Für {{29}} ist es aber eine große Hilfe, dass die Fernuniversität Chatgruppen anbietet, in {{30}} man rund um die Uhr Fragen stellen kann.\n\nIch bin jedenfalls gespannt, wie es mit meinem Studium weitergeht. Wie wäre es, wenn wir demnächst mal wieder telefonieren? Ich würde mich freuen, bald von dir zu hören.\n\nHerzliche Grüße",
      "questions": {
        "21": {
          "options": [
            "neue",
            "neuen",
            "neuer"
          ],
          "answer": 1,
          "note": "Dativ feminin Singular nach „mit deiner“: „mit deiner neuen Arbeit“."
        },
        "22": {
          "options": [
            "Seit",
            "Sobald",
            "Solange"
          ],
          "answer": 0,
          "note": "Beginn in der Vergangenheit mit Andauern bis heute: „Seit ich einen neuen Chef habe“."
        },
        "23": {
          "options": [
            "daran",
            "darauf",
            "darüber"
          ],
          "answer": 2,
          "note": "nachdenken über -> Pronominaladverb „darüber nachgedacht, ob ...“."
        },
        "24": {
          "options": [
            "es",
            "mich",
            "mir"
          ],
          "answer": 1,
          "note": "Reflexivverb mit Akkusativ: „sich an einer Universität einschreiben“."
        },
        "25": {
          "options": [
            "Damit",
            "Obwohl",
            "Wenn"
          ],
          "answer": 1,
          "note": "Konzessivsatz: „Obwohl ich zuerst einige Bedenken hatte, bin ich nun sehr froh ...“."
        },
        "26": {
          "options": [
            "dürfte",
            "könnte",
            "müsste"
          ],
          "answer": 1,
          "note": "Möglichkeit/Fähigkeit im Konjunktiv II: „ob ich nebenberuflich ein Studium schaffen könnte“."
        },
        "27": {
          "options": [
            "als",
            "noch",
            "wie"
          ],
          "answer": 2,
          "note": "Vergleich nach „so“: „nicht mehr so leichtfallen würde wie früher“."
        },
        "28": {
          "options": [
            "nahmen",
            "nehmen",
            "nimmt"
          ],
          "answer": 1,
          "note": "Funktionsverbgefüge im Plural („die Vorbereitungen“): „Zeit in Anspruch nehmen“."
        },
        "29": {
          "options": [
            "mein",
            "mich",
            "mir"
          ],
          "answer": 1,
          "note": "Präposition „für“ + Akkusativ: „Für mich ist es eine große Hilfe“."
        },
        "30": {
          "options": [
            "denen",
            "der",
            "die"
          ],
          "answer": 0,
          "note": "Relativpronomen im Dativ Plural nach „in“ (Wo?): „Chatgruppen, in denen man Fragen stellen kann“."
        }
      }
    },
    {
      "id": "39",
      "num": "39",
      "page": 405,
      "isVariant": false,
      "title": "Firmenaktion „Mit dem Rad zur Arbeit“",
      "category": "Rundschreiben im Betrieb / Gesundheit",
      "text": "Liebe Kolleginnen und Kollegen!\n\nVom 1. April bis zum 30. Oktober findet auch heuer wieder unsere beliebte Aktion „Mit dem Rad zur Arbeit“ statt. Wie jedes Jahr möchten wir Euch gerne {{21}} einladen, etwas für Eure Gesundheit zu tun.\n\nWie Ihr wisst, steigert schon eine halbe Stunde tägliches Fahrradfahren die Fitness. Damit wird auch das Krankheitsrisiko reduziert. Darum heißt es: Aufs Rad steigen und mitmachen! {{22}} Ihr den Arbeitsweg mit Bewegung verbindet, nützt das nicht nur Eurer Gesundheit. Ihr helft damit auch, den Verkehr und die Luftverschmutzung in unserem Stadtgebiet zu verringern. Als angenehme Nebenerscheinung hilft das Radfahren auch noch {{23}} Sparen.\n\nDieses Jahr gibt es zusätzlich noch die Möglichkeit, {{24}} zu gewinnen. Wir stellen Preise im Gesamtwert von 2500 Euro zur Verfügung. Was Ihr dafür tun sollt? Ganz einfach: Teams zu dritt bilden, gefahrene Kilometer in einen Pass eintragen und bis {{25}} 5. November im Sekretariat abgeben. Die drei Teams, die {{26}} Arbeit und Wohnung die meisten Kilometer zurückgelegt haben, bekommen am Ende einen Preis. Wer noch kein Team hat, kann {{27}} bei Frau Maier (Durchwahl 1245) melden. Wir bringen Euch gerne zusammen!\n\nIhr dürft uns auch Fotos und Berichte von Eurem Team schicken; diese veröffentlichen wir dann in der Betriebszeitung. Natürlich könnt Ihr auch heuer wieder Euer Rad kostenlos von unserem technischen Dienst {{28}} lassen. Eure Sicherheit liegt uns ganz besonders {{29}} Herzen!\n\nWir hoffen {{30}} eine rege Teilnahme und wünschen Euch jetzt schon alles Gute und viel Vergnügen beim Radeln!",
      "questions": {
        "21": {
          "options": [
            "dafür",
            "daran",
            "dazu"
          ],
          "answer": 2,
          "note": "einladen zu -> Pronominaladverb „dazu einladen, ... zu tun“."
        },
        "22": {
          "options": [
            "Als",
            "Ob",
            "Wenn"
          ],
          "answer": 2,
          "note": "Konditional-/Temporalsatz im Präsens: „Wenn Ihr den Arbeitsweg mit Bewegung verbindet“."
        },
        "23": {
          "options": [
            "an das",
            "beim",
            "zur"
          ],
          "answer": 1,
          "note": "helfen bei + substantiviertem Infinitiv: „hilft beim Sparen“."
        },
        "24": {
          "options": [
            "einige",
            "etwas",
            "keine"
          ],
          "answer": 1,
          "note": "Indefinitpronomen: „die Möglichkeit, etwas zu gewinnen“."
        },
        "25": {
          "options": [
            "alsbald",
            "beizeiten",
            "spätestens"
          ],
          "answer": 2,
          "note": "Fristangabe: „bis spätestens 5. November“."
        },
        "26": {
          "options": [
            "entlang",
            "von",
            "zwischen"
          ],
          "answer": 2,
          "note": "Wegstrecke mit zwei Endpunkten: „zwischen Arbeit und Wohnung“."
        },
        "27": {
          "options": [
            "euch",
            "ihn",
            "sich"
          ],
          "answer": 2,
          "note": "„Wer“ ist grammatisch 3. Person Singular -> Reflexivpronomen „sich melden“."
        },
        "28": {
          "options": [
            "übergeben",
            "übernehmen",
            "überprüfen"
          ],
          "answer": 2,
          "note": "Ein Fahrrad vom technischen Dienst „überprüfen (= kontrollieren) lassen“."
        },
        "29": {
          "options": [
            "am",
            "beim",
            "zum"
          ],
          "answer": 0,
          "note": "Feste Redewendung: „jemandem am Herzen liegen“."
        },
        "30": {
          "options": [
            "an",
            "auf",
            "mit"
          ],
          "answer": 1,
          "note": "Feste Präposition: „hoffen auf (+ Akkusativ)“."
        }
      }
    },
    {
      "id": "40",
      "num": "40",
      "page": 406,
      "isVariant": false,
      "title": "Halbjahresbilanz & Einladung zum Sommerfest",
      "category": "Rundschreiben der Geschäftsführung",
      "text": "Liebe Mitarbeiterinnen und Mitarbeiter,\n\nwir haben nun fast das Halbjahr geschafft und ich möchte mich bei allen für diese gute und fruchtbare Zusammenarbeit bedanken. Einige der Jahresziele, {{21}} wir uns im letzten Jahr für heuer vorgenommen hatten, konnten wir bereits erreichen und ich bin davon überzeugt, {{22}} wir auch noch die restlichen bis Jahresende gut meistern werden.\n\nUm einige der Besonderheiten in diesem Jahr zu nennen: Im ersten Halbjahr konnten wir die Verkaufszahlen unseres {{23}} um 35 % steigern und die Klicks auf unserer Homepage haben sich mehr als verdoppelt. Dies ist auch ein Mitverdienst der KommunikationsexpertInnen in unserer Firma, {{24}} ich ein besonderes Lob für die guten Werbemaßnahmen aussprechen möchte.\n\nWeiters konnten wir mit zwei großen Verlagen in Österreich Kooperationspartnerschaften eingehen und dadurch unseren Absatzmarkt erweitern. Hier gilt weiterhin, die Kooperationen {{25}} stärken, viel Arbeit zu investieren und dennoch auf die Interessen der Kooperationspartner nicht zu vergessen. Eine solche Annäherung bedarf großer Sensibilität, damit die Arbeit auch in Zukunft Früchte tragen wird.\n\nDie Ausgabe {{26}} Sommer haben wir bereits finalisiert und es sind nur mehr einige wenige Schritte bis zum Druck notwendig. {{27}} Mal werden auch beide Kooperationspartner auf der Titelseite vertreten sein. An dieser Stelle muss ich mich auch {{28}} den Graphikerinnen für die besonders gelungene und ansprechende Lösung bedanken. Beide Partner waren von der Gestaltung mehr als begeistert.\n\nAbschließend darf ich nun die Einladung zum diesjährigen Sommerfest verkünden, {{29}} diesmal im Palais Schönberg stattfinden wird. Ich lade Sie alle herzlich dazu ein, unseren {{30}} Erfolg in diesem Halbjahr bei einem wunderbaren Buffet und herrlicher Musik zu feiern.\n\nHerzlichst\nDie Geschäftsführung",
      "questions": {
        "21": {
          "options": [
            "der",
            "die",
            "diese"
          ],
          "answer": 1,
          "note": "Relativpronomen im Akkusativ Plural („Einige der Jahresziele, die wir uns vorgenommen hatten“)."
        },
        "22": {
          "options": [
            "das",
            "ob",
            "dass"
          ],
          "answer": 2,
          "note": "Objektsatz nach „überzeugt sein, dass ...“."
        },
        "23": {
          "options": [
            "Magazin",
            "Magazins",
            "Magazines"
          ],
          "answer": 1,
          "note": "Genitiv Neutrum Singular: „unseres Magazins“."
        },
        "24": {
          "options": [
            "den",
            "dem",
            "denen"
          ],
          "answer": 2,
          "note": "jemandem (Dativ Plural) ein Lob aussprechen -> Relativpronomen „denen“."
        },
        "25": {
          "options": [
            "zu",
            "zum",
            "zur"
          ],
          "answer": 0,
          "note": "Infinitiv mit „zu“ nach „Hier gilt weiterhin, die Kooperationen zu stärken“."
        },
        "26": {
          "options": [
            "im",
            "in",
            "aus"
          ],
          "answer": 0,
          "note": "Bei Jahreszeiten steht „im“: „Die Ausgabe im Sommer“."
        },
        "27": {
          "options": [
            "Dieses",
            "Diese",
            "Diesen"
          ],
          "answer": 0,
          "note": "Akkusativ der Zeit (Neutrum Singular „das Mal“): „Dieses Mal“."
        },
        "28": {
          "options": [
            "von",
            "bei",
            "für"
          ],
          "answer": 1,
          "note": "sich bedanken bei (+ Dativ der Person) für (+ Akkusativ der Sache)."
        },
        "29": {
          "options": [
            "welcher",
            "welchem",
            "welches"
          ],
          "answer": 2,
          "note": "Relativpronomen im Nominativ Neutrum Singular (Bezug auf „das Sommerfest“): „welches“."
        },
        "30": {
          "options": [
            "gemeinsames",
            "gemeinsamen",
            "gemein"
          ],
          "answer": 1,
          "note": "Akkusativ Maskulinum Singular („der Erfolg“): „unseren gemeinsamen Erfolg“."
        }
      }
    },
    {
      "id": "41",
      "num": "41",
      "page": 407,
      "isVariant": false,
      "title": "Wartungsarbeiten vor dem Winter & Hausordnung",
      "category": "Aushang der Hausverwaltung",
      "text": "Liebe HausbewohnerInnen,\n\nder Winter ist nicht mehr weit, das Haus soll deshalb winterfest gemacht werden. {{21}} sind noch einige Vorbereitungen nötig.\n\nBevor die Heizsaison beginnt, stehen Wartungsarbeiten im Heizraum an. Diese {{22}} in der Zeit vom 8.11. bis 10.11. durchgeführt. Um den reibungslosen Ablauf der Arbeiten zu ermöglichen, bitten wir alle BewohnerInnen, {{23}} zu diesem Datum sämtliche abgestellte Gegenstände (wie z. B. Schlitten) aus dem Heizraum zu entfernen.\n\nDes Weiteren sind über den Sommer einige Schäden am Gebäude entstanden, die vor Winterbeginn noch {{24}} werden müssen. Drei Fensterscheiben sind zu Bruch gegangen; das betrifft die Kellerabteile 5 und 7. Die Mitarbeiter der Glaserfirma werden am 12.11. kommen, {{25}} neue Fensterscheiben einzusetzen. Wir bitten Sie, an diesen Tagen den Zugang zu Ihren Kellerabteilen zu {{26}} und den Bereich vor den Fenstern nicht durch Objekte zu verstellen.\n\nAn dieser Stelle erfolgt noch ein kurzer Aufruf an alle HausbewohnerInnen, aufeinander Rücksicht zu nehmen. Es ist in {{27}} Zeit vermehrt zu Beschwerden gekommen. Bitte rufen Sie sich unsere Hausordnung wieder in Erinnerung. Lärm und laute Musik sind nach 22 Uhr untersagt, achten Sie aber zu jeder Tageszeit darauf, {{28}} sich Ihre Nachbarn nicht gestört fühlen. Fußballspielen u. Ä. ist nur im Bereich des Kinderspielplatzes hinter dem Haus gestattet. Auf den Parkplätzen und im Eingangsbereich darf nicht mit {{29}} gespielt werden.\n\nWir danken für die Zusammenarbeit und verbleiben mit {{30}} Grüßen,\ndie Hausverwaltung",
      "questions": {
        "21": {
          "options": [
            "Dafür",
            "Damit",
            "So"
          ],
          "answer": 0,
          "note": "Pronominaladverb für Zweck/Voraussetzung: „Dafür sind noch einige Vorbereitungen nötig.“"
        },
        "22": {
          "options": [
            "sind",
            "werden",
            "können"
          ],
          "answer": 1,
          "note": "Vorgangspassiv: „Diese werden ... durchgeführt.“"
        },
        "23": {
          "options": [
            "bis",
            "bei",
            "vor"
          ],
          "answer": 0,
          "note": "Fristangabe: „bis zu diesem Datum“."
        },
        "24": {
          "options": [
            "beheben",
            "behebt",
            "behoben"
          ],
          "answer": 2,
          "note": "Partizip II von „beheben“ im Passiv mit Modalverb: „Schäden, die behoben werden müssen“."
        },
        "25": {
          "options": [
            "dass",
            "für",
            "um"
          ],
          "answer": 2,
          "note": "Finalsatz mit Infinitiv: „um neue Fensterscheiben einzusetzen“."
        },
        "26": {
          "options": [
            "ermöglichen",
            "verhindern",
            "vergessen"
          ],
          "answer": 0,
          "note": "Damit die Handwerker arbeiten können: „den Zugang zu ermöglichen“."
        },
        "27": {
          "options": [
            "einiger",
            "letzte",
            "letzter"
          ],
          "answer": 2,
          "note": "Feste Zeitangabe im Dativ feminin Singular ohne Artikel: „in letzter Zeit“."
        },
        "28": {
          "options": [
            "weswegen",
            "weil",
            "dass"
          ],
          "answer": 2,
          "note": "Objektsatz nach „darauf achten, dass ...“."
        },
        "29": {
          "options": [
            "Bällen",
            "Bälle",
            "Ballen"
          ],
          "answer": 0,
          "note": "Dativ Plural von „der Ball“ (mit Umlaut und „-n“): „mit Bällen“."
        },
        "30": {
          "options": [
            "freundliche",
            "freundlichen",
            "freundlichem"
          ],
          "answer": 1,
          "note": "Dativ Plural nach „mit“: „mit freundlichen Grüßen“."
        }
      }
    },
    {
      "id": "42",
      "num": "42",
      "page": 408,
      "isVariant": false,
      "title": "Aktionstag für mehr Internetsicherheit (Elternbrief)",
      "category": "Formeller Elternbrief / Schule",
      "text": "Liebe Eltern und Erziehungsberechtigte,\n\n{{21}} mehr Internetsicherheit möchten wir dieses Thema am 9. Februar auch im Unterricht des alljährlich von der Europäischen Union veranstalteten Aktionstages behandeln.\n\nEs sind in erster Linie drei große Bereiche, {{22}} wir uns widmen. Zunächst geht es {{23}}, die Internetkommunikation im Allgemeinen, insbesondere über soziale Medien wie YouTube oder WhatsApp, genauer zu beleuchten. Wir wollen bei Schülerinnen und Schülern das Bewusstsein für die damit verbundenen Gefahren wecken.\n\nAls für die Gesellschaft bedrohlich ist die gezielte Verbreitung falscher Informationen in den Medien, sogenannter Fake News, anzusehen. {{24}} solche zu erkennen, muss man in der Lage sein, Berichte zu analysieren und ihren Wahrheitsgehalt zu überprüfen. Daher liegt es unseren engagierten Pädagoginnen und Pädagogen besonders am {{25}}, bei Schülerinnen und Schülern den kritischen Blick für Nachrichten sowie deren Quellen zu schärfen.\n\nDarüber hinaus werden sie {{26}} anschaulicher Beispiele lernen, wie mittels Bildbearbeitung eine alternative Realität {{27}} werden kann. Auch der Datenschutz, den wir als dritten Schwerpunkt besprechen werden, ist ein Thema von {{28}} Bedeutung. Denn im Zuge der Verwendung sozialer Netzwerke können Jugendliche allzu leicht in problematische Situationen geraten, weil sie oft zu sorglos mit sensiblen Daten von sich oder anderen umgehen. Auf solche Risiken möchten wir aufmerksam machen und erläutern, wie sich Derartiges vermeiden {{29}}. Den Schülerinnen und Schülern ist an diesem Tag die Nutzung ihrer Handys {{30}} des Unterrichts ausdrücklich gestattet.\n\nMit freundlichen Grüßen\nMag. Katharina Schnell",
      "questions": {
        "21": {
          "options": [
            "Anlässlich",
            "Mithilfe",
            "Zwecks"
          ],
          "answer": 2,
          "note": "„Zwecks mehr Internetsicherheit“ (= zum Zweck von mehr Internetsicherheit; Hinweis: lautet der Originalsatz „Anlässlich des Aktionstages für mehr Internetsicherheit“, steht „Anlässlich“)."
        },
        "22": {
          "options": [
            "deren",
            "denen",
            "dessen"
          ],
          "answer": 1,
          "note": "sich widmen (+ Dativ) -> Relativpronomen Dativ Plural „denen“."
        },
        "23": {
          "options": [
            "darum",
            "davon",
            "darüber"
          ],
          "answer": 0,
          "note": "es geht um -> Pronominaladverb „es geht darum, ... zu beleuchten“."
        },
        "24": {
          "options": [
            "Damit",
            "Dass",
            "Um"
          ],
          "answer": 2,
          "note": "Finalsatz mit Infinitiv: „Um solche zu erkennen, muss man ...“."
        },
        "25": {
          "options": [
            "Herz",
            "Herze",
            "Herzen"
          ],
          "answer": 2,
          "note": "Schwache Deklination in der festen Wendung: „jemandem am Herzen liegen“."
        },
        "26": {
          "options": [
            "anhand",
            "durch",
            "mit"
          ],
          "answer": 0,
          "note": "Präposition mit Genitiv Plural („anschaulicher Beispiele“): „anhand anschaulicher Beispiele“."
        },
        "27": {
          "options": [
            "schaffen",
            "geschaffen",
            "geschafft"
          ],
          "answer": 1,
          "note": "Starke Konjugation von „schaffen“ (= erschaffen/kreieren): Partizip II „geschaffen“."
        },
        "28": {
          "options": [
            "größe",
            "größen",
            "größter"
          ],
          "answer": 2,
          "note": "Starke Adjektivdeklination im Dativ feminin Singular ohne Artikel nach „von“: „von größter Bedeutung“."
        },
        "29": {
          "options": [
            "lassen",
            "lasst",
            "lässt"
          ],
          "answer": 2,
          "note": "Passiversatzform im Singular („Derartiges“): „wie sich Derartiges vermeiden lässt“."
        },
        "30": {
          "options": [
            "nämlich",
            "während",
            "trotzdem"
          ],
          "answer": 1,
          "note": "Temporale Präposition mit Genitiv: „während des Unterrichts“."
        }
      }
    },
    {
      "id": "43",
      "num": "43",
      "page": 409,
      "isVariant": false,
      "title": "Umzug von Berlin nach Bamberg (Lieber Julian)",
      "category": "Persönliche E-Mail / Umzug",
      "text": "Lieber Julian,\n\nwie geht es dir? Ich hoffe, du hattest eine schöne Reise und {{21}} dich gut erholen. Ich {{22}} ja auch gerne mal wieder ans Meer fahren, aber im Moment habe ich leider keine Zeit {{23}} Urlaub. Wie du dir bestimmt vorstellen kannst, war ich in den letzten Wochen vor allem mit meinem Umzug beschäftigt.\n\nDu weißt ja, dass ich zuerst ziemlich skeptisch war. Nach so {{24}} Jahren in Berlin konnte ich mir gar nicht mehr vorstellen, mich in einer kleinen Stadt wie Bamberg niederzulassen. Bamberg hat nur rund 77.000 Einwohner, aber langweilig ist es hier trotzdem nicht, wie ich inzwischen festgestellt habe. Mittlerweile fühle ich mich hier sogar richtig wohl. Die Stadt hat wirklich viel zu bieten. Es gibt jahrhundertealte Sehenswürdigkeiten in Hülle und Fülle, und in der Altstadt {{25}} mir besonders die schönen Fachwerkhäuser, die überwiegend aus dem Mittelalter stammen. Ich gehe oft durch die Fußgängerzone, {{26}} dort gibt es viele kleine Läden, Cafés und Restaurants mit typisch fränkischen Spezialitäten.\n\nIch glaube, dir würde es hier auch gefallen. {{27}} du willst, zeige ich dir gerne mal die Stadt. Hättest du vielleicht Lust, mich im nächsten Monat zu besuchen? {{28}} ist bei mir auch der Umzugsstress vorbei. Im Moment steht noch eine große Anzahl nicht {{29}} Kisten in meinem Wohnzimmer, die ausgepackt werden müssen. Mit meiner neuen Wohnung habe ich übrigens auch Glück gehabt, {{30}} sie geräumig und zentral gelegen ist. Wir können ja mal telefonieren, dann erzähle ich dir mehr.\n\nLiebe Grüße\nAnna",
      "questions": {
        "21": {
          "options": [
            "konntest",
            "wolltest",
            "solltest"
          ],
          "answer": 0,
          "note": "Wunsch für die vergangene Reise: „und konntest dich gut erholen“."
        },
        "22": {
          "options": [
            "könnte",
            "würde",
            "möchte"
          ],
          "answer": 1,
          "note": "Irrealer Wunsch mit „gerne“: „Ich würde ja auch gerne mal wieder ans Meer fahren“."
        },
        "23": {
          "options": [
            "für",
            "in",
            "auf"
          ],
          "answer": 0,
          "note": "Feste Präposition: „keine Zeit für Urlaub haben“."
        },
        "24": {
          "options": [
            "vielen",
            "einigen",
            "etlichen"
          ],
          "answer": 0,
          "note": "Nach „so“ steht „vielen“: „Nach so vielen Jahren in Berlin“."
        },
        "25": {
          "options": [
            "gefallen",
            "bewundere",
            "auffallen"
          ],
          "answer": 0,
          "note": "Mit Dativ („mir“) und Subjekt im Plural („die schönen Fachwerkhäuser“) im Hauptsatz: „gefallen mir“."
        },
        "26": {
          "options": [
            "denn",
            "weil",
            "darum"
          ],
          "answer": 0,
          "note": "Kausale Hauptsatzkonjunktion (Verb an Position 2: „dort gibt es“): „denn“."
        },
        "27": {
          "options": [
            "Ob",
            "Falls",
            "Wenn"
          ],
          "answer": 2,
          "note": "Konditionalsatz: „Wenn du willst, zeige ich dir gerne mal die Stadt“ (im PDF-Schlüssel ist C: Wenn markiert)."
        },
        "28": {
          "options": [
            "Sobald",
            "Dann",
            "Vielleicht"
          ],
          "answer": 1,
          "note": "Bezug auf „im nächsten Monat“: „Dann (= zu diesem Zeitpunkt) ist bei mir auch der Umzugsstress vorbei.“"
        },
        "29": {
          "options": [
            "geöffnet",
            "ausgeräumt",
            "ausgepackter"
          ],
          "answer": 2,
          "note": "Genitiv Plural nach „eine große Anzahl“: „nicht ausgepackter Kisten“."
        },
        "30": {
          "options": [
            "sodass",
            "da",
            "weil"
          ],
          "answer": 1,
          "note": "Kausale Konjunktion (im PDF-Schlüssel ist B: „da“ markiert): „da sie geräumig und zentral gelegen ist“."
        }
      }
    }
  ],
  "2": [
    {
      "id": "1",
      "num": "1",
      "page": 411,
      "isVariant": false,
      "title": "Theater für Kinder und Jugendliche",
      "category": "Kultur & Jugendförderung",
      "text": "Theater fördert nicht nur die Kreativität, {{31}} auch die Körpererfahrung von Kindern. Der Verein „Jugendhilfe Düsseldorf e. V.“ arbeitet {{32}} vielen Jahren in der Jugendförderung, und deshalb unterstützt er auch ein neues Theaterprojekt für Kinder. Üben und spielen werden die Teilnehmer im Jugendzentrum. Das Jugendzentrum ist eine Einrichtung des städtischen Jugendamtes und kümmert sich um Kinder, Jugendliche und junge Volljährige, die {{33}} familiärer und anderer Probleme Hilfe benötigen. Bis zu zwanzig Mädchen und Jungen werden {{34}} dem kommenden Jahr die Welt des Theaters kennenlernen. {{35}} Ende des Projekts werden die Nachwuchsschauspieler bei einem Theaterfestival auftreten, was sicher ein Höhepunkt für alle Teilnehmer sein wird.\n\nGeleitet wird die Gruppe vom Schauspieler Wolfgang Neuhausen. Er arbeitet mit dem Jugendzentrum zusammen und wird von zwei Theaterpädagogen unterstützt. Allen Mitarbeitern ist {{36}} wichtig, dass die Kinder auf der Bühne Anerkennung für ihre Leistung bekommen. Ohne die finanzielle Unterstützung wäre das Vorhaben unmöglich, {{37}} bei der Stadt keine Gelder vorhanden waren.\n\nDieses Theaterprojekt ist nicht das erste, das gefördert wird. Im vergangenen Jahr erhielt das Theaterprojekt „Schiller – das wilde, freie Leben“ finanzielle Unterstützung. Allerdings ist nicht nur Geld wichtig: Der Verein kümmert sich auch {{38}}, die Projekte bekannt zu machen. In verschiedenen Theaterhäusern der Stadt werden Plakate aufgehängt, mit denen der Verein für das Jugendtheater wirbt. Man hofft, {{39}} diese Weise noch mehr Unterstützer zu finden. Auch unsere Leser können die Jugendlichen unterstützen: Aktuell sammelt das Jugendzentrum Spenden, {{40}} weitere Projekte finanzieren zu können. Außerdem werden für die Theaterproben und die Aufführungen noch ehrenamtliche Helfer gesucht.",
      "words": {
        "a": "AB",
        "b": "ABER",
        "c": "AM",
        "d": "AUF",
        "e": "DA",
        "f": "DARUM",
        "g": "DAZU",
        "h": "ES",
        "i": "OHNE",
        "j": "SEIT",
        "k": "SONDERN",
        "l": "TROTZ",
        "m": "UM",
        "n": "VOR",
        "o": "WEGEN"
      },
      "answers": {
        "31": {
          "key": "k",
          "note": "Zweiteilige Konjunktion: „nicht nur ..., sondern auch ...“."
        },
        "32": {
          "key": "j",
          "note": "Zeitdauer von der Vergangenheit bis in die Gegenwart: „seit vielen Jahren“."
        },
        "33": {
          "key": "o",
          "note": "Kausale Präposition mit Genitiv: „wegen familiärer und anderer Probleme“."
        },
        "34": {
          "key": "a",
          "note": "Zeitlicher Beginn in der Zukunft (+ Dativ): „ab dem kommenden Jahr“."
        },
        "35": {
          "key": "c",
          "note": "Feste Zeitangabe: „Am Ende des Projekts“."
        },
        "36": {
          "key": "h",
          "note": "Formales Korrelat zum dass-Satz: „Allen Mitarbeitern ist es wichtig, dass ...“."
        },
        "37": {
          "key": "e",
          "note": "Kausale Nebensatzkonjunktion: „..., da (= weil) bei der Stadt keine Gelder vorhanden waren“."
        },
        "38": {
          "key": "f",
          "note": "sich kümmern um -> Pronominaladverb „kümmert sich auch darum, ... zu machen“."
        },
        "39": {
          "key": "d",
          "note": "Feste Wendung: „auf diese Weise“."
        },
        "40": {
          "key": "m",
          "note": "Finalsatz mit Infinitiv: „um weitere Projekte finanzieren zu können“."
        }
      }
    },
    {
      "id": "2",
      "num": "2",
      "page": 412,
      "isVariant": false,
      "title": "Das Schicksal des Braunbären",
      "category": "Natur, Klima & Tierwelt",
      "text": "Klimatische Veränderungen seit der letzten Kaltzeit könnten für den stetigen Rückgang der Braunbärenzahl in Europa verantwortlich sein. Wie eine aktuelle Studie nahelegt, haben vor allem steigende Wintertemperaturen {{31}} der vergangenen 12.000 Jahre die Fortpflanzungsrate der Tiere verringert, was entscheidend zu deren Verschwinden beigetragen hat. Zudem wurden durch die Klimaveränderung größere Flächen für den Ackerbau nutzbar. {{32}} wurde der Lebensraum der Tiere verkleinert. Es ist längst unumstritten, {{33}} das Verschwinden der Braunbären mit der Landnutzung durch den Menschen zusammenhängt.\n\nEin internationales Expertenteam untersuchte nun die Rolle des Klimas beim Rückgang der Bärenzahl. In den letzten Jahren ist die Wintertemperatur in weiten Teilen Europas {{34}} zwei bis vier Grad angestiegen. In der Folge bekamen die Braunbären weniger {{35}}, und ihre Zahl schrumpfte. Der Grund {{36}} ist, dass Braunbären bei steigenden Wintertemperaturen mehr Energie für ihre Winterruhe verbrauchen. Braunbärenweibchen benötigen ihre Energiereserven auch für die Fortpflanzung, {{37}} sie bringen im Winter ihre Jungen zur Welt. Wird mehr Energie für die Winterruhe verbraucht, bleibt nicht so viel für die Fortpflanzung übrig, und es gibt weniger Nachwuchs.\n\nSteigende Wintertemperaturen könnten auch indirekt für das Schicksal des Braunbären verantwortlich gewesen sein. Wärmere Winter begünstigten nämlich auch die menschlichen {{38}} in die Naturlandschaften und damit in den Lebensraum der Braunbären. Am Ende der letzten Eiszeit war der Braunbär {{39}} überall in Europa heimisch. Ein großes Aussterben gab es in Südwesteuropa vor 7.000 bis 5.000 Jahren. Richtig bergab {{40}} es mit dem Braunbären aber vor etwa 2.000 Jahren, als sich sein Lebensraum weiter verringerte.",
      "words": {
        "a": "BEGRIFFE",
        "b": "DADURCH",
        "c": "DAFÜR",
        "d": "DASS",
        "e": "DENN",
        "f": "EINGRIFFE",
        "g": "GING",
        "h": "KAM",
        "i": "NACHKOMMEN",
        "j": "NOCH",
        "k": "SODASS",
        "l": "SOWIE",
        "m": "UM",
        "n": "VORKOMMEN",
        "o": "WÄHREND"
      },
      "answers": {
        "31": {
          "key": "o",
          "note": "Temporale Präposition mit Genitiv: „während der vergangenen 12.000 Jahre“."
        },
        "32": {
          "key": "b",
          "note": "Kausal-/Instrumentaladverb: „Dadurch (= Auf diese Weise) wurde der Lebensraum verkleinert.“"
        },
        "33": {
          "key": "d",
          "note": "Subjektsatz nach „Es ist unumstritten, dass ...“."
        },
        "34": {
          "key": "m",
          "note": "Differenzangabe bei Veränderungen: „um zwei bis vier Grad angestiegen“."
        },
        "35": {
          "key": "i",
          "note": "„Nachkommen“ (= Jungen / Nachwuchs)."
        },
        "36": {
          "key": "c",
          "note": "der Grund für etwas -> „Der Grund dafür ist, dass ...“."
        },
        "37": {
          "key": "e",
          "note": "Kausale Hauptsatzkonjunktion (Verb an Position 2: „sie bringen“): „denn“."
        },
        "38": {
          "key": "f",
          "note": "Nomen mit Präposition „in“ (+ Akk.): „menschliche Eingriffe in die Naturlandschaften“."
        },
        "39": {
          "key": "j",
          "note": "Zeitpartikel: „war der Braunbär noch überall in Europa heimisch“."
        },
        "40": {
          "key": "g",
          "note": "Feste Redewendung: „es geht bergab mit jemandem/etwas“ -> Präteritum „ging“."
        }
      }
    },
    {
      "id": "3",
      "num": "3",
      "page": 413,
      "isVariant": false,
      "title": "Ausbildung mit über 30",
      "category": "Beruf & Weiterbildung",
      "text": "Die gelernte Krankenschwester Jaqueline Delgado drückt mit 38 Jahren noch einmal die Schulbank. {{31}} sie hat sich für einen beruflichen Neustart entschieden. Da ihr früherer Beruf ihr keinen Spaß mehr machte, begann sie eine Berufsausbildung bei der Polizei. Ihr Ziel: Sie {{32}} in den Streifendienst gehen.\n\nMit über 30 noch einmal einen ganz neuen Job zu erlernen – lange Zeit war das kaum möglich. Arbeitgeber suchten nur junge Berufseinsteiger. {{33}} es heute in vielen Branchen aber an Nachwuchs fehlt, geben sie öfter auch Älteren eine {{34}}. Thomas Neuendorfer, der stellvertretende Sprecher der Polizei Berlin, erklärt, {{35}} sein Arbeitgeber gerne Ältere ausbildet: „Sie haben in ihrem Berufsleben Erfahrungen gesammelt, die der Polizei und auch den Bürgern der Stadt zugutekommen.“ Sie seien häufig emotional reifer, außerdem bereit, Verantwortung zu {{36}}, und motiviert, die Ausbildung erfolgreich abzuschließen. Zudem {{37}} sie die Jüngeren unterstützen und ihnen als Vorbild dienen. Davon profitierten dann auch die Arbeitgeber.\n\nGegen die Einstellung von Älteren spreche nur, dass sie dem Unternehmen kürzer zur {{38}} stehen. {{39}} haben ältere Azubis in vielen Bereichen Möglichkeiten: in kaufmännischen oder in gewerblich-technischen Berufen, im Gesundheitswesen oder vor allem in der Gastronomie. Wenn das Azubi-Gehalt nicht für den Lebensunterhalt reicht, hilft die Arbeitsagentur. Der Betrag wird dabei nicht nach dem Alter festgelegt, {{40}} es wird der individuelle, konkrete Bedarf ermittelt. Im August schließt Delgado ihre Ausbildung ab. In dem künftigen Polizei-Job wird sie ihr medizinisches Wissen, ihre Menschenkenntnis sowie ihre spanischen und englischen Sprachkenntnisse wohl gut gebrauchen können.",
      "words": {
        "a": "AUSWAHL",
        "b": "CHANCE",
        "c": "DA",
        "d": "DAGEGEN",
        "e": "DENN",
        "f": "DURFTEN",
        "g": "KÖNNTEN",
        "h": "MÖCHTE",
        "i": "SOLLTE",
        "j": "SONDERN",
        "k": "TROTZDEM",
        "l": "ÜBERNEHMEN",
        "m": "VERFÜGUNG",
        "n": "WARUM",
        "o": "ZIEHEN"
      },
      "answers": {
        "31": {
          "key": "e",
          "note": "Hauptsatzkonjunktion auf Position 0 („Denn sie hat sich ... entschieden“)."
        },
        "32": {
          "key": "h",
          "note": "Ausdruck des Ziels/Wunsches: „Sie möchte in den Streifendienst gehen.“"
        },
        "33": {
          "key": "c",
          "note": "Kausale Nebensatzkonjunktion: „Da es heute in vielen Branchen an Nachwuchs fehlt, ...“."
        },
        "34": {
          "key": "b",
          "note": "Feste Wendung: „jemandem eine Chance geben“."
        },
        "35": {
          "key": "n",
          "note": "Indirekter Fragesatz nach „erklärt“: „erklärt, warum sein Arbeitgeber gerne Ältere ausbildet“."
        },
        "36": {
          "key": "l",
          "note": "Kollokation: „Verantwortung übernehmen“."
        },
        "37": {
          "key": "g",
          "note": "Indirekte Rede / Möglichkeit im Plural: „Zudem könnten sie die Jüngeren unterstützen“."
        },
        "38": {
          "key": "m",
          "note": "Funktionsverbgefüge: „zur Verfügung stehen“."
        },
        "39": {
          "key": "k",
          "note": "Konzessives Adverb nach dem Gegenargument: „Trotzdem haben ältere Azubis ... Möglichkeiten.“"
        },
        "40": {
          "key": "j",
          "note": "Gegensatz nach Verneinung: „nicht nach dem Alter festgelegt, sondern es wird ... ermittelt“."
        }
      }
    },
    {
      "id": "4",
      "num": "4",
      "page": 414,
      "isVariant": false,
      "title": "Die wichtigsten Regeln auf der Skipiste",
      "category": "Sport & Recht",
      "text": "Wer beim Skifahren fahrlässig einen anderen Sportler verletzt oder gefährdet, muss auch mit rechtlichen Folgen {{31}}. Das Strafgesetzbuch ist sowohl auf der Straße als auch auf der Piste {{32}}. Laut Gesetz gibt es Freiheitsstrafen bis zu 3 Monaten oder eine entsprechende Geldstrafe. Bei schwerer Körperverletzung sieht das Gesetz Freiheitsstrafen bis zu 6 Monaten {{33}}.\n\nDer Deutsche Skiverband hat eine Pistenordnung erarbeitet, die bei gerichtlichen Entscheidungen angewandt wird. Jeder Wintersportler {{34}} diese Regeln kennen: Jeder Skifahrer muss sich stets {{35}} verhalten, dass er keinen anderen gefährdet oder schädigt. Er muss die Zeichen und Hinweisschilder an der Piste kennen und beachten. Er muss die eigene Geschwindigkeit und Fahrweise seinem Können und dem Gelände sowie den herrschenden Wetterverhältnissen {{36}}.\n\nEin von hinten kommender Skifahrer muss seine Fahrspur so wählen, dass er vor ihm fahrende Skifahrer nicht gefährdet. Überholen darf man rechts oder links, {{37}} immer in einem Abstand, der dem überholten Skifahrer genug Raum für seine Bewegungen lässt. Aufsteigende Skifahrer dürfen nur den {{38}} einer Abfahrtsstrecke benützen. Dasselbe gilt für einen Skifahrer, der zu Fuß absteigt. Bei schlechten Sichtverhältnissen ist die Benutzung des Pistenrands verboten und der Skifahrer muss diesen verlassen.\n\nNiemand sollte sich an unübersichtlichen oder engen Stellen aufhalten. Gestürzte Skifahrer müssen eine solche {{39}} so schnell wie möglich freimachen. Bei Unfällen ist jeder zur Hilfeleistung verpflichtet. Jeder Zeuge oder Verantwortliche muss bei einem Unfall außerdem seine Personalien {{40}}. Durch Beachtung dieser Regeln ist die Sicherheit auf den Pisten deutlich gestiegen.",
      "words": {
        "a": "ZWAR",
        "b": "VOR (VORSEHEN)",
        "c": "STELLE",
        "d": "SOLLTE",
        "e": "SO",
        "f": "RECHNEN",
        "g": "RAND",
        "h": "KANN",
        "i": "GÜLTIG",
        "j": "GELTEN",
        "k": "EINORDNEN",
        "l": "DARF",
        "m": "ANPASSEN",
        "n": "ANGEBEN",
        "o": "ALLERDINGS"
      },
      "answers": {
        "31": {
          "key": "f",
          "note": "Feste Verbindung: „mit Folgen rechnen müssen“."
        },
        "32": {
          "key": "i",
          "note": "Prädikatives Adjektiv nach „ist“: „Das Strafgesetzbuch ist ... gültig.“"
        },
        "33": {
          "key": "b",
          "note": "Trennbares Verb „vorsehen“: „sieht das Gesetz Freiheitsstrafen ... vor“."
        },
        "34": {
          "key": "d",
          "note": "Empfehlung/Pflicht im Singular: „Jeder Wintersportler sollte diese Regeln kennen.“"
        },
        "35": {
          "key": "e",
          "note": "Konsekutivsatz: „muss sich stets so verhalten, dass ...“."
        },
        "36": {
          "key": "m",
          "note": "etwas (+ Akk.) einer Sache (+ Dat.) anpassen: „Geschwindigkeit ... seinem Können anpassen“."
        },
        "37": {
          "key": "o",
          "note": "Einschränkung: „allerdings immer in einem Abstand, der ...“."
        },
        "38": {
          "key": "g",
          "note": "Bezug auf den Folgesatz („Pistenrand“): „nur den Rand einer Abfahrtsstrecke benützen“."
        },
        "39": {
          "key": "c",
          "note": "Bezug auf den Vorsatz („engen Stellen“): „eine solche Stelle freimachen“."
        },
        "40": {
          "key": "n",
          "note": "Kollokation: „seine Personalien angeben“."
        }
      }
    },
    {
      "id": "5",
      "num": "5",
      "page": 415,
      "isVariant": false,
      "title": "Jugend diskutiert – mach mit!",
      "category": "Schule & Wettbewerb",
      "text": "Den Wettbewerb „Jugend diskutiert“ gibt es bereits {{31}} Herbst 2002. Für das kommende Jahr werden nun wieder Schülerinnen und Schüler gesucht, die an dem Wettbewerb teilnehmen möchten. {{32}} immer bereiten sich die Teilnehmer dann im Unterricht auf „Jugend diskutiert“ vor.\n\nDu fragst dich, {{33}} du teilnehmen solltest? Ganz einfach: „Jugend diskutiert“ bringt dich weiter! Sich einmischen, mitreden, überzeugen – bei der Vorbereitung im Unterricht trainierst du viele Fähigkeiten, die dir in der Schule und im Alltag helfen. Im Austausch mit den anderen entwickelst du deine Persönlichkeit weiter und profitierst langfristig.\n\n{{34}} bietet dir „Jugend diskutiert“ die Chance, im Wettstreit mit anderen weiterzukommen. Zuerst werden die Besten einer Schule ermittelt, die dann {{35}} Regionalwettbewerben teilnehmen. Die Sieger der Regionalwettbewerbe treten im Bundesfinale an. {{36}} Preise kann man professionelle Trainings gewinnen.\n\n{{37}} „Jugend diskutiert“ kannst du viel lernen. Du hast bessere Chancen im Unterricht und bei Referaten, denn du trainierst, frei zu sprechen und Dinge anschaulich und verständlich zu beschreiben. Du gewinnst mehr Selbstbewusstsein, {{38}} du lernst, wie man das Wort ergreift und auf sich aufmerksam macht. Du kannst überzeugen, da du eigene Argumente finden und die Argumente anderer genau prüfen kannst. Die Sichtweisen der anderen zeigen dir darüber hinaus, {{39}} du vielleicht selbst noch nicht gesehen hast. Du überzeugst bei Auftritten, Prüfungen und Bewerbungen, da du sicher auftrittst. {{40}} das alles im Unterricht gelernt hat, kann gemeinsam mit anderen viel bewegen!\n\nSchließlich ist der Wettbewerb „Jugend diskutiert“ auch eine Chance, Jugendliche aus ganz Deutschland kennenzulernen und neue Freundschaften zu knüpfen. Weitere Informationen zu Anmeldung und Teilnahme gibt es im Internet.",
      "words": {
        "a": "ALS",
        "b": "AN",
        "c": "AUSSERDEM",
        "d": "BEI",
        "e": "DARUNTER",
        "f": "DIE",
        "g": "NACHDEM",
        "h": "OBWOHL",
        "i": "SEIT",
        "j": "VOR",
        "k": "WARUM",
        "l": "WAS",
        "m": "WEIL",
        "n": "WER",
        "o": "WIE"
      },
      "answers": {
        "31": {
          "key": "i",
          "note": "Beginn in der Vergangenheit bis heute: „bereits seit Herbst 2002“."
        },
        "32": {
          "key": "o",
          "note": "Feste Wendung: „Wie immer“ (= Wie gewohnt)."
        },
        "33": {
          "key": "k",
          "note": "Indirekter Fragesatz nach dem Grund: „Du fragst dich, warum du teilnehmen solltest?“"
        },
        "34": {
          "key": "c",
          "note": "Weiteres Argument: „Außerdem bietet dir ‚Jugend diskutiert‘ die Chance ...“."
        },
        "35": {
          "key": "b",
          "note": "Feste Präposition: „teilnehmen an (+ Dativ)“."
        },
        "36": {
          "key": "a",
          "note": "Funktion: „Als Preise kann man professionelle Trainings gewinnen.“"
        },
        "37": {
          "key": "d",
          "note": "„Bei ‚Jugend diskutiert‘ kannst du viel lernen.“"
        },
        "38": {
          "key": "m",
          "note": "Kausalsatz: „..., weil du lernst, wie man das Wort ergreift“."
        },
        "39": {
          "key": "l",
          "note": "Relativierter Objektsatz: „zeigen dir darüber hinaus, was du vielleicht selbst noch nicht gesehen hast“."
        },
        "40": {
          "key": "n",
          "note": "Verallgemeinernder Relativsatz (Subjekt): „Wer das alles gelernt hat, kann viel bewegen!“"
        }
      }
    },
    {
      "id": "6",
      "num": "6",
      "page": 416,
      "isVariant": false,
      "title": "Manipulierte Bilder",
      "category": "Medien & Wissenschaft",
      "text": "Im Internet, in sozialen Netzwerken und der Werbung werden wir mit einer {{31}} von Fotos konfrontiert. Klar ist: Viele von ihnen sind keine wirklichen Originale. Bildbearbeitungsprogramme machen es sogar für Laien {{32}} einfach, Fotos zu verändern. Meist sind die Manipulationen harmlos, {{33}} die Möglichkeiten der Bildbearbeitung lassen sich natürlich auch für Betrügereien oder Meinungsmache missbrauchen.\n\nIn diesem Zusammenhang {{34}} sich die Frage, inwieweit Betrachtern solche Manipulationen auffallen. Können sie erkennen, dass an einem Bild etwas merkwürdig ist, oder sogar die manipulierte Stelle finden? {{35}} Fragen sind nun Forscher der University of Warwick (UK) nachgegangen. Sie entwickelten dazu ein Online-Testsystem, bei dem die Teilnehmer den manipulierten Bereich auf Fotos erkennen sollten.\n\nDie Auswertungen ergaben: Die {{36}} Teilnehmer waren nur eher zufällig in der Lage, ein manipuliertes Bild zu identifizieren. Oft hatten sie das vage Gefühl, dass mit einem der Bilder etwas nicht stimmt. Nur in 45 Prozent der Fälle konnten sie tatsächlich {{37}} bestimmen, wo das Bild verändert worden war. Selbst ein falscher Schattenwurf oder andere {{38}} Abweichungen wurden nicht besser erkannt als nachvollziehbare Manipulationen wie beispielsweise künstliche Farbveränderungen.\n\nBilder haben einen starken Einfluss auf unsere Erinnerungen, so die Forscher. Können Menschen also nicht zwischen echten und gefälschten Details auf Fotos {{39}}, so können manipulierte Bilder entscheidend beeinflussen, woran wir uns zu erinnern glauben. Die Ergebnisse dokumentieren {{40}}: Wir können recht leicht auf Fake-Fotos und damit auch auf ihre manipulierten Botschaften reinfallen. Aufbauend auf ihren Ergebnissen wollen die Forscher nun konkrete Ratschläge erarbeiten, die dem Betrachter helfen sollen, Fotomanipulationen besser zu erkennen.",
      "words": {
        "a": "ABER",
        "b": "ABGRENZEN",
        "c": "ALS",
        "d": "DIESEN",
        "e": "FLUT",
        "f": "KORREKT",
        "g": "MEISTEN",
        "h": "RECHT",
        "i": "REISEND",
        "j": "SOMIT",
        "k": "STELLT",
        "l": "UNLOGISCHE",
        "m": "UNTERSCHEIDEN",
        "n": "VERSCHIEDEN",
        "o": "ZWAR"
      },
      "answers": {
        "31": {
          "key": "e",
          "note": "Metapher für eine riesige Menge: „mit einer Flut von Fotos konfrontiert“."
        },
        "32": {
          "key": "h",
          "note": "Gradpartikel vor Adjektiv: „recht (= ziemlich) einfach“."
        },
        "33": {
          "key": "a",
          "note": "Gegensatz: „Meist sind die Manipulationen harmlos, aber die Möglichkeiten lassen sich ... missbrauchen.“"
        },
        "34": {
          "key": "k",
          "note": "Feste Wendung: „es stellt sich die Frage“."
        },
        "35": {
          "key": "d",
          "note": "einer Frage (Dativ Plural) nachgehen -> „Diesen Fragen sind nun Forscher nachgegangen.“"
        },
        "36": {
          "key": "g",
          "note": "„Die meisten Teilnehmer“."
        },
        "37": {
          "key": "f",
          "note": "Adverb zu „bestimmen“: „konnten sie tatsächlich korrekt bestimmen, wo ...“."
        },
        "38": {
          "key": "l",
          "note": "Im Gegensatz zu „nachvollziehbare Manipulationen“: „andere unlogische Abweichungen“."
        },
        "39": {
          "key": "m",
          "note": "Infinitiv zum Modalverb „Können“ am Satzanfang: „zwischen X und Y unterscheiden“."
        },
        "40": {
          "key": "j",
          "note": "Folgerndes Adverb: „Die Ergebnisse dokumentieren somit (= folglich): ...“."
        }
      }
    },
    {
      "id": "7",
      "num": "7",
      "page": 417,
      "isVariant": false,
      "title": "Der klügste Freund des Menschen",
      "category": "Wissenschaft & Tiere",
      "text": "Seit jeher gilt der Hund {{31}} als treuer Begleiter des Menschen, besondere Leistungen auf dem Gebiet der Intelligenz wurden ihm jedoch sehr viel seltener zugesprochen. Jetzt beweisen aber Untersuchungen, die etwa zeitgleich an der Eötvös-Loránd-Universität in Budapest, an der Harvard-Universität und am Max-Planck-Institut für evolutionäre Anthropologie in Leipzig durchgeführt {{32}}, dass die beliebten Vierbeiner offenbar mehr verstehen und leisten können, als man bislang glaubte.\n\nIn speziell ausgearbeiteten Lerntests mit Hunden, Schimpansen und Gorillas wurde die Kommunikationsfähigkeit der Tiere getestet. In allen Tests schnitten die Hunde besser ab als die Affen. Hunde lesen kommunikative Informationen besonders an den Augen {{33}}, aber sie reagieren auch {{34}} die Stimme und die Körpersprache eines Menschen. Ganz besonders der Blickkontakt {{35}} für Hunde ein wichtiges Instrument, um Informationen über den „Gesprächspartner“ zu erhalten. Diese Fähigkeit habe sich im Verlaufe der Domestizierung der Hunde durch den Menschen immer weiter ausgebildet und sei jetzt in den Genen der Hunde fest verankert, so die Aussage der Forscher.\n\nHunden wird jetzt auch bescheinigt, dass sie ein Verständnis für Objekte entwickelt haben. Die Forscher versteckten vor den Augen ihrer Probanden Spielzeuge entweder hinter einer Wand oder in einem Behälter. {{36}} der Behälter nach dem Öffnen leer, suchten die Hunde auch hinter der Wand nach dem Spielzeug. Hundetrainer, die in anerkannten Hundeschulen arbeiten, wissen schon lange Erstaunliches über die Fähigkeiten ihrer Schüler zu berichten. Ein Beispiel für die erstaunlichen Leistungen, die ein Hund zustande zu bringen vermag, ist der Blindenhund. Er kann nach den entsprechenden Trainings blinden Menschen sicher den Weg zeigen, er achtet auf den Straßenverkehr, er leitet sie {{37}} Hindernisse herum.\n\nNach neuesten Erkenntnissen wurden die ersten Hunde vor etwa 15.000 Jahren in Ostasien domestiziert. Nach umfangreichen Erbgutuntersuchungen geht man {{38}} aus, dass alle heute bekannten Hunderassen von etwa fünf weiblichen Wölfen abstammen. Als Ursprungsland der heutigen Hunderassen nimmt man China an. Hundebesitzer von heute können also stolz {{39}} sein, nicht nur einen anhänglichen, {{40}} auch einen intelligenten Begleiter bei sich zu haben.",
      "words": {
        "a": "AB",
        "b": "ABER",
        "c": "AN",
        "d": "AUF",
        "e": "DARAUF",
        "f": "DARÜBER",
        "g": "DAVON",
        "h": "SEI",
        "i": "SEIEN",
        "j": "SONDERN",
        "k": "ÜBER",
        "l": "UM",
        "m": "WAR",
        "n": "WURDEN",
        "o": "ZWAR"
      },
      "answers": {
        "31": {
          "key": "o",
          "note": "Konzessive Struktur mit „jedoch“ im zweiten Teilsatz: „gilt zwar als ..., ... jedoch ...“."
        },
        "32": {
          "key": "n",
          "note": "Passiv Präteritum im Relativsatz („Untersuchungen, die ... durchgeführt wurden“)."
        },
        "33": {
          "key": "a",
          "note": "Trennbares Verb „ablesen“: „Informationen an den Augen ablesen“."
        },
        "34": {
          "key": "d",
          "note": "Feste Präposition: „reagieren auf (+ Akkusativ)“."
        },
        "35": {
          "key": "h",
          "note": "Indirekte Rede im Konjunktiv I Singular („der Blickkontakt sei ...“)."
        },
        "36": {
          "key": "m",
          "note": "Uneingeleiteter Konditionalsatz im Präteritum: „War der Behälter leer (= Wenn der Behälter leer war), suchten die Hunde ...“."
        },
        "37": {
          "key": "l",
          "note": "Zirkumposition: „um Hindernisse herum leiten“."
        },
        "38": {
          "key": "g",
          "note": "Feste Wendung: „davon ausgehen, dass ...“."
        },
        "39": {
          "key": "e",
          "note": "stolz sein auf -> Pronominaladverb „stolz darauf sein, ... zu haben“."
        },
        "40": {
          "key": "j",
          "note": "„nicht nur ..., sondern auch ...“."
        }
      }
    },
    {
      "id": "7a",
      "num": "7a",
      "page": 418,
      "isVariant": true,
      "title": "Der klügste Freund des Menschen (Variante 7a)",
      "category": "Wissenschaft & Tiere",
      "text": "{{31}} gilt der Hund seit jeher als treuer Begleiter des Menschen, besondere Leistungen auf dem Gebiet der Intelligenz wurden ihm jedoch sehr viel seltener zugesprochen. Jetzt beweisen aber Untersuchungen, die etwa zeitgleich an der Eötvös-Loránd-Universität in Budapest, an der Harvard-Universität und am Max-Planck-Institut für evolutionäre Anthropologie in Leipzig durchgeführt {{32}}, dass die beliebten Vierbeiner offenbar mehr verstehen und leisten können, als man bislang glaubte.\n\nIn speziell ausgearbeiteten Lerntests mit Hunden, Schimpansen und Gorillas wurde die Kommunikationsfähigkeit der Tiere getestet. In allen Tests schnitten die Hunde besser ab als die Affen. Hunde lesen kommunikative Informationen besonders an den Augen {{33}}, aber sie reagieren auch {{34}} die Stimme und die Körpersprache eines Menschen. Ganz besonders der Blickkontakt {{35}} für Hunde ein wichtiges Instrument, um Informationen über den „Gesprächspartner“ zu erhalten. Diese Fähigkeit habe sich im Verlaufe der Domestizierung der Hunde durch den Menschen immer weiter ausgebildet und sei jetzt in den Genen der Hunde fest verankert, so die Aussage der Forscher.\n\nHunden wird jetzt auch bescheinigt, dass sie ein Verständnis für Objekte entwickelt haben. Die Forscher versteckten vor den Augen ihrer Probanden Spielzeuge entweder hinter einer Wand oder in einem Behälter. {{36}} der Behälter nach dem Öffnen leer, suchten die Hunde auch hinter der Wand nach dem Spielzeug. Hundetrainer, die in anerkannten Hundeschulen arbeiten, wissen schon lange Erstaunliches über die Fähigkeiten ihrer Schüler zu berichten. Ein Beispiel für die erstaunlichen Leistungen, die ein Hund zustande zu bringen vermag, ist der Blindenhund. Er kann nach den entsprechenden Trainings blinden Menschen sicher den Weg zeigen, er achtet auf den Straßenverkehr, er leitet sie {{37}} Hindernisse herum.\n\nNach neuesten Erkenntnissen wurden die ersten Hunde vor etwa 15.000 Jahren in Ostasien domestiziert. Nach umfangreichen Erbgutuntersuchungen geht man {{38}} aus, dass alle heute bekannten Hunderassen von etwa fünf weiblichen Wölfen abstammen. Als Ursprungsland der heutigen Hunderassen nimmt man China an. Hundebesitzer von heute können also stolz {{39}} sein, nicht nur einen anhänglichen, {{40}} auch einen intelligenten Begleiter bei sich zu haben.",
      "words": {
        "a": "AB",
        "b": "ABER",
        "c": "AN",
        "d": "AUF",
        "e": "DARAUF",
        "f": "DARÜBER",
        "g": "DAVON",
        "h": "SEI",
        "i": "SEIEN",
        "j": "SONDERN",
        "k": "ÜBER",
        "l": "UM",
        "m": "WAR",
        "n": "WURDEN",
        "o": "ZWAR"
      },
      "answers": {
        "31": {
          "key": "o",
          "note": "„Zwar“ im Vorfeld vor dem Verb „gilt“, gefolgt von „jedoch“ im zweiten Teilsatz."
        },
        "32": {
          "key": "n",
          "note": "Passiv Präteritum: „durchgeführt wurden“."
        },
        "33": {
          "key": "a",
          "note": "„an den Augen ablesen“."
        },
        "34": {
          "key": "d",
          "note": "„reagieren auf (+ Akkusativ)“."
        },
        "35": {
          "key": "h",
          "note": "Konjunktiv I Singular der indirekten Rede: „sei“."
        },
        "36": {
          "key": "m",
          "note": "„War der Behälter nach dem Öffnen leer, ...“."
        },
        "37": {
          "key": "l",
          "note": "„um Hindernisse herum“."
        },
        "38": {
          "key": "g",
          "note": "„geht man davon aus, dass ...“."
        },
        "39": {
          "key": "e",
          "note": "„stolz darauf sein“."
        },
        "40": {
          "key": "j",
          "note": "„nicht nur ..., sondern auch ...“."
        }
      }
    },
    {
      "id": "8",
      "num": "8",
      "page": 419,
      "isVariant": false,
      "title": "Maßgeschneidert nach Bodyscanning",
      "category": "Mode & Technik",
      "text": "Haben Sie sich schon einmal {{31}} geärgert, dass Sie zwar in vielen Geschäften viele schöne Kleidungsstücke sehen konnten, Ihnen aber dann bei der Anprobe keines gepasst hat? Dann geht es Ihnen wie zurzeit der Mehrheit der deutschen Bevölkerung: Die Kleidungsstücke, die in den Modehäusern angeboten werden, gibt es fast {{32}} noch in den falschen Größen.\n\nEine Untersuchung des Textilforschungszentrums Hohenstein brachte nun {{33}} Licht, dass die Modeproduzenten den Grund dafür, dass viele Konfektionsgrößen offenbar {{34}} den Kundinnen noch den Kunden passen, in der körperlichen Entwicklung der Bevölkerung in Deutschland suchen {{35}}. Seit den 1960er Jahren seien die Deutschen im Durchschnitt um bis zu acht Zentimeter sowohl größer als auch dicker geworden. Die Länge der Arme habe zugenommen, besonders aber an den Hüften hätten die Deutschen beträchtlich zugelegt.\n\n{{36}} der Handel natürlich daran interessiert ist, die Kleidungsstücke in den richtigen Größen in ausreichender Zahl zu produzieren, wurde jetzt ein neues Projekt geplant, {{37}} Aufschluss darüber geben soll, welche Größen die Kunden eigentlich brauchen. Die neue Body-Scan-Technologie soll Männer und Frauen neu vermessen. Mehrere Kameras tasten mit Laserlicht die menschlichen Körper ab und erstellen ein dreidimensionales Ebenbild der gescannten Person. Diese dreidimensionalen Bilder {{38}} es ermöglichen, in Zukunft genauere Informationen über die durchschnittliche Körpergröße zu erhalten. Ähnliche Messungen werden auch in Großbritannien, den Niederlanden, den skandinavischen Ländern, Frankreich und den USA vorgenommen. Mehr als zwei Millionen Euro wollen die Modefirmen dafür investieren, das Ergebnis lohnt sich aber für sie auf jeden Fall.\n\nAls Kundinnen und Kunden {{39}} wir uns außerdem darauf freuen, {{40}} sich als Nebenprodukt der Körpervermessung in den verschiedenen Ländern die Modefirmen vielleicht endlich dafür entscheiden, weltweit gleiche Nummern für gleiche Größen einzuführen. Dann ist ein Kleidungsstück mit der Nummer 36 überall gleich groß, ob in Nord- oder Südeuropa, in Amerika oder Asien.",
      "words": {
        "a": "ANS",
        "b": "ALS",
        "c": "DA",
        "d": "DARÜBER",
        "e": "DARUM",
        "f": "DAS",
        "g": "DASS",
        "h": "DÜRFEN",
        "i": "INS",
        "j": "MÜSSEN",
        "k": "NUR",
        "l": "SOLLEN",
        "m": "SONDERN",
        "n": "SOWIE",
        "o": "WEDER"
      },
      "answers": {
        "31": {
          "key": "d",
          "note": "sich ärgern über -> Pronominaladverb „darüber geärgert, dass ...“."
        },
        "32": {
          "key": "k",
          "note": "„fast nur noch in den falschen Größen“."
        },
        "33": {
          "key": "a",
          "note": "Feste Redewendung: „etwas ans (= an das) Licht bringen“."
        },
        "34": {
          "key": "o",
          "note": "Zweiteilige Verneinung mit „noch“: „weder den Kundinnen noch den Kunden“."
        },
        "35": {
          "key": "j",
          "note": "Nebensatz mit „dass“ -> konjugiertes Modalverb am Satzende: „suchen müssen“."
        },
        "36": {
          "key": "c",
          "note": "Kausale Nebensatzkonjunktion: „Da (= Weil) der Handel daran interessiert ist, ...“."
        },
        "37": {
          "key": "f",
          "note": "Relativpronomen Nominativ Neutrum Singular („ein neues Projekt, das Aufschluss geben soll“)."
        },
        "38": {
          "key": "l",
          "note": "Zweck/Plan der Bilder: „Diese dreidimensionalen Bilder sollen es ermöglichen, ...“."
        },
        "39": {
          "key": "h",
          "note": "1. Person Plural („wir“): „dürfen wir uns außerdem darauf freuen“."
        },
        "40": {
          "key": "g",
          "note": "Objektsatz nach „sich darauf freuen, dass ...“."
        }
      }
    },
    {
      "id": "8a",
      "num": "8a",
      "page": 420,
      "isVariant": true,
      "title": "Maßgeschneidert nach Bodyscanning (Variante 8a)",
      "category": "Mode & Technik",
      "text": "Haben Sie sich schon einmal {{31}} aufgeregt, dass Sie zwar in vielen Geschäften viele schöne Kleidungsstücke sehen konnten, Ihnen aber dann bei der Anprobe keines gepasst hat? Dann geht es Ihnen wie zurzeit der Mehrheit der deutschen Bevölkerung: Die Kleidungsstücke, die in den Modehäusern angeboten werden, gibt es fast {{32}} noch in den falschen Größen.\n\nEine Untersuchung des Textilforschungszentrums Hohenstein {{33}} nun zu der folgenden Erkenntnis: Der Grund dafür, dass viele Konfektionsgrößen offenbar {{34}} den Kundinnen noch den Kunden passen, sei die körperliche Entwicklung der Bevölkerung in Deutschland. Seit den 1960er Jahren seien die Deutschen im Durchschnitt um bis zu acht Zentimeter sowohl größer als auch dicker geworden. Die Länge der Arme {{35}} zugenommen, besonders aber an den Hüften hätten die Deutschen beträchtlich zugelegt.\n\n{{36}} man natürlich daran interessiert ist, Kleidungsstücke in den richtigen Größen und in ausreichender Zahl zu produzieren, soll jetzt neu ermittelt werden, welche Größen die Kunden eigentlich brauchen. Dazu wurde ein neues Verfahren entwickelt, {{37}} Männer und Frauen neu vermessen soll. Bei der Body-Scan-Technologie tasten mehrere Kameras mit Laserlicht die menschlichen Körper ab und erstellen ein dreidimensionales Ebenbild der gescannten Person. Diese dreidimensionalen Bilder {{38}} es ermöglichen, in Zukunft genauere Informationen über die durchschnittliche Körpergröße zu erhalten. Ähnliche Messungen werden auch in Großbritannien, den Niederlanden, den skandinavischen Ländern, Frankreich und den USA vorgenommen. Mehr als zwei Millionen Euro wollen die Modefirmen dafür investieren, das Ergebnis lohnt sich aber für sie auf jeden Fall.\n\nAls Kundinnen und Kunden dürfen wir uns außerdem darauf freuen, {{39}} sich als Nebenprodukt der Körpervermessung in den verschiedenen Ländern die Modefirmen vielleicht endlich dafür entscheiden, weltweit gleiche Nummern für gleiche Größen einzuführen. Dann ist ein Kleidungsstück mit der Nummer 36 überall {{40}} groß, ob in Nord- oder Südeuropa, in Amerika oder Asien.",
      "words": {
        "a": "ALS",
        "b": "DA",
        "c": "DARÜBER",
        "d": "DARUM",
        "e": "DAS",
        "f": "DASS",
        "g": "GLEICH",
        "h": "HABE",
        "i": "INS",
        "j": "KAM",
        "k": "NUR",
        "l": "SOLLEN",
        "m": "SONDERN",
        "n": "SOWIE",
        "o": "WEDER"
      },
      "answers": {
        "31": {
          "key": "c",
          "note": "sich aufregen über -> Pronominaladverb „darüber aufgeregt, dass ...“."
        },
        "32": {
          "key": "k",
          "note": "„fast nur noch in den falschen Größen“."
        },
        "33": {
          "key": "j",
          "note": "Funktionsverbgefüge im Präteritum: „kam zu der folgenden Erkenntnis“."
        },
        "34": {
          "key": "o",
          "note": "„weder den Kundinnen noch den Kunden“."
        },
        "35": {
          "key": "h",
          "note": "Indirekte Rede im Konjunktiv I Perfekt Singular („Die Länge der Arme habe zugenommen“)."
        },
        "36": {
          "key": "b",
          "note": "Kausale Konjunktion: „Da man natürlich daran interessiert ist, ...“."
        },
        "37": {
          "key": "e",
          "note": "Relativpronomen Nominativ Neutrum („ein neues Verfahren, das ...“)."
        },
        "38": {
          "key": "l",
          "note": "„Diese dreidimensionalen Bilder sollen es ermöglichen“."
        },
        "39": {
          "key": "f",
          "note": "„darauf freuen, dass ...“."
        },
        "40": {
          "key": "g",
          "note": "„überall gleich groß“."
        }
      }
    },
    {
      "id": "9",
      "num": "9",
      "page": 421,
      "isVariant": false,
      "title": "Das Fahrrad: ernsthafte Konkurrenz fürs Auto?",
      "category": "Mobilität & Gesundheit",
      "text": "Welches Fortbewegungsmittel, denken Sie, wird in Deutschland am häufigsten benutzt? Natürlich das Automobil. Volkswagen, Porsche, Mercedes-Benz, BMW, Audi: In {{31}} einem anderen Land gibt es so viele Automobilfabriken wie in Deutschland, spielt die Automobilindustrie eine so große Rolle. Nahezu jeder Haushalt verfügt über mindestens ein Auto, das Auto spielt im Leben der Deutschen eine große Rolle, sowohl als Fortbewegungsmittel zum Arbeitsplatz oder in den Urlaub als auch als Statussymbol: Zeig mir dein Auto und ich weiß, wer du bist.\n\nDoch hat das Autofahren auch Schattenseiten. Mangelnde Bewegungsmöglichkeiten, gesundheitliche Probleme und Stress bringen zumindest in den Großstädten immer mehr Autofahrer dazu, sich vom Automobil freizumachen und {{32}} ein anderes Verkehrsmittel umzusteigen, das in dem Ruf steht, gesünder zu sein als das Auto: das Fahrrad. Nicht nur in der Freizeit, sondern auch auf dem Weg zum Arbeitsplatz wird das Rad benutzt. „Ich habe keine Lust, Morgen für Morgen im Stau zu stehen und Zeit zu verlieren“, sagt Bettina Meier (25): „Da ist es viel entspannender, auf den zumeist gut ausgebauten Fahrradwegen an den im Stau wartenden Fahrzeugen {{33}} und ausgeruht am Arbeitsplatz anzukommen.“\n\nDass Fahrradfahren um einiges gesünder ist, als hinter dem Lenkrad zu sitzen, bestätigen auch die Mediziner. Wer Fahrrad fährt, {{34}} zu sitzen, bringt seinen Blutkreislauf in Schwung, stärkt die Abwehrkräfte des Körpers und trainiert seinen Körper. Auch die Bewegung an der frischen Luft tut Menschen gut, die sich sonst die meiste Zeit {{35}} geschlossener Räume in Büros, Schulen oder Fabriken aufhalten {{36}}.\n\nAuch die Geschäftswelt hat die Fahrradfahrer als Kunden entdeckt. Ein breites Angebot {{37}} Zubehör für Fahrräder von schicken Radfelgen über sportliche Mehrganggetriebe, mit denen Berge kein Problem mehr darstellen, bis zur Designer-Trinkflasche macht aus dem einfachen Fahrrad ein exklusives Fahrzeug. Und natürlich darf bei keinem Fahrradfahrer eine aufwändige Sicherheitsausstattung mehr fehlen: Schutzhelme, Ellenbogen- und Knieschützer, die das Fahrrad im Falle eines Unfalls fast so sicher wie einen Panzer machen {{38}}.\n\nNur wenn es regnet – und das passiert in Deutschland leider nicht so selten –, {{39}} sind die Autoschlangen wieder länger. {{40}} einen praktischen Wetterschutz für Radfahrer haben die Geschäfte noch nicht im Angebot.",
      "words": {
        "a": "AN",
        "b": "AUF",
        "c": "BEINAHE",
        "d": "DAFÜR",
        "e": "DANN",
        "f": "DENN",
        "g": "DÜRFEN",
        "h": "FAST",
        "i": "INNERHALB",
        "j": "KAUM",
        "k": "MÜSSEN",
        "l": "SOLLEN",
        "m": "STATT",
        "n": "VOR",
        "o": "VORBEI"
      },
      "answers": {
        "31": {
          "key": "j",
          "note": "Feste Verbindung: „In kaum einem anderen Land“ (= fast nirgendwo sonst)."
        },
        "32": {
          "key": "b",
          "note": "umsteigen auf (+ Akkusativ)."
        },
        "33": {
          "key": "o",
          "note": "an den wartenden Fahrzeugen „vorbei(zufahren)“."
        },
        "34": {
          "key": "m",
          "note": "Infinitivkonstruktion: „statt (= anstatt) zu sitzen“."
        },
        "35": {
          "key": "i",
          "note": "Präposition mit Genitiv Plural: „innerhalb geschlossener Räume“."
        },
        "36": {
          "key": "k",
          "note": "Relativsatz mit Verbendstellung: „die sich ... in Büros aufhalten müssen“."
        },
        "37": {
          "key": "a",
          "note": "Feste Präposition: „ein breites Angebot an (+ Dativ)“."
        },
        "38": {
          "key": "l",
          "note": "Beabsichtigter Zweck der Schutzausrüstung: „so sicher wie einen Panzer machen sollen“."
        },
        "39": {
          "key": "e",
          "note": "Korrelat nach „wenn“-Satz: „Nur wenn es regnet ..., dann sind die Autoschlangen wieder länger.“"
        },
        "40": {
          "key": "f",
          "note": "Hauptsatzkonjunktion auf Position 0: „Denn einen praktischen Wetterschutz haben die Geschäfte noch nicht.“"
        }
      }
    },
    {
      "id": "9a",
      "num": "9a",
      "page": 422,
      "isVariant": true,
      "title": "Das Fahrrad: ernsthafte Konkurrenz fürs Auto? (Variante 9a)",
      "category": "Mobilität & Gesundheit",
      "text": "Welches Fortbewegungsmittel, denken Sie, wird in Deutschland am häufigsten benutzt? Natürlich das Automobil. Volkswagen, Porsche, Mercedes-Benz, BMW, Audi: In {{31}} einem anderen Land gibt es so viele Automobilfabriken wie in Deutschland, spielt die Automobilindustrie eine so große Rolle. Nahezu jeder Haushalt verfügt über mindestens ein Auto, das Auto spielt im Leben der Deutschen eine große Rolle, sowohl als Fortbewegungsmittel zum Arbeitsplatz oder in den Urlaub als auch als Statussymbol: Zeig mir dein Auto und ich weiß, wer du bist.\n\nDoch hat das Autofahren auch Schattenseiten. Mangelnde Bewegungsmöglichkeiten, gesundheitliche Probleme und Stress bringen zumindest in den Großstädten immer mehr Autofahrer dazu, sich vom Automobil freizumachen und {{32}} ein anderes Verkehrsmittel umzusteigen, das in dem Ruf steht, gesünder zu sein als das Auto: das Fahrrad. Nicht nur in der Freizeit, sondern auch auf dem Weg zum Arbeitsplatz wird das Rad benutzt. „Ich habe keine Lust, Morgen für Morgen im Stau zu stehen und Zeit zu verlieren“, sagt Bettina Meier (25): „Da ist es viel entspannender, auf den {{33}} gut ausgebauten Fahrradwegen an den im Stau wartenden Fahrzeugen vorbeizufahren und ausgeruht am Arbeitsplatz anzukommen.“\n\nDass Fahrradfahren um einiges gesünder ist, als hinter dem Lenkrad zu sitzen, bestätigen auch die Mediziner. Wer Fahrrad fährt, {{34}} zu sitzen, bringt seinen Blutkreislauf in Schwung, stärkt die Abwehrkräfte des Körpers und trainiert seinen Körper. Auch die Bewegung an der frischen Luft tut Menschen gut, die sich sonst die meiste Zeit {{35}} geschlossener Räume in Büros, Schulen oder Fabriken aufhalten {{36}}.\n\nAuch die Geschäftswelt hat die Fahrradfahrer als Kunden entdeckt. Ein breites Angebot {{37}} Zubehör für Fahrräder von schicken Radfelgen über sportliche Mehrganggetriebe, mit denen Berge kein Problem mehr darstellen, bis zur Designer-Trinkflasche macht aus dem einfachen Fahrrad ein exklusives Fahrzeug. Und natürlich darf bei keinem Fahrradfahrer eine aufwändige Sicherheitsausstattung mehr fehlen: Schutzhelme, Ellenbogen- und Knieschützer, die das Fahrrad im Falle eines Unfalls fast so sicher wie einen Panzer machen {{38}}.\n\nNur wenn es regnet – und das passiert in Deutschland leider nicht so selten –, {{39}} sind die Autoschlangen wieder länger. {{40}} einen praktischen Wetterschutz für Radfahrer haben die Geschäfte noch nicht im Angebot.",
      "words": {
        "a": "AN",
        "b": "AUF",
        "c": "BEINAHE",
        "d": "DAFÜR",
        "e": "DANN",
        "f": "DENN",
        "g": "DÜRFEN",
        "h": "FAST",
        "i": "INNERHALB",
        "j": "KAUM",
        "k": "MÜSSEN",
        "l": "SOLLEN",
        "m": "STATT",
        "n": "VOR",
        "o": "ZUMEIST"
      },
      "answers": {
        "31": {
          "key": "j",
          "note": "„In kaum einem anderen Land“."
        },
        "32": {
          "key": "b",
          "note": "„auf ein anderes Verkehrsmittel umzusteigen“."
        },
        "33": {
          "key": "o",
          "note": "„auf den zumeist (= meistens) gut ausgebauten Fahrradwegen“."
        },
        "34": {
          "key": "m",
          "note": "„statt zu sitzen“."
        },
        "35": {
          "key": "i",
          "note": "„innerhalb geschlossener Räume“."
        },
        "36": {
          "key": "k",
          "note": "„aufhalten müssen“."
        },
        "37": {
          "key": "a",
          "note": "„Ein breites Angebot an Zubehör“."
        },
        "38": {
          "key": "l",
          "note": "„machen sollen“."
        },
        "39": {
          "key": "e",
          "note": "„dann sind die Autoschlangen wieder länger“."
        },
        "40": {
          "key": "f",
          "note": "„Denn einen praktischen Wetterschutz ...“."
        }
      }
    },
    {
      "id": "10",
      "num": "10",
      "page": 423,
      "isVariant": false,
      "title": "Ist der Umgang mit Haustieren gesund für Kleinkinder?",
      "category": "Gesundheit & Haustiere",
      "text": "Kleine Kinder, die in der Gesellschaft von Haustieren wie Hund und Katze leben, sind einer Studie aus Finnland zufolge seltener krank {{31}} Kinder in Haushalten ohne Tiere. Die Studie wurde in der {{32}} Woche in einem amerikanischen Fachmagazin veröffentlicht. Es wurden {{33}} keine Erklärungen für diese Tatsache geliefert, aber die Vermutung wurde geäußert, dass der Kontakt zu Hunden das Immunsystem der Kleinkinder stärke. Hunde haben nämlich {{34}} die täglichen Spaziergänge draußen viel Kontakt zu möglichen Krankheitserregern und trainieren vielleicht so das Immunsystem der Kinder. Auch Katzen, die die Möglichkeit haben, nach draußen zu gehen, haben danach {{35}} Wirkung auf die Gesundheit der Kinder, wenngleich in geringerem Maße.\n\nFür die Studie {{36}} in Finnland 397 Babys über den Zeitraum von der neunten Lebenswoche bis zu ihrem ersten Geburtstag beobachtet. Dabei hatten die mit Hund oder Katze aufwachsenden Kinder ein um 30 % {{37}} Risiko für Erkrankungen der Atemwege. Es fiel auf, dass bei diesen Kindern Ohrenentzündungen {{38}} oft auftraten.\n\nDie Studie kommt daher zu dem Schluss, dass die Gesundheit von Kindern in Gesellschaft von Tieren {{39}} besser sei. Frühere Untersuchungen aus den USA hatten das genaue {{40}} der jetzigen Ergebnisse ergeben. Ob diese Unterschiede mit den unterschiedlichen Lebens- und Umweltbedingungen der beiden Länder zusammenhängen, ist noch unklar.",
      "words": {
        "a": "ZWAR",
        "b": "WURDEN",
        "c": "WIE",
        "d": "WENIGER",
        "e": "WAREN",
        "f": "VERGANGENEN",
        "g": "UM",
        "h": "GERINGERES",
        "i": "GEGENTEIL",
        "j": "GEGENSATZ",
        "k": "FRÜHEREN",
        "l": "DURCH",
        "m": "DIESELBE",
        "n": "DEUTLICH",
        "o": "ALS"
      },
      "answers": {
        "31": {
          "key": "o",
          "note": "Vergleich nach Komparativ („seltener krank als ...“)."
        },
        "32": {
          "key": "f",
          "note": "Zeitangabe im Singular: „in der vergangenen (= letzten) Woche“."
        },
        "33": {
          "key": "a",
          "note": "Konzessive Struktur: „Es wurden zwar keine Erklärungen geliefert, aber ...“."
        },
        "34": {
          "key": "l",
          "note": "Kausal/Instrumental (+ Akkusativ): „durch die täglichen Spaziergänge“."
        },
        "35": {
          "key": "m",
          "note": "Demonstrativpronomen feminin Singular: „dieselbe Wirkung“."
        },
        "36": {
          "key": "b",
          "note": "Vorgangspassiv Präteritum: „wurden ... 397 Babys beobachtet“."
        },
        "37": {
          "key": "h",
          "note": "Komparativ Neutrum Singular nach „ein“: „ein um 30 % geringeres Risiko“."
        },
        "38": {
          "key": "d",
          "note": "Komparativ von „wenig“: „weniger oft (= seltener) auftraten“."
        },
        "39": {
          "key": "n",
          "note": "Adverb vor Komparativ: „deutlich besser“."
        },
        "40": {
          "key": "i",
          "note": "Neutrum („das genaue Gegenteil“; „Gegensatz“ wäre maskulin)."
        }
      }
    },
    {
      "id": "10a",
      "num": "10a",
      "page": 424,
      "isVariant": true,
      "title": "Stärkt der Kontakt zu Haustieren das Immunsystem? (Variante 10a)",
      "category": "Gesundheit & Haustiere",
      "text": "Kleine Kinder, die in der Gesellschaft von Haustieren wie Hund und Katze leben, sind einer Studie aus Finnland zufolge seltener krank {{31}} Kinder in Haushalten ohne Tiere.\n\nDie Studie wurde in der {{32}} Woche in einem amerikanischen Fachmagazin veröffentlicht. Es wurden {{33}} keine Erklärungen für diese Tatsachen geliefert, aber die Vermutung wurde geäußert, dass der Kontakt zu Hunden das Immunsystem der Kleinkinder stärke. Hunde haben nämlich {{34}} die täglichen Spaziergänge draußen viel Kontakt zu möglichen Krankheitserregern und trainieren vielleicht so das Immunsystem der Kinder. Auch Katzen, die die Möglichkeit haben, nach draußen zu gehen, haben danach {{35}} Wirkung auf die Gesundheit der Kinder, wenngleich in geringerem Maße.\n\nFür die Studie {{36}} in Finnland 397 Babys über einen Zeitraum von der neunten Lebenswoche bis zu ihrem ersten Geburtstag beobachtet. Dabei hatten die mit Hund oder Katze aufwachsenden Kinder ein um 30 % {{37}} Risiko für Erkrankungen der Atemwege. Es fiel auf, dass bei diesen Kindern Ohrenentzündungen {{38}} oft auftreten.\n\nDie Studie kommt daher zu dem Schluss, dass die Gesundheit von Kindern in Gesellschaft von Tieren {{39}} besser sei. Frühere Untersuchungen aus den USA hatten das genaue {{40}} der jetzigen Ergebnisse ergeben. Ob diese Unterschiede mit den unterschiedlichen Lebens- und Umweltbedingungen der beiden Länder zusammenhängen, ist noch unklar.",
      "words": {
        "a": "ALS",
        "b": "DEUTLICH",
        "c": "DIESELBE",
        "d": "DURCH",
        "e": "FRÜHEREN",
        "f": "GEGENSATZ",
        "g": "GEGENTEIL",
        "h": "GERINGERES",
        "i": "UM",
        "j": "VERGANGENEN",
        "k": "WAREN",
        "l": "WENIGER",
        "m": "WIE",
        "n": "WURDEN",
        "o": "ZWAR"
      },
      "answers": {
        "31": {
          "key": "a",
          "note": "„seltener krank als Kinder in Haushalten ohne Tiere“."
        },
        "32": {
          "key": "j",
          "note": "„in der vergangenen Woche“."
        },
        "33": {
          "key": "o",
          "note": "„zwar ..., aber ...“."
        },
        "34": {
          "key": "d",
          "note": "„durch die täglichen Spaziergänge“."
        },
        "35": {
          "key": "c",
          "note": "„dieselbe Wirkung“."
        },
        "36": {
          "key": "n",
          "note": "„wurden ... beobachtet“."
        },
        "37": {
          "key": "h",
          "note": "„ein um 30 % geringeres Risiko“."
        },
        "38": {
          "key": "l",
          "note": "„weniger oft auftreten“."
        },
        "39": {
          "key": "b",
          "note": "„deutlich besser“."
        },
        "40": {
          "key": "g",
          "note": "„das genaue Gegenteil“."
        }
      }
    },
    {
      "id": "11",
      "num": "11",
      "page": 425,
      "isVariant": false,
      "title": "Schwarzarbeit kann teuer werden",
      "category": "Wirtschaft & Recht",
      "text": "Schnäppchen machen, um Rabatte feilschen: Wer billig einkauft, gilt als clever. Vorsicht ist jedoch bei Aufträgen an Schwarzarbeiter geboten. Denn schnell zahlt der Kunde drauf, {{31}} – wie durch das illegale Arbeitsverhältnis erhofft – Geld zu sparen.\n\nRund ums Haus ist nicht {{32}} Gelegenheit so günstig, wie sie anfangs scheint: Schwarzarbeit etwa ist nicht nur verboten, sondern es gibt auch ein finanzielles Argument {{33}} illegale Arbeiter: Oftmals rechnet sich der Dienst gegen Barzahlung gar nicht. „Abgesehen {{34}}, dass es strafbar ist, Schwarzarbeiter zu beschäftigen, nimmt der Auftraggeber handfeste steuerliche Nachteile in Kauf“, warnt Dirk Witte, Steuerberater aus Wildeshausen in Niedersachsen. Wer eine Putzhilfe beschäftigt, kann die Steuerlast auch auf legalem Weg spürbar senken. Auch für die Modernisierung, Renovierung und Sanierung der Wohnung gibt es einen Steuernachlass, allerdings nur für legale Arbeiten. „Das Finanzamt {{35}} eine ordentliche Rechnung und einen Überweisungsbeleg sehen.“ Barzahler können daher nichts von der Steuer absetzen.\n\nNoch schwerer fällt ins Gewicht, dass ein Kunde seine Haftungsansprüche aufs Spiel setzt, wenn er vordergründig ein paar Euro sparen möchte. Denn mängelfreie Bauten {{36}} eher die Ausnahme. Und ob ein Kunde die Beseitigung von Mängeln gerichtlich gegen einen Schwarzarbeiter durchsetzen kann, ist von Fall zu Fall zu prüfen. Im Prinzip muss man aber damit rechnen, die Ansprüche zu verlieren. Ebenso dürften Verbraucher leer {{37}}, wenn beim Bauen etwas zu Bruch geht. Ein ordentlicher Handwerker hat für {{38}} Fälle eine Haftpflichtversicherung.\n\nRichtig teuer werden können auch Unfälle, bei denen sich der illegale Helfer verletzt. Dann zahlen weder Krankenversicherung noch Unfallkasse. Fällt etwa ein Arbeiter vom Gerüst und ist danach dauerhaft querschnittsgelähmt, dann wird der Kunde dafür sein Leben lang zahlen. Die Folgen von Schwarzarbeit lassen sich mit dem Dominoprinzip beschreiben: Fliegt die illegale Beschäftigung auf, dann {{39}} es gleich mehrere Behörden mit. Post gibt es dann vom Finanzamt, der Staatsanwaltschaft und den Sozialversicherungsträgern. Dann braucht der Auftraggeber {{40}} einen Anwalt. Und der kostet natürlich auch wieder Geld.",
      "words": {
        "a": "ALLES",
        "b": "ANSTATT",
        "c": "AUSGEHEN",
        "d": "BEKOMMEN",
        "e": "BILDEN",
        "f": "DAGEGEN",
        "g": "DAVON",
        "h": "GEGEN",
        "i": "HÖCHSTENS",
        "j": "JEDE",
        "k": "MEISTENS",
        "l": "SOLCHE",
        "m": "UM",
        "n": "WILL",
        "o": "WÜNSCHT"
      },
      "answers": {
        "31": {
          "key": "b",
          "note": "Infinitivkonstruktion: „anstatt ... Geld zu sparen“."
        },
        "32": {
          "key": "j",
          "note": "Nominativ feminin Singular: „nicht jede Gelegenheit“."
        },
        "33": {
          "key": "h",
          "note": "„ein finanzielles Argument gegen illegale Arbeiter“."
        },
        "34": {
          "key": "g",
          "note": "Feste Verbindung: „Abgesehen davon, dass ...“."
        },
        "35": {
          "key": "n",
          "note": "Modalverb mit reinem Infinitiv („sehen“): „Das Finanzamt will ... sehen.“"
        },
        "36": {
          "key": "e",
          "note": "Feste Wendung: „die Ausnahme bilden“ (= die Ausnahme sein)."
        },
        "37": {
          "key": "c",
          "note": "Redewendung: „leer ausgehen“ (= nichts bekommen)."
        },
        "38": {
          "key": "l",
          "note": "Akkusativ Plural: „für solche (= derartige) Fälle“."
        },
        "39": {
          "key": "d",
          "note": "Trennbares Verb „mitbekommen“ (= erfahren): „dann bekommen es gleich mehrere Behörden mit“."
        },
        "40": {
          "key": "k",
          "note": "Häufigkeitsadverb: „Dann braucht der Auftraggeber meistens (= in der Regel) einen Anwalt.“"
        }
      }
    },
    {
      "id": "11a",
      "num": "11a",
      "page": 426,
      "isVariant": true,
      "title": "Schwarzarbeit kann teuer werden (Variante 11a)",
      "category": "Wirtschaft & Recht",
      "text": "Schnäppchen machen, um Rabatte feilschen: Wer billig einkauft, gilt als clever. Vorsicht ist jedoch bei Aufträgen an Schwarzarbeiter geboten. Denn schnell zahlt der Kunde drauf, {{31}} – wie durch das illegale Arbeitsverhältnis erhofft – Geld zu sparen.\n\nRund ums Haus ist nicht {{32}} Gelegenheit so günstig, wie sie anfangs scheint: Schwarzarbeit etwa ist nicht nur verboten, sondern es gibt auch ein finanzielles Argument {{33}} illegale Arbeiter: Oftmals rechnet sich der Dienst gegen Barzahlung gar nicht. „Abgesehen {{34}}, dass es strafbar ist, Schwarzarbeiter zu beschäftigen, nimmt der Auftraggeber handfeste steuerliche Nachteile in Kauf“, warnt Dirk Witte, Steuerberater aus Wildeshausen in Niedersachsen. Wer eine Putzhilfe beschäftigt, kann die Steuerlast auch auf legalem Weg spürbar senken. Auch für die Modernisierung, Renovierung und Sanierung der Wohnung gibt es einen Steuernachlass, allerdings nur für legale Arbeiten. „Das Finanzamt {{35}} eine ordentliche Rechnung und einen Überweisungsbeleg sehen.“ Barzahler können daher nichts von der Steuer absetzen.\n\nNoch schwerer fällt ins Gewicht, dass ein Kunde seine Haftungsansprüche aufs Spiel setzt, wenn er vordergründig ein paar Euro sparen möchte. Denn mängelfreie Bauten {{36}} eher die Ausnahme dar. Und ob ein Kunde die Beseitigung von Mängeln gerichtlich gegen einen Schwarzarbeiter durchsetzen kann, ist von Fall zu Fall zu prüfen. Im Prinzip muss man aber damit rechnen, die Ansprüche zu verlieren. Ebenso dürften Verbraucher leer {{37}}, wenn beim Bauen etwas zu Bruch geht. Ein ordentlicher Handwerker hat für {{38}} Fälle eine Haftpflichtversicherung.\n\nRichtig teuer werden können auch Unfälle, bei denen sich der illegale Helfer verletzt. Dann zahlen weder Krankenversicherung noch Unfallkasse. Fällt etwa ein Arbeiter vom Gerüst und ist danach dauerhaft querschnittsgelähmt, dann wird der Kunde dafür sein Leben lang zahlen. Die Folgen von Schwarzarbeit lassen sich mit dem Dominoprinzip beschreiben: Fliegt die illegale Beschäftigung auf, dann {{39}} es gleich mehrere Behörden mit. Post gibt es dann vom Finanzamt, der Staatsanwaltschaft und den Sozialversicherungsträgern. Dann braucht der Auftraggeber {{40}} einen Anwalt. Und der kostet natürlich auch wieder Geld.",
      "words": {
        "a": "ALLES",
        "b": "ANSTATT",
        "c": "AUSGEHEN",
        "d": "BEKOMMEN",
        "e": "WECHSELN",
        "f": "DAGEGEN",
        "g": "DAVON",
        "h": "GEGEN",
        "i": "STELLEN",
        "j": "JEDE",
        "k": "MEISTENS",
        "l": "SOLCHE",
        "m": "UM",
        "n": "WILL",
        "o": "WÜNSCHT"
      },
      "answers": {
        "31": {
          "key": "b",
          "note": "„anstatt ... Geld zu sparen“."
        },
        "32": {
          "key": "j",
          "note": "„nicht jede Gelegenheit“."
        },
        "33": {
          "key": "h",
          "note": "„ein finanzielles Argument gegen illegale Arbeiter“."
        },
        "34": {
          "key": "g",
          "note": "„Abgesehen davon, dass ...“."
        },
        "35": {
          "key": "n",
          "note": "„Das Finanzamt will ... sehen.“"
        },
        "36": {
          "key": "i",
          "note": "Trennbares Verb „darstellen“: „Denn mängelfreie Bauten stellen eher die Ausnahme dar.“"
        },
        "37": {
          "key": "c",
          "note": "„leer ausgehen“."
        },
        "38": {
          "key": "l",
          "note": "„für solche Fälle“."
        },
        "39": {
          "key": "d",
          "note": "„bekommen es gleich mehrere Behörden mit“."
        },
        "40": {
          "key": "k",
          "note": "„braucht der Auftraggeber meistens einen Anwalt“."
        }
      }
    },
    {
      "id": "12",
      "num": "12",
      "page": 427,
      "isVariant": false,
      "title": "Was steckt hinter „Bio“?",
      "category": "Ernährung & Umwelt",
      "text": "Überall gibt es inzwischen Bio-Lebensmittel – aber häufig fehlen den Käufern Hintergrundinformationen. Viele Verbraucher fragen sich beispielsweise, {{31}} Bio-Produkte nun auch wirklich die gesünderen sind. Skepsis macht sich breit, spätestens wenn wieder einmal ein Skandal in den Nachrichten ist. {{32}} sind Bio-Produkte teurer – und den Aufpreis will man nur zahlen, wenn man sicher ist, dass die Bio-Lebensmittel die bessere Wahl sind.\n\nDer Informationsdienst des Bundesministeriums für Ernährung, Landwirtschaft und Verbraucherschutz gibt darüber eine eindeutige Auskunft: Bio-Lebensmittel sind gesünder. Sie {{33}} weniger Nitrat, mehr Nährstoffe und sind besser geeignet, wenn man Allergien hat. Doch Bio-Lebensmittel sind nicht nur gut für die Gesundheit. Bei vielen Verbrauchern steht {{34}} ihrem Einkaufsverhalten ein ökologisches Bewusstsein. Bio-Verbraucher machen sich Gedanken über die Herkunft der Lebensmittel, denn auch die umweltfreundliche Landwirtschaft ist besser für Tiere und Pflanzen, kurz: Sie {{35}} unsere Umwelt. Und viele Bio-Verbraucher wollen als gesunde Menschen in einer gesunden Umwelt leben und auch der nächsten Generation eine gesunde Umwelt hinterlassen.\n\nBio-Lebensmittel kommen {{36}} ökologischer Landwirtschaft, die im Einklang mit der Natur steht. Die Mindestrichtlinien der Bio-Landwirtschaft beinhalten eine artgerechte Tierhaltung: Alle Tiere müssen ausreichend Platz haben, es gibt keine langen Tiertransporte, keine Gentechnik. Die Produkte werden möglichst in der näheren Umgebung verkauft, beispielsweise {{37}} Wochenmärkten oder in Bio-Supermärkten. Außerdem dürfen weder Kunstdünger noch chemische Schädlingsbekämpfungsmittel {{38}} werden. Wenn die Bio-Lebensmittel weiterverarbeitet werden – beispielsweise aus Bio-Eiern, Bio-Mehl und Bio-Zucker ein Bio-Kuchen gebacken wird –, dürfen {{39}} nur Bio-Lebensmittel benutzt werden. Für Bio-Produkte gibt es übrigens auch ein Zertifikat, das Bio-Siegel. Diese Richtlinien garantieren, {{40}} die Produkte wirklich „bio“ sind.",
      "words": {
        "a": "AN",
        "b": "AUF",
        "c": "AUS",
        "d": "AUSSERDEM",
        "e": "DASS",
        "f": "ENTHALTEN",
        "g": "ENTLASTET",
        "h": "FÜR",
        "i": "HINTER",
        "j": "OB",
        "k": "SOGAR",
        "l": "SONDERN",
        "m": "VERWENDET",
        "n": "WENN",
        "o": "WIRKLICH"
      },
      "answers": {
        "31": {
          "key": "j",
          "note": "Indirekter Fragesatz nach „fragen sich“: „ob Bio-Produkte wirklich die gesünderen sind“."
        },
        "32": {
          "key": "d",
          "note": "Weiteres Argument: „Außerdem sind Bio-Produkte teurer“."
        },
        "33": {
          "key": "f",
          "note": "„Sie (die Bio-Lebensmittel) enthalten weniger Nitrat, mehr Nährstoffe“."
        },
        "34": {
          "key": "i",
          "note": "Feste Wendung: „hinter ihrem Einkaufsverhalten steht ein ökologisches Bewusstsein“."
        },
        "35": {
          "key": "g",
          "note": "„Sie (die umweltfreundliche Landwirtschaft) entlastet (= schont) unsere Umwelt.“"
        },
        "36": {
          "key": "c",
          "note": "Herkunft: „kommen aus ökologischer Landwirtschaft“."
        },
        "37": {
          "key": "b",
          "note": "Präposition bei „Markt“: „auf Wochenmärkten“."
        },
        "38": {
          "key": "m",
          "note": "Passiv mit Modalverb: „dürfen weder Kunstdünger noch ... verwendet werden“."
        },
        "39": {
          "key": "o",
          "note": "Verstärkung: „dürfen wirklich nur Bio-Lebensmittel benutzt werden“."
        },
        "40": {
          "key": "e",
          "note": "Objektsatz nach „garantieren, dass ...“."
        }
      }
    },
    {
      "id": "12a",
      "num": "12a",
      "page": 428,
      "isVariant": true,
      "title": "Was steckt hinter „Bio“? (Variante 12a)",
      "category": "Ernährung & Umwelt",
      "text": "Überall gibt es inzwischen Bio-Lebensmittel – aber häufig fehlen den Käufern Hintergrundinformationen. Viele Verbraucher fragen sich beispielsweise, {{31}} Bio-Produkte nun auch wirklich die gesünderen sind. Skepsis macht sich breit, spätestens wenn wieder einmal ein Skandal in den Nachrichten ist. {{32}} sind Bio-Produkte teurer – und den Aufpreis will man nur zahlen, wenn man sicher ist, dass die Bio-Lebensmittel die bessere Wahl sind.\n\nDer Informationsdienst des Bundesministeriums für Ernährung, Landwirtschaft und Verbraucherschutz gibt darüber eine eindeutige Auskunft: Bio-Lebensmittel sind gesünder. Sie {{33}} weniger Nitrat, mehr Nährstoffe und sind besser geeignet, wenn man Allergien hat. Doch Bio-Lebensmittel sind nicht nur gut für die Gesundheit. Bei vielen Verbrauchern steht {{34}} ihrem Einkaufsverhalten ein ökologisches Bewusstsein. Bio-Verbraucher machen sich Gedanken über die Herkunft der Lebensmittel, denn auch die umweltfreundliche Landwirtschaft ist besser für Tiere und Pflanzen, kurz: Sie {{35}} unsere Umwelt. Und viele Bio-Verbraucher wollen als gesunde Menschen in einer gesunden Umwelt leben und auch der nächsten Generation eine gesunde Umwelt hinterlassen.\n\nBio-Lebensmittel kommen {{36}} ökologischer Landwirtschaft, die im Einklang mit der Natur steht. Die Mindestrichtlinien der Bio-Landwirtschaft beinhalten eine artgerechte Tierhaltung: Alle Tiere müssen ausreichend Platz haben, es gibt keine langen Tiertransporte, keine Gentechnik. Die Produkte werden möglichst in der näheren Umgebung verkauft, beispielsweise {{37}} Wochenmärkten oder in Bio-Supermärkten. Außerdem dürfen weder Kunstdünger noch chemische Schädlingsbekämpfungsmittel {{38}} werden. Wenn die Bio-Lebensmittel weiterverarbeitet werden – beispielsweise aus Bio-Eiern, Bio-Mehl und Bio-Zucker ein Bio-Kuchen gebacken wird –, dürfen {{39}} nur Bio-Lebensmittel benutzt werden. Für Bio-Produkte gibt es übrigens auch ein Zertifikat, das Bio-Siegel. Diese Richtlinien garantieren, {{40}} die Produkte wirklich „bio“ sind.",
      "words": {
        "a": "AN",
        "b": "AUF",
        "c": "AUS",
        "d": "AUSSERDEM",
        "e": "DASS",
        "f": "ENTHALTEN",
        "g": "ENTLASTET",
        "h": "BELASTET",
        "i": "HINTER",
        "j": "OB",
        "k": "SOGAR",
        "l": "SONDERN",
        "m": "VERWENDET",
        "n": "WENN",
        "o": "WIRKLICH"
      },
      "answers": {
        "31": {
          "key": "j",
          "note": "„fragen sich ..., ob ...“."
        },
        "32": {
          "key": "d",
          "note": "„Außerdem sind Bio-Produkte teurer“."
        },
        "33": {
          "key": "f",
          "note": "„Sie enthalten weniger Nitrat“."
        },
        "34": {
          "key": "i",
          "note": "„steht hinter ihrem Einkaufsverhalten“."
        },
        "35": {
          "key": "g",
          "note": "Positiver Effekt: „Sie entlastet unsere Umwelt“ (nicht „belastet“)."
        },
        "36": {
          "key": "c",
          "note": "„kommen aus ökologischer Landwirtschaft“."
        },
        "37": {
          "key": "b",
          "note": "„auf Wochenmärkten“."
        },
        "38": {
          "key": "m",
          "note": "„dürfen ... verwendet werden“."
        },
        "39": {
          "key": "o",
          "note": "„dürfen wirklich nur Bio-Lebensmittel benutzt werden“."
        },
        "40": {
          "key": "e",
          "note": "„garantieren, dass ...“."
        }
      }
    },
    {
      "id": "12b",
      "num": "12b",
      "page": 429,
      "isVariant": true,
      "title": "Was genau sind eigentlich Bio-Lebensmittel? (Variante 12b)",
      "category": "Ernährung & Umwelt",
      "text": "Überall gibt es inzwischen Bio-Lebensmittel – aber häufig fehlen den Käufern Hintergrundinformationen. So fragen sich viele Verbraucher beispielsweise, {{31}} Bio-Produkte denn wirklich gesünder sind als herkömmliche Produkte. Skepsis macht sich breit, spätestens wenn wieder einmal ein Skandal in den Nachrichten ist. {{32}} sind Bio-Produkte teurer, und den Aufpreis will man nur zahlen, wenn man sicher ist, dass die Bio-Lebensmittel die bessere Wahl sind.\n\nDer Informationsdienst des Bundesministeriums für Ernährung, Landwirtschaft und Verbraucherschutz gibt darüber eine eindeutige Auskunft: Bio-Lebensmittel sind gesünder. Sie {{33}} weniger Nitrat, mehr Nährstoffe und sind besser geeignet, wenn man Allergien hat. Doch Bio-Lebensmittel sind nicht nur gut für die Gesundheit. Bei vielen Verbrauchern steht ein ökologisches Bewusstsein {{34}} ihrem Einkaufsverhalten. Bio-Verbraucher machen sich Gedanken über die Herkunft der Lebensmittel, denn die umweltfreundliche Landwirtschaft ist besser für Tiere und Pflanzen, weil sie unsere Umwelt {{35}}. Und viele Bio-Verbraucher wollen als gesunde Menschen in einer gesunden Umwelt leben und auch der nächsten Generation eine gute, gesunde Umwelt hinterlassen.\n\nBio-Lebensmittel kommen {{36}} ökologischer Landwirtschaft, die im Einklang mit der Natur steht. Die Mindestrichtlinien der Bio-Landwirtschaft beinhalten eine artgerechte Tierhaltung: Alle Tiere müssen ausreichend Platz haben, es gibt keine langen Tiertransporte, keine Gentechnik. Die Produkte werden möglichst in der näheren Umgebung verkauft, beispielsweise {{37}} Wochenmärkten oder in Bio-Supermärkten. Außerdem dürfen weder Kunstdünger noch chemische Schädlingsbekämpfungsmittel {{38}} werden. Wenn zum Beispiel ein Bio-Kuchen gebacken werden soll, dann dürfen {{39}} nur Bio-Lebensmittel, wie etwa Bio-Eier, Bio-Mehl oder Bio-Zucker, benutzt werden. Für Bio-Produkte gibt es übrigens auch ein Zertifikat, das Bio-Siegel. Diese Richtlinien garantieren, {{40}} die Produkte wirklich „bio“ sind.",
      "words": {
        "a": "WIRKLICH",
        "b": "WENN",
        "c": "VON",
        "d": "VERWENDET",
        "e": "ÜBERLASSEN",
        "f": "OB",
        "g": "HINTER",
        "h": "ENTLASTET",
        "i": "ENTHALTEN",
        "j": "DASS",
        "k": "BELASTET",
        "l": "AUSSERDEM",
        "m": "AN",
        "n": "AUF",
        "o": "AUS"
      },
      "answers": {
        "31": {
          "key": "f",
          "note": "„fragen sich ..., ob ...“."
        },
        "32": {
          "key": "l",
          "note": "„Außerdem sind Bio-Produkte teurer“."
        },
        "33": {
          "key": "i",
          "note": "„Sie enthalten weniger Nitrat“."
        },
        "34": {
          "key": "g",
          "note": "„steht ein ökologisches Bewusstsein hinter ihrem Einkaufsverhalten“."
        },
        "35": {
          "key": "h",
          "note": "Nebensatz mit „weil“: „weil sie unsere Umwelt entlastet“."
        },
        "36": {
          "key": "o",
          "note": "„kommen aus ökologischer Landwirtschaft“."
        },
        "37": {
          "key": "n",
          "note": "„auf Wochenmärkten“."
        },
        "38": {
          "key": "d",
          "note": "„dürfen ... verwendet werden“."
        },
        "39": {
          "key": "a",
          "note": "„dürfen wirklich nur Bio-Lebensmittel benutzt werden“."
        },
        "40": {
          "key": "j",
          "note": "„garantieren, dass ...“."
        }
      }
    },
    {
      "id": "13",
      "num": "13",
      "page": 430,
      "isVariant": false,
      "title": "Teamarbeit als Schlüssel zum Erfolg (Erkenntnisse über Affen)",
      "category": "Wissenschaft & Verhaltensforschung",
      "text": "Nicht nur Menschen sind in der Lage, bei der Lösung einer Aufgabe mit anderen zusammenzuarbeiten. Ein deutsch-britisches Forscherteam konnte eindrücklich {{31}}, dass auch Schimpansen {{32}} echter Teamarbeit fähig sind. Die Wissenschaftler gaben zwei Schimpansen gemeinsam die Aufgabe, Trauben aus einer Kiste zu holen. {{33}} bekam einer der beiden Affen zwei Werkzeuge. Um die Aufgabe zu meistern, musste er aber eines {{34}} an seinen Artgenossen weitergeben. Zehn von zwölf Schimpansen taten dies auch, und in über 70 Prozent der Versuche {{35}} es sogar das richtige Werkzeug gewesen, berichten die Forscher.\n\nZiel der Untersuchung war es, herauszufinden, wo die Fähigkeit des Menschen zur Zusammenarbeit herkommt und ob diese Eigenschaft {{36}} beim Menschen vorhanden ist. Dass einige Tierarten zusammenarbeiten, beispielsweise bei der Jagd, war bekannt. Unklar war aber bisher, wie viel Teamarbeit bewusst erfolgt.\n\nIn dem Versuch musste der eine Affe Trauben mit einer Harke durch eine Öffnung in einer Kiste auf eine Platte schubsen. Der andere Affe musste dann mit einem Stock die Platte anheben, damit die Trauben auf den Boden fielen und die Affen sie fressen {{37}}. Bei den einzelnen Affen dauerte es unterschiedlich lange, bis ein Werkzeug weitergegeben wurde. Hatte einer es jedoch einmal getan, gab er in 97 Prozent der folgenden Versuche wieder ein Werkzeug weiter.\n\nDiese Studie {{38}} erste Hinweise darauf, dass Schimpansen bei einer gemeinsamen Aufgabe auf die Handlungen ihres Partners Acht {{39}} können. Den Affen scheint bewusst zu sein, dass ihr Artgenosse wichtig ist, um an die Trauben zu kommen. Daraus schließen die Forscher: Genau {{40}} den Menschen sei es den Affen möglich, strategisch zusammenzuarbeiten.",
      "words": {
        "a": "ZU",
        "b": "WIE",
        "c": "SEI",
        "d": "NUR",
        "e": "NACHWEISEN",
        "f": "MUSSTEN",
        "g": "LIEFERT",
        "h": "KONNTEN",
        "i": "HABEN",
        "j": "GEBEN",
        "k": "FÖRDERTE",
        "l": "ERBRINGEN",
        "m": "DAZU",
        "n": "DAVON",
        "o": "BEKANNTLICH"
      },
      "answers": {
        "31": {
          "key": "e",
          "note": "Infinitiv nach Modalverb „konnte“: „konnte eindrücklich nachweisen (= beweisen), dass ...“."
        },
        "32": {
          "key": "a",
          "note": "Feste Präposition: „fähig sein zu (+ Dativ)“."
        },
        "33": {
          "key": "m",
          "note": "„Dazu (= Zu diesem Zweck) bekam einer der beiden Affen zwei Werkzeuge.“"
        },
        "34": {
          "key": "n",
          "note": "Teilmenge („zwei Werkzeuge -> eines davon“)."
        },
        "35": {
          "key": "c",
          "note": "Indirekte Rede im Konjunktiv I Perfekt („sei ... gewesen, berichten die Forscher“)."
        },
        "36": {
          "key": "d",
          "note": "„ob diese Eigenschaft nur beim Menschen vorhanden ist“."
        },
        "37": {
          "key": "h",
          "note": "Finalsatz in der Vergangenheit: „damit die Trauben auf den Boden fielen und die Affen sie fressen konnten“."
        },
        "38": {
          "key": "g",
          "note": "Kollokation: „Hinweise liefern“."
        },
        "39": {
          "key": "j",
          "note": "Feste Wendung: „auf etwas Acht geben“ (= achten)."
        },
        "40": {
          "key": "b",
          "note": "Vergleich bei Gleichheit: „Genau wie den Menschen“."
        }
      }
    },
    {
      "id": "14",
      "num": "14",
      "page": 431,
      "isVariant": false,
      "title": "Verlernen die Deutschen die Höflichkeit?",
      "category": "Gesellschaft & Umgangsformen",
      "text": "„Höflichkeit gehört zu den Dingen, die allmählich verschwinden.“ Drei von vier Deutschen {{31}} dieser Behauptung zu: Früher waren die Menschen höflicher, {{32}} einer Umfrage zufolge 75 Prozent der Befragten. Genauso viele denken, dass junge Leute zu wenig Respekt vor älteren Menschen haben. Ärgert sich da möglicherweise nur die ältere Generation über den Verlust überholter Umgangsformen? Keineswegs: Glaubt man der Studie, besteht der Wunsch {{33}} gewissen Höflichkeitsformen altersübergreifend.\n\nKlare Spielregeln für ein höfliches {{34}}? In einer immer weniger von Formalität und offiziellen Hierarchien geprägten Welt sucht man sie oft {{35}}. Da wäre zum Beispiel die Frage nach dem Du oder Sie. {{36}} die Hälfte der Deutschen gibt zu, regelmäßig verunsichert zu sein, wie sie ihr Gegenüber ansprechen sollen. Während es jüngere Menschen zum Beispiel als normal oder sogar angenehm empfinden {{37}}, vom Kellner geduzt zu werden, kann es älteren Semestern den Restaurantbesuch vermiesen. Nur ein Viertel der Befragten kann sich damit anfreunden, besonders Ältere {{38}} sich am ungefragten Duzen.\n\nÜber andere Umgangsformen herrscht hingegen Konsens bei Jung und Alt: Den Sitzplatz in der Bahn Älteren oder Schwangeren anzubieten, finden 94 Prozent wichtig. 95 Prozent legen Wert auf Pünktlichkeit. Für immerhin 78 Prozent erfordert es die Höflichkeit, dass Männer Frauen die Tür aufhalten und ihnen den Vortritt {{39}}. Unhöflich finden es 91 Prozent, wenn jemand während einer Unterhaltung auf das Handy schaut.\n\nAngesichts von so viel Einigkeit über den angemessenen Umgang miteinander stellt sich freilich die Frage, warum so wenig davon im Alltag zu sehen ist. Wenn man weiß, was {{40}} gehört, kann es doch nicht so schwer sein, sich daran zu halten.",
      "words": {
        "a": "FEIN",
        "b": "GUT",
        "c": "LASSEN",
        "d": "MAN",
        "e": "MEINEN",
        "f": "MITEINANDER",
        "g": "MÖGEN",
        "h": "NACH",
        "i": "NACHEINANDER",
        "j": "NEHMEN",
        "k": "SICH",
        "l": "SINNLOS",
        "m": "STIMMEN",
        "n": "STÖREN",
        "o": "VERGEBLICH"
      },
      "answers": {
        "31": {
          "key": "m",
          "note": "Trennbares Verb „zustimmen“ (+ Dativ): „stimmen dieser Behauptung zu“."
        },
        "32": {
          "key": "e",
          "note": "„meinen (= glauben/finden) einer Umfrage zufolge 75 Prozent der Befragten“."
        },
        "33": {
          "key": "h",
          "note": "Feste Präposition: „der Wunsch nach (+ Dativ)“."
        },
        "34": {
          "key": "f",
          "note": "Substantiviertes Adverb: „ein höfliches Miteinander“ (= Zusammenleben)."
        },
        "35": {
          "key": "o",
          "note": "„etwas vergeblich (= umsonst / ohne Erfolg) suchen“."
        },
        "36": {
          "key": "b",
          "note": "Vor Bruchzahlen/Mengenangaben bedeutet „gut“ = „reichlich / etwas mehr als“: „Gut die Hälfte der Deutschen“."
        },
        "37": {
          "key": "g",
          "note": "Modalverb „mögen“ zum Ausdruck einer Möglichkeit/Einräumung: „Während es jüngere Menschen als angenehm empfinden mögen, ...“."
        },
        "38": {
          "key": "n",
          "note": "Reflexivverb: „sich an etwas (+ Dat.) stören“ (= Anstoß nehmen)."
        },
        "39": {
          "key": "c",
          "note": "Feste Wendung: „jemandem den Vortritt lassen“."
        },
        "40": {
          "key": "k",
          "note": "Redewendung: „was sich gehört“ (= was den guten Sitten entspricht)."
        }
      }
    },
    {
      "id": "15",
      "num": "15",
      "page": 432,
      "isVariant": false,
      "title": "Im Restaurant (Benimmregeln beim Essen)",
      "category": "Gastronomie & Etikette",
      "text": "Eine unterhaltsame, schöne und gesellige Zeit. Das stellt man sich unter einem guten Essen vor. Störend wirkt da der anschauliche Erlebnisbericht der letzten Operation im Krankenhaus oder das Klingeln des Handys. Sowohl Gastgeber als auch Gast sollen alles dafür tun, dass das gemeinsame Essen Freude macht. Das Handy stellt man selbstverständlich ab.\n\nDas Essen beginnt, wenn der Gastgeber zur Serviette greift oder zum Gruß sein Glas erhebt. Besonders bei Kindern ein unbeliebtes Thema: die richtige Körperhaltung beim Essen. Die Arme {{31}} nicht auf den Tisch und die Hände nicht unter den Tisch. Man sitzt gerade, ohne unruhig hin und her zu rücken. Die Beine werden nebeneinander gestellt, nicht übereinander gelegt. Die Schuhe {{32}} man in jedem Fall an.\n\nNur keine Angst vor guten Restaurants mit ihrem Luxus! Denn je besser die Küche, umso aufmerksamer ist in der Regel das Personal. Doch schon bei der Anrede der Bedienung steht so {{33}} vor einem Problem. Die Bedienung {{34}} „Fräulein“ an den Tisch zu rufen, ist in Zeiten der Gleichberechtigung veraltet. „Herr Ober“ oder „Bedienung“ ist {{35}} noch möglich, aber auch schon etwas ungewöhnlich. Am besten versucht man, sich Blickkontakt zu verschaffen, um mit einem kleinen {{36}} mit der Hand den Kellner an den Tisch zu bitten.\n\nZudem gibt es zwischen Gast und Service eine Zeichensprache. Schließt der Gast die Speisekarte und legt sie auf den Tisch, ist dies für den Kellner das Signal, die Bestellung aufzunehmen. Ist man mit dem Essen {{37}}, legt man das Besteck parallel nebeneinander auf den rechten Tellerrand. Der Kellner wird dann abräumen. Macht man hingegen nur eine Pause, wird es gekreuzt oder offen auf den Teller gelegt.\n\nBeim Bezahlen ist {{38}} gefragt. Übernimmt ein Gastgeber die Kosten, macht er dies dem Kellner {{39}}. Ein „Bringen Sie mir bitte die Rechnung“ reicht da völlig aus. Möchte man hingegen getrennt bezahlen, {{40}} durchaus üblich ist, teilt man dies ebenfalls rechtzeitig der Bedienung mit. In Deutschland gibt man, je nach Zufriedenheit mit dem Service und der Höhe der Gesamtsumme, zwischen drei und zehn Prozent Trinkgeld. Ist man mit dem Service unzufrieden gewesen, gibt man kein Trinkgeld.",
      "words": {
        "a": "ALS",
        "b": "BEHÄLT",
        "c": "BEREIT",
        "d": "BLEIBT",
        "e": "DAGEGEN",
        "f": "FERTIG",
        "g": "GEHÖREN",
        "h": "JEDER",
        "i": "KLAR",
        "j": "MANCHER",
        "k": "MIT",
        "l": "TAKT",
        "m": "TIPP",
        "n": "WAS",
        "o": "WINK"
      },
      "answers": {
        "31": {
          "key": "g",
          "note": "„Die Arme gehören nicht auf den Tisch“ (= dürfen dort nicht liegen)."
        },
        "32": {
          "key": "b",
          "note": "Trennbares Verb „anbehalten“: „Die Schuhe behält man in jedem Fall an.“"
        },
        "33": {
          "key": "j",
          "note": "Nominativ Singular (Subjekt): „steht so mancher vor einem Problem“."
        },
        "34": {
          "key": "k",
          "note": "„Die Bedienung mit ‚Fräulein‘ an den Tisch zu rufen“."
        },
        "35": {
          "key": "e",
          "note": "Gegensatz: „‚Herr Ober‘ ist dagegen noch möglich, aber ...“."
        },
        "36": {
          "key": "o",
          "note": "„mit einem kleinen Wink mit der Hand“ (= Handzeichen)."
        },
        "37": {
          "key": "f",
          "note": "„Ist man mit dem Essen fertig, ...“."
        },
        "38": {
          "key": "l",
          "note": "„Takt“ (= Feingefühl / Taktgefühl): „Beim Bezahlen ist Takt gefragt.“"
        },
        "39": {
          "key": "i",
          "note": "Trennbares Verb „klarmachen“: „macht er dies dem Kellner klar“."
        },
        "40": {
          "key": "n",
          "note": "Weiterführender Relativsatz (Bezug auf den ganzen Satz): „..., was durchaus üblich ist“."
        }
      }
    },
    {
      "id": "15a",
      "num": "15a",
      "page": 433,
      "isVariant": true,
      "title": "Im Restaurant (Benimmregeln beim Essen – Variante 15a)",
      "category": "Gastronomie & Etikette",
      "text": "Eine unterhaltsame, schöne und gesellige Zeit. Das stellt man sich unter einem guten Essen vor. Störend wirkt da der anschauliche Erlebnisbericht der letzten Operation im Krankenhaus oder das Klingeln des Handys. Sowohl Gastgeber als auch Gast sollen alles dafür tun, dass das gemeinsame Essen Freude macht. Das Handy stellt man selbstverständlich ab.\n\nDas Essen beginnt, wenn der Gastgeber zur Serviette greift oder zum Gruß sein Glas erhebt. Besonders bei Kindern ein unbeliebtes Thema: die richtige Körperhaltung beim Essen. Die Arme {{31}} nicht auf den Tisch und die Hände nicht unter den Tisch. Man sitzt gerade, ohne unruhig hin und her zu rücken. Die Beine werden nebeneinander gestellt, nicht übereinander gelegt. Die Schuhe {{32}} man in jedem Fall an.\n\nNur keine Angst vor guten Restaurants mit ihrem Luxus! Denn je besser die Küche, umso aufmerksamer ist in der Regel das Personal. Doch schon die korrekte Anrede der Bedienung bereitet so {{33}} Probleme. Die Bedienung {{34}} der Anrede „Fräulein“ an den Tisch zu rufen, ist in Zeiten der Gleichberechtigung veraltet. „Herr Ober“ oder „Bedienung“ ist {{35}} zwar korrekt, aber in der Zwischenzeit auch eher unüblich. Am besten versucht man, sich Blickkontakt zu verschaffen, um mit einem kleinen {{36}} mit der Hand den Kellner an den Tisch zu bitten.\n\nZudem gibt es zwischen Gast und Service eine Zeichensprache. Schließt der Gast die Speisekarte und legt sie auf den Tisch, ist dies für den Kellner das Signal, die Bestellung aufzunehmen. Wenn man mit dem Essen {{37}} ist, platziert man das Besteck parallel nebeneinander auf den rechten Tellerrand. Der Kellner wird dann abräumen. Macht man hingegen nur eine Pause, wird es gekreuzt oder offen auf den Teller gelegt.\n\nBeim Bezahlen ist {{38}} wichtig: Wenn einer der Gäste die Kosten übernehmen möchte, macht er dies dem Kellner {{39}}. Ein „Bringen Sie mir bitte die Rechnung“ reicht da völlig aus. Möchte man hingegen getrennt bezahlen, {{40}} durchaus üblich ist, teilt man dies am besten rechtzeitig der Bedienung mit. In Deutschland gibt man, je nach Zufriedenheit mit dem Service und der Höhe der Gesamtsumme, zwischen drei und zehn Prozent Trinkgeld. Ist man mit dem Service unzufrieden gewesen, gibt man kein Trinkgeld.",
      "words": {
        "a": "ALS",
        "b": "BEHÄLT",
        "c": "BEREIT",
        "d": "BLEIBT",
        "e": "DAGEGEN",
        "f": "FERTIG",
        "g": "GEHÖREN",
        "h": "JEDER",
        "i": "KLAR",
        "j": "MANCHEM",
        "k": "MIT",
        "l": "TAKTGEFÜHL",
        "m": "TIPP",
        "n": "WAS",
        "o": "WINK"
      },
      "answers": {
        "31": {
          "key": "g",
          "note": "„Die Arme gehören nicht auf den Tisch“."
        },
        "32": {
          "key": "b",
          "note": "„Die Schuhe behält man in jedem Fall an.“"
        },
        "33": {
          "key": "j",
          "note": "jemandem (Dativ) Probleme bereiten: „bereitet so manchem Probleme“."
        },
        "34": {
          "key": "k",
          "note": "„mit der Anrede ‚Fräulein‘“."
        },
        "35": {
          "key": "e",
          "note": "„ist dagegen zwar korrekt, aber ...“."
        },
        "36": {
          "key": "o",
          "note": "„mit einem kleinen Wink mit der Hand“."
        },
        "37": {
          "key": "f",
          "note": "„Wenn man mit dem Essen fertig ist“."
        },
        "38": {
          "key": "l",
          "note": "„Beim Bezahlen ist Taktgefühl wichtig“."
        },
        "39": {
          "key": "i",
          "note": "„macht er dies dem Kellner klar“."
        },
        "40": {
          "key": "n",
          "note": "„..., was durchaus üblich ist“."
        }
      }
    },
    {
      "id": "16",
      "num": "16",
      "page": 434,
      "isVariant": false,
      "title": "Online-Sprachkurse & Co. – Wie lernt man heute am besten eine Sprache?",
      "category": "Sprachenlernen & Medien",
      "text": "Es gibt inzwischen zahlreiche Online-Sprachkurse und {{31}} mit Smartphones kann man Sprachen lernen. Eine weitere Lernmöglichkeit ist zum Beispiel eine Tandem-Partnerschaft {{32}} einem Muttersprachler. Welche Vorteile und Nachteile haben die unterschiedlichen Methoden?\n\nEs gibt inzwischen zahlreiche Online-Lernportale, die leicht zu überblicken und zu bedienen sind. Der Vorteil: Man kann die Wörter nicht nur lesen, {{33}} gleichzeitig auch hören. Außerdem kann man Wörter nachsprechen, {{34}} dass ein ganzer Kurs zuhört. Auch Lerntipps bekommt man bei Online-Portalen, beispielsweise diesen: Vokabeln sollte man lieber mehrmals täglich in Fünf-Minuten-Blöcken wiederholen, {{35}} sie in einer Stunde alle auf einmal zu lernen.\n\nWer auch unterwegs lernen möchte, kann es mit einer Smartphone-App versuchen, einem kleinen Programm, das auf dem Handy läuft. Viele Programme gibt es kostenlos, andere kosten zwischen einem und mehreren Euro. Die kleinen Helfer sind {{36}} gut zum Vokabellernen geeignet – mehr aber meist nicht. Das spielerische Vokabeltraining macht zwar Spaß, {{37}} Satzbau oder andere Grammatikthemen werden allenfalls kurz angesprochen. Ein richtiges Gespräch kann man mit dieser Methode erst recht nicht üben. Dafür {{38}} man besser in einen Kurs gehen oder einen Tandem-Partner suchen.\n\nEin Tandem-Partner ist ein Muttersprachler, der die Grammatik erklärt, die Aussprache verbessert und seinerseits die Muttersprache des anderen lernen möchte. Der schnellste Weg, {{39}} einen passenden Tandem-Partner zu finden, ist die Online-Suche: Muttersprache, Zielsprache und Wohnort eingeben, {{40}} werden alle Treffer angezeigt. Man trifft sich beispielsweise in einem Restaurant, schickt sich Nachrichten oder E-Mails und erklärt sich gegenseitig die eigene Sprache.",
      "words": {
        "a": "ABER",
        "b": "ANSTATT",
        "c": "BESONDERS",
        "d": "FÜR",
        "e": "KAUM",
        "f": "MIT",
        "g": "MÜSSTE",
        "h": "OHNE",
        "i": "SCHON",
        "j": "SO",
        "k": "SOGAR",
        "l": "SOLLTE",
        "m": "SONDERN",
        "n": "UM",
        "o": "VON"
      },
      "answers": {
        "31": {
          "key": "k",
          "note": "Fokuspartikel: „und sogar mit Smartphones kann man Sprachen lernen“."
        },
        "32": {
          "key": "f",
          "note": "„eine Tandem-Partnerschaft mit einem Muttersprachler“."
        },
        "33": {
          "key": "m",
          "note": "„nicht nur lesen, sondern gleichzeitig auch hören“."
        },
        "34": {
          "key": "h",
          "note": "Modalsatz: „ohne dass ein ganzer Kurs zuhört“."
        },
        "35": {
          "key": "b",
          "note": "Infinitivkonstruktion: „anstatt sie in einer Stunde alle auf einmal zu lernen“."
        },
        "36": {
          "key": "c",
          "note": "Gradpartikel vor „gut“: „sind besonders gut zum Vokabellernen geeignet“."
        },
        "37": {
          "key": "a",
          "note": "Konzessive Struktur: „zwar ..., aber Satzbau ... werden allenfalls kurz angesprochen“."
        },
        "38": {
          "key": "l",
          "note": "Empfehlung mit „besser“: „Dafür sollte man besser in einen Kurs gehen.“"
        },
        "39": {
          "key": "n",
          "note": "Finalsatz mit Infinitiv: „Der schnellste Weg, um einen passenden Tandem-Partner zu finden“."
        },
        "40": {
          "key": "i",
          "note": "Unmittelbare Folge: „Muttersprache ... eingeben, schon werden alle Treffer angezeigt.“"
        }
      }
    },
    {
      "id": "17",
      "num": "17",
      "page": 435,
      "isVariant": false,
      "title": "Liebesgrüße aus der Kühltruhe",
      "category": "Alltag, Ernährung & Psychologie",
      "text": "Wer sich einen Mann angeln will, sollte einen Blick in dessen Tiefkühlfach werfen. Einer Studie zufolge kann man {{31}} des Inhalts des Tiefkühlfachs den Charakter seines Besitzers erkennen. Die Meinungsforscher unterscheiden fünf Kategorien {{32}} Single-Männern: den spontanen Typ, den Bequemen, den Kreativen {{33}} den Cocktail- und den Gourmet-Typen. Am häufigsten gibt es in Deutschland den spontanen Typ. Er hat neben kompletten Gerichten auch tiefgekühlte Produkte wie Brokkoligemüse oder Putenfilet in der Truhe, {{34}} denen er eine Mahlzeit zusammenstellen kann. Dieser Typ liebt die Abwechslung auf dem Teller und auch sonst im Leben. Da wird es vermutlich auch in der Liebe nicht langweilig.\n\nHauptgewinn für jede Frau ist aber der Gourmet-Typ. In seinem Tiefkühlfach liegen Produkte wie Garnelen, Muscheln oder Ente. Dieser Typ liebt es, Frauen zu verwöhnen. Der Nachteil liegt {{35}} der Hand: Dieser Typ Single-Mann ist selten.\n\nWas man in der Tiefkühltruhe von bequemen Single-Männern findet, kann man leicht erraten, denn diese Männer haben gar keine Lust zu kochen. Ihnen ist es sogar zu {{36}}, zwei Tüten zu öffnen statt nur einer. {{37}} kaufen diese Männer am häufigsten komplette Gerichte, die sie nur noch in die Mikrowelle oder den Backofen stellen müssen. Aber ob sie so das Herz einer Frau erobern können? Zumindest Frauen sehen das wohl {{38}} skeptisch.\n\nDoch egal, {{39}} welcher Kategorie ein Mann gehört – eines haben alle gemeinsam: Sie kaufen immer mehr Tiefkühlkost. Warum das so ist, kann die Studie nicht beantworten – da kann man nur raten: Einige haben vermutlich wenig Zeit zum Kochen, andere {{40}} eher keine Lust. Dabei wäre das doch der beste Weg, um eine Frau zu erobern.",
      "words": {
        "a": "ANHAND",
        "b": "ANSTRENGEND",
        "c": "AUF",
        "d": "AUS",
        "e": "EHER",
        "f": "FAST",
        "g": "FOLGLICH",
        "h": "HIN",
        "i": "KAUM",
        "j": "LANGWEILIG",
        "k": "SOWIE",
        "l": "VON",
        "m": "WEGEN",
        "n": "WOHL",
        "o": "ZU"
      },
      "answers": {
        "31": {
          "key": "a",
          "note": "Präposition mit Genitiv: „anhand des Inhalts“."
        },
        "32": {
          "key": "l",
          "note": "„fünf Kategorien von Single-Männern“."
        },
        "33": {
          "key": "k",
          "note": "Aufzählung: „den spontanen Typ, den Bequemen, den Kreativen sowie den Cocktail- und den Gourmet-Typen“."
        },
        "34": {
          "key": "d",
          "note": "etwas zusammenstellen aus (+ Dativ): „aus denen er eine Mahlzeit zusammenstellen kann“."
        },
        "35": {
          "key": "c",
          "note": "Feste Redewendung: „auf der Hand liegen“ (= offensichtlich sein)."
        },
        "36": {
          "key": "b",
          "note": "Für „bequeme“ Männer ist es „zu anstrengend, zwei Tüten zu öffnen“."
        },
        "37": {
          "key": "g",
          "note": "Konsekutives Adverb: „Folglich (= Daher) kaufen diese Männer ...“."
        },
        "38": {
          "key": "e",
          "note": "„sehen das wohl eher skeptisch“."
        },
        "39": {
          "key": "o",
          "note": "Feste Präposition: „gehören zu (+ Dativ)“ -> „zu welcher Kategorie ein Mann gehört“."
        },
        "40": {
          "key": "n",
          "note": "Vermutungspartikel: „andere wohl eher keine Lust“."
        }
      }
    },
    {
      "id": "17a",
      "num": "17a",
      "page": 436,
      "isVariant": true,
      "title": "Liebesgrüße aus der Kühltruhe (Variante 17a)",
      "category": "Alltag, Ernährung & Psychologie",
      "text": "Wer sich einen Mann angeln will, sollte einen Blick in dessen Tiefkühlfach werfen. Einer Studie {{31}} kann man anhand des Inhalts des Tiefkühlfachs den Charakter seines Besitzers erkennen. Die Meinungsforscher unterscheiden fünf Kategorien {{32}} Single-Männern: den spontanen Typ, den Bequemen, den Kreativen sowie den Cocktail- und den Gourmet-Typen. Am häufigsten gibt es in Deutschland den spontanen Typ. Er hat neben kompletten Gerichten auch tiefgekühlte Produkte wie Brokkoligemüse oder Putenfilet in der Truhe, aus denen er eine Mahlzeit zusammenstellen kann. Dieser Typ liebt die Abwechslung auf dem Teller und auch sonst im Leben. Da wird es vermutlich auch in der Liebe nicht langweilig.\n\nHauptgewinn für {{33}} Frau ist aber der Gourmet-Typ. In seinem Tiefkühlfach liegen Produkte wie Garnelen, Muscheln oder Ente. Dieser Typ liebt es, Frauen {{34}} verwöhnen. Der Nachteil liegt {{35}} der Hand: Dieser Typ Single-Mann ist selten.\n\nWas man in der Tiefkühltruhe von bequemen Single-Männern findet, kann man leicht erraten, denn diese Männer haben gar keine Lust zu kochen. Ihnen ist es sogar zu {{36}}, zwei Tüten zu öffnen statt nur einer. {{37}} kaufen diese Männer am häufigsten komplette Gerichte, die sie nur noch in die Mikrowelle oder den Backofen stellen müssen. Aber {{38}} sie so das Herz einer Frau erobern können? Zumindest Frauen sehen das wohl eher skeptisch.\n\nDoch egal, zu welcher Kategorie ein Mann gehört – eines haben alle gemeinsam: Sie kaufen immer mehr Tiefkühlkost. Warum das so ist, kann die Studie nicht beantworten – da kann man nur raten: Einige haben {{39}} wenig Zeit zum Kochen, andere {{40}} eher keine Lust. Dabei wäre das doch der beste Weg, um eine Frau zu erobern.",
      "words": {
        "a": "ZUFOLGE",
        "b": "ANSTRENGEND",
        "c": "AUF",
        "d": "ZU",
        "e": "OB",
        "f": "FAST",
        "g": "FOLGLICH",
        "h": "HIN",
        "i": "KAUM",
        "j": "LANGWEILIG",
        "k": "JEDE",
        "l": "VON",
        "m": "WEGEN",
        "n": "WOHL",
        "o": "VERMUTLICH"
      },
      "answers": {
        "31": {
          "key": "a",
          "note": "Nachgestellte Präposition mit Dativ: „Einer Studie zufolge“."
        },
        "32": {
          "key": "l",
          "note": "„fünf Kategorien von Single-Männern“."
        },
        "33": {
          "key": "k",
          "note": "„Hauptgewinn für jede Frau“."
        },
        "34": {
          "key": "d",
          "note": "Infinitiv mit „zu“ nach „liebt es, Frauen zu verwöhnen“."
        },
        "35": {
          "key": "c",
          "note": "„liegt auf der Hand“."
        },
        "36": {
          "key": "b",
          "note": "„zu anstrengend“."
        },
        "37": {
          "key": "g",
          "note": "„Folglich kaufen diese Männer ...“."
        },
        "38": {
          "key": "e",
          "note": "Selbstständiger ob-Fragesatz (Zweifel): „Aber ob sie so das Herz einer Frau erobern können?“"
        },
        "39": {
          "key": "o",
          "note": "„Einige haben vermutlich wenig Zeit zum Kochen“."
        },
        "40": {
          "key": "n",
          "note": "„andere wohl eher keine Lust“."
        }
      }
    },
    {
      "id": "17b",
      "num": "17b",
      "page": 437,
      "isVariant": true,
      "title": "Liebesgrüße aus der Kühltruhe (Variante 17b)",
      "category": "Alltag, Ernährung & Psychologie",
      "text": "Wer sich einen Mann angeln will, sollte einen Blick in dessen Tiefkühlfach werfen. Einer Studie {{31}} kann man anhand des Inhalts des Tiefkühlfachs den Charakter seines Besitzers erkennen. Die Meinungsforscher unterscheiden fünf Kategorien {{32}} Single-Männern: den spontanen Typ, den Bequemen, den Kreativen {{33}} den Cocktail- und den Gourmet-Typen. Am häufigsten gibt es in Deutschland den spontanen Typ. Er hat neben kompletten Gerichten auch tiefgekühlte Produkte wie Brokkoligemüse oder Putenfilet in der Truhe, aus {{34}} er eine Mahlzeit zusammenstellen kann. Dieser Typ liebt die Abwechslung auf dem Teller und auch sonst im Leben. Da wird es vermutlich auch in der Liebe nicht langweilig.\n\nHauptgewinn für {{35}} Frau ist aber der Gourmet-Typ. In seinem Tiefkühlfach liegen Produkte wie Garnelen, Muscheln oder Ente. Dieser Typ liebt es, Frauen zu verwöhnen. Der Nachteil liegt auf der Hand: Dieser Typ Single-Mann ist selten.\n\nWas man in der Tiefkühltruhe von bequemen Single-Männern findet, kann man leicht erraten, denn diese Männer haben gar keine Lust zu kochen. Ihnen ist es sogar zu {{36}}, zwei Tüten zu öffnen statt nur einer. {{37}} kaufen diese Männer am häufigsten komplette Gerichte, die sie nur noch in die Mikrowelle oder den Backofen stellen müssen. Aber {{38}} sie so das Herz einer Frau erobern können? Zumindest Frauen sehen das wohl eher skeptisch.\n\nDoch egal, {{39}} welcher Kategorie ein Mann gehört – eines haben alle gemeinsam: Sie kaufen immer mehr Tiefkühlkost. Warum das so ist, kann die Studie nicht beantworten – da kann man nur raten: Einige haben {{40}} wenig Zeit zum Kochen, andere wohl eher keine Lust. Dabei wäre das doch der beste Weg, um eine Frau zu erobern.",
      "words": {
        "a": "ZUFOLGE",
        "b": "ANSTRENGEND",
        "c": "AUF",
        "d": "VERMUTLICH",
        "e": "JEDE",
        "f": "FAST",
        "g": "FOLGLICH",
        "h": "HIN",
        "i": "OB",
        "j": "LANGWEILIG",
        "k": "SOWIE",
        "l": "VON",
        "m": "WEGEN",
        "n": "DENEN",
        "o": "ZU"
      },
      "answers": {
        "31": {
          "key": "a",
          "note": "„Einer Studie zufolge“."
        },
        "32": {
          "key": "l",
          "note": "„fünf Kategorien von Single-Männern“."
        },
        "33": {
          "key": "k",
          "note": "„sowie den Cocktail- und den Gourmet-Typen“."
        },
        "34": {
          "key": "n",
          "note": "Relativpronomen im Dativ Plural nach „aus“: „aus denen er eine Mahlzeit zusammenstellen kann“."
        },
        "35": {
          "key": "e",
          "note": "„Hauptgewinn für jede Frau“."
        },
        "36": {
          "key": "b",
          "note": "„zu anstrengend“."
        },
        "37": {
          "key": "g",
          "note": "„Folglich kaufen diese Männer ...“."
        },
        "38": {
          "key": "i",
          "note": "„Aber ob sie so das Herz einer Frau erobern können?“"
        },
        "39": {
          "key": "o",
          "note": "„zu welcher Kategorie ein Mann gehört“."
        },
        "40": {
          "key": "d",
          "note": "„Einige haben vermutlich wenig Zeit zum Kochen“."
        }
      }
    },
    {
      "id": "18",
      "num": "18",
      "page": 438,
      "isVariant": false,
      "title": "Man(n) kocht selbst",
      "category": "Alltag & Gesellschaft",
      "text": "Selbst ist der Mann. Von der Wahrheit dieser alten deutschen Redewendung haben Frauen Generationen lang geträumt, wenn es um typische Hausarbeiten wie Waschen, Putzen oder Kochen ging. Zumindest bei Letzterem scheint sich jedoch in den letzten Jahren vieles zu ändern. {{31}} immer mehr Männer in Deutschland greifen jetzt selbst zum Kochtopf. Ein Grund {{32}} diese Entwicklung mag sein, dass es immer mehr Ein-Personen-Haushalte in Deutschland gibt. Es ist einfach niemand anderes da, der die Kocharbeit übernehmen könnte. Und Hunger zwingt bekanntlich zum Handeln.\n\nAndererseits ist das Kochen inzwischen ein allgemein akzeptiertes Hobby geworden, besonders unter Männern. Doch welch ein Unterschied besteht {{33}} den Ansprüchen einer traditionellen Hausfrau und denen eines Hobbykochs, was die Ausstattung der Küche angeht! Nicht {{34}} Topf darf es für den selbsternannten Drei-Sterne-Küchenchef sein: Gebürsteter Edelstahl mit versiegelter Antihaftbeschichtung und integrierter digitaler Temperaturanzeige ist der Mindeststandard für einen echten kochenden Mann. Alles andere gilt als stillos.\n\nDie zweite Voraussetzung {{35}}, dass die Gerichte auch gelingen, ist das Wissen, wie man welche Speise am besten zubereitet. Zu diesem Zweck bieten die Buchhandlungen Berge von Kochbüchern an mit Rezepten von Alaska bis Zimbabwe, mit oder ohne Fleisch, für zu Dicke und zu Dünne. Jetzt hängt es nur noch {{36}} ab, was der Hobbykoch aus den Kochideen der Buchautoren macht. Wird es ein exzellentes Mahl oder wäre unser „Chefkoch“ nicht doch lieber zum Dönerstand um die Ecke gegangen? Überraschungen gehören zum Kochen dazu.\n\nHelfen die Bücher nicht {{37}}, bieten zum Beispiel die Volkshochschulen zahlreiche Kochkurse an, die in der Regel – zumeist von kochwilligen Männern – gut besucht sind. Das Kursangebot umfasst neben deutscher Hausmannskost wie Schnitzel, Krautwickel oder Rinderbraten zumeist auch die mediterrane und die asiatische Küche. Das führt {{38}}, dass man(n) zu Hause immer öfter international kocht.\n\nDas größte Problem der Hobbyköche ist aber, {{39}} es viel zu aufwändig ist, für sich alleine zu kochen. Daher sind zurzeit Internetseiten wie www.allein-kochen-ist-doof.de beliebt, wo sich Hobbyköche und -köchinnen Kochpartner für das gemeinsame Kochen und Essen suchen können. Das Interessante {{40}} ist, dass dabei unsere männlichen Chefköche feststellen müssen, dass es andere Menschen gibt, die mit vielleicht weniger Aufwand genauso gut ein Festmahl zubereiten können wie sie: nämlich die Frauen.",
      "words": {
        "a": "DAFÜR",
        "b": "DAHER",
        "c": "DAMIT",
        "d": "DARAN",
        "e": "DASS",
        "f": "DAVON",
        "g": "DAZU",
        "h": "DENN",
        "i": "FÜR",
        "j": "GEGEN",
        "k": "IRGENDEIN",
        "l": "WAS",
        "m": "WEITER",
        "n": "ZU",
        "o": "ZWISCHEN"
      },
      "answers": {
        "31": {
          "key": "h",
          "note": "Kausale Hauptsatzkonjunktion auf Position 0: „Denn immer mehr Männer greifen jetzt selbst zum Kochtopf.“"
        },
        "32": {
          "key": "i",
          "note": "Feste Präposition: „Ein Grund für (+ Akkusativ)“."
        },
        "33": {
          "key": "o",
          "note": "„ein Unterschied zwischen X und Y“."
        },
        "34": {
          "key": "k",
          "note": "Indefinitpronomen Nominativ Maskulinum: „Nicht irgendein (= ein beliebiger) Topf darf es sein“."
        },
        "35": {
          "key": "a",
          "note": "Voraussetzung für -> Pronominaladverb „Die zweite Voraussetzung dafür, dass ...“."
        },
        "36": {
          "key": "f",
          "note": "abhängen von -> Pronominaladverb „Jetzt hängt es nur noch davon ab, was ...“."
        },
        "37": {
          "key": "m",
          "note": "Trennbares Verb „weiterhelfen“: „Helfen die Bücher nicht weiter, ...“."
        },
        "38": {
          "key": "g",
          "note": "führen zu -> Pronominaladverb „Das führt dazu, dass ...“."
        },
        "39": {
          "key": "e",
          "note": "Prädikativer dass-Satz: „Das größte Problem ist aber, dass ...“."
        },
        "40": {
          "key": "d",
          "note": "Feste Verbindung: „Das Interessante daran (= an dieser Sache) ist, dass ...“."
        }
      }
    },
    {
      "id": "19",
      "num": "19",
      "page": 439,
      "isVariant": false,
      "title": "Der Hund als intelligentes Wesen",
      "category": "Wissenschaft & Verhaltensforschung",
      "text": "Hunde sind beliebte Begleiter vieler Menschen. Gerade in den Großstädten Deutschlands und Österreichs gibt es eine große Anzahl an Hundebesitzern, die das Tier als Freund, manchmal sogar als Helfer schätzen. Bislang galt die Auffassung, Hunde seien zwar treu, aber {{31}} ihre Intelligenz betrifft, eher mit geringen Begabungen ausgestattet. Doch {{32}} haben wissenschaftliche Experimente {{33}} der Universität Wien und am Max-Planck-Institut in Leipzig die Hundeehre gerettet und bewiesen: Der Hund ist ein außerordentlich intelligentes Lebewesen und kommt in einer Vielzahl von Strategien, die er anwendet, an menschliche Denkmuster durchaus heran.\n\nFriederike Range von der Universität Wien setzte ihren Hund vor einen Computer. Der Hund sollte {{34}} verschiedenen Bildern, von denen jeweils zwei auf dem Monitor zu sehen waren, das richtige auswählen und {{35}} entweder einen Menschen oder eine Landschaft erkennen. Der Monitor war mit einem Touchscreen ausgestattet, {{36}} der Hund mit der Schnauze auf das jeweils richtige Bild tippen konnte. Lag er richtig, bekam er ein Stück Trockenfutter als Belohnung, lag er falsch, wurde der Bildschirm kurz rot und zeigte gleich im Anschluss das nächste Bilderpaar.\n\nDas Ergebnis war verblüffend. Der Hund hing {{37}} mit einer ähnlichen Begeisterung und Ausdauer am Bildschirm wie manch Jugendlicher an der Playstation, sondern er war auch bei seinen Entscheidungen äußerst treffsicher. Die Leipziger Forscherin Juliane Kaminski setzte ihren Hund vor zwei Gefäße, von {{38}} eins Futter enthielt, das andere nicht. Danach schaute sie in die Richtung des Behälters, in dem das Fleischstück lag. Der Hund beobachtete sie dabei und interpretierte die menschliche Mimik richtig.\n\nDasselbe Experiment wurde mit dem gleichen Ergebnis mit Hundebabys wiederholt. Daraus schließen die Forscher in Leipzig, {{39}} bestimmte Muster menschlicher Gestik und Mimik von den Hunden sehr treffsicher interpretiert werden können und diese Fähigkeiten bereits seit langem bei Hunden vorhanden sein müssen. Man kann also mit Recht annehmen, dass die Interpretationsfähigkeit menschlicher Mimik und Gestik bei den Hunden genetisch verankert ist. Ähnliche Experimente mit Wölfen, die als die Vorfahren des Haushundes gelten, brachten {{40}} vergleichbaren Resultate. Ein weiterer Beweis also dafür, dass der Hund diese Fähigkeiten gelernt und verinnerlicht haben muss.",
      "words": {
        "a": "AN",
        "b": "AUS",
        "c": "DARAUF",
        "d": "DAS",
        "e": "DASS",
        "f": "DEM",
        "g": "DENEN",
        "h": "JETZT",
        "i": "KEINE",
        "j": "NICHT NUR",
        "k": "SO DASS",
        "l": "ÜBRIGENS",
        "m": "WAS",
        "n": "WELCHE",
        "o": "ZU"
      },
      "answers": {
        "31": {
          "key": "m",
          "note": "Feste Wendung: „was ihre Intelligenz betrifft“."
        },
        "32": {
          "key": "h",
          "note": "Gegensatz zu „Bislang“: „Doch jetzt haben wissenschaftliche Experimente ... bewiesen“."
        },
        "33": {
          "key": "a",
          "note": "Präposition bei Universitäten: „an der Universität Wien“."
        },
        "34": {
          "key": "b",
          "note": "etwas auswählen aus (+ Dativ): „aus verschiedenen Bildern das richtige auswählen“."
        },
        "35": {
          "key": "c",
          "note": "„darauf (= auf dem Bild) entweder einen Menschen oder eine Landschaft erkennen“."
        },
        "36": {
          "key": "k",
          "note": "Konsekutivsatz: „..., so dass der Hund ... tippen konnte“."
        },
        "37": {
          "key": "j",
          "note": "Korrespondierend mit „sondern ... auch“: „nicht nur ..., sondern auch ...“."
        },
        "38": {
          "key": "g",
          "note": "Relativpronomen im Dativ Plural nach „von“ („zwei Gefäße, von denen eins ...“)."
        },
        "39": {
          "key": "e",
          "note": "Objektsatz nach „schließen, dass ...“."
        },
        "40": {
          "key": "i",
          "note": "Verneinung im Plural: „brachten keine vergleichbaren Resultate“."
        }
      }
    },
    {
      "id": "20",
      "num": "20",
      "page": 440,
      "isVariant": false,
      "title": "Deutschland – ein Paradies für Kinder?",
      "category": "Gesellschaft & Familie",
      "text": "17 Millionen Kinder leben in Deutschland. Verglichen {{31}} der Bevölkerungszahl von ungefähr 80 Millionen ist das fast ein Viertel der Einwohner. Doch nur für jedes zehnte Kind unter drei Jahren steht ein Betreuungsplatz in einer Kindertagesstätte zur Verfügung. Die Folge: Nur etwas mehr als die Hälfte der Mütter dieser Kinder ist berufstätig – und nur ein Viertel kann ganztägig zur Arbeit gehen.\n\nUm dem entgegenzuwirken, gibt es in Deutschland die dreijährige Elternzeit, die es einem Elternteil ermöglichen soll, drei Jahre {{32}} dem Kind zu Hause zu bleiben. {{33}} hat den Vorteil, dass der zu Hause bleibende Elternteil seinen Arbeitsplatz nicht verliert. Dennoch wird die Elternzeit für viele Eltern in finanzieller Hinsicht zu einem gravierenden Problem. Außerdem gilt die Elternzeit nur für Angestellte. Mütter zum Beispiel, die vor der Geburt ihres Kindes selbständig waren und mit dem Baby zu Hause bleiben wollen, stehen weit schlechter da. Kind und Karriere zu vereinbaren ist daher in Deutschland für die meisten Mütter so gut wie unmöglich. Dies scheinen die Hauptgründe {{34}} zu sein, warum in Deutschland zurzeit weltweit die wenigsten Kinder geboren werden.\n\nDoch auch andere Dinge machen Familien mit Kindern in Deutschland das Leben schwer: In Restaurants zum Beispiel sind Kinder selten willkommen. Sie sitzen eben nicht still am Tisch, {{35}} stören mit ihrem Lachen und lauten Sprechen die anderen (kinderlosen) Gäste. Bei den kinderlosen Erwachsenen werden andere Maßstäbe angelegt. {{36}} diese selbst häufig lautstark telefonieren, stört das niemanden: Telefonate sind eben wichtiger als Kinder. In zahlreichen deutschen Städten wie Mainz strengen Anwohner Prozesse gegen Kindergärten und Spielplätze an, {{37}} die Kinder die Ruhe der benachbarten (kinderlosen) Hausbewohner stören. Die Folge: Spielplätze werden von Gerichts wegen geschlossen. An Wiesen, auf denen früher Kinder tobten und Ball spielten, stehen nun Schilder: Betreten und Spielen verboten. Bei Zuwiderhandlung drohen Geldstrafen.\n\nEltern, die mit der Deutschen Bahn mit ihren Kindern verreisen möchten, haben schlechte Karten. In den meisten Zügen sind die Gänge so angeordnet, {{38}} mit einem Kinderwagen kein Durchkommen ist. Und in den Mutter-Kind-Abteilen haben sich schon andere Reisende breitgemacht, die nicht einsehen, warum sie Müttern mit Kind Platz machen sollten. Schließlich hätten sie ja eine Fahrkarte gekauft und damit Anspruch {{39}} einen Platz. In vielen Berichten in Zeitungen oder im Fernsehen, die sich mit Kindern, ihrer Erziehung oder mit dem Schulsystem befassen, spricht man in Deutschland gerne {{40}} „Problemen“. Man meint damit die Kinder. Kann eine Gesellschaft, in der ein Kind als ein Problemfall angesehen wird, ein Paradies für Kinder sein?",
      "words": {
        "a": "AUF",
        "b": "BEI",
        "c": "DABEI",
        "d": "DAFÜR",
        "e": "DAS",
        "f": "DASS",
        "g": "DAVON",
        "h": "DENNOCH",
        "i": "DOCH",
        "j": "JEDOCH",
        "k": "MIT",
        "l": "OBWOHL",
        "m": "SONDERN",
        "n": "VON",
        "o": "WEIL"
      },
      "answers": {
        "31": {
          "key": "k",
          "note": "vergleichen mit (+ Dativ): „Verglichen mit der Bevölkerungszahl“."
        },
        "32": {
          "key": "b",
          "note": "„drei Jahre bei dem Kind zu Hause zu bleiben“."
        },
        "33": {
          "key": "e",
          "note": "Demonstrativpronomen als Satzsubjekt: „Das hat den Vorteil, dass ...“."
        },
        "34": {
          "key": "d",
          "note": "Gründe für -> Pronominaladverb „die Hauptgründe dafür, warum ...“."
        },
        "35": {
          "key": "m",
          "note": "Gegensatz nach „nicht“: „Sie sitzen nicht still am Tisch, sondern stören ...“."
        },
        "36": {
          "key": "l",
          "note": "Konzessivsatz: „Obwohl diese selbst häufig lautstark telefonieren, stört das niemanden.“"
        },
        "37": {
          "key": "o",
          "note": "Kausalsatz: „..., weil die Kinder die Ruhe ... stören“."
        },
        "38": {
          "key": "f",
          "note": "Konsekutivsatz nach „so angeordnet“: „..., dass mit einem Kinderwagen kein Durchkommen ist“."
        },
        "39": {
          "key": "a",
          "note": "Feste Präposition: „Anspruch auf (+ Akkusativ) haben“."
        },
        "40": {
          "key": "n",
          "note": "sprechen von (+ Dativ): „spricht man gerne von ‚Problemen‘“."
        }
      }
    },
    {
      "id": "20a",
      "num": "20a",
      "page": 441,
      "isVariant": true,
      "title": "Deutschland – ein Paradies für Kinder? (Variante 20a)",
      "category": "Gesellschaft & Familie",
      "text": "17 Millionen Kinder leben in Deutschland. Verglichen mit der Bevölkerungszahl von ungefähr 80 Millionen ist das fast ein Viertel der Einwohner. Doch nur für jedes zehnte Kind unter drei Jahren steht ein Betreuungsplatz in einer Kindertagesstätte {{31}} Verfügung. Die Folge: Nur etwas mehr als die Hälfte der Mütter dieser Kinder ist berufstätig – und nur ein Viertel kann ganztägig zur Arbeit gehen.\n\nUm dem entgegenzuwirken, gibt es in Deutschland die dreijährige Elternzeit, die es einem Elternteil ermöglichen soll, drei Jahre {{32}} dem Kind zu Hause zu bleiben. {{33}} hat den Vorteil, dass der zu Hause bleibende Elternteil seinen Arbeitsplatz nicht verliert. {{34}} wird die Elternzeit für viele Eltern in finanzieller Hinsicht zu einem gravierenden Problem. Außerdem gilt die Elternzeit nur für Angestellte. Mütter zum Beispiel, die vor der Geburt ihres Kindes selbständig waren und mit dem Baby zu Hause bleiben wollen, stehen weit schlechter da. Kind und Karriere zu vereinbaren ist daher in Deutschland für die meisten Mütter so gut wie unmöglich. Dies scheinen die Hauptgründe dafür zu sein, warum in Deutschland zurzeit weltweit die wenigsten Kinder geboren werden.\n\n{{35}} auch andere Dinge machen Familien mit Kindern in Deutschland das Leben schwer: In Restaurants zum Beispiel sind Kinder selten willkommen. Sie sitzen eben nicht still am Tisch, {{36}} stören mit ihrem Lachen und lauten Sprechen die anderen (kinderlosen) Gäste. Bei den kinderlosen Erwachsenen werden andere Maßstäbe angelegt. Obwohl diese selbst häufig lautstark telefonieren, stört das {{37}}: Telefonate sind eben wichtiger als Kinder. In zahlreichen deutschen Städten wie Mainz strengen Anwohner Prozesse gegen Kindergärten und Spielplätze an, {{38}} die Kinder die Ruhe der benachbarten (kinderlosen) Hausbewohner stören. Die Folge: Spielplätze werden von Gerichts wegen geschlossen. An Wiesen, auf denen früher Kinder tobten und Ball spielten, stehen nun Schilder: Betreten und Spielen verboten. Bei Zuwiderhandlung drohen Geldstrafen.\n\nEltern, die mit der Deutschen Bahn mit ihren Kindern reisen möchten, haben schlechte Karten. In den meisten Zügen sind die Gänge so angeordnet, {{39}} mit einem Kinderwagen kein Durchkommen ist. Und in den Mutter-Kind-Abteilen haben sich schon andere Reisende breitgemacht, die nicht einsehen, warum sie Müttern mit Kind Platz machen sollten. Schließlich hätten sie ja eine Fahrkarte gekauft und damit Anspruch {{40}} einen Platz. In vielen Berichten in Zeitungen oder im Fernsehen, die sich mit Kindern, ihrer Erziehung oder mit dem Schulsystem befassen, spricht man in Deutschland gern von „Problemen“. Man meint damit die Kinder. Kann eine Gesellschaft, in der ein Kind als ein Problemfall angesehen wird, ein Paradies für Kinder sein?",
      "words": {
        "a": "AUF",
        "b": "BEI",
        "c": "DABEI",
        "d": "DENNOCH",
        "e": "DAS",
        "f": "DASS",
        "g": "DAVON",
        "h": "DAFÜR",
        "i": "DOCH",
        "j": "JEDOCH",
        "k": "ZUR",
        "l": "NIEMANDEN",
        "m": "SONDERN",
        "n": "VON",
        "o": "WEIL"
      },
      "answers": {
        "31": {
          "key": "k",
          "note": "Funktionsverbgefüge: „zur Verfügung stehen“."
        },
        "32": {
          "key": "b",
          "note": "„drei Jahre bei dem Kind zu Hause zu bleiben“."
        },
        "33": {
          "key": "e",
          "note": "„Das hat den Vorteil, dass ...“."
        },
        "34": {
          "key": "d",
          "note": "„Dennoch (= Trotzdem) wird die Elternzeit ... zu einem gravierenden Problem.“"
        },
        "35": {
          "key": "i",
          "note": "„Doch (= Aber) auch andere Dinge machen Familien das Leben schwer.“"
        },
        "36": {
          "key": "m",
          "note": "„nicht still am Tisch, sondern stören ...“."
        },
        "37": {
          "key": "l",
          "note": "Akkusativ von „niemand“: „stört das niemanden“."
        },
        "38": {
          "key": "o",
          "note": "„..., weil die Kinder die Ruhe ... stören“."
        },
        "39": {
          "key": "f",
          "note": "„so angeordnet, dass ...“."
        },
        "40": {
          "key": "a",
          "note": "„Anspruch auf einen Platz“."
        }
      }
    },
    {
      "id": "20b",
      "num": "20b",
      "page": 442,
      "isVariant": true,
      "title": "Deutschland – ein Paradies für Kinder? (Variante 20b)",
      "category": "Gesellschaft & Familie",
      "text": "17 Millionen Kinder leben in Deutschland. Verglichen mit der Bevölkerungszahl von ungefähr 80 Millionen ist das fast ein Viertel der Einwohner. Doch nur für jedes zehnte Kind unter drei Jahren steht ein Betreuungsplatz in einer Kindertagesstätte {{31}} Verfügung. Die Folge: Nur etwas mehr als die Hälfte der Mütter dieser Kinder ist berufstätig – und nur ein Viertel kann ganztägig zur Arbeit gehen.\n\nUm dem entgegenzuwirken, gibt es in Deutschland die dreijährige Elternzeit, die es einem Elternteil ermöglichen soll, drei Jahre bei dem Kind zu Hause zu bleiben. Das hat den Vorteil, dass der zu Hause bleibende Elternteil seinen Arbeitsplatz nicht verliert. {{32}} wird die Elternzeit für viele Eltern in finanzieller Hinsicht zu einem gravierenden Problem. Außerdem gilt die Elternzeit nur für Angestellte. Mütter zum Beispiel, die vor der Geburt ihres Kindes selbständig waren und mit dem Baby zu Hause bleiben wollen, stehen weit schlechter da. Kind und Karriere zu {{33}} ist daher in Deutschland für die meisten Mütter so gut wie unmöglich. Dies scheinen die Hauptgründe dafür zu sein, warum in Deutschland zurzeit weltweit die wenigsten Kinder geboren werden.\n\nDoch auch andere Dinge machen Familien mit Kindern in Deutschland das Leben schwer: In Restaurants zum Beispiel sind Kinder selten willkommen. Sie sitzen eben nicht still am Tisch, sondern stören mit ihrem Lachen und lauten Sprechen die anderen (kinderlosen) Gäste. Bei den kinderlosen Erwachsenen werden andere Maßstäbe angelegt. Obwohl diese selbst häufig lautstark telefonieren, stört das {{34}}: Telefonate sind eben wichtiger als Kinder. In zahlreichen deutschen Städten wie Mainz strengen Anwohner Prozesse gegen Kindergärten und Spielplätze an, {{35}} die Kinder die Ruhe der benachbarten (kinderlosen) Hausbewohner stören. Die Folge: Spielplätze {{36}} von Gerichts wegen geschlossen. An Wiesen, auf denen früher Kinder tobten und Ball spielten, stehen nun Schilder: Betreten und Spielen verboten. Bei Zuwiderhandlung drohen Geldstrafen.\n\nEltern, die mit der Deutschen Bahn mit ihren Kindern reisen möchten, haben schlechte Karten. In den meisten Zügen sind die Gänge so angeordnet, {{37}} mit einem Kinderwagen kein Durchkommen ist. Und in den Mutter-Kind-Abteilen haben {{38}} schon andere Reisende breitgemacht, die nicht einsehen, warum sie Müttern mit Kind Platz machen sollten. Schließlich hätten sie ja eine Fahrkarte gekauft und damit Anspruch {{39}} einen Platz. In vielen Berichten in Zeitungen oder im Fernsehen, {{40}} sich mit Kindern, ihrer Erziehung oder mit dem Schulsystem befassen, spricht man in Deutschland gerne von „Problemen“. Man meint damit die Kinder. Kann eine Gesellschaft, in der ein Kind als ein Problemfall angesehen wird, ein Paradies für Kinder sein?",
      "words": {
        "a": "AUF",
        "b": "SICH",
        "c": "DABEI",
        "d": "NIEMANDEN",
        "e": "VEREINBAREN",
        "f": "DASS",
        "g": "DAVON",
        "h": "DENNOCH",
        "i": "DOCH",
        "j": "JEDOCH",
        "k": "ZUR",
        "l": "OBWOHL",
        "m": "WERDEN",
        "n": "DIE",
        "o": "WEIL"
      },
      "answers": {
        "31": {
          "key": "k",
          "note": "„zur Verfügung stehen“."
        },
        "32": {
          "key": "h",
          "note": "„Dennoch wird die Elternzeit ... zu einem gravierenden Problem.“"
        },
        "33": {
          "key": "e",
          "note": "Kollokation: „Kind und Karriere zu vereinbaren“."
        },
        "34": {
          "key": "d",
          "note": "„stört das niemanden“."
        },
        "35": {
          "key": "o",
          "note": "„..., weil die Kinder die Ruhe ... stören“."
        },
        "36": {
          "key": "m",
          "note": "Vorgangspassiv: „Spielplätze werden von Gerichts wegen geschlossen.“"
        },
        "37": {
          "key": "f",
          "note": "„so angeordnet, dass ...“."
        },
        "38": {
          "key": "b",
          "note": "Reflexivverb: „sich breitmachen“."
        },
        "39": {
          "key": "a",
          "note": "„Anspruch auf einen Platz“."
        },
        "40": {
          "key": "n",
          "note": "Relativpronomen Nominativ Plural („Berichten ..., die sich mit Kindern befassen“)."
        }
      }
    },
    {
      "id": "21",
      "num": "21",
      "page": 443,
      "isVariant": false,
      "title": "Wie TV-Bilder die Fantasie von Kindern prägen",
      "category": "Medienwissenschaft & Pädagogik",
      "text": "Werden Kinder und Jugendliche {{31}} brutale, von Gewalt geprägte Medieninhalte gewaltbereiter? Zumindest prägen Bilder aus Kino und Fernsehen massiv ihre Fantasie. Das zeigt eine Studie von Forschern der Universität Bonn. {{32}} allem Jungen scheinen für extrem gewalttätige Bilder empfänglich zu sein.\n\n„Unsere Studie zeigt in der Tat, wie sehr Medienbilder inzwischen die Fantasie von Kindern beeinflussen“, erklärt Professor Volker Ladenthin von der Universität Bonn. „Also auch jene Fantasie, mit der sie ihr späteres Handeln planen.“ Ladenthin hat zusammen mit seinen Forscherkollegen untersucht, {{33}} Bilder in den Köpfen von Kindern herumgeistern. Die Wissenschaftler ließen nach eigenen Angaben knapp 300 Schüler der Klassenstufen 7 und 8 zu einem klassischen Märchenanfang einen Schluss schreiben. Die Fantasien der Jungen und Mädchen {{34}} sich deutlich: So beendeten Schüler ihre Märchen oft in wahren Blutorgien. Die Schülerinnen {{35}} das Märchen dagegen meist gewaltfrei enden, verwendeten aber stattdessen gerne Anleihen an romantischen Fernsehsendungen.\n\n„Unsere Studie kann und will nicht nach den Ursachen von konkreten Gewaltverbrechen jugendlicher Täter fragen“, betont die an der Studie mitwirkende Medienwissenschaftlerin Jessica von Wülfing. Das Experiment zeige jedoch, {{36}} sehr Bilder aus den Medien die Vorstellungswelt {{37}} Jugendlichen prägen.\n\n„Das ist eine gefährliche Entwicklung“, warnt Ladenthin, auf den die Idee zu dem Projekt zurückgeht: „In der Jugend lernt man das Vokabular, {{38}} dem man die Welt begreift. Wenn darin bestimmte Vokabeln fehlen – Mitgefühl, Liebe, aber auch Mitleid oder Schuld –, führt das zu Defiziten in der Wahrnehmung und in letzter Konsequenz auch im eigenen Verhalten.“ Wer nie Musik gehört hat, kann keine Vorstellung davon entwickeln, {{39}} Musik überhaupt ist. Ähnlich kann man in Horrorfilmen und Schießspielen vieles lernen, aber kein Mitgefühl. Sind die Jungen mit den brutalsten Märchen also allesamt potenzielle Gewalttäter? Sicherlich nicht, relativiert der Bonner Erziehungswissenschaftler. Gefährlich werde es aber {{40}}, wenn positive Alternativbilder fehlten: Dann bleibe das Vokabular lückenhaft. Aufgabe der Schule sei es daher, Gegenbilder anzubieten. Und ganz klar ist das Fazit: Der Fernseher gehört nicht ins Kinderzimmer.",
      "words": {
        "a": "AUS",
        "b": "DANN",
        "c": "DURCH",
        "d": "JENE",
        "e": "LIESSEN",
        "f": "MACHTEN",
        "g": "MIT",
        "h": "SO",
        "i": "UNTERSCHIEDEN",
        "j": "VERÄNDERTEN",
        "k": "VON",
        "l": "VOR",
        "m": "WAS",
        "n": "WELCHE",
        "o": "WIE"
      },
      "answers": {
        "31": {
          "key": "c",
          "note": "Kausal/Instrumental (+ Akkusativ): „durch brutale Medieninhalte“."
        },
        "32": {
          "key": "l",
          "note": "Feste Wendung: „Vor allem“ (= Insbesondere)."
        },
        "33": {
          "key": "n",
          "note": "Indirekter Fragesatz (Plural „Bilder“): „untersucht, welche Bilder ... herumgeistern“."
        },
        "34": {
          "key": "i",
          "note": "Präteritum von „sich unterscheiden“: „unterschieden sich deutlich“."
        },
        "35": {
          "key": "e",
          "note": "lassen + Infinitiv („enden“): „Die Schülerinnen ließen das Märchen gewaltfrei enden.“"
        },
        "36": {
          "key": "o",
          "note": "Gradangabe im Nebensatz: „wie sehr Bilder ... prägen“."
        },
        "37": {
          "key": "k",
          "note": "Genitiv-Ersatz mit „von“ (+ Dativ Plural ohne Artikel): „die Vorstellungswelt von Jugendlichen“."
        },
        "38": {
          "key": "g",
          "note": "Relativsatz zu „das Vokabular“: „mit dem man die Welt begreift“."
        },
        "39": {
          "key": "m",
          "note": "Indirekter Fragesatz: „was Musik überhaupt ist“."
        },
        "40": {
          "key": "b",
          "note": "Korrelat zum nachfolgenden „wenn“-Satz: „Gefährlich werde es aber dann, wenn ...“."
        }
      }
    },
    {
      "id": "22",
      "num": "22",
      "page": 444,
      "isVariant": false,
      "title": "Städte vor dem Infarkt",
      "category": "Verkehr & Umwelt",
      "text": "Schon immer haben Menschen {{31}} geträumt, jederzeit mobil zu sein. Deswegen ist es nicht verwunderlich, dass das Auto das beliebteste Verkehrsmittel weltweit geworden ist. Es ist nicht nur die uneingeschränkte Mobilität, die das Auto so attraktiv macht, sondern auch die Symbolik, die dem Auto anhängt: {{32}} Auto fährt, hat in seinem Leben etwas erreicht. Nicht selten soll die Größe eines Autos den gesellschaftlichen Status des Fahrers widerspiegeln.\n\nDer Wunsch nach einem „Auto für jeden“ ist zwar für viele Menschen Realität geworden, er hat aber auf der anderen Seite auch viele Probleme hervorgebracht. Denn die meisten Großstädte sind zu einer Zeit entstanden, als es noch keine Autos gab. Daraus folgt, {{33}} für so viele Fahrzeuge der Platz nicht mehr ausreicht. Die Straßen sind {{34}} nicht breit genug, es gibt zu wenig Parkplätze. Staus und langes Suchen nach einem Platz, wo man sein Gefährt loswerden kann, rauben vielen städtischen Autofahrern inzwischen den letzten Nerv. In einigen Großstädten stehen die Fahrzeuge inzwischen länger, als sie {{35}}. Manche Orte in der Stadt lassen sich zu Fuß schneller erreichen als mit dem Auto. Der Verkehrsinfarkt tritt ein: Nichts geht mehr, {{36}} die Zahl der Straßenfahrzeuge ist zu groß geworden.\n\nHinzu kommen noch die durch den Verkehr erzeugten Umweltprobleme. Die Erwärmung der Luft führt {{37}}, dass sich das Klima verändert. Ruß und Feinstaub sind die Ursache dafür, dass immer mehr Großstädter an Atemwegserkrankungen leiden. Und schließlich benötigen immer mehr Fahrzeuge immer mehr Energie, die weltweit aber gleichzeitig immer knapper und damit teurer wird.\n\n{{38}} dem Verkehrsinfarkt zuvorzukommen und nicht tatenlos zuzusehen, wie der Verkehr zu einem immer größeren Problem wird, haben einige Großstädte damit begonnen, den öffentlichen Personennahverkehr auszubauen. Eigene Spuren für Busse und Straßenbahnen werden eingerichtet, damit die öffentlichen Verkehrsmittel beschleunigt und damit attraktiv werden. In den großen Metropolen {{39}} sich die Tunnel der U-Bahnen immer weiter durch das Erdreich.\n\nDiese Maßnahmen sind recht teuer. Doch langsam setzt sich das Bewusstsein dafür durch, dass das ungebremste Anwachsen des Individualverkehrs in eine Sackgasse führt, aus der wieder herauszukommen noch viel Überzeugungsarbeit {{40}} wird.",
      "words": {
        "a": "DASS",
        "b": "DAVON",
        "c": "DAZU",
        "d": "DENN",
        "e": "FAHREN",
        "f": "GRABEN",
        "g": "HIERMIT",
        "h": "KLAUEN",
        "i": "KOSTEN",
        "j": "OFT",
        "k": "REIBEN",
        "l": "SO",
        "m": "UM",
        "n": "WENN",
        "o": "WER"
      },
      "answers": {
        "31": {
          "key": "b",
          "note": "träumen von -> Pronominaladverb „davon geträumt, ... zu sein“."
        },
        "32": {
          "key": "o",
          "note": "Verallgemeinernder Relativsatz: „Wer Auto fährt, hat in seinem Leben etwas erreicht.“"
        },
        "33": {
          "key": "a",
          "note": "Subjektsatz nach „Daraus folgt, dass ...“."
        },
        "34": {
          "key": "j",
          "note": "Häufigkeitsadverb: „Die Straßen sind oft nicht breit genug“."
        },
        "35": {
          "key": "e",
          "note": "Gegensatz zu „stehen“: „stehen die Fahrzeuge inzwischen länger, als sie fahren“."
        },
        "36": {
          "key": "d",
          "note": "Kausale Hauptsatzkonjunktion (Verb an Position 2: „ist“): „denn“."
        },
        "37": {
          "key": "c",
          "note": "führen zu -> Pronominaladverb „führt dazu, dass ...“."
        },
        "38": {
          "key": "m",
          "note": "Finalsatz mit Infinitiv: „Um dem Verkehrsinfarkt zuvorzukommen“."
        },
        "39": {
          "key": "f",
          "note": "Metaphorisches Verb: „graben sich die Tunnel der U-Bahnen durch das Erdreich“."
        },
        "40": {
          "key": "i",
          "note": "„viel Überzeugungsarbeit kosten (= erfordern) wird“."
        }
      }
    },
    {
      "id": "23",
      "num": "23",
      "page": 445,
      "isVariant": false,
      "title": "Fische sind schlauer, als wir denken",
      "category": "Biologie & Tierwelt",
      "text": "Fische sind dumm, stumm und haben keine Empfindungen – diese Vorurteile halten sich hartnäckig. Doch {{31}} das Gegenteil ist der Fall. Sie sind nämlich zu erstaunlichen kognitiven Leistungen {{32}} und können sowohl Freude als auch Schmerz empfinden. Die meisten Menschen wüssten so gut wie nichts über Fische, beklagt der Verhaltensbiologe Douglas Allan. Wenn man genauer hinsehe, verändere sich aber die Sicht auf sie.\n\nDenn das Leben im Wasser stellt die etwa 33.000 existierenden Arten vor besondere Herausforderungen. Im Laufe der Zeit {{33}} sie hochspezialisierte Sinnesfähigkeiten und Kommunikationsformen. So verständigen sie sich über Geräusche, Gerüche oder Berührungen. Einige Arten lernen durch {{34}} oder benutzen sogar Werkzeuge. Bis in die 1930er Jahre wurde Fischen {{35}} nicht einmal zugetraut, dass sie hören können. Erst dem österreichischen Verhaltensforscher Karl von Frisch gelang der Nachweis: Er brachte seinem blinden Wels Xaverl bei, auf ein akustisches Signal zu reagieren. Wenn er pfiff, kam Xaverl aus seinem Versteck, um Futter in Empfang zu nehmen. Der Forscher bewies {{36}} auch als Erster, dass Fische Farben sehen können.\n\n{{37}} warum wurden die Fähigkeiten der Fische so lange unterschätzt? {{38}} intelligent halten wir oft nur Tiere, die uns ähnlich sind, erklärt Douglas Allan. Fische hätten daher schlechte Karten. Schließlich müssten sie mit ganz anderen Lebensbedingungen zurechtkommen {{39}} Tiere an Land. Allan rät, {{40}} mehr über Fische herausfinden wolle, solle einfach mal in einem Aquarium im Zoo ein paar Minuten lang einen einzelnen Fisch beobachten. Dann erkenne man schnell, dass Fische nicht nur ein Bewusstsein, sondern auch einen eigenen Charakter und Bedürfnisse hätten.",
      "words": {
        "a": "ALS",
        "b": "BEOBACHTUNG",
        "c": "BETRACHTUNG",
        "d": "DENN",
        "e": "DER",
        "f": "DEUTLICH",
        "g": "DOCH",
        "h": "ENTWARFEN",
        "i": "ENTWICKELTEN",
        "j": "FÄHIG",
        "k": "FÜR",
        "l": "GENAU",
        "m": "NOCH",
        "n": "ÜBRIGENS",
        "o": "WER"
      },
      "answers": {
        "31": {
          "key": "l",
          "note": "Verstärkung vor „das Gegenteil“: „Doch genau das Gegenteil ist der Fall.“"
        },
        "32": {
          "key": "j",
          "note": "zu etwas (+ Dativ) fähig sein."
        },
        "33": {
          "key": "i",
          "note": "Biologische Evolution: „Im Laufe der Zeit entwickelten sie hochspezialisierte Sinnesfähigkeiten.“"
        },
        "34": {
          "key": "b",
          "note": "Fachbegriff der Verhaltensbiologie: „lernen durch Beobachtung“."
        },
        "35": {
          "key": "m",
          "note": "Feste Verbindung: „noch nicht einmal“ (= selbst ... nicht)."
        },
        "36": {
          "key": "n",
          "note": "Zusätzliche Information: „Der Forscher bewies übrigens auch als Erster, dass ...“."
        },
        "37": {
          "key": "g",
          "note": "Einleitung einer kontrastierenden Frage: „Doch (= Aber) warum wurden ... unterschätzt?“"
        },
        "38": {
          "key": "k",
          "note": "jemanden/etwas halten für (+ Adjektiv): „Für intelligent halten wir oft nur Tiere, die ...“."
        },
        "39": {
          "key": "a",
          "note": "Nach „anderen“ steht „als“: „mit ganz anderen Lebensbedingungen zurechtkommen als Tiere an Land“."
        },
        "40": {
          "key": "o",
          "note": "Verallgemeinernder Relativsatz: „wer mehr über Fische herausfinden wolle, solle ...“."
        }
      }
    },
    {
      "id": "24",
      "num": "24",
      "page": 446,
      "isVariant": false,
      "title": "Garten in der Stadt (Urban Gardening)",
      "category": "Stadtleben & Umwelt",
      "text": "Unter jungen Großstadtbewohnern gibt es einen neuen Trend: Sie wünschen sich einen eigenen Garten. Daher lassen sie sich auf lange Wartelisten für Kleingartenparzellen {{31}}. Auf Dächern, in Vorgärten, auf Mauern und grünen Grünstreifen werden Blumen {{32}}, und WGs nutzen ihre Südbalkons nicht mehr, um Altglas, sondern um Pflanzentöpfe abzustellen. In den deutschen Städten wird also gegraben, gepflanzt, gegossen und geerntet.\n\nDie {{33}} von grünen Städten liegen auf der Hand: Je mehr Pflanzen es in einer Stadt gibt, desto {{34}} ist die Lebensqualität. Pflanzen filtern Verunreinigungen aus der Luft, nehmen Kohlenstoffdioxid auf und geben Sauerstoff ab. Bäume sind natürliche Schutzwälle {{35}} Wind und Lärm, Parks sind beliebte Treffpunkte, und zu guter Letzt machen Pflanzen eine Stadt, die ansonsten aus Ziegeln, Beton und Asphalt besteht, auch viel schöner.\n\nDas liegt daran, dass sie auch einen psychologischen Effekt auf uns Menschen haben: Wo {{36}} grünt und blüht, da fühlen wir uns {{37}} wohl. {{38}} haben viele Städte entdeckt, dass {{39}} Gärtchen auch schnell zu sozialen Treffpunkten werden – {{40}} entsteht ein neues Nachbarschaftsgefühl.",
      "words": {
        "a": "SETZEN",
        "b": "GEZÜCHTET",
        "c": "VORTEILE",
        "d": "VOR",
        "e": "ES",
        "f": "EINFACH",
        "g": "MITTLERWEILE",
        "h": "SOLCHE",
        "i": "DADURCH",
        "j": "VON",
        "k": "KLEIN",
        "l": "KEIN",
        "m": "HÖHER",
        "n": "ERZOGEN",
        "o": "BEZÜCHTET"
      },
      "answers": {
        "31": {
          "key": "a",
          "note": "Kollokation: „sich auf eine Warteliste setzen lassen“."
        },
        "32": {
          "key": "b",
          "note": "Pflanzen/Blumen werden „gezüchtet“ („erzogen“ gilt nur für Kinder)."
        },
        "33": {
          "key": "c",
          "note": "„Die Vorteile von grünen Städten liegen auf der Hand.“"
        },
        "34": {
          "key": "m",
          "note": "Komparativ zu „Lebensqualität“ nach „je ..., desto ...“: „desto höher ist die Lebensqualität“."
        },
        "35": {
          "key": "d",
          "note": "Schutz / Schutzwälle „vor (+ Dativ) Wind und Lärm“."
        },
        "36": {
          "key": "e",
          "note": "Unpersönliches „es“: „Wo es grünt und blüht“."
        },
        "37": {
          "key": "f",
          "note": "Modalpartikel: „da fühlen wir uns einfach wohl“."
        },
        "38": {
          "key": "g",
          "note": "Temporaladverb: „Mittlerweile (= Inzwischen) haben viele Städte entdeckt, dass ...“."
        },
        "39": {
          "key": "h",
          "note": "Demonstrativpronomen Plural: „solche (= derartige) Gärtchen“."
        },
        "40": {
          "key": "i",
          "note": "Im PDF-Schlüssel S. 446 ist 40 = i) DADURCH markiert."
        }
      }
    },
    {
      "id": "25",
      "num": "25",
      "page": 447,
      "isVariant": false,
      "title": "Sicherer Schulweg",
      "category": "Familie, Kinder & Verkehr",
      "text": "Kinder sind oft mit dem Straßenverkehr überfordert, {{31}} ist es wichtig, dass sich Eltern und Bezugspersonen den besten Schulweg überlegen und mit ihren Kindern üben. {{32}} immer ist der kürzeste Weg auch der ungefährlichste. Zum Üben sollte man sich Zeit nehmen und sich voll auf das Kind {{33}}. Eltern sollten im Verkehr immer auch an ihre Vorbildfunktion denken: Verkehrsregeln nicht nur erklären, sondern sich auch {{34}} daran halten.\n\nWegen ihrer geringeren Körpergröße haben Kinder ein anderes Sichtfeld als Erwachsene. Dessen müssen sich die Erwachsenen bewusst sein. Manchmal ist es {{35}}, wenn die Großen sich von ihren Kindern erzählen lassen, was diese sehen. Um das Kind langsam an den Schulweg zu gewöhnen, sollte es anfangs nur das letzte Stück allein gehen. Diese Strecke kann man dann Schritt {{36}} Schritt verlängern. Dasselbe gilt für den Nachhauseweg. Auch ist es sinnvoll, zu Schulbeginn nochmals kurz und klar die wichtigsten Regeln für das {{37}} im Straßenverkehr mit den Kindern zu wiederholen.\n\nWenn der Schulweg kein Problem mehr darstellt, kann man noch mögliche {{38}} Situationen besprechen. Wie zum Beispiel: „Was machst du, wenn der Gehweg gesperrt ist?“ oder „Was tust du, wenn die Ampel ausgefallen ist?“ oder „Was machst du, wenn auf der anderen Straßenseite jemand nach dir ruft oder jemand bei Rot über die Kreuzung rennt?“. So lernt das Kind, sich {{39}} im Straßenverkehr zu verhalten und selbstständig {{40}} zu finden. Und die Erwachsenen können sicher sein, dass ihr Kind zumindest auf die Standardsituationen vorbereitet ist.",
      "words": {
        "a": "BEMÜHEN",
        "b": "FÜR",
        "c": "DESHALB",
        "d": "DOCH",
        "e": "HILFREICH",
        "f": "KONZENTRIEREN",
        "g": "KRITISCHE",
        "h": "LÖSUNGEN",
        "i": "NICHT",
        "j": "PROBLEME",
        "k": "SCHON",
        "l": "SELBST",
        "m": "STATT",
        "n": "SELBSTBEWUSST",
        "o": "VERHALTEN"
      },
      "answers": {
        "31": {
          "key": "c",
          "note": "Kausaladverb mit Inversion („ist es“): „..., deshalb ist es wichtig“."
        },
        "32": {
          "key": "i",
          "note": "Verneinung: „Nicht immer ist der kürzeste Weg auch der ungefährlichste.“"
        },
        "33": {
          "key": "f",
          "note": "sich konzentrieren auf (+ Akkusativ)."
        },
        "34": {
          "key": "l",
          "note": "Vorbildfunktion: „sondern sich auch selbst daran halten“."
        },
        "35": {
          "key": "e",
          "note": "Prädikatives Adjektiv: „Manchmal ist es hilfreich, wenn ...“."
        },
        "36": {
          "key": "b",
          "note": "Feste Wendung: „Schritt für Schritt“."
        },
        "37": {
          "key": "o",
          "note": "Substantivierter Infinitiv nach „das“: „für das Verhalten im Straßenverkehr“."
        },
        "38": {
          "key": "g",
          "note": "Adjektiv im Akkusativ Plural: „mögliche kritische (= gefährliche/schwierige) Situationen“."
        },
        "39": {
          "key": "n",
          "note": "Adverb zu „sich verhalten“: „sich selbstbewusst (= sicher) im Straßenverkehr zu verhalten“."
        },
        "40": {
          "key": "h",
          "note": "„selbstständig Lösungen zu finden“."
        }
      }
    },
    {
      "id": "26",
      "num": "26",
      "page": 448,
      "isVariant": false,
      "title": "Wie Handschrift wieder cool wird (Lettering-Trend)",
      "category": "Bildung, Kunst & Alltag",
      "text": "Mit dem sogenannten SMS-Daumen erbringen Kinder heutzutage Höchstleistungen. Das Handgelenk hingegen schmerzt schnell, {{31}} Schreiben mit der Hand ungewohnt ist. Kinder haben damit in der Schule {{32}} mehr Probleme.\n\nDennoch gibt es einen neuen Trend, der mit Handschrift zu {{33}} hat: Unter dem Hashtag „Lettering“ finden sich auf Instagram über zwölf Millionen Beiträge. Beim Lettering werden Buchstaben auf kunstvolle Weise gezeichnet und danach dekoriert. Vom klassischen Schönschreiben, wie es früher unterrichtet und von einigen auch gefürchtet {{34}}, ist das alles weit entfernt. Die Verbindung {{35}} Schrift und Bild lässt sich auch im Alltag anwenden.\n\nErfahrungen {{36}} hat auch die Wiener Designerin Nina Holler gemacht, die Schrift-Workshops für Kinder und Erwachsene anbietet. Auf {{37}} Weise vermittelt die Künstlerin das Thema Schrift aus unterschiedlichen Zeitepochen bis hin zum handgezeichneten modernen Alphabet. So will sie dem persönlichen sprachlichen Ausdruck wieder mehr Tiefe verleihen. Der Künstlerin ist es ein Anliegen, {{38}} Kinder die Freude am Schreiben wiederentdecken. Die Schülerinnen und Schüler lernen durch Lettering nebenbei auch, coole Einladungen und Logos zu {{39}}.\n\nDer Rhythmus mache den individuellen Ausdruck beim Schreiben mit der Hand aus. Es nütze wenig, an einzelnen Elementen von Buchstaben zu feilen; vielmehr solle man Wörter im Ganzen schreiben, bis ihnen das flüssig von der Hand {{40}}. So wird die Feinmotorik wieder gestärkt, die vielen Kindern abhandengekommen ist. Gerade Jugendlichen im Alter zwischen 13 und 15 Jahren biete die Auseinandersetzung mit Schrift eine Möglichkeit, die eigene Handschrift zu beurteilen und zu entwickeln. So sollen sie neue Wege finden, um sich auszudrücken.",
      "words": {
        "a": "DAMIT",
        "b": "DAS",
        "c": "DASS",
        "d": "FIGUREN",
        "e": "FÜR",
        "f": "GEHT",
        "g": "GESTALTEN",
        "h": "IMMER",
        "i": "NIE",
        "j": "SPIELERISCHE",
        "k": "SUCHEN",
        "l": "TUN",
        "m": "VON",
        "n": "WEIL",
        "o": "WURDE"
      },
      "answers": {
        "31": {
          "key": "n",
          "note": "Kausalsatz mit Verbendstellung („ungewohnt ist“): „weil“."
        },
        "32": {
          "key": "h",
          "note": "Zunehmende Entwicklung: „immer mehr Probleme“."
        },
        "33": {
          "key": "l",
          "note": "Feste Wendung: „mit etwas zu tun haben“."
        },
        "34": {
          "key": "o",
          "note": "Passiv Präteritum: „wie es früher unterrichtet und ... gefürchtet wurde“."
        },
        "35": {
          "key": "m",
          "note": "„Die Verbindung von Schrift und Bild“."
        },
        "36": {
          "key": "a",
          "note": "Erfahrungen machen mit -> Pronominaladverb „Erfahrungen damit“."
        },
        "37": {
          "key": "j",
          "note": "Akkusativ feminin Singular nach „Auf“: „Auf spielerische Weise“."
        },
        "38": {
          "key": "c",
          "note": "Subjektsatz nach „ist es ein Anliegen, dass ...“."
        },
        "39": {
          "key": "g",
          "note": "Kollokation: „coole Einladungen und Logos zu gestalten“."
        },
        "40": {
          "key": "f",
          "note": "Redewendung: „etwas geht jemandem flüssig / leicht von der Hand“."
        }
      }
    },
    {
      "id": "27",
      "num": "27",
      "page": 449,
      "isVariant": false,
      "title": "Die Reise im Schlafwagen",
      "category": "Reisen, Bahn & Umwelt",
      "text": "Lange sah es so aus, als würde er ganz verschwinden: Die Rede ist vom Nachtzug. In den letzten Jahrzehnten wurde er immer mehr von Billigfliegern verdrängt und viele Angebote wurden {{31}}. Noch in den 1990er Jahren fuhren allerdings Nachtzüge von Deutschland aus direkt bis nach Venedig, Stockholm oder Warschau. Heute sind die Österreichischen Bundesbahnen der größte Nachtzuganbieter in Europa. Und das Geschäft läuft: Das Angebot gewinne kontinuierlich neue {{32}}, erklärt Sprecher Olaf Heise. Die Zahl der Flugreisen steigt zwar weiter an, aber aus {{33}} des Umweltschutzes rücken andere Transportmittel wieder stärker in den Fokus. Kommt der Nachtzug also wieder in {{34}}? Und könnten komfortable Schlafwagen tatsächlich dem Flugzeug als Reisemittel {{35}} machen?\n\nStefan Wiese, der als passionierter Bahnfahrer ein Blog für Zugreisende betreibt, ist skeptisch: „In den engen Schlafabteilen ist es manchmal {{36}} schön ungemütlich und stickig.“ {{37}} schrecke die lange Reisezeit viele ab. Mit dem Flugzeug schaffe man es in 90 Minuten von München nach Rom, mit der Bahn brauche man 13 Stunden.\n\nDennoch: Es muss nicht immer das Flugzeug sein. {{38}} umweltschonendes Transportmittel ist der Nachtzug aktueller denn je. Zumal er auch einige romantische Vorstellungen weckt: Vor den Zugfenstern ziehen malerische Landschaften vorbei, {{39}} man von dem sanften Rattern des Zuges in den Schlaf gewiegt wird.\n\nSicher ist jedenfalls: Wer schon bedauert hatte, dass mit dem Verschwinden des Nachtzugs ein Stück Reisekultur verlorengehen könnte, war etwas {{40}}. Als sanfte Alternative zum Fliegen hat er durchaus eine Zukunft.",
      "words": {
        "a": "WÄHREND",
        "b": "VOREILIG",
        "c": "MODE",
        "d": "KUNDEN",
        "e": "KONKURRENZ",
        "f": "GRÜNDEN",
        "g": "GESAMT",
        "h": "GENAU",
        "i": "GANZ",
        "j": "FORM",
        "k": "EINGESTELLT",
        "l": "EINGESETZT",
        "m": "EIN",
        "n": "AUSSERDEM",
        "o": "ALS"
      },
      "answers": {
        "31": {
          "key": "k",
          "note": "Betrieb/Angebote beenden = „einstellen“ -> „viele Angebote wurden eingestellt“."
        },
        "32": {
          "key": "d",
          "note": "„Das Angebot gewinne kontinuierlich neue Kunden.“"
        },
        "33": {
          "key": "f",
          "note": "Feste Wendung: „aus Gründen des Umweltschutzes“."
        },
        "34": {
          "key": "c",
          "note": "Feste Wendung: „wieder in Mode kommen“."
        },
        "35": {
          "key": "e",
          "note": "Funktionsverbgefüge: „jemandem Konkurrenz machen“."
        },
        "36": {
          "key": "i",
          "note": "Umgangssprachlich: „ganz schön (= ziemlich) ungemütlich“."
        },
        "37": {
          "key": "n",
          "note": "Weiteres Gegenargument: „Außerdem schrecke die lange Reisezeit viele ab.“"
        },
        "38": {
          "key": "o",
          "note": "Rolle/Eigenschaft: „Als umweltschonendes Transportmittel“."
        },
        "39": {
          "key": "a",
          "note": "Gleichzeitigkeit: „..., während man ... in den Schlaf gewiegt wird“."
        },
        "40": {
          "key": "b",
          "note": "„war etwas voreilig“ (= hat zu früh geurteilt)."
        }
      }
    },
    {
      "id": "28",
      "num": "28",
      "page": 450,
      "isVariant": false,
      "title": "Katzen kennen ihren Namen",
      "category": "Wissenschaft & Haustiere",
      "text": "Sitz, Platz, Pfötchen geben: Nur die wenigsten Katzen befolgen Kommandos. Dabei sind sie durchaus in der {{31}}, ihren Namen aus anderen Wörtern herauszuhören, berichtet ein japanisches Forschungsteam im Fachblatt „Scientific Reports“. Nach eigenen {{32}} haben sie den ersten experimentellen Nachweis geliefert, dass Katzen Laute von Menschen verstehen können.\n\nErst als ihnen ihr eigener Name vorgespielt wurde, zeigten die meisten Versuchstiere eine Reaktion. Sie bewegten beispielsweise ihre Ohren oder drehten den Kopf. Der Effekt war auch zu beobachten, wenn nicht der Katzenbesitzer selbst zu seinem Tier sprach, {{33}} eine fremde Person. Lebten mehrere Katzen in einem Haushalt, konnten einige Katzen ihren Namen von {{34}} ihrer Artgenossen unterscheiden.\n\nDie Forscher hatten das {{35}} von 78 Katzen untersucht. {{36}} spielten sie den Tieren vier japanische Wörter vom Band vor, die ähnlich klangen wie der Name der Katze. Dabei nahm die Aufmerksamkeit der Katzen immer {{37}} ab. Doch wenn die Tiere ihren Namen und einzelne Gesten verstehen, warum ist es {{38}} schwierig, ihnen Tricks beizubringen? Laut Dennis Turner sei dies durchaus möglich, allerdings verlören die meisten Halter schnell die Geduld.\n\nBiologe Dennis Turner hält die japanische Studie für „seriös durchgeführt“. Die Ergebnisse aus Japan seien sicher auch auf deutsche Katzen übertragbar, so Turner. Überrascht ist er von dem Ergebnis allerdings nicht. „Katzen sind sehr intelligente und lernfähige Tiere – {{39}} sie bereit sind mitzumachen“, sagt Turner, der nicht an der Studie beteiligt war. Aus vorherigen Untersuchungen ist {{40}}, dass es Katzen verstehen, wenn Menschen mit dem Finger den Weg zum Fressnapf zeigen. Zudem ändern zumindest einige Katzen ihr Verhalten, je nachdem, ob ihr Herrchen grimmig oder fröhlich schaut.",
      "words": {
        "a": "ANGABEN",
        "b": "ANZEIGEN",
        "c": "BEKANNT",
        "d": "BLOSS",
        "e": "DENEN",
        "f": "DEREN",
        "g": "LAGE",
        "h": "SOFERN",
        "i": "SONDERN",
        "j": "STELLUNG",
        "k": "VERHALTEN",
        "l": "VERTRAUT",
        "m": "WEITER",
        "n": "ZUDEM",
        "o": "ZUNÄCHST"
      },
      "answers": {
        "31": {
          "key": "g",
          "note": "Feste Wendung: „in der Lage sein, etwas zu tun“."
        },
        "32": {
          "key": "a",
          "note": "Feste Wendung: „Nach eigenen Angaben“."
        },
        "33": {
          "key": "i",
          "note": "Gegensatz nach „nicht“: „nicht der Katzenbesitzer selbst ..., sondern eine fremde Person“."
        },
        "34": {
          "key": "e",
          "note": "Demonstrativpronomen im Dativ Plural nach „von“: „ihren Namen von denen (= den Namen) ihrer Artgenossen unterscheiden“."
        },
        "35": {
          "key": "k",
          "note": "Substantiv Neutrum: „das Verhalten von 78 Katzen“."
        },
        "36": {
          "key": "o",
          "note": "Erster Versuchsschritt: „Zunächst (= Zuerst) spielten sie den Tieren vier japanische Wörter vor.“"
        },
        "37": {
          "key": "m",
          "note": "„nahm die Aufmerksamkeit immer weiter ab“."
        },
        "38": {
          "key": "d",
          "note": "Fragepartikel in „warum“-Fragen (bzw. im PDF-Schlüssel markiert): „warum ist es bloß (so) schwierig“."
        },
        "39": {
          "key": "h",
          "note": "Konditionale Konjunktion: „sofern (= vorausgesetzt, dass) sie bereit sind mitzumachen“."
        },
        "40": {
          "key": "c",
          "note": "„Aus vorherigen Untersuchungen ist bekannt, dass ...“."
        }
      }
    },
    {
      "id": "29",
      "num": "29",
      "page": 451,
      "isVariant": false,
      "title": "Die Rückkehr des Nachtzugs",
      "category": "Verkehr, Bahn & Klimapolitik",
      "text": "Warum die Klimadebatte Schlafwagen wieder in {{31}} bringt: Der Zug heißt „Nightjet“, aber {{32}} so schnell wie mit dem Flugzeug ist es nicht.\n\nEine Bahnreise von Wien nach Brüssel verursacht nur einen Bruchteil des CO2-Ausstoßes eines Fluges. Bis Dezember soll als 28. Nachtzug-Linie eine von Wien und München nach Amsterdam hinzukommen. „Wenn wir mehr Schlafwagen hätten, könnten wir das Angebot rasch deutlich {{33}}“, sagt Bernhard Rieder von der ÖBB. Fünf Jahre dauert es vom Beschluss für einen neuen Zug bis zur Inbetriebnahme, auch weil Aufträge europaweit ausgeschrieben werden müssen. Man könne sie aber inzwischen kostendeckend betreiben. Pro Schlafwagen sei ein „Night Steward“ an Bord. {{34}} seien in der Regel acht Mitarbeiter in einem Nachtzug unterwegs, tagsüber seien es nur zwei – plus die Lokführer. Die Bahn betont, es gebe auch Züge, die in der Nacht fahren, aber mit Sitzplätzen. Wer das mal gemacht hat, kommt gerädert am Zielort an.\n\nAm 15. Dezember hat die Bahn in Kooperation mit den ÖBB auf den Strecken Zürich–Berlin und Zürich–Hamburg eine {{35}} Intercity-Nachtverbindung gestartet. „Daher investieren wir in den kommenden Jahren rund zwölf Milliarden Euro in unsere Fahrzeugflotte, die allein im Fernverkehr auf insgesamt 600 Züge anwachsen wird. Dazu sollen auch rund tausend zusätzliche Mitarbeiter {{36}} werden.“\n\n„Wenn die Deutsche Bahn nicht will, ist das bedauernswert.“ Er sehe aber kein Hindernis, warum nicht {{37}} dieses Angebot bei Nachtzügen übernehmen sollten – ihnen dürften nur keine Steine in den Weg gelegt werden. Sie betonen, mit einem Nachtzug gebe es die Chance, die vielen Flugreisen, die im Rahmen der Ratspräsidentschaft zwischen Berlin und Brüssel anfallen werden, {{38}} ein klimafreundliches Mobilitätsangebot zu reduzieren. Bisher müssten viele das Flugzeug nutzen, weil sie mit den aktuellen Zugverbindungen für Reisen zwischen Berlin und Brüssel nur tagsüber reisen können, damit sechs bis acht Stunden Zeit verlieren und in der Regel einen Tag vorher anreisen müssen. Am liebsten würden sie es sehen, wenn dieser neue Nachtzug in den blau-gelben Europafarben {{39}} wäre. Und der Nachtzug weckt bei vielen Menschen auch die Sehnsucht nach ungewöhnlichen Fernreisen. Der Nachtzug der Deutschen Bahn wurde {{40}} damals hoher Verluste 2016 eingestellt.",
      "words": {
        "a": "ALS",
        "b": "NEUE",
        "c": "FORM",
        "d": "MODE",
        "e": "EINSTEHEN",
        "f": "AUSWEITEN",
        "g": "WEGEN",
        "h": "GANZ",
        "i": "DURCH",
        "j": "GESTALTET",
        "k": "KONKURRENTEN",
        "l": "INSGESAMT",
        "m": "EIN",
        "n": "EINGESTELLT",
        "o": "KUNDEN"
      },
      "answers": {
        "31": {
          "key": "d",
          "note": "Feste Wendung: „etwas wieder in Mode bringen“."
        },
        "32": {
          "key": "h",
          "note": "Einschränkung vor „so schnell wie“: „aber ganz so schnell wie mit dem Flugzeug ist es nicht“."
        },
        "33": {
          "key": "f",
          "note": "Infinitiv nach „könnten“: „das Angebot rasch deutlich ausweiten (= vergrößern)“."
        },
        "34": {
          "key": "l",
          "note": "Summenangabe: „Insgesamt seien in der Regel acht Mitarbeiter ... unterwegs“."
        },
        "35": {
          "key": "b",
          "note": "Adjektiv im Akkusativ feminin Singular: „eine neue Intercity-Nachtverbindung“."
        },
        "36": {
          "key": "n",
          "note": "Personal einstellen -> Passiv: „tausend zusätzliche Mitarbeiter eingestellt werden“."
        },
        "37": {
          "key": "k",
          "note": "Subjekt im Plural: „warum nicht Konkurrenten (= Wettbewerber) dieses Angebot übernehmen sollten“."
        },
        "38": {
          "key": "i",
          "note": "Mittel (+ Akkusativ): „durch ein klimafreundliches Mobilitätsangebot reduzieren“."
        },
        "39": {
          "key": "j",
          "note": "Zustandspassiv Konjunktiv II: „in den blau-gelben Europafarben gestaltet wäre“."
        },
        "40": {
          "key": "g",
          "note": "Kausale Präposition mit Genitiv: „wegen damals hoher Verluste“."
        }
      }
    },
    {
      "id": "30",
      "num": "30",
      "page": 452,
      "isVariant": false,
      "title": "Joggen: Mehr als nur Laufen",
      "category": "Sport, Fitness & Gesundheit",
      "text": "Auto, Rolltreppe, Fahrstuhl – das moderne Leben ist {{31}} geworden. Ein Großteil der Bevölkerung verbringt den Tag sitzend. Zum Leidwesen unseres Körpers, denn das geht zu Lasten der Gesundheit. Herz-Kreislauf-Erkrankungen {{32}} in den westlichen Industrieländern mittlerweile die Todesursache Nummer Eins. Dennoch: Rund zehn Millionen Menschen in Deutschland joggen, etwa acht Millionen gehen Inline-Skaten oder Rad fahren, jeder Dritte schwimmt. Wer regelmäßig, richtig und vor allem in Maßen trainiert, fördert Gesundheit, Körper- und Selbstbewusstsein.\n\nZahlreiche Sportarten bieten einen einfachen und abwechslungsreichen Einstieg auch für Ungeübte. Vom Klassiker Jogging bis hin zu Walking, Radfahren, Schwimmen, Aerobic, Inline-Skating und Langlauf im Winter. Wichtig ist {{33}}, richtig zu trainieren, den Körper nicht zu überfordern – vor allem nach einer längeren Sportpause! Empfehlenswert ist aerobes Herz-Kreislauf-Training. Das bedeutet Ausdauertraining {{34}} Verbrennung von Sauerstoff. Dreimal in der Woche 30 bis 40 Minuten genügen. Dabei {{35}} der Puls kontrolliert werden. Der Richtwert ist hier 180 minus Lebensalter. Dann wird auch Fett verbrannt, der Körper nicht überfordert.\n\n{{36}} mehr Menschen den Schritt in ein aktiveres Leben wagen sollten, machen zahlreiche Studien deutlich: Rund 40 Prozent {{37}} Deutschen bringen zu viel auf die Waage, jeder Zehnte ist sogar stark fettleibig – Tendenz steigend. Auch vor Kindern und Jugendlichen macht diese Entwicklung nicht halt. Oft fehlt die Zeit für regelmäßiges Essen, Sport und Entspannung. Der Körper quittiert dies meist mit Herz-Kreislauf-Erkrankungen, nicht selten mit {{38}} Herzinfarkt – auch und immer häufiger {{39}} Frauen.\n\nAusdauersport hingegen wirkt auf Herz, Gefäße, Muskeln, Körpergewicht, Hormone und Stimmungen. Stress wird wegtrainiert, Krankheiten geheilt und vorgebeugt. Zusammen mit der richtigen Ernährung minimiert sich das Risiko, einen Herzinfarkt oder Schlaganfall zu erleiden, {{40}}. Milch und Milchprodukte, pflanzliche Lebensmittel wie Vollkornprodukte, Obst, Gemüse, Salat, magere Wurst und Käsesorten unterstützen das richtige Training.",
      "words": {
        "a": "ERHEBLICH",
        "b": "SCHNELL",
        "c": "IMMER",
        "d": "WIRD",
        "e": "DASS",
        "f": "EINEM",
        "g": "ALLER",
        "h": "SOLLTE",
        "i": "IST",
        "j": "SIND",
        "k": "BEQUEM",
        "l": "UNTER",
        "m": "BEI",
        "n": "DABEI",
        "o": "WIE"
      },
      "answers": {
        "31": {
          "key": "k",
          "note": "Durch Auto, Rolltreppe und Fahrstuhl ist das moderne Leben „bequem“ geworden."
        },
        "32": {
          "key": "j",
          "note": "Subjekt im Plural („Herz-Kreislauf-Erkrankungen“): „sind ... die Todesursache Nummer Eins“."
        },
        "33": {
          "key": "n",
          "note": "„Wichtig ist dabei (= beim Einstieg in den Sport), richtig zu trainieren.“"
        },
        "34": {
          "key": "l",
          "note": "Fachsprachlich: „unter Verbrennung von Sauerstoff“."
        },
        "35": {
          "key": "h",
          "note": "Empfehlung im Passiv: „Dabei sollte der Puls kontrolliert werden.“"
        },
        "36": {
          "key": "e",
          "note": "Vorangestellter Objektsatz: „Dass mehr Menschen den Schritt wagen sollten, machen zahlreiche Studien deutlich.“"
        },
        "37": {
          "key": "g",
          "note": "Genitiv Plural: „Rund 40 Prozent aller Deutschen“."
        },
        "38": {
          "key": "f",
          "note": "Dativ Maskulinum Singular nach „mit“: „mit einem Herzinfarkt“."
        },
        "39": {
          "key": "m",
          "note": "Betroffene Personengruppe: „immer häufiger bei Frauen“."
        },
        "40": {
          "key": "a",
          "note": "Adverb am Satzende zu „minimiert sich“: „minimiert sich das Risiko ... erheblich (= deutlich)“."
        }
      }
    },
    {
      "id": "31",
      "num": "31",
      "page": 453,
      "isVariant": false,
      "title": "Lernen ist kein Privileg der Jugend (Seniorenstudium)",
      "category": "Bildung & Gesellschaft",
      "text": "Senioren sind heute höchst {{31}}, aktiv und nutzen vielfach die Chance, sich in der sogenannten dritten Lebensphase Wünsche oder Träume zu erfüllen. Dazu gehören oft Weiterbildung oder in der Jugend verpasste Bildung.\n\nDie Folge: Das Seniorenstudium, wie es {{32}} verschiedenen deutschen Universitäten angeboten wird, erfreut sich zunehmender Beliebtheit. {{33}} in Trier waren im vergangenen Sommersemester über 130 Personen der Altersgruppe 50+ als Gasthörer eingeschrieben und nahmen am regulären Lehrbetrieb teil.\n\nBesonders gefragt waren allgemeinbildende Veranstaltungen aus den Fächern Geschichte, Kunstgeschichte und Politik. {{34}} folgten die neueren Sprach- und Literaturwissenschaften sowie Themen aus Philosophie, Psychologie und Pädagogik. Angebote aus den Sozial-, Wirtschafts-, Geo- und Rechtswissenschaften wurden dagegen weniger häufig gewählt. Hier finden sich insbesondere solche Seniorenstudierende wieder, die gezielt an der Vertiefung ihres fachspezifischen Wissens arbeiten.\n\nDer größte Teil der studierenden Senioren besteht übrigens aus Frauen. Die Gründe dafür {{35}} sein, dass Frauen in ihren jüngeren Lebensjahren häufig {{36}} eine berufliche Karriere verzichteten. {{37}} setzten sie sich für die Familie und insbesondere für ihre Kinder ein. Nun sind die Kinder erwachsen und aus dem Haus, die Frauen verspüren den Wunsch, ihre geistigen Fähigkeiten, deren Einsatz in den „Familienjahren“ häufig zu {{38}} gekommen war, wieder zu trainieren und zu erweitern.\n\nMänner hingegen konnten häufiger während ihres Arbeitslebens ihre Karriere verwirklichen, sich weiterbilden und ihr Wissen in gesellschaftlich angesehener Weise an den Mann (weniger an die Frau) bringen. {{39}} dessen sehen sie keine Veranlassung, ihren Lebensabend an einer Weiterbildungsinstitution oder gar an einer Universität zu verbringen.\n\nLernen ist kein Privileg der Jugend! Vielmehr besteht gerade in Bezug auf das Bildungsangebot für ältere Menschen ein riesiger Bedarf. Er wird gespeist {{40}} die Vitalität und die hohe Bildungsmotivation der heutigen „Alten“. Mit der wachsenden Fitness der Generation 50+ wächst auch das Interesse, neues Wissen zu erwerben, neue Kompetenzen zu entwickeln und bisher eventuell vernachlässigte Ressourcen zu aktivieren. Gleichzeitig tragen Bildungsaktivitäten wesentlich dazu bei, dass immer mehr Menschen ihre kognitive Leistungsfähigkeit und psychische Gesundheit bis ins hohe Alter erhalten können.",
      "words": {
        "a": "ALLEIN",
        "b": "AN",
        "c": "AUF",
        "d": "AUFGRUND",
        "e": "DARAUF",
        "f": "DURCH",
        "g": "DÜRFTEN",
        "h": "EINZIGE",
        "i": "KNAPP",
        "j": "KURZ",
        "k": "MÖCHTEN",
        "l": "REGE",
        "m": "STATTDESSEN",
        "n": "WÄHREND",
        "o": "WEGEN"
      },
      "answers": {
        "31": {
          "key": "l",
          "note": "Adjektiv: „höchst rege (= lebendig / geistig beweglich), aktiv“."
        },
        "32": {
          "key": "b",
          "note": "Präposition bei Universitäten: „an verschiedenen deutschen Universitäten“."
        },
        "33": {
          "key": "a",
          "note": "Fokuspartikel: „Allein (= Schon allein) in Trier waren über 130 Personen eingeschrieben.“"
        },
        "34": {
          "key": "e",
          "note": "folgen auf -> Pronominaladverb „Darauf (= Auf den ersten Platz) folgten ...“."
        },
        "35": {
          "key": "g",
          "note": "Konjunktiv II für eine begründete Vermutung im Plural („Die Gründe dafür dürften sein, dass ...“)."
        },
        "36": {
          "key": "c",
          "note": "Feste Präposition: „verzichten auf (+ Akkusativ)“."
        },
        "37": {
          "key": "m",
          "note": "Alternative zum Karriereverzicht: „Stattdessen setzten sie sich für die Familie ein.“"
        },
        "38": {
          "key": "j",
          "note": "Feste Redewendung: „zu kurz kommen“ (= vernachlässigt werden)."
        },
        "39": {
          "key": "d",
          "note": "Mit Genitiv „dessen“: „Aufgrund dessen (= Aus diesem Grund) sehen sie keine Veranlassung ...“."
        },
        "40": {
          "key": "f",
          "note": "Passiv mit unbelebter Ursache (+ Akkusativ): „wird gespeist durch die Vitalität“."
        }
      }
    },
    {
      "id": "32",
      "num": "32",
      "page": 454,
      "isVariant": false,
      "title": "Teleshopping – nicht immer gut und günstig",
      "category": "Verbraucherschutz & Medien",
      "text": "Zu Hause bequem vor dem Fernseher sitzen und einkaufen – das hört sich doch gut an! Gut schon – aber ist es auch günstig? Die Stiftung Warentest hat sich im Interesse der Kundinnen und Kunden drei große Anbieter einmal genauer angeschaut: Qualität {{31}} enttäuschend, Preise ziemlich hoch, rechtliche Rahmenbedingungen und Service im Wesentlichen in Ordnung, Werbung grell und nervig – so etwa lautet das Fazit, das die Stiftung Warentest zum Thema Teleshopping nach dem Test von drei großen Anbietern {{32}}.\n\nGenau wie die Stiftung Warentest sind auch die Verbraucherzentralen auf der Seite der Kunden. Die Juristin der sächsischen Verbraucherzentrale, Bettina Dittrich, meint zu der Untersuchung von Stiftung Warentest: „Das deckt sich im Wesentlichen mit den Erfahrungen, die wir {{33}} Beschwerdefällen machen“, und ergänzt, „doch nicht immer und überall läuft es damit problemlos.“\n\nGegenwärtig beschäftigen sie mehrere Beschwerden von Verbrauchern, die bei einem ausländischen Teleshoppinganbieter eingekauft hatten. Da wird für fristgerecht zurückgesandte Waren der Kaufpreis nicht erstattet, {{34}} es erfolgt nur eine Gutschrift – und das nicht einmal in voller {{35}}. Dabei beruft man sich offenbar auf die geltenden Allgemeinen Geschäftsbedingungen. Zumindest werden diese teilweise der Warenlieferung mitgeschickt.\n\nGanz {{36}} davon gilt natürlich deutsches Recht, wenn sich ausländische Unternehmen über deutsche Fernsehkanäle in deutscher Sprache an deutsche Verbraucher {{37}}. „Teleshoppingkäufe sind im rechtlichen Sinne Fernabsatzverträge, bei denen Verbraucher ein gesetzliches Widerrufs- oder Rückgaberecht von 2 Wochen haben“, sagt die Juristin und ergänzt, „dieses Recht gilt {{38}} unbefristet, wenn keine ordnungsgemäße Widerrufs- oder Rückgabebelehrung erfolgt ist.“\n\nDaher rät die Verbraucherzentrale den Verbrauchern, beim Teleshopping ihre Rechte {{39}} konsequent durchzusetzen wie bei anderen Verbraucherverträgen auch. {{40}} hilft die Verbraucherzentrale Sachsen mit Tipps und Informationen.",
      "words": {
        "a": "ABER",
        "b": "ABGESEHEN",
        "c": "BEI",
        "d": "BESCHLOSS",
        "e": "DABEI",
        "f": "DEUTLICH",
        "g": "EHER",
        "h": "GENAUSO",
        "i": "HÖHE",
        "j": "NACH",
        "k": "RECHNUNG",
        "l": "SOGAR",
        "m": "SONDERN",
        "n": "WENDEN",
        "o": "ZOG"
      },
      "answers": {
        "31": {
          "key": "g",
          "note": "Relativierendes Adverb: „Qualität eher enttäuschend“."
        },
        "32": {
          "key": "o",
          "note": "Funktionsverbgefüge „ein Fazit ziehen“ -> Präteritum „zog“."
        },
        "33": {
          "key": "c",
          "note": "„Erfahrungen, die wir bei Beschwerdefällen machen“."
        },
        "34": {
          "key": "m",
          "note": "Gegensatz nach „nicht erstattet“: „sondern es erfolgt nur eine Gutschrift“."
        },
        "35": {
          "key": "i",
          "note": "Feste Wendung bei Geldbeträgen: „in voller Höhe“."
        },
        "36": {
          "key": "b",
          "note": "Feste Verbindung: „Ganz abgesehen davon“."
        },
        "37": {
          "key": "n",
          "note": "Reflexivverb: „sich wenden an (+ Akkusativ)“."
        },
        "38": {
          "key": "l",
          "note": "Steigerungspartikel: „dieses Recht gilt sogar unbefristet, wenn ...“."
        },
        "39": {
          "key": "h",
          "note": "Vergleich mit „wie“: „ihre Rechte genauso konsequent durchzusetzen wie ...“."
        },
        "40": {
          "key": "e",
          "note": "helfen bei -> Pronominaladverb „Dabei hilft die Verbraucherzentrale Sachsen.“"
        }
      }
    },
    {
      "id": "33",
      "num": "33",
      "page": 455,
      "isVariant": false,
      "title": "Es gibt immer weniger Deutsche (Demografischer Wandel)",
      "category": "Demografie, Wirtschaft & Politik",
      "text": "{{31}} Angaben des Statistischen Bundesamtes in Wiesbaden wird die Bevölkerungszahl in Deutschland in den nächsten Jahrzehnten {{32}} sinken. Die Statistiker {{33}} damit, dass die Zahl der Deutschen bis zum Jahr 2050 von jetzt 82 Millionen auf nur noch 65 Millionen zurückgehen wird. Diese Entwicklung sei, so kommentieren die Statistiker, deswegen so dramatisch, weil sich gleichzeitig mit dem Rückgang der Einwohnerzahl die Altersstruktur Deutschlands sehr stark verändern wird: Fast die Hälfte der Bevölkerung wird dann im Rentenalter sein. Das Gesundheitssystem und die Altersversorgung werden {{34}} dieser Entwicklung vor großen Problemen stehen und möglicherweise nicht mehr bezahlbar sein.\n\nDiese ungünstige Bevölkerungsentwicklung in Deutschland hat nach Auskunft der Statistiker mehrere Aspekte. Zum einen werden die Deutschen immer älter: Das durchschnittliche Lebensalter für Frauen wird bis 2050 auf 84, das der Männer auf 78 Jahre {{35}}. Gleichzeitig werde zum anderen die Zahl der Geburten zurückgehen: Im Jahr 2050 werden voraussichtlich nur noch 1400 Kinder pro 1000 Frauen geboren. Die Zahl der Erwerbstätigen werde um fast 10 Millionen auf nur noch 30 Millionen sinken.\n\nDie Auswirkungen auf das politische und gesellschaftliche Leben in Deutschland im Jahr 2050 lassen sich {{36}} erahnen. Wenn nahezu fünfzig Prozent der Bevölkerung Senioren sind, werden sich Politik und Geschäftswelt {{37}} diesen Personenkreis einstellen. Für junge Leute wird sich dann das Problem ergeben, dass sich Politiker mehr {{38}} die alten Wähler interessieren werden. Die Produktivität der Wirtschaft wird abnehmen, da Arbeitnehmer den größten Teil ihres Einkommens in die Kranken- und Rentenversicherungen {{39}} in den Konsum stecken müssen. Diese Probleme könne man nur {{40}}, so das Statistische Bundesamt, wenn ab sofort eine hohe Zahl von jungen Arbeitskräften aus dem Ausland zuwandere. Diese würden dann für eine ausgeglichenere Bevölkerungsentwicklung in Deutschland sorgen.",
      "words": {
        "a": "AN",
        "b": "AUF",
        "c": "AUFGRUND",
        "d": "BEHEBEN",
        "e": "BESCHEIDEN",
        "f": "DRASTISCH",
        "g": "ERHÖHEN",
        "h": "FÜR",
        "i": "IM",
        "j": "NACH",
        "k": "RECHNEN",
        "l": "STATT",
        "m": "STEIGEN",
        "n": "ÜBERHEBLICH",
        "o": "UNSCHWER"
      },
      "answers": {
        "31": {
          "key": "j",
          "note": "Quellenangabe: „Nach Angaben des Statistischen Bundesamtes“."
        },
        "32": {
          "key": "f",
          "note": "Adverb zu „sinken“: „drastisch (= sehr stark) sinken“."
        },
        "33": {
          "key": "k",
          "note": "rechnen mit -> „Die Statistiker rechnen damit, dass ...“."
        },
        "34": {
          "key": "c",
          "note": "Kausale Präposition mit Genitiv: „aufgrund dieser Entwicklung“."
        },
        "35": {
          "key": "m",
          "note": "Intransitives Verb (ohne „sich“): „auf 78 Jahre steigen“ („erhöhen“ bräuchte „sich“)."
        },
        "36": {
          "key": "o",
          "note": "Adverb: „lassen sich unschwer (= leicht / ohne Mühe) erahnen“."
        },
        "37": {
          "key": "b",
          "note": "sich einstellen auf (+ Akkusativ)."
        },
        "38": {
          "key": "h",
          "note": "sich interessieren für (+ Akkusativ)."
        },
        "39": {
          "key": "l",
          "note": "Gegenüberstellung: „in die Versicherungen statt in den Konsum stecken“."
        },
        "40": {
          "key": "d",
          "note": "Kollokation: „Probleme beheben (= lösen / beseitigen)“."
        }
      }
    },
    {
      "id": "34",
      "num": "34",
      "page": 456,
      "isVariant": false,
      "title": "Die Internet-Hauptstadt Deutschlands (Erste E-Mail aus Karlsruhe)",
      "category": "Technikgeschichte & Kommunikation",
      "text": "Mit einem historischen Knopfdruck versandte der Karlsruher Informatik-Professor Werner Zorn (im Text: Heinz Henn) im Jahr 1984 die erste E-Mail von deutschem Boden aus. Mehr als zwei Jahre dauerte die Forschungsarbeit an der Karlsruher Universität, bis es möglich wurde, ein offenes Rechnernetz herzustellen, {{31}} das sich immer weitere Teilnehmer anschließen konnten. Aus dem ursprünglichen Kommunikationsnetz zum Informationsaustausch unter Wissenschaftlern war ein elektronischer Postverband {{32}}.\n\nKarlsruhe ist dann schnell zum Knotenpunkt des E-Mail-Netzes für Deutschland ausgebaut {{33}}. Aus allen Winkeln Deutschlands liefen hier die elektronischen Fäden zusammen. Zu den ersten Kunden zählten aber {{34}} nur Universitäten und Forschungseinrichtungen, {{35}} auch große Firmen wie Siemens oder Bosch. Deutschland war nach Kanada, Schweden und Israel das weltweit vierte Land, das ein landesweites E-Mail-Netz aufweisen konnte. Bis 1989 wurden schließlich die E-Mail-Netze bis nach China und in die USA ausgeweitet.\n\nDer Knopfdruck von 1984 hat die Kommunikationsmöglichkeiten der Menschen geradezu revolutioniert. Die Briefschreiber von früher verwandelten sich {{36}} die Versender elektronischer Post von heute. War früher ein Brief von einem Kontinent zu einem anderen manchmal wochenlang unterwegs, erreicht die E-Mail ihre Empfänger in Sekundenschnelle. Der uralte Menschheitstraum, jedermann jederzeit schnellstmöglich zu erreichen, wurde Wirklichkeit.\n\n{{37}} es gibt auch Stimmen, die Kritik {{38}} üben, dass die elektronische Post {{39}} einem Sprachgebrauch geführt hat, der sich deutlich negativ auf den Stil ausgewirkt hat. Es gebe keine festgelegte Form mehr für E-Mails, wie sie für Briefe verbindlich war. Man lege keinen Wert mehr {{40}} den Ausdruck, die Sprache sei knapp und kurz, ohne Schönheit. Diese Kritik interessiert die E-Mail-Nutzer von heute aber meist nicht. Das beweisen die mehr als drei Millionen Internetdomains, die heute auf den Servern einer einzigen Karlsruher Internetfirma liegen. Bis zum Ende des letzten Jahrtausends wurden Internetadressen nur von Karlsruhe aus vergeben. 2003 wurde Karlsruhe daher in den Stand der Internethauptstadt Deutschlands erhoben.",
      "words": {
        "a": "NICHT",
        "b": "AN",
        "c": "AUF",
        "d": "DARAN",
        "e": "DARÜBER",
        "f": "DOCH",
        "g": "EIGENTLICH",
        "h": "GEWESEN",
        "i": "GEWORDEN",
        "j": "IN",
        "k": "SONDERN",
        "l": "ÜBER",
        "m": "ÜBRIGENS",
        "n": "WORDEN",
        "o": "ZU"
      },
      "answers": {
        "31": {
          "key": "b",
          "note": "sich anschließen an (+ Akkusativ): „an das sich immer weitere Teilnehmer anschließen konnten“."
        },
        "32": {
          "key": "i",
          "note": "Vollverb „werden“ im Plusquamperfekt Aktiv: „war ein elektronischer Postverband geworden“."
        },
        "33": {
          "key": "n",
          "note": "Hilfsverb „werden“ im Perfekt Passiv (ohne „ge-“): „ist ... ausgebaut worden“."
        },
        "34": {
          "key": "a",
          "note": "„nicht nur ..., sondern auch ...“."
        },
        "35": {
          "key": "k",
          "note": "„nicht nur ..., sondern auch ...“."
        },
        "36": {
          "key": "j",
          "note": "sich verwandeln in (+ Akkusativ)."
        },
        "37": {
          "key": "f",
          "note": "Adversative Konjunktion am Satzanfang: „Doch (= Aber) es gibt auch Stimmen, ...“."
        },
        "38": {
          "key": "d",
          "note": "Kritik üben an -> Pronominaladverb „die Kritik daran üben, dass ...“."
        },
        "39": {
          "key": "o",
          "note": "führen zu (+ Dativ): „zu einem Sprachgebrauch geführt hat“."
        },
        "40": {
          "key": "c",
          "note": "Feste Wendung: „Wert legen auf (+ Akkusativ)“."
        }
      }
    },
    {
      "id": "35",
      "num": "35",
      "page": 457,
      "isVariant": false,
      "title": "Vegetarisch essen – Ein neuer Trend in unserer Zeit",
      "category": "Ernährung & Gesundheit",
      "text": "Vegetarierinnen, die schwanger werden, möchten sich oft weiter vegetarisch ernähren. Worauf sollten sie dann achten? Abwechslungsreich essen ist wichtig für Schwangere. Schwangere haben einen teilweise {{31}} erhöhten Nährstoffbedarf, insbesondere bei Eiweiß, Vitaminen und Mineralstoffen. Verzichten sie auf Fisch, muss das aber keine Auswirkungen {{32}} das ungeborene Kind haben.\n\nEssen sie wie die meisten Vegetarier Eier oder Milchprodukte oder sogar {{33}}, dann können sie mit einer abwechslungsreichen Ernährung den Bedarf der meisten Nährstoffe {{34}}. Mängel können zwar bei der Versorgung mit Vitamin D, Eisen, Jod und Zink auftreten – das gilt allerdings auch für Nichtvegetarierinnen. Anders als oft vermutet, kommen gerade Eisenmangelanämien bei Vegetariern nicht häufiger als bei Nichtvegetariern {{35}}. Besonders achten sollten vegetarische Schwangere auf ausreichend Folat und Vitamin B12. Folat, das in seiner synthetischen Form Folsäure heißt, {{36}} zum Beispiel in Tomaten, Spinat und Vollkornprodukten. Vitamin B12 ist in pflanzlichen Lebensmitteln nicht enthalten, aber in Milch und Eiern.\n\nErnährungswissenschaftler empfehlen schwangeren Vegetarierinnen, ihren Nährstoffstatus regelmäßig {{37}} zu lassen. Wer diese Ratschläge befolgt, kann auch als Vegetarierin sein Baby stillen, ohne eine Mangelversorgung für das Baby befürchten zu müssen. Außerdem kommt es auf die richtige Mischung der Lebensmittel {{38}}. Bei der Einführung der Beikost zwischen dem fünften und siebten Lebensmonat sollten Eltern bei vegetarischer Ernährung den eisenreichen Gemüse-Kartoffel-Fleisch-Brei durch einen vegetarischen Gemüse-Kartoffel-Getreide-Brei {{39}}. Denn beim schnellen Wachstum von Babys und Kindern ist die Versorgung mit Eisen besonders wichtig. Deshalb sollten vegetarisch {{40}} Kinder viel eisenreiches Vollkorngetreide und Vitamin-C-reiches Gemüse wie Blumenkohl und Brokkoli essen.",
      "words": {
        "a": "STECKT",
        "b": "BEIDE",
        "c": "AUF",
        "d": "EINSETZEN",
        "e": "ERNÄHRTE",
        "f": "ÜBERPRÜFEN",
        "g": "BEIDES",
        "h": "ESSENDE",
        "i": "VOR",
        "j": "AN",
        "k": "SCHWER",
        "l": "WORAUF",
        "m": "DEUTLICH",
        "n": "ERSETZEN",
        "o": "DECKEN"
      },
      "answers": {
        "31": {
          "key": "m",
          "note": "Adverb vor Partizip/Adjektiv: „einen teilweise deutlich erhöhten Nährstoffbedarf“."
        },
        "32": {
          "key": "c",
          "note": "Feste Präposition: „Auswirkungen auf (+ Akkusativ) haben“."
        },
        "33": {
          "key": "g",
          "note": "Zusammenfassendes Neutrum für zwei Sachgruppen (Eier + Milchprodukte): „oder sogar beides“."
        },
        "34": {
          "key": "o",
          "note": "Kollokation: „den Bedarf decken“."
        },
        "35": {
          "key": "i",
          "note": "Trennbares Verb „vorkommen“ (= auftreten): „kommen ... nicht häufiger vor“."
        },
        "36": {
          "key": "a",
          "note": "„steckt (= ist enthalten) zum Beispiel in Tomaten, Spinat und Vollkornprodukten“."
        },
        "37": {
          "key": "f",
          "note": "„ihren Nährstoffstatus regelmäßig überprüfen zu lassen“."
        },
        "38": {
          "key": "j",
          "note": "Trennbares Verb „ankommen auf“: „kommt es auf die richtige Mischung an“."
        },
        "39": {
          "key": "n",
          "note": "etwas durch etwas „ersetzen“."
        },
        "40": {
          "key": "e",
          "note": "Partizip II als Attribut im Nominativ Plural ohne Artikel: „vegetarisch ernährte Kinder“."
        }
      }
    },
    {
      "id": "36",
      "num": "36",
      "page": 458,
      "isVariant": false,
      "title": "Crowdfunding boomt, Print lebt (Journalismusfestival in Perugia)",
      "category": "Medien & Journalismus",
      "text": "Perugia – Ein Gewinn sind vor allem die starke Präsenz von US-Amerikanern und der Mix aus Teilnehmern von Branchengrößen wie Facebook oder „New York Times“ bis zu freien Journalisten, die in Perugia ihr Start-up oder ein Technik-Tool {{31}}. Ein starker Schwerpunkt lag auch beim diesjährigen Journalismusfestival, das zum neunten Mal stattfand, auf Datenjournalismus, die Einbindung von Video in Onlineauftritte war {{32}} ein Schwerpunktthema.\n\nIm Gegensatz zu den Jahren {{33}} wurde nicht mehr darüber diskutiert, ob Print- und Online-Redaktionen zusammengelegt werden sollten, {{34}} wurde das bei den vielen Diskussionen und Workshops, die zwischen Mittwoch und Sonntag in der umbrischen Stadt stattfanden, als gegeben angenommen. Generell herrschte viel Optimismus {{35}}, den auch der via Skype von einem unbekannten Ort in den Rathaussaal von Perugia zugeschaltete NSA-Aufdecker Edward Snowden am Freitagabend beflügelte. Er setze auf den Journalismus, um die Massenüberwachung aller Bürger durch Geheimdienste einzudämmen, sagte Snowden.\n\nBürger sind offenbar auch immer mehr {{36}}, in journalistische Projekte zu investieren. In Perugia wurden auch mehrere Online-Magazine vorgestellt, die durch Crowdfunding finanziert werden. „De Correspondent“, 2013 in den Niederlanden gestartet, ist das {{37}} bekannteste Modell in Europa, das rund 1,3 Millionen Euro durch Mitgliedschaften gesammelt hat. Am meisten Unterstützungen hat jedoch das spanische Projekt „El Español“ erfahren: 1,7 Millionen Euro. Die „Krautreporter“ sammelten zwischen Mai und Juni 2014 rund eine Million ein und zählten 17.585 Mitglieder.\n\nWeitere journalistische Projekte, die vor kurzem an den Start gegangen sind, werden ebenfalls {{38}} Crowdfunding finanziert. In Perugia wurden auch Printproduktionen vorgestellt, die erst seit kurzem am Markt sind und sich {{39}} behaupten: das opulent gestaltete Magazin „Flaneur“, das 2013 erstmals erschienen ist und im Halbjahres-Rhythmus erscheint; „Berlin Quarterly“, eine englischsprachige Vierteljahreszeitschrift, und „Outpost“, ein im Arabischen Frühling in Beirut gestartetes Magazin, das sich explizit an junge Leser wendet. „Wir haben es als Printprodukt gestartet, weil {{40}} ein Qualitätsanspruch verbunden ist. Wir wollen ein Sprachrohr für die Jungen sein“, erläuterte Gründer Ibrahim Nehme.",
      "words": {
        "a": "VORSTELLEN",
        "b": "VOR",
        "c": "VIELMEHR",
        "d": "SOGLEICH",
        "e": "BEREIT",
        "f": "ZWAR",
        "g": "DURCH",
        "h": "DAMIT",
        "i": "ERGEBEN",
        "j": "OBWOHL",
        "k": "WOHL",
        "l": "EIGENTLICH",
        "m": "ERFOLGREICH",
        "n": "DAVOR",
        "o": "EBENFALLS"
      },
      "answers": {
        "31": {
          "key": "a",
          "note": "Relativsatz im Plural („freien Journalisten, die ... ihr Start-up vorstellen“)."
        },
        "32": {
          "key": "o",
          "note": "„war ebenfalls (= auch) ein Schwerpunktthema“."
        },
        "33": {
          "key": "n",
          "note": "Zeitangabe: „Im Gegensatz zu den Jahren davor (= zuvor)“."
        },
        "34": {
          "key": "c",
          "note": "Gegensatz nach Verneinung mit Inversion („wurde das“): „vielmehr wurde das ... als gegeben angenommen“."
        },
        "35": {
          "key": "b",
          "note": "Trennbares Verb „vorherrschen“: „Generell herrschte viel Optimismus vor.“"
        },
        "36": {
          "key": "e",
          "note": "bereit sein, etwas zu tun: „sind offenbar immer mehr bereit, ... zu investieren“."
        },
        "37": {
          "key": "k",
          "note": "Vermutungspartikel vor Superlativ: „ist das wohl bekannteste Modell in Europa“."
        },
        "38": {
          "key": "g",
          "note": "Mittel (+ Akkusativ): „durch Crowdfunding finanziert“."
        },
        "39": {
          "key": "m",
          "note": "Adverb zu „sich behaupten“: „und sich erfolgreich am Markt behaupten“."
        },
        "40": {
          "key": "h",
          "note": "verbunden sein mit -> Pronominaladverb „weil damit (= mit einem Printprodukt) ein Qualitätsanspruch verbunden ist“."
        }
      }
    },
    {
      "id": "37",
      "num": "37",
      "page": 459,
      "isVariant": false,
      "title": "Schnell und schneller – Von der Schnelligkeit des Lebens",
      "category": "Gesellschaft & Psychologie",
      "text": "So schnell wie Michael Schumacher fahren, das würde manch deutscher Autofahrer gern. Eine Geschwindigkeitsbegrenzung auf den Autobahnen {{31}} in Deutschland aber eine fast undenkbare Idee. Schnell ist modern, schnell ist ein Muss: Man geht ins Schnell-Restaurant, um Fastfood zu essen, man geht auf einen schnellen Kaffee ins Bistro und besucht am Abend einen Schnellkurs in Spanisch. Schnell, schneller, am schnellsten.\n\nEin Grund {{32}}, dass das Leben hierzulande so schnell geworden ist, {{33}} die moderne Technik sein. Kommunikationsmittel wie E-Mail oder das Handy machen fast jeden sofort erreichbar. Autos und Züge werden immer schneller und sogar die Nahrungsmittelindustrie preist die Vorteile der fixen „5-Minuten-Produkte“.\n\nDabei stellt sich die Frage, ob denn tatsächlich alles schneller geworden ist. E-Mails erreichen den Empfänger {{34}} schneller als ein Brief, {{35}} die Informationsflut im Internet bewirkt auch, dass es länger dauert, bis man die wirklich benötigte Information überhaupt findet. Das Mobiltelefon macht natürlich sofort erreichbar, das andauernde Klingeln stört jedoch immer öfter bei anderen Tätigkeiten, die man dann unterbricht. Und obwohl moderne Autos oft schneller als 200 km/h fahren können, kostet die steigende Anzahl der Staus auf den Autobahnen mehr Zeit, {{36}} man möchte. Viele zweifeln inzwischen {{37}}, ob die theoretisch mögliche Schnelligkeit und die reale Geschwindigkeit noch übereinstimmen.\n\nForscher haben nun herausgefunden, warum alles immer schneller zu werden scheint: Die Gleichförmigkeit unseres Lebens hat einen starken Einfluss {{38}}, wie das Lebenstempo empfunden wird. Bei immer mehr Routine bei der Arbeit und in der Freizeit und wenig Abwechslung im Leben {{39}}, so die Forscher, der Eindruck von Schnelligkeit entstehen. Das Gedächtnis blendet Lebenszeiten, in denen nichts Ungewöhnliches passiert ist, einfach aus und bringt so das Zeitempfinden des Menschen durcheinander.\n\nDen Gegenbeweis erbringt das Zeitempfinden im Urlaub. Hier wird die Routine durchbrochen und man tut Dinge, die sonst keinen Platz im Leben haben. Und siehe da: {{40}} befragt, wie sie die Urlaubszeit empfunden haben, antworten die meisten Urlauber: „Die Zeit verging so langsam – es war so richtig entspannend!“ Vielleicht sollten wir deshalb einfach öfters raus aus der Routine und schnell mal was Anderes machen.",
      "words": {
        "a": "ABER",
        "b": "ALS",
        "c": "DAFÜR",
        "d": "DANACH",
        "e": "DARAN",
        "f": "DARAUF",
        "g": "ENTWEDER",
        "h": "MAG",
        "i": "MÖCHTE",
        "j": "ODER",
        "k": "SEI",
        "l": "WÜRDE",
        "m": "WÄRE",
        "n": "WIE",
        "o": "ZWAR"
      },
      "answers": {
        "31": {
          "key": "m",
          "note": "Konjunktiv II von „sein“: „Eine Geschwindigkeitsbegrenzung wäre in Deutschland aber eine fast undenkbare Idee.“"
        },
        "32": {
          "key": "c",
          "note": "Ein Grund für -> Pronominaladverb „Ein Grund dafür, dass ...“."
        },
        "33": {
          "key": "h",
          "note": "Modalverb „mögen“ zum Ausdruck einer Vermutung: „mag die moderne Technik sein“."
        },
        "34": {
          "key": "o",
          "note": "Konzessive Struktur mit „aber“ in Lücke 35: „zwar ..., aber ...“."
        },
        "35": {
          "key": "a",
          "note": "„zwar schneller als ein Brief, aber die Informationsflut bewirkt auch, ...“."
        },
        "36": {
          "key": "b",
          "note": "Vergleich nach Komparativ („mehr Zeit, als man möchte“)."
        },
        "37": {
          "key": "e",
          "note": "zweifeln an -> Pronominaladverb „zweifeln inzwischen daran, ob ...“."
        },
        "38": {
          "key": "f",
          "note": "Einfluss haben auf -> Pronominaladverb „hat einen starken Einfluss darauf, wie ...“."
        },
        "39": {
          "key": "l",
          "note": "Im PDF-Schlüssel S. 459 ist 39 = l) WÜRDE markiert („würde, so die Forscher, der Eindruck von Schnelligkeit entstehen“)."
        },
        "40": {
          "key": "d",
          "note": "jemanden befragen nach -> Pronominaladverb „Danach befragt, wie sie die Urlaubszeit empfunden haben, ...“."
        }
      }
    },
    {
      "id": "38",
      "num": "38",
      "page": 460,
      "isVariant": false,
      "title": "Lange schlafen ist gesund, oder etwa nicht? (Drei Mythen über den Schlaf)",
      "category": "Gesundheit & Schlafforschung",
      "text": "Warum träumen wir? Was passiert im Gehirn, wenn wir schlafen? Und warum müssen wir {{31}} schlafen? Während Wissenschaftler nach Antworten auf diese Fragen suchen, werden im Volksmund etliche Geschichten über den Schlaf erzählt. Viele davon sind unwahr.\n\nMythos 1: Lange schlafen ist gesund.\nImmer wieder werden wir {{32}} gewarnt, dass sich zu wenig Schlaf früher oder später negativ auf unser Wohlbefinden auswirkt. Aber kann man auch zu viel schlafen? Schlafmediziner sagen: ja. Ein internationales Forschungsteam ist zu dem Ergebnis gekommen, dass zu viel Schlaf {{33}} ungesund ist wie zu wenig. Notorische Langschläfer leiden zum Beispiel häufiger {{34}} Depressionen und haben ein erhöhtes Risiko, an Diabetes zu erkranken.\n\nMythos 2: Der Schlaf vor Mitternacht ist der beste.\nViele Menschen behaupten, dass der Schlaf vor Mitternacht besonders erholsam sei. Das {{35}} so aber nicht. Wissenschaftler haben herausgefunden, dass nicht die Uhrzeit entscheidend ist, {{36}} vielmehr die ersten Stunden nach dem Einschlafen. In dieser Zeit {{37}} ein Großteil des wertvollen Tiefschlafs statt. In den Tiefschlafphasen erholt sich unser Körper am intensivsten. Der Zeitpunkt des Einschlafens spielt dabei keine {{38}}.\n\nMythos 3: Im Schlaf passiert {{39}} viel.\nWer glaubt, dass im Schlaf nicht viel passiert, der täuscht sich gewaltig. Nachts, wenn der Körper zur {{40}} kommt, laufen in unserem Organismus äußerst komplexe Prozesse ab. Unser Immunsystem wird aktiviert, Wachstumshormone bauen unsere Muskeln auf, die Haut regeneriert sich und unser Gehirn läuft auf Hochtouren, um die Ereignisse des Tages zu verarbeiten.",
      "words": {
        "a": "ALLZU",
        "b": "BEDEUTUNG",
        "c": "DARAUF",
        "d": "DAVOR",
        "e": "FINDET",
        "f": "GENAUSO",
        "g": "HIERMIT",
        "h": "MIT",
        "i": "SONDERN",
        "j": "ROLLE",
        "k": "RUHE",
        "l": "NIMMT",
        "m": "STIMMT",
        "n": "ÜBERHAUPT",
        "o": "UNTER"
      },
      "answers": {
        "31": {
          "key": "n",
          "note": "Grundsatzfrage: „Und warum müssen wir überhaupt schlafen?“"
        },
        "32": {
          "key": "d",
          "note": "warnen vor -> Pronominaladverb „werden wir davor gewarnt, dass ...“."
        },
        "33": {
          "key": "f",
          "note": "Vergleich mit „wie“: „dass zu viel Schlaf genauso ungesund ist wie zu wenig“."
        },
        "34": {
          "key": "o",
          "note": "leiden unter (+ Dativ): „leiden häufiger unter Depressionen“."
        },
        "35": {
          "key": "m",
          "note": "„Das stimmt so aber nicht.“ (= Das ist nicht richtig.)"
        },
        "36": {
          "key": "i",
          "note": "Gegensatz nach „nicht“: „nicht die Uhrzeit ..., sondern vielmehr die ersten Stunden“."
        },
        "37": {
          "key": "e",
          "note": "Trennbares Verb „stattfinden“: „In dieser Zeit findet ein Großteil des Tiefschlafs statt.“"
        },
        "38": {
          "key": "j",
          "note": "Feste Wendung: „keine Rolle spielen“."
        },
        "39": {
          "key": "a",
          "note": "In der Zwischenüberschrift / im Text mit „nicht“: „nicht allzu viel“."
        },
        "40": {
          "key": "k",
          "note": "Feste Wendung: „zur Ruhe kommen“."
        }
      }
    },
    {
      "id": "39",
      "num": "39",
      "page": 461,
      "isVariant": false,
      "title": "Leserbrief: „Menschen helfen Menschen“ (Autopanne vor Wien)",
      "category": "Leserbrief / Erlebnisbericht",
      "text": "Sehr geehrte Redaktion von „Menschen helfen Menschen“,\n\nich lese täglich die Zeitung und bin oft sehr traurig {{31}}, wie böse und grausam Menschen sein können. In solchen Momenten freue ich mich dann ganz {{32}} über Ihre Artikel, die zeigen, {{33}} es auch viele gute und hilfsbereite Menschen gibt. Ich selbst bin einem solchen Menschen vor kurzer Zeit begegnet.\n\nLetzten Samstag hatte ich auf der Autobahn kurz vor Wien eine Autopanne. Es war bereits 10 Uhr nachts, {{34}} mein Auto plötzlich stehen blieb und sich nicht mehr von der Stelle bewegte. Ich versuchte mehrmals, das Auto wieder zu starten, {{35}} alles war vergeblich. Kurz darauf hielt ein Autofahrer an und fragte, {{36}} er mir helfen könne. Er sagte, dass er Mechaniker sei und gleich in der Nähe wohne. Sofort stieg er aus, {{37}} sich den Motor anzusehen. Nach zehn Minuten fand er den Schaden und {{38}}, dass man einen Teil des Motors austauschen müsse. Dann fuhr er kurz nach Hause und kam eine halbe Stunde später mit dem notwendigen Ersatzteil wieder zurück. Kurz nach Mitternacht war das Auto wieder in Ordnung und ich konnte weiterfahren.\n\nSelbstverständlich wollte ich den netten Mann für seine Mühe belohnen, aber er {{39}} nichts annehmen. Doch möchte ich mich {{40}} auf diese Art und Weise besonders herzlich bei ihm bedanken.",
      "words": {
        "a": "ALS",
        "b": "BESONDERS",
        "c": "DA",
        "d": "DASS",
        "e": "DARÜBER",
        "f": "DAZU",
        "g": "DENN",
        "h": "DOCH",
        "i": "IMMER",
        "j": "MEINTE",
        "k": "OB",
        "l": "SEHR",
        "m": "UM",
        "n": "WENIGSTENS",
        "o": "WOLLTE"
      },
      "answers": {
        "31": {
          "key": "e",
          "note": "traurig sein über -> Pronominaladverb „traurig darüber, wie ...“."
        },
        "32": {
          "key": "b",
          "note": "Nach „ganz“: „freue ich mich ganz besonders über Ihre Artikel“."
        },
        "33": {
          "key": "d",
          "note": "Objektsatz nach „zeigen, dass ...“."
        },
        "34": {
          "key": "a",
          "note": "Einmaliges Ereignis in der Vergangenheit: „Es war bereits 10 Uhr nachts, als mein Auto plötzlich stehen blieb.“"
        },
        "35": {
          "key": "h",
          "note": "Gegensatz: „..., doch (= aber) alles war vergeblich“."
        },
        "36": {
          "key": "k",
          "note": "Indirekter Fragesatz nach „fragte“: „fragte, ob er mir helfen könne“."
        },
        "37": {
          "key": "m",
          "note": "Finalsatz mit Infinitiv: „um sich den Motor anzusehen“."
        },
        "38": {
          "key": "j",
          "note": "Präteritum von „meinen“ (= sagen): „und meinte, dass man ... austauschen müsse“."
        },
        "39": {
          "key": "o",
          "note": "Präteritum von „wollen“: „aber er wollte nichts annehmen“."
        },
        "40": {
          "key": "n",
          "note": "„Doch möchte ich mich wenigstens (= zumindest) auf diese Art herzlich bei ihm bedanken.“"
        }
      }
    },
    {
      "id": "40",
      "num": "40",
      "page": 462,
      "isVariant": false,
      "title": "Hase im Display (SMS-Weltmeister Deutschland)",
      "category": "Kommunikation & Sprache",
      "text": "Mehr als 25 Milliarden SMS (Short Message Service) oder Kurznachrichten wurden im vergangenen Jahr in Deutschland von Handy {{31}} Handy verschickt. Im Durchschnitt sendet jeder Handynutzer in Deutschland eine SMS pro Tag. Damit ist Deutschland unangefochtener SMS-Weltmeister, nicht einmal die US-Amerikaner kommen auch nur annähernd {{32}} das deutsche SMS-Fieber heran.\n\nWo man sich früher Grußkarten oder Briefe schickte, zum Beispiel zu Ostern, Weihnachten oder Neujahr, da drückt man jetzt schnell eine SMS in die Handytastatur und ein paar Minuten später ist {{33}} die Antwort da. Selbst Liebesbriefe sind {{34}} der Mode gekommen. Per SMS verschickt klingen sie vielleicht nicht mehr so romantisch wie früher, dafür aber {{35}} cooler, dynamischer und weltweit vernetzter.\n\nUnd {{36}} muss der verliebte SMS-Casanova durchaus einiges an Kreativität und Schöpferkraft zeigen, wenn er sich der mobilen Kurznachrichten für seinen Liebesschwur bedienen will; {{37}} die Nachrichten dürfen nicht sehr lang sein, da bleibt kaum Platz für Satzzeichen. Abkürzen ist zu einer richtigen Kunst geworden: Nicht mehr „Ich liebe dich“ heißt es, das ist zu lang. Der SMS-Künstler macht {{38}} „ILD“. Und die Dame, auf deren Handydisplay das Wort „Hase“ erscheint, weiß, dass ihr Geliebter ihr gerade „Habe Sehnsucht nach dir“ zuflüstert.\n\nSchlechte Zeiten {{39}} für wahre Liebhaber literarischer Schreibkunst, die seitenweise ihre Gefühle zu Papier bringen und sich gar abmühen mit Fragen nach Versmaß, Rhythmus oder einfach Schönheit der Sprache: Fragen, die beim modischen SMS-Benutzer nur Kopf- und Fingerschütteln hervorbringen. Doch leider hat die schöne neue Technik auch eine Schattenseite. SMS können schnell teuer werden, je nachdem, welche Art von Handyvertrag man hat. Und so mancher SMS-Dauernutzer erlebt dann am Monatsende eine unangenehme Überraschung, wenn er die Rechnung seines Mobilfunkanbieters öffnet. In Zukunft sollen die Preise für SMS möglicherweise {{40}} ansteigen: keine guten Zukunftsaussichten für diese Form der Weltmeisterschaft in Deutschland.",
      "words": {
        "a": "ALSO",
        "b": "AN",
        "c": "AUS",
        "d": "DA",
        "e": "DABEI",
        "f": "DARAUS",
        "g": "DENN",
        "h": "DRASTISCH",
        "i": "HÖHER",
        "j": "NACH",
        "k": "SCHON",
        "l": "SEHR",
        "m": "STATISCH",
        "n": "UMSO",
        "o": "ZU"
      },
      "answers": {
        "31": {
          "key": "o",
          "note": "Feste Verbindung: „von Handy zu Handy“."
        },
        "32": {
          "key": "b",
          "note": "herankommen an (+ Akkusativ): „kommen an das deutsche SMS-Fieber heran“."
        },
        "33": {
          "key": "k",
          "note": "„und ein paar Minuten später ist schon (= bereits) die Antwort da“."
        },
        "34": {
          "key": "c",
          "note": "Feste Wendung: „aus der Mode kommen“."
        },
        "35": {
          "key": "n",
          "note": "Steigerung vor Komparativen („cooler, dynamischer“): „dafür aber umso cooler“."
        },
        "36": {
          "key": "e",
          "note": "„Und dabei (= beim Verfassen von Liebes-SMS) muss der SMS-Casanova Kreativität zeigen.“"
        },
        "37": {
          "key": "g",
          "note": "Kausale Hauptsatzkonjunktion (Verb an Position 2: „dürfen“): „denn“."
        },
        "38": {
          "key": "f",
          "note": "etwas machen aus -> Pronominaladverb „Der SMS-Künstler macht daraus ‚ILD‘.“"
        },
        "39": {
          "key": "a",
          "note": "Schlussfolgerung: „Schlechte Zeiten also für wahre Liebhaber literarischer Schreibkunst“."
        },
        "40": {
          "key": "h",
          "note": "Adverb zu „ansteigen“: „drastisch (= stark) ansteigen“."
        }
      }
    },
    {
      "id": "41",
      "num": "41",
      "page": 463,
      "isVariant": false,
      "title": "Kaffee und Kuchen – ein Stück Tradition",
      "category": "Kulturgeschichte & Alltag",
      "text": "In England zelebriert man um 17 Uhr die Teatime, in Deutschland trifft man sich am Sonntagnachmittag {{31}} Kaffee und Kuchen. Schon unsere Großeltern haben diese Tradition zu schätzen gewusst. {{32}} lange es den Brauch in der uns bekannten Form gibt, ist jedoch nicht bekannt. {{33}} ist nur, dass sich dieses Getränk im 17. Jahrhundert in Europa als Genussmittel verbreitete. {{34}} entstanden zahlreiche Kaffeehäuser – erst in Italien, dann in anderen Ländern. Das erste Café in Deutschland wurde im Jahr 1673 in Bremen eröffnet.\n\nDie Kaffeehäuser begannen schnell, zu dem bitteren Kaffee süße Speisen zu servieren. Dort wurde jedoch nicht nur gespeist und getrunken, {{35}} man konnte in Gesellschaft sein, und es fanden sogar kleine Konzerte statt. So wurde 1732 die berühmte Kaffeekantate {{36}} Johann Sebastian Bach in dem Leipziger Kaffeehaus „Zimmermann“ uraufgeführt.\n\nDas schwarze Getränk war zu dieser Zeit aber noch ein Luxusgut, das sich nur Adelige und wohlhabende Bürger leisten {{37}}. Erst mit der Industrialisierung wurde es für den Großteil der Bevölkerung erschwinglich. 1965 wurde Kaffee zum ersten Mal vor Bier zum Lieblingsgetränk der Deutschen gekürt – und ist es {{38}} heute geblieben.\n\nGegen Ende des 20. Jahrhunderts kam noch einmal Bewegung in die deutsche Kaffeewelt: Spezialitäten {{39}} aller Welt wie Café au Lait oder Latte Macchiato wurden beliebter, die Zubereitungsarten vielfältiger. Der klassischen Filterkaffeemaschine machten seitdem Espressokocher oder Kaffeevollautomaten {{40}} Konkurrenz. Die Auswahl ist also größer geworden, doch die Liebe der Deutschen zu Kaffee und Kuchen bleibt nach wie vor unverändert.",
      "words": {
        "a": "BEI",
        "b": "AN",
        "c": "WIE",
        "d": "SONDERN",
        "e": "DANN",
        "f": "KLAR",
        "g": "ZUR",
        "h": "DAMALS",
        "i": "VON",
        "j": "VIELEN",
        "k": "KONNTEN",
        "l": "BIS",
        "m": "AUS",
        "n": "BEWUNDERE",
        "o": "STARKE"
      },
      "answers": {
        "31": {
          "key": "a",
          "note": "„sich treffen bei Kaffee und Kuchen“."
        },
        "32": {
          "key": "c",
          "note": "Indirekter Fragesatz nach der Zeitdauer: „Wie lange es den Brauch gibt, ist nicht bekannt.“"
        },
        "33": {
          "key": "f",
          "note": "Prädikatives Adjektiv: „Klar (= Sicher) ist nur, dass ...“."
        },
        "34": {
          "key": "h",
          "note": "Bezug auf das 17. Jahrhundert: „Damals entstanden zahlreiche Kaffeehäuser.“"
        },
        "35": {
          "key": "d",
          "note": "„nicht nur gespeist und getrunken, sondern man konnte ...“."
        },
        "36": {
          "key": "i",
          "note": "Urheber eines Werkes: „die berühmte Kaffeekantate von Johann Sebastian Bach“."
        },
        "37": {
          "key": "k",
          "note": "sich etwas leisten können -> Präteritum Plural „leisten konnten“."
        },
        "38": {
          "key": "l",
          "note": "Zeitspanne bis in die Gegenwart: „bis heute geblieben“."
        },
        "39": {
          "key": "m",
          "note": "Feste Wendung: „Spezialitäten aus aller Welt“."
        },
        "40": {
          "key": "o",
          "note": "Adjektiv zu „Konkurrenz“: „starke Konkurrenz“."
        }
      }
    },
    {
      "id": "42",
      "num": "42",
      "page": 464,
      "isVariant": false,
      "title": "Obst und Gemüse (Berliner Großmarkt)",
      "category": "Wirtschaft, Handel & Ernährung",
      "text": "Es ist erst 6 Uhr morgens, und draußen herrscht noch Dunkelheit. {{31}} in der riesigen, hell erleuchteten Halle, in der sich Kisten mit Obst und Gemüse meterhoch stapeln, wird schon lange gearbeitet. „Vor ein paar Stunden war hier noch viel mehr Betrieb“, sagt Jens Rogall. Er {{32}} einen Berliner Großmarkt, auf dem Einkäufer von Supermärkten, Geschäften oder Restaurants frisches Obst und Gemüse besorgen.\n\nDie Ware hat oft schon eine lange Reise zurückgelegt, bis sie auf dem Großmarkt {{33}}. Die meisten Früchte wurden {{34}} auf dem Land-, Luft- oder Seeweg aus wärmeren Ländern nach Deutschland transportiert. Wenn die Ware per Schiff nach Europa gebracht wird, kommt sie in großen Seehäfen wie Rotterdam oder Hamburg an. Von dort aus geht es mit dem Lastwagen weiter. Auf seinem Weg {{35}} das empfindliche Obst und Gemüse keinesfalls Schaden nehmen. „Nichts ist schlimmer {{36}} verdorbene Ware“, sagt Rogall.\n\nAuf dem Großmarkt schauen sich die Käufer alles {{37}} an. Für makellose Salatköpfe, Beeren und Kräuter zahlen sie höhere Preise, krumme Gurken oder verwachsene Kartoffeln {{38}} sie dagegen günstiger. Diese werden später nicht in Geschäften zum Verkauf angeboten, {{39}} direkt verarbeitet. „Es ist egal, wie Gurken aussehen, die ohnehin im Fertigsalat landen“, erklärt Rogall. Wenn die Preisverhandlungen erfolgreich {{40}} sind, werden die Paletten voller Obst und Gemüse hinaus zu den Lieferwagen gebracht. Die Fahrer müssen dann zügig zu den Geschäften und Restaurants fahren, um die Ware abzuliefern.",
      "words": {
        "a": "SONDERN",
        "b": "GENAU",
        "c": "NÄMLICH",
        "d": "ALS",
        "e": "ABGESCHLOSSEN",
        "f": "DARF",
        "g": "ANKOMMT",
        "h": "DOCH",
        "i": "ERWERBEN",
        "j": "LEITET",
        "k": "ZUR",
        "l": "BIS",
        "m": "KONNTEN",
        "n": "BEWUNDERE",
        "o": "SICHER"
      },
      "answers": {
        "31": {
          "key": "h",
          "note": "Gegensatz zu „draußen herrscht noch Dunkelheit“: „Doch (= Aber) in der riesigen Halle wird schon lange gearbeitet.“"
        },
        "32": {
          "key": "j",
          "note": "„Er leitet (= führt) einen Berliner Großmarkt.“"
        },
        "33": {
          "key": "g",
          "note": "Nebensatz mit „bis“: „bis sie auf dem Großmarkt ankommt“."
        },
        "34": {
          "key": "c",
          "note": "Begründende Partikel: „Die meisten Früchte wurden nämlich ... aus wärmeren Ländern transportiert.“"
        },
        "35": {
          "key": "f",
          "note": "Modalverb mit „keinesfalls“: „darf ... keinesfalls Schaden nehmen“."
        },
        "36": {
          "key": "d",
          "note": "Vergleich nach Komparativ: „Nichts ist schlimmer als verdorbene Ware.“"
        },
        "37": {
          "key": "b",
          "note": "Adverb zu „anschauen“: „schauen sich die Käufer alles genau (= gründlich) an“."
        },
        "38": {
          "key": "i",
          "note": "Gehobenes Verb für „kaufen“: „erwerben sie dagegen günstiger“."
        },
        "39": {
          "key": "a",
          "note": "Gegensatz nach „nicht“: „nicht in Geschäften angeboten, sondern direkt verarbeitet“."
        },
        "40": {
          "key": "e",
          "note": "Zustandspassiv: „Wenn die Preisverhandlungen erfolgreich abgeschlossen (= beendet) sind“."
        }
      }
    },
    {
      "id": "43",
      "num": "43",
      "page": 465,
      "isVariant": false,
      "title": "Allein das Wort „Museum“ ist schon fad",
      "category": "Kultur, Jugend & Schule",
      "text": "Museen gelten nach wie vor und trotz aller gegenteiligen Bemühungen gerade unter Jugendlichen als verstaubt und uncool. Oder wie es eine Oberstufenschülerin auf den {{31}} bringt: „Allein das Wort ‚Museum‘ ist schon irgendwie fad.“ Ignoranter Sarkasmus, könnte man meinen, aber enthält diese Einschätzung nicht auch eine Prise Wahrheit?\n\nUm genau diese Vorurteile aus der Welt zu {{32}}, wurde der Aktionstag „Schule schaut Museum“ eingeführt. Über fünfzig Einrichtungen in ganz Österreich sind an diesem Unternehmen beteiligt und bieten spezielle Veranstaltungen für Schüler {{33}}. In Zukunft sollen in Zusammenarbeit mit den Landesschulräten noch {{34}} schulbezogene Veranstaltungen angeboten werden, um das Museum stärker in den Unterricht einzubauen.\n\nGeht es den teilnehmenden Schulklassen {{35}}, Interessantes über unsere Kultur und Geschichte zu erfahren, oder ist der Museumsbesuch nur Mittel {{36}} Zweck, um dem Schulalltag zu {{37}}? Woran liegt es, dass viele Schüler nach Ende eines Rundgangs gar nicht sagen können, {{38}} das zuvor Gesehene handelt?\n\nObwohl Jugendliche in ganz Österreich von speziellen Vergünstigungen profitieren, gehen sie nur selten ins Museum. Liegt es allein {{39}} Unwillen der jungen Bevölkerung, sich der Kultur zu widmen? Vielleicht ist einer der Gründe auch darin zu finden, dass bei der Auswahl des Programms {{40}} die Vorlieben der Pädagogen als diejenigen der Schüler zählen. Fragt man die Jugendlichen selbst, woran sie Interesse hätten, kommen hauptsächlich Wünsche nach interaktiven und multimedialen Ausstellungen. Dazu gibt es genug spannende Projekte, bei denen die Grenzen zwischen Kunst, Medien und Alltag verschwimmen und welche die Schüler durchaus begeistern können.",
      "words": {
        "a": "AM",
        "b": "AN",
        "c": "BRINGEN",
        "d": "DARIN",
        "e": "DARUM",
        "f": "EHER",
        "g": "ENTGEHEN",
        "h": "GIPFEL",
        "i": "LIEFERN",
        "j": "PUNKT",
        "k": "SCHAFFEN",
        "l": "WEITERE",
        "m": "WOMIT",
        "n": "WOVON",
        "o": "ZUM"
      },
      "answers": {
        "31": {
          "key": "j",
          "note": "Feste Redewendung: „etwas auf den Punkt bringen“."
        },
        "32": {
          "key": "k",
          "note": "Feste Redewendung: „etwas aus der Welt schaffen“ (= beseitigen)."
        },
        "33": {
          "key": "b",
          "note": "Trennbares Verb „anbieten“: „bieten spezielle Veranstaltungen für Schüler an“."
        },
        "34": {
          "key": "l",
          "note": "Adjektiv im Nominativ Plural: „noch weitere (= zusätzliche) schulbezogene Veranstaltungen“."
        },
        "35": {
          "key": "e",
          "note": "es geht um -> Pronominaladverb „Geht es den Schulklassen darum, ... zu erfahren?“"
        },
        "36": {
          "key": "o",
          "note": "Feste Redewendung: „Mittel zum Zweck“."
        },
        "37": {
          "key": "g",
          "note": "Verb mit Dativ: „dem Schulalltag zu entgehen (= entfliehen)“."
        },
        "38": {
          "key": "n",
          "note": "handeln von -> Interrogativadverb „wovon das zuvor Gesehene handelt“."
        },
        "39": {
          "key": "a",
          "note": "liegen an (+ Dativ Maskulinum „dem Unwillen“): „Liegt es allein am Unwillen ...?“"
        },
        "40": {
          "key": "f",
          "note": "Komparativstruktur „eher ... als ...“: „eher die Vorlieben der Pädagogen als diejenigen der Schüler“."
        }
      }
    },
    {
      "id": "44",
      "num": "44",
      "page": 466,
      "isVariant": false,
      "title": "Klimawandel lässt in den Alpen neue Seen entstehen",
      "category": "Klima, Umwelt & Alpenraum",
      "text": "Gletscherschmelze, Überschwemmungen, Steinschlag: Der Klimawandel bringt Extreme – mit drastischen Folgen für den Alpenraum.\n\nSchmutzig weiß zieht sich der Rest einer Skipiste durch grüne Wiesen: Schon {{31}} Ostern ist vielerorts in den Nordalpen die Wintersportsaison beendet. Der milde Winter scheint manchen Menschen ein Vorgeschmack auf den Klimawandel zu sein. Doch einige Experten warnen, das Wetter {{32}} Jahre als Hinweis auf die Erwärmung zu betrachten. Der Klimawandel bringt nach Ansicht {{33}} Forscher nicht einfach milderes Wetter, {{34}} vor allem mehr Extreme mit Stürmen, Fluten und Dürren. Das Ausmaß der Extreme ist demnach kaum einschätzbar. In den Alpen werden die Durchschnittstemperaturen bis 2100 je nach Klimaschutz und Modellrechnung um wenige bis einige Grad {{35}}. Die Folgen: grüne Almen statt Skipisten, Regen statt Schnee, Steinschlag und schwindende Gletscher.\n\n{{36}} die Gletscher gerade erst schmelzen, entstehen derzeit neue Seen; 500 könnten es in der Schweiz bis Ende des Jahrhunderts sein. Blaues Wasser in blitzendem Eis: schön – und gefährlich. Vielerorts wurden Schutzbauten errichtet – {{37}} die Seen sich sturzbachartig entladen. In den Alpen kommt es zu weiteren {{38}} Situationen. Im extrem heißen Sommer 2003 häuften sich Steinschlag und Bergstürze. Eis, das die Felsen zusammenhält, indem es das Eindringen von Wasser verhindert, taut. Liftanlagen, einst auf eishartem Boden gebaut, gleiten. Hütten {{39}} Risse. Steinschlag und Muren häufen sich. Felsen rutschen. Der Gipfel des Hohen Sonnblicks in Österreich ist sogar eigens mit Beton {{40}} worden.",
      "words": {
        "a": "BEKOMMEN",
        "b": "BEDROHLICHEN",
        "c": "BEFESTIGT",
        "d": "BESCHWERLICH",
        "e": "VOR",
        "f": "DA",
        "g": "SINKEN",
        "h": "GLEITEN",
        "i": "ZU",
        "j": "VIELER",
        "k": "EINZELNER",
        "l": "KEINER",
        "m": "STEIGEN",
        "n": "FALLS",
        "o": "SONDERN"
      },
      "answers": {
        "31": {
          "key": "e",
          "note": "Zeitangabe: „Schon vor Ostern ist vielerorts die Wintersportsaison beendet.“"
        },
        "32": {
          "key": "k",
          "note": "Genitiv Plural: „das Wetter einzelner Jahre“ (ein einzelnes Jahr beweist noch keinen Klimatrend)."
        },
        "33": {
          "key": "j",
          "note": "Genitiv Plural nach „nach Ansicht“: „nach Ansicht vieler Forscher“."
        },
        "34": {
          "key": "o",
          "note": "Gegensatz nach „nicht einfach“: „nicht einfach milderes Wetter, sondern vor allem mehr Extreme“."
        },
        "35": {
          "key": "m",
          "note": "Durch die Erwärmung werden die Durchschnittstemperaturen „steigen“."
        },
        "36": {
          "key": "f",
          "note": "Kausale Nebensatzkonjunktion (im PDF S. 466 Nr. 6 = h/f „da“): „Da die Gletscher gerade erst schmelzen, entstehen neue Seen.“"
        },
        "37": {
          "key": "n",
          "note": "Konditionale Konjunktion für den Ernstfall: „Schutzbauten wurden errichtet – falls die Seen sich sturzbachartig entladen.“"
        },
        "38": {
          "key": "b",
          "note": "Dativ Plural nach „zu weiteren“: „zu weiteren bedrohlichen Situationen“."
        },
        "39": {
          "key": "a",
          "note": "Kollokation im Plural: „Hütten bekommen Risse.“"
        },
        "40": {
          "key": "c",
          "note": "Perfekt Passiv: „ist eigens mit Beton befestigt (= gesichert) worden“."
        }
      }
    }
  ]
};
