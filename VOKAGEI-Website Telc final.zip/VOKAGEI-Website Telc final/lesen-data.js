const readingData = {
  "1": [
    {
      "id": "1",
      "title": "Test 1 – Wasser & Klima",
      "isVariant": false,
      "headings": {
        "a": "Limonade aus dem Wasserhahn",
        "b": "Limonade ist moderner als Wasser",
        "c": "Sommer bedeutet in Zukunft nicht unbedingt Sonne",
        "d": "Mehr Sauerstoff im Wasser macht müde Menschen fit",
        "e": "Viel Wasser trinken – Gesundheit tanken",
        "f": "Frische Luft macht stark",
        "g": "Die Sonne macht Landwirten Probleme",
        "h": "Sprudel hausgemacht – Zeit des Flaschen-Tragens ist vorbei",
        "i": "Alarm: Nitrat im Regenwasser bedroht die Gesundheit",
        "j": "Vom Regen zum Mineralwasser"
      },
      "items": [
        {
          "num": 1,
          "text": "Möchten Sie Kraft, Jugend und Gesundheit aus der Flasche? Dann suchen Sie bei Ihrem nächsten Einkauf im Supermarkt nach Sauerstoff-Mineralwasser. Für den etwa doppelten Preis eines normalen Mineralwassers erhalten Sie dann ein Getränk, von dem die Hersteller versprechen, dass es Ihnen – natürlich nur, wenn Sie es regelmäßig trinken – magische Kräfte verleiht. In einer Umfrage wurden Schülerinnen und Schüler in Bayern nach ihren Erfahrungen mit dem Sauerstoffkraftdrink befragt. Die meisten fanden, dass es nicht anders schmeckt als andere Mineralwässer auch. Das Deutsche Institut für Ernährungsforschung in Potsdam hält es für Unsinn, Wasser mit Sauerstoff anzureichern. Der menschliche Körper nimmt Sauerstoff hauptsächlich über die Atemluft auf, höchstens 0,3 % können auch über den Magen-Darm-Trakt aufgenommen werden. Möchten Sie immer noch Kraft, Jugend und Gesundheit? Dann gehen Sie doch einfach mehr an die frische Luft. Und die ist kostenlos.",
          "answer": "f",
          "explanation": "Der Text erklärt, dass mit Sauerstoff angereichertes Wasser Unsinn ist, da der Körper Sauerstoff über die Atemluft aufnimmt, und rät stattdessen dazu, an die frische Luft zu gehen ('Frische Luft macht stark')."
        },
        {
          "num": 2,
          "text": "Wenn es regnet, dann fließt das Regenwasser in den Erdboden, der es wie ein Schwamm aufsaugt. Langsam sickert das Wasser dann in immer tiefere Erdschichten, in denen es gefiltert und gereinigt wird. Aus dem Regenwasser ist Trinkwasser geworden. Schließlich sammelt es sich in einer Schicht aus Sandstein, wo es sich mit älterem Wasser vermischt. Mehrere tausend Jahre lang kann das Trinkwasser so in den Tiefen der Erde ruhen. Durch Brunnen, die bis in die tiefen Sandsteinschichten reichen, kann dann Mineralwasser gewonnen werden. 10,6 Milliarden Liter Mineralwasser sind im letzten Jahr in Deutschland verkauft und getrunken worden. Gesteinsschichten wie Ton oder Kalk schützen es seit Jahrtausenden vor Verunreinigungen. Jedoch gelangt in den letzten Jahrzehnten Nitrat durch übermäßige Düngung in der Landwirtschaft vermehrt in das Trinkwasser und stellt langfristig eine Gesundheitsbedrohung für die Menschen dar.",
          "answer": "j",
          "explanation": "Der Text beschreibt den Weg des Regenwassers durch die Erdschichten bis zur Gewinnung als Mineralwasser ('Vom Regen zum Mineralwasser')."
        },
        {
          "num": 3,
          "text": "Nach den Unwettern der letzten Sommer sprechen Meteorologen in ganz Europa davon, dass sich das Klima weltweit dramatisch verändert. Stabile Sommer mit Sonnenschein pur von Juni bis August sollen selbst am Mittelmeer in Zukunft passé sein. Die durch Treibhausgase aufgeheizte Atmosphäre hat sich erwärmt, mehr Wasser verdunstet durch die höheren Temperaturen aus den Ozeanen und prasselt in extrem starken Unwettern mit Donner, Blitz und Hagel auf die Erde. Dort kann die Erde nicht mehr solche Mengen Wassers aufnehmen, wie in kürzester Zeit fallen. Die Folge davon sind Überschwemmungen. Kurze Sonnenscheinperioden werden sich mit Unwetterfronten abwechseln und vielen Menschen den Badespaß an den Stränden nicht nur des Mittelmeeres gründlich verderben. Doch auch den Landwirten bereiten die stärkeren Unwetter Sorgen. Denn die starken Niederschläge mit Hagel zerstören nicht selten einen großen Teil der Ernte und bescheren so manchen landwirtschaftlichen Betrieben große finanzielle Probleme.",
          "answer": "c",
          "explanation": "Laut Meteorologen gehören stabile, sonnige Sommer künftig der Vergangenheit an und wechseln sich mit starken Unwettern ab ('Sommer bedeutet in Zukunft nicht unbedingt Sonne')."
        },
        {
          "num": 4,
          "text": "Wozu noch Kästen mit Mineralwasserflaschen nach Hause schleppen, wenn es sich doch bequem zu Hause zubereiten lässt? Tatsächlich ist das Leitungswasser, das aus den Wasserhähnen in deutschen Wohnungen fließt, von guter bis sehr guter Qualität. Einzig das Prickeln auf der Zunge, das durch das Hinzufügen von Kohlensäure in viele Mineralwässer entsteht, fehlt bei dem Leitungswasser. Doch auch hier gibt es bereits eine preiswerte Möglichkeit, dies selbst zu tun: mit einer Sodamaschine. Damit lassen sich Sprudel und Limonaden selbst herstellen, ganz nach dem individuellen Geschmack des Nutzers: mal mit mehr, mal mit weniger Prickeln, mal süßer, mal fruchtiger. Und das Wasser kommt wie von selbst ins Haus, das Tragen und Stapeln von Getränkekästen ist für den cleveren Selbsthersteller Vergangenheit.",
          "answer": "h",
          "explanation": "Mit einer Sodamaschine lässt sich Sprudelwasser bequem zu Hause aus Leitungswasser herstellen, sodass man keine Getränkekästen mehr schleppen muss ('Sprudel hausgemacht – Zeit des Flaschen-Tragens ist vorbei')."
        },
        {
          "num": 5,
          "text": "„Wasser ist zum Waschen da“ lautete ein deutscher Schlager Mitte der 1950er, in dem es weiter hieß: „Auch zum Zähneputzen kann man es benutzen.“ Wasser zu trinken schien damals manchen Leuten nicht in die neue Wohlstandswelt zu passen. Süße Limonaden galten als besser als einfach nur Wasser. Dabei raten heute die meisten Ärzte zum Wassertrinken: „Trinken Sie täglich mindestens 2,5 Liter davon“, steht auch in nahezu allen medizinischen Ratgebern von heute. Mineralwasser hat, wie man heute wieder weiß, durch seine mineralischen Inhaltsstoffe Natrium, Kalium, Magnesium, Calcium und Spurenelemente für den menschlichen Körper viele Vorteile: Es gleicht den Mineral- und Flüssigkeitsverlust beim Schwitzen aus, es fördert die Verdauung und das alles ohne den Körper belastenden Zucker und ohne Kalorien. Ob aus der Heimat oder – wie in den jetzt modischen Wasserbars – von der Insel Hawaii oder vom Südpol: Wasser ist wieder zum Trinken da.",
          "answer": "e",
          "explanation": "Ärzte empfehlen heute, täglich mindestens 2,5 Liter Wasser zu trinken, da seine Mineralstoffe viele gesundheitliche Vorteile bieten ('Viel Wasser trinken – Gesundheit tanken')."
        }
      ]
    },
    {
      "id": "1a",
      "title": "Test 1a – Wasser & Klima (Variante 1)",
      "isVariant": true,
      "headings": {
        "a": "Alarm: Nitrat im Regenwasser bedroht die Gesundheit",
        "b": "Die Sonne macht Landwirten Probleme",
        "c": "Frische Luft als wahre Energiequelle",
        "d": "Limonade – als modernes Kultgetränk wieder im Trend",
        "e": "Limonade aus dem Wasserhahn",
        "f": "Mehr Sauerstoff im Sprudel macht fit",
        "g": "Sommer bedeutet in Zukunft nicht unbedingt Sonne",
        "h": "Sprudel hausgemacht – Zeit des Flaschen-Tragens ist vorbei",
        "i": "Viel Wasser trinken – Gesundheit tanken",
        "j": "Vom Regen zum Mineralwasser"
      },
      "items": [
        {
          "num": 1,
          "text": "Möchten Sie Kraft, Jugend und Gesundheit aus der Flasche? Dann suchen Sie bei Ihrem nächsten Einkauf im Supermarkt nach Sauerstoff-Mineralwasser. Für den etwa doppelten Preis eines normalen Mineralwassers erhalten Sie dann ein Getränk, von dem die Hersteller versprechen, dass es Ihnen – natürlich nur, wenn Sie es regelmäßig trinken – magische Kräfte verleiht. In einer Umfrage wurden Schülerinnen und Schüler in Bayern nach ihren Erfahrungen mit dem Sauerstoffkraftdrink befragt. Die meisten fanden, dass es nicht anders schmeckt als andere Mineralwässer auch. Das Deutsche Institut für Ernährungsforschung in Potsdam hält es für Unsinn, Wasser mit Sauerstoff anzureichern. Der menschliche Körper nimmt Sauerstoff hauptsächlich über die Atemluft auf, höchstens 0,3 % können auch über den Magen-Darm-Trakt aufgenommen werden. Möchten Sie immer noch Kraft, Jugend und Gesundheit? Dann gehen Sie doch einfach mehr an die frische Luft. Und die ist kostenlos.",
          "answer": "c",
          "explanation": "Der Text erklärt, dass mit Sauerstoff angereichertes Wasser Unsinn ist, da der Körper Sauerstoff über die Atemluft aufnimmt, und rät stattdessen dazu, an die frische Luft zu gehen ('Frische Luft als wahre Energiequelle')."
        },
        {
          "num": 2,
          "text": "Wenn es regnet, dann fließt das Regenwasser in den Erdboden, der es wie ein Schwamm aufsaugt. Langsam sickert das Wasser dann in immer tiefere Erdschichten, in denen es gefiltert und gereinigt wird. Aus dem Regenwasser ist Trinkwasser geworden. Schließlich sammelt es sich in einer Schicht aus Sandstein, wo es sich mit älterem Wasser vermischt. Mehrere tausend Jahre lang kann das Trinkwasser so in den Tiefen der Erde ruhen. Durch Brunnen, die bis in die tiefen Sandsteinschichten reichen, kann dann Mineralwasser gewonnen werden. 10,6 Milliarden Liter Mineralwasser sind im letzten Jahr in Deutschland verkauft und getrunken worden. Gesteinsschichten wie Ton oder Kalk schützen es seit Jahrtausenden vor Verunreinigungen. Jedoch gelangt in den letzten Jahrzehnten Nitrat durch übermäßige Düngung in der Landwirtschaft vermehrt in das Trinkwasser und stellt langfristig eine Gesundheitsbedrohung für die Menschen dar.",
          "answer": "j",
          "explanation": "Der Text beschreibt den Weg des Regenwassers durch die Erdschichten bis zur Gewinnung als Mineralwasser ('Vom Regen zum Mineralwasser')."
        },
        {
          "num": 3,
          "text": "Nach den Unwettern der letzten Sommer sprechen Meteorologen in ganz Europa davon, dass sich das Klima weltweit dramatisch verändert. Stabile Sommer mit Sonnenschein pur von Juni bis August sollen selbst am Mittelmeer in Zukunft passé sein. Die durch Treibhausgase aufgeheizte Atmosphäre hat sich erwärmt, mehr Wasser verdunstet durch die höheren Temperaturen aus den Ozeanen und prasselt in extrem starken Unwettern mit Donner, Blitz und Hagel auf die Erde. Dort kann die Erde nicht mehr solche Mengen Wassers aufnehmen, wie in kürzester Zeit fallen. Die Folge davon sind Überschwemmungen. Kurze Sonnenscheinperioden werden sich mit Unwetterfronten abwechseln und vielen Menschen den Badespaß an den Stränden nicht nur des Mittelmeeres gründlich verderben. Doch auch den Landwirten bereiten die stärkeren Unwetter Sorgen. Denn die starken Niederschläge mit Hagel zerstören nicht selten einen großen Teil der Ernte und bescheren so manchen landwirtschaftlichen Betrieben große finanzielle Probleme.",
          "answer": "g",
          "explanation": "Laut Meteorologen gehören stabile, sonnige Sommer künftig der Vergangenheit an und wechseln sich mit starken Unwettern ab ('Sommer bedeutet in Zukunft nicht unbedingt Sonne')."
        },
        {
          "num": 4,
          "text": "Wozu noch Kästen mit Mineralwasserflaschen nach Hause schleppen, wenn es sich doch bequem zu Hause zubereiten lässt? Tatsächlich ist das Leitungswasser, das aus den Wasserhähnen in deutschen Wohnungen fließt, von guter bis sehr guter Qualität. Einzig das Prickeln auf der Zunge, das durch das Hinzufügen von Kohlensäure in viele Mineralwässer entsteht, fehlt bei dem Leitungswasser. Doch auch hier gibt es bereits eine preiswerte Möglichkeit, dies selbst zu tun: mit einer Sodamaschine. Damit lassen sich Sprudel und Limonaden selbst herstellen, ganz nach dem individuellen Geschmack des Nutzers: mal mit mehr, mal mit weniger Prickeln, mal süßer, mal fruchtiger. Und das Wasser kommt wie von selbst ins Haus, das Tragen und Stapeln von Getränkekästen ist für den cleveren Selbsthersteller Vergangenheit.",
          "answer": "h",
          "explanation": "Mit einer Sodamaschine lässt sich Sprudelwasser bequem zu Hause aus Leitungswasser herstellen, sodass man keine Getränkekästen mehr schleppen muss ('Sprudel hausgemacht – Zeit des Flaschen-Tragens ist vorbei')."
        },
        {
          "num": 5,
          "text": "„Wasser ist zum Waschen da“ lautete ein deutscher Schlager Mitte der 1950er, in dem es weiter hieß: „Auch zum Zähneputzen kann man es benutzen.“ Wasser zu trinken schien damals manchen Leuten nicht in die neue Wohlstandswelt zu passen. Süße Limonaden galten als besser als einfach nur Wasser. Dabei raten heute die meisten Ärzte zum Wassertrinken: „Trinken Sie täglich mindestens 2,5 Liter davon“, steht auch in nahezu allen medizinischen Ratgebern von heute. Mineralwasser hat, wie man heute wieder weiß, durch seine mineralischen Inhaltsstoffe Natrium, Kalium, Magnesium, Calcium und Spurenelemente für den menschlichen Körper viele Vorteile: Es gleicht den Mineral- und Flüssigkeitsverlust beim Schwitzen aus, es fördert die Verdauung und das alles ohne den Körper belastenden Zucker und ohne Kalorien. Ob aus der Heimat oder – wie in den jetzt modischen Wasserbars – von der Insel Hawaii oder vom Südpol: Wasser ist wieder zum Trinken da.",
          "answer": "i",
          "explanation": "Ärzte empfehlen heute, täglich mindestens 2,5 Liter Wasser zu trinken, da seine Mineralstoffe viele gesundheitliche Vorteile bieten ('Viel Wasser trinken – Gesundheit tanken')."
        }
      ]
    },
    {
      "id": "1b",
      "title": "Test 1b – Wasser & Klima (Variante 2)",
      "isVariant": true,
      "headings": {
        "a": "Vom Regen zum Mineralwasser",
        "b": "Viel Wasser trinken – Gesundheit tanken",
        "c": "Sprudel hausgemacht – Zeit des Flaschen-Tragens ist vorbei",
        "d": "Sommer bedeutet in Zukunft nicht unbedingt Sonne",
        "e": "Mehr Sauerstoff im Sprudel macht fit",
        "f": "Limonade aus dem Wasserhahn",
        "g": "Limonade – als modernes Kultgetränk wieder im Trend",
        "h": "Frische Luft als wahre Energiequelle",
        "i": "Die Sonne macht Landwirten Probleme",
        "j": "Alarm: Nitrat im Regenwasser bedroht die Gesundheit"
      },
      "items": [
        {
          "num": 1,
          "text": "Möchten Sie Kraft, Jugend und Gesundheit aus der Flasche? Dann suchen Sie bei Ihrem nächsten Einkauf im Supermarkt nach Sauerstoff-Mineralwasser. Für den etwa doppelten Preis eines normalen Mineralwassers erhalten Sie dann ein Getränk, von dem die Hersteller versprechen, dass es Ihnen – natürlich nur, wenn Sie es regelmäßig trinken – magische Kräfte verleiht. In einer Umfrage wurden Schülerinnen und Schüler in Bayern nach ihren Erfahrungen mit dem Sauerstoffkraftdrink befragt. Die meisten fanden, dass es nicht anders schmeckt als andere Mineralwässer auch. Das Deutsche Institut für Ernährungsforschung in Potsdam hält es für Unsinn, Wasser mit Sauerstoff anzureichern. Der menschliche Körper nimmt Sauerstoff hauptsächlich über die Atemluft auf, höchstens 0,3 % können auch über den Magen-Darm-Trakt aufgenommen werden. Möchten Sie immer noch Kraft, Jugend und Gesundheit? Dann gehen Sie doch einfach mehr an die frische Luft. Und die ist kostenlos.",
          "answer": "h",
          "explanation": "Der Text erklärt, dass mit Sauerstoff angereichertes Wasser Unsinn ist, da der Körper Sauerstoff über die Atemluft aufnimmt, und rät stattdessen dazu, an die frische Luft zu gehen ('Frische Luft als wahre Energiequelle')."
        },
        {
          "num": 2,
          "text": "Wenn es regnet, dann fließt das Regenwasser in den Erdboden, der es wie ein Schwamm aufsaugt. Langsam sickert das Wasser dann in immer tiefere Erdschichten, in denen es gefiltert und gereinigt wird. Aus dem Regenwasser ist Trinkwasser geworden. Schließlich sammelt es sich in einer Schicht aus Sandstein, wo es sich mit älterem Wasser vermischt. Mehrere tausend Jahre lang kann das Trinkwasser so in den Tiefen der Erde ruhen. Durch Brunnen, die bis in die tiefen Sandsteinschichten reichen, kann dann Mineralwasser gewonnen werden. 10,6 Milliarden Liter Mineralwasser sind im letzten Jahr in Deutschland verkauft und getrunken worden. Gesteinsschichten wie Ton oder Kalk schützen es seit Jahrtausenden vor Verunreinigungen. Jedoch gelangt in den letzten Jahrzehnten Nitrat durch übermäßige Düngung in der Landwirtschaft vermehrt in das Trinkwasser und stellt langfristig eine Gesundheitsbedrohung für die Menschen dar.",
          "answer": "a",
          "explanation": "Der Text beschreibt den Weg des Regenwassers durch die Erdschichten bis zur Gewinnung als Mineralwasser ('Vom Regen zum Mineralwasser')."
        },
        {
          "num": 3,
          "text": "Nach den Unwettern der letzten Sommer sprechen Meteorologen in ganz Europa davon, dass sich das Klima weltweit dramatisch verändert. Stabile Sommer mit Sonnenschein pur von Juni bis August sollen selbst am Mittelmeer in Zukunft passé sein. Die durch Treibhausgase aufgeheizte Atmosphäre hat sich erwärmt, mehr Wasser verdunstet durch die höheren Temperaturen aus den Ozeanen und prasselt in extrem starken Unwettern mit Donner, Blitz und Hagel auf die Erde. Dort kann die Erde nicht mehr solche Mengen Wassers aufnehmen, wie in kürzester Zeit fallen. Die Folge davon sind Überschwemmungen. Kurze Sonnenscheinperioden werden sich mit Unwetterfronten abwechseln und vielen Menschen den Badespaß an den Stränden nicht nur des Mittelmeeres gründlich verderben. Doch auch den Landwirten bereiten die stärkeren Unwetter Sorgen. Denn die starken Niederschläge mit Hagel zerstören nicht selten einen großen Teil der Ernte und bescheren so manchen landwirtschaftlichen Betrieben große finanzielle Probleme.",
          "answer": "d",
          "explanation": "Laut Meteorologen gehören stabile, sonnige Sommer künftig der Vergangenheit an und wechseln sich mit starken Unwettern ab ('Sommer bedeutet in Zukunft nicht unbedingt Sonne')."
        },
        {
          "num": 4,
          "text": "Wozu noch Kästen mit Mineralwasserflaschen nach Hause schleppen, wenn es sich doch bequem zu Hause zubereiten lässt? Tatsächlich ist das Leitungswasser, das aus den Wasserhähnen in deutschen Wohnungen fließt, von guter bis sehr guter Qualität. Einzig das Prickeln auf der Zunge, das durch das Hinzufügen von Kohlensäure in viele Mineralwässer entsteht, fehlt bei dem Leitungswasser. Doch auch hier gibt es bereits eine preiswerte Möglichkeit, dies selbst zu tun: mit einer Sodamaschine. Damit lassen sich Sprudel und Limonaden selbst herstellen, ganz nach dem individuellen Geschmack des Nutzers: mal mit mehr, mal mit weniger Prickeln, mal süßer, mal fruchtiger. Und das Wasser kommt wie von selbst ins Haus, das Tragen und Stapeln von Getränkekästen ist für den cleveren Selbsthersteller Vergangenheit.",
          "answer": "c",
          "explanation": "Mit einer Sodamaschine lässt sich Sprudelwasser bequem zu Hause aus Leitungswasser herstellen, sodass man keine Getränkekästen mehr schleppen muss ('Sprudel hausgemacht – Zeit des Flaschen-Tragens ist vorbei')."
        },
        {
          "num": 5,
          "text": "„Wasser ist zum Waschen da“ lautete ein deutscher Schlager Mitte der 1950er, in dem es weiter hieß: „Auch zum Zähneputzen kann man es benutzen.“ Wasser zu trinken schien damals manchen Leuten nicht in die neue Wohlstandswelt zu passen. Süße Limonaden galten als besser als einfach nur Wasser. Dabei raten heute die meisten Ärzte zum Wassertrinken: „Trinken Sie täglich mindestens 2,5 Liter davon“, steht auch in nahezu allen medizinischen Ratgebern von heute. Mineralwasser hat, wie man heute wieder weiß, durch seine mineralischen Inhaltsstoffe Natrium, Kalium, Magnesium, Calcium und Spurenelemente für den menschlichen Körper viele Vorteile: Es gleicht den Mineral- und Flüssigkeitsverlust beim Schwitzen aus, es fördert die Verdauung und das alles ohne den Körper belastenden Zucker und ohne Kalorien. Ob aus der Heimat oder – wie in den jetzt modischen Wasserbars – von der Insel Hawaii oder vom Südpol: Wasser ist wieder zum Trinken da.",
          "answer": "b",
          "explanation": "Ärzte empfehlen heute, täglich mindestens 2,5 Liter Wasser zu trinken, da seine Mineralstoffe viele gesundheitliche Vorteile bieten ('Viel Wasser trinken – Gesundheit tanken')."
        }
      ]
    },
    {
      "id": "2",
      "title": "Test 2 – Nachwuchs, Technik & Berufsorientierung",
      "isVariant": false,
      "headings": {
        "a": "Immer mehr Jugendliche werden Programmierer",
        "b": "Automobilindustrie schafft neue Arbeitsplätze",
        "c": "Diskussion über schulische Berufsorientierung",
        "d": "Förderwochenende für junge Softwareentwickler",
        "e": "Frauen in technischen Berufen werden stärker gefördert",
        "f": "Spannende Gewinne für wissenschaftliche Nachwuchstalente",
        "g": "Mehr Bemühungen um weiblichen Nachwuchs gefordert",
        "h": "Verleihung des Jugendnobelpreises in Stockholm",
        "i": "Berufswahl: Jugendliche werden stark von ihrem gesellschaftlichen Umfeld geprägt",
        "j": "Studienabsolventen technischer Fächer sehen ihre Zukunft meist in der Automobilindustrie"
      },
      "items": [
        {
          "num": 1,
          "text": "Martina Lux hat ein Hobby, mit dem sie im Kreis ihrer Freundinnen ziemlich allein steht: Sie programmiert in ihrer Freizeit. „Mich hat immer schon interessiert, wie Computerprogramme eigentlich funktionieren“, sagt die 17-Jährige. Außerdem habe sie großen Spaß an logischem Denken. Ihr Informatiklehrer erzählte ihr von einem Workshop in Berlin: Bei „Jugend programmiert“ traf Martina von letztem Freitag bis Sonntag mit gleichgesinnten Jungen und Mädchen zwischen zwölf und 18 Jahren zusammen, um gemeinsam Programme zu entwickeln. Dabei standen ihnen erfahrene Informatiker zur Seite. In 15 Gruppen entwickelten die jungen Nachwuchsprogrammierer ihre Projekte. Eine Jury verlieh Preise in vier Kategorien. Bewertet wurden die originellste Idee, die sauberste Umsetzung, die beste Präsentation und die größte Relevanz für die Gesellschaft. Martinas Gruppe erhielt zwar keinen Preis, aber das Wochenende hat sich für sie auf jeden Fall gelohnt. Sie hat zwei Mädchen kennengelernt, mit denen sie auch in Zukunft gemeinsam programmieren möchte. Zu wissen, dass sie nicht allein ist mit ihrem Hobby, das ist für sie ein besonders wichtiges Ergebnis dieses Wochenendes, meint Martina.",
          "answer": "d",
          "explanation": "Der Text berichtet über den dreitägigen Berliner Workshop „Jugend programmiert“ von Freitag bis Sonntag, bei dem Jugendliche gemeinsam Software entwickelten ('Förderwochenende für junge Softwareentwickler')."
        },
        {
          "num": 2,
          "text": "„Jugend forscht“ ist ein bundesweiter Nachwuchswettbewerb für junge Menschen bis zum Alter von 21 Jahren, bei dem besondere Leistungen in Mathematik, Technik, Naturwissenschaften und Informatik ausgezeichnet werden. Neben Geldpreisen werden auch einige Sonderpreise vergeben, die bei den Jugendlichen ganz besonders begehrt sind. Dazu gehört die Teilnahme an internationalen Wettbewerben, bei denen die jungen Forscher Fachleuten aus aller Welt ihre Projekte vorstellen können. Auch Einladungen zu Studienreisen und Kongressen im Ausland sind für viele Teilnehmer besonders attraktiv. Im Rahmen von „Jugend forscht“ wird sogar eine Reise zur Nobelpreisverleihung in Stockholm angeboten. Im Inland haben die Preisträger die Möglichkeit, ein langes Praktikum an angesehenen Forschungsinstituten und bei wichtigen Unternehmen zu absolvieren. Dort bekommen die Jugendlichen im Arbeitsalltag eine gute Vorstellung davon, wie Forschungsarbeit funktioniert. Zusätzlich gibt es auch Abonnements für technische und naturwissenschaftliche Fachzeitschriften zu gewinnen. Auch Schulen und Projektbetreuer können teilnehmen. Bei diesem Wettbewerb haben junge Menschen die Möglichkeit, wertvolle Erfahrungen mit Forschungsprojekten zu sammeln. Mitmachen lohnt sich auf jeden Fall.",
          "answer": "f",
          "explanation": "Im Mittelpunkt stehen die attraktiven Geld- und Sonderpreise (Studienreisen, Praktika, Reise nach Stockholm) beim Wettbewerb „Jugend forscht“ ('Spannende Gewinne für wissenschaftliche Nachwuchstalente')."
        },
        {
          "num": 3,
          "text": "Die Industriellenvereinigung beklagt in einer jüngsten Pressemitteilung den deutlichen Mangel an Fachkräften in den Naturwissenschaften und den technischen Berufen. Dieser Fachkräftemangel sei besonders ausgeprägt in den Bereichen Maschinenbau, Elektrotechnik, Werkstoffwissenschaften und Verfahrenstechnik, heißt es in dem Papier. Um dem entgegenzusteuern, ruft die Industriellenvereinigung unter anderem dazu auf, insbesondere Mädchen und junge Frauen für solche Berufe zu gewinnen. Die Berufsorientierung der Schulen müsse noch gezielter auf die vielfältigen und interessanten Themenfelder sowie die guten Zukunftschancen technischer Berufe hinweisen. Erfolgreiche Frauen aus diesen Bereichen sollten sich zudem verstärkt als Vorbilder für Schülerinnen präsentieren. In diesem Zusammenhang wird in der Pressemitteilung auch an die Möglichkeit erinnert, am bevorstehenden bundesweiten Mädchenzukunftstag „Girls' Day“ an den Standorten namhafter Firmen Einblicke in den Arbeitsalltag in technischen Berufen zu bekommen. Die Industriellenvereinigung fordert die Unternehmen und Organisationen auf, ihre Türen für potenzielle Talente zu öffnen und sich Fachkräfte für die Zukunft zu sichern.",
          "answer": "g",
          "explanation": "Die Industriellenvereinigung ruft Schulen und Unternehmen dazu auf, gezielter Mädchen und junge Frauen für technische Berufe zu gewinnen ('Mehr Bemühungen um weiblichen Nachwuchs gefordert')."
        },
        {
          "num": 4,
          "text": "Im Kulturzentrum war gestern Abend Tobias Meyer zu Gast. Die Organisatoren hatten den bekannten Autor zahlreicher Sachbücher über Erziehung und Bildung eingeladen, zum Thema Berufsorientierung zu sprechen. In seinem Vortrag ging Meyer auf zwei wesentliche Aspekte von Berufsorientierung ein. Zum einen versteht er Berufsorientierung als eine Entwicklung, die eng mit den persönlichen und sozialen Beziehungen eines jungen Menschen zusammenhängt. Die Orientierung auf einen Beruf hin wertet er als einen Teil der Persönlichkeitsentwicklung. In engem Zusammenhang damit sieht er die Berufsvorbilder, an denen sich Jugendliche orientieren: Diese hängen ebenso wie die Erwartungen, die an einen Beruf gestellt würden, stark von der sozialen Umgebung ab. Zudem spielten lokale wirtschaftliche Umstände eine Rolle bei der Berufsorientierung. Meyer zeigte anhand konkreter Beispiele, wie große Unternehmen vor Ort die Berufswahl junger Menschen entscheidend beeinflussen können. Anschließend ging Meyer auf einen zweiten wesentlichen Aspekt, nämlich Berufsorientierung im Rahmen der Schulen, ein. Hier könnten entscheidende Impulse gesetzt werden, indem Talente und Stärken erkannt und bereits sehr früh gefördert würden.",
          "answer": "i",
          "explanation": "Laut Tobias Meyers Vortrag hängt die Berufsorientierung Jugendlicher stark von persönlichen Beziehungen, Vorbildern und der sozialen sowie lokalen wirtschaftlichen Umgebung ab ('Berufswahl: Jugendliche werden stark von ihrem gesellschaftlichen Umfeld geprägt')."
        },
        {
          "num": 5,
          "text": "Wie eine repräsentative Umfrage unter Studenten kürzlich zeigte, erfreut sich die Automobilindustrie nach wie vor großer Beliebtheit bei Studierenden der Fachgebiete Wirtschaft und Technik. Gefragt nach den fünf attraktivsten zukünftigen Arbeitgebern, nannten Wirtschaftsstudenten vier führende Automobilkonzerne und eine Internet-Suchmaschine; künftige Ingenieure nannten sogar ausschließlich Automobilunternehmen. Auch für Studenten der Informatik gewinnt die Automobilindustrie zunehmend an Attraktivität – wenig verwunderlich angesichts der rasch zunehmenden Bedeutung, die der Elektronik in Fahrzeugen zukommt. Die Branche punktet bei jungen Absolventen mit vielen spannenden Themen: Wie wird die Mobilität der Zukunft aussehen? Welche alternativen Antriebe wird es geben? Die Automobilindustrie bietet viel Raum für Innovationen und somit gute Chancen für motivierte Berufseinsteiger. Doch ausschlaggebend sind nicht nur solide Berufsaussichten. Wie die Befragung ergab, spielt auch der emotionale Faktor eine Rolle: Viele Studierende sind einfach begeistert vom Thema Auto.",
          "answer": "j",
          "explanation": "Einer Umfrage zufolge nennen angehende Ingenieure ausschließlich Automobilunternehmen als attraktivste Arbeitgeber ('Studienabsolventen technischer Fächer sehen ihre Zukunft meist in der Automobilindustrie')."
        }
      ]
    },
    {
      "id": "2a",
      "title": "Test 2a – Nachwuchs & Technik (Variante 1)",
      "isVariant": true,
      "headings": {
        "a": "Automobilindustrie schafft neue Arbeitsplätze",
        "b": "Berufswahl: Jugendliche werden stark von ihrem gesellschaftlichen Umfeld geprägt",
        "c": "Diskussion über schulische Berufsorientierung",
        "d": "Förderwochenende für junge Softwareentwickler",
        "e": "Immer mehr Frauen ergreifen technische Berufe",
        "f": "Immer mehr Jugendliche werden Programmierer",
        "g": "Mehr Bemühungen um weiblichen Nachwuchs gefordert",
        "h": "Spannende Gewinne für wissenschaftliche Nachwuchstalente",
        "i": "Studienabsolventen technischer Fächer sehen ihre Zukunft meist in der Fahrzeugbranche",
        "j": "Verleihung des Jugendnobelpreises in Stockholm"
      },
      "items": [
        {
          "num": 1,
          "text": "Martina Lux hat ein Hobby, mit dem sie im Kreis ihrer Freundinnen ziemlich allein steht: Sie programmiert in ihrer Freizeit. „Mich hat immer schon interessiert, wie Computerprogramme eigentlich funktionieren“, sagt die 17-Jährige. Außerdem habe sie großen Spaß an logischem Denken. Ihr Informatiklehrer erzählte ihr von einem Workshop in Berlin: Bei „Jugend programmiert“ traf Martina von letztem Freitag bis Sonntag mit gleichgesinnten Jungen und Mädchen zwischen zwölf und 18 Jahren zusammen, um gemeinsam Programme zu entwickeln. Dabei standen ihnen erfahrene Informatiker zur Seite. In 15 Gruppen entwickelten die jungen Nachwuchsprogrammierer ihre Projekte. Eine Jury verlieh Preise in vier Kategorien. Bewertet wurden die originellste Idee, die sauberste Umsetzung, die beste Präsentation und die größte Relevanz für die Gesellschaft. Martinas Gruppe erhielt zwar keinen Preis, aber das Wochenende hat sich für sie auf jeden Fall gelohnt. Sie hat zwei Mädchen kennengelernt, mit denen sie auch in Zukunft gemeinsam programmieren möchte. Zu wissen, dass sie nicht allein ist mit ihrem Hobby, das ist für sie ein besonders wichtiges Ergebnis dieses Wochenendes, meint Martina.",
          "answer": "d",
          "explanation": "Der Text berichtet über den dreitägigen Berliner Workshop „Jugend programmiert“ von Freitag bis Sonntag, bei dem Jugendliche gemeinsam Software entwickelten ('Förderwochenende für junge Softwareentwickler')."
        },
        {
          "num": 2,
          "text": "„Jugend forscht“ ist ein bundesweiter Nachwuchswettbewerb für junge Menschen bis zum Alter von 21 Jahren, bei dem besondere Leistungen in Mathematik, Technik, Naturwissenschaften und Informatik ausgezeichnet werden. Neben Geldpreisen werden auch einige Sonderpreise vergeben, die bei den Jugendlichen ganz besonders begehrt sind. Dazu gehört die Teilnahme an internationalen Wettbewerben, bei denen die jungen Forscher Fachleuten aus aller Welt ihre Projekte vorstellen können. Auch Einladungen zu Studienreisen und Kongressen im Ausland sind für viele Teilnehmer besonders attraktiv. Im Rahmen von „Jugend forscht“ wird sogar eine Reise zur Nobelpreisverleihung in Stockholm angeboten. Im Inland haben die Preisträger die Möglichkeit, ein langes Praktikum an angesehenen Forschungsinstituten und bei wichtigen Unternehmen zu absolvieren. Dort bekommen die Jugendlichen im Arbeitsalltag eine gute Vorstellung davon, wie Forschungsarbeit funktioniert. Zusätzlich gibt es auch Abonnements für technische und naturwissenschaftliche Fachzeitschriften zu gewinnen. Auch Schulen und Projektbetreuer können teilnehmen. Bei diesem Wettbewerb haben junge Menschen die Möglichkeit, wertvolle Erfahrungen mit Forschungsprojekten zu sammeln. Mitmachen lohnt sich auf jeden Fall.",
          "answer": "h",
          "explanation": "Im Mittelpunkt stehen die attraktiven Geld- und Sonderpreise (Studienreisen, Praktika, Reise nach Stockholm) beim Wettbewerb „Jugend forscht“ ('Spannende Gewinne für wissenschaftliche Nachwuchstalente')."
        },
        {
          "num": 3,
          "text": "Die Industriellenvereinigung beklagt in einer jüngsten Pressemitteilung den deutlichen Mangel an Fachkräften in den Naturwissenschaften und den technischen Berufen. Dieser Fachkräftemangel sei besonders ausgeprägt in den Bereichen Maschinenbau, Elektrotechnik, Werkstoffwissenschaften und Verfahrenstechnik, heißt es in dem Papier. Um dem entgegenzusteuern, ruft die Industriellenvereinigung unter anderem dazu auf, insbesondere Mädchen und junge Frauen für solche Berufe zu gewinnen. Die Berufsorientierung der Schulen müsse noch gezielter auf die vielfältigen und interessanten Themenfelder sowie die guten Zukunftschancen technischer Berufe hinweisen. Erfolgreiche Frauen aus diesen Bereichen sollten sich zudem verstärkt als Vorbilder für Schülerinnen präsentieren. In diesem Zusammenhang wird in der Pressemitteilung auch an die Möglichkeit erinnert, am bevorstehenden bundesweiten Mädchenzukunftstag „Girls' Day“ an den Standorten namhafter Firmen Einblicke in den Arbeitsalltag in technischen Berufen zu bekommen. Die Industriellenvereinigung fordert die Unternehmen und Organisationen auf, ihre Türen für potenzielle Talente zu öffnen und sich Fachkräfte für die Zukunft zu sichern.",
          "answer": "g",
          "explanation": "Die Industriellenvereinigung ruft Schulen und Unternehmen dazu auf, gezielter Mädchen und junge Frauen für technische Berufe zu gewinnen ('Mehr Bemühungen um weiblichen Nachwuchs gefordert')."
        },
        {
          "num": 4,
          "text": "Im Kulturzentrum war gestern Abend Tobias Meyer zu Gast. Die Organisatoren hatten den bekannten Autor zahlreicher Sachbücher über Erziehung und Bildung eingeladen, zum Thema Berufsorientierung zu sprechen. In seinem Vortrag ging Meyer auf zwei wesentliche Aspekte von Berufsorientierung ein. Zum einen versteht er Berufsorientierung als eine Entwicklung, die eng mit den persönlichen und sozialen Beziehungen eines jungen Menschen zusammenhängt. Die Orientierung auf einen Beruf hin wertet er als einen Teil der Persönlichkeitsentwicklung. In engem Zusammenhang damit sieht er die Berufsvorbilder, an denen sich Jugendliche orientieren: Diese hängen ebenso wie die Erwartungen, die an einen Beruf gestellt würden, stark von der sozialen Umgebung ab. Zudem spielten lokale wirtschaftliche Umstände eine Rolle bei der Berufsorientierung. Meyer zeigte anhand konkreter Beispiele, wie große Unternehmen vor Ort die Berufswahl junger Menschen entscheidend beeinflussen können. Anschließend ging Meyer auf einen zweiten wesentlichen Aspekt, nämlich Berufsorientierung im Rahmen der Schulen, ein. Hier könnten entscheidende Impulse gesetzt werden, indem Talente und Stärken erkannt und bereits sehr früh gefördert würden.",
          "answer": "b",
          "explanation": "Laut Tobias Meyers Vortrag hängt die Berufsorientierung Jugendlicher stark von persönlichen Beziehungen, Vorbildern und der sozialen sowie lokalen wirtschaftlichen Umgebung ab ('Berufswahl: Jugendliche werden stark von ihrem gesellschaftlichen Umfeld geprägt')."
        },
        {
          "num": 5,
          "text": "Wie eine repräsentative Umfrage unter Studenten kürzlich zeigte, erfreut sich die Automobilindustrie nach wie vor großer Beliebtheit bei Studierenden der Fachgebiete Wirtschaft und Technik. Gefragt nach den fünf attraktivsten zukünftigen Arbeitgebern, nannten Wirtschaftsstudenten vier führende Automobilkonzerne und eine Internet-Suchmaschine; künftige Ingenieure nannten sogar ausschließlich Automobilunternehmen. Auch für Studenten der Informatik gewinnt die Automobilindustrie zunehmend an Attraktivität – wenig verwunderlich angesichts der rasch zunehmenden Bedeutung, die der Elektronik in Fahrzeugen zukommt. Die Branche punktet bei jungen Absolventen mit vielen spannenden Themen: Wie wird die Mobilität der Zukunft aussehen? Welche alternativen Antriebe wird es geben? Die Automobilindustrie bietet viel Raum für Innovationen und somit gute Chancen für motivierte Berufseinsteiger. Doch ausschlaggebend sind nicht nur solide Berufsaussichten. Wie die Befragung ergab, spielt auch der emotionale Faktor eine Rolle: Viele Studierende sind einfach begeistert vom Thema Auto.",
          "answer": "i",
          "explanation": "Einer Umfrage zufolge nennen angehende Ingenieure ausschließlich Automobilunternehmen als attraktivste Arbeitgeber ('Studienabsolventen technischer Fächer sehen ihre Zukunft meist in der Fahrzeugbranche')."
        }
      ]
    },
    {
      "id": "2b",
      "title": "Test 2b – Nachwuchs & Technik (Variante 2)",
      "isVariant": true,
      "headings": {
        "a": "Verleihung des Jugendnobelpreises in Stockholm",
        "b": "Studienabsolventen technischer Fächer sehen ihre Zukunft meist in der Fahrzeugbranche",
        "c": "Spannende Gewinne für wissenschaftliche Nachwuchstalente",
        "d": "Mehr Bemühungen um weiblichen Nachwuchs gefordert",
        "e": "Immer mehr Jugendliche werden Programmierer",
        "f": "Immer mehr Frauen ergreifen technische Berufe",
        "g": "Förderwochenende für junge Softwareentwickler",
        "h": "Diskussion über schulische Berufsorientierung",
        "i": "Berufswahl: Jugendliche werden stark von ihrem gesellschaftlichen Umfeld geprägt",
        "j": "Automobilindustrie schafft neue Arbeitsplätze"
      },
      "items": [
        {
          "num": 1,
          "text": "Martina Lux hat ein Hobby, mit dem sie im Kreis ihrer Freundinnen ziemlich allein steht: Sie programmiert in ihrer Freizeit. „Mich hat immer schon interessiert, wie Computerprogramme eigentlich funktionieren“, sagt die 17-Jährige. Außerdem habe sie großen Spaß an logischem Denken. Ihr Informatiklehrer erzählte ihr von einem Workshop in Berlin: Bei „Jugend programmiert“ traf Martina von letztem Freitag bis Sonntag mit gleichgesinnten Jungen und Mädchen zwischen zwölf und 18 Jahren zusammen, um gemeinsam Programme zu entwickeln. Dabei standen ihnen erfahrene Informatiker zur Seite. In 15 Gruppen entwickelten die jungen Nachwuchsprogrammierer ihre Projekte. Eine Jury verlieh Preise in vier Kategorien. Bewertet wurden die originellste Idee, die sauberste Umsetzung, die beste Präsentation und die größte Relevanz für die Gesellschaft. Martinas Gruppe erhielt zwar keinen Preis, aber das Wochenende hat sich für sie auf jeden Fall gelohnt. Sie hat zwei Mädchen kennengelernt, mit denen sie auch in Zukunft gemeinsam programmieren möchte. Zu wissen, dass sie nicht allein ist mit ihrem Hobby, das ist für sie ein besonders wichtiges Ergebnis dieses Wochenendes, meint Martina.",
          "answer": "g",
          "explanation": "Der Text berichtet über den dreitägigen Berliner Workshop „Jugend programmiert“ von Freitag bis Sonntag, bei dem Jugendliche gemeinsam Software entwickelten ('Förderwochenende für junge Softwareentwickler')."
        },
        {
          "num": 2,
          "text": "„Jugend forscht“ ist ein bundesweiter Nachwuchswettbewerb für junge Menschen bis zum Alter von 21 Jahren, bei dem besondere Leistungen in Mathematik, Technik, Naturwissenschaften und Informatik ausgezeichnet werden. Neben Geldpreisen werden auch einige Sonderpreise vergeben, die bei den Jugendlichen ganz besonders begehrt sind. Dazu gehört die Teilnahme an internationalen Wettbewerben, bei denen die jungen Forscher Fachleuten aus aller Welt ihre Projekte vorstellen können. Auch Einladungen zu Studienreisen und Kongressen im Ausland sind für viele Teilnehmer besonders attraktiv. Im Rahmen von „Jugend forscht“ wird sogar eine Reise zur Nobelpreisverleihung in Stockholm angeboten. Im Inland haben die Preisträger die Möglichkeit, ein langes Praktikum an angesehenen Forschungsinstituten und bei wichtigen Unternehmen zu absolvieren. Dort bekommen die Jugendlichen im Arbeitsalltag eine gute Vorstellung davon, wie Forschungsarbeit funktioniert. Zusätzlich gibt es auch Abonnements für technische und naturwissenschaftliche Fachzeitschriften zu gewinnen. Auch Schulen und Projektbetreuer können teilnehmen. Bei diesem Wettbewerb haben junge Menschen die Möglichkeit, wertvolle Erfahrungen mit Forschungsprojekten zu sammeln. Mitmachen lohnt sich auf jeden Fall.",
          "answer": "c",
          "explanation": "Im Mittelpunkt stehen die attraktiven Geld- und Sonderpreise (Studienreisen, Praktika, Reise nach Stockholm) beim Wettbewerb „Jugend forscht“ ('Spannende Gewinne für wissenschaftliche Nachwuchstalente')."
        },
        {
          "num": 3,
          "text": "Die Industriellenvereinigung beklagt in einer jüngsten Pressemitteilung den deutlichen Mangel an Fachkräften in den Naturwissenschaften und den technischen Berufen. Dieser Fachkräftemangel sei besonders ausgeprägt in den Bereichen Maschinenbau, Elektrotechnik, Werkstoffwissenschaften und Verfahrenstechnik, heißt es in dem Papier. Um dem entgegenzusteuern, ruft die Industriellenvereinigung unter anderem dazu auf, insbesondere Mädchen und junge Frauen für solche Berufe zu gewinnen. Die Berufsorientierung der Schulen müsse noch gezielter auf die vielfältigen und interessanten Themenfelder sowie die guten Zukunftschancen technischer Berufe hinweisen. Erfolgreiche Frauen aus diesen Bereichen sollten sich zudem verstärkt als Vorbilder für Schülerinnen präsentieren. In diesem Zusammenhang wird in der Pressemitteilung auch an die Möglichkeit erinnert, am bevorstehenden bundesweiten Mädchenzukunftstag „Girls' Day“ an den Standorten namhafter Firmen Einblicke in den Arbeitsalltag in technischen Berufen zu bekommen. Die Industriellenvereinigung fordert die Unternehmen und Organisationen auf, ihre Türen für potenzielle Talente zu öffnen und sich Fachkräfte für die Zukunft zu sichern.",
          "answer": "d",
          "explanation": "Die Industriellenvereinigung ruft Schulen und Unternehmen dazu auf, gezielter Mädchen und junge Frauen für technische Berufe zu gewinnen ('Mehr Bemühungen um weiblichen Nachwuchs gefordert')."
        },
        {
          "num": 4,
          "text": "Im Kulturzentrum war gestern Abend Tobias Meyer zu Gast. Die Organisatoren hatten den bekannten Autor zahlreicher Sachbücher über Erziehung und Bildung eingeladen, zum Thema Berufsorientierung zu sprechen. In seinem Vortrag ging Meyer auf zwei wesentliche Aspekte von Berufsorientierung ein. Zum einen versteht er Berufsorientierung als eine Entwicklung, die eng mit den persönlichen und sozialen Beziehungen eines jungen Menschen zusammenhängt. Die Orientierung auf einen Beruf hin wertet er als einen Teil der Persönlichkeitsentwicklung. In engem Zusammenhang damit sieht er die Berufsvorbilder, an denen sich Jugendliche orientieren: Diese hängen ebenso wie die Erwartungen, die an einen Beruf gestellt würden, stark von der sozialen Umgebung ab. Zudem spielten lokale wirtschaftliche Umstände eine Rolle bei der Berufsorientierung. Meyer zeigte anhand konkreter Beispiele, wie große Unternehmen vor Ort die Berufswahl junger Menschen entscheidend beeinflussen können. Anschließend ging Meyer auf einen zweiten wesentlichen Aspekt, nämlich Berufsorientierung im Rahmen der Schulen, ein. Hier könnten entscheidende Impulse gesetzt werden, indem Talente und Stärken erkannt und bereits sehr früh gefördert würden.",
          "answer": "i",
          "explanation": "Laut Tobias Meyers Vortrag hängt die Berufsorientierung Jugendlicher stark von persönlichen Beziehungen, Vorbildern und der sozialen sowie lokalen wirtschaftlichen Umgebung ab ('Berufswahl: Jugendliche werden stark von ihrem gesellschaftlichen Umfeld geprägt')."
        },
        {
          "num": 5,
          "text": "Wie eine repräsentative Umfrage unter Studenten kürzlich zeigte, erfreut sich die Automobilindustrie nach wie vor großer Beliebtheit bei Studierenden der Fachgebiete Wirtschaft und Technik. Gefragt nach den fünf attraktivsten zukünftigen Arbeitgebern, nannten Wirtschaftsstudenten vier führende Automobilkonzerne und eine Internet-Suchmaschine; künftige Ingenieure nannten sogar ausschließlich Automobilunternehmen. Auch für Studenten der Informatik gewinnt die Automobilindustrie zunehmend an Attraktivität – wenig verwunderlich angesichts der rasch zunehmenden Bedeutung, die der Elektronik in Fahrzeugen zukommt. Die Branche punktet bei jungen Absolventen mit vielen spannenden Themen: Wie wird die Mobilität der Zukunft aussehen? Welche alternativen Antriebe wird es geben? Die Automobilindustrie bietet viel Raum für Innovationen und somit gute Chancen für motivierte Berufseinsteiger. Doch ausschlaggebend sind nicht nur solide Berufsaussichten. Wie die Befragung ergab, spielt auch der emotionale Faktor eine Rolle: Viele Studierende sind einfach begeistert vom Thema Auto.",
          "answer": "b",
          "explanation": "Einer Umfrage zufolge nennen angehende Ingenieure ausschließlich Automobilunternehmen als attraktivste Arbeitgeber ('Studienabsolventen technischer Fächer sehen ihre Zukunft meist in der Fahrzeugbranche')."
        }
      ]
    },
    {
      "id": "3",
      "title": "Test 3 – Rund ums Geld",
      "isVariant": false,
      "headings": {
        "a": "Ausstellung über Finanzmetropole",
        "b": "Fachinformationen für Finanzprofis",
        "c": "Finanz-ABC für Anfänger",
        "d": "Interessante Tätigkeit wichtiger als hohes Gehalt",
        "e": "Lehrreicher Rundgang zu Finanzwissen",
        "f": "Sammelgefäße als Ausstellungsobjekte",
        "g": "Sparbüchsen – Nun wieder in Mode",
        "h": "Vertrauen zeigt sich auf dem Konto",
        "i": "Wie Kinder den Umgang mit Geld lernen",
        "j": "Wie man Kinder zum Sparen motiviert"
      },
      "items": [
        {
          "num": 1,
          "text": "Spardosen sind Sammelbehälter, Dekoration oder Kinderspielzeug – und zwar seit Jahrhunderten. Und obwohl bargeldloses Bezahlen immer mehr in Mode kommt, sind sie bis heute nicht aus den Kinderzimmern verschwunden. Das Spardosen-Museum im Haus Kemnade zeigt 1200 Exemplare aus dem Mittelalter bis zum 20. Jahrhundert. Daneben widmet sich das Museum der Geschichte des Geldes. In zwei Räumen sind Münzen, Scheine und weitere Tauschmittel aus der ganzen Welt ausgestellt. Die Sammlung von Spardosen reicht von schweren Gefäßen aus Eisen über kunstvoll verzierte Truhen und Kutschen bis zu Mickey-Mäusen aus Blech. „Um 1900 erlebten Spardosen einen Boom“, erzählt Museumsleiter Jürgen Stollmann. In vielen Häusern hatten sie zwar nur als hübsche Dekoration hergehalten, doch immer seien sie auch ein Spiegel der Gesellschaft. Seit zehn Jahren schon gibt es das Museum, das interessante Einblicke in die Geldgeschichte bietet. Jährlich lockt es über 13.000 Besucher an.",
          "answer": "f",
          "explanation": "Das Spardosen-Museum im Haus Kemnade stellt 1200 Spardosen (Sammelbehälter) aus verschiedenen Jahrhunderten aus ('Sammelgefäße als Ausstellungsobjekte')."
        },
        {
          "num": 2,
          "text": "Wer beim leisen Klirren von Geldstücken ein prickelndes Gefühl verspürt, ist in der neuen Sonderausstellung „Die Sprache des Geldes“ im Berliner Museum für Kommunikation richtig. Auf ungewöhnliche Weise nähert sich diese kleine Schau dem Geld als Dreh- und Angelpunkt einer globalisierten Welt. Im Museum machen die Besucher auf 450 Quadratmetern eine Tour durch eine fiktive Stadt: Auf dem „Marktplatz“ erfahren sie, warum sich zuerst Münzen und viel später Scheine als Zahlungsmittel durchsetzten. Bei den Stationen „Bank“ und „Börse“ lernen sie das Prinzip kennen, das in guten Zeiten dahintersteht: Vertrauen in den Wert des Geldes. In der Station „Einkaufszentrum“ geht es dagegen um die heutige Konsumgesellschaft. Entlohnt werden die Besucher für ihren Ausstellungsbesuch natürlich auch. Wer sein neues Wissen in einem Computerquiz nachweisen kann, erhält einen Spielgeld-Schein mit dem eigenen Konterfei. Macht Geld denn nun glücklich? „Nur für einen kurzen Moment“, versichert Kurator Gregor Isenbrot. „Wenn der Rausch vorbei ist, will der Mensch noch mehr. Und zwar mehr Geld.“",
          "answer": "e",
          "explanation": "In der Sonderausstellung machen Besucher eine lehrreiche Tour durch eine fiktive Stadt mit verschiedenen Stationen rund um das Thema Geld ('Lehrreicher Rundgang zu Finanzwissen')."
        },
        {
          "num": 3,
          "text": "„Versteh' ich ja doch nicht; ist mir zu kompliziert.“ So oder ähnlich lauten die üblichen Vorbehalte, wenn es darum geht, zu begreifen, wie Wirtschaft funktioniert und der Finanzsektor arbeitet. Der englische Journalist John Lanchester nimmt alle jene neugierigen Laien, denen die Fachsprache rund ums Geld bislang verwirrend erschien, bei der Hand. So schildert er in seinem Buch „Die Sprache des Geldes und warum wir sie nicht verstehen“, wie er sich als Außenseiter dem Thema genähert hat. Geld habe eine eigene Sprache, erklärt Lanchester. Wer diese nicht lerne, könne nicht mitreden. Und so erläutert er im ersten Teil seines Buches die Besonderheiten dieser Sprache. Den zweiten Teil bildet ein alphabetisches Glossar, in dem Fachwörter und Namen in kurzen Artikeln erläutert werden. Anschaulich erklärt Lanchester etwa, was Derivate sind und wie man antizyklisch handelt. Das Buch ist anekdotenreich und gut lesbar, seine Lektüre zu empfehlen. Denn Lanchester ermöglicht es dem interessierten Wirtschaftslaien, mitreden zu können.",
          "answer": "c",
          "explanation": "John Lanchesters Buch erklärt Wirtschaftslaien mit einem alphabetischen Glossar anschaulich die Fachsprache der Finanzwelt ('Finanz-ABC für Anfänger')."
        },
        {
          "num": 4,
          "text": "Eine neue Untersuchung des Instituts der deutschen Wirtschaft bestätigt eine Tatsache, über die sich Sozialwissenschaftler und Psychologen schon lange einig sind: Die Höhe des Einkommens allein macht nicht glücklich. Wie zufrieden ein Arbeitnehmer ist, hängt demnach nicht in erster Linie vom Lohn oder der Tätigkeit ab, sondern davon, wie emotional stabil, belastbar und selbstsicher er ist. Für die Studie hat die Ökonomin Mara Ewers die Zusammenhänge zwischen der Lebens- und Arbeitszufriedenheit, dem Bruttostundenlohn, der Anzahl der Bildungsjahre und dem Gesundheitszustand untersucht. Sie fand heraus, dass 53 Prozent der Bundesbürger, die sich emotional als besonders stabil bezeichnen, auch im Job sehr zufrieden sind. Die Fähigkeit, anderen Menschen zu vertrauen, steigere die Lebens- und Arbeitszufriedenheit. Die Untersuchung lege die These nahe, dass Einkommensunterschiede auch eine Folge der Persönlichkeitsentwicklung sein können, so Ewers. Wer misstrauisch sei, verwende mehr Zeit und Kraft für Kontrollen und sei daher weniger produktiv, sagt sie. Und wer weniger produktiv sei, verdiene auf Dauer auch weniger.",
          "answer": "h",
          "explanation": "Die Studie zeigt, dass Menschen, die anderen vertrauen, produktiver sind und dadurch langfristig auch mehr verdienen, während Misstrauische weniger verdienen ('Vertrauen zeigt sich auf dem Konto')."
        },
        {
          "num": 5,
          "text": "Über Geld sprechen viele Deutsche nicht gerne – selbst Verwandte oder Lebenspartner haben oft keine Ahnung, was sich auf den Konten ihrer Nächsten tut. Dabei spielt Geld bei den meisten Entscheidungen eine wichtige Rolle, und zwar auch in der Familie. Es ist heutzutage zum Glück üblich, dass Kinder spielerisch ein Gefühl für Geld entwickeln: Zwei Drittel der Vier- bis Fünfjährigen bekommen mittlerweile Taschengeld. Doch die Offenheit von Eltern sollte noch weiter gehen: Denn die Erziehung prägt entscheidend das spätere Verhältnis der Kinder zu Geld, wie Studien belegen. Vorteilhaftes Finanzverhalten nennen Forscher das und setzen es mit der Fähigkeit gleich, Geld sinnvoll einzuteilen oder zu sparen. Natürlich ist das Thema Geld für Eltern ein Balanceakt. Doch letztlich lohnt sich der Mut zu Vertrauen und wohldosierter Offenheit, denn wo Offenheit herrscht, kann Verständnis wachsen. Vielleicht sieht dann auch ein Elfjähriger ein, dass die Spielekonsole für viele hundert Euro zwar toll, aber trotzdem nicht nötig ist.",
          "answer": "i",
          "explanation": "Der Text behandelt, wie Kinder durch Taschengeld und elterliche Offenheit ein Gefühl für Geld und vorteilhaftes Finanzverhalten entwickeln ('Wie Kinder den Umgang mit Geld lernen')."
        }
      ]
    },
    {
      "id": "4",
      "title": "Test 4 – Viren & Grippeimpfung",
      "isVariant": false,
      "headings": {
        "a": "WHO gibt neue Empfehlungen für Grippe-Impfung heraus",
        "b": "Neue Erkenntnisse über artübergreifende Krankheitserreger",
        "c": "Kontroverse um den Zugang zu Forschungsergebnissen",
        "d": "Hoffnung auf einen allumfassenden Grippeschutz",
        "e": "Hinweise auf eingeschränkten Erfolg von Influenza-Impfungen",
        "f": "Gesetz verpflichtet Forscher zur Veröffentlichung ihrer Ergebnisse",
        "g": "Geschlechtsspezifische Übertragung von Grippeviren",
        "h": "Endlich eine universale Grippe-Impfung auf dem Markt",
        "i": "Durchschlagender Erfolg der diesjährigen Grippeimpfung",
        "j": "Die häufigsten Kinderkrankheiten in der Grundschule"
      },
      "items": [
        {
          "num": 1,
          "text": "Immer wieder überspringen Krankheitserreger aus dem Tierreich die Artengrenze und werden auch dem Menschen gefährlich. Allerdings galt die Gruppe Adenoviren bislang als artgebunden: Manche verursachen beim Menschen verschiedene Probleme, von Schnupfen über Durchfall bis hin zu Lungenentzündung. Andere machen bestimmten Tierarten zu schaffen. Aber noch nie wurde bekannt, dass solche Viren von einer Spezies auf eine andere wechseln. Nun berichten Forscher erstmals von einem solchen Fall: Demnach erlitten in einem kalifornischen Primatenzentrum 23 von insgesamt 65 Roten Springaffen Entzündungen der Atemwege oder der Leber. Nur vier der infizierten Tiere überlebten. Als Ursache identifizierten die Mediziner das bislang unbekannte Adenovirus TMAdV. Dieser Erreger kann auch Menschen befallen: Ein Mitarbeiter des Primatenzentrums, der viel Kontakt zu den erkrankten Affen hatte, bekam Fieber und Husten. Zudem steckte er ein Mitglied seiner Familie an. Die Experten empfehlen, Adenoviren künftig sorgfältiger zu beobachten, um rechtzeitig auf mögliche Gefahren für den Menschen aufmerksam zu werden.",
          "answer": "b",
          "explanation": "Forscher berichten erstmals darüber, dass ein Adenovirus (TMAdV) von Affen auf den Menschen übertragen wurde ('Neue Erkenntnisse über artübergreifende Krankheitserreger')."
        },
        {
          "num": 2,
          "text": "Virologen ist es gelungen, den Vogelgrippe-Erreger hochansteckend zu machen. Nun empfiehlt das US-Gesundheitsministerium Fachzeitschriften, die entsprechenden Daten nicht zu veröffentlichen, weil Terroristen mit ihrer Hilfe Biowaffen basteln könnten. Nur die Ergebnisse der Versuche sollen erscheinen, nicht aber Einzelheiten über die Arbeitsweise der Forscher oder Details über die Beschaffenheit der Viren. Das Ministerium stützt seine Entscheidung auf die Empfehlungen des unabhängigen Expertengremiums NSABB. Es ist das erste Mal, dass das Gremium eine solche Empfehlung ausgesprochen hat. Ihr vorausgegangen war eine wochenlange Diskussion darüber, wie Forscher mit heiklen Erkenntnissen umgehen sollen: Alles offenlegen oder brisante Versuche unterlassen und erst recht nicht veröffentlichen? Für die betroffenen Forscher steht die Freiheit der Forschung und der Presse auf dem Spiel. Unklar ist noch, inwieweit sie und die Fachjournale den Empfehlungen des NSABB folgen. Es ist für die öffentliche Gesundheit notwendig, dass alle Details jeder wissenschaftlichen Analyse zu Influenzaviren Forschern zugänglich sind.",
          "answer": "c",
          "explanation": "Es gibt eine heftige Debatte darüber, ob Details zur Erforschung hochansteckender Vogelgrippe-Viren veröffentlicht werden dürfen oder zurückgehalten werden sollen ('Kontroverse um den Zugang zu Forschungsergebnissen')."
        },
        {
          "num": 3,
          "text": "Ein neuer Impfstoff gegen Grippe könnte in Zukunft sämtliche Varianten der Krankheit abdecken und damit die jährliche Spritze überflüssig machen. Der Stoff bekämpft die stets gleichen Proteine im Inneren der Grippeviren statt wie derzeitige Substanzen die sich ständig ändernden an der Außenhülle. Ein Forscherteam der Universität Oxford hat den Impfstoff erstmals an Menschen getestet. Weitere Studien sollen folgen. Es kann Jahre dauern, bis die Substanz eine Zulassung bekommt. Doch die Forscher sind optimistisch. Derzeit müssen jedes Jahr neue Impfstoffe für die Grippesaison entwickelt werden, weil sich die Virenhülle so schnell wandelt. Da der neue Stoff an den stabileren inneren Proteinen der Viren ansetze, könnte das in Zukunft überflüssig werden. Es könnte eine Routine-Impfung wie gegen andere Krankheiten wie zum Beispiel Tetanus entwickelt werden. Bei der bisherigen Impfung gehe es vor allem darum, den Körper zur Produktion von Antikörpern gegen die Grippeviren zu aktivieren. Der neue Stoff hingegen rege die sogenannten T-Zellen an, die ebenfalls ein wichtiger Teil des Immunsystems sind.",
          "answer": "d",
          "explanation": "Ein in Oxford getesteter neuer Impfstoff könnte künftig alle Grippevarianten abdecken, braucht aber noch Jahre bis zur Zulassung ('Hoffnung auf einen allumfassenden Grippeschutz')."
        },
        {
          "num": 4,
          "text": "Breitet sich die Grippe in einer Schule aus, sind es besonders geschlechtshomogene Gruppen, in denen das Virus schnell neue Opfer findet. Denn wie US-Mediziner herausgefunden haben, stecken Buben vor allem Buben und Mädchen in erster Linie Mädchen an. Infektionen innerhalb eines Geschlechts passieren dreimal häufiger als über die Geschlechtergrenzen hinweg. Innerhalb derselben Schulklasse sind Übertragungen fünfmal häufiger als zu einer Parallelklasse und 25-mal häufiger als zu den Schülern anderer Schulstufen, fanden die Forscher bei Untersuchungen an einer Volksschule heraus. Ein weiterer interessanter Befund: Ob ein Kind neben einem bereits infizierten Schulkollegen saß oder nicht, machte keinen Unterschied bei der Ausbreitung der Influenza.",
          "answer": "g",
          "explanation": "Untersuchungen zeigen, dass sich Grippeviren in Schulen dreimal häufiger innerhalb desselben Geschlechts verbreiten ('Geschlechtsspezifische Übertragung von Grippeviren')."
        },
        {
          "num": 5,
          "text": "Da sich Influenzaviren immer wieder verändern, unternimmt die Weltgesundheitsorganisation WHO jedes Jahr große Anstrengungen, um die gerade umlaufenden Grippeviren zu identifizieren, anhand derer Pharmaunternehmen dann gezielt Impfstoffe herstellen können. Die Entwicklung solcher Impfstoffe nimmt allerdings bis zu neun Monate in Anspruch. Daher kann es vorkommen, dass sich gerade aktive Influenza-Viren von denen, die für die Herstellung des Impfstoffes verwendet wurden, etwas unterscheiden. Prinzipiell ist also jedes Jahr eine erneute Impfung notwendig. Eine neue Studie liefert Anhaltspunkte dafür, dass die tatsächliche Wirksamkeit von Grippeimpfstoffen weit niedriger sein soll als bisher angenommen. Denn in der Studie zeigte sich, dass gängige Grippeimpfstoffe nur 59 von 100 Grippefällen verhindern konnten.",
          "answer": "e",
          "explanation": "Eine neue Studie belegt, dass gängige Grippeimpfstoffe nur 59 % der Fälle verhindern und damit weniger wirksam sind als gedacht ('Hinweise auf eingeschränkten Erfolg von Influenza-Impfungen')."
        }
      ]
    },
    {
      "id": "5",
      "title": "Test 5 – Inseln & Tourismus",
      "isVariant": false,
      "headings": {
        "a": "Deutscher Forscher startet Expedition auf Vogelinsel in Südamerika",
        "b": "Die beliebtesten Reiseziele unter den europäischen Inseln",
        "c": "Fernreisen in eine unberührte Tierwelt",
        "d": "Geführte Bootsausflüge zu einsamen Badebuchten",
        "e": "Grüne Geisterinsel in Asien",
        "f": "Immer mehr Reiseunternehmen streichen Thailand aus ihrem Angebot",
        "g": "Inseln zählen weltweit zu den wichtigsten Reisedestinationen",
        "h": "Nachhaltiger Tourismus auf chinesischen Inseln",
        "i": "Tierparadies auf einer Nordseeinsel",
        "j": "Umstrittener Umgang mit Tieren als Touristenmagnet"
      },
      "items": [
        {
          "num": 1,
          "text": "Die Shengsi-Inseln liegen im Ostchinesischen Meer. Nicht einmal 20 der rund 400 Inseln sind bewohnt, und manche, auf denen einst Menschen lebten, wurden wieder verlassen. Ein altes Dorf auf der nun unbewohnten Insel Shengshan ist zu einer Sehenswürdigkeit geworden. Die Einwohner haben das ehemalige Fischerdorf auf der viereinhalb Quadratkilometer großen Insel längst verlassen. Sie sind aus wirtschaftlichen Gründen auf das Festland gezogen. Dort ist es für sie leichter, ihren Fischfang zu verarbeiten und zu verkaufen. Das Dorf aber, das sie zurückgelassen haben, ist in kürzester Zeit von der Natur zurückerobert worden. Farne und Gräser überwuchern Häuser und Wege. Die Grenzen zwischen den von Menschenhand geschaffenen Gebäuden und dem umgebenden Urwald verschwinden: Mauerwerk, von wildem Wein überwuchert; Grün, so weit das Auge reicht. An diesem Ort lebt keine Menschenseele mehr.",
          "answer": "e",
          "explanation": "Ein verlassenes Fischerdorf auf der chinesischen Insel Shengshan wurde komplett von grünen Pflanzen überwuchert ('Grüne Geisterinsel in Asien')."
        },
        {
          "num": 2,
          "text": "Der Reiseveranstalter TOURIMARS hat kürzlich eine Befragung durchgeführt. Er wollte wissen, welche Inseln in Europa unter Reisenden besonders populär sind. Nach dieser Umfrage führt die griechische Insel Santorin die Liste an. Auf Platz zwei steht Madeira, die grüne Insel im Atlantik. Mit Kreta und Zakynthos schaffen es an dritter und vierter Stelle noch zwei weitere griechische Inseln in die Liste – übrigens wird die Attraktivität griechischer Inseln auch in anderen Umfragen bestätigt. Platz fünf nimmt die Badeinsel Fuerteventura ein. Rang sechs kommt der britischen Kanalinsel Jersey zu. Mallorca folgt auf Platz sieben, gefolgt von der italienischen Insel Capri und der Kanareninsel Teneriffa. Gerade noch in die Top Ten schaffte es auch die französische Mittelmeerinsel Korsika, die sowohl für Wanderer als auch für Badeurlauber interessant ist. Für die Umfrage waren Erfahrungsberichte von Urlaubern über einen Zeitraum von 12 Monaten ausgewertet worden. Sie bewerteten dabei die Hotels, Restaurants und Sehenswürdigkeiten der besuchten Insel.",
          "answer": "b",
          "explanation": "Eine Umfrage des Reiseveranstalters TOURIMARS kürt die Top 10 der populärsten Inseln Europas ('Die beliebtesten Reiseziele unter den europäischen Inseln')."
        },
        {
          "num": 3,
          "text": "Das ostfriesische Memmert ist für seltene Vögel reserviert. Auf der Düneninsel, die vor ein paar Jahrhunderten aus der Nordsee aufgetaucht ist, leben Zigtausende von Vögeln. Nur der Inselvogt lebt zeitweise dort. Von Anfang März bis Ende Oktober ist der Forscher das einzige menschliche Wesen auf der kleinen Vogelschutzinsel im Wattenmeer. Im Auftrag des Landes Niedersachsen ist der Inselvogt zuständig für den Schutz von Natur und Vögeln auf Memmert. Von Mai bis Ende Juli ist Brutzeit auf der Insel. 100.000 Tiere, Vertreter von 60 verschiedenen Vogelarten, kommen Jahr für Jahr zum Brüten nach Memmert. Während dieser Zeit besteht ein absolutes Betretungsverbot – ausgenommen für Personen, die in Seenot geraten sind oder eine schriftliche Genehmigung haben. Ab August, dem Ende der Brutzeit, haben auch Urlauber für kurze Zeit die Chance auf einen Besuch, aber ausschließlich im Rahmen einer geführten Expedition. Nur mit einem Experten dürfen sie die Düneninsel im Wattenmeer erkunden.",
          "answer": "i",
          "explanation": "Auf der ostfriesischen Nordseeinsel Memmert leben und brüten geschützt Zigtausende Vögel ('Tierparadies auf einer Nordseeinsel')."
        },
        {
          "num": 4,
          "text": "Die südamerikanischen Galapagosinseln locken nicht mit weißen Sandstränden und Palmen. Dennoch sind sie das Ziel so mancher Reisesehnsüchte. Für viele Menschen gelten die fernen Inseln als eine Art Paradies. Und tatsächlich kommt man wohl nirgendwo sonst ungezähmten Tieren so nahe wie auf diesen Inseln: Auf den unbewohnten Galapagosinseln verhalten sich die Tiere so, als ob es keine Menschen gäbe. Für die Besucher genauso faszinierend wie für die Entdeckungsreisenden früherer Jahrhunderte ist dabei die Zutraulichkeit, die sich die Tiere durch das Fehlen von natürlichen Feinden auf den Inseln bewahrt haben. Man kann das ganze Jahr über zu den Galapagosinseln reisen. Die bewohnten Inseln kann man dabei ganz gut allein besuchen. Anders sieht es bei den unbewohnten Inseln aus. Hier lassen die Behörden seit einigen Jahren nur eine begrenzte Zahl an Schiffen zu, und ohne Führer ist das Betreten nicht erlaubt. Die Inseln und ihre Tiere bleiben sich selbst überlassen, damit das Naturparadies auch weiterhin erhalten bleibt.",
          "answer": "c",
          "explanation": "Reisen zu den fernen Galapagosinseln ermöglichen Begegnungen mit völlig ungezähmten, zutraulichen Wildtieren ('Fernreisen in eine unberührte Tierwelt')."
        },
        {
          "num": 5,
          "text": "Dass Elefanten in Thailand teurer sein können als ein 3er-BMW in München, liegt an ihrem enormen wirtschaftlichen Potenzial: Sie sind eine der Hauptattraktionen der thailändischen Tourismusindustrie. Jeder dritte Besucher des Landes möchte mit Elefanten in Kontakt kommen oder hat das bereits hinter sich, zeigt die Umfrage einer Tierschutzgruppe. Die Organisation schätzt, dass in dem Land mehr als 2000 Elefanten im Einsatz sind, um die Nachfrage der Urlauber zu bedienen – so viele wie in keinem anderen Land der Welt. Was für die Besitzer ein gutes Geschäft ist, steht immer häufiger bei Tierschützern in der Kritik: Elefantenreiten sei die grausamste Tierattraktion der Welt. Sie sprechen von einer lebenslangen Qual für die Elefanten. Mehr als 100 Reiseveranstalter haben solche Angebote schon aus den Katalogen gestrichen. Dies feiern Tierschützer als Sieg: „Elefanten sind Wildtiere, keine Entertainer.“ Dass die Lebensbedingungen der Tourismuselefanten nicht artgerecht sind, ist bekannt. Doch selbst wenn sie nicht mehr als Einnahmequelle dienen, wird das an ihren Lebensumständen wenig ändern.",
          "answer": "j",
          "explanation": "Elefantenreiten ist eine Hauptattraktion für Touristen in Thailand, wird aber von Tierschützern scharf als Tierquälerei kritisiert ('Umstrittener Umgang mit Tieren als Touristenmagnet')."
        }
      ]
    },
    {
      "id": "6",
      "title": "Test 6 – Koffein, Bienen & Insekten",
      "isVariant": false,
      "headings": {
        "a": "Wie aus Tieren Frostschutzmittel gewonnen werden",
        "b": "Genussmittel erhöht die Wahrnehmung bestimmter Wörter",
        "c": "Insektensterben in der kalten Jahreszeit",
        "d": "Pflanzen und Insekten – eine gemeinsame Entwicklung",
        "e": "Koffeinrückstände in landwirtschaftlichen Erzeugnissen",
        "f": "Koffein im Blütennektar verbessert die Gedächtnisleistung",
        "g": "Die bisher ältesten Pflanzensamen entdeckt",
        "h": "Neue Erkenntnisse über das weltweite Bienensterben",
        "i": "Methoden zum Überleben in der kalten Jahreszeit",
        "j": "Wie Kaffee unser Sprachvermögen beeinträchtigt"
      },
      "items": [
        {
          "num": 1,
          "text": "Kaffee verleiht neuen Schwung und hebt die Stimmung. Viele Kaffeetrinker schätzen diesen Effekt des Koffeins. Forscher der Ruhr-Universität Bochum haben das Phänomen untersucht und herausgefunden, dass Koffein selektiv das Erkennungsvermögen für positive Begriffe schärft. Die Wahrnehmung von negativen oder neutralen Wörtern verändert der Muntermacher dagegen nicht. Es war bereits vorher bekannt, dass der Mensch beim Lesen emotional positiv besetzte Begriffe besser und schneller erfasst als negative oder neutrale Wörter. Die anregende Wirkung von Koffein auf das Denkvermögen und die Aufmerksamkeit ist durch Studien ebenfalls gut belegt. Psychologen wollten nun durch ihre Untersuchungen herausfinden, ob es eine Kombinationswirkung dieser beiden Effekte gibt. Dazu führten sie Tests mit 66 Teilnehmern durch. Die Kontrollgruppe bekam ein wirkstofffreies Präparat, die Versuchsgruppe dagegen 200 Milligramm Koffein, was etwa zwei bis drei Tassen Kaffee entspricht. Die Teilnehmer in beiden Gruppen konnten positiv besetzte Begriffe deutlich besser und schneller erkennen. Das Koffein hat allerdings diesen Effekt überproportional verstärkt. Das könnte daran liegen, dass Koffein Hirnfunktionen beeinflusst, die auf dem Neurotransmitter Dopamin beruhen.",
          "answer": "b",
          "explanation": "Laut einer Studie der Ruhr-Universität Bochum verstärkt Koffein (Kaffee) gezielt das schnelle Erkennen positiv besetzter Begriffe ('Genussmittel erhöht die Wahrnehmung bestimmter Wörter')."
        },
        {
          "num": 2,
          "text": "Ihr Gehirn ist gerade ein Millionstel Mal so groß wie unseres, und doch haben sie ein Verhalten inklusive Sozialleben und Kommunikation entwickelt, über das wir nur staunen können. Sie bestäuben nicht nur viele Pflanzen, sondern haben die Entwicklung dieser Pflanzen erst ermöglicht sowie gegenseitig ihre Evolution vorangetrieben: In Amerika wurde die bisher älteste Biene entdeckt. Sie lag seit 100 Millionen Jahren in Bernstein in Burma, und sie war winzig – 2,95 Millimeter lang, so winzig wie die Blüten, die sie damals bestäubte. Dann wuchsen beide auf ihre heutigen Größen. Fast gleichzeitig wurde das Genom der Honigbiene publiziert. Das zeigt, dass Bienen für die Blütensuche bestens gerüstet sind. Sie haben 170 Gene für Geruchs-Rezeptoren. Dafür ist ihr Geschmacks-Repertoire extrem schmal. Die Forscher führen das darauf zurück, dass Bienen zum gegenseitigen Wohl mit Pflanzen zusammenleben. Sie müssen nicht mit Gift-Gegenwehr der Pflanzen rechnen und deshalb nicht abschmecken.",
          "answer": "d",
          "explanation": "Bienen und Blütenpflanzen haben ihre Evolution über Millionen Jahre hinweg gegenseitig vorangetrieben ('Pflanzen und Insekten – eine gemeinsame Entwicklung')."
        },
        {
          "num": 3,
          "text": "Nicht nur bei Menschen bringt Koffein die kleinen grauen Zellen in Schwung – auch Bienen, die Pollen von Kaffee oder anderen koffeinhaltigen Pflanzen sammeln, kommen dabei so richtig in Fahrt. Wie die amerikanische Fachzeitschrift „Science“ berichtet, erinnern sich Bienen mit der richtigen Dosis Koffein bis zu dreimal länger an den Duft einer Futterpflanze. Das hilft nicht nur den Bienen bei ihrer Suche, sondern auch den Pflanzen. In hoher Konzentration ist Koffein bitter und schreckt Insekten ab. In geringen Dosen scheint es die Bienen aber nicht zu stören, sondern ihnen eher auf die Sprünge zu helfen. Koffein stärke offensichtlich das Langzeitgedächtnis der Bienen, schlussfolgerten die Forscher aus ihrem Versuch. Sie konnten diese Wirkung auch im Gehirn der Insekten nachweisen: Koffein veränderte dort die Erregbarkeit von Neuronen, die mit dem Geruchslernen in Verbindung stehen. Dadurch wird wahrscheinlich die Sammelleistung der Bienen gesteigert. Gleichzeitig erhalten die Pflanzen treue Bestäuber.",
          "answer": "f",
          "explanation": "Koffein im Nektar stärkt das Langzeitgedächtnis der Bienen, sodass sie sich dreimal länger an den Duft einer Futterpflanze erinnern ('Koffein im Blütennektar verbessert die Gedächtnisleistung')."
        },
        {
          "num": 4,
          "text": "Es ist ein schwerer Gang im Leben jedes Imkers. Die paar Schritte hin zu seinen Völkern im Frühjahr, wenn an den Fluglöchern eigentlich schon seit Tagen emsiges Treiben herrschen sollte – aber stattdessen nur Stille von einer Tragödie kündet. Ein paar Schritte, bevor der Imker den Deckel von der „Beute“, wie ein Stock in der Fachsprache heißt, nimmt und schließlich Gewissheit über das erlangt, was er längst befürchtet hat: Das ganze Volk – tot. Es ist frustrierend, wenn ein Imker Ende Februar Handvoll um Handvoll vertrockneter Insekten wegschaufeln muss – aber völlig ungewöhnlich ist es nicht. Jahr für Jahr überstehen zwischen zehn und 15 Prozent aller Bienenvölker die Winterruhe zwischen November und Februar nicht. Verluste, auf die die heimischen Bienenzüchter eingestellt sind: Nicht umsonst wird dem zuletzt wieder zahlreicher gewordenen Imkernachwuchs empfohlen, ihre Karriere mit mindestens drei Völkern zu beginnen – so hält sich die Frustration über Verluste in Grenzen, der Betrieb kann ungestört weitergehen.",
          "answer": "c",
          "explanation": "Jedes Jahr überleben 10 bis 15 Prozent der Bienenvölker die Winterruhe zwischen November und Februar nicht ('Insektensterben in der kalten Jahreszeit')."
        },
        {
          "num": 5,
          "text": "Viele Insekten überwintern als Puppe oder Larve. Doch auch „erwachsene“ Fliegen, Bienen und Käfer überleben die eisige Zeit. Wichtig ist die Wahl von geschützten Orten wie Baumritzen, Laubstreu, Höhlen, Dachböden oder Kellern. Honigbienen bilden im Nest eine Traube und wärmen sich gegenseitig durch Muskelzittern. Bei Wespen und Hummeln überwintern nur die Königinnen in Erdlöchern. Sie bauen dann im Frühling neue Staaten auf. Maikäfer überdauern als Engerlinge den Winter, Marienkäfer suchen geschützte Bereiche auf. Viele Insekten unserer Regionen sind „gefriertolerant“. Sie stellen im Herbst ihren Organismus um und versetzen ihr Blut mit einem Cocktail aus Gefrierschutzmitteln. Andere Insekten erleben im Herbst ebenfalls enorme Umbauarbeiten in ihrem Körper. Die Organe werden kleiner, Herz- und Atemfrequenz sowie Körpertemperatur sind im Winter gesenkt. Egal, ob mit oder ohne Winterschlaf: Es heißt Energie sparen, um die Zeit der Minusgrade, des Schnees und Nahrungsmangels aushalten zu können.",
          "answer": "i",
          "explanation": "Der Text beschreibt verschiedene Strategien (geschützte Orte, Muskelzittern, körpereigene Gefrierschutzmittel, Energiesparen), mit denen Insekten den Winter überstehen ('Methoden zum Überleben in der kalten Jahreszeit')."
        }
      ]
    },
    {
      "id": "7",
      "title": "Test 7 – Rauchen, Bergurlaub & Sportvereine",
      "isVariant": false,
      "headings": {
        "a": "Freizeitsport in den Alpen",
        "b": "Mädchen geben mehr Geld für Zigaretten aus als Jungen",
        "c": "Hochgebirge als Skiparadies",
        "d": "Höhenluft – gut fürs Herz",
        "e": "Junge Sportler: weniger suchtanfällig",
        "f": "Mit der Zigarette an die frische Luft",
        "g": "Rauchverbot in Sportvereinen",
        "h": "Uni-Campus: rauchfreie Zone eingerichtet",
        "i": "Zigaretten gegen Alleinsein",
        "j": "Zum Leistungssport in die Berge"
      },
      "items": [
        {
          "num": 1,
          "text": "Für Raucher wird es an der Universität in Köln ab dem kommenden Wintersemester eng. Denn nach zahllosen Beschwerden sowohl vom Personal der Universität als auch von Studierenden erweiterte nun die Universitätsverwaltung das bereits bestehende Rauchverbot. Bisher erstreckte es sich nur auf Hörsäle und Seminarräume. Doch kaum waren die Veranstaltungen zu Ende, fand man sich in den Fluren, Foyers und Cafeterias eingehüllt in dicke Schwaden von Zigarettenqualm wieder. Dieser Zustand war vielen Nichtrauchern schon seit Längerem ein Dorn im Auge. Unterstützt von mehreren Untersuchungsberichten über die Gefahren des passiven Rauchens und angespornt von den guten Erfahrungen, die man an ausländischen Universitäten – vor allem in den USA – mit Rauchverboten gemacht hat, wollten die Nichtraucher diesen Zustand nicht länger hinnehmen. Das Rauchverbot gilt nun in allen Gebäuden einschließlich der Toiletten. Die Professoren und Studierenden, die das Qualmen auch künftig nicht lassen können, werden in ihren Rauchpausen im kommenden Winter irgendwo auf dem Campus ganz sicher kalte Füße bekommen.",
          "answer": "f",
          "explanation": "Da das Rauchverbot nun in allen Gebäuden der Universität Köln gilt, müssen Raucher zum Rauchen nach draußen auf den Campus gehen ('Mit der Zigarette an die frische Luft')."
        },
        {
          "num": 2,
          "text": "Urlaub in den Bergen ist sehr gesund. Das fanden jetzt Wissenschaftler am Anatomischen Zentrum der Universität Köln heraus. Besonders die Höhenlagen um die 2.000 Meter wirken sich messbar positiv auf die Gesundheit aus. Die „dünnere Luft“ in Hochgebirgslagen bewirke eine Senkung des Blutdrucks und des Pulsschlages, eine verbesserte Leistungsfähigkeit des Herzens und damit eine Stärkung der Funktion von Herz, Lunge und Kreislauf. Wichtig sei es aber, in den ersten Tagen auf eine ausreichende Akklimatisierung zu achten. Denn etwa eine Woche benötige der Körper, um sich an die neuen klimatischen Bedingungen im Gebirge anzupassen. Während dieser Zeit solle man, so die Wissenschaftler, größere körperliche Anstrengungen und Extremsport vermeiden. Ab der zweiten Urlaubswoche habe man dann seine volle körperliche Leistungsfähigkeit erreicht.",
          "answer": "d",
          "explanation": "Studien zeigen, dass die dünnere Luft in 2.000 Metern Höhe Blutdruck und Puls senkt und Herz sowie Kreislauf stärkt ('Höhenluft – gut fürs Herz')."
        },
        {
          "num": 3,
          "text": "Schlechte Haut, übler Atem, leere Brieftasche. Das ist eigentlich ziemlich „uncool“. Und doch dauert es ziemlich lange, bis junge Raucher begriffen haben, dass Rauchen nicht hält, was viele Jugendliche in ihrer Phantasie damit verbinden: Freiheit und Attraktivität – der Glimmstängel macht „cool“ und begehrenswert. Stress und Leistungsdruck verfliegen angeblich, sobald man nur an der Zigarette zieht. Doch das Gegenteil ist der Fall: Die zuerst genannten Negativfolgen stellen sich oft schneller ein als gedacht. Häufig ist es aber dann schon zu spät, denn das Entwöhnen von der Sucht des Rauchens ist ein langwieriger und oft auch schmerzhafter Weg. Obwohl dies alles bekannt ist, finden es in Deutschland fast 50 % aller Teenager zwischen 12 und 16 Jahren schick, Zigaretten zu konsumieren – ein eindeutig zu großer Anteil, warnen die Gesundheitsbehörden. Besonders groß ist der prozentuale Anteil der Raucher übrigens unter den jungen Mädchen. Als Raucherinnen fühlen sie sich erwachsen und der Cliquendruck – nahezu alle Freunde und Freundinnen rauchen auch – erzeugt oft ein vermeintliches Notwendigkeitsgefühl, auch zu rauchen.",
          "answer": "b",
          "explanation": "Unter den rauchenden Teenagern ist der prozentuale Anteil bei jungen Mädchen besonders groß ('Mädchen geben mehr Geld für Zigaretten aus als Jungen')."
        },
        {
          "num": 4,
          "text": "Sport im Hochgebirge? Da denkt man zuallererst an Wintersport: Ski fahren, rodeln, eislaufen. Doch auch im Sommer ist das Hochgebirge ein Ort, an dem man sich vielfältig sportlich betätigen kann: Wandern, Klettern oder Schwimmen in einem der zahlreichen kristallklaren Bergseen erfreuen sich großer Beliebtheit bei Jung und Alt. In Deutschland ist Hochgebirgssport vor allem in den Alpenregionen im südlichen Bayern möglich. Es muss jedoch nicht unbedingt gleich Deutschlands höchster Berg – die Zugspitze – sein, die man als Ziel ansteuert. Auch rund um Oberstdorf, Füssen, Berchtesgaden oder rund um den Tegernsee bieten sich viele Möglichkeiten für sportliche Naturliebhaber wie für naturverbundene Sportler. Für die zumeist städtischen Urlauber, die hier vor allem Ruhe und Erholung vom Alltagsstress suchen, haben die deutschen Alpengebiete außerdem den Vorteil, dass man keine weiten Wege zurücklegen muss, wenn einen das Heimweh nach der Stadt packt, nach Schwimmhallen, Fußballstadien oder Golfplätzen. Denn für die Stadtsportler ist es von keinem Alpenort weiter als eine gute Stunde in die bayerische Landeshauptstadt München.",
          "answer": "a",
          "explanation": "Der Text stellt die vielfältigen Möglichkeiten für Sommer- und Wintersport für Urlauber in den bayerischen Alpen vor ('Freizeitsport in den Alpen')."
        },
        {
          "num": 5,
          "text": "Sportvereine spielen eine immer wichtigere soziale Rolle für junge Leute in Deutschland. Das haben neueste Untersuchungen an den Tag gebracht. Ging man früher in einen Sportverein, um Fußball zu spielen, zu reiten oder zu turnen, geben die Clubs heute vielen Jugendlichen ein zweites Zuhause. Hier treffen sich Freunde, hier kümmert sich jemand um sie, hier haben sie eine Aufgabe. Zuhause fühlen sie sich einsam und überflüssig. Die Eltern arbeiten und sind nicht da, die Kommunikation mit dem Fernseher oder dem Computer ist eine recht einseitige Angelegenheit. Jugendliche, die in Sportvereinen Mitglied sind, sind geselliger, werden – so zahlreiche Studien – weniger gewalttätig, leben gesundheitsbewusster, rauchen deutlich weniger als ihre Altersgenossen, die nicht im Verein sind, konsumieren erheblich weniger Alkohol oder gar Drogen. Das Zugehörigkeitsgefühl zum Verein und das Gefühl, etwas zu leisten, tragen sehr stark dazu bei, dass die jungen Leute gegen die Verführungen der Zigaretten- und Alkoholindustrie resistent werden.",
          "answer": "e",
          "explanation": "Jugendliche in Sportvereinen rauchen deutlich weniger und konsumieren viel weniger Alkohol oder Drogen als Gleichaltrige ('Junge Sportler: weniger suchtanfällig')."
        }
      ]
    },
    {
      "id": "7a",
      "title": "Test 7a – Rauchen, Bergurlaub & Sportvereine (Variante 1)",
      "isVariant": true,
      "headings": {
        "a": "Freizeitsport in den Alpen",
        "b": "Mädchen geben mehr Geld für Zigaretten aus als Jungen",
        "c": "Hochgebirge als Skiparadies",
        "d": "Höhenluft – gut fürs Herz",
        "e": "Vereine wirken positiv auf Jugendliche",
        "f": "Lehrer berichten von ihren Erfahrungen mit dem Rauchen",
        "g": "Rauchverbot in Sportvereinen",
        "h": "Studenten engagieren sich gegen das Rauchen",
        "i": "Zigaretten gegen Alleinsein",
        "j": "Zum Leistungssport in die Berge"
      },
      "items": [
        {
          "num": 1,
          "text": "Seit einigen Jahren schon gibt es das bundesweite Projekt „Aufklärung gegen Tabak“. Ins Leben gerufen hat es ein Medizinstudent. Mittlerweile machen rund 500 Studenten in 23 deutschen Städten mit und klären Schüler der sechsten bis achten Klasse über die Gefahren des Rauchens auf. „Unser Ziel ist es, die Kinder möglichst früh anzusprechen und präventiv zu arbeiten“, erklärt Ailis Haney, die im vierten Semester in Heidelberg Medizin studiert. „Dabei ist es auch hilfreich, dass wir Studenten die Kinder aufklären und nicht etwa ihre Lehrer. Da wir selbst noch nicht so alt sind, entstehen leichter Gespräche auf Augenhöhe.“ Die Medizinstudenten wollen die Möglichkeit auch nutzen, um ihr während des Studiums erworbenes Wissen an die Schüler weiterzugeben: Nach einer Präsentation bieten sie in einzelnen Klassen Seminare an, bei denen die Kinder teilweise spielerisch die Gefahren des Rauchens kennenlernen. An einem Modell wird beispielsweise gezeigt, welche Teile des Körpers durch das Rauchen geschädigt werden können.",
          "answer": "h",
          "explanation": "Rund 500 Medizinstudenten klären im Projekt „Aufklärung gegen Tabak“ Schüler über die Gefahren des Rauchens auf ('Studenten engagieren sich gegen das Rauchen')."
        },
        {
          "num": 2,
          "text": "Urlaub in den Bergen ist sehr gesund. Das fanden jetzt Wissenschaftler am Anatomischen Zentrum der Universität Köln heraus. Besonders die Höhenlagen um die 2.000 Meter wirken sich messbar positiv auf die Gesundheit aus. Die „dünnere Luft“ in Hochgebirgslagen bewirke eine Senkung des Blutdrucks und des Pulsschlages, eine verbesserte Leistungsfähigkeit des Herzens und damit eine Stärkung der Funktion von Herz, Lunge und Kreislauf. Wichtig sei es aber, in den ersten Tagen auf eine ausreichende Akklimatisierung zu achten. Denn etwa eine Woche benötige der Körper, um sich an die neuen klimatischen Bedingungen im Gebirge anzupassen. Während dieser Zeit solle man, so die Wissenschaftler, größere körperliche Anstrengungen und Extremsport vermeiden. Ab der zweiten Urlaubswoche habe man dann seine volle körperliche Leistungsfähigkeit erreicht.",
          "answer": "d",
          "explanation": "Studien zeigen, dass die dünnere Luft in 2.000 Metern Höhe Blutdruck und Puls senkt und Herz sowie Kreislauf stärkt ('Höhenluft – gut fürs Herz')."
        },
        {
          "num": 3,
          "text": "Schlechte Haut, übler Atem, leere Brieftasche. Das ist eigentlich ziemlich „uncool“. Und doch dauert es ziemlich lange, bis junge Raucher begriffen haben, dass Rauchen nicht hält, was viele Jugendliche in ihrer Phantasie damit verbinden: Freiheit und Attraktivität – der Glimmstängel macht „cool“ und begehrenswert. Stress und Leistungsdruck verfliegen angeblich, sobald man nur an der Zigarette zieht. Doch das Gegenteil ist der Fall: Die zuerst genannten Negativfolgen stellen sich oft schneller ein als gedacht. Häufig ist es aber dann schon zu spät, denn das Entwöhnen von der Sucht des Rauchens ist ein langwieriger und oft auch schmerzhafter Weg. Obwohl dies alles bekannt ist, finden es in Deutschland fast 50 % aller Teenager zwischen 12 und 16 Jahren schick, Zigaretten zu konsumieren – ein eindeutig zu großer Anteil, warnen die Gesundheitsbehörden. Besonders groß ist der prozentuale Anteil der Raucher übrigens unter den jungen Mädchen. Als Raucherinnen fühlen sie sich erwachsen und der Cliquendruck – nahezu alle Freunde und Freundinnen rauchen auch – erzeugt oft ein vermeintliches Notwendigkeitsgefühl, auch zu rauchen.",
          "answer": "b",
          "explanation": "Unter den rauchenden Teenagern ist der prozentuale Anteil bei jungen Mädchen besonders groß ('Mädchen geben mehr Geld für Zigaretten aus als Jungen')."
        },
        {
          "num": 4,
          "text": "Sport im Hochgebirge? Da denkt man zuallererst an Wintersport: Ski fahren, rodeln, eislaufen. Doch auch im Sommer ist das Hochgebirge ein Ort, an dem man sich vielfältig sportlich betätigen kann: Wandern, Klettern oder Schwimmen in einem der zahlreichen kristallklaren Bergseen erfreuen sich großer Beliebtheit bei Jung und Alt. In Deutschland ist Hochgebirgssport vor allem in den Alpenregionen im südlichen Bayern möglich. Es muss jedoch nicht unbedingt gleich Deutschlands höchster Berg – die Zugspitze – sein, die man als Ziel ansteuert. Auch rund um Oberstdorf, Füssen, Berchtesgaden oder rund um den Tegernsee bieten sich viele Möglichkeiten für sportliche Naturliebhaber wie für naturverbundene Sportler. Für die zumeist städtischen Urlauber, die hier vor allem Ruhe und Erholung vom Alltagsstress suchen, haben die deutschen Alpengebiete außerdem den Vorteil, dass man keine weiten Wege zurücklegen muss, wenn einen das Heimweh nach der Stadt packt, nach Schwimmhallen, Fußballstadien oder Golfplätzen. Denn für die Stadtsportler ist es von keinem Alpenort weiter als eine gute Stunde in die bayerische Landeshauptstadt München.",
          "answer": "a",
          "explanation": "Der Text stellt die vielfältigen Möglichkeiten für Sommer- und Wintersport für Urlauber in den bayerischen Alpen vor ('Freizeitsport in den Alpen')."
        },
        {
          "num": 5,
          "text": "Sportvereine spielen eine immer wichtigere soziale Rolle für junge Leute in Deutschland. Das haben neueste Untersuchungen an den Tag gebracht. Ging man früher in einen Sportverein, um Fußball zu spielen, zu reiten oder zu turnen, geben die Clubs heute vielen Jugendlichen ein zweites Zuhause. Hier treffen sich Freunde, hier kümmert sich jemand um sie, hier haben sie eine Aufgabe. Zuhause fühlen sie sich einsam und überflüssig. Die Eltern arbeiten und sind nicht da, die Kommunikation mit dem Fernseher oder dem Computer ist eine recht einseitige Angelegenheit. Jugendliche, die in Sportvereinen Mitglied sind, sind geselliger, werden – so zahlreiche Studien – weniger gewalttätig, leben gesundheitsbewusster, rauchen deutlich weniger als ihre Altersgenossen, die nicht im Verein sind, konsumieren erheblich weniger Alkohol oder gar Drogen. Das Zugehörigkeitsgefühl zum Verein und das Gefühl, etwas zu leisten, tragen sehr stark dazu bei, dass die jungen Leute gegen die Verführungen der Zigaretten- und Alkoholindustrie resistent werden.",
          "answer": "e",
          "explanation": "Sportvereine geben Jugendlichen Halt, machen sie geselliger, weniger gewalttätig und gesundheitsbewusster ('Vereine wirken positiv auf Jugendliche')."
        }
      ]
    },
    {
      "id": "7b",
      "title": "Test 7b – Rauchen, Bergurlaub & Sportvereine (Variante 2)",
      "isVariant": true,
      "headings": {
        "a": "Zum Leistungssport in die Berge",
        "b": "Zigaretten gegen Alleinsein",
        "c": "Vereine wirken positiv auf Jugendliche",
        "d": "Studenten engagieren sich gegen das Rauchen",
        "e": "Mädchen geben mehr Geld für Zigaretten aus als Jungen",
        "f": "Lehrer berichten von ihren Erfahrungen mit dem Rauchen",
        "g": "Höhenluft fördert die Gesundheit",
        "h": "Hochgebirge als Skiparadies",
        "i": "Freizeitsport in den Alpen",
        "j": "Alkohol- und Rauchverbot in Sportvereinen"
      },
      "items": [
        {
          "num": 1,
          "text": "Seit einigen Jahren schon gibt es das bundesweite Projekt „Aufklärung gegen Tabak“. Ins Leben gerufen hat es ein Medizinstudent. Mittlerweile machen rund 500 Studenten in 23 deutschen Städten mit und klären Schüler der sechsten bis achten Klasse über die Gefahren des Rauchens auf. „Unser Ziel ist es, die Kinder möglichst früh anzusprechen und präventiv zu arbeiten“, erklärt Ailis Haney, die im vierten Semester in Heidelberg Medizin studiert. „Dabei ist es auch hilfreich, dass wir Studenten die Kinder aufklären und nicht etwa ihre Lehrer. Da wir selbst noch nicht so alt sind, entstehen leichter Gespräche auf Augenhöhe.“ Die Medizinstudenten wollen die Möglichkeit auch nutzen, um ihr während des Studiums erworbenes Wissen an die Schüler weiterzugeben: Nach einer Präsentation bieten sie in einzelnen Klassen Seminare an, bei denen die Kinder teilweise spielerisch die Gefahren des Rauchens kennenlernen. An einem Modell wird beispielsweise gezeigt, welche Teile des Körpers durch das Rauchen geschädigt werden können.",
          "answer": "d",
          "explanation": "Rund 500 Medizinstudenten klären im Projekt „Aufklärung gegen Tabak“ Schüler über die Gefahren des Rauchens auf ('Studenten engagieren sich gegen das Rauchen')."
        },
        {
          "num": 2,
          "text": "Urlaub in den Bergen ist sehr gesund. Das fanden jetzt Wissenschaftler am Anatomischen Zentrum der Universität Köln heraus. Besonders die Höhenlagen um die 2.000 Meter wirken sich messbar positiv auf die Gesundheit aus. Die „dünnere Luft“ in Hochgebirgslagen bewirke eine Senkung des Blutdrucks und des Pulsschlages, eine verbesserte Leistungsfähigkeit des Herzens und damit eine Stärkung der Funktion von Herz, Lunge und Kreislauf. Wichtig sei es aber, in den ersten Tagen auf eine ausreichende Akklimatisierung zu achten. Denn etwa eine Woche benötige der Körper, um sich an die neuen klimatischen Bedingungen im Gebirge anzupassen. Während dieser Zeit solle man, so die Wissenschaftler, größere körperliche Anstrengungen und Extremsport vermeiden. Ab der zweiten Urlaubswoche habe man dann seine volle körperliche Leistungsfähigkeit erreicht.",
          "answer": "g",
          "explanation": "Studien zeigen, dass die dünnere Luft in 2.000 Metern Höhe Blutdruck und Puls senkt und Herz sowie Kreislauf stärkt ('Höhenluft fördert die Gesundheit')."
        },
        {
          "num": 3,
          "text": "Schlechte Haut, übler Atem, leere Brieftasche. Das ist eigentlich ziemlich „uncool“. Und doch dauert es ziemlich lange, bis junge Raucher begriffen haben, dass Rauchen nicht hält, was viele Jugendliche in ihrer Phantasie damit verbinden: Freiheit und Attraktivität – der Glimmstängel macht „cool“ und begehrenswert. Stress und Leistungsdruck verfliegen angeblich, sobald man nur an der Zigarette zieht. Doch das Gegenteil ist der Fall: Die zuerst genannten Negativfolgen stellen sich oft schneller ein als gedacht. Häufig ist es aber dann schon zu spät, denn das Entwöhnen von der Sucht des Rauchens ist ein langwieriger und oft auch schmerzhafter Weg. Obwohl dies alles bekannt ist, finden es in Deutschland fast 50 % aller Teenager zwischen 12 und 16 Jahren schick, Zigaretten zu konsumieren – ein eindeutig zu großer Anteil, warnen die Gesundheitsbehörden. Besonders groß ist der prozentuale Anteil der Raucher übrigens unter den jungen Mädchen. Als Raucherinnen fühlen sie sich erwachsen und der Cliquendruck – nahezu alle Freunde und Freundinnen rauchen auch – erzeugt oft ein vermeintliches Notwendigkeitsgefühl, auch zu rauchen.",
          "answer": "e",
          "explanation": "Unter den rauchenden Teenagern ist der prozentuale Anteil bei jungen Mädchen besonders groß ('Mädchen geben mehr Geld für Zigaretten aus als Jungen')."
        },
        {
          "num": 4,
          "text": "Sport im Hochgebirge? Da denkt man zuallererst an Wintersport: Ski fahren, rodeln, eislaufen. Doch auch im Sommer ist das Hochgebirge ein Ort, an dem man sich vielfältig sportlich betätigen kann: Wandern, Klettern oder Schwimmen in einem der zahlreichen kristallklaren Bergseen erfreuen sich großer Beliebtheit bei Jung und Alt. In Deutschland ist Hochgebirgssport vor allem in den Alpenregionen im südlichen Bayern möglich. Es muss jedoch nicht unbedingt gleich Deutschlands höchster Berg – die Zugspitze – sein, die man als Ziel ansteuert. Auch rund um Oberstdorf, Füssen, Berchtesgaden oder rund um den Tegernsee bieten sich viele Möglichkeiten für sportliche Naturliebhaber wie für naturverbundene Sportler. Für die zumeist städtischen Urlauber, die hier vor allem Ruhe und Erholung vom Alltagsstress suchen, haben die deutschen Alpengebiete außerdem den Vorteil, dass man keine weiten Wege zurücklegen muss, wenn einen das Heimweh nach der Stadt packt, nach Schwimmhallen, Fußballstadien oder Golfplätzen. Denn für die Stadtsportler ist es von keinem Alpenort weiter als eine gute Stunde in die bayerische Landeshauptstadt München.",
          "answer": "i",
          "explanation": "Der Text stellt die vielfältigen Möglichkeiten für Sommer- und Wintersport für Urlauber in den bayerischen Alpen vor ('Freizeitsport in den Alpen')."
        },
        {
          "num": 5,
          "text": "Sportvereine spielen eine immer wichtigere soziale Rolle für junge Leute in Deutschland. Das haben neueste Untersuchungen an den Tag gebracht. Ging man früher in einen Sportverein, um Fußball zu spielen, zu reiten oder zu turnen, geben die Clubs heute vielen Jugendlichen ein zweites Zuhause. Hier treffen sich Freunde, hier kümmert sich jemand um sie, hier haben sie eine Aufgabe. Zuhause fühlen sie sich einsam und überflüssig. Die Eltern arbeiten und sind nicht da, die Kommunikation mit dem Fernseher oder dem Computer ist eine recht einseitige Angelegenheit. Jugendliche, die in Sportvereinen Mitglied sind, sind geselliger, werden – so zahlreiche Studien – weniger gewalttätig, leben gesundheitsbewusster, rauchen deutlich weniger als ihre Altersgenossen, die nicht im Verein sind, konsumieren erheblich weniger Alkohol oder gar Drogen. Das Zugehörigkeitsgefühl zum Verein und das Gefühl, etwas zu leisten, tragen sehr stark dazu bei, dass die jungen Leute gegen die Verführungen der Zigaretten- und Alkoholindustrie resistent werden.",
          "answer": "c",
          "explanation": "Sportvereine geben Jugendlichen Halt, machen sie geselliger, weniger gewalttätig und gesundheitsbewusster ('Vereine wirken positiv auf Jugendliche')."
        }
      ]
    },
    {
      "id": "8",
      "title": "Test 8 – Frauen im Studium & Frauenwahlrecht",
      "isVariant": false,
      "headings": {
        "a": "Der heutige Anteil von Frauen im Medizinstudium",
        "b": "Die Frauen in der Französischen Revolution",
        "c": "Eine Pionierin der akademischen Frauenausbildung",
        "d": "Entwicklung des Frauenstimmrechts",
        "e": "Frauen erreichen zunehmend bessere Noten im Studium",
        "f": "Geschlechtsspezifische Entscheidungen an der Wahlurne",
        "g": "Studentinnen auf der Überholspur",
        "h": "Umfrage verspricht Erfolg der grünen Wahlkandidatin",
        "i": "Vorkämpferinnen für das Frauenwahlrecht",
        "j": "Wieder Demonstrationen für freie Wahlen"
      },
      "items": [
        {
          "num": 1,
          "text": "In Russland 1843 als Tochter eines Bauern geboren, schaffte es Nadeschda Suslowa ins Gymnasium. Mit 16 Jahren erhielt sie ihr Diplom als Hauslehrerin. Das war der höchste Abschluss, den eine Frau damals in Russland erreichen konnte. Doch Nadeschda wollte mehr. Die junge Frau wollte Ärztin werden. Weil es ihr in Russland aber nicht erlaubt war, eine Hochschule zu besuchen, ging sie ins Ausland. An der Universität Zürich konnten Frauen schon seit einigen Jahren Vorlesungen besuchen. Nadeschda Suslowa war die erste Frau, die sich ordentlich an der Universität einschreiben durfte, und gleichzeitig die erste Russin an der Zürcher Universität. Am 14. Dezember 1867 machte die damals 24-Jährige ihr Examen. Sie war die erste promovierte Ärztin in der Schweiz und in Russland. „Ich bin die Erste, aber nicht die Letzte. Nach mir werden Tausende kommen.“ Davon war sie überzeugt, und sie sollte recht behalten. Nach ihrem Abschluss ging sie zurück nach Russland und gründete dort eine eigene Praxis für Frauen- und Kinderheilkunde.",
          "answer": "c",
          "explanation": "Nadeschda Suslowa war die erste ordentlich eingeschriebene Studentin an der Universität Zürich und die erste promovierte Ärztin in der Schweiz und Russland ('Eine Pionierin der akademischen Frauenausbildung')."
        },
        {
          "num": 2,
          "text": "Dass Frauen wählen und gewählt werden dürfen, ist heutzutage selbstverständlich. Doch das war nicht immer so. Überall auf der Welt mussten sie lange erbittert um ihr Wahlrecht streiten. In Europa war die Französin Olympe de Gouges eine der ersten Frauen, die sich aktiv für das Wahlrecht der Bürgerinnen einsetzten. Sie forderte zu Zeiten der Französischen Revolution die rechtliche, politische und soziale Gleichstellung der Frau. Dies wurde zur Grundlage für die Einführung des Frauenwahlrechts in Europa. Frankreich gehörte allerdings nicht zu den ersten Ländern, in denen das Wahlrecht für Frauen realisiert wurde. Das geschah zuerst 1838 in der britischen Kolonie Pitcairn, einer Insel im südlichen Pazifik. Es folgten einzelne nordamerikanische Staaten, Neuseeland und Südaustralien. In Europa erlangten die Frauen das Wahlrecht zuerst in Finnland, zu Beginn des 20. Jahrhunderts. In Frankreich, dem Heimatland von Olympe de Gouges, wurde es erst 1944 eingeführt. Als eines der letzten europäischen Länder führte die Schweiz das Frauenwahlrecht 1971 ein – durch eine Volksabstimmung der männlichen Bevölkerung.",
          "answer": "d",
          "explanation": "Der Text zeichnet die historische Einführung des Frauenwahlrechts weltweit und in Europa von der Französischen Revolution bis 1971 nach ('Entwicklung des Frauenstimmrechts')."
        },
        {
          "num": 3,
          "text": "Das Wahlverhalten von Frauen hat sich in den letzten Jahrzehnten verändert: In den 50er Jahren wählten verheiratete Frauen oft noch so wie ihre Männer. Vor allem in der Mittelschicht zeigten sie eine deutliche Vorliebe für konservative Parteien. Die politischen Unruhen von 1968 hingegen hinterließen ihre Spuren im Wahlverhalten der Frauen. Sie wählten nun deutlich weniger konservativ und stimmten für Parteien, die sie in ihrem Anspruch auf Gleichberechtigung und Selbstständigkeit unterstützten. Auch heute wählen Männer und Frauen in vielen Ländern unterschiedlich. Frauen scheinen für radikale Parteien weniger Sympathie aufzubringen als Männer, während ihnen Gleichberechtigung ein großes Anliegen ist. Die Sorge um die Umwelt schlägt sich in einem höheren Anteil an Frauenstimmen für grüne Parteien nieder. Frauen wählen auch gerne Frauen. Deshalb geben sie ihre Stimmen bevorzugt Parteien, die mehr Kandidatinnen auf ihren Listen führen. Insgesamt scheint einiges darauf hinzudeuten, dass Frauen rationaler wählen als Männer.",
          "answer": "f",
          "explanation": "Der Text analysiert, wie sich das Wahlverhalten von Frauen verändert hat und worin sich die Wahlentscheidungen von Männern und Frauen unterscheiden ('Geschlechtsspezifische Entscheidungen an der Wahlurne')."
        },
        {
          "num": 4,
          "text": "In den vergangenen Jahrzehnten hat sich das Geschlechterverhältnis bei Studierenden stark verändert. Nicht nur bei Studienanfängern sind Frauen in der Mehrzahl, sondern auch unter jenen, die ein Hochschulstudium abschließen. Doch das ist noch nicht alles: Weibliche Studierende absolvieren das Studium schneller als ihre Kommilitonen und schließen es auch häufiger erfolgreich ab. Allerdings ist die Erfolgs- und Abschlussquote nicht in allen Studienrichtungen gleich. Am größten ist der Abstand beim Musikstudium: Mehr als 70 Prozent der Frauen schließen es tatsächlich ab, während rund 50 Prozent der männlichen Studienanfänger es abbrechen. Unterschiedliche Erfolgsquoten der Geschlechter lassen sich an den meisten Universitäten beobachten; nur vereinzelt sind sie gleich hoch oder bei Männern sogar etwas höher. Warum das so ist, darüber können Wissenschaftler vorerst nur Vermutungen anstellen. Die höchsten Abschlussquoten erreichen übrigens die Universitäten, für die es eine Zugangsbeschränkung gibt.",
          "answer": "g",
          "explanation": "Frauen stellen heute die Mehrheit der Studierenden, studieren schneller und schließen ihr Studium häufiger erfolgreich ab als Männer ('Studentinnen auf der Überholspur')."
        },
        {
          "num": 5,
          "text": "„Suffragetten“ – so nannte man Anfang des 20. Jahrhunderts die Frauen, die sich in Großbritannien für das allgemeine Frauenwahlrecht einsetzten. Der Begriff kommt von „suffrage“, was im Französischen und im Englischen „Wahlrecht“ bedeutet. Emmeline Pankhurst und ihre Töchter zählen zu den bekanntesten Persönlichkeiten der britischen Frauenbewegung. Sie setzten zunächst auf die Methode des passiven Widerstandes. Als der erhoffte Erfolg ausblieb und Gesetzesänderungen abgelehnt wurden, griffen sie zu immer härteren Mitteln, bis hin zu Brand- und Bombenanschlägen. Pankhurst wurde immer wieder verhaftet und eingesperrt. Ihr Kampf für das Wahlrecht der Frauen wurde durch den Ersten Weltkrieg unterbrochen. Nach Kriegsende bekamen Frauen ab 21 Jahren das Recht, zur Parlamentswahl anzutreten. Selbst wählen durften sie allerdings erst ab 30. Dass Frauen dasselbe Wahlrecht wie die Männer erhielten, erlebte Emmeline Pankhurst nicht mehr. Sie war drei Wochen vor dessen Einführung am 2. Juli 1928 gestorben.",
          "answer": "i",
          "explanation": "Der Text porträtiert Emmeline Pankhurst und die britischen Suffragetten, die für das Frauenwahlrecht kämpften ('Vorkämpferinnen für das Frauenwahlrecht')."
        }
      ]
    },
    {
      "id": "9",
      "title": "Test 9 – Gesunde Ernährung, Pflanzen & Gemüse",
      "isVariant": false,
      "headings": {
        "a": "Das ideale Gemüse für schwer Arbeitende",
        "b": "Ein schlankes Gemüse für schlanke Leute",
        "c": "Gesunde Ernährung mit Aloe Vera",
        "d": "Gesundes Leben schützt vor Zivilisationskrankheiten",
        "e": "Gesundheitsrisiken durch fettreiche Ernährung",
        "f": "Kartoffelrezepte als Zeitungsbeilage",
        "g": "Pflanzliche Kosmetik für gesunde Haut",
        "h": "Tolle Figur durch ausgewogene Ernährung",
        "i": "Von der Wildpflanze zum international geschätzten Nahrungsmittel",
        "j": "WHO untersucht Zusammenhang von Krebs und Herzinfarkt"
      },
      "items": [
        {
          "num": 1,
          "text": "Über zehntausend wissenschaftliche Studien wurden in den vergangenen Jahren im Auftrag der Weltgesundheitsorganisation WHO durchgeführt, um herauszubekommen, warum manche Menschen erheblich seltener an lebensgefährlichen Krankheiten wie Krebs oder Herzinfarkt erkranken als andere. Die Zahl dieser Erkrankungen hat nämlich in den Industriestaaten inzwischen einen traurigen Höhepunkt erreicht. Die Forscher fanden heraus, dass mit wenigen Tricks viele Menschen gesünder leben und damit ihr Leben verlängern könnten. Das Risiko eines Herzinfarkts kann man zum Beispiel durch den täglichen Verzehr eines Apfels und tägliches zwanzigminütiges Radfahren erheblich reduzieren. Die Entstehung von Krebs hemmt zum Beispiel der tägliche Genuss eines Löffels reinen Olivenöls oder eine große Tasse grünen Tees. Gegen Stress hilft Vitamin-C-reiche Ernährung und regelmäßiges Schwimmen.",
          "answer": "d",
          "explanation": "Studien der WHO zeigen, dass einfache Gewohnheiten wie gesunde Ernährung und Bewegung das Risiko für Herzinfarkt, Krebs und Stress deutlich senken ('Gesundes Leben schützt vor Zivilisationskrankheiten')."
        },
        {
          "num": 2,
          "text": "Am Mittelmeer und in Mexiko wächst die Aloe-Vera-Pflanze, der in der heutigen Naturmedizin eine wachsende Rolle zukommt. Durch die dickfleischigen Blätter dieser Pflanze ist für Schädlinge kein Hindurchkommen, deshalb kann sie in Plantagen ohne chemische Schutzmittel angebaut werden. Unter der dicken Haut der Pflanze befindet sich eine gelartige Flüssigkeit, deren Aufgabe darin besteht, Wasser möglichst lange zu speichern – schließlich ist die Pflanze in extrem trockenen Landschaften beheimatet. Dieses Gel ist sehr vitamin- und mineralstoffreich. In der Wundheilung ist Aloegel sehr effektiv. Kosmetisch wird es für Cremes benutzt, die Hauterkrankungen und leichte Verbrennungen wie zum Beispiel Sonnenbrand lindern, Feuchtigkeit spenden und die Haut straffen.",
          "answer": "g",
          "explanation": "Das Gel der Aloe-Vera-Pflanze wird in Cremes zur Wundheilung, bei Sonnenbrand sowie zur Feuchtigkeitspflege und Straffung der Haut eingesetzt ('Pflanzliche Kosmetik für gesunde Haut')."
        },
        {
          "num": 3,
          "text": "Eine der ältesten bekannten Gemüsesorten ist der Spargel. Schon vor 5000 Jahren war er bei den Chinesen bekannt. Geschätzt wurde er vor allem in der Medizin als Herzschutzmittel und zur Stärkung der körpereigenen Abwehrkräfte: Spargel hält gesund. Heute schätzen wir am Spargel besonders, dass er nicht dick macht. Die körperlich hart arbeitende Bevölkerung früherer Zeiten schätzte ihn deshalb nicht sehr, weil er kaum Energie lieferte. Im Südwesten Deutschlands wächst der Spargel von Mitte April bis zum Johannistag, dem 24. Juni. Besonders rund um Mainz, Darmstadt, Heidelberg, Bruchsal und in der Pfalz erntet man das stangenförmige Gemüse. In Deutschland ist allerdings der weiße Spargel, der unter der Erde wächst, populärer als sein oberirdisch wachsender Bruder, der grüne Spargel.",
          "answer": "b",
          "explanation": "Spargel ist ein stangenförmiges („schlankes“) Gemüse, das kaum Kalorien liefert und daher nicht dick macht ('Ein schlankes Gemüse für schlanke Leute')."
        },
        {
          "num": 4,
          "text": "Schlank sein ist „in“. Deshalb versuchen Millionen Menschen nicht nur in Deutschland immer wieder ihre Pfunde loszuwerden. Und so purzeln sie von einer Diät zur nächsten, immer mit dem gleichen Erfolg: Nach dem Abnehmen nehmen sie genauso schnell wieder zu. Und bei vielen kommt mit dem Gewichtsverlust die Krankheit, denn die meisten Diäten sind sehr einseitig und entziehen dem Körper viele für sein Wohlbefinden wichtige Nährstoffe. Hier setzt eine neue Theorie an: Sie unterscheidet Nahrungsmittel in Fetthorter, die Fett im Körper speichern, und Fatburner, die dem Körper helfen, zu viel Fett und damit Kilos zu verwerten. Frisches Gemüse, Obst, Fisch und Geflügel versorgen den Körper mit Energie und helfen ihm dabei, die Nahrungsstoffe optimal zu verwerten. „Iss dich schlank“, lautet das Motto der Fatburnertheorie. Aber ist es nur eine neue Theorie oder hilft sie uns wirklich, schlank zu werden?",
          "answer": "h",
          "explanation": "Statt einseitiger Diäten setzt die Fatburner-Theorie auf frisches Gemüse, Obst, Fisch und Geflügel zum Abnehmen ('Tolle Figur durch ausgewogene Ernährung')."
        },
        {
          "num": 5,
          "text": "Als typisch deutsch gilt sie, doch rund um den Globus ist sie eines der Basislebensmittel schlechthin. In Österreich nennt man sie Erdapfel, an der Mosel heißt sie Grumbeere. Gemeint ist die überaus populäre Kartoffel. Hunderte verschiedener Sorten gibt es auf der Welt, doch ihr Ursprung liegt in Südamerika. Präkolumbianische Kulturen begannen damit, die bis dahin wild wachsende Urform der Kartoffel systematisch anzubauen. Die englischen Seehelden Sir Francis Drake und Sir Walter Raleigh sollen sie im 16. Jahrhundert nach Europa mitgebracht haben. Etwa zur gleichen Zeit wurde sie in Spanien und Portugal bekannt. Dennoch ist das Klischee von der „deutschen“ Kartoffel nicht ganz falsch, denn zu vielen traditionellen Gerichten wird die Knolle gekocht oder in der Form von Bratkartoffeln, Kartoffelknödeln oder Pommes frites als Beilage gereicht. Informationen rund um die Kartoffel in www.rheinzeitung.de/kartoffel.",
          "answer": "i",
          "explanation": "Die ursprünglich in Südamerika wild wachsende Kartoffel wurde zu einem weltweit beliebten Grundnahrungsmittel ('Von der Wildpflanze zum international geschätzten Nahrungsmittel')."
        }
      ]
    },
    {
      "id": "9a",
      "title": "Test 9a – Gesunde Ernährung, Pflanzen & Gemüse (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Das ideale Gemüse für schwer Arbeitende",
        "b": "Ein schlankes Gemüse für schlanke Leute",
        "c": "Gesundes Leben schützt vor Zivilisationskrankheiten",
        "d": "Gesundheitsrisiken durch fettreiche Ernährung",
        "e": "Kartoffelrezepte als Zeitungsbeilage",
        "f": "Pflanzliche Stoffe für die Gesundheit der Haut",
        "g": "Tolle Figur durch ausgewogene Ernährung",
        "h": "Vitaminreiche Ernährung mit Aloe Vera",
        "i": "Von der Wildpflanze zum international geschätzten Nahrungsmittel",
        "j": "WHO untersucht Zusammenhang von Krebs und Herzinfarkt"
      },
      "items": [
        {
          "num": 1,
          "text": "Über zehntausend wissenschaftliche Studien wurden in den vergangenen Jahren im Auftrag der Weltgesundheitsorganisation WHO durchgeführt, um herauszubekommen, warum manche Menschen erheblich seltener an lebensgefährlichen Krankheiten wie Krebs oder Herzinfarkt erkranken als andere. Die Zahl dieser Erkrankungen hat nämlich in den Industriestaaten inzwischen einen traurigen Höhepunkt erreicht. Die Forscher fanden heraus, dass mit wenigen Tricks viele Menschen gesünder leben und damit ihr Leben verlängern könnten. Das Risiko eines Herzinfarkts kann man zum Beispiel durch den täglichen Verzehr eines Apfels und tägliches zwanzigminütiges Radfahren erheblich reduzieren. Die Entstehung von Krebs hemmt zum Beispiel der tägliche Genuss eines Löffels reinen Olivenöls oder eine große Tasse grünen Tees. Gegen Stress hilft Vitamin-C-reiche Ernährung und regelmäßiges Schwimmen.",
          "answer": "c",
          "explanation": "Studien der WHO zeigen, dass einfache Gewohnheiten wie gesunde Ernährung und Bewegung das Risiko für Herzinfarkt, Krebs und Stress deutlich senken ('Gesundes Leben schützt vor Zivilisationskrankheiten')."
        },
        {
          "num": 2,
          "text": "Am Mittelmeer und in Mexiko wächst die Aloe-Vera-Pflanze, der in der heutigen Naturmedizin eine wachsende Rolle zukommt. Durch die dickfleischigen Blätter dieser Pflanze ist für Schädlinge kein Hindurchkommen, deshalb kann sie in Plantagen ohne chemische Schutzmittel angebaut werden. Unter der dicken Haut der Pflanze befindet sich eine gelartige Flüssigkeit, deren Aufgabe darin besteht, Wasser möglichst lange zu speichern – schließlich ist die Pflanze in extrem trockenen Landschaften beheimatet. Dieses Gel ist sehr vitamin- und mineralstoffreich. In der Wundheilung ist Aloegel sehr effektiv. Kosmetisch wird es für Cremes benutzt, die Hauterkrankungen und leichte Verbrennungen wie zum Beispiel Sonnenbrand lindern, Feuchtigkeit spenden und die Haut straffen.",
          "answer": "f",
          "explanation": "Das Gel der Aloe-Vera-Pflanze wird in Cremes zur Wundheilung, bei Sonnenbrand sowie zur Feuchtigkeitspflege und Straffung der Haut eingesetzt ('Pflanzliche Stoffe für die Gesundheit der Haut')."
        },
        {
          "num": 3,
          "text": "Eine der ältesten bekannten Gemüsesorten ist der Spargel. Schon vor 5000 Jahren war er bei den Chinesen bekannt. Geschätzt wurde er vor allem in der Medizin als Herzschutzmittel und zur Stärkung der körpereigenen Abwehrkräfte: Spargel hält gesund. Heute schätzen wir am Spargel besonders, dass er nicht dick macht. Die körperlich hart arbeitende Bevölkerung früherer Zeiten schätzte ihn deshalb nicht sehr, weil er kaum Energie lieferte. Im Südwesten Deutschlands wächst der Spargel von Mitte April bis zum Johannistag, dem 24. Juni. Besonders rund um Mainz, Darmstadt, Heidelberg, Bruchsal und in der Pfalz erntet man das stangenförmige Gemüse. In Deutschland ist allerdings der weiße Spargel, der unter der Erde wächst, populärer als sein oberirdisch wachsender Bruder, der grüne Spargel.",
          "answer": "b",
          "explanation": "Spargel ist ein stangenförmiges („schlankes“) Gemüse, das kaum Kalorien liefert und daher nicht dick macht ('Ein schlankes Gemüse für schlanke Leute')."
        },
        {
          "num": 4,
          "text": "Schlank sein ist „in“. Deshalb versuchen Millionen Menschen nicht nur in Deutschland immer wieder ihre Pfunde loszuwerden. Und so purzeln sie von einer Diät zur nächsten, immer mit dem gleichen Erfolg: Nach dem Abnehmen nehmen sie genauso schnell wieder zu. Und bei vielen kommt mit dem Gewichtsverlust die Krankheit, denn die meisten Diäten sind sehr einseitig und entziehen dem Körper viele für sein Wohlbefinden wichtige Nährstoffe. Hier setzt eine neue Theorie an: Sie unterscheidet Nahrungsmittel in Fetthorter, die Fett im Körper speichern, und Fatburner, die dem Körper helfen, zu viel Fett und damit Kilos zu verwerten. Frisches Gemüse, Obst, Fisch und Geflügel versorgen den Körper mit Energie und helfen ihm dabei, die Nahrungsstoffe optimal zu verwerten. „Iss dich schlank“, lautet das Motto der Fatburnertheorie. Aber ist es nur eine neue Theorie oder hilft sie uns wirklich, schlank zu werden?",
          "answer": "g",
          "explanation": "Statt einseitiger Diäten setzt die Fatburner-Theorie auf frisches Gemüse, Obst, Fisch und Geflügel zum Abnehmen ('Tolle Figur durch ausgewogene Ernährung')."
        },
        {
          "num": 5,
          "text": "Als typisch deutsch gilt sie, doch rund um den Globus ist sie eines der Basislebensmittel schlechthin. In Österreich nennt man sie Erdapfel, an der Mosel heißt sie Grumbeere. Gemeint ist die überaus populäre Kartoffel. Hunderte verschiedener Sorten gibt es auf der Welt, doch ihr Ursprung liegt in Südamerika. Präkolumbianische Kulturen begannen damit, die bis dahin wild wachsende Urform der Kartoffel systematisch anzubauen. Die englischen Seehelden Sir Francis Drake und Sir Walter Raleigh sollen sie im 16. Jahrhundert nach Europa mitgebracht haben. Etwa zur gleichen Zeit wurde sie in Spanien und Portugal bekannt. Dennoch ist das Klischee von der „deutschen“ Kartoffel nicht ganz falsch, denn zu vielen traditionellen Gerichten wird die Knolle gekocht oder in der Form von Bratkartoffeln, Kartoffelknödeln oder Pommes frites als Beilage gereicht. Informationen rund um die Kartoffel in www.rheinzeitung.de/kartoffel.",
          "answer": "i",
          "explanation": "Die ursprünglich in Südamerika wild wachsende Kartoffel wurde zu einem weltweit beliebten Grundnahrungsmittel ('Von der Wildpflanze zum international geschätzten Nahrungsmittel')."
        }
      ]
    },
    {
      "id": "10",
      "title": "Test 10 – Umwelt, Tiere & Forschung",
      "isVariant": false,
      "headings": {
        "a": "Neue Heuschreckenart in Frankreich entdeckt",
        "b": "Kleine Plagegeister können Krankheiten bringen",
        "c": "Landwirte wollen Gift gegen schädliche Insekten einsetzen",
        "d": "Neue Mittel gegen Mücken",
        "e": "Neue Studie: Nicht nur Affen und Delfine erkennen sich selbst",
        "f": "Probleme beim Versuchsaufbau: Studie gescheitert",
        "g": "Rhein nach Chemieunfall noch immer tot",
        "h": "Rückblick: Fischsterben im Rhein",
        "i": "Um die Zukunft der Nordsee ist es schlecht bestellt",
        "j": "WWF zieht positive Bilanz für die Nordsee"
      },
      "items": [
        {
          "num": 1,
          "text": "Die anhaltenden außergewöhnlich hohen Temperaturen haben im Süden Frankreichs eine Tierplage bisher unbekannten Ausmaßes ausgelöst. Bei den Plagegeistern handelt es sich um Unmengen von zwei bis dreieinhalb Zentimeter langen Heuschrecken, sogenannten Roten Schnarrschrecken. Die dunklen Insekten fressen Felder und Wiesen kahl und haben innerhalb von rund sechs Wochen die Landschaft in eine trostlose Steppe verwandelt. Die Landwirte der Region sind bereits verzweifelt, denn ihre gesamte Ernte hat sich buchstäblich in Luft aufgelöst. Wenn man über ein befallenes Feld geht, springt bei jedem Schritt ein Schnarrschreckenschwarm auf. Der Name dieser heimischen Tierart hat übrigens einen ganz einfachen Ursprung: Die Heuschrecken machen ein lautes Geräusch beim Springen – sie schnarren also – und man sieht an ihnen leuchtend rote Hinterflügel. Daher also „Rote Schnarrschrecke“. Manche Experten vermuten, die Heuschreckenplage werde durch einen drastischen Klimawandel ausgelöst. Die damit verbundene Aufheizung mache Südeuropa immer „afrikanischer“. Ein deutscher Wissenschaftsautor wies kürzlich im Internet mehrfach darauf hin, dass es im Laufe der Erdgeschichte ständig einen Wechsel von Warmzeiten und Kaltzeiten gegeben habe, der keineswegs abgeschlossen sei. Zeitweise habe das Gebiet von Europa nahe dem Äquator gelegen. Der Einsatz von Gift gegen die Heuschrecken ist sehr riskant. Denn dabei darf nur ein Mittel verwendet werden, das ausschließlich für die Heuschrecken tödlich ist, nicht aber für Bienen und andere Insekten. Auch das Vieh der Bauern darf nicht durch verseuchtes Futter gefährdet werden. Die einzige gute Nachricht: Für Menschen und andere Tiere sind die Heuschrecken völlig ungefährlich.",
          "answer": "c",
          "explanation": "Angesichts kahl gefressener Felder in Südfrankreich wird der riskante Einsatz von Gift gegen die Heuschreckenplage diskutiert ('Landwirte wollen Gift gegen schädliche Insekten einsetzen')."
        },
        {
          "num": 2,
          "text": "Für immer wird eine der größten Umweltkatastrophen mit dem Namen des damals in Basel ansässigen Chemiekonzerns Sandoz verbunden bleiben, der jetzt zu Novartis gehört. 1986 führte ein Brand in einer Lagerhalle des Konzerns zur Verunreinigung des Rheins mit 20 Tonnen hochgiftiger Pestizide und Insektizide. Auf einer Länge von 450 Kilometern kam es zu einem gigantischen Fischsterben. Vor allem Aale waren betroffen. Trinkwasser konnte nicht mehr aus dem Fluss gewonnen werden. Der öffentliche Druck, der als Reaktion auf die Umweltkatastrophe entstanden war, führte zu großen Investitionen für den Gewässerschutz. Im Rahmen des „Aktionsprogramms Rhein“ wurden rund 60 Milliarden Euro in den Ausbau von Kläranlagen entlang des Rheinufers investiert. Viele Schwermetalle wie Kupfer, Cadmium, Blei und Quecksilber konnten reduziert und teilweise sogar ganz aus dem Rhein verbannt werden. Angesichts der getroffenen Maßnahmen spricht die Internationale Kommission zum Schutz des Rheins (IKSR) heute wieder von „guter Wasserqualität“ des Rheins. 63 Fischarten sind wieder im Rhein vertreten, darunter auch Lachse. Die Aufgaben des Gewässerschutzes gehen aber noch weiter. Zink, Kupfer und Cadmium sowie Pestizide und Stickstoff bereiten weiterhin Sorgen. Kürzlich warnte das Verbraucherschutzministerium des Landes Nordrhein-Westfalen vor dem Verzehr von Rheinfischen unterhalb von Duisburg, weil Tenside durch die Nebenflüsse Möhne und Ruhr in den Rhein gelangt waren.",
          "answer": "h",
          "explanation": "Der Text blickt auf die Sandoz-Chemiekatastrophe von 1986 mit dem großen Fischsterben im Rhein und die anschließenden Schutzmaßnahmen zurück ('Rückblick: Fischsterben im Rhein')."
        },
        {
          "num": 3,
          "text": "Der Klimawandel bringt es in Verbindung mit der Globalisierung mit sich, dass auch in Deutschland Tiere heimisch werden, die hier zuvor nicht beobachtet wurden. Zu diesen Neuankömmlingen gehören auch exotische Stechmücken, beispielsweise der Japanische Buschmoskito. Mit den exotischen Stechmücken kommen auch neue Infektionserreger nach Deutschland, die möglicherweise auch bisher unbekannte Krankheiten beim Menschen auslösen können. Eine Forschergruppe identifizierte jetzt einige bisher nur in Afrika und Asien vorkommende Erreger. Anfang 2011 wurde ein interdisziplinäres Projekt ins Leben gerufen. Als ein erstes Ziel der Forschungsarbeit wird die Erstellung einer Mückenkarte für Deutschland angestrebt. „Innerhalb weniger Jahre wollen wir einen Überblick über die Artenverteilung der Mücken haben und wissen, was an Viren in ihnen steckt“, so der Leiter des Bernhard-Nocht-Instituts Professor Dr. Sven Klimpel. Das Bernhard-Nocht-Institut ist eine international anerkannte Forschungseinrichtung, die eine langjährige Erfahrung in der Virendiagnostik in das Projekt einbringen kann. Es verfügt über Laboratorien der höchsten Sicherheitsstufe, die erforderlich sind, um neue Viren mit unbekanntem Gefährdungspotenzial zu untersuchen. Mit den neu entdeckten, aus Asien stammenden Mückenarten konnten in Deutschland bisher 48 Stechmückenarten von den Entomologen nachgewiesen werden. Seit einigen Jahren breitet sich die Malaria-Mücke Anopheles plumbeus in Südwestdeutschland aus. Auch die Asiatische Tigermücke, die unter anderem das gefährliche Denguefieber verbreitet, schaffte es 2018 in die Schlagzeilen, weil sie am Rhein gefunden wurde.",
          "answer": "b",
          "explanation": "Exotische Stechmücken breiten sich in Deutschland aus und bringen gefährliche Krankheitserreger mit ('Kleine Plagegeister können Krankheiten bringen')."
        },
        {
          "num": 4,
          "text": "Forscher haben bei Versuchen im Bronx Zoo in New York eine neue Erkenntnis über Elefanten erlangt: Sie können sich selbst im Spiegel erkennen. Zumindest eines von drei Versuchstieren versuchte, einen auf seinem Kopf aufgemalten Fleck, der im Spiegelbild zu sehen war, zu entfernen. Bisher war unter anderem von Affen, Delfinen und Elstern ein ähnliches Verhalten bekannt. Und auch bei diesen reagierten nicht immer alle Versuchstiere auf einen Spiegel. Es gab auch schon in der Vergangenheit solche Tests mit Elefanten, die aber auf keine Selbsterkenntnis schließen ließen. Den Grund sieht ein Wissenschaftler im Versuchsaufbau: „Das große Problem ist, einen Spiegel zu haben, der ‚elefantenfest‘ ist.“ Frühere Versuche hätten zu kleine und zu schwer zugängliche Spiegel verwendet. Die Elefanten aber wollten „dagegen knallen, dahinter schauen, die Sache ausprobieren, bevor sie verstehen, was vor sich geht“. Deshalb wurde diesmal ein 2,5 mal 2,5 Meter großer Spiegel in einem Elefantengehege mit drei weiblichen asiatischen Elefanten montiert, der stabil genug für ausgiebige Untersuchungen durch die Tiere war. Bei ähnlichen Tests mit Affen und Delfinen gibt es normalerweise vier Phasen der Erkenntnis im Spiegel: Zuerst der Versuch der Kommunikation mit dem vermeintlichen Artgenossen, dann eine physische Inspektion des Spiegels, ein Testen des Verhaltens des Spiegelbilds und schließlich die Selbsterkenntnis. Die Elefanten übersprangen die erste Phase und schauten in Phase zwei hinter den Spiegel und griffen auch mit dem Rüssel dahinter. In Phase drei führten sie verschiedene Bewegungen durch und verglichen sie mit denen des Spiegelbildes. Auch wenn sich dann nur eines der Tiere selbst erkannte, indem es den aufgemalten Fleck untersuchte und nach einiger Zeit dann auch das Interesse an dem Fleck verlor, sehen die Wissenschaftler das Ergebnis als eindeutigen Beweis für die Fähigkeit zur Selbsterkenntnis. Als Nächstes wollen sie die Fähigkeiten von Elefanten auch in ihrer natürlichen Umgebung weiter erforschen.",
          "answer": "e",
          "explanation": "Versuche im Bronx Zoo beweisen, dass sich auch Elefanten – wie Affen und Delfine – im Spiegel selbst erkennen können ('Neue Studie: Nicht nur Affen und Delfine erkennen sich selbst')."
        },
        {
          "num": 5,
          "text": "Heute und morgen tagt in Göteborg die Internationale Nordseekonferenz (INK), an der Regierungsvertreter der acht Nordsee-Anrainerstaaten teilnehmen. Der World Wide Fund For Nature (WWF) kritisierte in diesem Zusammenhang, dass dies das letzte Treffen dieser Art sei. Künftig sollen Fragen der Nordsee auf europäischer Ebene behandelt werden. Der WWF befürchtet, dass die Berücksichtigung ökologischer Belange der Nordsee künftig im europäischen Rahmen vernachlässigt werde: „Es sieht nicht gut aus für die Nordsee.“ So fasste WWF-Meeresschützer Stefan Lutter diese Besorgnis in Worte. Der WWF ist der Ansicht, dass auf den Treffen der INK richtungsweisende Beschlüsse zum Nordseeschutz gefasst worden seien. Das Problem sei allerdings die Umsetzung dieser Beschlüsse in politisches Handeln in den Anrainerstaaten. Zu diesen Beschlüssen gehörte beispielsweise das 2001 vereinbarte Abkommen zum Verbot giftiger Schiffsfarben sowie ein weiteres Abkommen, das die Verunreinigung der Nordsee durch von Schiffen abgelassenes Ballastwasser bekämpfen sollte. Diese Abkommen wurden erst zum Teil umgesetzt. Der WWF befürchtet nun, dass diese wichtigen INK-Initiativen unter den Tisch fallen könnten. Anlässlich des letzten Treffens der Anrainerstaaten erneuerte der WWF seine Kritik an der Fischereipolitik. Das Ziel einer nachhaltigen Fischereipolitik stehe zwar auf der Tagesordnung der Konferenz, die alltägliche Praxis in der EU sei jedoch durch die „Plünderung der Fischbestände“ gekennzeichnet. Die Kabeljaubestände stünden kurz vor dem Zusammenbruch, sagte der WWF-Fischereiexperte. Ein notwendiger Fangstopp für diese Fischart sei jedoch nicht geplant. Ein weiteres ungelöstes Problem sei das Beifang-Problem. Der WWF-Sprecher brachte dazu folgendes Rechenbeispiel: Auf jedes Kilo Plattfisch, das auf den Tellern lande, gingen über fünf Kilo ungenutzter Beifang in die Netze der Fangflotten.",
          "answer": "i",
          "explanation": "Der WWF warnt vor Überfischung und mangelndem Umweltschutz in der Nordsee: „Es sieht nicht gut aus für die Nordsee“ ('Um die Zukunft der Nordsee ist es schlecht bestellt')."
        }
      ]
    },
    {
      "id": "10a",
      "title": "Test 10a – Umwelt, Tiere & Forschung (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Neue Insektenart in Frankreich",
        "b": "Kleine Insekten können Krankheiten bringen",
        "c": "Bauern sind gezwungen, Gift gegen schädliche Insekten einzusetzen",
        "d": "Neue Mittel gegen Mücken",
        "e": "Neue Studie: Nicht nur Affen und Delfine erkennen sich selbst",
        "f": "Probleme beim Versuchsaufbau: Studie gescheitert",
        "g": "Rhein nach Chemieunfall noch immer tot",
        "h": "Rückblick: Fischsterben im Rhein",
        "i": "Um die Zukunft der Nordsee ist es schlecht bestellt",
        "j": "WWF zieht positive Bilanz für die Nordsee"
      },
      "items": [
        {
          "num": 1,
          "text": "Heute tagt in Göteborg die Internationale Nordseekonferenz (INK), an der Regierungsvertreter der acht Nordsee-Länder teilnehmen. Der World Wide Fund For Nature (WWF) kritisierte in diesem Zusammenhang, dass dies das letzte Treffen dieser Art sei. Künftig sollen Fragen der Nordsee auf europäischer Ebene behandelt werden. Der WWF befürchtet, dass die Berücksichtigung ökologischer Belange der Nordsee künftig im europäischen Rahmen vernachlässigt werde: „Es sieht nicht gut aus für die Nordsee.“ So fasste WWF-Meeresschützer Stephan Lutter diese Besorgnis in Worte. Der WWF ist der Ansicht, dass auf den Treffen der INK richtungsweisende Beschlüsse zum Nordseeschutz gefasst worden seien. Das Problem sei allerdings die Umsetzung dieser Beschlüsse in politisches Handeln in den Nordsee-Ländern. Zu diesen Beschlüssen gehörte beispielsweise das vor Jahren beschlossene Abkommen zum Verbot giftiger Schiffsfarben und das Abkommen, das die Verunreinigung der Nordsee durch von Schiffen abgelassenes Ballastwasser bekämpfen sollte. Diese Abkommen wurden erst zum Teil umgesetzt. Der WWF befürchtet nun, dass diese wichtigen INK-Initiativen unter den Tisch fallen könnten. Anlässlich des letzten Treffens der Regierungen der Nordsee-Länder erneuerte der WWF seine Kritik an der Fischereipolitik. Das Ziel einer nachhaltigen Fischereipolitik stehe zwar auf der Tagesordnung der Konferenz, die alltägliche Praxis in der EU sei jedoch durch die „Plünderung der Fischbestände“ gekennzeichnet.",
          "answer": "i",
          "explanation": "Der WWF warnt vor Überfischung und mangelndem Umweltschutz in der Nordsee ('Um die Zukunft der Nordsee ist es schlecht bestellt')."
        },
        {
          "num": 2,
          "text": "Für immer wird eine der größten Umweltkatastrophen mit dem Namen des damals in Basel ansässigen Chemiekonzerns Sandoz verbunden bleiben, der jetzt zu Novartis gehört. 1986 führte ein Brand in einer Lagerhalle des Konzerns zur Verunreinigung des Rheins mit 20 Tonnen hochgiftiger Pestizide und Insektizide. Auf einer Länge von 450 Kilometern kam es zu einem gigantischen Fischsterben. Vor allem Aale waren betroffen. Trinkwasser konnte nicht mehr aus dem Fluss gewonnen werden. Der öffentliche Druck, der als Reaktion auf die Umweltkatastrophe entstanden war, führte zu großen Investitionen für den Gewässerschutz. Im Rahmen des „Aktionsprogramms Rhein“ wurden rund 60 Milliarden Euro in den Ausbau von Kläranlagen entlang des Rheinufers investiert. Viele Schwermetalle wie Kupfer, Cadmium, Blei und Quecksilber konnten reduziert und teilweise sogar ganz aus dem Rhein verbannt werden. Angesichts der getroffenen Maßnahmen spricht die Internationale Kommission zum Schutz des Rheins (IKSR) heute wieder von „guter Wasserqualität“ des Rheins, 63 Fischarten sind wieder im Rhein vertreten, darunter auch Lachse.",
          "answer": "h",
          "explanation": "Der Text blickt auf die Sandoz-Chemiekatastrophe von 1986 mit dem großen Fischsterben im Rhein und die anschließenden Schutzmaßnahmen zurück ('Rückblick: Fischsterben im Rhein')."
        },
        {
          "num": 3,
          "text": "Der Klimawandel bringt es in Verbindung mit der Globalisierung mit sich, dass auch in Deutschland Tiere heimisch werden, die hier zuvor nicht beobachtet wurden. Zu diesen Neuankömmlingen gehören auch exotische Stechmücken, beispielsweise der Japanische Buschmoskito. Mit den exotischen Stechmücken kommen auch neue Infektionserreger nach Deutschland, die möglicherweise auch bisher unbekannte Krankheiten beim Menschen auslösen können. Eine Forschergruppe identifizierte jetzt einige bisher nur in Afrika und Asien vorkommende Erreger. Anfang 2011 wurde ein interdisziplinäres Projekt ins Leben gerufen. Als ein erstes Ziel der Forschungsarbeit wird die Erstellung einer Mückenkarte für Deutschland angestrebt. „Innerhalb weniger Jahre wollen wir einen Überblick über die Artenverteilung der Mücken haben und wissen, was an Viren in ihnen steckt“, so der Leiter des Bernhard-Nocht-Instituts Professor Dr. Sven Klimpel. Das Bernhard-Nocht-Institut ist eine international anerkannte Forschungseinrichtung, die eine langjährige Erfahrung in der Virendiagnostik in das Projekt einbringen kann. Es verfügt über Laboratorien der höchsten Sicherheitsstufe, die erforderlich sind, um neue Viren mit unbekanntem Gefährdungspotenzial zu untersuchen.",
          "answer": "b",
          "explanation": "Exotische Stechmücken breiten sich in Deutschland aus und bringen gefährliche Krankheitserreger mit ('Kleine Insekten können Krankheiten bringen')."
        },
        {
          "num": 4,
          "text": "Forscher haben bei Versuchen im Bronx Zoo in New York eine neue Erkenntnis über Elefanten erlangt: Sie können sich selbst im Spiegel erkennen. Zumindest eines von drei Versuchstieren versuchte, einen auf seinem Kopf aufgemalten Fleck, der im Spiegelbild zu sehen war, zu entfernen. Bisher war unter anderem von Affen, Delfinen und Elstern ein ähnliches Verhalten bekannt. Und auch bei diesen reagierten nicht immer alle Versuchstiere auf einen Spiegel. Es gab auch schon in der Vergangenheit solche Tests mit Elefanten, die aber auf keine Selbsterkenntnis schließen ließen. Den Grund sieht ein Wissenschaftler im Versuchsaufbau: „Das große Problem ist, einen Spiegel zu haben, der ‚elefantenfest‘ ist.“ Frühere Versuche hätten zu kleine und zu schwer zugängliche Spiegel verwendet. Die Elefanten aber wollten „dagegen knallen, dahinter schauen, die Sache ausprobieren, bevor sie verstehen, was vor sich geht“. Deshalb wurde diesmal ein 2,5 mal 2,5 Meter großer Spiegel in einem Elefantengehege mit drei weiblichen asiatischen Elefanten montiert, der stabil genug für ausgiebige Untersuchungen durch die Tiere war. Bei ähnlichen Tests mit Affen und Delfinen gibt es normalerweise vier Phasen der Erkenntnis im Spiegel: Zuerst der Versuch der Kommunikation mit dem vermeintlichen Artgenossen, dann eine physische Inspektion des Spiegels, ein Testen des Verhaltens des Spiegelbilds und schließlich die Selbsterkenntnis. Die Elefanten übersprangen die erste Phase und schauten in Phase zwei hinter den Spiegel und griffen auch mit dem Rüssel dahinter. In Phase drei führten sie verschiedene Bewegungen durch und verglichen sie mit denen des Spiegelbildes. Auch wenn sich dann nur eines der Tiere selbst erkannte, indem es den aufgemalten Fleck untersuchte und nach einiger Zeit dann auch das Interesse an dem Fleck verlor, sehen die Wissenschaftler das Ergebnis als eindeutigen Beweis für die Fähigkeit zur Selbsterkenntnis.",
          "answer": "e",
          "explanation": "Versuche im Bronx Zoo beweisen, dass sich auch Elefanten – wie Affen und Delfine – im Spiegel selbst erkennen können ('Neue Studie: Nicht nur Affen und Delfine erkennen sich selbst')."
        },
        {
          "num": 5,
          "text": "Die anhaltenden außergewöhnlich hohen Temperaturen haben im Süden Frankreichs eine Tierplage bisher unbekannten Ausmaßes ausgelöst. Bei den Plagegeistern handelt es sich um Unmengen von zwei bis dreieinhalb Zentimeter langen Heuschrecken, sogenannten Roten Schnarrschrecken. Die dunklen Insekten fressen Felder und Wiesen kahl und haben innerhalb von rund sechs Wochen die Landschaft in eine trostlose Steppe verwandelt. Die Landwirte der Region sind bereits verzweifelt, denn ihre gesamte Ernte hat sich buchstäblich in Luft aufgelöst. Wenn man über ein befallenes Feld geht, springt bei jedem Schritt ein Schnarrschreckenschwarm auf. Der Name dieser heimischen Tierart hat übrigens einen ganz einfachen Ursprung: Die Heuschrecken machen ein lautes Geräusch beim Springen – sie schnarren also – und man sieht an ihnen leuchtend rote Hinterflügel. Daher also „Rote Schnarrschrecke“. Manche Experten vermuten, die Heuschreckenplage werde durch einen drastischen Klimawandel ausgelöst. Die damit verbundene Aufheizung mache Südeuropa immer „afrikanischer“. Ein deutscher Wissenschaftsautor wies kürzlich im Internet mehrfach darauf hin, dass es im Laufe der Erdgeschichte ständig einen Wechsel von Warmzeiten und Kaltzeiten gegeben habe, der keineswegs abgeschlossen sei. Zeitweise habe das Gebiet von Europa nahe dem Äquator gelegen. Der Einsatz von Gift gegen die Heuschrecken ist sehr riskant. Denn dabei darf nur ein Mittel verwendet werden, das ausschließlich für die Heuschrecken tödlich ist, nicht aber für Bienen und andere Insekten. Auch das Vieh der Bauern darf nicht durch verseuchtes Futter gefährdet werden.",
          "answer": "c",
          "explanation": "Angesichts kahl gefressener Felder in Südfrankreich wird der riskante Einsatz von Gift gegen die Heuschreckenplage diskutiert ('Bauern sind gezwungen, Gift gegen schädliche Insekten einzusetzen')."
        }
      ]
    },
    {
      "id": "11",
      "title": "Test 11 – Sport, Freizeit & Schule",
      "isVariant": false,
      "headings": {
        "a": "Freie Plätze im Tanzkurs",
        "b": "Neue Lerntechniken präsentiert",
        "c": "Stolze Eltern: vom Schüler zum Superstar",
        "d": "Verändertes Freizeitverhalten von Jugendlichen",
        "e": "Höher, schneller, weiter: Suche nach dem Nervenkitzel",
        "f": "Hilfen für überforderte Schüler",
        "g": "Keine Zeit für Langeweile",
        "h": "Neue Sportarten",
        "i": "Tanzlehrer fordern: moderne Tänze bekannter machen",
        "j": "Befragung bestätigt alte Vorurteile"
      },
      "items": [
        {
          "num": 1,
          "text": "Der Begriff Extremsport wird oft subjektiv verwendet. Man kann viele gängige Sportarten als Extremsport bezeichnen, wenn sie mit erhöhtem Risiko für das eigene Leben ausgeübt werden, z. B. Skilaufen auf ungesicherten Pisten oder Klettern ohne Sicherung. Extremsportlern geht es aber nicht darum, das höchste Risiko einzugehen, sondern ihre Grenzen zu erkennen. Extremsport kann man an vielen Orten betreiben: in der Wüste, unter Wasser, auf Klippen oder Bergen, in der Luft oder sogar auf seinem eigenen Hausdach. Es gibt viele Wettbewerbe in verschiedenen extremen Sportarten, zum Beispiel Bungee-Jumping, was früher ursprünglich ein Ritual für junge Männer in der Südsee war. Eine andere Art des Extremsports ist Freeclimbing: Man klettert ohne jegliche Sicherung an mehreren hundert Meter hohen Felswänden. Kein Berg ist zu hoch, keine Wand ist zu steil, keine Schlucht zu tief, um für den Adrenalinkick zu sorgen. Manchen Sportlern kann es nicht aufregend genug sein. Leider entwickeln nicht wenige Extremsportler dabei eine regelrechte „Sportsucht“, die krankhaft ist. Viele Extremsportler ignorieren die Gefahren, was zu schweren Unfällen führt und sie häufig genug das Leben kostet.",
          "answer": "e",
          "explanation": "Beim Extremsport wie Bungee-Jumping oder Freeclimbing suchen Sportler ihre Grenzen und den extremen Adrenalinkick ('Höher, schneller, weiter: Suche nach dem Nervenkitzel')."
        },
        {
          "num": 2,
          "text": "Musik, Sport, ehrenamtliches Engagement – die Teilnahme von Jugendlichen an diesen sogenannten bildungsorientierten Freizeitaktivitäten hat in den vergangenen zehn Jahren deutlich zugenommen. So lautet das Ergebnis einer Studie des Deutschen Instituts für Wirtschaftsforschung. Während vor 10 Jahren erst 48 Prozent aller 16- bis 17-Jährigen an bildungsorientierten Aktivitäten teilnahmen, waren es im vergangenen Jahr bereits 62 Prozent. Die Daten zeigen außerdem: Während vor 10 Jahren nur etwa 10 Prozent der 16- bis 17-Jährigen musizierten, waren es im letzten Jahr bereits 18 Prozent. Noch stärker hat im gleichen Zeitraum das ehrenamtliche Engagement der 16- bis 17-Jährigen zugenommen (von 11 auf 22 Prozent). Darüber hinaus ist auch der Anteil der Jugendlichen, die Sport treiben, tanzen oder Theater spielen, gestiegen. Gleichzeitig verzeichnen die Forscher einen Abwärtstrend der sogenannten informellen Freizeitbeschäftigungen. So ist der Anteil derer, die täglich mit der besten Freundin oder dem besten Freund unterwegs sind, im Untersuchungszeitraum von 40 auf 25 Prozent zurückgegangen. Auffallend ist, dass Jugendliche aus sozial schwächeren Haushalten bildungsorientierte Angebote viel seltener nutzen als junge Menschen aus gut situierten Familien.",
          "answer": "d",
          "explanation": "Eine Studie belegt, dass Jugendliche heute deutlich häufiger bildungsorientierte Freizeitaktivitäten (Musik, Sport, Ehrenamt) nutzen als noch vor zehn Jahren ('Verändertes Freizeitverhalten von Jugendlichen')."
        },
        {
          "num": 3,
          "text": "In Firmen gibt es sie schon, jetzt wollen auch Schulen Entspannungskurse anbieten. Schüler sollen zwischen den Unterrichtsstunden mit Entspannungstechniken lernen, Stress abzubauen. Ein erster Probelauf des Projekts an einer Gesamtschule in Hamburg ist bei den Teilnehmenden gut angekommen. Die Schüler waren zu Beginn zwar skeptisch, dann aber vom Ergebnis überzeugt. „Ich konnte mich in meiner nächsten Stunde nach der Entspannungsübung viel besser konzentrieren und habe viel mehr mitbekommen“, berichtet Jens aus der 12. Klasse. Die Schule hat damit auf Kritik von Schülern und Lehrern reagiert: Nach der Umstrukturierung der Stundenpläne klagten die Schüler zunehmend über Stress und zu wenige Pausen. Gerade Entspannungspausen seien aber wichtig, erklären Pädagogen und auch Neurowissenschaftler. Nur wer ausreichend Pausen macht, kann sich Dinge auch langfristig merken. Nachdem das Projekt in Hamburg solch einen Erfolg hatte, wollen es jetzt auch andere Schulen anbieten.",
          "answer": "f",
          "explanation": "Schulen bieten Entspannungskurse an, um gestressten Schülern beim Stressabbau und der Konzentration zu helfen ('Hilfen für überforderte Schüler')."
        },
        {
          "num": 4,
          "text": "Tanja Kleist ist von modernem Tanz absolut begeistert. Seit ihrem neunten Lebensjahr tanzt sie, früher auf Wettkampfniveau. Seit einigen Jahren engagiert sie sich beim TSV Neustadt. Die Freude, die sie beim Tanzen hat, möchte sie weitergeben und mehr Jugendliche motivieren, diesem einzigartigen Sport eine Chance zu geben. Und diese Chance ist nun für alle Interessierten besonders groß. Für ihre Hip-Hop-Tanzgruppe sucht Frau Kleist neue tanzbegeisterte Teilnehmerinnen und Teilnehmer, da im vergangenen Sommer viele nach dem Abitur die Gruppe verlassen haben. Das abwechslungsreiche Training vereint Kreatives mit „Handwerklichem“. Im Mittelpunkt der Übungsstunden steht die Erarbeitung kleiner choreografierter Sequenzen auf Basis von Musikvideos bekannter Hip-Hopper, aber auch das Techniktraining und die Schulung von akrobatischen Grundelementen kommen nicht zu kurz. Es entstehen Choreografien, die die Gruppe bei öffentlichen Auftritten vorführt. Ein tolles Tanzangebot mit viel Spaß, das es ab sofort beim TSV Neustadt für Jugendliche ab 14 Jahren gibt!",
          "answer": "a",
          "explanation": "Tanja Kleist sucht für ihre Hip-Hop-Tanzgruppe beim TSV Neustadt neue Teilnehmerinnen und Teilnehmer ab 14 Jahren ('Freie Plätze im Tanzkurs')."
        },
        {
          "num": 5,
          "text": "Montags Tennis, dienstags Klavierunterricht, mittwochs Jazztanz in der Gruppe und donnerstags Treffen der Astronomie-Gruppe. Was klingt wie der Terminkalender eines vielbeschäftigten Erwachsenen, ist heute oft eine ganz normale Woche im Leben von Kindern und Jugendlichen. Nicht genug damit, dass sie sechs oder sieben Stunden Schule haben, dann vielleicht noch Hausaufgaben machen und natürlich auch etwas essen müssen – in ihrer Freizeit haben sie dann gleich weitere Termine. Dabei suchen sich das viele Kinder und Jugendliche gar nicht selbst aus, sondern die Eltern wollen, dass ihr Nachwuchs möglichst viel unternimmt. Einige hoffen, aus ihrem Sohn könnte ein neuer Spitzensportler werden, andere denken an eine Karriere als Musikerin, meist aber glauben die Eltern „nur“, sie müssten ihre Kinder ständig beschäftigen. Sonst könnte es ihnen ja langweilig werden, und wer weiß, was sie dann machen. Viele Eltern haben Angst, dass ihre Kinder dann „auf dumme Gedanken“ kommen oder dass sie zuhause nur vor dem Fernseher oder Computer sitzen, wenn sie nicht ständig etwas unternehmen. Ob der Freizeitstress für alle Beteiligten wirklich gut ist?",
          "answer": "g",
          "explanation": "Der Terminkalender vieler Kinder ist durch die Eltern jeden Tag komplett mit Kursen und Hobbys durchgeplant ('Keine Zeit für Langeweile')."
        }
      ]
    },
    {
      "id": "11a",
      "title": "Test 11a – Sport, Freizeit & Schule (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Befragung bestätigt alte Vorurteile",
        "b": "Freie Plätze im Tanzkurs",
        "c": "Hilfen für überforderte Schüler",
        "d": "Höher, schneller, weiter: Suche nach dem Nervenkitzel",
        "e": "Keine Zeit für Langeweile",
        "f": "Neue Lerntechniken präsentiert",
        "g": "Neue Sportarten",
        "h": "Stolze Eltern: vom Schüler zum Superstar",
        "i": "Tanzlehrer fordern: moderne Tänze bekannter machen",
        "j": "Wandel im Freizeitverhalten von Jugendlichen"
      },
      "items": [
        {
          "num": 1,
          "text": "Der Begriff Extremsport wird oft subjektiv verwendet. Man kann viele gängige Sportarten als Extremsport bezeichnen, wenn sie mit erhöhtem Risiko für das eigene Leben ausgeübt werden, z. B. Skilaufen auf ungesicherten Pisten oder Klettern ohne Sicherung. Extremsportlern geht es aber nicht darum, das höchste Risiko einzugehen, sondern ihre Grenzen zu erkennen. Extremsport kann man an vielen Orten betreiben: in der Wüste, unter Wasser, auf Klippen oder Bergen, in der Luft oder sogar auf seinem eigenen Hausdach. Es gibt viele Wettbewerbe in verschiedenen extremen Sportarten, zum Beispiel Bungee-Jumping, was früher ursprünglich ein Ritual für junge Männer in der Südsee war. Eine andere Art des Extremsports ist Freeclimbing: Man klettert ohne jegliche Sicherung an mehreren hundert Meter hohen Felswänden. Kein Berg ist zu hoch, keine Wand ist zu steil, keine Schlucht zu tief, um für den Adrenalinkick zu sorgen. Manchen Sportlern kann es nicht aufregend genug sein. Leider entwickeln nicht wenige Extremsportler dabei eine regelrechte „Sportsucht“, die krankhaft ist. Viele Extremsportler ignorieren die Gefahren, was zu schweren Unfällen führt und sie häufig genug das Leben kostet.",
          "answer": "d",
          "explanation": "Beim Extremsport wie Bungee-Jumping oder Freeclimbing suchen Sportler ihre Grenzen und den extremen Adrenalinkick ('Höher, schneller, weiter: Suche nach dem Nervenkitzel')."
        },
        {
          "num": 2,
          "text": "Musik, Sport, ehrenamtliches Engagement – die Teilnahme von Jugendlichen an diesen sogenannten bildungsorientierten Freizeitaktivitäten hat in den vergangenen zehn Jahren deutlich zugenommen. So lautet das Ergebnis einer Studie des Deutschen Instituts für Wirtschaftsforschung. Während vor 10 Jahren erst 48 Prozent aller 16- bis 17-Jährigen an bildungsorientierten Aktivitäten teilnahmen, waren es im vergangenen Jahr bereits 62 Prozent. Die Daten zeigen außerdem: Während vor 10 Jahren nur etwa 10 Prozent der 16- bis 17-Jährigen musizierten, waren es im letzten Jahr bereits 18 Prozent. Noch stärker hat im gleichen Zeitraum das ehrenamtliche Engagement der 16- bis 17-Jährigen zugenommen (von 11 auf 22 Prozent). Darüber hinaus ist auch der Anteil der Jugendlichen, die Sport treiben, tanzen oder Theater spielen, gestiegen. Gleichzeitig verzeichnen die Forscher einen Abwärtstrend der sogenannten informellen Freizeitbeschäftigungen. So ist der Anteil derer, die täglich mit der besten Freundin oder dem besten Freund unterwegs sind, im Untersuchungszeitraum von 40 auf 25 Prozent zurückgegangen. Auffallend ist, dass Jugendliche aus sozial schwächeren Haushalten bildungsorientierte Angebote viel seltener nutzen als junge Menschen aus gut situierten Familien.",
          "answer": "j",
          "explanation": "Eine Studie belegt, dass Jugendliche heute deutlich häufiger bildungsorientierte Freizeitaktivitäten (Musik, Sport, Ehrenamt) nutzen als noch vor zehn Jahren ('Wandel im Freizeitverhalten von Jugendlichen')."
        },
        {
          "num": 3,
          "text": "In Firmen gibt es sie schon, jetzt wollen auch Schulen Entspannungskurse anbieten. Schüler sollen zwischen den Unterrichtsstunden mit Entspannungstechniken lernen, Stress abzubauen. Ein erster Probelauf des Projekts an einer Gesamtschule in Hamburg ist bei den Teilnehmenden gut angekommen. Die Schüler waren zu Beginn zwar skeptisch, dann aber vom Ergebnis überzeugt. „Ich konnte mich in meiner nächsten Stunde nach der Entspannungsübung viel besser konzentrieren und habe viel mehr mitbekommen“, berichtet Jens aus der 12. Klasse. Die Schule hat damit auf Kritik von Schülern und Lehrern reagiert: Nach der Umstrukturierung der Stundenpläne klagten die Schüler zunehmend über Stress und zu wenige Pausen. Gerade Entspannungspausen seien aber wichtig, erklären Pädagogen und auch Neurowissenschaftler. Nur wer ausreichend Pausen macht, kann sich Dinge auch langfristig merken. Nachdem das Projekt in Hamburg solch einen Erfolg hatte, wollen es jetzt auch andere Schulen anbieten.",
          "answer": "c",
          "explanation": "Schulen bieten Entspannungskurse an, um gestressten Schülern beim Stressabbau und der Konzentration zu helfen ('Hilfen für überforderte Schüler')."
        },
        {
          "num": 4,
          "text": "Tanja Kleist ist von modernem Tanz absolut begeistert. Seit ihrem neunten Lebensjahr tanzt sie, früher auf Wettkampfniveau. Seit einigen Jahren engagiert sie sich beim TSV Neustadt. Die Freude, die sie beim Tanzen hat, möchte sie weitergeben und mehr Jugendliche motivieren, diesem einzigartigen Sport eine Chance zu geben. Und diese Chance ist nun für alle Interessierten besonders groß. Für ihre Hip-Hop-Tanzgruppe sucht Frau Kleist neue tanzbegeisterte Teilnehmerinnen und Teilnehmer, da im vergangenen Sommer viele nach dem Abitur die Gruppe verlassen haben. Das abwechslungsreiche Training vereint Kreatives mit „Handwerklichem“. Im Mittelpunkt der Übungsstunden steht die Erarbeitung kleiner choreografierter Sequenzen auf Basis von Musikvideos bekannter Hip-Hopper, aber auch das Techniktraining und die Schulung von akrobatischen Grundelementen kommen nicht zu kurz. Es entstehen Choreografien, die die Gruppe bei öffentlichen Auftritten vorführt. Ein tolles Tanzangebot mit viel Spaß, das es ab sofort beim TSV Neustadt für Jugendliche ab 14 Jahren gibt!",
          "answer": "b",
          "explanation": "Tanja Kleist sucht für ihre Hip-Hop-Tanzgruppe beim TSV Neustadt neue Teilnehmerinnen und Teilnehmer ab 14 Jahren ('Freie Plätze im Tanzkurs')."
        },
        {
          "num": 5,
          "text": "Montags Tennis, dienstags Klavierunterricht, mittwochs Jazztanz in der Gruppe und donnerstags Treffen der Astronomie-Gruppe. Was klingt wie der Terminkalender eines vielbeschäftigten Erwachsenen, ist heute oft eine ganz normale Woche im Leben von Kindern und Jugendlichen. Nicht genug damit, dass sie sechs oder sieben Stunden Schule haben, dann vielleicht noch Hausaufgaben machen und natürlich auch etwas essen müssen – in ihrer Freizeit haben sie dann gleich weitere Termine. Dabei suchen sich das viele Kinder und Jugendliche gar nicht selbst aus, sondern die Eltern wollen, dass ihr Nachwuchs möglichst viel unternimmt. Einige hoffen, aus ihrem Sohn könnte ein neuer Spitzensportler werden, andere denken an eine Karriere als Musikerin, meist aber glauben die Eltern „nur“, sie müssten ihre Kinder ständig beschäftigen. Sonst könnte es ihnen ja langweilig werden, und wer weiß, was sie dann machen. Viele Eltern haben Angst, dass ihre Kinder dann „auf dumme Gedanken“ kommen oder dass sie zuhause nur vor dem Fernseher oder Computer sitzen, wenn sie nicht ständig etwas unternehmen. Ob der Freizeitstress für alle Beteiligten wirklich gut ist?",
          "answer": "e",
          "explanation": "Der Terminkalender vieler Kinder ist durch die Eltern jeden Tag komplett mit Kursen und Hobbys durchgeplant ('Keine Zeit für Langeweile')."
        }
      ]
    },
    {
      "id": "12",
      "title": "Test 12 – Rund um die Nase & den Geruchssinn",
      "isVariant": false,
      "headings": {
        "a": "Doping für Drogenspürhunde",
        "b": "Durch den Geruchssinn die Welt neu erfahren",
        "c": "Elefanten mit dem feinsten Näschen",
        "d": "Erst schmecken, dann riechen",
        "e": "Mit vierbeinigen Spürnasen gegen den Drogenschmuggel",
        "f": "Nasenkorrektur für jedermann",
        "g": "Neue Therapie für Allergikernasen",
        "h": "Schönheitsoperationen nicht um jeden Preis",
        "i": "Selbstreinigung für unser Riechorgan",
        "j": "Tierische Riechorgane – unterschiedlich ausgeprägt"
      },
      "items": [
        {
          "num": 1,
          "text": "Wie wollen wir von anderen gesehen werden? Von unserer Schokoladenseite natürlich. Aber es gibt Menschen, die haben keine. Eine Frau mit schiefer Nase mag sich weder im Profil noch frontal zeigen. „Die Nase“, so der plastische Chirurg Professor Henrik Menke, „sitzt mitten im Gesicht – so banal das klingt. Zu große Abweichungen von der Norm beeinträchtigen den ganzen Menschen.“ Der Chirurg, der an der Wiesbadener Wilhelm-Fresenius-Klinik eine Abteilung für ästhetische Chirurgie leitet, lehnt es ab, am Mängelwesen Mensch alles chirurgisch Machbare auszuführen. Keinem unter 18 würde er die Nase operieren – es sei denn, sie ist durch einen Unfall oder eine Krankheit verunstaltet. Menke: „Wenn ich die Probleme nachvollziehen kann, die junge Leute mit ihrer Nase haben, werde ich in allen Details mit den Patienten besprechen, was getan werden kann, lehne es aber ab, mit Videoanimation zu arbeiten. Damit kann ich zwar alles machen, jedes gewünschte Resultat herbeizaubern. Die Realität ist aber eine andere. Aus diesem Grund hat es der Gesetzgeber zu Recht untersagt, mit Vorher-nachher-Bildern zu arbeiten.“",
          "answer": "h",
          "explanation": "Der plastische Chirurg Prof. Menke lehnt es ab, alles chirurgisch Machbare durchzuführen, operiert keine Minderjährigen ohne medizinischen Grund und verzichtet auf Videoanimationen ('Schönheitsoperationen nicht um jeden Preis')."
        },
        {
          "num": 2,
          "text": "Der Riechsinn ist unser ursprünglichster Sinn – sagt Matthias Schenk vom Schloss Freudenberg. Wer ihn schärfen will, ist im dort untergebrachten „Erfahrungsfeld der Sinne“ an der richtigen Adresse: „Es entsteht eine neue Welt, sogar ein ganz neuer Kosmos, wenn man sich mit der Nase beschäftigt“, weiß Matthias Schenk. Sein „Erfahrungsfeld der Sinne“ wird täglich von rund 400 Gästen besucht. An 140 Stationen im Gemäuer und im parkähnlichen Außenbereich lässt es sich bewusst fühlen, hören, sehen, riechen und schmecken. Sieben Stationen befassen sich mit dem Riechvermögen. Ob klein oder groß, dick oder schmal – auch wenn manch einer die Form seiner Nase schon mal verflucht hat, ohne sie können wir nicht sein. Der Nase kommt im „Erfahrungsfeld der Sinne“ eine zentrale Rolle zu. Schließlich, so Schenk, sei der Geruchssinn gehirngeschichtlich der älteste Sinn. „Er ist ein Ur-Sinn, der uns mit allen Tieren verbindet.“ Gestützt wird diese Aussage dadurch, dass beispielsweise Säuglinge ihre Mutter riechen, bevor sie sie sehen und hören.",
          "answer": "b",
          "explanation": "Im „Erfahrungsfeld der Sinne“ auf Schloss Freudenberg kann man seinen Geruchssinn schärfen, wodurch „eine neue Welt, sogar ein ganz neuer Kosmos“ entsteht ('Durch den Geruchssinn die Welt neu erfahren')."
        },
        {
          "num": 3,
          "text": "Mit Drogen kennt sich Falko aus. Der sechs Jahre alte Schäferhund sucht für den Zoll nach Kokain, Haschisch und Heroin. Bis zu vier Kofferladungen, meist aus Südamerika, Afrika und Südostasien, beschnüffelt der Vierbeiner am Tag. Rund 300-mal in der Minute atmet er dabei ein und aus – ein wahrer Nasenmarathon. Hunde riechen bis zu eine Million Mal besser als Menschen. Hat der Mensch fünf Millionen Riechzellen, so sind es bei einem Schäferhund 200 Millionen. Grundsätzlich gilt: Je länger die Hundeschnauze, desto besser das Geruchsvermögen. Schnüffler wie Falko können „stereo“ riechen, das heißt, ihre Nase kann zwischen rechts und links unterscheiden. Spürhunde erkennen deshalb auch die Richtung eines Geruchs. Doch die beste Hundenase nutzt nichts, wenn sie nicht geschult wird. So lernen Drogenspürhunde in jungen Jahren, wie sie sogenannte weiche und harte Drogen finden. Werden bei der Ausbildung noch alle Drogen zusammengepackt, so schafft es Falko, sie beim Kofferschnüffeln dann einzeln wahrzunehmen. Bis zu zehn Jahre können Spürhunde des Zolls arbeiten, ehe sie samt ihrer Nase in den verdienten Hunde-Ruhestand gehen dürfen.",
          "answer": "e",
          "explanation": "Der Text beschreibt die Ausbildung und Arbeit von Drogenspürhunden wie Schäferhund Falko beim Zoll ('Mit vierbeinigen Spürnasen gegen den Drogenschmuggel')."
        },
        {
          "num": 4,
          "text": "Beim Menschen ist das Sehen der Sinn Nummer eins, gefolgt vom Hören und an dritter Stelle dem Riechen. Ganz anders sieht es bei vielen Tieren aus, zum Beispiel bei Hunden. „Ein Hund, der nicht sehen kann, ist wie ein Mensch ohne Geruch – das ist nicht schön, aber auch nicht dramatisch“, sagt Ralf Spangenberg, Tierarzt aus Ingelheim. Zum Vergleich: Während die Riechschleimhaut des Menschen rund fünf Quadratzentimeter misst, bringt es der Hund auf 85 Quadratzentimeter und mehr. „Hunde sind Riechweltmeister“, bringt es der Tierarzt auf den Punkt. Nicht die beste, dafür die längste Nase der Welt hat der Elefant. „Das Riechen ist allerdings Nebensache, beim Elefanten ist die Nase zum Werkzeug geworden.“ Er kann damit Baumstämme umschlingen und schleppen, die Nase kann als Rüsseldusche genutzt werden und natürlich als Esswerkzeug. Interessant sind auch die Nasen der Spinnen. Deren Riechorgane stecken in den Beinen. „Da sind sie ganz nah an den Dingen dran“, erklärt Spangenberg. Wiederum anders verhält es sich bei Schlangen: „Sie nehmen über die Zunge Gerüche auf.“ Und damit nicht genug: Weil die Zunge gespalten ist, können sie auch rechts und links unterscheiden und genau die Richtung bestimmen, in der sie ihre Beute finden. Auch die scheinbar nasenlosen Fische können riechen. „Haie zum Beispiel riechen und schmecken Blut über Kilometer“, so Spangenberg.",
          "answer": "j",
          "explanation": "Der Text vergleicht die völlig unterschiedlichen Riechorgane von Hunden, Elefanten, Spinnen, Schlangen und Fischen ('Tierische Riechorgane – unterschiedlich ausgeprägt')."
        },
        {
          "num": 5,
          "text": "Niesen ist eine Reaktion auf die Umwelt. Mal kitzelt Staub die Nase, mal reizt ein chemischer Stoff oder ein anderer Fremdkörper in der Luft unser Riechorgan. Sogar grelles Licht kann durch die Verbindung der Gesichtsnerven zum Niesen führen. Unwillkürlich wird ein Reflex ausgelöst, der die Nase „säubern“ soll. Es kommt zu einem explosionsartigen Ausstoßen der Luft durch die Nase – dem Niesen. Allergiker niesen oft serienweise, bis der letzte Reiz aus der Nase entfernt ist. Auf die Reizmeldung hin holt der Körper tief Luft – bis die Lungen maximal gefüllt sind. Dann wird der Atem kurz angehalten. Und schließlich stößt der Körper in Sekundenschnelle die eingeatmete Luft wieder aus. Dabei kann diese leicht eine Geschwindigkeit von 150 bis 160 Stundenkilometern erreichen. Lautlos geht das Niesen selten vonstatten. Das „Ha“ – oft gleich mehrfach vor dem befreienden „Tschi“ hervorgestoßen – entsteht, weil beim Einatmen die Stimmbänder aufgemacht werden. Beim „Tschi“ wird die Luft dann wieder ausgestoßen. Der Laut entsteht, weil gleichzeitig die Zunge hinter die Vorderzähne gepresst wird. Denn der Körper will, dass möglichst viel Luft durch die Nase und möglichst wenig durch den Mund entweicht, daher verschließt die Zunge der Luft teilweise den Weg.",
          "answer": "i",
          "explanation": "Niesen ist ein unwillkürlicher Reflex des Körpers, um die Nase von Staub und Fremdkörpern zu säubern ('Selbstreinigung für unser Riechorgan')."
        }
      ]
    },
    {
      "id": "13",
      "title": "Test 13 – Schulanfang & Schulweg",
      "isVariant": false,
      "headings": {
        "a": "Das neue Schülerticket – rund ums Jahr mit Bus und Bahn fahren",
        "b": "Das richtige Alter für die Einschulung",
        "c": "Mit Schulanfängern richtiges Verhalten im Verkehr üben",
        "d": "Neue Methode: So lernen Kinder leichter lesen und schreiben",
        "e": "Neues Buch für kleine Leseanfänger",
        "f": "Traditionen zum Schulanfang",
        "g": "Vorsicht an Haltestellen!",
        "h": "Weniger Fahrten in den Schulferien",
        "i": "Woher stammt der Brauch mit der Schultüte?",
        "j": "Wörterbuch mit CD – Neuerscheinung"
      },
      "items": [
        {
          "num": 1,
          "text": "Nach der englischen Bezeichnung für „Schultüte“ sucht man vergebens. Die mit Süßigkeiten und kleinen Geschenken gefüllte Spitztüte aus Karton, die Kinder in Deutschland am ersten Schultag von ihren Eltern bekommen, ist offenbar etwas typisch Deutsches. In Großbritannien besucht die Klassenlehrerin oder der Klassenlehrer die Familie zu Hause, bevor das Kind in die Schule kommt. So können sich Lehrer, Schüler und Eltern schon vor dem Schuleintritt kennenlernen. In den USA bekommen die Kinder vor dem ersten Schultag kleine Geschenke; Dinge, die sie in der Schule gebrauchen können. In Russland wird zum Schulanfang zu Hause ein großes Familienfest gefeiert. Den Lehrerinnen und Lehrern überreichen die Schulanfänger Blumen. Gefeiert wird die Einschulung auch in Japan, allerdings nicht zuhause, sondern in der Schule. Dort gibt es Ansprachen und Aufführungen von älteren Schülerinnen und Schülern. In Indien wird am ersten Schultag ein besonderer Joghurt gegessen. Er soll den Schulanfängern Glück bringen. Am wenigsten Aufheben macht man in Frankreich von der Einschulung: Dort gibt es keine besonderen Bräuche.",
          "answer": "f",
          "explanation": "Der Text vergleicht verschiedene Bräuche zur Einschulung in Deutschland, Großbritannien, den USA, Russland, Japan, Indien und Frankreich ('Traditionen zum Schulanfang')."
        },
        {
          "num": 2,
          "text": "Raban Rabovic ist ein kleiner Rabe. Seit Wochen denkt er nur noch an eines: den Schulanfang! Nun ist es endlich so weit: Für ihn und neun andere Rabenkinder beginnt die Schule. Wie es Raban dabei ergeht, erzählt Antonija Tomic in „Schulanfang in der Rabenschule“. So heißt ihr Erstlesebuch, das gerade erschienen ist. Antonija Tomic hat als Lektorin in einem Kinderbuchverlag gearbeitet, bevor sie selbst begonnen hat, Erzählungen zu schreiben. Inzwischen hat sie sich vor allem als Bilderbuchautorin für Kinder einen Namen gemacht. Von ihr stammen dabei nicht nur die Geschichten, sondern auch die meist farbigen Illustrationen. Auch die ersten Schultage von Raban begleiten liebevoll gezeichnete Bilder. Dazu gibt es eine CD mit Liedern, die kleine Rabenkinder gerne singen. In einem Begleitheft finden sich zudem Arbeitsblätter mit Mal- und Schreibübungen. Für alle ABC-Schützen, die gerade lesen und schreiben lernen, ein ideales Geschenk für den ersten Schultag!",
          "answer": "e",
          "explanation": "Vorgestellt wird das neu erschienene Erstlesebuch „Schulanfang in der Rabenschule“ von Antonija Tomic ('Neues Buch für kleine Leseanfänger')."
        },
        {
          "num": 3,
          "text": "Auf den Straßen sind ab Schulbeginn wieder viele Kinder unterwegs. Autofahrer sind deshalb zu erhöhter Aufmerksamkeit aufgefordert, besonders beim Überholen an Haltestellen der öffentlichen Verkehrsmittel. In der Straßenverkehrsordnung ist das Überholen von Bussen und Straßenbahnen genau geregelt: An Omnibussen des Linienverkehrs, an Straßenbahnen und an gekennzeichneten Schulbussen, die an Haltestellen stehen bleiben, darf man nur vorsichtig vorbeifahren. Wenn Fahrgäste ein- oder aussteigen, dürfen Autofahrer rechts nur mit Schrittgeschwindigkeit vorbeifahren. Sie müssen auch genügend Abstand wahren, um die Fahrgäste nicht zu gefährden. Wenn nötig, müssen die Autofahrer warten. Omnibusse des Linienverkehrs und gekennzeichnete Schulbusse, die sich einer Haltestelle nähern und das Warnblinklicht eingeschaltet haben, darf man gar nicht überholen. Auf jeden Fall sollten Autofahrer damit rechnen, dass sich Kinder dort vielleicht nicht so verhalten, wie sie es eigentlich sollten, zum Beispiel beim Überqueren der Fahrbahn. Dann ist es Aufgabe der Autofahrer, für die Sicherheit der Kinder zu sorgen.",
          "answer": "g",
          "explanation": "Autofahrer werden zu besonderer Vorsicht beim Vorbeifahren an haltenden Linien- und Schulbussen sowie Straßenbahnen ermahnt ('Vorsicht an Haltestellen!')."
        },
        {
          "num": 4,
          "text": "In Deutschland herrscht für alle Kinder Schulpflicht: Ab einem gewissen Alter muss jedes Kind die Schule besuchen. An ihrem ersten Schultag können sie fünf, sechs oder sieben Jahre alt sein. Der genaue Zeitpunkt des Schuleintritts wurde Ende der 1990er Jahre bewusst flexibler gestaltet. Denn das optimale Alter für den Schuleintritt ist umstritten. Zum einen setzen die einzelnen Bundesländer unterschiedliche Stichtage und Mindestalter fest. Zum anderen gibt es höchst unterschiedliche Ansichten über den Zeitpunkt, zu dem ein Kind reif sein soll für die Schule. Die einen argumentieren, dass auch Fünfjährige schon lesen und schreiben lernen können. Die anderen warnen vor Überforderung und Leistungsdruck. Entscheidend ist aber nicht das Alter, sondern die Entwicklung eines Kindes: Wenn sich ein fünfjähriges Kind im Kindergarten langweilt und sich auf die Schule freut, ist es vermutlich bereit für den Schulanfang. Ein sechsjähriges Kind aber, das kaum stillsitzen kann, ist im Kindergarten noch gut aufgehoben.",
          "answer": "b",
          "explanation": "Diskutiert wird, wann Kinder mit fünf, sechs oder sieben Jahren reif für den Schuleintritt sind ('Das richtige Alter für die Einschulung')."
        },
        {
          "num": 5,
          "text": "Ein Großteil des Busverkehrs in der Region dient vor allem dem Schulverkehr. Fast die Hälfte der in unserem Gebiet eingesetzten Busse fährt ausschließlich an Schultagen. Daher sind viele Fahrten in den Fahrplänen mit einem „S“ gekennzeichnet. Diese Fußnote steht für „nur an Schultagen“. Zudem gibt es auch Fahrten, die „nur in den Ferien“ stattfinden; diese sind mit einem „F“ gekennzeichnet. Die mit einem „S“ gekennzeichneten Fahrten stehen natürlich jedem Fahrgast zur Verfügung und sind nicht ausschließlich für die Beförderung von Schülerinnen und Schülern zugelassen. Allerdings muss man bei diesen Fahrten mit gewissen Einschränkungen rechnen: Sie gelten nicht an Ferientagen. Hierbei ist zudem zu berücksichtigen, dass auch die Ferien in den angrenzenden Bundesländern ausschlaggebend sein können. Bitte achten Sie auf jeden Fall auf die Anmerkungen in den jeweiligen Fußnoten. Bei Regionalzügen und Straßenbahnen gibt es ebenfalls bestimmte Fahrten, die sich an Schul- und Ferientagen unterscheiden. Bitte beachten Sie auch hier die Angaben in den Fahrplänen.",
          "answer": "h",
          "explanation": "Da fast die Hälfte der Busse nur an Schultagen („S“) fährt, ist das Fahrtenangebot während der Ferien eingeschränkt ('Weniger Fahrten in den Schulferien')."
        }
      ]
    },
    {
      "id": "14",
      "title": "Test 14 – Fitness, Reiten, Schwimmen & Tauchen",
      "isVariant": false,
      "headings": {
        "a": "Auf dem Weg zu internationalen Wettkämpfen",
        "b": "Durch Wassergymnastik Verspannungen lösen",
        "c": "Ein tierischer Lernspaß für alle",
        "d": "Fit und gesund auch nach der Pensionierung",
        "e": "Gefahren beim Tauchen",
        "f": "Mit dem eigenen Pferd zu Olympia",
        "g": "Muskeln wie ein Gewichtheber",
        "h": "Neueröffnetes Internat für junge Sporttaucher",
        "i": "Schlank, fit und glücklich im Flug",
        "j": "Sport treiben wie ein Fisch unter Wasser"
      },
      "items": [
        {
          "num": 1,
          "text": "Wir bieten Bewegungsförderung mit und auf Pferden zur Stärkung der körperlichen und geistigen Fitness. Ponys und Pferde stehen im Mittelpunkt dieses Programms. Sie zu beobachten, füttern, streicheln, putzen, führen oder reiten zu können, übt auf Teenies eine große Faszination aus. Spielerisch werden sie in Kontakt mit unseren Tieren gebracht und haben dann vielfältige Möglichkeiten, unter Anleitung Aufgaben für, mit oder auf den Pferden durchzuführen. Zudem können sie auf dem Gelände der Ranch weitere ungewohnte Bewegungs- und Wahrnehmungserfahrungen sammeln, z. B. auf dem Erlebnis-Parcours. Die Betreuung erfolgt durch einen Reitlehrer und qualifiziertes Personal. Unsere Sattel- und Kleiderkammer verfügt über alle notwendigen Utensilien. Selbstverständlich kann auch eigene Ausrüstung mitgebracht werden.",
          "answer": "c",
          "explanation": "Jugendliche erleben spielerisch Bewegungsförderung und Aufgaben rund um Ponys und Pferde ('Ein tierischer Lernspaß für alle')."
        },
        {
          "num": 2,
          "text": "Die Schwimm- und Sportfreunde 1905 e. V. gehörten in den 70er und 80er Jahren zu den besten Vereinen im deutschen Schwimmsport. Auch noch zu Beginn der 90er Jahre stellte der Verein Schwimmer für die Nationalmannschaft, die bei Weltmeisterschaften oder Olympischen Spielen für Deutschland an den Start gingen. Seit 2010 versuchen die Schwimm- und Sportfreunde, wieder an alte Zeiten anzuknüpfen. Mit idealen Voraussetzungen, nämlich der vereinseigenen 50-Meter-Bahn im Sportpark Nord, dem Stadion, der großen Mehrfachsporthalle über dem Bad, einem sehr gut eingerichteten Kraftraum und einer idealen Betreuung durch zwei ganztags angestellte Trainer, stellten sich in den letzten Jahren wieder Erfolge auf Landes- und Bundesebene ein. Die Sportler können auch das Teilzeitinternat nutzen. Dann wohnen und trainieren sie für eine Zeitlang zusammen, was den Jugendlichen ihren Tagesablauf sowie die Organisation von Schule und Training leichter macht.",
          "answer": "a",
          "explanation": "Der Schwimmverein knüpft mit professionellem Training und ersten Erfolgen auf Landes- und Bundesebene wieder an frühere WM- und Olympia-Zeiten an ('Auf dem Weg zu internationalen Wettkämpfen')."
        },
        {
          "num": 3,
          "text": "In unserem modernen Studio bieten wir Ihnen alle Arten von Gesundheits-, Kraft- und Fitnesstraining an. Wer selbst im Rentenalter noch einen durchtrainierten Körper haben möchte, der sollte schon in jungen Jahren das Ausdauertraining nicht vernachlässigen. Aber auch wer spät mit dem Sport beginnt, fühlt sich nach dem Training einfach besser. Um auch im Alter noch mit allen Problemen des Alltags klarzukommen, ist ein Ausdauertraining wirklich wichtig. Deshalb haben wir für Sie zum Beispiel moderne Trainingsgeräte, die Ihren Herzschlag kontrollieren. Auch bei Rückenschmerzen hilft das Fitnessstudio. Wer kennt sie nicht, die Rückenschmerzen. Acht von zehn Deutschen haben sie, aber sie werden beim Arzt selten richtig behandelt. Die Gründe für die Rückenprobleme liegen nämlich darin, dass die Muskeln nicht ausreichend trainiert sind. Wenn Sie bei uns trainieren, werden Sie bald merken, dass die Schmerzen nachlassen und schließlich verschwinden. Sind Sie neugierig geworden? Dann vereinbaren Sie doch ein Probetraining bei uns!",
          "answer": "d",
          "explanation": "Das Fitnessstudio wirbt für Ausdauer- und Muskeltraining, um bis ins Rentenalter fit und schmerzfrei zu bleiben ('Fit und gesund auch nach der Pensionierung')."
        },
        {
          "num": 4,
          "text": "Das Trampolin ist ein einzigartiges Trainingsgerät, das die Möglichkeit bietet, auch bei verschiedenen körperlichen Einschränkungen ein umfassendes Trainingsprogramm zu absolvieren. Die Übungen auf dem Trampolin haben vielfältige positive Effekte auf den Körper und den gesamten Organismus. Neben einer Gewichtsabnahme (der Kalorienverbrauch ist ähnlich hoch wie beim Joggen) und der Straffung des Körpergewebes werden Muskeln gelockert, Verspannungen lösen sich und der komplette Bewegungsapparat wird nicht so hart belastet wie bei herkömmlichen Sportarten. Ein weiterer wichtiger Effekt für den Körper ist die Unterstützung des Lymphflusses. Aber auch Geist und Seele werden positiv beeinflusst. Es bietet sich also an, auf hochwertigen Therapiegeräten unter fachkompetenter Anleitung Luftsprünge zu machen.",
          "answer": "i",
          "explanation": "Trampolinspringen („Luftsprünge“) hilft beim Abnehmen, hält den Körper schonend fit und wirkt positiv auf Geist und Seele ('Schlank, fit und glücklich im Flug')."
        },
        {
          "num": 5,
          "text": "Sporttauchen ist eine fantastische Natursportart. In den Vereinen und Tauchschulen des Verbandes Deutscher Sporttaucher wird das immer wieder faszinierende Sporttauchen mit verschiedenen Schwerpunkten angeboten. Dort wird auch Tauchfitness aufgebaut und regelmäßig trainiert. Sie können sich in allen Bereichen von gut geschulten Trainern ausbilden lassen und die Welt unter Wasser kennenlernen. Im Sporttauchen sollte man sich auf jeden Fall durch regelmäßiges Training „tauchfit“ halten. Eine ausreichende Kondition unter Wasser ist sehr wichtig, denn untrainiert ist man als Sporttaucher ein Risiko für sich und andere. Ziel des Tauchtrainings ist ebenfalls das Lernen der richtigen Technik für das Atmen und das Beherrschen der Techniken für das Abtauchen. Eigentlich braucht man für das Tauchen nicht viel. Für das allgemeine Training reichen eine Tauchermaske, ein Schnorchel, mit dem man auch ohne Geräte Luft bekommt, und Flossen, die wie Schuhe über die Füße gezogen werden. Alle anderen Tauchgeräte kann man in praktisch jedem Verein oder in einer der vielen Tauchschulen im In- und Ausland preiswert ausleihen.",
          "answer": "j",
          "explanation": "Der Text stellt das Sporttauchen und das Tauchtraining mit Maske, Schnorchel und Flossen unter Wasser vor ('Sport treiben wie ein Fisch unter Wasser')."
        }
      ]
    },
    {
      "id": "15",
      "title": "Test 15 – Familie, Partnersuche & Beziehung",
      "isVariant": false,
      "headings": {
        "a": "Keine Zeit für die Kinder",
        "b": "Vorsicht vor zweifelhaften Kontaktagenturen!",
        "c": "Liebe fürs Leben muss wachsen",
        "d": "Mehr Zeit für Hobbys",
        "e": "Partnervermittlungen generell empfehlenswert",
        "f": "Wer sucht, der findet",
        "g": "Probleme bei der Kindererziehung",
        "h": "Partnervermittlung per Telefon",
        "i": "Wenn die Kinder aus dem Haus sind",
        "j": "Zeitprobleme in der Familie"
      },
      "items": [
        {
          "num": 1,
          "text": "Die Krügers sind eine ganz normale Familie. Vater Bernd arbeitet 40 Stunden pro Woche in einer Versicherungsagentur, Mutter Yvonne hat einen Teilzeitjob als Arzthelferin. Das Paar hat zwei Kinder. Tom ist neun, Linda ist vier Jahre alt. Nach ihrer Arbeit holt Yvonne die beiden aus der Schule und dem Kindergarten ab. Dann geht sie einkaufen, sie wäscht, putzt und kocht, sie bringt Tom zum Fußballtraining oder Linda zum Turnen. Wenn Bernd abends nach Hause kommt, kontrolliert er noch Hausaufgaben oder besucht seinen alten Vater, der immer öfter seine Hilfe braucht. Bernd Krüger kann sich nicht erinnern, wann er das letzte Buch gelesen hat. Für Sport bleibt keine Zeit, Freunde treffen seine Frau und er eher selten. Und wenn dann ein langer Tag zu Ende geht und die beiden Kinder endlich schlafen, sitzen Bernd und Yvonne Krüger total müde auf der Couch. In vielen Familien ist es ähnlich. Vor allem Eltern befinden sich in der Gefahr, die Doppellast von Beruf und Familie nicht mehr tragen zu können. Was hilft, ist Zeitmanagement. Der Begriff ist allerdings missverständlich. Die Zeit lässt sich nicht managen. Wir können uns nur selbst managen.",
          "answer": "j",
          "explanation": "Durch die Doppelbelastung von Beruf, Haushalt und Familie bleibt den Eltern im Alltag kaum noch freie Zeit ('Zeitprobleme in der Familie')."
        },
        {
          "num": 2,
          "text": "Der Wunsch nach der Zweisamkeit hat sich zu einem guten Geschäft entwickelt, denn gerade reiferen Alleinstehenden fällt es oft schwer, neue Partnerschaften herzustellen. Vermittlungsagenturen bieten ihre Dienste im Internet oder in den Tageszeitungen an. Neben vielen seriösen Firmen finden sich auf dem Markt aber auch zahlreiche schwarze Schafe. Bei solchen Anbietern beginnen die Tricks bereits bei den Anzeigen in der Zeitung oder im Netz. Dort stellen Personen angeblich sich selbst vor. Ihre Beschreibung ist direkt auf die Wünsche älterer Singles zugeschnitten, oft genug auch schon mit ansprechendem „Originalfoto“. Wer die angegebene Telefonnummer wählt, muss dann plötzlich feststellen, es in Wirklichkeit mit einer Partnervermittlungsagentur zu tun zu haben. Und die gehen dann in der Regel schnell und aggressiv vor. Es wird ein Treffen vereinbart – und wenn man sich wirklich darauf einlassen möchte, heißt es schon hier: Aufgepasst! Wird nämlich ein neutraler Treffpunkt, beispielsweise ein Café, vereinbart, verliert der Kunde sein 14-tägiges Widerrufs- bzw. Rücktrittsrecht, das ihm bei einem Hausbesuch zustehen und ihn von einem vielleicht zu schnell unterschriebenen Vertrag befreien würde.",
          "answer": "b",
          "explanation": "Der Text warnt vor unseriösen Partnervermittlungsagenturen („schwarzen Schafen“), die mit gefälschten Kontaktanzeigen und Treffen im Café das Widerrufsrecht umgehen ('Vorsicht vor zweifelhaften Kontaktagenturen!')."
        },
        {
          "num": 3,
          "text": "Hat man den richtigen Partner gefunden, muss an der Beziehung gearbeitet werden. Was viele nicht wissen: Die Partnerschaft verläuft in Phasen. Fast jede Liebe beginnt mit einer Hochphase der Verliebtheit. Ist diese Phase vorüber, folgt eine Phase des satten Glücks, in der beide den Wunsch haben, mit diesem Menschen ein ganzes Leben zu verbringen. Fast alle Paare erleben danach eine Zeit, in der der Alltag in die Beziehung eintritt. Man ist gezwungen, sich in einem realistischeren Licht zu sehen. In der folgenden Stress- und Streitphase geht es darum, die Bedingungen des Zusammenlebens festzulegen, Lösungen für Partnerschaft und Beruf zu finden. Bleibt ein Paar nach dieser schwierigen Phase zusammen, festigt sich die Partnerschaft in der fünften Phase weiter und wird ruhiger. Die Partner finden zu sich selbst, erlauben sich gegenseitig mehr freie Zeit und eigene Interessen. In der letzten Phase bildet sich, was man die Liebe fürs Leben nennen kann. In der Beziehung haben sich so viel Sicherheit und Vertrauen gebildet, dass die Beziehung eine feste Basis für die Zukunft hat.",
          "answer": "c",
          "explanation": "Eine Partnerschaft durchläuft mehrere Entwicklungsphasen, bis nach dem Überstehen der Alltags- und Streitphase schließlich die beständige Liebe fürs Leben entsteht ('Liebe fürs Leben muss wachsen')."
        },
        {
          "num": 4,
          "text": "Knapp 13 Millionen Single-Haushalte – d. h. Haushalte von Alleinlebenden – gibt es in Deutschland, und das meist unfreiwillig. Fast jeder, der alleine lebt, wünscht sich den richtigen Partner. Doch wie und wo ist er oder sie zu finden? Glückliche Zweisamkeit – davon träumen die meisten Singles. Oftmals stecken Singles in einer schwierigen Situation: Wer lange allein gelebt hat, wünscht sich zwar eine feste Bindung, gleichzeitig wächst aber auch die Angst davor. Dieses Wechselbad aus Wollen und Vorsichtig-Sein macht die Sache immer schwieriger und nicht selten vergehen so die Jahre des Alleinseins. Zwar sollte man die Hoffnung nie aufgeben, den oder die Richtige irgendwann zufällig zu finden. Aber dass die Traumfrau auf einmal an die Tür klopft oder ganz plötzlich der Traumprinz auf einem weißen Schimmel um die Ecke reitet, ist ziemlich unwahrscheinlich. Deswegen lautet der Rat für alle Singles, ob es ihnen gefällt oder nicht: Ausgehen, Ausgehen, Ausgehen.",
          "answer": "f",
          "explanation": "Da der Traumpartner kaum von allein an die Tür klopft, müssen Singles selbst aktiv werden und ausgehen ('Wer sucht, der findet')."
        },
        {
          "num": 5,
          "text": "Nach dem Abitur, zum Studium oder weil der Zeitpunkt einfach gekommen ist: Wenn die Kinder ausziehen, verändert sich viel, auch für die Eltern. Neben der Freude, endlich wieder Zeit und Raum für sich zu haben, entsteht auch eine Leere, die es nun zu füllen gilt. Erika Paxmann hat drei Kinder: Benni, Anna und Alina. Zwei ihrer Kinder sind schon ausgezogen, innerhalb von vier Monaten. Zurück blieben die Eltern und die 14-jährige Alina. Noch während die Kinder zu Hause wohnten, hat Erika Paxmann sich beruflich weitergebildet und sich neue Aufgaben gesucht. Trotzdem war sie traurig, als die Kinder auszogen. Die Selbständigkeit des Kindes bedeutet, dass auch die Eltern wieder ein unabhängiges Leben führen können. Die Ehepartner haben wieder mehr Zeit füreinander. Das kann auch bisher unbewusste Probleme an den Tag bringen. Viele Partner müssen sich erst wieder an ein Leben zu zweit gewöhnen. Hilfreich ist es, sich schon frühzeitig auf ein Leben „ohne“ Kinder einzustellen. Man kann sich z. B. beruflich fortbilden oder anderen eigenen Interessen nachgehen. Die Umstellung, wenn die Kinder ausziehen, ist dann nicht mehr so groß.",
          "answer": "i",
          "explanation": "Der Text beschreibt die Veränderung und Neuorientierung für Eltern, sobald die erwachsenen Kinder ausziehen ('Wenn die Kinder aus dem Haus sind')."
        }
      ]
    },
    {
      "id": "15a",
      "title": "Test 15a – Familie, Partnersuche & Beziehung (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Termindruck schon bei Kindern",
        "b": "Vorsicht vor zweifelhaften Kontaktagenturen!",
        "c": "Liebe fürs Leben muss wachsen",
        "d": "Kinder bleiben immer länger bei den Eltern wohnen",
        "e": "Partnervermittlungen generell empfehlenswert",
        "f": "Aktive Partnersuche gegen das Alleinsein",
        "g": "Probleme bei der Kindererziehung",
        "h": "Partnervermittlung per Telefon",
        "i": "Wenn die Kinder aus dem Hause sind",
        "j": "Zeitprobleme in der Familie"
      },
      "items": [
        {
          "num": 1,
          "text": "Die Krügers sind eine ganz normale Familie. Vater Bernd arbeitet 40 Stunden pro Woche bei einer Versicherung, Mutter Yvonne hat einen Teilzeitjob als Arzthelferin. Das Paar hat zwei Kinder. Tom ist neun, Linda vier Jahre alt. Nach der Arbeit holt Yvonne die beiden aus der Schule und dem Kindergarten ab. Dann geht sie einkaufen, wäscht, putzt und kocht. Wenn Bernd abends nach Hause kommt, kontrolliert er noch Hausaufgaben oder besucht seinen alten Vater, der immer häufiger Hilfe braucht. Bernd Krüger kann sich nicht erinnern, wann er das letzte Buch gelesen hat. Für Hobbys oder Bekannte bleibt keine Zeit. Und wenn dann ein langer Tag zu Ende geht und die beiden Kinder schlafen, sitzen Bernd und Yvonne Krüger total müde auf der Couch. In vielen Familien ist es ähnlich. Vor allem manche Eltern können die Doppellast von Beruf und Familie kaum noch tragen. Was hilft, ist Zeitmanagement. Der Begriff ist allerdings missverständlich. Die Zeit lässt sich nicht managen. Wir können uns nur selbst managen.",
          "answer": "j",
          "explanation": "Durch die Doppelbelastung von Beruf, Haushalt und Familie bleibt den Eltern im Alltag keine Zeit für Hobbys oder Bekannte ('Zeitprobleme in der Familie')."
        },
        {
          "num": 2,
          "text": "Der Wunsch nach der Zweisamkeit hat sich zu einem guten Geschäft entwickelt, denn gerade reiferen Alleinstehenden fällt es oft schwer, neue Partner zu finden. Vermittlungsagenturen bieten ihre Dienste im Internet oder in den Tageszeitungen an. Neben vielen seriösen Firmen finden sich auf dem Markt aber auch schwarze Schafe. Bei solchen Anbietern beginnen die Tricks bereits bei den Anzeigen in der Zeitung oder im Netz. Dort stellen Personen angeblich sich selbst vor. Ihre Beschreibung ist direkt auf die Wünsche älterer Singles zugeschnitten, oft genug auch mit ansprechendem „Originalfoto“. Wer die angegebene Telefonnummer wählt, muss dann plötzlich feststellen, es in Wirklichkeit mit einer Partnervermittlungsagentur zu tun zu haben. Und die gehen dann in der Regel schnell und aggressiv vor. Es wird ein Treffen vereinbart – und wenn man sich wirklich darauf einlassen möchte, heißt es schon hier: Aufgepasst! Wird nämlich ein neutraler Treffpunkt, beispielsweise ein Café, vereinbart, verliert der Kunde sein 14-tägiges Widerrufs- bzw. Rücktrittsrecht, das ihm bei einem Hausbesuch zustehen und ihn von einem vielleicht zu schnell unterschriebenen Vertrag befreien würde.",
          "answer": "b",
          "explanation": "Der Text warnt vor unseriösen Partnervermittlungsagenturen („schwarzen Schafen“), die mit gefälschten Kontaktanzeigen und Treffen im Café das Widerrufsrecht umgehen ('Vorsicht vor zweifelhaften Kontaktagenturen!')."
        },
        {
          "num": 3,
          "text": "Wie entsteht eine langfristige Beziehung? Was viele nicht wissen: Die Partnerschaft verläuft in Phasen. Fast jede Liebe beginnt mit einer Hochphase der Verliebtheit. Ist diese Phase vorüber, folgt eine Phase des satten Glücks, in der beide den Wunsch haben, mit diesem Menschen ein ganzes Leben zu verbringen. Fast alle Paare erleben danach eine Zeit, in der der Alltag eintritt. Man ist gezwungen, sich in einem realistischeren Licht zu sehen. In der folgenden Stress- und Streitphase geht es darum, die Bedingungen des Zusammenlebens festzulegen und Lösungen für Partnerschaft und Beruf zu finden. Bleibt ein Paar nach dieser schwierigen Phase zusammen, festigt sich die Partnerschaft in der fünften Phase weiter und wird ruhiger. Die Partner finden zu sich selbst, erlauben sich gegenseitig mehr freie Zeit und eigene Interessen. In der letzten Phase entsteht das, was man die Liebe fürs Leben nennen kann. In der Beziehung hat sich so viel Vertrauen gebildet, dass die Beziehung eine feste Basis für die Zukunft hat.",
          "answer": "c",
          "explanation": "Eine Partnerschaft durchläuft mehrere Entwicklungsphasen, bis nach dem Überstehen der Alltags- und Streitphase schließlich die beständige Liebe fürs Leben entsteht ('Liebe fürs Leben muss wachsen')."
        },
        {
          "num": 4,
          "text": "Knapp 13 Millionen Single-Haushalte gibt es in Deutschland, und das meist unfreiwillig. Fast jeder, der allein lebt, wünscht sich einen Partner. Doch wie und wo ist er oder sie zu finden? Oftmals stecken Singles in einer schwierigen Situation: Wer lange allein gelebt hat, wünscht sich zwar eine feste Bindung, gleichzeitig wächst aber auch die Angst davor. Dieses Wechselbad aus Wollen und Vorsichtig-Sein macht die Sache immer schwieriger – und nicht selten vergehen so die Jahre des Alleinseins. Zwar sollte man die Hoffnung nie aufgeben, den oder die Richtige irgendwann zufällig zu finden. Aber dass die Traumfrau auf einmal an die Tür klopft oder plötzlich der Traumprinz auf einem weißen Schimmel um die Ecke reitet, ist unwahrscheinlich. Deswegen lautet der Rat für alle Singles: Ergreifen Sie die Initiative!",
          "answer": "f",
          "explanation": "Da der Traumpartner kaum zufällig an die Tür klopft, wird Singles geraten, selbst die Initiative zu ergreifen ('Aktive Partnersuche gegen das Alleinsein')."
        },
        {
          "num": 5,
          "text": "Nach dem Abitur, zum Studium oder weil der Zeitpunkt einfach gekommen ist: Wenn die Kinder ausziehen, verändert sich auch das Leben der Eltern. Neben der Freude, endlich wieder Zeit und Raum für sich zu haben, entsteht auch eine Leere, die es nun zu füllen gilt. Die Selbständigkeit des Kindes bedeutet, dass auch die Eltern wieder ein unabhängigeres Leben führen können. Die Ehepartner haben wieder mehr Zeit füreinander. Das kann auch bisher unbewusste Probleme an den Tag bringen. Viele Partner müssen sich erst wieder an ein Leben zu zweit gewöhnen. Hilfreich ist es, sich frühzeitig auf ein Leben „ohne“ Kinder einzustellen. Man kann sich z. B. beruflich fortbilden oder anderen, eigenen Interessen nachgehen. Die Umstellung, wenn die Kinder ausziehen, ist dann nicht mehr so groß.",
          "answer": "i",
          "explanation": "Der Text beschreibt die Veränderung und Neuorientierung für Eltern, sobald die erwachsenen Kinder ausziehen ('Wenn die Kinder aus dem Hause sind')."
        }
      ]
    },
    {
      "id": "16",
      "title": "Test 16 – Medien, Nachrichten & Bewegung",
      "isVariant": false,
      "headings": {
        "a": "Viele Trampoline haben erhebliche Sicherheitsmängel",
        "b": "Traditionelle Nachrichtenmedien immer noch gefragt",
        "c": "Soziale Medien ersetzen alte Informationsquellen",
        "d": "Schüler bereiten Nachrichtensendungen vor",
        "e": "Mit Nachrichten im Unterricht arbeiten",
        "f": "Medienkonsum fördert ungesunde Lebensweise",
        "g": "Kritik an der Nachrichtensprache",
        "h": "Jugendliche konsumieren mehr Fett und Zucker",
        "i": "Informationen leichter verstehen",
        "j": "Fachleute warnen vor unsachgemäßer Nutzung von Sprunggeräten"
      },
      "items": [
        {
          "num": 1,
          "text": "Die meisten Menschen verbinden den Begriff Barrierefreiheit mit dem Zugang zu Gebäuden oder Transportmitteln. Dabei betrifft Barrierefreiheit viele weitere Bereiche unseres Alltags, so zum Beispiel auch die Informations- und Kommunikationstechnologie. Die APA, die Austria Presse Agentur, hat deshalb einen Nachrichtendienst in einfacher und leicht verständlicher Sprache ins Leben gerufen. Er wendet sich an Menschen, die Lese- oder Lernschwierigkeiten haben oder die die deutsche Sprache noch nicht so gut beherrschen. Für diesen Nachrichtendienst werden die wichtigsten Meldungen des Tages aus Politik, Wirtschaft, Sport, Kultur und Lokalnachrichten für die Niveaustufen A2 und B1 geschrieben. Interessenten können sich die Texte fünfmal pro Woche am späten Nachmittag per E-Mail schicken lassen oder über eine besondere Informationsplattform bekommen. Das Projekt wird vom Sozialministerium gefördert und wurde gemeinsam mit einem Grazer Unternehmen entwickelt, das auf Textübertragungen für verschiedene Schwierigkeitsstufen spezialisiert ist. Der Nachrichtendienst wurde bereits als innovativer Beitrag zum Thema Barrierefreiheit ausgezeichnet.",
          "answer": "i",
          "explanation": "Die Austria Presse Agentur (APA) bietet einen barrierefreien Nachrichtendienst in einfacher, leicht verständlicher Sprache auf A2/B1-Niveau an ('Informationen leichter verstehen')."
        },
        {
          "num": 2,
          "text": "Die WHO, die Weltgesundheitsorganisation, warnt vor den Folgen ungesunder Werbung im Internet. Kinder und Jugendliche treffen beim Nutzen der sozialen Medien häufig auf Anzeigen für ungesunde Lebensmittel wie Süßigkeiten oder salzige und fettreiche Snacks. So werden Übergewicht und damit zusammenhängende Krankheiten im Erwachsenenalter gefördert, mahnt die Organisation. Sie fordert deshalb Regierungen dazu auf, diese Werbung zum Schutze der Kinder stärker zu begrenzen. Die WHO weist außerdem auf die Gefahr von Bewegungsmangel im Zusammenhang mit den Neuen Medien hin. Das betrifft nicht nur Jugendliche, sondern auch Kleinkinder. Gerade in den ersten Jahren sollte der natürliche Bewegungsdrang der Kinder genutzt werden, damit sie Freude an Bewegung und Sport entwickeln. Kleinkinder sollten sich mindestens drei Stunden pro Tag bewegen und so wenig Zeit wie möglich vor einem Bildschirm verbringen. Überhaupt sollten Kinder, die jünger als zwei Jahre sind, grundsätzlich nicht vor ein Tablet oder einen PC gesetzt werden. Denn wer viel sitzt, wird in der Folge leichter krank.",
          "answer": "f",
          "explanation": "Laut WHO fördern Werbung für ungesunde Snacks in sozialen Medien sowie langes Sitzen vor Bildschirmen Übergewicht und Bewegungsmangel ('Medienkonsum fördert ungesunde Lebensweise')."
        },
        {
          "num": 3,
          "text": "Schülerinnen und Schüler sollen im Schulunterricht auch den Umgang mit Nachrichten lernen. Das forderten kürzlich in Wien die Teilnehmenden an einer Konferenz zur politischen Bildung von Jugendlichen. Das Ziel dabei ist, jungen Menschen den kritischen Umgang mit den Inhalten und der Präsentation von Nachrichten beizubringen. Heute ist der Zugriff auf Nachrichtensendungen so einfach wie noch nie. Viele Nachrichtensendungen des ORF können mindestens eine Woche lang im Internet abgerufen werden. Schülerinnen und Schüler können sie so zur eigenen Arbeit nutzen oder gemeinsam in der Klasse besprechen. Die Konferenz nannte auch gleich konkrete Fragen für die Analyse von Nachrichtensendungen: Welche Nachrichten werden angeboten – Politik und Wirtschaft, Unfälle, Sport oder Prominews? Berichten die Moderatorinnen und Moderatoren sachlich oder machen sie persönliche Bemerkungen zu den einzelnen Nachrichten? Wie ist die Reihenfolge, wie lange sind die Beiträge? Am besten eignen sich die Unterrichtsfächer Politische Bildung, Geschichte, Deutsch oder Englisch, so die Expertenrunde.",
          "answer": "e",
          "explanation": "Auf einer Konferenz in Wien wurde gefordert, Nachrichtensendungen im Schulunterricht gemeinsam zu analysieren ('Mit Nachrichten im Unterricht arbeiten')."
        },
        {
          "num": 4,
          "text": "Mit dem Trampolin den Körper in Schwung bringen – für viele Menschen ist das Sprunggerät eine gute Möglichkeit, sich mit viel Spaß und ohne allzu großen Aufwand zu bewegen. Besonders beliebt ist das Trampolin bei Kindern. Expertinnen und Experten betonen auch die Vorteile des Hüpfens auf dem Trampolin. Die Bewegung auf dem Trampolin fördert nicht nur die Beweglichkeit, sondern auch die Koordination. Allerdings ist sie nicht ganz ungefährlich. Orthopäden weisen auf die extrem hohe Unfallgefahr hin. Die Ärzteschaft möchte Kindern und Eltern keineswegs die Freude am Trampolinspringen verderben. Vielmehr möchte sie dazu aufrufen, einige Sicherheitsregeln zu befolgen, mit denen sich Unfälle leicht vermeiden lassen. Eine harte, ebene Stellfläche und ein Sicherheitsnetz sind dabei unverzichtbare Voraussetzungen. Viele Sportvereine bieten Kurse an, in denen Kinder sicheres Trampolinspringen lernen können.",
          "answer": "j",
          "explanation": "Orthopäden weisen auf die hohe Unfallgefahr beim Trampolinspringen hin und mahnen zur Einhaltung wichtiger Sicherheitsregeln ('Fachleute warnen vor unsachgemäßer Nutzung von Sprunggeräten')."
        },
        {
          "num": 5,
          "text": "Die Klage, dass Jugendliche und junge Erwachsene kein Interesse mehr an Nachrichten haben, ist unbegründet. So lautet zumindest eine der Schlussfolgerungen aus einer Studie zum durchschnittlichen Medienkonsum junger Menschen mit dem Schwerpunkt Nachrichten. Demnach lesen oder hören in Österreich nahezu 50 % der Personen unter 30 Jahren täglich Nachrichten. Viele der Befragten gaben an, dass sie sich nicht auf die Inhalte der sozialen Medien verlassen möchten, da ihre Glaubwürdigkeit oft angezweifelt wird. Den klassischen Medien wie Nachrichtensendungen oder Tageszeitungen wird hingegen eher geglaubt. Soziale Netzwerke können herkömmliche Nachrichtenquellen nicht ersetzen, so die vorherrschende Meinung, auch wenn diese Quellen in der Gestaltung oft als eher langweilig empfunden werden.",
          "answer": "b",
          "explanation": "Junge Erwachsene vertrauen weiterhin klassischen Nachrichtensendungen und Tageszeitungen mehr als sozialen Netzwerken ('Traditionelle Nachrichtenmedien immer noch gefragt')."
        }
      ]
    },
    {
      "id": "17",
      "title": "Test 17 – Ausdauersport, Fitness & Kinderwagen",
      "isVariant": false,
      "headings": {
        "a": "Sport ist gesund – wenn man einige wichtige Regeln beachtet",
        "b": "Griechische Sportler so erfolgreich wie nie zuvor",
        "c": "Fitness auch mit wenig Zeitaufwand erreichbar",
        "d": "Geprüfte Qualität für Babys",
        "e": "Bluthochdruck beschleunigt das Abnehmen",
        "f": "Sportbegeisterte Eltern – und auch die Babys sind beim Joggen dabei",
        "g": "Täglich kurze Sprints besser als langes Ausdauertraining",
        "h": "Ein Leistungssport für jedes Alter",
        "i": "Unüberschaubares Angebot an Kinderwagen überfordert junge Eltern",
        "j": "Autoindustrie: In Zukunft Mobilität ohne Grenzen"
      },
      "items": [
        {
          "num": 1,
          "text": "An der Ostküste Attikas in Griechenland lag in der Antike der Ort Marathon. Dort siegte der griechische Feldherr Miltiades im Jahr 490 vor Christus über das Heer der Perser. Der Sage nach soll ein Soldat die 42,2 km lange Strecke nach Athen gerannt sein, um die Nachricht dieses für Griechenland wichtigen Sieges zu überbringen. Bei seiner Ankunft in Athen brach er, noch während er die Nachricht verkündete, vor Erschöpfung tot zusammen. Auf diese Legende geht eine sportliche Disziplin zurück: der Marathonlauf. Bereits seit 1896 ist er olympische Disziplin, seit 1984 auch für Frauen. Die Streckenlänge von 42.195 m wurde 1924 festgelegt. Der Marathonlauf gilt als einziger Leistungssport, der bis ins hohe Alter ausgeübt werden kann. Wissenschaftler erklären das mit der menschlichen Evolution: Der Mensch jagte in der Frühzeit seine Beute so lange vor sich her, bis diese vor Erschöpfung nicht mehr weiterkonnte. Die Fähigkeit, ausdauernd über lange Strecken zu rennen, ist also in den menschlichen Genen verankert.",
          "answer": "h",
          "explanation": "Der Marathonlauf gilt als einziger Leistungssport, der dank der menschlichen Evolution bis ins hohe Alter ausgeübt werden kann ('Ein Leistungssport für jedes Alter')."
        },
        {
          "num": 2,
          "text": "Warum soll sich der Mensch nur auf Straßen und Wegen fortbewegen? Sich in Feld und Wald, über Stock und Stein fortzubewegen, ist mindestens genauso interessant. Daher erfand die Autoindustrie den Geländewagen und die Fahrradindustrie das Mountainbike. Da fehlte eigentlich nur noch eine Neuentwicklung eines Gefährts, dessen Mobilitätsfähigkeiten vorher relativ begrenzt waren: der Kinderwagen. Doch das ist jetzt auch vorbei: Im Trend liegt jetzt der Jogging-Kinderwagen, ein Kinderwagen mit nur noch drei bereiften Rädern. Diese neuen Transportmittel für Babys können sportbegeisterte und von grenzenloser Mobilität träumende Eltern jetzt samt Kind beim Joggen oder beim Inlineskaten vor sich herschieben. Doch der für die Gerätesicherheit bewährte TÜV, bei Fahrzeugbesitzern in Deutschland schon seit langem als Spielverderber bekannt, warnte vor den Joggingwagen: Sie haben einen ungünstigen Schwerpunkt auf der Hinterachse, d. h. sie kippen leicht nach hinten um, und sie können sich leicht selbständig machen – jedenfalls solange, bis die Babys das Bremsen gelernt haben.",
          "answer": "f",
          "explanation": "Mit neuen dreirädrigen Jogging-Kinderwagen nehmen sportbegeisterte Eltern ihre Babys zum Joggen oder Inlineskaten mit ('Sportbegeisterte Eltern – und auch die Babys sind beim Joggen dabei')."
        },
        {
          "num": 3,
          "text": "Schweizer Forscher haben herausgefunden, dass nur 6 Minuten Hochleistungstraining pro Woche – also weniger als eine Minute pro Tag – ausreichen, um den Körper fit zu halten. In einem Versuch mit mehreren Probanden nahm eine Gruppe an einem traditionellen Ausdauertraining teil, mit je ein bis zwei Trainingsstunden täglich. Die zweite Gruppe führte täglich 60 Sekunden dauernde Radsprints durch, wobei die Teilnehmer quasi aus dem Stand Höchstgeschwindigkeit erzielen mussten. Das Resultat war überraschend: Beide Gruppen zeigten die gleichen gesundheitlichen Verbesserungen. Die Muskeln nahmen gleich viel Sauerstoff auf, und auch die Werte des für die Sauerstoffaufnahme verantwortlichen Zitratenzyms waren gleich. Sehr kurze und hochintensive sportliche Übungen verbessern die Fitness genauso wie das zeitraubende traditionelle Ausdauertraining.",
          "answer": "c",
          "explanation": "Schon 6 Minuten hochintensives Training pro Woche verbessern die Fitness genauso stark wie stundenlanges Ausdauertraining ('Fitness auch mit wenig Zeitaufwand erreichbar')."
        },
        {
          "num": 4,
          "text": "Mehr Bewegung als Ausgleich für zu langes Sitzen im Büro und in der Freizeit ist zurzeit angesagt, um Übergewicht, Bluthochdruck und Herz-Kreislauf-Erkrankungen vorzubeugen und um fit zu bleiben. Gerade für Einsteiger gibt es jedoch bei den die Ausdauer trainierenden Sportarten wie dem Joggen einige Grundregeln, die beachtet werden müssen, will man gesundheitliche Schäden vermeiden. Die ersten Trainingseinheiten sollten nicht länger als 20 bis 30 Minuten dauern und zweimal pro Woche durchgeführt werden. Der Puls sollte nie den Wert 200 minus Lebensalter überschreiten, bei einem 20-Jährigen kann er also bei 180, bei einem 60-Jährigen hingegen nur bei 140 liegen. Außerdem gilt für alle, die beim Sport abnehmen möchten: Je höher der Pulsschlag, desto weniger Fett wird verbrannt. Hoher Pulsschlag lässt Sporttreibende langsamer abnehmen.",
          "answer": "a",
          "explanation": "Um gesundheitliche Schäden beim Ausdauersport zu vermeiden, müssen Einsteiger Grundregeln zu Trainingsdauer und Puls beachten ('Sport ist gesund – wenn man einige wichtige Regeln beachtet')."
        },
        {
          "num": 5,
          "text": "Viele frischgebackene Eltern stehen einem riesigen Angebot an Kinderwagen gegenüber, das in Kinderläden und Großmärkten feilgeboten wird. Doch welcher ist der richtige? Experten raten, beim Kauf dieses für die ersten Jahre mit dem Kleinkind wichtigen Gefährts auf ein paar Dinge zu achten. Erstens sollte die Matratze nicht zu weich sein, damit das Kind nicht einsinkt, wodurch die Atmung behindert werden kann. Zweitens sollten die Räder gefedert sein, um Erschütterungen auf unebenen Wegen auszugleichen. Ein hoher Wagen schützt die Babys vor dem Auspuff der Autos an Straßenkreuzungen. Zusammenklappbare Wagen passen in jeden Kofferraum und lassen sich fast überallhin mitnehmen. Der Wagen sollte vor allem kippsicher sein und keine scharfen Kanten haben, an denen sich die Kinder verletzen können. Vom TÜV geprüfte Kinderwagen erhalten ein Prüfzeichen. Damit haben die Eltern eine gewisse Sicherheit, dass der Kinderwagen auch nach Dauergebrauch nicht zu einem Sicherheitsrisiko für ihr Kind werden kann.",
          "answer": "d",
          "explanation": "Experten erklären, worauf Eltern beim Kinderwagenkauf achten sollten und dass ein TÜV-Prüfzeichen für Sicherheit bürgt ('Geprüfte Qualität für Babys')."
        }
      ]
    },
    {
      "id": "17a",
      "title": "Test 17a – Ausdauersport, Fitness & Kinderwagen (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Sport ist gesund – wenn man einige wichtige Regeln beachtet",
        "b": "Griechische Sportler so erfolgreich wie nie zuvor",
        "c": "Fitness auch mit wenig Zeitaufwand erreichbar",
        "d": "Geprüfte Qualität für Babys",
        "e": "Bluthochdruck beschleunigt das Abnehmen",
        "f": "Sportbegeisterte Eltern – und auch die Babys sind beim Joggen dabei",
        "g": "Täglich kurze Sprints besser als langes Ausdauertraining",
        "h": "Ein Leistungssport für jedes Alter",
        "i": "Knappes Angebot an Kinderwagen",
        "j": "Autoindustrie: In Zukunft Mobilität ohne Grenzen"
      },
      "items": [
        {
          "num": 1,
          "text": "An der Ostküste Attikas in Griechenland lag in der Antike der Ort Marathon. Dort siegte der griechische Feldherr Miltiades im Jahr 490 vor Christus über das Heer der Perser. Der Sage nach soll ein Soldat die 42,2 km lange Strecke nach Athen gerannt sein, um die Nachricht dieses für Griechenland wichtigen Sieges zu überbringen. Bei seiner Ankunft in Athen brach er, noch während er die Nachricht verkündete, vor Erschöpfung tot zusammen. Auf diese Legende geht eine sportliche Disziplin zurück: der Marathonlauf. Bereits seit 1896 ist er olympische Disziplin, seit 1984 auch für Frauen. Die Streckenlänge von 42.195 m wurde 1924 festgelegt. Der Marathonlauf gilt als einziger Leistungssport, der bis ins hohe Alter ausgeübt werden kann. Wissenschaftler erklären das mit der menschlichen Evolution: Der Mensch jagte in der Frühzeit seine Beute so lange vor sich her, bis diese vor Erschöpfung nicht mehr weiterkonnte. Die Fähigkeit, ausdauernd über lange Strecken zu rennen, ist also in den menschlichen Genen verankert.",
          "answer": "h",
          "explanation": "Der Marathonlauf gilt als einziger Leistungssport, der dank der menschlichen Evolution bis ins hohe Alter ausgeübt werden kann ('Ein Leistungssport für jedes Alter')."
        },
        {
          "num": 2,
          "text": "Warum soll sich der Mensch nur auf Straßen und Wegen fortbewegen? Sich in Feld und Wald, über Stock und Stein fortzubewegen, ist mindestens genauso interessant. Daher erfand die Autoindustrie den Geländewagen und die Fahrradindustrie das Mountainbike. Da fehlte eigentlich nur noch eine Neuentwicklung eines Gefährts, dessen Mobilitätsfähigkeiten vorher relativ begrenzt waren: der Kinderwagen. Doch das ist jetzt auch vorbei: Im Trend liegt jetzt der Jogging-Kinderwagen, ein Kinderwagen mit nur noch drei bereiften Rädern. Diese neuen Transportmittel für Babys können sportbegeisterte und von grenzenloser Mobilität träumende Eltern jetzt samt Kind beim Joggen oder beim Inlineskaten vor sich herschieben. Doch der für die Gerätesicherheit bewährte TÜV, bei Fahrzeugbesitzern in Deutschland schon seit langem als Spielverderber bekannt, warnte vor den Joggingwagen: Sie haben einen ungünstigen Schwerpunkt auf der Hinterachse, d. h. sie kippen leicht nach hinten um, und sie können sich leicht selbständig machen – jedenfalls solange, bis die Babys das Bremsen gelernt haben.",
          "answer": "f",
          "explanation": "Mit neuen dreirädrigen Jogging-Kinderwagen nehmen sportbegeisterte Eltern ihre Babys zum Joggen oder Inlineskaten mit ('Sportbegeisterte Eltern – und auch die Babys sind beim Joggen dabei')."
        },
        {
          "num": 3,
          "text": "Schweizer Forscher haben herausgefunden, dass nur 6 Minuten Hochleistungstraining pro Woche – also weniger als eine Minute pro Tag – ausreichen, um den Körper fit zu halten. In einem Versuch mit mehreren Probanden nahm eine Gruppe an einem traditionellen Ausdauertraining teil, mit je ein bis zwei Trainingsstunden täglich. Die zweite Gruppe führte täglich 60 Sekunden dauernde Radsprints durch, wobei die Teilnehmer quasi aus dem Stand Höchstgeschwindigkeit erzielen mussten. Das Resultat war überraschend: Beide Gruppen zeigten die gleichen gesundheitlichen Verbesserungen. Die Muskeln nahmen gleich viel Sauerstoff auf, und auch die Werte des für die Sauerstoffaufnahme verantwortlichen Zitratenzyms waren gleich. Sehr kurze und hochintensive sportliche Übungen verbessern die Fitness genauso wie das zeitraubende traditionelle Ausdauertraining.",
          "answer": "c",
          "explanation": "Schon 6 Minuten hochintensives Training pro Woche verbessern die Fitness genauso stark wie stundenlanges Ausdauertraining ('Fitness auch mit wenig Zeitaufwand erreichbar')."
        },
        {
          "num": 4,
          "text": "Mehr Bewegung als Ausgleich für zu langes Sitzen im Büro und in der Freizeit ist zurzeit angesagt, um Übergewicht, Bluthochdruck und Herz-Kreislauf-Erkrankungen vorzubeugen und um fit zu bleiben. Gerade für Einsteiger gibt es jedoch bei den die Ausdauer trainierenden Sportarten wie dem Joggen einige Grundregeln, die beachtet werden müssen, will man gesundheitliche Schäden vermeiden. Die ersten Trainingseinheiten sollten nicht länger als 20 bis 30 Minuten dauern und zweimal pro Woche durchgeführt werden. Der Puls sollte nie den Wert 200 minus Lebensalter überschreiten, bei einem 20-Jährigen kann er also bei 180, bei einem 60-Jährigen hingegen nur bei 140 liegen. Außerdem gilt für alle, die beim Sport abnehmen möchten: Je höher der Pulsschlag, desto weniger Fett wird verbrannt. Hoher Pulsschlag lässt Sporttreibende langsamer abnehmen.",
          "answer": "a",
          "explanation": "Um gesundheitliche Schäden beim Ausdauersport zu vermeiden, müssen Einsteiger Grundregeln zu Trainingsdauer und Puls beachten ('Sport ist gesund – wenn man einige wichtige Regeln beachtet')."
        },
        {
          "num": 5,
          "text": "Viele frischgebackene Eltern stehen einem riesigen Angebot an Kinderwagen gegenüber, das in Kinderläden und Großmärkten feilgeboten wird. Doch welcher ist der richtige? Experten raten, beim Kauf dieses für die ersten Jahre mit dem Kleinkind wichtigen Gefährts auf ein paar Dinge zu achten. Erstens sollte die Matratze nicht zu weich sein, damit das Kind nicht einsinkt, wodurch die Atmung behindert werden kann. Zweitens sollten die Räder gefedert sein, um Erschütterungen auf unebenen Wegen auszugleichen. Ein hoher Wagen schützt die Babys vor dem Auspuff der Autos an Straßenkreuzungen. Zusammenklappbare Wagen passen in jeden Kofferraum und lassen sich fast überallhin mitnehmen. Der Wagen sollte vor allem kippsicher sein und keine scharfen Kanten haben, an denen sich die Kinder verletzen können. Vom TÜV geprüfte Kinderwagen erhalten ein Prüfzeichen. Damit haben die Eltern eine gewisse Sicherheit, dass der Kinderwagen auch nach Dauergebrauch nicht zu einem Sicherheitsrisiko für ihr Kind werden kann.",
          "answer": "d",
          "explanation": "Experten erklären, worauf Eltern beim Kinderwagenkauf achten sollten und dass ein TÜV-Prüfzeichen für Sicherheit bürgt ('Geprüfte Qualität für Babys')."
        }
      ]
    },
    {
      "id": "18",
      "title": "Test 18 – Märkte in Österreich & Selbstmarketing",
      "isVariant": false,
      "headings": {
        "a": "Erneuerungskur für einen alten Markt",
        "b": "Junge Influencer werben für Bioprodukte",
        "c": "Neues Buch über einen Wiener Architekten erschienen",
        "d": "Österreichs beliebteste Marktplätze",
        "e": "Schreiben im Internet für die Karriere",
        "f": "Schulung zum Erfolg im Beruf",
        "g": "Seminar: Produkte erfolgreich verkaufen",
        "h": "Warum immer mehr Menschen auf Märkten einkaufen",
        "i": "Wenn Blogger Firmengeheimnisse verraten",
        "j": "Wissenswertes über Wiens größten innerstädtischen Markt"
      },
      "items": [
        {
          "num": 1,
          "text": "Das Lesermagazin MENU hat eine Umfrage zu den populärsten Märkten in Österreich durchgeführt. Vor der eigentlichen Abstimmung hatte das Magazin seine Leserinnen und Leser dazu aufgerufen, Märkte zu nominieren. Aus den häufigsten Nennungen hat das Redaktionsteam eine Liste mit zwanzig Märkten aus ganz Österreich erstellt und zwei Wochen lang online zur Abstimmung angeboten. Als klarer Sieger ging der Markt am Domplatz von St. Pölten hervor. Dieser ist berühmt für sein ganzjähriges Einkaufsvergnügen. Als Nahversorger für die Innenstadt und Anziehungspunkt für Menschen aus dem Umland trägt er erheblich zur Lebensqualität der Bevölkerung bei. Auf Platz zwei und drei folgten zwei burgenländische Märkte, nämlich der Markt der Erde in Parndorf und der Regionalmarkt in den ehemaligen Stallungen von Schloss Esterházy in Eisenstadt. Das große Interesse an der Abstimmung zeigt laut MENU, wie sehr die Konsumentinnen und Konsumenten Märkte schätzen.",
          "answer": "d",
          "explanation": "Das Magazin MENU hat in einer Online-Abstimmung die populärsten Märkte Österreichs gekürt ('Österreichs beliebteste Marktplätze')."
        },
        {
          "num": 2,
          "text": "Sie sind der Meinung, dass Ihre Qualifikationen ausreichen, um Karriere zu machen? Qualifikationen und Berufserfahrung sind zwar wichtige Kriterien für den erfolgreichen Aufstieg auf der Karriereleiter, doch ohne gutes Selbstmarketing werden Sie auf halbem Wege stehenbleiben. Das ist letztlich genauso wie beim Verkauf eines Produktes: Es reicht nicht, dass ein Produkt gut ist, es muss auch gut beworben werden. Während Marketing das Produkt vorteilhaft am Markt platzieren möchte, verfolgt man beim Selbstmarketing das Ziel, seine Persönlichkeit und Stärken bewusst hervorzuheben. Mit anderen Worten: Es geht darum, sich gut zu verkaufen. Selbstmarketing beginnt schon bei der Bewerbung und dem Vorstellungsgespräch und setzt sich im Job fort. Auch dort müssen Sie auf sich aufmerksam machen. Doch Achtung: Angeber mag niemand! Wie Sie das richtige Maß finden, erfahren Sie in einem Seminar, das an vier Wochenenden im April in Klagenfurt stattfindet. Alle Details gibt es hier.",
          "answer": "f",
          "explanation": "Ein Wochenendseminar in Klagenfurt zeigt, wie man durch gezieltes Selbstmarketing beruflich aufsteigt ('Schulung zum Erfolg im Beruf')."
        },
        {
          "num": 3,
          "text": "Der Wiener Naschmarkt gehört zu Österreichs beliebtesten Märkten. Mit einer Fläche von mehr als zwei Hektar ist er der größte Markt in der Innenstadt. Schon 1780 handelten Bauern dort mit Milchprodukten. Gemauerte Marktstände entstanden erst mehr als 100 Jahre später. Von 1910 an wurden mehr als 120 fixe Marktstände im einheitlichen Stil von Otto Wagner geplant und errichtet. Das Marktamtsgebäude bei der Kettenbrückengasse wurde 1916 fertiggestellt. Heute ist der Naschmarkt eine begehrte Wiener Sehenswürdigkeit. Bei Schönwetter zählt der Markt mehr als 65.000 Personen pro Woche, viele davon Touristen. Ein Teil der Marktfläche ist für Gastronomiebetriebe reserviert. Nun erzählt ein neuer Reiseführer die Geschichte des Naschmarktes, reich illustriert mit alten Aufnahmen. Ein Kapitel behandelt auch die berühmten Wienzeilenhäuser Otto Wagners, die sich an der Linken Wienzeile im Bereich des Naschmarktes befinden. Dazu gibt es Einkaufstipps und Beschreibungen der Lokale. „Der Markt am Wienfluss“, Hrsg. Hannes Ortner, 35 Seiten, 17 Euro.",
          "answer": "j",
          "explanation": "Der Text und der vorgestellte Reiseführer liefern Geschichte, Fakten und Tipps rund um den Wiener Naschmarkt ('Wissenswertes über Wiens größten innerstädtischen Markt')."
        },
        {
          "num": 4,
          "text": "Wer bloggt, zeigt neben Fachkompetenz auch Kreativität. Das schätzen auch Arbeitgeber. Ob man über fachliche Fragestellungen schreibt oder einfach nur über das Leben – das Themenspektrum von Blogs ist riesig. Genauso vielfältig sind auch die Möglichkeiten, die sie Bewerberinnen und Bewerbern bieten. Wer einen Blog professionell betreibt, kann seine fachlichen Kompetenzen präsentieren und gleichzeitig seinen Ideenreichtum unter Beweis stellen. Doch auch die Darstellung eines Hobbys zeigt, dass der Bewerber aktiv und kreativ ist. Experten raten daher Bloggerinnen und Bloggern, in ihren Bewerbungsunterlagen gezielt darauf hinzuweisen. Doch Achtung: Ein Blog kann Bewerber auch in einem schlechten Licht erscheinen lassen. Bloggen während der Arbeitszeit und das Schreiben über Firmeninterna sind natürlich tabu.",
          "answer": "e",
          "explanation": "Ein professionell geführter Blog im Internet zeigt Fachkompetenz und Kreativität und kann bei Bewerbungen die Karriere fördern ('Schreiben im Internet für die Karriere')."
        },
        {
          "num": 5,
          "text": "Bis Herbst soll ein neues Marktkonzept für den altehrwürdigen Salzburger Grünmarkt vorliegen. Damit der Markt für Besucherinnen und Besucher wieder attraktiver wird, setzt die zuständige Stelle im Magistrat auf Nachhaltigkeit. Biologische Lebensmittel aus nachhaltiger Produktion, im Idealfall aus der Region, sollen den Markt wieder zu einem Fixpunkt in der Altstadt werden lassen. Der für Märkte, Stadtnatur und Lebensqualität zuständige Vizebürgermeister hofft, dass der Markt dazu beitragen kann, ein positives Lebensgefühl zu vermitteln. Obwohl die Stadt die Verkaufsstände vor einigen Jahren aufwändig hatte restaurieren lassen, verzeichneten die Händler zuletzt einen deutlichen Rückgang an Kundschaft. Zudem haben einige von ihnen altersbedingt ihre Verkaufsstände aufgegeben. In diesem Zusammenhang wurde auch die beliebte Foodbloggerin Jasmin May engagiert. Sie soll dazu beitragen, das Konzept in der Öffentlichkeit bekannter zu machen. Wir werden das Projekt weiterverfolgen und von seinem Fortgang berichten.",
          "answer": "a",
          "explanation": "Mit einem neuen Nachhaltigkeitskonzept soll der altehrwürdige Salzburger Grünmarkt wiederbelebt werden ('Erneuerungskur für einen alten Markt')."
        }
      ]
    },
    {
      "id": "18a",
      "title": "Test 18a – Märkte in Österreich & Selbstmarketing (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Erneuerungskur für einen alten Markt",
        "b": "Junge Influencer werben für Bioprodukte",
        "c": "Neues Buch über einen Wiener Architekten erschienen",
        "d": "Österreichs beliebteste Marktplätze",
        "e": "Schreiben im Internet für die Karriere",
        "f": "Schulung zum Erfolg im Beruf",
        "g": "Seminar: Produkte erfolgreich verkaufen",
        "h": "Warum immer mehr Menschen auf Märkten einkaufen",
        "i": "Wenn Blogger Firmengeheimnisse verraten",
        "j": "Wissenswertes über Wiens größten innerstädtischen Markt"
      },
      "items": [
        {
          "num": 1,
          "text": "Das Lesermagazin MENU hat eine Umfrage zu den populärsten Märkten in Österreich durchgeführt. Vor der eigentlichen Abstimmung hatte das Magazin seine Leserinnen und Leser dazu aufgerufen, Märkte zu nominieren. Aus den häufigsten Nennungen hat das Redaktionsteam eine Liste mit zwanzig Märkten aus ganz Österreich erstellt und zwei Wochen lang online zur Abstimmung angeboten. Als klarer Sieger ging der Markt am Domplatz von St. Pölten hervor. Dieser ist berühmt für sein ganzjähriges Einkaufsvergnügen. Als Nahversorger für die Innenstadt und Anziehungspunkt für Menschen aus dem Umland trägt er erheblich zur Lebensqualität der Bevölkerung bei. Auf Platz zwei und drei folgten zwei burgenländische Märkte, nämlich der Markt der Erde in Parndorf und der Regionalmarkt in den ehemaligen Stallungen von Schloss Esterházy in Eisenstadt. Das große Interesse an der Abstimmung zeigt laut MENU, wie sehr die Konsumentinnen und Konsumenten Märkte schätzen.",
          "answer": "d",
          "explanation": "Das Magazin MENU hat in einer Online-Abstimmung die populärsten Märkte Österreichs gekürt ('Österreichs beliebteste Marktplätze')."
        },
        {
          "num": 2,
          "text": "Sie sind der Meinung, dass Ihre Qualifikationen ausreichen, um Karriere zu machen? Qualifikationen und Berufserfahrung sind zwar wichtige Kriterien für den erfolgreichen Aufstieg auf der Karriereleiter, doch ohne gutes Selbstmarketing werden Sie auf halbem Wege stehenbleiben. Das ist letztlich genauso wie beim Verkauf eines Produktes: Es reicht nicht, dass ein Produkt gut ist, es muss auch gut beworben werden. Während Marketing das Produkt vorteilhaft am Markt platzieren möchte, verfolgt man beim Selbstmarketing das Ziel, seine Persönlichkeit und Stärken bewusst hervorzuheben. Mit anderen Worten: Es geht darum, sich gut zu verkaufen. Selbstmarketing beginnt schon bei der Bewerbung und dem Vorstellungsgespräch und setzt sich im Job fort. Auch dort müssen Sie auf sich aufmerksam machen. Doch Achtung: Angeber mag niemand! Wie Sie das richtige Maß finden, erfahren Sie in einem Seminar, das an vier Wochenenden im April in Klagenfurt stattfindet. Alle Details gibt es hier.",
          "answer": "f",
          "explanation": "Ein Wochenendseminar in Klagenfurt zeigt, wie man durch gezieltes Selbstmarketing beruflich aufsteigt ('Schulung zum Erfolg im Beruf')."
        },
        {
          "num": 3,
          "text": "Der Wiener Naschmarkt gehört zu Österreichs beliebtesten Märkten. Mit einer Fläche von mehr als zwei Hektar ist er der größte Markt in der Innenstadt. Schon 1780 handelten Bauern dort mit Milchprodukten. Gemauerte Marktstände entstanden erst mehr als 100 Jahre später. Von 1910 an wurden mehr als 120 fixe Marktstände im einheitlichen Stil von Otto Wagner geplant und errichtet. Das Marktamtsgebäude bei der Kettenbrückengasse wurde 1916 fertiggestellt. Heute ist der Naschmarkt eine begehrte Wiener Sehenswürdigkeit. Bei Schönwetter zählt der Markt mehr als 65.000 Personen pro Woche, viele davon Touristen. Ein Teil der Marktfläche ist für Gastronomiebetriebe reserviert. Nun erzählt ein neuer Reiseführer die Geschichte des Naschmarktes, reich illustriert mit alten Aufnahmen. Ein Kapitel behandelt auch die berühmten Wienzeilenhäuser Otto Wagners, die sich an der Linken Wienzeile im Bereich des Naschmarktes befinden. Dazu gibt es Einkaufstipps und Beschreibungen der Lokale. „Der Markt am Wienfluss“, Hrsg. Hannes Ortner, 35 Seiten, 17 Euro.",
          "answer": "j",
          "explanation": "Der Text und der vorgestellte Reiseführer liefern Geschichte, Fakten und Tipps rund um den Wiener Naschmarkt ('Wissenswertes über Wiens größten innerstädtischen Markt')."
        },
        {
          "num": 4,
          "text": "Wer bloggt, zeigt neben Fachkompetenz auch Kreativität. Das schätzen auch Arbeitgeber. Ob man über fachliche Fragestellungen schreibt oder einfach nur über das Leben – das Themenspektrum von Blogs ist riesig. Genauso vielfältig sind auch die Möglichkeiten, die sie Bewerberinnen und Bewerbern bieten. Wer einen Blog professionell betreibt, kann seine fachlichen Kompetenzen präsentieren und gleichzeitig seinen Ideenreichtum unter Beweis stellen. Doch auch die Darstellung eines Hobbys zeigt, dass der Bewerber aktiv und kreativ ist. Experten raten daher Bloggerinnen und Bloggern, in ihren Bewerbungsunterlagen gezielt darauf hinzuweisen. Doch Achtung: Ein Blog kann Bewerber auch in einem schlechten Licht erscheinen lassen. Bloggen während der Arbeitszeit und das Schreiben über Firmeninterna sind natürlich tabu.",
          "answer": "e",
          "explanation": "Ein professionell geführter Blog im Internet zeigt Fachkompetenz und Kreativität und kann bei Bewerbungen die Karriere fördern ('Schreiben im Internet für die Karriere')."
        },
        {
          "num": 5,
          "text": "Bis Herbst soll ein neues Marktkonzept für den altehrwürdigen Salzburger Grünmarkt vorliegen. Damit der Markt für Besucherinnen und Besucher wieder attraktiver wird, setzt die zuständige Stelle im Magistrat auf Nachhaltigkeit. Biologische Lebensmittel aus nachhaltiger Produktion, im Idealfall aus der Region, sollen den Markt wieder zu einem Fixpunkt in der Altstadt werden lassen. Der für Märkte, Stadtnatur und Lebensqualität zuständige Vizebürgermeister hofft, dass der Markt dazu beitragen kann, ein positives Lebensgefühl zu vermitteln. Obwohl die Stadt die Verkaufsstände vor einigen Jahren aufwändig hatte restaurieren lassen, verzeichneten die Händler zuletzt einen deutlichen Rückgang an Kundschaft. Zudem haben einige von ihnen altersbedingt ihre Verkaufsstände aufgegeben. In diesem Zusammenhang wurde auch die beliebte Foodbloggerin Jasmin May engagiert. Sie soll dazu beitragen, das Konzept in der Öffentlichkeit bekannter zu machen. Wir werden das Projekt weiterverfolgen und von seinem Fortgang berichten.",
          "answer": "a",
          "explanation": "Mit einem neuen Nachhaltigkeitskonzept soll der altehrwürdige Salzburger Grünmarkt wiederbelebt werden ('Erneuerungskur für einen alten Markt')."
        }
      ]
    },
    {
      "id": "19",
      "title": "Test 19 – Licht, Stadt & Landleben",
      "isVariant": false,
      "headings": {
        "a": "Der Wald als neues Zuhause",
        "b": "Die Auswirkungen künstlichen Lichts",
        "c": "Landbewohner fordern besseren öffentlichen Nahverkehr",
        "d": "Plötzlich geht das Licht aus – was tun bei Stromausfall?",
        "e": "Stadtbewohner entdecken das Landleben",
        "f": "Stadtbewohner leben umweltfreundlicher",
        "g": "Trend: Großstädter machen Urlaub im Wald",
        "h": "Warum Licht für unser Wohlbefinden wichtig ist",
        "i": "Was tun, wenn es Nacht wird? Lichtquellen vergangener Zeiten",
        "j": "Wohnungsnot in Metropolen"
      },
      "items": [
        {
          "num": 1,
          "text": "Heute machen die elektrische Beleuchtung in Wohnhäusern, Straßenlaternen, Ampeln, Neonreklame und Scheinwerferlicht draußen die Nacht fast zum Tag. Vor der Erfindung der Elektrizität war das anders. Der Arbeitsalltag der Menschen wurde von den Jahreszeiten und vom Tageslicht bestimmt. Gearbeitet wurde von Sonnenaufgang bis Sonnenuntergang. Danach war Beleuchtung nur mit anderen Hilfsmitteln wie z. B. Feuer, Kerzen und Petroleum möglich. Das Museum für Dorfkultur in Weinheim zeigt in einer Sonderausstellung, wie sich das Landleben früher nach Einbruch der Dunkelheit abspielte. Man erfährt zum Beispiel, wie man vor Erfindung des Streichholzes Feuer entfachte. Es geht um die Bedeutung der Kerzen im bäuerlichen Leben und darum, welche weitreichenden Umbrüche die Erfindung der Gasbeleuchtung und des elektrischen Lichts mit sich brachte.",
          "answer": "i",
          "explanation": "Eine Sonderausstellung in Weinheim zeigt, wie Menschen früher mit Feuer, Kerzen, Petroleum und Gaslicht die Dunkelheit erhellten ('Was tun, wenn es Nacht wird? Lichtquellen vergangener Zeiten')."
        },
        {
          "num": 2,
          "text": "Jahrelang zog es vor allem junge Berufstätige in die Großstädte, denn diese sind attraktiv, bieten umfangreiche Einkaufsmöglichkeiten und einen gut ausgebauten öffentlichen Nahverkehr. Doch seit einiger Zeit beobachten Forscher eine gegenläufige Bewegung: Immer mehr Menschen kehren den Metropolen den Rücken und lassen sich im Umland nieder – wegen der Ruhe und der günstigeren Preise. Die Städte, die immer teurer werden, die Freiräume, die der ländliche Raum bietet, sowie die neuen Formen des digitalen Arbeitens begünstigen die Stadtflucht. „Unter den neuen Landbewohnern finden sich einerseits Berufstätige, die ortsunabhängig arbeiten können, wie Programmierer, Journalisten oder Grafikdesigner, andererseits aber zum Beispiel auch Lehrer, Ärzte und Handwerker“, heißt es in der Studie. Die Wissenschaftler sprechen schon von einer Trendwende, die sich vor allem in den Ballungszentren Berlin, Hamburg, München, Frankfurt und Stuttgart abzeichnet.",
          "answer": "e",
          "explanation": "Immer mehr Großstädter ziehen wegen der Ruhe, der Freiräume und günstigerer Preise aufs Land ('Stadtbewohner entdecken das Landleben')."
        },
        {
          "num": 3,
          "text": "Satellitenbilder der Erde bei Nacht zeigen ein strahlendes Lichtermeer, das sich fast durchgehend über den Globus erstreckt. Seit der Erfindung der Glühbirne steht Licht für Wohlstand und Fortschritt. Die Städte sind nachts hell erleuchtet – nicht immer jedoch zum Wohle von Mensch und Umwelt: Denn zu viel Licht hat Folgen für Menschen und Tiere. An Straßenlaternen verenden jede Nacht Milliarden von Insekten, Zugvögel verlieren die Orientierung, und selbst der Mensch wird durch das Kunstlicht um einen gesunden Schlaf gebracht. Wissenschaftler sprechen bereits von einer massiven Lichtverschmutzung. Weltweit gehen Forscher jetzt der Frage nach, wie sich die Lichtflut auf ein gesundes Maß reduzieren lässt. Dabei arbeiten Physiker, Biologen, Mediziner und Ingenieure an der Beleuchtung der Zukunft – an einem Licht, das weder Energie verschwendet noch unnötig den Nachthimmel erhellt, keine Insekten verenden und durch besondere Farbspektren auch den Menschen unbehelligt schlafen lässt. Denn es geht nicht darum, die Städte völlig dunkel zu machen. Es geht darum, sie nachhaltiger und intelligenter zu beleuchten.",
          "answer": "b",
          "explanation": "Nächtliche Lichtverschmutzung schadet Insekten, Zugvögeln und dem menschlichen Schlaf ('Die Auswirkungen künstlichen Lichts')."
        },
        {
          "num": 4,
          "text": "Vor zehn Jahren lebten Dirk und Antje Sebens noch in Mannheim, mitten in der Stadt. Dann kauften sie sich ein altes Forsthaus im Wald. Sie hatten es zufällig entdeckt, denn eigentlich hatten sie nur einen ruhigen Ort gesucht, um am Wochenende dem Stadtleben entfliehen zu können. Doch sie waren sofort von dem Haus begeistert; dass es dort weder Strom noch fließendes Wasser gab, schreckte sie nicht ab. Heute versuchen die beiden, so autark wie möglich zu leben: Die Solaranlage auf dem Dach liefert Strom, eigenes Holz die Wärme, der Brunnen vor dem Haus das Wasser. Im Sommer bauen Dirk und Antje Sebens Gemüse an, das sie für den Winter einwecken. Das nächste Dorf ist mehrere Kilometer entfernt und außer Besuchern verirrt sich höchstens mal ein Wanderer zu ihnen. „Die absolute Dunkelheit draußen in der Nacht war am Anfang sehr ungewohnt“, erzählt Antje Sebens. Denn elektrische Straßenlaternen wie in der Stadt gibt es im Wald natürlich nicht. Bereut haben die beiden ihre Entscheidung nie. Noch immer empfinden sie es als großes Abenteuer, mitten in der Natur zu sein und auf viele Annehmlichkeiten zu verzichten.",
          "answer": "a",
          "explanation": "Dirk und Antje Sebens sind aus der Stadt Mannheim in ein altes Forsthaus mitten im Wald gezogen und leben dort autark ('Der Wald als neues Zuhause')."
        },
        {
          "num": 5,
          "text": "Wer verbringt nicht gerne sein Wochenende fernab der Stadt? Im Grünen, wo es noch Wiesen und Schmetterlinge gibt und weder Staus noch Lärm. Viele zieht es gleich ganz aufs Land. Doch dort braucht man meist ein Auto. Wer nicht im Home-Office arbeiten kann, wird zum Pendler. Hinzu kommt, dass es in vielen Dörfern kaum noch Einkaufsmöglichkeiten oder Schulen gibt und die Bewohner durch den schwachen öffentlichen Nahverkehr in ländlichen Regionen nicht ohne PKW auskommen können. Forscher haben errechnet, dass wir bis zu 87 Prozent der Emissionen aus unserer Alltagsmobilität einsparen können, wenn wir in verkehrstechnisch günstiger Lage wohnen, also am besten in der Stadt mit Einkaufsmöglichkeiten vor der Tür. Auch das Argument, das Wohnen auf dem Land sei günstiger, überzeugt immer weniger. Zwar waren dort früher Mieten und Baugrund vergleichsweise erschwinglich, doch wird heute das Preisgefälle zwischen Stadt und Land immer flacher. Das Ergebnis könnte ernüchternd sein und das Leben in der Stadt attraktiver machen.",
          "answer": "f",
          "explanation": "Wer in der Stadt mit kurzen Wegen und öffentlichem Nahverkehr wohnt, spart bis zu 87 % der Mobilitätsemissionen gegenüber dem Landleben mit Auto ('Stadtbewohner leben umweltfreundlicher')."
        }
      ]
    },
    {
      "id": "20",
      "title": "Test 20 – Spielzeug, Bücher & Brettspiele",
      "isVariant": false,
      "headings": {
        "a": "Alte Spiele stärken das Miteinander",
        "b": "Dinge zum Anfassen bleiben beliebt",
        "c": "Je mehr Spielsachen, desto größer die Kreativität",
        "d": "Kleine Züge mit langer Geschichte",
        "e": "Massenfertigung von Kuscheltieren",
        "f": "Naturgetreue Handarbeit für das Kinderzimmer",
        "g": "Technik-Spielzeug von früher wieder im Handel",
        "h": "Überfluss im Kinderzimmer",
        "i": "Viele Computerspiele kommen schnell aus der Mode",
        "j": "Warum sich Leser von Büchern abwenden"
      },
      "items": [
        {
          "num": 1,
          "text": "Die erste Kösener Puppenfabrik wurde 1912 von Käthe Kruse gegründet. 80 Jahre später übernahm der Unternehmer Helmut Schache die traditionsreiche Spielzeugmanufaktur in Sachsen-Anhalt, seitdem wird sie von seiner Familie geführt. Dort werden noch wie früher Plüschtiere einzeln angefertigt, rund 80.000 jährlich, von der kleinen Maus bis zum 1,65 Meter großen Bären. „Wir machen keine niedlichen Plüschtiere. Wir versuchen die Tiere so zu gestalten, wie sie in ihrer Umwelt sind“, erklärt Helmut Schache. Die Plüschtiere entstehen nicht in Fließbandproduktion, sondern werden einzeln zusammengenäht, manche aus über 100 Teilen. Nur so gelingt es, die charakteristischen Merkmale der Tiere authentisch abzubilden. Jedem Entwurf gehen ausführliche anatomische Beobachtungen und Studien in der Natur und im Zoo voraus. Dann erst folgen Skizzen und erste Modelle aus Ton. 15 bis 20 neue Tiere bringt die Kösener Spielzeugmanufaktur jedes Jahr auf den Markt. Verkauft werden sie in 25 Ländern.",
          "answer": "f",
          "explanation": "In der Kösener Spielzeugmanufaktur werden Plüschtiere nach Naturstudien einzeln von Hand authentisch zusammengenäht ('Naturgetreue Handarbeit für das Kinderzimmer')."
        },
        {
          "num": 2,
          "text": "Die Modelleisenbahn hat auch im Computerzeitalter ihre Anziehungskraft nicht verloren. Bis heute bringt sie die Augen von großen und kleinen Eisenbahnfans zum Leuchten. Doch ihre ersten Erfolge feierte sie schon vor langer Zeit: 1891 rollte die erste Uhrwerkeisenbahn zum Aufziehen über die Gleise, und mit ihr begann der Aufstieg der Firma Märklin zum führenden Hersteller von Spielzeugeisenbahnen. Damals brachte die beginnende Industrialisierung mit ihren neuen Technologien auch für die Spielzeugherstellung neue Impulse. Dampfmaschinen im Kleinformat und funktionierende Kinder-Kochherde hielten Einzug in die Kinderstuben. 1895 brachte Märklin die erste dampfbetriebene Spielzeugeisenbahn auf den Markt. Einige Jahre später entwickelte man daraus die elektrische Modelleisenbahn, wie sie noch immer zu kaufen ist. Diese faszinierte Generationen technikbegeisterter Fans und wurde zum Sammelobjekt. Gewiss werden die Miniatureisenbahnen noch lange durch Kinderzimmer und Hobbykeller rattern.",
          "answer": "d",
          "explanation": "Der Text schildert die traditionsreiche Entwicklung der Märklin-Modelleisenbahn seit 1891 ('Kleine Züge mit langer Geschichte')."
        },
        {
          "num": 3,
          "text": "Gedruckten Büchern wurde vor einigen Jahren von Experten ein schnelles Ende vorausgesagt. Das papierlose Lesen sei die Zukunft, hieß es. Höchstens als Nischenprodukt könnten Bücher noch existieren. Doch schon wenig später stiegen deren Verkaufszahlen überraschend an. Vieles deutet darauf hin, dass sich Sachen, die man selbst in die Hand nehmen kann, doch nicht so leicht von digitalen Inhalten verdrängen lassen. Zum Beispiel sind Papierkalender nicht aus den Geschäften verschwunden und die Schallplatte findet trotz der Verbreitung von Streaming-Angeboten viele Käufer. Zukunftsforscher erkennen darin sogar einen Trend, nämlich eine Gegenbewegung zur Digitalisierung. Dafür gibt es natürlich Gründe: „Wer will schon nur Passwörter, PINs, Speicherplatz und Kontaktdaten besitzen? Alte Bücher, Hörspielkassetten oder Fotoalben wecken dagegen Gefühle“, erklärt der Konsumforscher Peter Riefenberg. Nimmt man das Taschenbuch in die Hand, das man am Strand gelesen hat, fühlt man sich gleich wieder in den Sommerurlaub zurückversetzt. Gegenstände wecken also Erinnerungen – das werden sie digitalen Produkten immer voraushaben.",
          "answer": "b",
          "explanation": "Gedruckte Bücher, Papierkalender und Schallplatten erfreuen sich trotz Digitalisierung großer Beliebtheit, weil physische Gegenstände Gefühle und Erinnerungen wecken ('Dinge zum Anfassen bleiben beliebt')."
        },
        {
          "num": 4,
          "text": "Immer neue Spielekonsolen, Spielformate und Apps drängen auf den elektronischen Spielemarkt und dennoch haben Brettspiele nie an Bedeutung verloren. Die Hersteller vermelden sogar Jahr für Jahr steigende Umsätze. Was aber macht den Zauber des klassischen analogen Brettspiels aus? Wer selbst sein Glück am Würfelbecher versucht, kommt dem Geheimnis schnell auf die Spur: Beim gemeinsamen Spiel genießen die Mitspieler besondere Momente der Zusammengehörigkeit. „Bei solchen Spielen steht das gemeinsame Erlebnis im Vordergrund: Familie und Freunde kommen an einem Tisch zusammen“, erklärt Stefan Wiese, Geschäftsführer des Naumburger Spieleverlags. „Das gute Brettspiel von früher wird auch in Zukunft Anhänger haben. Nach einer gemeinsamen Spielrunde stehen meist alle mit einem Lächeln vom Tisch auf“, ergänzt er. Das Spielen in analogen statt digitalen Welten steigert also Zufriedenheit und Gemeinschaftsgefühl.",
          "answer": "a",
          "explanation": "Klassische Brettspiele bringen Familie und Freunde an einem Tisch zusammen und fördern das Gemeinschaftsgefühl ('Alte Spiele stärken das Miteinander')."
        },
        {
          "num": 5,
          "text": "Jahr für Jahr steigt der Umsatz der Spielzeughersteller. Und das ist auch kein Wunder: Denn kaum etwas erfreut Eltern mehr als die leuchtenden Augen der Kinder, wenn sie ein neues Spielzeug bekommen. Und so sind die Schränke und Spielzeugkisten der lieben Kleinen voll mit Puppen, Kuscheltieren und Autos. Doch das hat auch unerwünschte Folgen: „Wenn ein Kind zu viel Spielzeug hat, wird sich seine Phantasie nicht weiterentwickeln“, warnt Spielforscher Jens Junge. Deshalb verzichten manche Kindergärten auf überflüssiges Spielzeug. Im Berliner Musikkindergarten zum Beispiel quillt kaum ein Regal über – und trotzdem wird den Kindern hier nie langweilig. Es gibt Musikinstrumente, Bastelmaterialien und auch Spielzeug – aber nie zu viel, sodass die Kinder nicht überfordert sind. Es komme für die Kinder gar nicht so sehr darauf an, womit sie spielen, sondern vor allem mit wem, betont Mitarbeiterin Lara Schwarz. Das gemeinsame Spielen mit Freunden sei für Kinder sowieso am wichtigsten.",
          "answer": "h",
          "explanation": "Übervolle Spielzeugkisten in Kinderzimmern überfordern Kinder und hemmen laut Spielforschern ihre Fantasie ('Überfluss im Kinderzimmer')."
        }
      ]
    },
    {
      "id": "21",
      "title": "Test 21 – Löwen & Tierschutz (Rekonstruktion)",
      "isVariant": false,
      "headings": {
        "a": "Die Löwen sind sehr beliebt unter den Besuchern",
        "b": "Mehr Bemühungen für den Tierschutz",
        "c": "Löwen als Zeichen für den Mangel an Touristen",
        "d": "Löwen als Haustier",
        "e": "Planung für den Tierschutz",
        "f": "Schließung eines Schutzgebiets durch die Regierung",
        "g": "Ausbildung von Menschen im Umgang mit Tieren",
        "h": "Raubtiere in freier Wildbahn beobachten",
        "i": "Verbot der Haltung exotischer Tiere in Europa",
        "j": "Rückgang der Besucherzahlen im Berliner Zoo"
      },
      "items": [
        {
          "num": 1,
          "text": "Berlin hat einen berühmten Zoo. Der Text berichtet, dass zahlreiche Besucher in den großen Tierpark von Berlin kommen, um dort die Tiere zu beobachten – ganz besonders beliebt bei den Besuchern sind dabei die Löwen.",
          "answer": "a",
          "explanation": "Im Berliner Zoo ziehen vor allem die Löwen zahlreiche Besucher an ('Die Löwen sind sehr beliebt unter den Besuchern')."
        },
        {
          "num": 2,
          "text": "In Südafrika hatten die Menschen große Angst vor den Löwen und haben deshalb angefangen, sie zu töten. Aus diesem Grund hat die Regierung beschlossen, spezielle Reservate und Schutzgebiete zum Schutz der Löwen vor dem Aussterben zu errichten.",
          "answer": "b",
          "explanation": "Um die Löwen in Südafrika vor dem Aussterben zu bewahren, richtet die Regierung Schutzgebiete ein ('Mehr Bemühungen für den Tierschutz')."
        },
        {
          "num": 3,
          "text": "In den USA gab es einen Zoo, in dem das Interesse an den Löwen eine besondere Bedeutung für die Anziehung von Touristen hatte. Als die Besucherzahlen einbrachen, zeigte sich an den Löwen der Mangel an Touristen.",
          "answer": "c",
          "explanation": "In einem US-amerikanischen Zoo standen die Löwen im Zusammenhang mit dem Interesse bzw. dem Ausbleiben von Touristen ('Löwen als Zeichen für den Mangel an Touristen')."
        },
        {
          "num": 4,
          "text": "Reiche Familien in Asien wünschen sich meistens etwas Besonderes. Sie haben die Tendenz, exotische Tiere zu züchten und privat zu halten. In ihren Palästen und Gärten leben Raubtiere wie Löwen und Leoparden als Statussymbol.",
          "answer": "d",
          "explanation": "Wohlhabende Familien in Asien halten in ihren Palästen exotische Raubtiere wie Löwen und Leoparden ('Löwen als Haustier')."
        },
        {
          "num": 5,
          "text": "Eine Tierschutzorganisation ruft zu einer Sitzung zusammen. Es geht um die Planung und Schaffung spezieller Schutzgebiete für die Tiere. Außerdem wird ein neues Konzept für den Umgang mit Tieren sowie die Ausbildung von Menschen im Umgang mit Wildtieren vorgestellt.",
          "answer": "e",
          "explanation": "Bei der Sitzung einer Tierschutzorganisation werden spezielle Gebiete und Konzepte für den Umgang mit Tieren geplant ('Planung für den Tierschutz')."
        }
      ]
    },
    {
      "id": "22",
      "title": "Test 22 – Kaffee, Klöster & historische Städte",
      "isVariant": false,
      "headings": {
        "a": "Altes Handwerk und alte Technik anschaulich präsentiert",
        "b": "Attraktive Kleinstadt – touristischer Geheimtipp",
        "c": "Ein altes Kloster als Feuerwache",
        "d": "Eine Universität mit langer Geschichte",
        "e": "Eliteschule für Schriftsteller",
        "f": "Entdeckung und Verbreitung des Kaffees",
        "g": "Kaffee macht die Leute süß",
        "h": "Klösterliche Strenge für berühmte Schüler",
        "i": "Mehr Ziegenmilch dank Energy-Drink",
        "j": "Ohne Kaffee geht hier nichts"
      },
      "items": [
        {
          "num": 1,
          "text": "Das erste Kaffeehaus in Leipzig, „Zum Arabischen Coffe Baum“, öffnete 1685 seine Pforten. Seitdem ist der Kaffee in Sachsen zum beliebten Getränk geworden, das weder zu Hause auf Partys und Feiern noch beim Ausgehen fehlen darf. „Kaffeesachsen“ wurden früher die Bewohner des Landes zwischen Leipzig und polnischer Grenze auch deswegen scherzhaft von den anderen Deutschen genannt. Bevorzugt wird der Kaffee heiß und süß getrunken. Süße Ergänzungen wie Dresdner Stollen oder Leipziger Lerchen, beides traditionell gebackene Kuchenspezialitäten, gehören zum Kaffee wie das Tüpfelchen zum „i“. Dabei wird das Gebäck auf echt sächsische Art „geditscht“, das heißt: Es wird in den Kaffee getunkt, bevor es gegessen wird. Die Sachsen schwören darauf, dass sowohl das Gebäck als auch der Kaffee so und nur so ihr volles Aroma entfalten. Wer es selbst ausprobieren möchte: Zahlreiche Kaffeehäuser laden in allen größeren und kleineren Städten Sachsens dazu ein, dies auszuprobieren.",
          "answer": "j",
          "explanation": "In Sachsen („Kaffeesachsen“) ist Kaffee seit 1685 das liebste Getränk, das bei keiner Gelegenheit fehlen darf ('Ohne Kaffee geht hier nichts')."
        },
        {
          "num": 2,
          "text": "Eppingen liegt etwa auf halbem Weg zwischen Karlsruhe und Heilbronn im Kraichgau, einer geschichtsträchtigen Region mit wunderschöner Landschaft und bodenständiger Kultur, die von Erholung suchenden Menschenmassen noch nicht überrollt ist. Die Altstadt des Städtchens ist ein einziges Museum: Über 100 Fachwerkhäuser mit ihrem romantisch anmutenden Muster aus braunen Holzbalken und weiß getünchtem Lehm können hier bewundert werden. Die bekanntesten davon sind das „Baumannsche Haus“ (erbaut 1582), heute ein Hotel, und die „Alte Universität“, heute ein Museum. Hier befand sich 1564/1565 die Heidelberger Universität, die, als in Heidelberg die Pest wütete, hierhin ausgelagert wurde. Im heutigen Museum kann man die Fachwerkbaukunst studieren. Seit 1993 findet im Juli und August der „Carillonsommer“ statt. Dann geben international bekannte Orgelinterpreten Glockenspielkonzerte, die vom achteckigen Turm der Stadtpfarrkirche erklingen. Eine lange Tradition in Eppingen hat die Bierbrauerei. Das hier gebraute „Palmbräu“-Bier kann an Ort und Stelle in der Brauereigaststätte probiert werden. Eppingen ist auch Ausgangspunkt zahlreicher Wanderwege, auf denen der Kraichgau zu Fuß erkundet werden kann.",
          "answer": "b",
          "explanation": "Die Fachwerkstadt Eppingen im Kraichgau bietet viel Kultur und Natur, ohne von Touristenmassen überlaufen zu sein ('Attraktive Kleinstadt – touristischer Geheimtipp')."
        },
        {
          "num": 3,
          "text": "Das Kloster Maulbronn wurde 1147 von Zisterziensermönchen gegründet. Man sagt, ein Maulesel, den die Mönche auf ihren Wanderungen mitgeführt hatten, solle hier einen Brunnen gefunden haben und man habe daraufhin beschlossen, an dieser Stelle das Kloster zu bauen. Im 16. Jahrhundert wurde es im Verlauf der Reformation säkularisiert und zum Internat umfunktioniert. Heute von der UNESCO zum Weltkulturerbe der Menschheit erhoben, ist das Kloster ein Touristenmagnet. Selbst vom berüchtigten Doktor Faust wird erzählt, er sei einmal dort gewesen. Das Kloster soll einmal kein Geld mehr gehabt haben, und der sonst gottesfürchtige Abt habe geglaubt, mit Hilfe des Doktor Faust und dessen Zauberkünsten wieder zu Geld zu kommen. Maulbronn war besonders wegen seiner Klosterschule bekannt, die von namhaften Persönlichkeiten besucht wurde: Johannes Kepler lernte hier Latein und Mathematik, der Schriftsteller Hermann Hesse litt bekanntlich sehr unter der eisernen Disziplin und Härte, die hier nach seiner Meinung vorherrschte. Hermann Hesse hat die Klosteranlage später in seinen Romanen „Unterm Rad“ und „Narziß und Goldmund“ zum Schauplatz gemacht.",
          "answer": "h",
          "explanation": "Die Klosterschule Maulbronn wurde von berühmten Schülern wie Johannes Kepler und Hermann Hesse besucht, der unter der dortigen eisernen Disziplin litt ('Klösterliche Strenge für berühmte Schüler')."
        },
        {
          "num": 4,
          "text": "Auf einer Anhöhe oberhalb des Bodensees liegt, ca. 10 km vom See entfernt in idyllischer ländlicher Umgebung, das ehemalige Zisterzienserkloster Salem. Innerhalb der weitläufigen Klosteranlage aus dem 12. Jahrhundert befinden sich heute mehrere Museen und das gotische Münster. Im Feuerwehrmuseum findet der interessierte Besucher alte Feuerwehrwagen, die noch von Pferden gezogen wurden, alte Geräte, Spritzen und Pumpen sowie mehrere Modellanlagen. Im Weinbaumuseum bekommt man einen Überblick über die Weinproduktion der Bodenseeregion. Hier können regionale Weine probiert und auch gekauft werden. In den angrenzenden Gebäuden kann man zuschauen, wie – noch in Handarbeit – Musikinstrumente gebaut werden, Glas geblasen oder Goldschmuck hergestellt wird. Ein kleiner, aber feiner Park lädt zum Ausruhen und Verweilen ein. International bekannt ist jedoch das von Kurt Hahn und dem Prinzen Max von Baden 1920 gegründete Internat Salem, das von den Söhnen und Töchtern bekannter Familien aus ganz Europa besucht wurde und wird: Der erste deutsche Bundespräsident Theodor Heuss ging hier ebenso zur Schule wie der Ehemann der britischen Königin Elisabeth II., Prinz Philipp.",
          "answer": "a",
          "explanation": "Im Kloster Salem sind historische Feuerwehrwagen, Geräte und traditionelles Handwerk wie Glasblasen, Instrumentenbau und Goldschmiedekunst zu sehen ('Altes Handwerk und alte Technik anschaulich präsentiert')."
        },
        {
          "num": 5,
          "text": "Vermutlich vor fast 900 Jahren, irgendwann im dreizehnten Jahrhundert, sollen die Menschen herausgefunden haben, was es mit dem Kaffee auf sich hat. Eine Legende erzählt von einem jemenitischen Ziegenhirten, dessen Ziegen sich nach dem Genuss der roten Beeren eines bestimmten Strauches merkwürdig lebendig und aufgedreht benommen haben sollen. Im Dorf habe der Dorfgelehrte dann herausgefunden, dass die Früchte, die bisher nur den Ziegen zu viel „Energie“ verholfen hatten, auch beim Menschen ihre Wirkung zeigten. Nach mehreren Experimenten habe man dann herausgefunden, dass die Beeren, wenn man sie trocknet und dann mit heißem Wasser aufkocht, am besten schmecken. Der Kaffee war erfunden. Wegen seiner berauschenden Wirkung, so eine Theorie, soll das Getränk dann arabisch „qahwa“ genannt worden sein, was auch einen Wein bezeichnen konnte. Nach einer anderen Theorie stammt der Kaffee aus der Region „Kaffa“ im südwestlichen Äthiopien. Von hier aus nahm jedenfalls sein Siegeszug über die ganze Welt seinen Ausgang. 1582 erreichte der Kaffee schließlich Europa, wo er bis heute zu einem der beliebtesten Getränke wurde.",
          "answer": "f",
          "explanation": "Der Text erzählt die Ursprungslegenden des Kaffees im Jemen bzw. in Äthiopien und seinen weltweiten Siegeszug bis nach Europa ('Entdeckung und Verbreitung des Kaffees')."
        }
      ]
    },
    {
      "id": "23",
      "title": "Test 23 – Nachthimmel & Fotografie",
      "isVariant": false,
      "headings": {
        "a": "Bilder einer bedeutenden Künstlerin",
        "b": "Das Ende der Dunkelheit",
        "c": "Die bemerkenswerte Karriere eines Fotografen",
        "d": "Ein Fotograf auf Reisen",
        "e": "Eine Fotografin dreht einen Film",
        "f": "Entwicklungsgeschichte der Lampen",
        "g": "Erde, Mond und Sterne – wie man sie noch nie gesehen hat",
        "h": "Familienfotos berühmter Persönlichkeiten",
        "i": "Gelungene Einführung in die moderne Fotografie",
        "j": "Mit Profis eine neue Foto-Technik erlernen"
      },
      "items": [
        {
          "num": 1,
          "text": "Der Buchtitel erinnert an eine Horrorgeschichte: „Die Nacht“. Aber dem Autor Paul Bogard geht es nicht um Fantasiewelten, sondern um sehr reale Dinge. Das Thema des Autors ist die nächtliche Finsternis. Wer erlebt noch eine dunkle Nacht? Großstadtbewohner eher nicht, außer im abgedunkelten Schlafzimmer. Ein natürlicher Nachthimmel mit unzähligen Sternen ist die Ausnahme, deshalb sind wir überwältigt, wenn wir ihn doch einmal zu sehen bekommen. Das war früher anders, und zwar bis Gaslicht und Glühlampe erfunden wurden. Heute sieht man in Städten gerade noch den Mond und, wenn man Glück hat, eine Handvoll der hellsten Sterne. Paul Bogard erläutert, warum künstliches Licht so weit verbreitet ist, und betrachtet dies sehr kritisch. Der Autor fesselt seine Leser dabei mit beachtlichem Fachwissen. Außerdem ist er weit gereist. Überall, so berichtet er, gebe es Organisationen, die sich für eine Reduzierung des künstlichen Lichts einsetzen – auch in Deutschland. Paul Bogard fände es positiv, wenn die Organisationen sich durchsetzen könnten. Denn der Autor – und das macht er sehr deutlich – hält nicht viel davon, dass es heute kaum noch völlig dunkel ist.",
          "answer": "b",
          "explanation": "Paul Bogards Buch „Die Nacht“ setzt sich kritisch damit auseinander, dass es durch künstliches Licht heute kaum noch echte nächtliche Dunkelheit gibt ('Das Ende der Dunkelheit')."
        },
        {
          "num": 2,
          "text": "Fotos machen ist heute nicht schwer. Schnell nimmt man das Handy und macht einen Schnappschuss. Wer aber besondere und eindrucksvolle Bilder haben möchte, muss sich mit dem Thema Fotografie schon etwas intensiver befassen. Dietmar Spehrs neuer Fotografie-Ratgeber ist dabei ein gutes Hilfsmittel. Auf 424 Seiten erklärt der Autor und Journalist mit einfachen, aber kompetenten Worten, was zu beachten ist. Der Ratgeber versteht sich als Fotokurs für Ein- und Aufsteiger und richtet sich an die vielen Menschen, die gerne fotografieren, aber wenig Fachwissen haben. Diesen Hobbyfotografen vermittelt das Buch sehr verständlich Schritt für Schritt solides Basiswissen. Spehr setzt dabei auf Beispielbilder, Tabellen und Grafiken und schreibt so wenig wie möglich, aber so viel wie nötig. Das sorgt dafür, dass der Ratgeber sehr unterhaltsam zu lesen ist und nicht wie ein langweiliges Lehrbuch daherkommt. Von der Auswahl des Motivs über die richtige Kameraeinstellung bis hin zur optimierenden Nachbearbeitung am Computer wird alles Wissenswerte vermittelt.",
          "answer": "i",
          "explanation": "Dietmar Spehrs neuer Ratgeber vermittelt Hobbyfotografen verständlich und unterhaltsam solides Basiswissen zur digitalen Fotografie ('Gelungene Einführung in die moderne Fotografie')."
        },
        {
          "num": 3,
          "text": "Bilder der Fotografin Annie Leibovitz sind ab kommendem Samstag im Kunsthaus Wien zu sehen. Die Ausstellung besticht durch ihre umfangreiche Bildauswahl. Zum einen kann man zahlreiche Porträts berühmter Schauspieler, Politiker oder Musiker bestaunen. Zum anderen sieht man Bilder aus dem privaten Fotoalbum der Künstlerin. Die zum Teil sehr persönlichen Aufnahmen dokumentieren ihr Leben und zeigen bisher unveröffentlichte Werke, die zum Teil sehr bedrückend sind. Bilder ihres Vaters berühren den Besucher und oftmals ist man von der Offenheit der Fotografin überrascht. Zwischen Aufnahmen der Fotografin selbst stehen zahlreiche Porträts ihrer Eltern und Urlaubsfotos der Familie. Die bunte Mischung von großformatigen und kleinformatigen Bildern sorgt für Abwechslung. Um die Fotografien besser kennenzulernen, können Besucher einen ca. 1,5 Stunden langen Film über die Karriere von Annie Leibovitz sehen. Eines ist nach der Ausstellung und dem Film klar: Annie Leibovitz zählt zu den bedeutendsten Fotografinnen des 20. und beginnenden 21. Jahrhunderts.",
          "answer": "a",
          "explanation": "Das Kunsthaus Wien zeigt eine große Ausstellung mit Porträts und privaten Aufnahmen der berühmten Fotografin Annie Leibovitz ('Bilder einer bedeutenden Künstlerin')."
        },
        {
          "num": 4,
          "text": "Die Abkürzung TWAN klingt nach einem neuen Computerprogramm, aber tatsächlich steht sie für eine neue fotografische Methode, die der Iraner Babak Amin Tafreshi entwickelt hat. Diese neue Methode führt zu atemberaubenden Ergebnissen: Noch nie hat man die Sterne so eindrucksvoll über den Landschaften der Erde gesehen wie auf den Bildern in diesem Buch – ein Genuss für die Augen. Was man auf den 160 Seiten des Buches sieht, ist meines Wissens ohne Beispiel. Viele der gezeigten Orte und Landschaften sind bekannte Motive, hier aber wirken sie doch vollkommen anders, als man sie kennt. Da sieht man Sterne über den Ruinen von Persepolis, den Mond über ungarischen Wäldern, die Milchstraße über dem kalifornischen Mammutbaum „General Grant“. Die drei Herausgeber Stefan Seip, Gernot Meiser und Babak A. Tafreshi wurden unterstützt von einem weltweiten Team erfahrener Naturfotografen. Auf den letzten Seiten des Buchs erfährt man auch, dass „Fotografieren im TWAN-Stil heißt, bei fortgeschrittener Dämmerung oder Dunkelheit Aufnahmen zu machen, auch wenn man selbst nicht mehr viel sehen kann“. Neben aller Technik kommt es aber auf den künstlerischen Blick des Fotografen an – und viel Geduld.",
          "answer": "g",
          "explanation": "Ein neuer Bildband zeigt mithilfe der TWAN-Fototechnik noch nie dagewesene Aufnahmen von Sternen und Mond über bekannten Landschaften der Erde ('Erde, Mond und Sterne – wie man sie noch nie gesehen hat')."
        },
        {
          "num": 5,
          "text": "Er gehörte zu den ganz Großen seines Fachs: Andreas Feininger. Eine neue Biografie erzählt die Lebensgeschichte des weltberühmten Fotografen. Neben einem Text auf Deutsch und Englisch enthält sie auch eine kleine, aber gute Auswahl seiner Fotoarbeiten aus allen Schaffensphasen. Die Autoren zeigen den Weg des 1906 in Paris geborenen Fotografen von der Kindheit in Berlin über die Jahre in Weimar und Dessau bis hin zum Leben in Hamburg, Stockholm und schließlich New York, dessen Stadtansichten Feininger weltberühmt machten. Dabei hatte Feininger keineswegs das Ziel, Fotograf zu sein. Eigentlich war Andreas Feininger gelernter Architekt. Als Feininger mit seiner Frau 1933 nach Stockholm auswandert, findet er dort als Architekt keine Anstellung. So macht er aus der Not eine Tugend: Weil er die kleine Familie mit Sohn Thomas ernähren muss, macht er seine Leidenschaft, die Fotografie, zum Broterwerb. Den Durchbruch als weltweit anerkannter Fotograf schafft er schließlich in New York, wohin seine Familie 1939 auswandert.",
          "answer": "c",
          "explanation": "Eine neue Biografie schildert den ungewöhnlichen Werdegang von Andreas Feininger vom Architekten zum weltberühmten Fotografen in New York ('Die bemerkenswerte Karriere eines Fotografen')."
        }
      ]
    },
    {
      "id": "23a",
      "title": "Test 23a – Nachthimmel & Fotografie (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Bilder einer bedeutenden Künstlerin",
        "b": "Das Ende der Dunkelheit",
        "c": "Die bemerkenswerte Karriere eines Fotografen",
        "d": "Ein Fotograf auf Reisen",
        "e": "Eine Fotografin dreht einen Film",
        "f": "Entwicklungsgeschichte der Lampen",
        "g": "Erde, Mond und Sterne – wie man sie noch nie gesehen hat",
        "h": "Familienfotos berühmter Persönlichkeiten",
        "i": "Fotografie – wie, aber richtig: Einführung",
        "j": "Mit Profis eine neue Foto-Technik erlernen"
      },
      "items": [
        {
          "num": 1,
          "text": "Der Buchtitel erinnert an eine Horrorgeschichte: „Die Nacht“. Aber dem Autor Paul Bogard geht es nicht um Fantasiewelten, sondern um sehr reale Dinge. Das Thema des Autors ist die nächtliche Finsternis. Wer erlebt noch eine dunkle Nacht? Großstadtbewohner eher nicht, außer im abgedunkelten Schlafzimmer. Ein natürlicher Nachthimmel mit unzähligen Sternen ist die Ausnahme, deshalb sind wir überwältigt, wenn wir ihn doch einmal zu sehen bekommen. Das war früher anders, und zwar bis Gaslicht und Glühlampe erfunden wurden. Heute sieht man in Städten gerade noch den Mond und, wenn man Glück hat, eine Handvoll der hellsten Sterne. Paul Bogard erläutert, warum künstliches Licht so weit verbreitet ist, und betrachtet dies sehr kritisch. Der Autor fesselt seine Leser dabei mit beachtlichem Fachwissen. Außerdem ist er weit gereist. Überall, so berichtet er, gebe es Organisationen, die sich für eine Reduzierung des künstlichen Lichts einsetzen – auch in Deutschland. Paul Bogard fände es positiv, wenn die Organisationen sich durchsetzen könnten. Denn der Autor – und das macht er sehr deutlich – hält nicht viel davon, dass es heute kaum noch völlig dunkel ist.",
          "answer": "b",
          "explanation": "Paul Bogards Buch „Die Nacht“ setzt sich kritisch damit auseinander, dass es durch künstliches Licht heute kaum noch echte nächtliche Dunkelheit gibt ('Das Ende der Dunkelheit')."
        },
        {
          "num": 2,
          "text": "Fotos machen ist heute nicht schwer. Schnell nimmt man das Handy und macht einen Schnappschuss. Wer aber besondere und eindrucksvolle Bilder haben möchte, muss sich mit dem Thema Fotografie schon etwas intensiver befassen. Dietmar Spehrs neuer Fotografie-Ratgeber ist dabei ein gutes Hilfsmittel. Auf 424 Seiten erklärt der Autor und Journalist mit einfachen, aber kompetenten Worten, was zu beachten ist. Der Ratgeber versteht sich als Fotokurs für Ein- und Aufsteiger und richtet sich an die vielen Menschen, die gerne fotografieren, aber wenig Fachwissen haben. Diesen Hobbyfotografen vermittelt das Buch sehr verständlich Schritt für Schritt solides Basiswissen. Spehr setzt dabei auf Beispielbilder, Tabellen und Grafiken und schreibt so wenig wie möglich, aber so viel wie nötig. Das sorgt dafür, dass der Ratgeber sehr unterhaltsam zu lesen ist und nicht wie ein langweiliges Lehrbuch daherkommt. Von der Auswahl des Motivs über die richtige Kameraeinstellung bis hin zur optimierenden Nachbearbeitung am Computer wird alles Wissenswerte vermittelt.",
          "answer": "i",
          "explanation": "Dietmar Spehrs neuer Ratgeber vermittelt Hobbyfotografen verständlich und unterhaltsam solides Basiswissen zur digitalen Fotografie ('Fotografie – wie, aber richtig: Einführung')."
        },
        {
          "num": 3,
          "text": "Bilder der Fotografin Annie Leibovitz sind ab kommendem Samstag im Kunsthaus Wien zu sehen. Die Ausstellung besticht durch ihre umfangreiche Bildauswahl. Zum einen kann man zahlreiche Porträts berühmter Schauspieler, Politiker oder Musiker bestaunen. Zum anderen sieht man Bilder aus dem privaten Fotoalbum der Künstlerin. Die zum Teil sehr persönlichen Aufnahmen dokumentieren ihr Leben und zeigen bisher unveröffentlichte Werke, die zum Teil sehr bedrückend sind. Bilder ihres Vaters berühren den Besucher und oftmals ist man von der Offenheit der Fotografin überrascht. Zwischen Aufnahmen der Fotografin selbst stehen zahlreiche Porträts ihrer Eltern und Urlaubsfotos der Familie. Die bunte Mischung von großformatigen und kleinformatigen Bildern sorgt für Abwechslung. Um die Fotografien besser kennenzulernen, können Besucher einen ca. 1,5 Stunden langen Film über die Karriere von Annie Leibovitz sehen. Eines ist nach der Ausstellung und dem Film klar: Annie Leibovitz zählt zu den bedeutendsten Fotografinnen des 20. und beginnenden 21. Jahrhunderts.",
          "answer": "a",
          "explanation": "Das Kunsthaus Wien zeigt eine große Ausstellung mit Porträts und privaten Aufnahmen der berühmten Fotografin Annie Leibovitz ('Bilder einer bedeutenden Künstlerin')."
        },
        {
          "num": 4,
          "text": "Die Abkürzung TWAN klingt nach einem neuen Computerprogramm, aber tatsächlich steht sie für eine neue fotografische Methode, die der Iraner Babak Amin Tafreshi entwickelt hat. Diese neue Methode führt zu atemberaubenden Ergebnissen: Noch nie hat man die Sterne so eindrucksvoll über den Landschaften der Erde gesehen wie auf den Bildern in diesem Buch – ein Genuss für die Augen. Was man auf den 160 Seiten des Buches sieht, ist meines Wissens ohne Beispiel. Viele der gezeigten Orte und Landschaften sind bekannte Motive, hier aber wirken sie doch vollkommen anders, als man sie kennt. Da sieht man Sterne über den Ruinen von Persepolis, den Mond über ungarischen Wäldern, die Milchstraße über dem kalifornischen Mammutbaum „General Grant“. Die drei Herausgeber Stefan Seip, Gernot Meiser und Babak A. Tafreshi wurden unterstützt von einem weltweiten Team erfahrener Naturfotografen. Auf den letzten Seiten des Buchs erfährt man auch, dass „Fotografieren im TWAN-Stil heißt, bei fortgeschrittener Dämmerung oder Dunkelheit Aufnahmen zu machen, auch wenn man selbst nicht mehr viel sehen kann“. Neben aller Technik kommt es aber auf den künstlerischen Blick des Fotografen an – und viel Geduld.",
          "answer": "g",
          "explanation": "Ein neuer Bildband zeigt mithilfe der TWAN-Fototechnik noch nie dagewesene Aufnahmen von Sternen und Mond über bekannten Landschaften der Erde ('Erde, Mond und Sterne – wie man sie noch nie gesehen hat')."
        },
        {
          "num": 5,
          "text": "Er gehörte zu den ganz Großen seines Fachs: Andreas Feininger. Eine neue Biografie erzählt die Lebensgeschichte des weltberühmten Fotografen. Neben einem Text auf Deutsch und Englisch enthält sie auch eine kleine, aber gute Auswahl seiner Fotoarbeiten aus allen Schaffensphasen. Die Autoren zeigen den Weg des 1906 in Paris geborenen Fotografen von der Kindheit in Berlin über die Jahre in Weimar und Dessau bis hin zum Leben in Hamburg, Stockholm und schließlich New York, dessen Stadtansichten Feininger weltberühmt machten. Dabei hatte Feininger keineswegs das Ziel, Fotograf zu sein. Eigentlich war Andreas Feininger gelernter Architekt. Als Feininger mit seiner Frau 1933 nach Stockholm auswandert, findet er dort als Architekt keine Anstellung. So macht er aus der Not eine Tugend: Weil er die kleine Familie mit Sohn Thomas ernähren muss, macht er seine Leidenschaft, die Fotografie, zum Broterwerb. Den Durchbruch als weltweit anerkannter Fotograf schafft er schließlich in New York, wohin seine Familie 1939 auswandert.",
          "answer": "c",
          "explanation": "Eine neue Biografie schildert den ungewöhnlichen Werdegang von Andreas Feininger vom Architekten zum weltberühmten Fotografen in New York ('Die bemerkenswerte Karriere eines Fotografen')."
        }
      ]
    },
    {
      "id": "24",
      "title": "Test 24 – Jugend, Ernährung, Umweltforschung & Mobbing",
      "isVariant": false,
      "headings": {
        "a": "Jugend forscht – auch auf dem Meer",
        "b": "Jugend engagiert sich für den Umweltschutz",
        "c": "Kochen für Eltern und Kinder",
        "d": "Mehr Gewalt auf Schulhöfen",
        "e": "Psychoterror an der Schule",
        "f": "Schiffsreise für Jugendliche",
        "g": "Starker Wettbewerb um Schüler",
        "h": "Von der Diät zur Krankheit",
        "i": "Wenn Lernen krank macht",
        "j": "Wenn aus Erdbeeren Tomaten werden"
      },
      "items": [
        {
          "num": 1,
          "text": "Die Zahlen wirken auf den ersten Blick dramatisch: 15 Prozent der Kinder sind übergewichtig und davon sechs Prozent sogar fettleibig. Der Ernährungswissenschaftler Timo Schmidt betreibt in Berlin ein Kochstudio für Kinder und Jugendliche. Timo Schmidt meint, es fehle vor allem an Praxis-Erfahrungen in der Küche. Kinder und Jugendliche können heute oft nicht (mehr) kochen, so seine Erfahrung. Das Interesse ist oft da, und die Kinder wollen kochen. Aber das Problem sind die Eltern. Oft haben sie keine Zeit, den Kindern alles zu erklären. Zum anderen haben sie Angst wegen der scharfen Messer. Dabei ist die Quote von Schnittverletzungen im Kinder- und Jugendkochstudio verschwindend gering. Besonders erschreckend findet Schmidt, dass viele Kinder Lebensmittel einfach nicht mehr erkennen. So standen im Kochstudio beispielsweise Erdbeeren auf dem Tisch, die dann für Tomaten gehalten wurden. Und eine gelbe Zucchini wird gerne mal als Banane bezeichnet. „Was fehlt, ist die Praxis“, meint Schmidt. „Deswegen schneiden die Kinder dann mit der stumpfen Seite des Messers oder wissen nicht, wie heiß die Pfanne beim Kochen wird.“",
          "answer": "j",
          "explanation": "Im Kinderkochstudio zeigt sich, dass viele Kinder mangels Küchenpraxis Lebensmittel nicht mehr erkennen und etwa Erdbeeren für Tomaten halten ('Wenn aus Erdbeeren Tomaten werden')."
        },
        {
          "num": 2,
          "text": "Immer mehr Mädchen leiden an schweren Essstörungen – und das, obwohl Ärzte und Fachleute seit Jahren vor den negativen Folgen des Schlankheitswahns warnen. Die Kinder- und Jugendpsychiatrie im Kinderkrankenhaus in Hannover schlägt jetzt Alarm. „Allein in den letzten zwei Jahren hat die Nachfrage für einen Therapieplatz um fast 50 Prozent zugenommen“, sagt der leitende Psychologe Gerd Kuznik. Von 33 zur Verfügung stehenden Plätzen in der Jugendpsychiatrie seien derzeit 25 von Mädchen mit Essstörungen belegt. „Wir wissen längst, dass dünn zu sein weder gesund noch lebensverlängernd ist“, sagt Kuznik, „doch unsere Gesellschaft konfrontiert gerade junge Mädchen noch immer mit völlig überzogenen Schlankheitsvorstellungen.“ Das allein verursacht noch keine Essstörung. „Wenn aber noch ein grundlegendes familiäres Problem hinzukommt, legen viele Mädchen einen übertriebenen Wert auf ihr Aussehen.“ So berichtet eine 17-Jährige, dass sie aus dem Gefühl heraus, „nichts hinzubekommen“, eine Diät gemacht habe. Und die Diät war dann endlich etwas, das klappte. Als Folge davon hat sie nicht nur wie geplant zwei Kilo abgenommen, sondern dreizehn. So zieht Gerd Kuznik nicht nur in diesem Fall das Fazit: Mit einer harmlosen Diät fängt es meist an, mit einer schweren Krankheit kann es enden.",
          "answer": "h",
          "explanation": "Der Psychologe Gerd Kuznik warnt davor, dass eine vermeintlich harmlose Diät bei jungen Mädchen schnell in einer schweren Essstörung enden kann ('Von der Diät zur Krankheit')."
        },
        {
          "num": 3,
          "text": "Energiesparlampen, umweltfreundliche Elektrogeräte, Bio-Nagellack – sieht man sich die Themen an, mit denen sich die Teilnehmer des 46. Regionalwettbewerbs „Jugend forscht“ beschäftigt haben, wird vor allem eines klar: Das ökologische Bewusstsein hat die Klassenzimmer erreicht. Knapp 100 Schüler nahmen an dem Wettbewerb teil. Die Teilnehmer schreckten auch vor komplexen Themen nicht zurück. Die Zwölftklässler Adrian, Thanh und Son beschäftigten sich mit der Herstellung künstlicher Muskeln. „Die Herausforderung war, sich mit drei Fachgebieten – Anatomie, Technik und Chemie – zu beschäftigen“, sagt Adrian. Gelohnt hat es sich – in der Rubrik Technik erreichte die Gruppe den ersten Platz. In der Rubrik Arbeitswelt ermittelten die Abiturientinnen Yara-Alessandra und Bahir die Ökobilanz von Gartengeräten. „Wir haben festgestellt, dass Laubbläser mit Benzinmotor nicht nur große Mengen Kohlenstoffdioxid produzieren, sie vernichten auch Würmer und Insekten, die für das Gleichgewicht der Umwelt wichtig sind“, sagt Yara-Alessandra. Die Jury honorierte das Projekt mit dem zweiten Platz. Die Gewinner bereiten sich nun auf den Landeswettbewerb „Jugend forscht“ vor.",
          "answer": "b",
          "explanation": "Beim Regionalwettbewerb „Jugend forscht“ stehen ökologische Themen und Umweltschutzprojekte der Schüler im Vordergrund ('Jugend engagiert sich für den Umweltschutz')."
        },
        {
          "num": 4,
          "text": "13,5 Meter lang und leuchtend gelb – die „Aldebaran“ zieht die Blicke im Jachthafen auf sich. Für drei Schüler aus Diepholz ist ein Traum wahr geworden. Als Meeresforscher auf See arbeiten sie an einem eigenen Forschungsprojekt. Sie nehmen am Meereswettbewerb „Forschen auf See“ teil. Ziel des Projektes: junge Leute an wissenschaftliches Arbeiten heranzuführen. Die drei Schüler Jonas, Annika und Katharina sind 17 Jahre alt. Ihr Thema: die Verschmutzung der Nordsee mit winzigen Plastikteilchen. Mit ihren Forschungen wollen die Schüler die Aufmerksamkeit auf die Verschmutzung der Nordsee lenken. Zu Hause in Diepholz engagieren sich die drei in der Umwelt-Arbeitsgruppe ihrer Schule. Über die Verschmutzung der Meere mit winzigen Plastikteilchen und die Gefahren für Fische und Meeressäuger wissen sie schon einiges. Mit ihren Untersuchungen wollen sie die Aufmerksamkeit auf das Problem lenken. Die Proben sind zwar noch nicht ausgewertet, die ersten Plastikteile haben die Jugendlichen aber schon gefunden. „Es sieht so aus, dass wir Ergebnisse kriegen, die gut für unser Projekt sind, aber nicht gut für die Umwelt.“",
          "answer": "a",
          "explanation": "Drei Jugendliche erforschen beim Wettbewerb „Forschen auf See“ an Bord eines Forschungsschiffes die Plastikverschmutzung der Nordsee ('Jugend forscht – auch auf dem Meer')."
        },
        {
          "num": 5,
          "text": "Mobbing ist kein neues Phänomen. Es ist auch in Schulen weitverbreitet. Da spricht zum Beispiel eine Lehrerin vor der Klasse negativ über eine Schülerin, weil sie etwas nicht versteht oder immer wieder krank ist. Oder die Mitschüler lachen oder lassen beleidigende Bemerkungen fallen, wenn ein bestimmter Schüler sich zu Wort meldet. Da lauern Jungen einer 4. Klasse einem schüchternen Mitschüler auf dem Schulweg auf und erpressen von ihm Geld oder Kleidung. Häufig sind die Erwachsenen ratlos oder schauen weg, während die Opfer die Schuld bei sich selbst suchen und zunehmend in eine soziale Isolation geraten. Lehrkräfte sind meist überrascht, wenn man sie auf Mobbing in einer Klasse anspricht. Denn die Schikanen geschehen oft zu subtil und meist außerhalb des Unterrichts, während der Pausen oder auf dem Schulweg.",
          "answer": "e",
          "explanation": "Der Text beschreibt die subtilen Schikanen, Beleidigungen und Ausgrenzungen durch Mobbing im Schulalltag ('Psychoterror an der Schule')."
        }
      ]
    },
    {
      "id": "25",
      "title": "Test 25 – Wohnen, Farben & Zimmerpflanzen",
      "isVariant": false,
      "headings": {
        "a": "Farben in der Wohnung als Therapie",
        "b": "Pflanzen machen den Wohnraum gesünder",
        "c": "Zimmerpflanzen sind selten krank",
        "d": "Möbel als Energiequellen der Zukunft",
        "e": "Gesünder durch kräftige, leuchtende Farben in der Wohnung",
        "f": "Farbberatung durch den Gärtner oder die Floristin",
        "g": "Wohnen in Harmonie mit den Kräften der Natur",
        "h": "Kräuter als Zimmerpflanzen",
        "i": "Kräuter bringen Farbe in Wohnräume",
        "j": "Zimmerpflanzen sorgen für gute Stimmung bei Menschen"
      },
      "items": [
        {
          "num": 1,
          "text": "Feng Shui – wörtlich: „Wind und Wasser“ – ist die taoistische Lehre vom Leben im Einklang mit der Umgebung. Seit Jahrhunderten wird Feng Shui in China und anderen fernöstlichen Kulturen praktiziert, inzwischen ist es auch bei uns beliebt. Wohnen mit Feng Shui bedeutet, ein Gleichgewicht herzustellen – beginnend bei der Auswahl des Grundstücks, der Anordnung von Türen und Fenstern und der Gestaltung der Wohnräume. Türen und Fenster leiten den Energiefluss wie Schleusen, die Position der Möbel lässt die positive Energie weiterströmen oder behindert sie. Wie man vorhandene Energiestörungen durch einfaches Umstellen der Möbel beseitigen kann, zeigen Feng-Shui-erfahrene Innenarchitekten.",
          "answer": "g",
          "explanation": "Die fernöstliche Lehre Feng Shui zielt beim Einrichten darauf ab, im Einklang mit der Umgebung und den natürlichen Energieströmen zu wohnen ('Wohnen in Harmonie mit den Kräften der Natur')."
        },
        {
          "num": 2,
          "text": "Farben haben eine stärkere Wirkung auf Menschen, als viele vermuten. Der Einfluss der Farben ist sogar so groß, dass er für therapeutische Zwecke genutzt wird. Bei der farblichen Gestaltung einer neuen Wohnung sollte man zuerst einmal zurückhaltend sein. Ist der Raum nämlich in knalligem Rot oder blendendem Gelb gestrichen, müssen die Möbel und andere Gegenstände farblich darauf abgestimmt sein, da sonst eine unruhige oder aggressive Atmosphäre entstehen kann. Weiß gestrichene Wände stehen hingegen zwar in dem Ruf, langweilig zu sein, sie lassen sich aber mit allen Möbeln, Stoffen und Dekorationsgegenständen kombinieren und schaffen so leicht eine gemütliche und für das Auge ansprechende Atmosphäre.",
          "answer": "a",
          "explanation": "Der Text beleuchtet die psychologische und therapeutische Wirkung von Wand- und Einrichtungsfarben auf die Wohnatmosphäre ('Farben in der Wohnung als Therapie')."
        },
        {
          "num": 3,
          "text": "Ein allgemeingültiger Optimalwert wird von Fachleuten ungern benannt, da kaum ein Wert so hohen natürlichen Schwankungen unterliegt wie die Luftfeuchte. Witterung, Temperaturunterschiede, Wohngewohnheiten, alles sorgt für ständiges Auf und Ab. Als Mittelwert kann 40–60 % angenommen werden. Die relative Luftfeuchtigkeit sollte in Wohnräumen nie dauerhaft unter 30 % oder über 70 % liegen. In den meisten Wohnräumen ist die Luft zu trocken. Die Luftfeuchtigkeit beträgt nur 20 %. Besonders Zentralheizungen und Klimaanlagen trocknen die Luft aus und wirbeln Staub, Keime und Schadstoffe auf. Atemwegserkrankungen und Allergien sind oft die Folge. Auslöser sind meist Keime oder Bakterien, die bei trockener Luft gut gedeihen. Gegen üble Gerüche und zu hohe Lufttrockenheit helfen am besten Pflanzen. Sie geben Wasserdampf an die Umgebung ab und sorgen für ein gutes Raumklima.",
          "answer": "b",
          "explanation": "Zimmerpflanzen geben Wasserdampf ab, wirken gegen trockene Heizungsluft und beugen so Atemwegserkrankungen und Allergien vor ('Pflanzen machen den Wohnraum gesünder')."
        },
        {
          "num": 4,
          "text": "Frische Kräuter machen jedes Essen zum Genuss. Man braucht keinen großen Garten, um sich für den Eigenbedarf aromatische Gewürzpflanzen selbst ziehen zu können. Die meisten dieser Kräuter gedeihen nämlich auch im Blumentopf auf dem Balkon oder auf der Fensterbank. Dabei sind natürlich solche Pflanzen, die im Freien wachsen können, durch den Einfluss des Sonnenlichts aromatischer als solche, die nur hinter Glas wachsen können. Die Pflanzen im Zimmer brauchen auch mehr Pflege als ihre Kollegen an der frischen Luft. Wegen der Lufttrockenheit in den Wohnungen müssen sie z. B. viel häufiger gegossen werden als Freilandpflanzen, auch sind sie weniger widerstandsfähig gegen Schädlinge und Pflanzenkrankheiten.",
          "answer": "h",
          "explanation": "Der Text erklärt, wie man Gewürzkräuter im Blumentopf auf der Fensterbank zieht und pflegt ('Kräuter als Zimmerpflanzen')."
        },
        {
          "num": 5,
          "text": "Bei der Wohnraumgestaltung lässt sich viel erreichen mit der richtigen Auswahl der Zimmerpflanzen. Es müssen nicht nur grünblättrige Gummibäume oder Palmen sein, die einen Raum verschönern – vielfältige Blatt- und Blütenfarben machen selbst trostlos wirkende Räume farbenfroh und fröhlich. So können Blühpflanzen auf der Fensterbank auch im Herbst oder Winter die Bewohner in gute Laune versetzen. Grünpflanzen beruhigen zudem und man fühlt sich beim Anblick der Natur in der eigenen Wohnung einfach ruhiger und ausgeglichener. Bedenken Sie aber: Pflanzen müssen am richtigen Platz stehen, wenn man lange an ihnen Freude haben möchte. Viele Gärtnereien oder Blumengeschäfte bieten daher einen Beratungsservice an.",
          "answer": "j",
          "explanation": "Blüh- und Grünpflanzen machen Wohnräume fröhlich, beruhigen und versetzen die Bewohner in gute Laune ('Zimmerpflanzen sorgen für gute Stimmung bei Menschen')."
        }
      ]
    },
    {
      "id": "26",
      "title": "Test 26 – Verkehr, Fliegen & Solarmobil",
      "isVariant": false,
      "headings": {
        "a": "Benzingeld sparen: Tipp vom Tankwart",
        "b": "Die wichtigsten Erste-Hilfe-Ratschläge",
        "c": "Einmal die Welt als Ganzes sehen",
        "d": "Einmal um die Welt ohne einen Tropfen Benzin",
        "e": "Fliegen statt fahren",
        "f": "Innerdeutsche Reisen besonders beliebt",
        "g": "Frau im All",
        "h": "Schweizer nutzen Solartaxis",
        "i": "Steigende Spritpreise: die Tricks der Autofahrer",
        "j": "Die richtige Unfallversicherung"
      },
      "items": [
        {
          "num": 1,
          "text": "Aussteigen, tanken, wegfahren: Wenn die Benzinpreise steigen, ist wieder Hochsaison bei den Benzindieben. Früh morgens und abends schlagen sie besonders gerne zu. Viele setzen auf den Schutz der Dunkelheit. Vor Weihnachten und im Januar und Februar häufen sich die Fälle. Auch am Monatsende, wenn das Geld knapp wird, steigt die Zahl der Benzindiebstähle. Doch sparen lässt sich durch Benzinklau nicht. Fast alle Täter werden von der Polizei gefasst. Schließlich gibt es an jeder Tankstelle eine Kamera, die das Autokennzeichen aufgenommen hat. Tankwart Kurt Jochimsen aus Emden zeigt uns einen Fall aus seiner großen Videosammlung. Ein Wagen mit zwei Insassen fährt an die Zapfsäule. Der Fahrer tankt, seine Frau geht in den Shop. Sie kauft dort zwei Cola und bezahlt. Aber nicht das Benzin. Der Mann hat inzwischen vollgetankt und wartet im Wagen. „Hier sehen Sie: Die Frau kommt raus, steigt ein und das Fahrzeug fährt davon. Hinterher heißt es dann, ich habe doch glatt vergessen, das Benzin zu bezahlen“, erklärt Kurt Jochimsen. Bei der Polizei kennt man diese Ausreden. Polizeihauptkommissar Werner Knips: „Vergessen gilt nicht, es gibt immer eine Anzeige. Und dann wird es richtig teuer.“",
          "answer": "i",
          "explanation": "Bei hohen Benzinpreisen versuchen manche Autofahrer mit dreisten Tricks und Ausreden an der Tankstelle ohne Bezahlung davonzufahren ('Steigende Spritpreise: die Tricks der Autofahrer')."
        },
        {
          "num": 2,
          "text": "Viele Autofahrer, die in einen Unfall verwickelt sind, sind so aufgeregt, dass sie vergessen, was zu tun ist. Der Versicherungsexperte Klaus Lenhoff gibt die wichtigsten Tipps: 1. Unfallstelle absichern: Warnblinkanlage einschalten und Warndreieck in 100 Metern Entfernung aufstellen. 2. Rettung aus dem Gefahrenbereich: alle Unfallbeteiligten aus dem Gefahrenbereich retten. Eingeschlossene befreien und Brände sofort bekämpfen. 3. Rettungskräfte informieren: bei schweren Unfällen und wenn es Verletzte gibt, die Polizei (Ruf 110) oder die Rettungsleitstelle (Ruf 112) informieren. Dabei an „die fünf Ws“ denken: Wo ist es passiert? Was ist passiert? Wie viele Verletzte? Welche Verletzungen? Warten Sie auf Rückfragen. 4. Verletzten Hilfe leisten, zum Beispiel: Kontrolle von Atmung und Puls, Atemspende, stabile Seitenlage, Erkennen und Behandeln eines Schocks, Stillen von Blutungen. 5. Lokalisierung auf der Autobahn: Wo hat sich der Unfall ereignet? 6. Beweismittel sichern: am besten Fotos oder eine Skizze von der Unfallstelle machen. 7. Verkehrsfluss wiederherstellen, also schnell die Fahrbahn räumen. 8. Name, Anschrift und Telefonnummern von Zeugen notieren. 9. Vorsicht bei Aussagen: die Aufregung am Unfallort verleitet zu missverständlichen Äußerungen. Keine Aussagen unter Druck machen. 10. Versicherung des Unfallgegners ermitteln.",
          "answer": "b",
          "explanation": "Der Text listet eine 10-Punkte-Anleitung zum richtigen Verhalten und zur Ersten Hilfe am Unfallort auf ('Die wichtigsten Erste-Hilfe-Ratschläge')."
        },
        {
          "num": 3,
          "text": "Hast du schon mal mit dem Gedanken gespielt, Pilotin zu werden? Nicht? Dann geht es euch wahrscheinlich wie den meisten Mädchen oder Frauen. Warum wollen eigentlich so wenige Frauen Pilotinnen werden? Nur weil der Beruf angeblich ein typischer Männerberuf ist? Wir haben eine Pilotin getroffen: Monique Belling ist 39 Jahre alt, wohnt im Süden Frankfurts und ist Pilotin. „Schon seit früher Kindheit habe ich mich für die Fliegerei interessiert. Es hat mich schon immer fasziniert, dass es mit Hilfe technischer Mittel möglich ist, die Schwerkraft zu überwinden und die Welt aus der Vogelperspektive zu betrachten. Und irgendwann wollte ich diese Technik dann auch selbst beherrschen“, so Belling. Seit sie in diesem Beruf arbeite, habe sich ihre Einstellung zu vielen Dingen verändert: „Ich bin toleranter als vor meinem ‚Fliegerleben‘ – vielleicht weil ich versuche, mein Umfeld aus anderen Perspektiven zu betrachten. Auch meine Freizeit und meine Familie sind mir noch kostbarer geworden, seit ich in diesem Beruf tätig bin“, erklärt sie. Hat sie noch Träume? „Aber ja!“, sagt Monique Belling: „Mit einem Shuttle ins Weltall fliegen, um die Erde als Kugel zu sehen und das Gefühl absoluter Schwerelosigkeit zu erleben.“",
          "answer": "c",
          "explanation": "Die Pilotin Monique Belling betrachtet die Welt aus der Vogelperspektive und träumt davon, aus dem Weltall die Erde als Kugel im Ganzen zu sehen ('Einmal die Welt als Ganzes sehen')."
        },
        {
          "num": 4,
          "text": "Der Schweizer Louis Palmer hat eine Weltumrundung mit seinem „Solartaxi“ fast abgeschlossen. Er habe bereits 47.000 km mit seinem Solarauto zurückgelegt, sagte Palmer bei einem Stopp in Paris. „Nun habe ich fast den ganzen Planeten umrundet, ohne einen Tropfen Benzin zu brauchen.“ Die Batterien des bis zu 90 Stundenkilometer schnellen Solarmobils können Energie für eine Reichweite von 400 km speichern. „Das Wetter spielt keine Rolle“, sagte Palmer. „Es kann mehrere Tage in Folge regnen, ich fahre ohne Probleme weiter.“ Palmer war mit seinem dreirädrigen „Taxi“ im Juli in Luzern gestartet. Seitdem hat er Europa, Asien, Australien, Neuseeland und Nordamerika durchquert. Er zieht einen Anhänger mit sechs Quadratmetern Solarzellen hinter sich her und die Sonnenenergie treibt das Gefährt an. Seit dem Start ist das Solartaxi nur zwei Tage ausgefallen, weil ein Kabel beschädigt war. Gebaut wurde das innovative Fahrzeug von vier Schweizer Ingenieurschulen. Palmer hat auch Platz für Beifahrer: Neben ihm saßen schon berühmte Persönlichkeiten aus Politik, Wirtschaft und Showgeschäft im „Solartaxi“.",
          "answer": "d",
          "explanation": "Louis Palmer hat mit seinem solarbetriebenen Auto 47.000 km rund um den Globus zurückgelegt, „ohne einen Tropfen Benzin zu brauchen“ ('Einmal um die Welt ohne einen Tropfen Benzin')."
        },
        {
          "num": 5,
          "text": "Die Bundesregierung und ihre Spitzenbeamten sind auf Dienstreisen gern mit dem Flugzeug unterwegs – aber nicht nur, wenn es um Fernreisen geht, sondern auch bei kurzen Inlandsreisen. Wie aus der Antwort des Innenministeriums auf eine Frage eines Abgeordneten hervorgeht, gab die Bundesregierung im letzten Jahr 7,7 Millionen Euro für innerdeutsche Flugreisen aus. Fahrkarten der Bahn hingegen schlugen lediglich mit 3,2 Millionen zu Buche. Der Vergleich mit anderen Jahren zeigt aber, dass sich die meisten Politiker bemühen, immer häufiger vom Flugzeug auf die Bahn umzusteigen. Eine Ausnahme bildet das Kanzleramt (Flugkosten um 30 % erhöht gegenüber dem Vorjahr) sowie ausgerechnet das Ressort des Bundesumweltministers (plus 7 %). Vergleichszahlen für den erhöhten und gesenkten Benzinverbrauch für die Dienstwagen der Bundesregierung liegen noch nicht vor.",
          "answer": "e",
          "explanation": "Politiker und Spitzenbeamte der Bundesregierung geben für innerdeutsche Dienstreisen deutlich mehr Geld für Flüge als für Bahntickets aus ('Fliegen statt fahren')."
        }
      ]
    },
    {
      "id": "27",
      "title": "Test 27 – Lehrermangel & Schule in Deutschland",
      "isVariant": false,
      "headings": {
        "a": "An deutschen Grundschulen sind männliche Lehrkräfte selten",
        "b": "Bildungsexperten warnen: Deutsche Lehrer sind schlecht ausgebildet",
        "c": "Bildungsforscher: Lehrermangel wird in Deutschland nicht eintreten",
        "d": "Die Zahl der männlichen Lehrkräfte an Grundschulen nimmt zu",
        "e": "Experten befürchten zunehmenden Lehrermangel in Deutschland",
        "f": "Gewerkschaft erwartet Lehrermangel in Berlin",
        "g": "GEW befürchtet Abwanderung von gut ausgebildeten Lehrkräften aus Berlin",
        "h": "Immer mehr Berliner wandern aus",
        "i": "Immer weniger Frauen machen ein Grundschullehrer-Studium",
        "j": "Vorausschauende Politiker verhindern Lehrermangel in Berlin"
      },
      "items": [
        {
          "num": 1,
          "text": "Berlin wird in 10 Jahren rund 5.000 Lehrkräfte weniger brauchen als derzeit. Für den Unterricht an den Schulen werden dann, wie die Gewerkschaft Erziehung und Wissenschaft (GEW) errechnet hat, noch etwa 25.500 von heute 30.000 Pädagogen benötigt. Die Gewerkschaft befürchtet zugleich, dass bis zu diesem Zeitpunkt zu wenig Nachwuchskräfte ausgebildet werden und es deshalb zu einer dramatischen Unterversorgung kommt. Nach Meinung der GEW steuert die Hauptstadt bei der Personalausstattung der Schulen auf ein Fiasko zu, weil in den nächsten 10 Jahren mehr als 10.000 Lehrkräfte aus Altersgründen in den Ruhestand gehen. Außerdem würden jährlich zirka 400 Lehrer die Berliner Schulen verlassen, sodass nach Ansicht der GEW letztlich 9.000 Stellen fehlen. Wenn die Zahl der Studienanfänger nicht kräftig gesteigert werde, könne langfristig nicht einmal die Hälfte des prognostizierten Einstellungsbedarfs gedeckt werden. Außerdem sei die Hauptstadt für Berufseinsteiger nicht so attraktiv wie andere Bundesländer, da sie selbst für Mangelfächer nur befristete Verträge anbietet.",
          "answer": "f",
          "explanation": "Die Bildungsgewerkschaft GEW warnt davor, dass in Berlin in den nächsten zehn Jahren durch Pensionierungen rund 9.000 Lehrerstellen unbesetzt bleiben könnten ('Gewerkschaft erwartet Lehrermangel in Berlin')."
        },
        {
          "num": 2,
          "text": "Wer sich in Berlin um eine Stelle als Lehrer bewirbt, muss hart im Nehmen sein. „Während man in Hamburg respektvoll behandelt wird, rechnen Vertreter der Berliner Schulverwaltung den Bewerbern vor, wie teuer Lehrer sind. Da fühlt man sich nicht richtig gewollt“, sagt Maria Schütz. Die 27-Jährige gehört zu den rund 500 Referendaren, die in zwei Wochen mit ihrem Studium fertig werden. Maria Schütz, die ihr Examen mit der Note 1,5 bestanden hat und unbedingt in Berlin unterrichten wollte, hat mit ihrer Bewerbung leidvolle Erfahrungen hinter sich. „Während man in Hamburg sofort eine feste Stelle im Beamtenverhältnis angeboten hat, konnte mir in Berlin keiner zusagen, dass ich im nächsten Schuljahr gebraucht werde.“ Die junge Frau hat das gute Angebot aus Hamburg einer unsicheren Zukunft in Berlin vorgezogen. Für Anna Richter, Vorsitzende der Lehrergewerkschaft GEW, ist Marias Geschichte nur eine von vielen. Ihre Organisation ist besorgt darüber, dass Berlin auf diese Weise viele gut qualifizierte Lehrer an andere Bundesländer verlieren könnte.",
          "answer": "g",
          "explanation": "Wegen fehlender Stellenzusagen und fehlender Verbeamtung wechseln gut ausgebildete Nachwuchslehrer von Berlin in andere Bundesländer wie Hamburg ('GEW befürchtet Abwanderung von gut ausgebildeten Lehrkräften aus Berlin')."
        },
        {
          "num": 3,
          "text": "Die Hilferufe aus den Schulen wollen nicht verstummen: Schüler klagen über ständigen Lehrerwechsel, Eltern über Stundenausfall und Schulleiter über fehlende Bewerber. Doch es könnte noch schlimmer werden. Der Verband Bildung und Erziehung (VBE) rechnet in den nächsten 15 Jahren mit einem „gewaltigen Lehrermangel“ in Deutschland. Der Verbandsvorsitzende Ludwig Eckinger sagte am Donnerstag, er gehe für diesen Zeitraum von bis zu 400.000 Lehrern aus, die aus Altersgründen aus dem Schuldienst ausscheiden. Für 100 pensionierte Lehrer kämen jedoch nur 50 neue Kollegen. Der Lehrernotstand kommt nicht überraschend, Forscher sagten ihn längst voraus. Und auch die Konferenz der Kultusminister präsentierte schon vor fünf Jahren beunruhigende Zahlen: Es werden an deutschen Schulen 70.000 Pädagogen fehlen, denn fast die Hälfte der 800.000 Lehrer geht in Pension. Deshalb fordern Experten seit langem einen bundesweiten Entwicklungsplan, denn Untersuchungen des Lehrerarbeitsmarkts zeigten eher „Chaos als systematische Planung“. Deutschland steuere auf Zustände wie in den Niederlanden zu. Dort ist der Lehrermangel so groß, dass sich Schulen gegenseitig Lehrer ausspannen.",
          "answer": "e",
          "explanation": "Der Verband Bildung und Erziehung (VBE) und Experten warnen bundesweit vor einem massiven Lehrermangel in den kommenden 15 Jahren ('Experten befürchten zunehmenden Lehrermangel in Deutschland')."
        },
        {
          "num": 4,
          "text": "Bildungspolitiker und Lehrervertreter wollen Abiturienten scharenweise in den Lehrerberuf locken. Sie sollen große Lücken schließen, die durch Pensionierungen entstehen. Doch das Versprechen vom sicheren Job lässt sich womöglich nicht einlösen – es basiere auf falschen Annahmen, sagen Essener Bildungsforscher. Die Arbeitsgruppe Bildungsforschung/Bildungsplanung unter der Leitung des Wissenschaftlers Klaus Klemm kommt in ihrem Bericht zu einem ganz anderen Ergebnis. Während die Kultusministerkonferenz mit 70.000 fehlenden Lehrern rechnet und der Philologenverband gar mit 80.000, errechnete die Forschungsgruppe, dass es zu einer insgesamt ausgeglichenen Bilanz zwischen Nachfrage und Angebot auf dem Lehrer-Arbeitsmarkt kommen werde. Wenn sich die „Einstellungspolitik der Bundesländer nicht ändert, dürften wir sogar einen Lehrerüberschuss bekommen“, sagte Klemm. Er warnt Abiturienten, ihre Studienentscheidung von den angeblich rosigen Aussichten für Lehrer abhängig zu machen. „Die Abiturienten hören, es werden Lehrer gesucht, und schon studieren sie Germanistik fürs Gymnasium. Das ist ein Fehler“, sagt Klemm. Denn schon jetzt zeichne sich ab, dass es Deutsch-, Geschichts- und Fremdsprachenlehrer eher schwer haben werden.",
          "answer": "c",
          "explanation": "Die Essener Forschungsgruppe um Klaus Klemm widerspricht den Warnungen und prognostiziert eine ausgeglichene Bilanz oder sogar einen Lehrerüberschuss ('Bildungsforscher: Lehrermangel wird in Deutschland nicht eintreten')."
        },
        {
          "num": 5,
          "text": "Mädchen haben tendenziell bessere Noten und stellen 56 Prozent der Abiturienten. Dagegen sind zwei Drittel der Schulabbrecher und drei Viertel der Sonderschüler Jungen. Liegt die Ursache in der Grundschule, wo von den knapp 200.000 Lehrkräften nur rund 26.000 männlich sind? An der Grundschule sind Männer eine Rarität. Wer sich dorthin verirrt, arbeitet allein unter Frauen. Im Schuljahr 1990/1991 unterrichteten noch ein Drittel Männer an Grundschulen, im Schuljahr 2006/2007 liegt der Frauenanteil an den Grundschullehrern bei 86,9 Prozent, während an weiterführenden Schulen das Geschlechterverhältnis nahezu ausgeglichen ist. Im Extremfall kann das bedeuten, dass Jungen bis zum Alter von 10 oder 12 Jahren in Krippe, Kindergarten und Grundschule ausschließlich von Frauen betreut und unterrichtet werden. Auch die Familienministerin vermisst die Männer an den Grundschulen. „In den wichtigen frühen Jahren fehlen den Jungen männliche Vorbilder, an denen sie sich im Alltag ausrichten können“, sagte sie in einem Interview. Das gelte gerade für Kinder mit Migrationshintergrund. Gründe dafür sieht sie in der gesellschaftlichen Anerkennung des Berufs und in den Gehaltsstrukturen.",
          "answer": "a",
          "explanation": "An deutschen Grundschulen sind fast 87 % der Lehrkräfte Frauen, männliche Grundschullehrer sind eine Rarität ('An deutschen Grundschulen sind männliche Lehrkräfte selten')."
        }
      ]
    },
    {
      "id": "28",
      "title": "Test 28 – Konsum, Nachhaltigkeit & Glück",
      "isVariant": false,
      "headings": {
        "a": "Gemeinsam kaputte Geräte retten",
        "b": "Kaufsucht überwinden – diese Möglichkeiten gibt es",
        "c": "Neue Besitzer für nicht mehr gebrauchte Gegenstände",
        "d": "Reparatur alter Haushaltsgeräte lohnt oft nicht",
        "e": "Rücksendungen verderben Online-Händlern das Geschäft",
        "f": "Rücksendungen verringern: Händler hoffen auf Lösungen",
        "g": "Studie zeigt, welche Geschenke glücklich machen",
        "h": "Verein mit Preis für Umweltschutz ausgezeichnet",
        "i": "Volle Einkaufstüten machen nur kurze Zeit Freude",
        "j": "Wer Engagement zeigt, steigert sein Glücksgefühl"
      },
      "items": [
        {
          "num": 1,
          "text": "Sie sind eine gut funktionierende Gemeinschaft mit einer Vision: Schon seit den 80er Jahren leben Mitglieder des „Tauschrings Harmelsdorf e. V.“ vor, wie man nachhaltig mit Ressourcen umgehen kann und dadurch die Umwelt schont. „Tauschen, nicht wegwerfen“ ist das Motto dieser Initiative – die damals als eine der ersten dieser Art in Deutschland noch belächelt wurde, heute aber viel Lob und Anerkennung bekommt. Ob Küchengeräte, Bücher oder auch Kleidungsstücke, die man nicht mehr anzieht: Was ungenutzt ist, findet bei jemandem Verwendung, der noch etwas damit anfangen kann. Getauscht werden nicht nur Güter, sondern auch Dienstleistungen. Eine der Voraussetzungen für das Gelingen: „Die Dienstleistungen dürfen nicht in Konkurrenz zum Handwerk stehen“, erklärt Tauschring-Mitglied Kati Jago. Besonders gefragt seien Fahrdienste, etwa zum Arzt. Ihre monatlichen Zusammenkünfte an der Rathausstraße sind für die derzeit 30 Vereinsmitglieder viel mehr als bloße Tauschtreffs: „Man darf den Faktor Mensch nicht unterschätzen“, sagt Kati Jago. Denn beim Tauschen zählt auch das soziale Miteinander.",
          "answer": "c",
          "explanation": "Im Tauschring Harmelsdorf finden ungenutzte Küchengeräte, Bücher und Kleidungsstücke neue Abnehmer ('Neue Besitzer für nicht mehr gebrauchte Gegenstände')."
        },
        {
          "num": 2,
          "text": "„Man gönnt sich ja sonst nichts.“ Und schon ist die Einkaufstüte voll und das Konto leer. Macht das glücklich? Oder wieso sonst kauft man mehr, als man eigentlich geplant hat? „Ein Einkauf kann sich ähnlich anfühlen wie eine Belohnung“, sagt der Psychologe Daniel Stüber. Denn dabei würden Glückshormone ausgeschüttet. Manchmal könne das sogar in einem Kaufrausch enden. Denn das Glücksgefühl, das Konsumenten beim Kaufen erleben, könne sie dazu anregen, immer mehr Geld auszugeben. Doch die Ernüchterung folge oft schnell, warnt er: Denn wer später merke, wie teuer das alles gewesen ist, schütte Stresshormone aus. Dies könne zu Schlafstörungen und schlechter Laune führen. Langfristig lässt sich so die eigene Lebenszufriedenheit also gewiss nicht steigern.",
          "answer": "i",
          "explanation": "Auf das kurze Glücksgefühl beim Einkaufen folgt angesichts der Kosten oft rasch Ernüchterung und Stress ('Volle Einkaufstüten machen nur kurze Zeit Freude')."
        },
        {
          "num": 3,
          "text": "Geklickt, gekauft, zurückgeschickt: Kunden nutzen im Online-Handel gerne die Möglichkeit, Waren innerhalb einer bestimmten Frist kostenlos zurückzusenden. Vor allem im Modehandel steigt die Zahl der Rücksendungen immer weiter an. Oft bestellen Kunden gleich mehrere Modelle in unterschiedlichen Größen, um sie zu Hause in Ruhe anzuprobieren. Die Kosten für die Retouren trägt der Anbieter. Dennoch lohnt sich für die Online-Händler das Geschäft. Die zurückgegebene Kleidung kann zum Beispiel oft so aufbereitet werden, dass sie erneut zum Verkauf angeboten werden kann. „Rücksendungen werden sich im Online-Handel nie ganz vermeiden lassen“, erklärt Birgit Steinköhler vom Bundesverband Online-Handel. Dennoch ist es möglich, dass sich ihre Anzahl in Zukunft senken lässt. Dies wünschen natürlich auch die Online-Verkäufer und suchen nach neuen Möglichkeiten: etwa detailliertere Produktinformationen oder neue Technologien, die die individuellen Maße der Kunden ermitteln. Dennoch: Rücksendungen werden im Online-Handel wohl immer zum Geschäftsmodell gehören.",
          "answer": "f",
          "explanation": "Online-Händler suchen nach Wegen wie besseren Produktinformationen und Maß-Technologien, um die Zahl der Retouren künftig zu senken ('Rücksendungen verringern: Händler hoffen auf Lösungen')."
        },
        {
          "num": 4,
          "text": "Keine Lust mehr auf die Konsum-Gesellschaft? Dann könnte es ein erster Schritt sein, den Lieblingspulli zu stopfen statt zu entsorgen oder den alten Wecker von Oma noch mal zum Laufen zu bringen. Ob Fahrrad, Fernseher oder Smartphone – man muss bei Defekten nicht gleich alles wegwerfen. In sogenannten Repair-Cafés können defekte Gegenstände unter fachkundiger Anleitung wieder instandgesetzt werden. „Damit schonen wir die Umwelt und den Geldbeutel“, erklärt Thomas Rederitz, Inhaber eines solchen Reparaturcafés. Repair-Cafés verstehen sich als Initiative gegen die Wegwerfmentalität. „Da viele Firmen keinen Reparaturservice mehr anbieten, muss vieles aufwendig entsorgt werden“, sagt Rederitz. Das sei nicht immer nötig. „Manchmal ist ja auch nur eine Schraube locker, oder es fehlt ein kleines Bauteil, das leicht ersetzt werden kann.“ Im Reparaturcafé wird gemeinsam gewerkelt, geschraubt, genäht, gebastelt – und auch gelacht und geredet. Die Reparatur wird in jedem Fall sachgerecht durchgeführt; denn zu den freiwilligen Mitarbeitern von Repair-Cafés gehören Handwerksmeister der unterschiedlichsten Fachrichtungen.",
          "answer": "a",
          "explanation": "In Repair-Cafés reparieren Besucher gemeinsam mit ehrenamtlichen Fachleuten defekte Alltagsgeräte ('Gemeinsam kaputte Geräte retten')."
        },
        {
          "num": 5,
          "text": "Viele Menschen sind erstaunlich großzügig: Sie machen anderen gern Geschenke, spenden Geld für gute Zwecke oder opfern Zeit für ehrenamtliche Tätigkeiten. Aber was motiviert sie dazu? Die Wissenschaft liefert ganz unterschiedliche Erklärungsansätze. Eine Erklärung lautet, dass großzügige Menschen auf Gegenseitigkeit hoffen: Wer viel gibt, bekommt auch viel zurück. Eine Studie konnte nun aber zeigen, dass die Antwort vielleicht ganz einfach ist: Großzügigkeit mache eben glücklich. Dies fanden Forscher der Universität Lübeck heraus. Diese enge Verknüpfung zwischen großzügigem Verhalten und Glücksgefühl zeige sich auch im Gehirn. So aktiviere ein solches Verhalten ein Hirnareal, das eng mit unserem Belohnungszentrum verknüpft ist. Das Ergebnis ihrer Studie könne weitreichende Folgen für die Gesellschaft haben. Wer glücklicher werden möchte, könne sich diese neuen Erkenntnisse zunutze machen: Denn wer für andere da ist, tut auch etwas für das eigene Wohlbefinden.",
          "answer": "j",
          "explanation": "Eine Lübecker Studie zeigt, dass Großzügigkeit, Spenden und ehrenamtlicher Einsatz für andere das Belohnungszentrum im Gehirn aktivieren ('Wer Engagement zeigt, steigert sein Glücksgefühl')."
        }
      ]
    },
    {
      "id": "28a",
      "title": "Test 28a – Konsum, Nachhaltigkeit & Glück (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Wer Engagement zeigt, steigert sein Glücksgefühl",
        "b": "Volle Einkaufstüten machen nur kurze Zeit Freude",
        "c": "Verein mit Preis für Umweltschutz ausgezeichnet",
        "d": "Studie zeigt, welche Geschenke glücklich machen",
        "e": "Rücksendungen verringern: Händler hoffen auf Lösungen",
        "f": "Rücksendungen verderben Online-Händlern das Geschäft",
        "g": "Reparatur alter Haushaltsgeräte lohnt oft nicht",
        "h": "Neue Besitzer für nicht mehr gebrauchte Gegenstände",
        "i": "Kaufsucht überwinden – diese Möglichkeiten gibt es",
        "j": "Gemeinsam kaputte Geräte retten"
      },
      "items": [
        {
          "num": 1,
          "text": "Sie sind eine gut funktionierende Gemeinschaft mit einer Vision: Schon seit den 80er Jahren leben Mitglieder des „Tauschrings Harmelsdorf e. V.“ vor, wie man nachhaltig mit Ressourcen umgehen kann und dadurch die Umwelt schont. „Tauschen, nicht wegwerfen“ ist das Motto dieser Initiative – die damals als eine der ersten dieser Art in Deutschland noch belächelt wurde, heute aber viel Lob und Anerkennung bekommt. Ob Küchengeräte, Bücher oder auch Kleidungsstücke, die man nicht mehr anzieht: Was ungenutzt ist, findet bei jemandem Verwendung, der noch etwas damit anfangen kann. Getauscht werden nicht nur Güter, sondern auch Dienstleistungen. Eine der Voraussetzungen für das Gelingen: „Die Dienstleistungen dürfen nicht in Konkurrenz zum Handwerk stehen“, erklärt Tauschring-Mitglied Kati Jago. Besonders gefragt seien Fahrdienste, etwa zum Arzt. Ihre monatlichen Zusammenkünfte an der Rathausstraße sind für die derzeit 30 Vereinsmitglieder viel mehr als bloße Tauschtreffs: „Man darf den Faktor Mensch nicht unterschätzen“, sagt Kati Jago. Denn beim Tauschen zählt auch das soziale Miteinander.",
          "answer": "h",
          "explanation": "Im Tauschring Harmelsdorf finden ungenutzte Küchengeräte, Bücher und Kleidungsstücke neue Abnehmer ('Neue Besitzer für nicht mehr gebrauchte Gegenstände')."
        },
        {
          "num": 2,
          "text": "„Man gönnt sich ja sonst nichts.“ Und schon ist die Einkaufstüte voll und das Konto leer. Macht das glücklich? Oder wieso sonst kauft man mehr, als man eigentlich geplant hat? „Ein Einkauf kann sich ähnlich anfühlen wie eine Belohnung“, sagt der Psychologe Daniel Stüber. Denn dabei würden Glückshormone ausgeschüttet. Manchmal könne das sogar in einem Kaufrausch enden. Denn das Glücksgefühl, das Konsumenten beim Kaufen erleben, könne sie dazu anregen, immer mehr Geld auszugeben. Doch die Ernüchterung folge oft schnell, warnt er: Denn wer später merke, wie teuer das alles gewesen ist, schütte Stresshormone aus. Dies könne zu Schlafstörungen und schlechter Laune führen. Langfristig lässt sich so die eigene Lebenszufriedenheit also gewiss nicht steigern.",
          "answer": "b",
          "explanation": "Auf das kurze Glücksgefühl beim Einkaufen folgt angesichts der Kosten oft rasch Ernüchterung und Stress ('Volle Einkaufstüten machen nur kurze Zeit Freude')."
        },
        {
          "num": 3,
          "text": "Geklickt, gekauft, zurückgeschickt: Kunden nutzen im Online-Handel gerne die Möglichkeit, Waren innerhalb einer bestimmten Frist kostenlos zurückzusenden. Vor allem im Modehandel steigt die Zahl der Rücksendungen immer weiter an. Oft bestellen Kunden gleich mehrere Modelle in unterschiedlichen Größen, um sie zu Hause in Ruhe anzuprobieren. Die Kosten für die Retouren trägt der Anbieter. Dennoch lohnt sich für die Online-Händler das Geschäft. Die zurückgegebene Kleidung kann zum Beispiel oft so aufbereitet werden, dass sie erneut zum Verkauf angeboten werden kann. „Rücksendungen werden sich im Online-Handel nie ganz vermeiden lassen“, erklärt Birgit Steinköhler vom Bundesverband Online-Handel. Dennoch ist es möglich, dass sich ihre Anzahl in Zukunft senken lässt. Dies wünschen natürlich auch die Online-Verkäufer und suchen nach neuen Möglichkeiten: etwa detailliertere Produktinformationen oder neue Technologien, die die individuellen Maße der Kunden ermitteln. Dennoch: Rücksendungen werden im Online-Handel wohl immer zum Geschäftsmodell gehören.",
          "answer": "e",
          "explanation": "Online-Händler suchen nach Wegen wie besseren Produktinformationen und Maß-Technologien, um die Zahl der Retouren künftig zu senken ('Rücksendungen verringern: Händler hoffen auf Lösungen')."
        },
        {
          "num": 4,
          "text": "Keine Lust mehr auf die Konsum-Gesellschaft? Dann könnte es ein erster Schritt sein, den Lieblingspulli zu stopfen statt zu entsorgen oder den alten Wecker von Oma noch mal zum Laufen zu bringen. Ob Fahrrad, Fernseher oder Smartphone – man muss bei Defekten nicht gleich alles wegwerfen. In sogenannten Repair-Cafés können defekte Gegenstände unter fachkundiger Anleitung wieder instandgesetzt werden. „Damit schonen wir die Umwelt und den Geldbeutel“, erklärt Thomas Rederitz, Inhaber eines solchen Reparaturcafés. Repair-Cafés verstehen sich als Initiative gegen die Wegwerfmentalität. „Da viele Firmen keinen Reparaturservice mehr anbieten, muss vieles aufwendig entsorgt werden“, sagt Rederitz. Das sei nicht immer nötig. „Manchmal ist ja auch nur eine Schraube locker, oder es fehlt ein kleines Bauteil, das leicht ersetzt werden kann.“ Im Reparaturcafé wird gemeinsam gewerkelt, geschraubt, genäht, gebastelt – und auch gelacht und geredet. Die Reparatur wird in jedem Fall sachgerecht durchgeführt; denn zu den freiwilligen Mitarbeitern von Repair-Cafés gehören Handwerksmeister der unterschiedlichsten Fachrichtungen.",
          "answer": "j",
          "explanation": "In Repair-Cafés reparieren Besucher gemeinsam mit ehrenamtlichen Fachleuten defekte Alltagsgeräte ('Gemeinsam kaputte Geräte retten')."
        },
        {
          "num": 5,
          "text": "Viele Menschen sind erstaunlich großzügig: Sie machen anderen gern Geschenke, spenden Geld für gute Zwecke oder opfern Zeit für ehrenamtliche Tätigkeiten. Aber was motiviert sie dazu? Die Wissenschaft liefert ganz unterschiedliche Erklärungsansätze. Eine Erklärung lautet, dass großzügige Menschen auf Gegenseitigkeit hoffen: Wer viel gibt, bekommt auch viel zurück. Eine Studie konnte nun aber zeigen, dass die Antwort vielleicht ganz einfach ist: Großzügigkeit mache eben glücklich. Dies fanden Forscher der Universität Lübeck heraus. Diese enge Verknüpfung zwischen großzügigem Verhalten und Glücksgefühl zeige sich auch im Gehirn. So aktiviere ein solches Verhalten ein Hirnareal, das eng mit unserem Belohnungszentrum verknüpft ist. Das Ergebnis ihrer Studie könne weitreichende Folgen für die Gesellschaft haben. Wer glücklicher werden möchte, könne sich diese neuen Erkenntnisse zunutze machen: Denn wer für andere da ist, tut auch etwas für das eigene Wohlbefinden.",
          "answer": "a",
          "explanation": "Eine Lübecker Studie zeigt, dass Großzügigkeit, Spenden und ehrenamtlicher Einsatz für andere das Belohnungszentrum im Gehirn aktivieren ('Wer Engagement zeigt, steigert sein Glücksgefühl')."
        }
      ]
    },
    {
      "id": "29",
      "title": "Test 29 – Telefon, Handy & Urlaubsfotos",
      "isVariant": false,
      "headings": {
        "a": "Neue Kinderhandys auf den Markt gebracht",
        "b": "Profi-Tipps für bessere Urlaubsbilder",
        "c": "Moderne schnurlose Geräte vermindern die Strahlenbelastung",
        "d": "Mehr Mut zum Fotografieren",
        "e": "Handy im Ausland: aufpassen und tricksen!",
        "f": "Kinder-Überwachung für Eltern per Handy wird geplant",
        "g": "Tipps zum Telefonieren mit weniger Strahlung",
        "h": "Handy-TV zur Fußball-WM 2006",
        "i": "Der neue Euro-Tarif",
        "j": "Mobiler Fernsehgenuss wird zum Alltag"
      },
      "items": [
        {
          "num": 1,
          "text": "Vielen Menschen verursachen sie ein mulmiges Gefühl: Die meisten Schnurlos-Telefone strahlen auch dann, wenn man gar nicht telefoniert. Vor allem DECT-Geräte („Digital Enhanced Cordless Telecommunications“ – digital verbesserte schnurlose Kommunikation) sind deshalb in die Kritik geraten. Allmählich nehmen Hersteller die Bedenken ernst und bieten Geräte an, die das Bundesamt für Strahlenschutz (BfS) als „bedingt strahlungsarm“ einstuft. Stehen diese Telefone auf der Ladestation, wird die Sendeleistung von Handgerät und Basis abgeschaltet oder radikal vermindert. Voraussetzung: Nur ein Mobilteil ist angemeldet. Einige Modelle reduzieren die Strahlung auch, wenn man nahe der Basisstation telefoniert: Nur 25 Prozent Sendeleistung braucht das Siemens Gigaset E360 im Umkreis von fünf Metern, das AEG Fame 400 kommt mit rund 30 Prozent aus.",
          "answer": "c",
          "explanation": "Neue Schnurlostelefone schalten auf der Ladestation die Sendeleistung ab oder reduzieren sie im Nahbereich deutlich ('Moderne schnurlose Geräte vermindern die Strahlenbelastung')."
        },
        {
          "num": 2,
          "text": "Wenn Kinder ein Handy haben, dann ist das schön und gut. Doch was, wenn der Filius nicht drangeht? Wenn er möglicherweise etwas Besseres zu tun hat, als zurückzurufen? Und noch schlimmer, wenn sich Heranwachsende im prüden Amerika schmutzige Bilder auf dem Handydisplay anschauen? Das schreit nach Kontrolle. Und genau die will Motorolas CEO Edward Zander den Eltern über ihre Kinder geben: Sie sollen jederzeit wissen, wo sie (oder deren Mobiltelefon) sind und was sie damit tun. Verbunden werden soll die Einführung von einem solchen Handy mit einer Reihe Merkmale, die junge Menschen ansprechen, wie zum Beispiel mit dem für nächsten Monat anvisierten Start des iTunes-Handys. „Handys sind heute das, was in meiner Jugend der Fernseher war“, so Zander. „Aber es gibt einen Weg, es sicher zu machen.“ Eltern müssten sich in die entstehende Jugendkultur rund um Handys stärker einbringen, und sie sollten sich stärker für das interessieren, was sie hören, sehen und lesen, so Zander weiter. Handys mit entsprechender Zensur-Software seien bereits in Vorbereitung.",
          "answer": "f",
          "explanation": "Motorola plant Handys mit Ortungs- und Zensur-Software, damit Eltern jederzeit kontrollieren können, wo ihre Kinder sind und was sie auf dem Handy tun ('Kinder-Überwachung für Eltern per Handy wird geplant')."
        },
        {
          "num": 3,
          "text": "Wer unter Palmen liegt, greift gern zum Handy. Doch trotz neuer Preisobergrenzen bleibt das ein teurer Spaß! Die Verbraucherzentrale Schleswig-Holstein erklärt, wie Sie richtig wählen. Bis 30. Juli müssen alle europäischen Mobilfunkanbieter den neuen „Eurotarif“ anbieten. Er gilt in allen EU-Staaten und schreibt Preislimits von maximal 49 Cent/Min. für eigene Anrufe bzw. maximal 24 Cent für ankommende Gespräche vor. Aber aufgepasst: Falle 1: kein Rabatt im Juli/August! Falle 2: Mehrwertsteuer! Zu den Kosten für abgehende bzw. angenommene Anrufe kommen noch 19 % Mehrwertsteuer dazu. Falle 3: Alte Sondertarife! Bis 20 Prozent der Handy-Nutzer haben Sonderverträge für Auslandsgespräche. Gefahr: Sie können den neuen Eurotarif nicht nutzen. Unbedingt informieren! Die besten Spar-Tricks: Prepaid-Karte – besonders für Viel-Telefonierer interessant. Zurzeit zahlen die meisten Kunden mit Vertrag mindestens 99 Cent pro angefangene Minute, mit Prepaid-Karte nur etwa 58 Cent. SMS schreiben: Im Vergleich zu Telefonaten sind Kurzmitteilungen (SMS) auch im Urlaub meistens günstiger.",
          "answer": "e",
          "explanation": "Die Verbraucherzentrale warnt vor Kostenfallen beim Telefonieren im EU-Ausland und gibt Spartricks wie Prepaid-Karten und SMS ('Handy im Ausland: aufpassen und tricksen!')."
        },
        {
          "num": 4,
          "text": "Manche Momente muss man einfach festhalten – mit einem Foto. Doch dessen Qualität hängt von vielen Faktoren ab: der Kamera, den Verhältnissen vor Ort und der Erfahrung des Fotografen. Für ein paar schöne Erinnerungsfotos sich aber eine teure Profi-Ausrüstung zuzulegen, lohnt selten. Vom Pauken schwieriger technischer Details ganz zu schweigen. Das ist heute auch längst nicht mehr nötig. Schon mit normalen Digitalkameras lassen sich wunderbare Bilder schießen – mit ein paar Tricks: Abwechslungsreiche Motivwahl: Die meisten Urlauber fotografieren gerne Sehenswürdigkeiten mit ihren Liebsten. Schaut man sich die Bilder später an, sind sie oft eine Variation des ewig Gleichen: der Sohn auf dem Kamel, vor der Kathedrale, im Pool. Der Sohn ist niedlich, keine Frage. Es kann jedoch nicht schaden, die Motive zu variieren: verschiedene Personen und Orte, zu unterschiedlichen Tageszeiten – mal den menschenleeren Strand, mal das Marktgetümmel. Nähe und Distanz: Mehr Abwechslung erreichen Sie auch, wenn Sie mit der Nähe zum Objekt spielen: hier eine Totale mit dem Weitwinkel, dort eine Nahaufnahme. Perspektive und Technik: Schnelle Schnappschüsse gelingen nicht immer. Nehmen Sie sich Zeit für Porträt- und Landschaftsaufnahmen. Nutzen Sie dabei auch den extra einstellbaren Modus bei Digitalkameras. Er stellt Objektiv und Belichtung perfekt auf die gewählte Variante ein. Licht und Schatten: Für stimmungsvolle Bilder eignen sich am besten Vormittags- und Spätnachmittagsstunden, weil das Licht dann besonders weich ist.",
          "answer": "b",
          "explanation": "Der Artikel gibt praktische Ratschläge zu Motivwahl, Perspektive und Licht für gelungene Urlaubsfotos ('Profi-Tipps für bessere Urlaubsbilder')."
        },
        {
          "num": 5,
          "text": "Es gibt in Deutschland wohl kaum eine bessere Chance für die Einführung von Handy-TV als die Fußball-WM 2006. Doch ein rechtzeitiger Start ist ungewiss. Die Problemfelder sind vielschichtig. Drei Standards kämpfen darum, das erste deutsche Mobilfernsehen zu sein: UMTS, DMB und DVB-H. Und das möglichst pünktlich zum 9. Juni 2006, dem Start der Fußball-WM. Dieser Dreikampf wird von Experten jedoch kritisch betrachtet. In Südostasien floriert dieser Markt doch schon seit vielen Monaten. In Korea beispielsweise gehört der mobile Fernsehgenuss zum Alltag. Bis zu zwei Stunden täglich schauen Besitzer der kleinen TV-Handys dort unterwegs auf die Mini-Mattscheibe. Warum sollte dies mittelfristig nicht auch in Deutschland realisierbar sein? In einem sind sich Experten jedoch sicher: Handy-TV wird die Fernsehbranche verändern. Kenner sprechen von drei neuen Prime Times (Hauptfernsehzeiten), die durch die mobile Glotze entstehen: der Weg zur Arbeit, die Mittagspause und der Heimweg. Dafür ist jedoch eine andere Art von Inhalten notwendig, vor allem kurz müssen sie sein, denn kaum jemand wird sich einen kompletten Spielfilm auf dem kleinen Bildschirm ansehen wollen.",
          "answer": "j",
          "explanation": "Während der Start zur WM noch ungewiss ist, ist Handy-TV in Ländern wie Korea bereits Alltag und wird auch hierzulande neue Hauptfernsehzeiten auf dem Arbeitsweg schaffen ('Mobiler Fernsehgenuss wird zum Alltag')."
        }
      ]
    },
    {
      "id": "30",
      "title": "Test 30 – Bionik & Überlebenskünstler in der Wüste",
      "isVariant": false,
      "headings": {
        "a": "Das Geheimnis des schnellen Schwimmens",
        "b": "Extremer Lebensraum",
        "c": "Fische im Fokus der Forscher von der Technischen Universität in Berlin",
        "d": "Wie wird Technik in der Natur eingesetzt?",
        "e": "Bioniker erforschen die Wüstennatur",
        "f": "Ein Fisch in den Dünen",
        "g": "Die Ursachen für den Wassermangel",
        "h": "Rasante Flucht",
        "i": "Trinkwasser aus Nebel",
        "j": "Auf der Suche nach verborgenen Details"
      },
      "items": [
        {
          "num": 1,
          "text": "Willkommen in der Wüste. Die Sonne brennt gnadenlos. Endlose Weite. Nur Sand und Geröll, so weit das Auge reicht. Kein Baum, kein Strauch, kein noch so winziges Tier. Bilder wie diese kommen wohl den meisten in den Sinn, wenn sie an die Wüste denken. Doch diese Vorstellung stimmt nicht ganz. Denn so hart und lebensfeindlich die Bedingungen in der Wüste auch sind: Es gibt einige Überlebenskünstler, die es selbst hier schaffen, zu existieren. Um in der Wüste zu überleben, mussten sie sich im Laufe der Jahrmillionen perfekt an die harten Lebensbedingungen anpassen. Sie wurden zu ausgesprochenen Spezialisten. Zu Spezialisten, von denen Wissenschaftler jede Menge lernen können. Und so zieht es jedes Jahr Bioniker aus vielen Ländern der Erde in die entlegenen Wüsten der Welt – auf der Suche nach kleinen, aber wirksamen Tricks für das Leben in einer extremen Umgebung.",
          "answer": "b",
          "explanation": "Der Text beschreibt die extremen, lebensfeindlichen Bedingungen der Wüste und die perfekt angepassten Überlebenskünstler dort ('Extremer Lebensraum')."
        },
        {
          "num": 2,
          "text": "Denn Bioniker entwickeln technische Anlagen nach dem Vorbild der Natur – der Begriff Bionik setzt sich zusammen aus den Wörtern „Biologie“ und „Technik“. Ihre Aufgabe: die Pflanzen und Tiere erst genau beobachten, kleinste Details entdecken und deren Geheimnisse lüften. Warum kann ein Gecko an der Wand hochlaufen? Wie kann ein Kolibri rückwärts fliegen? Wenn die Bioniker die Abläufe verstanden haben, fängt der größte Teil ihrer Arbeit erst an. Dann versuchen sie, aus dem Gelernten eine technische Anwendung zu entwickeln. Auch die besonderen Eigenschaften von Wüstentieren eignen sich dafür, wie die folgenden Beispiele zeigen.",
          "answer": "j",
          "explanation": "Bioniker beobachten Tiere und Pflanzen ganz genau, um kleinste Details und Geheimnisse der Natur für technische Anwendungen zu entschlüsseln ('Auf der Suche nach verborgenen Details')."
        },
        {
          "num": 3,
          "text": "Der Sandfisch ist eigentlich gar kein Fisch, sondern eine kleine Echse. Doch seinen Namen hat er sich redlich verdient. Denn er kann ausgezeichnet schwimmen. Zwar nicht im Wasser, dafür aber umso besser im Sand der Sahara. Droht dem wenige Zentimeter großen Tier Gefahr, dann verschwindet es rasend schnell im Wüstensand, nur um Augenblicke später einige Meter entfernt wieder aufzutauchen. Was im Wasser jedes Kind beherrscht, scheint im Sand unmöglich. Doch nicht für den Sandfisch. Denn er hat ein winziges Geheimnis: Seine Haut erscheint nur auf den ersten Blick ganz glatt. Unter dem Mikroskop fanden Wissenschaftler der Technischen Universität (TU) Berlin winzige Grate auf seiner Haut, nur wenige Nanometer groß (ein Nanometer entspricht dem millionsten Teil eines Millimeters). Genau diese Grate verhindern, dass der Sand an der Haut des Sandfisches hängen bleibt. Die Forscher konnten es kaum glauben und bauten in ihrem Labor eine Oberfläche mit vergleichbarer Struktur nach. Und siehe da: An einer vollkommen glatten Oberfläche bleibt der Sand förmlich kleben, an der mit den kleinen Erhebungen findet er keinen Halt. Die Idee für eine technische Umsetzung dieser Oberfläche ließ nicht lange auf sich warten. So arbeiten die Forscher am Institut für Bionik und Evolutionstechnik der TU Berlin etwa an besonderen Leitungsrohren. Mit einer „Sandfisch-Haut“ im Inneren können die Rohre ein für alle Mal vor einer Verstopfung bewahrt werden.",
          "answer": "f",
          "explanation": "Vorgestellt wird der „Sandfisch“, eine Wüstenechse, die dank spezieller Hautstruktur durch den Sand der Sahara schwimmt ('Ein Fisch in den Dünen')."
        },
        {
          "num": 4,
          "text": "Das größte Problem aller Wüstenbewohner ist die Wasserbeschaffung. In allen Wüsten der Erde herrscht fast ständig akuter Wassermangel. In vielen fällt jahrelang kein einziger Regentropfen vom Himmel. In einigen Regionen der Atacama-Wüste in Südamerika soll es seit mehreren hundert Jahren keinen Niederschlag mehr gegeben haben. Der Nebeltrinker-Käfer hat seine ganz eigene Strategie gegen den Wassermangel entwickelt. Er lebt in der Namib-Wüste im Südwesten Afrikas. Viele Tage im Jahr krabbelt er emsig die Sanddünen hinauf, macht eine Art Kopfstand und wartet auf den Nebel, der vom Atlantik her über den Rand der Wüste zieht. Dabei senkt er den Kopf und hebt sein Hinterteil in die Höhe. Die Flüssigkeit des Nebels kondensiert an seinem nur anderthalb Zentimeter langen Körper und läuft über eine kleine Vertiefung auf seinem Rücken direkt in sein Maul. Hier liegt die technische Anwendung auf der Hand: Wassergewinnung aus Nebel. Tatsächlich wird diese Methode auch schon einige Jahre genutzt. In der Nähe des Dorfes El Tofo in Chile wurden sogenannte Nebelnetze errichtet. Pro Nebeltag kondensieren hier bis zu 11.000 Liter frisches Wasser an den Netzen – eine stolze Ausbeute.",
          "answer": "i",
          "explanation": "Nach dem Vorbild des Nebeltrinker-Käfers gewinnen Menschen in trockenen Regionen mit Nebelnetzen tausende Liter Wasser aus kondensierendem Nebel ('Trinkwasser aus Nebel')."
        },
        {
          "num": 5,
          "text": "Beispiel Nummer drei: die Räderspinne. Auch sie lebt in der Wüste Namib und wurde erst vor wenigen Jahren entdeckt. Die Wissenschaftler waren ziemlich verblüfft, als sie die ungewöhnliche Fluchtmethode des Achtbeiners sahen: einfach die Beine anwinkeln und dann wie ein Rad die Sanddünen hinunterrollen. Die Bioniker filmten die Spinne mehrmals und schauten sich das Video unzählige Male an. Dann war ihnen klar: Mit ihren Vorderbeinen stößt sich die Spinne während des Rollens immer wieder vom Boden ab. Dadurch kullert sie nicht einfach nur passiv den Abhang hinunter. Vielmehr kann sie durch diese Methode auf ihrer Flucht wieder ordentlich an Tempo zulegen. Doch welche technische Anwendung soll dabei herausspringen? Hier beweisen die Forscher Mut zur Vision: An der TU Berlin soll ein Mars-Auto entstehen, das im unwegsamen Gelände auf Beinen laufen und in besserem Gelände normal fahren kann.",
          "answer": "h",
          "explanation": "Die Räderspinne winkelt bei Gefahr ihre Beine an und rollt mit hohem Tempo wie ein Rad die Sanddünen hinunter ('Rasante Flucht')."
        }
      ]
    },
    {
      "id": "31",
      "title": "Test 31 – Kindergesundheit, Medizin & Ernährung",
      "isVariant": false,
      "headings": {
        "a": "Neue Richtlinie für Zertifizierung von Medikamenten für Kinder",
        "b": "Neue Verfahren in der Kinderheilkunde",
        "c": "Gefahren zu hohen Fernsehkonsums bei Kindern",
        "d": "Alternative Heilverfahren: Wie gut sind sie wirklich?",
        "e": "Naturkosmetik aus Geschwisterhand",
        "f": "Kinder bekommen immer mehr Medikamente",
        "g": "Studie: Schulkinder treiben zu wenig Sport",
        "h": "Schlechte Noten fürs Baby-TV",
        "i": "Kinder und Jugendliche: Risikofaktor Übergewicht",
        "j": "Neueste Forschungsergebnisse zur Wirkung von Ginseng"
      },
      "items": [
        {
          "num": 1,
          "text": "Fernsehen ist der Sprachentwicklung bei Kleinkindern nicht förderlich. Sie sind bunt und lustig, die Teletubbies, die am Bildschirm auch deutsche Kinder beglücken. Doch gute Sprachlehrer für Babys sind sie nicht – so das Ergebnis einer US-amerikanischen Studie. „Manche Eltern mögen davon träumen, dass ihre Kinder die ersten Worte beim Fernsehen lernen“, sagt eine Linguistin, „aber das funktioniert nicht.“ Die Kommunikationsexpertin hat 48 Kleinkinder im Alter von 5 bis 24 Monaten getestet. Zuerst bekamen sie Gegenstände zu Gesicht, für die sie noch keine Worte hatten – etwa einen Schraubenzieher. Für das gezeigte Objekt erfanden die Forscher dann ein Fantasiewort wie „Deet“. „Damit wollten wir sicherstellen, dass die Kinder den Begriff wirklich noch nie gehört hatten“, erklärt die Expertin. Dann wurde es fünfmal wiederholt – entweder in einem Teletubby-ähnlichen Video oder direkt von einer anwesenden Person. Nach kurzer Pause legten die Forscher ihren Probanden einige Gegenstände vor und forderten sie auf: „Zeig mir Deet.“ Babys, die das Wort direkt gelernt hatten, reagierten spätestens bei der dritten Wiederholung. Die jungen TV-Seher aber waren meist ratlos.",
          "answer": "h",
          "explanation": "Eine US-Studie beweist, dass Kleinkinder Wörter über das Fernsehen („Baby-TV“) im Gegensatz zum direkten Kontakt mit Personen kaum lernen ('Schlechte Noten fürs Baby-TV')."
        },
        {
          "num": 2,
          "text": "Pharmakologen am Universitätsklinikum Tübingen haben kürzlich bei einer Auswertung von 1,6 Millionen Rezeptverordnungen für Kinder und Jugendliche festgestellt, dass in gut 13 Prozent der Fälle das jeweils verschriebene Medikament gar nicht eigens für Kinder zugelassen war oder in einer für sie nicht getesteten Dosierung verwendet wurde. In Kinderkliniken sind etwa 50 Prozent, auf Intensivstationen für Neugeborene sogar bis zu 90 Prozent der verabreichten Medikamente nicht speziell für Kinder konzipiert. Noch bedenklicher: Je kleiner und je kränker ein Kind ist, desto mehr dieser „Off-Label“-Verordnungen hat es zu erwarten. Besonders bei den in Kliniken behandelten, ernsthafteren Krankheiten aber können die Ärzte oft gar nicht anders, als für Kinder nicht getestete Medikamente zu verabreichen. Da Kinder vergleichsweise selten schwer erkranken, sind die aufwendigen Testverfahren zur Herstellung altersspezifischer Medikamente für die Hersteller häufig wirtschaftlich uninteressant. Glücklicherweise ändert sich dieser Zustand durch eine EU-Verordnung, die seit Januar 2007 gilt: Demnach müssen alle in der Entwicklung befindlichen Medikamente, die für Kinder und Jugendliche in Betracht kommen, auch an ihnen geprüft werden. Für bereits zugelassene Präparate gibt es finanzielle Anreize, sie nachträglich an jungen Altersgruppen zu erproben. Geprüfte Medikamente erhalten dann den Packungsaufdruck: „Für Kinder geprüft.“",
          "answer": "a",
          "explanation": "Eine EU-Verordnung schreibt vor, dass neue Medikamente, die für Kinder infrage kommen, gezielt an ihnen geprüft und zertifiziert werden müssen ('Neue Richtlinie für Zertifizierung von Medikamenten für Kinder')."
        },
        {
          "num": 3,
          "text": "Alternative Heilverfahren können vor allem bei leichten Erkrankungen hilfreich sein. Dabei gilt es, Nützliches von Scharlatanerie zu unterscheiden. Viele sprechen noch von „alternativer“ Heilkunde. Doch inzwischen ist für die etwa 400 Heilverfahren jenseits der Schulmedizin der Ausdruck „Komplementärmedizin“ üblich geworden. Denn die Akupunkteure, Aromatherapeuten, anthroposophischen Mediziner, Pflanzenheilkundler, Homöopathen und viele andere begreifen ihre besonderen Methoden meist als Ergänzung der herkömmlichen Medizin und nicht als deren Ersatz. In dieser Funktion ist die Komplementärmedizin heute weithin akzeptiert. Auch in der Kinderheilkunde sind die Verfahren beliebt. Ob sie wirksam sind, lässt sich mithilfe klinischer Studien überprüfen. Die aber sind aufwendig und teuer, weshalb es oft an wissenschaftlichen Wirksamkeitsnachweisen mangelt. Sicher nachgewiesen ist vor allem die Wirksamkeit von Pflanzenpräparaten. Mehr Forschung auf dem Gebiet der Komplementärmedizin könnte verhindern, dass mancher vielleicht nützliche Behandlungsansatz den Schulmedizinern völlig aus dem Blick gerät. Und einige Ärzte sollten vielleicht darüber nachdenken, was ein Kenner jener Szene vor einiger Zeit auf einem Kongress des Berufsverbandes der Kinder- und Jugendärzte gesagt hat: Das Erfolgsgeheimnis der Anbieter nicht-konventioneller Methoden beruhe vor allem darauf, dass sie den Eltern das Gefühl vermittelten, „endlich einmal ernst genommen zu werden“.",
          "answer": "d",
          "explanation": "Der Text beleuchtet den Nutzen, die Verbreitung und die wissenschaftliche Überprüfung komplementärmedizinischer Verfahren ('Alternative Heilverfahren: Wie gut sind sie wirklich?')."
        },
        {
          "num": 4,
          "text": "Die eine liebt Flora und Fauna, die andere hat ein Händchen für Kommunikation und Marketing: Zusammen betreiben die Schwestern Henrike Rodemeier und Gesine Wischmann Deutschlands einzige Ginseng-Farm im niedersächsischen Bockhorn. Als studierte Agraringenieurin ist die 38-jährige Rodemeier für den Anbau zuständig. Die vier Jahre ältere Schwester vertreibt über ihre Firma Florafarm die aus den Wurzeln gewonnenen Arzneimittel. Zudem entwickelte die gelernte Pharmareferentin eine eigene Ginseng-Kosmetiklinie. Den Anfang hatte ihr Vater Heinrich Wischmann bereits vor 24 Jahren gemacht: Er gab die unrentable traditionelle Landwirtschaft auf und konzentrierte sich auf den Anbau von Ginsengwurzeln, die unter anderem das Immunsystem stärken und den Blutdruck regulieren. Trotz Ruhestand ist auch er noch auf der Farm aktiv. Doch die Zukunft gehört den Töchtern – die planen bereits eine Dependance.",
          "answer": "e",
          "explanation": "Zwei Schwestern betreiben gemeinsam Deutschlands einzige Ginseng-Farm und vertreiben eine eigene Ginseng-Kosmetiklinie ('Naturkosmetik aus Geschwisterhand')."
        },
        {
          "num": 5,
          "text": "Kinder essen zu viel Fast Food, aber zu wenig Obst und Gemüse, so eine Expertin vom Deutschen Institut für Ernährungsmedizin und Diätetik (D.I.E.T.) in Bad Aachen. Nach Angabe der Deutschen Gesellschaft für Ernährung sind 10 bis 20 Prozent aller Schulkinder und Jugendlichen übergewichtig, Tendenz steigend. Übergewicht kann schon im frühen Alter zu Folgeerkrankungen wie Hypertonie, Fettstoffwechselstörungen, Diabetes oder Gallensteinleiden führen. Zu den Ursachen gehören eine oftmals zu hohe tägliche Energie- und Fettzufuhr und mangelnde Bewegung. Gerade bei einer genetischen Vorbelastung führt das zu einer Zunahme der Fettmasse des Körpers. Das D.I.E.T. rät daher allen Eltern, ihren Kindern von klein auf eine gesunde Kost zu bieten. Durch einen regelmäßigen Mahlzeitenrhythmus im Tagesablauf kann außerdem unkontrolliertes „Zwischendurchessen“ vermieden werden. Ein kompletter Verzicht auf Süßes ist aus psychologischen Gründen nicht empfehlenswert, ein vernünftiger Umgang mit Süßigkeiten muss erlernt werden. Durch vermehrte körperliche Aktivität wird der Energieverbrauch erhöht. Eltern sollten versuchen, bei ihren Kindern sportliche Interessen zu wecken und Hobbys zu fördern.",
          "answer": "i",
          "explanation": "10 bis 20 Prozent der Schulkinder sind durch Fast Food und Bewegungsmangel übergewichtig, was schon früh zu schweren Folgeerkrankungen führen kann ('Kinder und Jugendliche: Risikofaktor Übergewicht')."
        }
      ]
    },
    {
      "id": "32",
      "title": "Test 32 – Urlaub, Natur & Engagement",
      "isVariant": false,
      "headings": {
        "a": "Am Strand im Dienst: mehr Sicherheit für Urlauber",
        "b": "Bäder, Seen und Natur – im hessischen Paradies",
        "c": "Freiheit und Natur – nach sechs Wochen harter Arbeit",
        "d": "Jugendliche arbeiten für Jugendliche",
        "e": "Kinderarbeit in Deutschland: Jugendliche werden zur Arbeit gezwungen",
        "f": "Nach harter Arbeit durch nordische Gewässer",
        "g": "Schaden an Kreuzfahrtschiff verhindert Weiterfahrt",
        "h": "Urlaub an deutschen Seen immer gefährlicher",
        "i": "Wegen Niedrigwasser: vom Fluss auf die Straße",
        "j": "Zu Gast bei den Fürsten"
      },
      "items": [
        {
          "num": 1,
          "text": "Entdecken Sie interessante Städte und Regionen. Im Herzen Deutschlands liegen wunderbare Landschaften, mit einem für deutsche Verhältnisse sehr milden Klima – und keine typischen Touristenziele. Von der Stadt Gießen ausgehend kann man in den hessischen Kreisen Bergstraße und Waldeck-Frankenberg viele Orte entdecken, die noch ein Geheimtipp sind. Vor allem gilt dies für den Kreis Waldeck-Frankenberg. Wer nicht gerade in Hessen wohnt, wird kaum wissen, wo diese Region eigentlich liegt. Es ist ein herrliches Stück Deutschland ohne besonders große Städte, eine Gegend, die Natur pur bietet. Daher wundert es nicht, dass man hier einige Kurorte findet wie Bad Arolsen oder Bad Wildungen oder den Luftkurort Edertal-Kleinern. Apropos Edertal: Der zwölf Quadratkilometer große Edersee gehört zu den „vier schönen blauen Augen“ des Kreises. Der Landkreis Waldeck-Frankenberg ist Hessens attraktivstes Umland. In der Region der Berge und Seen spürt man auch heute noch einen Hauch von Fürstlichkeit: Majestätisch erhebt sich über dem Edersee das Schloss Waldeck. Auch in Bad Arolsen, einer ehemaligen Residenzstadt, ist vieles noch vom früheren Adel geprägt. Unbedingt besuchen sollte man darüber hinaus das über 1000 Jahre alte Korbach wie auch die Fachwerkstadt Frankenberg.",
          "answer": "b",
          "explanation": "Der hessische Landkreis Waldeck-Frankenberg lockt mit unberührter Natur, dem Edersee und Kurorten wie Bad Arolsen und Bad Wildungen ('Bäder, Seen und Natur – im hessischen Paradies')."
        },
        {
          "num": 2,
          "text": "Pferde waren schon immer Melanie Schilles Leidenschaft. „Und jetzt kann ich Hobby und Beruf miteinander verbinden“, freut sich die Beamtin aus Hannover. In diesem Jahr verstärkt sie die Strandwache an der Nordseeküste. Ihr Arbeitsplatz ist der Strand: Mit „Magnus“, einem 11-jährigen Pferd, patrouilliert sie dort, wo die Kleinen Sandburgen bauen, Urlauber bei einem Buch entspannen oder sich in die kühlen Fluten stürzen. Melanie Schille und ihr Hannoveraner sind eine Attraktion in dem Ferienort. Immer wieder wollen Gäste das Tier streicheln, von der Polizistin wissen, was sie hier macht. „Wir sorgen für mehr Sicherheit am Strand“, erklären Melanie Schille und Rüdiger Teichmann (42). Sie suchen im Watt nach Vermissten, klären über Gefahren auf, verhindern Diebstähle und Sachbeschädigungen. Nachweislich gingen die Delikte zurück, seit es die Streife hoch zu Ross gibt. Die Polizisten: „Wir sind in dem unwegsamen Gelände oft schneller am Einsatzort als die Kollegen per Fahrrad oder mit dem Auto. Außerdem schonen wir die Natur.“ Für sich persönlich sieht Melanie Schille noch einen großen Vorteil: „Es ist schön, mal keine Demonstration sichern zu müssen, stattdessen genieße ich die frische Luft mit fröhlichen Urlaubern.“ Nur eins vermisst die 22-Jährige, die mit Polizeipferd „Magnus“ auf einem Bauernhof Quartier bezogen hat, während ihres sechswöchigen Einsatzes: Freund Robert (23). Er fährt als Polizist in Hannover Streife und wartet auf sie.",
          "answer": "a",
          "explanation": "Die Reiterpolizistin Melanie Schille patrouilliert hoch zu Ross an der Nordseeküste und sorgt dort für den Schutz der Feriengäste ('Am Strand im Dienst: mehr Sicherheit für Urlauber')."
        },
        {
          "num": 3,
          "text": "Ein neuer Urlaubstrend setzt sich durch: Statt faul am Strand zu liegen, wird man aktiv. Ein besonders beliebtes Ziel ist Schweden: So kann man am Ufer des Flusses Klarälven in der Provinz Värmland selbst ein Floß bauen. Das dauert drei bis sechs Stunden, anschließend macht man darauf Urlaub. „Das ist Abenteuerurlaub pur“, schwärmt Johan Bengtson, der mit seiner Frau und den drei Kindern zum zweiten Mal Floßferien macht. „Sich auf dem Fluss treiben lassen und in der Wildnis leben – dieses Gefühl ist super!“ Seit zehn Jahren veranstaltet Marie Junler von der Agentur Vildmark i Värmland die Holzfloßtrips. Wir haben die Bengtsons an ihrem ersten Urlaubstag begleitet. Mit dabei ist auch Veranstalterin Marie Junler, die der Familie hilft, das Floß zu bauen. Es ist ein herrlicher Sonnentag. In einer sanften Kurve des Flusses Klarälven steht Marie bis zu den Hüften im tiefblauen Wasser. Mit dicken grünen Seilen schnürt sie Holzstämme zusammen und gibt Kommandos: Einer hält den Stamm, der andere knotet den Seemannsknoten, wie wir ihn vorhin an Land geübt haben. Ohne einen Nagel werden 96 Baumstämme verzurrt – im Wasser, sonst wäre das Holz zu schwer. Mindestens zwei Erwachsene sind nötig, um ein Floß zu bauen, einer allein packt das nicht. Nach drei Stunden ist es geschafft: Das Urlaubsparadies der Bengtsons – es misst übrigens 6 mal 3 Meter und wiegt 2 Tonnen – treibt am Ufer. Noch schnell das Sonnenzelt befestigen, darunter Vorratskasten, Frischwassertank, Chemie-Klo, Küchenausrüstung, Zelt, Rettungsring, Schwimmwesten und das Paddel zum Steuern und Manövrieren verstauen und ab geht's.",
          "answer": "f",
          "explanation": "In Schweden schnüren Urlauber in mehrstündiger körperlicher Arbeit 96 Baumstämme zu einem Floß zusammen und fahren damit anschließend den Fluss Klarälven hinunter ('Nach harter Arbeit durch nordische Gewässer')."
        },
        {
          "num": 4,
          "text": "Von 9 bis 15 Uhr arbeitet Sebastian Keller (18) in einem Altenwohnheim in Hamburg-Altona: Er kümmert sich um die Essensausgabe, putzt die Küche und dann ist noch Zeit, um den Senioren vorzulesen oder mit ihnen Karten zu spielen. Zur selben Zeit putzen Rebecca (12) und Christiane (13) den Eingang des „Hamburger Michels“, der wohl bekanntesten Kirche der Stadt, und Friederike (17) füttert schon frühmorgens Kühe, Schweine und Hühner auf einem Bio-Bauernhof bei Wedel. „Endlich mal ein sinnvoller Job“, sagen die fünf übereinstimmend. Sie stehen stellvertretend für etwa 100.000 Jugendliche, die beim „Sozialen Tag“ mitgemacht haben, Hut ab! Und was mindestens ebenso beeindruckend ist: Der Verein „Hamburgs Schüler helfen“ (HSH) wurde von Jugendlichen im Jahr 2004 gegründet und seitdem findet jedes Jahr im August der „Soziale Tag“ statt. Mit Behörden und Firmen haben Schüler aus Hamburg Verträge für einen Tag abgeschlossen. Die Schülerinnen und Schüler verdienen dann am „Sozialen Tag“ zwischen 6 und 8 Euro pro Stunde – aber nicht für sich selbst, sondern für andere. Denn der Verdienst wird gespendet. Die Jugendlichen wählen selbst ein Projekt aus, an das sie die Gelder spenden wollen. Einzige Bedingung: Es muss ein Projekt sein, von dem Jugendliche profitieren. Im letzten Jahr zum Beispiel wurde die Gesamtsumme von 1,2 Millionen Euro an das Projekt „Frieden für alle“ gespendet. Dessen Ziel ist es, Jugendliche in Kriegs- und Krisenregionen zu unterstützen, den Dialog unter Jugendlichen aus verschiedenen Ländern zu fördern und auch das Kennenlernen anderer Kulturen zu ermöglichen. Für Ralf Waldner (20) vom HSH steht fest: „Wir können und werden anderen auch in Zukunft helfen, das Engagement der Schülerinnen und Schüler in Hamburg ist in den letzten Jahren schließlich immer weiter gestiegen.“",
          "answer": "d",
          "explanation": "Beim Hamburger „Sozialen Tag“ arbeiten rund 100.000 Schülerinnen und Schüler einen Tag lang und spenden ihren Verdienst für Jugendprojekte in Krisenregionen ('Jugendliche arbeiten für Jugendliche')."
        },
        {
          "num": 5,
          "text": "Die Windjacken waren schon eingepackt, die Koffer geschlossen. Thomas Meurer (64) und Wiebke Fuchs (62) aus Hannover freuten sich auf ihre Flusskreuzfahrt mit der „MS Eurostar“ von Potsdam nach Prag. Stattliche 2500 Euro kostete die Reise pro Person, und beide hatten lange gespart, um sich das leisten zu können. Doch aus der Kreuzfahrt wurde eine Bustour. Meurer berichtet, was er erlebt hat: „Wir waren am Abend auf das Schiff gegangen und hatten unsere Kabinen bezogen. Am nächsten Morgen ging es los. Aber schon bald machte das Schiff wieder fest und alle Gäste mussten von Bord.“ Wiebke Fuchs ergänzt: „Der Fluss hatte einfach zu wenig Wasser, da konnten wir mit dem großen Kreuzfahrtschiff nicht weiterfahren!“ Per Bus ging es nach Prag. Beide wollen nun einen Teil des Reisepreises zurück, aber der Veranstalter Hapag-Lloyd wehrt ab: „Das war höhere Gewalt, da kann man nichts machen.“",
          "answer": "i",
          "explanation": "Da der Fluss zu wenig Wasser führte, mussten die Passagiere das Kreuzfahrtschiff verlassen und mit dem Bus weiter nach Prag reisen ('Wegen Niedrigwasser: vom Fluss auf die Straße')."
        }
      ]
    },
    {
      "id": "32a",
      "title": "Test 32a – Urlaub, Natur & Engagement (Variante)",
      "isVariant": true,
      "headings": {
        "a": "Schaden an Kreuzfahrtschiff verhindert Weiterfahrt",
        "b": "Bäder, Seen und Natur – im hessischen Paradies",
        "c": "Freiheit und Natur – nach sechs Wochen harter Arbeit",
        "d": "Jugendliche arbeiten für Jugendliche",
        "e": "Von der Polizeiwache an die See – sichere Strände für Urlauber",
        "f": "Urlaub an deutschen Seen immer gefährlicher",
        "g": "Kinderarbeit in Deutschland: Jugendliche werden zur Arbeit gezwungen",
        "h": "Nach harter Arbeit durch nordische Gewässer",
        "i": "Zu Gast bei den Fürsten",
        "j": "Wegen Niedrigwasser: Vom Fluss auf die Straße"
      },
      "items": [
        {
          "num": 1,
          "text": "Entdecken Sie interessante Städte und Regionen. Im Herzen Deutschlands liegen wunderbare Landschaften, mit einem für deutsche Verhältnisse sehr milden Klima – und keine typischen Touristenziele. Von der Stadt Gießen ausgehend kann man in den hessischen Kreisen Bergstraße und Waldeck-Frankenberg viele Orte entdecken, die noch ein Geheimtipp sind. Vor allem gilt dies für den Kreis Waldeck-Frankenberg. Wer nicht gerade in Hessen wohnt, wird kaum wissen, wo diese Region eigentlich liegt. Es ist ein herrliches Stück Deutschland ohne besonders große Städte, eine Gegend, die Natur pur bietet. Daher wundert es nicht, dass man hier einige Kurorte findet wie Bad Arolsen oder Bad Wildungen oder den Luftkurort Edertal-Kleinern. Apropos Edertal: Der zwölf Quadratkilometer große Edersee gehört zu den „vier schönen blauen Augen“ des Kreises. Der Landkreis Waldeck-Frankenberg ist Hessens attraktivstes Umland. In der Region der Berge und Seen spürt man auch heute noch einen Hauch von Fürstlichkeit: Majestätisch erhebt sich über dem Edersee das Schloss Waldeck. Auch in Bad Arolsen, einer ehemaligen Residenzstadt, ist vieles noch vom früheren Adel geprägt. Unbedingt besuchen sollte man darüber hinaus das über 1000 Jahre alte Korbach wie auch die Fachwerkstadt Frankenberg.",
          "answer": "b",
          "explanation": "Der hessische Landkreis Waldeck-Frankenberg lockt mit unberührter Natur, dem Edersee und Kurorten wie Bad Arolsen und Bad Wildungen ('Bäder, Seen und Natur – im hessischen Paradies')."
        },
        {
          "num": 2,
          "text": "Pferde waren schon immer Melanie Schilles Leidenschaft. „Und jetzt kann ich Hobby und Beruf miteinander verbinden“, freut sich die Beamtin aus Hannover. In diesem Jahr verstärkt sie die Strandwache an der Nordseeküste. Ihr Arbeitsplatz ist der Strand: Mit „Magnus“, einem 11-jährigen Pferd, patrouilliert sie dort, wo die Kleinen Sandburgen bauen, Urlauber bei einem Buch entspannen oder sich in die kühlen Fluten stürzen. Melanie Schille und ihr Hannoveraner sind eine Attraktion in dem Ferienort. Immer wieder wollen Gäste das Tier streicheln, von der Polizistin wissen, was sie hier macht. „Wir sorgen für mehr Sicherheit am Strand“, erklären Melanie Schille und Rüdiger Teichmann (42). Sie suchen im Watt nach Vermissten, klären über Gefahren auf, verhindern Diebstähle und Sachbeschädigungen. Nachweislich gingen die Delikte zurück, seit es die Streife hoch zu Ross gibt. Die Polizisten: „Wir sind in dem unwegsamen Gelände oft schneller am Einsatzort als die Kollegen per Fahrrad oder mit dem Auto. Außerdem schonen wir die Natur.“ Für sich persönlich sieht Melanie Schille noch einen großen Vorteil: „Es ist schön, mal keine Demonstration sichern zu müssen, stattdessen genieße ich die frische Luft mit fröhlichen Urlaubern.“ Nur eins vermisst die 22-Jährige, die mit Polizeipferd „Magnus“ auf einem Bauernhof Quartier bezogen hat, während ihres sechswöchigen Einsatzes: Freund Robert (23). Er fährt als Polizist in Hannover Streife und wartet auf sie.",
          "answer": "e",
          "explanation": "Die Reiterpolizistin Melanie Schille patrouilliert hoch zu Ross an der Nordseeküste und sorgt dort für den Schutz der Feriengäste ('Von der Polizeiwache an die See – sichere Strände für Urlauber')."
        },
        {
          "num": 3,
          "text": "Ein neuer Urlaubstrend setzt sich durch: Statt faul am Strand zu liegen, wird man aktiv. Ein besonders beliebtes Ziel ist Schweden: So kann man am Ufer des Flusses Klarälven in der Provinz Värmland selbst ein Floß bauen. Das dauert drei bis sechs Stunden, anschließend macht man darauf Urlaub. „Das ist Abenteuerurlaub pur“, schwärmt Johan Bengtson, der mit seiner Frau und den drei Kindern zum zweiten Mal Floßferien macht. „Sich auf dem Fluss treiben lassen und in der Wildnis leben – dieses Gefühl ist super!“ Seit zehn Jahren veranstaltet Marie Junler von der Agentur Vildmark i Värmland die Holzfloßtrips. Wir haben die Bengtsons an ihrem ersten Urlaubstag begleitet. Mit dabei ist auch Veranstalterin Marie Junler, die der Familie hilft, das Floß zu bauen. Es ist ein herrlicher Sonnentag. In einer sanften Kurve des Flusses Klarälven steht Marie bis zu den Hüften im tiefblauen Wasser. Mit dicken grünen Seilen schnürt sie Holzstämme zusammen und gibt Kommandos: Einer hält den Stamm, der andere knotet den Seemannsknoten, wie wir ihn vorhin an Land geübt haben. Ohne einen Nagel werden 96 Baumstämme verzurrt – im Wasser, sonst wäre das Holz zu schwer. Mindestens zwei Erwachsene sind nötig, um ein Floß zu bauen, einer allein packt das nicht. Nach drei Stunden ist es geschafft: Das Urlaubsparadies der Bengtsons – es misst übrigens 6 mal 3 Meter und wiegt 2 Tonnen – treibt am Ufer. Noch schnell das Sonnenzelt befestigen, darunter Vorratskasten, Frischwassertank, Chemie-Klo, Küchenausrüstung, Zelt, Rettungsring, Schwimmwesten und das Paddel zum Steuern und Manövrieren verstauen und ab geht's.",
          "answer": "h",
          "explanation": "In Schweden schnüren Urlauber in mehrstündiger körperlicher Arbeit 96 Baumstämme zu einem Floß zusammen und fahren damit anschließend den Fluss Klarälven hinunter ('Nach harter Arbeit durch nordische Gewässer')."
        },
        {
          "num": 4,
          "text": "Von 9 bis 15 Uhr arbeitet Sebastian Keller (18) in einem Altenwohnheim in Hamburg-Altona: Er kümmert sich um die Essensausgabe, putzt die Küche und dann ist noch Zeit, um den Senioren vorzulesen oder mit ihnen Karten zu spielen. Zur selben Zeit putzen Rebecca (12) und Christiane (13) den Eingang des „Hamburger Michels“, der wohl bekanntesten Kirche der Stadt, und Friederike (17) füttert schon frühmorgens Kühe, Schweine und Hühner auf einem Bio-Bauernhof bei Wedel. „Endlich mal ein sinnvoller Job“, sagen die fünf übereinstimmend. Sie stehen stellvertretend für etwa 100.000 Jugendliche, die beim „Sozialen Tag“ mitgemacht haben, Hut ab! Und was mindestens ebenso beeindruckend ist: Der Verein „Hamburgs Schüler helfen“ (HSH) wurde von Jugendlichen im Jahr 2004 gegründet und seitdem findet jedes Jahr im August der „Soziale Tag“ statt. Mit Behörden und Firmen haben Schüler aus Hamburg Verträge für einen Tag abgeschlossen. Die Schülerinnen und Schüler verdienen dann am „Sozialen Tag“ zwischen 6 und 8 Euro pro Stunde – aber nicht für sich selbst, sondern für andere. Denn der Verdienst wird gespendet. Die Jugendlichen wählen selbst ein Projekt aus, an das sie die Gelder spenden wollen. Einzige Bedingung: Es muss ein Projekt sein, von dem Jugendliche profitieren. Im letzten Jahr zum Beispiel wurde die Gesamtsumme von 1,2 Millionen Euro an das Projekt „Frieden für alle“ gespendet. Dessen Ziel ist es, Jugendliche in Kriegs- und Krisenregionen zu unterstützen, den Dialog unter Jugendlichen aus verschiedenen Ländern zu fördern und auch das Kennenlernen anderer Kulturen zu ermöglichen. Für Ralf Waldner (20) vom HSH steht fest: „Wir können und werden anderen auch in Zukunft helfen, das Engagement der Schülerinnen und Schüler in Hamburg ist in den letzten Jahren schließlich immer weiter gestiegen.“",
          "answer": "d",
          "explanation": "Beim Hamburger „Sozialen Tag“ arbeiten rund 100.000 Schülerinnen und Schüler einen Tag lang und spenden ihren Verdienst für Jugendprojekte in Krisenregionen ('Jugendliche arbeiten für Jugendliche')."
        },
        {
          "num": 5,
          "text": "Die Windjacken waren schon eingepackt, die Koffer geschlossen. Thomas Meurer (64) und Wiebke Fuchs (62) aus Hannover freuten sich auf ihre Flusskreuzfahrt mit der „MS Eurostar“ von Potsdam nach Prag. Stattliche 2500 Euro kostete die Reise pro Person, und beide hatten lange gespart, um sich das leisten zu können. Doch aus der Kreuzfahrt wurde eine Bustour. Meurer berichtet, was er erlebt hat: „Wir waren am Abend auf das Schiff gegangen und hatten unsere Kabinen bezogen. Am nächsten Morgen ging es los. Aber schon bald machte das Schiff wieder fest und alle Gäste mussten von Bord.“ Wiebke Fuchs ergänzt: „Der Fluss hatte einfach zu wenig Wasser, da konnten wir mit dem großen Kreuzfahrtschiff nicht weiterfahren!“ Per Bus ging es nach Prag. Beide wollen nun einen Teil des Reisepreises zurück, aber der Veranstalter Hapag-Lloyd wehrt ab: „Das war höhere Gewalt, da kann man nichts machen.“",
          "answer": "j",
          "explanation": "Da der Fluss zu wenig Wasser führte, mussten die Passagiere das Kreuzfahrtschiff verlassen und mit dem Bus weiter nach Prag reisen ('Wegen Niedrigwasser: Vom Fluss auf die Straße')."
        }
      ]
    },
    {
      "id": "33",
      "title": "Test 33 – Frauen im Beruf, Ernährung & Ausbildung",
      "isVariant": false,
      "headings": {
        "a": "Schlechtere Chancen für Frauen am Arbeitsmarkt",
        "b": "Schnell essen macht dick",
        "c": "Neue Broschüre: Studieren im Ausland",
        "d": "Was tun nach der Schule? Neue Ausbildungsmöglichkeiten",
        "e": "Initiative: Frauen für Männerberufe begeistern",
        "f": "Immer mehr Frauen machen Karriere im technischen Bereich",
        "g": "Experiment in Florida: Schlank in zwölf Stunden",
        "h": "Ernährungstipps kostenlos am Telefon",
        "i": "Schweizer Frauen kämpfen für mehr Rechte im Beruf",
        "j": "Wissenschaftler warnen: Immer mehr dicke Mädchen in Österreich!"
      },
      "items": [
        {
          "num": 1,
          "text": "Ein hochwertiger Schulabschluss gilt gemeinhin als Schlüssel zum Berufsein- und -aufstieg. Das ist aber nur bedingt richtig, denn sonst hätten die Frauen auf dem Arbeitsmarkt längst die Nase vorn. Mehr als die Hälfte aller Absolventen an höheren Schulen ist weiblich. Trotz besserer Qualifikation haben Frauen aber das Nachsehen. Zu diesem Schluss kommt eine Untersuchung des städtischen Frauenreferates zur Ausbildungssituation von Frauen und Mädchen in Frankfurt. Eine Erklärung für die schlechte Lage von weiblichen Arbeitskräften ist aber auch die Tatsache, dass Frauen nach wie vor für Familie und Kindererziehung auf Karriere verzichten.",
          "answer": "a",
          "explanation": "Trotz besserer Schulabschlüsse haben Frauen laut einer Frankfurter Untersuchung auf dem Arbeitsmarkt das Nachsehen ('Schlechtere Chancen für Frauen am Arbeitsmarkt')."
        },
        {
          "num": 2,
          "text": "Übergewicht könnte erheblich durch Krankheiten, aber auch durch falsche Essgewohnheiten bedingt sein. Psychiater der Universität Florida haben jetzt das schnelle Essen als mögliche Ursache für Fettleibigkeit entdeckt. Die Wissenschaftler untersuchten, was genau im Hirn bei der Nahrungsaufnahme passiert. Zu diesem Zweck bekamen Testpersonen nach einer zwölfstündigen Fastenzeit eine Zuckerlösung zu trinken. Zuerst zeigte sich verstärkte Gehirntätigkeit, ausgelöst durch Schlucken, Geruch und Geschmack. Dann, zehn Minuten später, signalisierte das Gehirn, dass der Körper genug habe. Bei Menschen, die zu schnell essen, ist dieses Signal stark verzögert. Daher dürfte das Sprichwort „Iss langsam, Kind!“ tatsächlich eine Weisheit sein.",
          "answer": "b",
          "explanation": "Forscher der Universität Florida stellten fest, dass bei schnellem Essen das Sättigungssignal im Gehirn stark verzögert eintritt und so Übergewicht fördert ('Schnell essen macht dick')."
        },
        {
          "num": 3,
          "text": "Wenn Sie mehr über richtige Ernährung und das ideale Gewicht wissen wollen, informieren Sie der „Fonds Gesundes Österreich“ und der Verein für Konsumenteninformation. Unter 0810 810 27 werden gratis firmenunabhängige, wissenschaftlich fundierte Informationen über ausgewogene und gesunde Ernährung angeboten. Die Verantwortlichen reagieren damit auf den erschreckenden Trend, dass die Zahl der dicken Menschen, darunter vor allem Kinder, immer mehr zunimmt. In den vergangenen 15 Jahren habe sich die Zahl übergewichtiger Kinder und Jugendlicher mehr als verdoppelt. Bewegungsmangel und fettes Essen seien die Hauptgründe dafür.",
          "answer": "h",
          "explanation": "Unter einer Hotline bieten der „Fonds Gesundes Österreich“ und der Verein für Konsumenteninformation kostenlose telefonische Beratung zu gesunder Ernährung an ('Ernährungstipps kostenlos am Telefon')."
        },
        {
          "num": 4,
          "text": "Das Arbeitsamt Berlin hat seine beiden Informationshefte „Alternative zum Studium“ neu aufgelegt. Auf 200 Seiten zeigt die Behörde neue Ausbildungsmöglichkeiten für junge Frauen und Männer nach der Schule außerhalb der Universitäten. Ein Heft befasst sich mit betriebswirtschaftlichen Ausbildungen bzw. fremdsprachlichen Angeboten im sozialen Bereich, das andere mit dem technisch-naturwissenschaftlichen Bereich. Mit diesen Broschüren geht auch eine Informationswoche einher, die die hohe Zahl an Studienbewerbern in Deutschland reduzieren helfen und andere Wege einer guten Berufsausbildung für junge Leute aufzeigen soll.",
          "answer": "d",
          "explanation": "Das Arbeitsamt Berlin informiert mit den Broschüren „Alternative zum Studium“ Schulabgänger über neue Berufsausbildungen außerhalb der Hochschulen ('Was tun nach der Schule? Neue Ausbildungsmöglichkeiten')."
        },
        {
          "num": 5,
          "text": "Junge Frauen in der Schweiz sollen nun mehr Chancen für eine offene Berufswahl haben. Mit einer Motivationskampagne wollen die Fachleute zum Umdenken anregen und neue Horizonte öffnen. „Von wem würden Sie lieber Ihr Auto reparieren lassen?“ oder „Wem vertrauen Sie eher eine Herzoperation an?“, heißt es unter jeweils zwei Porträts einer Frau und eines Mannes. Die Plakate sollen für den „kleinen Unterschied“ im Kopf sensibilisieren, wonach Frauen nicht dasselbe zugetraut wird wie Männern. Immer noch ergreifen junge Frauen typische Frauenberufe wie Textilverkäuferin oder Sekretärin. Mit einem Internetwettbewerb soll das Thema „Frauen und Technik“ fokussiert werden, im Speziellen der Informationssektor, der in der Schweiz noch ganz in Männerhand ist.",
          "answer": "e",
          "explanation": "Eine Schweizer Kampagne will junge Frauen motivieren, technische und bislang männerdominierte Berufe zu ergreifen ('Initiative: Frauen für Männerberufe begeistern')."
        }
      ]
    },
    {
      "id": "34",
      "title": "Test 34 – Stürme & Wettervorhersage",
      "isVariant": false,
      "headings": {
        "a": "Eine ungewöhnliche Geschenkidee",
        "b": "Gut informiert mit neuer Wetter-App",
        "c": "Heftiger Sturm sorgt für Verkehrschaos in Deutschland",
        "d": "Junge Erfinder zeigen ihr Können",
        "e": "Kostenlose Wetter-Apps sind nicht empfehlenswert",
        "f": "Präzise Vorhersage von Stürmen durch neue Messinstrumente",
        "g": "Schüler erfinden App und gewinnen Wettbewerb",
        "h": "Sturm richtet schwere Schäden an Flughäfen an",
        "i": "Vorhersage von Stürmen ist schwierig",
        "j": "Warum Tiefs immer weibliche Namen haben"
      },
      "items": [
        {
          "num": 1,
          "text": "Kyrill, Friederike, Lothar oder Xaver – all dies sind Namen von Stürmen, die in Deutschland und Europa in den vergangenen Jahrzehnten für Schlagzeilen gesorgt haben. Aber wie kommen Stürme eigentlich zu ihren Namen? Die Antwort auf diese Frage findet man beim Institut für Meteorologie in Berlin. Hier werden bereits seit 1954 Namen für alle Hoch- und Tiefdruckgebiete vergeben, die das Wetter in Deutschland mitbestimmen. Zunächst hatten alle Tiefs weibliche Namen und alle Hochs männliche. Seit Ende der 90er-Jahre wird abgewechselt: In einigen Jahren tragen die Tiefs männliche Namen, in anderen weibliche. Seit 2002 haben alle Bürgerinnen und Bürger außerdem eine ganz besondere Möglichkeit: Sie können ein Hoch oder ein Tief „kaufen“, ihm einen Namen geben oder es sogar verschenken. Der Deutsche Wetterdienst und die Medien übernehmen diesen Namen dann und verwenden ihn in den Wetterberichten. So können Sie einem lieben Menschen eine originelle Überraschung bereiten oder sich selbst eine Freude machen.",
          "answer": "a",
          "explanation": "Beim Institut für Meteorologie in Berlin kann man die Namenspatenschaft für ein Hoch- oder Tiefdruckgebiet kaufen und als originelle Überraschung verschenken ('Eine ungewöhnliche Geschenkidee')."
        },
        {
          "num": 2,
          "text": "Der Jugendwettbewerb „Naturwissenschaft & Technik“ geht in die nächste Runde. Auch in diesem Jahr haben Schülerinnen und Schüler wieder die Möglichkeit, ihre Erfindungen der Öffentlichkeit zu präsentieren. Eine Jury bewertet die Wettbewerbsbeiträge und wählt die fünf besten aus. Auch das Publikum vor Ort darf abstimmen und einen „Publikumsliebling“ wählen. Insgesamt sind Sachpreise im Wert von 3000 Euro zu gewinnen, gesponsert von Unternehmen aus der Region. Teilnehmen können Schülerteams aller Schularten ab der fünften Klasse. Mit dabei ist diesmal auch ein Team des Thomas-Mann-Gymnasiums in Neustadt. Die Oberstufe hat eine neue Wetter-App entwickelt, mit der sie in diesem Jahr die Jury und das Publikum überzeugen möchte. Der Schulleiter des Thomas-Mann-Gymnasiums, Bernd Giesinger, ist stolz auf die Schülerinnen und Schüler: „Ich freue mich sehr über das Engagement dieser jungen Menschen, die ihre Zeit und Kreativität nutzen, um unsere gemeinsame Zukunft zu gestalten.“",
          "answer": "d",
          "explanation": "Beim Jugendwettbewerb „Naturwissenschaft & Technik“ präsentieren Schülerteams der Öffentlichkeit ihre Erfindungen ('Junge Erfinder zeigen ihr Können')."
        },
        {
          "num": 3,
          "text": "Am gestrigen Abend fegte Sturmtief Charlotte über Deutschland hinweg und legte große Teile des Landes lahm. Mit Spitzengeschwindigkeiten von 140 Kilometern pro Stunde sei Charlotte einer der stärksten Stürme der vergangenen Jahre, sagte Meteorologe Andreas Fischer. Insbesondere in Hessen, Nordrhein-Westfalen und im Saarland sind wegen umgestürzter Bäume unzählige Straßen und Bahnstrecken blockiert. Viele Züge konnten gestern nicht mehr weiterfahren und Hunderte Bahnreisende saßen zum Teil bis spät in die Nacht auf freier Strecke fest. In Hessen wurde der Bahnverkehr zeitweise komplett eingestellt. An den Flughäfen Frankfurt, Düsseldorf und Köln/Bonn kam es zu zahlreichen Verspätungen und Flugausfällen. Ankommende Maschinen wurden teilweise zu anderen Flughäfen umgeleitet. Von dort gestaltete sich die Weiterfahrt für viele Reisende allerdings ebenfalls sehr schwierig. Die Aufräumarbeiten laufen derzeit auf Hochtouren und werden noch einige Zeit in Anspruch nehmen. Im Moment ist es noch nicht absehbar, wie lange es dauern wird, bis alle Strecken wieder frei sind.",
          "answer": "c",
          "explanation": "Sturmtief Charlotte blockierte Straßen und Bahnstrecken und führte zu zahlreichen Flugausfällen in Deutschland ('Heftiger Sturm sorgt für Verkehrschaos in Deutschland')."
        },
        {
          "num": 4,
          "text": "Soll ich einen Pullover anziehen oder reicht ein T-Shirt? Muss man einen Schirm mitnehmen oder braucht man eine Sonnenbrille? Jedes Smartphone hat heutzutage eine vorinstallierte Wetter-App, aber genaue Wettervorhersagen liefern die meisten nicht. Es gibt aber gute Alternativen. Wer einen zuverlässigen Wetterdienst für sein Smartphone oder Tablet sucht, ist mit der neuen App „Wetterwissen“ bestens beraten. Schon in der kostenlosen Version bietet die App umfangreiche Daten zur aktuellen Wetterlage, leicht verständliche Prognosen und Unwetterwarnungen. Der Regenradar zeigt Ihnen genau, wo sich Regenwolken bilden und ob diese in Ihre Richtung ziehen oder nicht. Für 1,99 Euro gibt es ein Premium-Abo mit zusätzlichen Wetter-Videos und Informationen zu Wintersport und Badewetter. Die App ist in der Premium-Version werbefrei, in der kostenlosen Version wird am unteren Rand Werbung eingeblendet, die viele Nutzer aber nicht als störend wahrnehmen. Die App punktet außerdem mit einem modernen Design und schafft es damit ganz klar in die Top 10 der Wetter-Apps.",
          "answer": "b",
          "explanation": "Die neue Smartphone-App „Wetterwissen“ überzeugt mit genauen Prognosen, Unwetterwarnungen und einem Regenradar ('Gut informiert mit neuer Wetter-App')."
        },
        {
          "num": 5,
          "text": "Zehn Jahre ist es her, dass sich aus einem scheinbar harmlosen Tiefdruckgebiet schnell und überraschend der gefährliche Sturm Tinka entwickelte, der in Norddeutschland immense Schäden anrichtete und als einer der teuersten Stürme in die Geschichte einging. Den Wetterdiensten wurde damals vorgeworfen, die Entwicklung des Tiefdruckgebietes nicht richtig berechnet und die Bevölkerung nicht rechtzeitig gewarnt zu haben. Obwohl die Messinstrumente immer präziser geworden sind, lassen sich manche Wetterereignisse wie zum Beispiel Gewitter und Stürme nur schwer vorhersagen. Ein Sturm kann von vielen Faktoren abhängig sein und entwickelt sich oft kurzfristig. Daher kann es passieren, dass die Prognosen völlig verschieden ausfallen, manchmal sogar auch ganz falsch sind. Um dies zu vermeiden, vergleichen Meteorologen möglichst viele Wetterlagen. Je mehr Übereinstimmungen es gibt, desto wahrscheinlicher ist es, dass ihre Prognose zutrifft. Mit einer Trefferquote von etwa 80 Prozent kann die Entwicklung eines Sturms inzwischen auch recht gut eingeschätzt werden – aber eben nicht zu 100 Prozent.",
          "answer": "i",
          "explanation": "Da Stürme von vielen Faktoren abhängen und sich oft kurzfristig entwickeln, lassen sie sich trotz moderner Messinstrumente nur schwer zu 100 Prozent berechnen ('Vorhersage von Stürmen ist schwierig')."
        }
      ]
    },
    {
      "id": "35",
      "title": "Test 35 – Computer, Internet & Online-Dienste",
      "isVariant": false,
      "headings": {
        "a": "Jeder kann Netzreporter werden",
        "b": "Historisches Wissen ohne Mühe",
        "c": "Hotels online vermarkten",
        "d": "Sprachen lernen per Computer",
        "e": "Neues Hotelangebot spart Geschäftsleuten Zeit",
        "f": "Verschenken Sie Ihr Geld nicht an den Staat!",
        "g": "Neuer Computerkurs an der Volkshochschule",
        "h": "Elektronischer Weg aus dem Steuerlabyrinth",
        "i": "Onlinebibliothek für Referate und Kurznachrichten",
        "j": "Pädagogen gegen Internetdienste"
      },
      "items": [
        {
          "num": 1,
          "text": "„Auf meinen elektronischen Steuerberater kann ich mich hundertprozentig verlassen“, erklärt Rainer Wust, Inhaber einer kleinen Elektronikfirma in Hamburg. Die Steuererstattung, die er für das vergangene Jahr vom Finanzamt erhielt, stimmte völlig mit dem überein, was sein Steuersparprogramm ausgerechnet hatte. Immer mehr Deutsche sparen sich den teuren Gang zum Steuerberater und setzen auf Computerprogramme. Die Vorteile liegen auf der Hand: Am heimischen Rechner lassen sich alle steuerrelevanten Daten bequem in die richtigen Formulare eingeben und per Internet an das Finanzamt schicken. Das Programm fragt nach wichtigen Zahlen, kennt Steuerspartipps und hilft zuverlässig durch den Steuerdschungel – ohne Terminabsprachen und langwierige Sitzungen beim Steuerberater, wie das früher üblich war. In einigen Fällen muss man aber trotzdem noch Belege und andere Unterlagen beim Finanzamt einreichen – und zwar per herkömmlicher Post.",
          "answer": "h",
          "explanation": "Steuersparprogramme am heimischen PC führen zuverlässig durch den „Steuerdschungel“ und übermitteln die Formulare ans Finanzamt ('Elektronischer Weg aus dem Steuerlabyrinth')."
        },
        {
          "num": 2,
          "text": "Kundenberaterin Sabine E. ist ständig auf Achse. Als Repräsentantin einer großen Plastikgeschirrfirma für Süddeutschland besucht sie Messen, Ausstellungen und Kunden, um den Verkauf anzukurbeln. Heute München, morgen Stuttgart, übermorgen Mainz – Sabine E. ist an das Leben einer modernen Geschäftsnomadin gewöhnt. Umso mehr schätzt sie den Service, den eine immer größere Zahl an Hotels Geschäftsreisenden wie ihr anbieten: das Hotelzimmer mit komplettem Büroservice. Dem Hotelgast stehen nicht nur Internetzugang und Telefon kostenlos zur Verfügung, er kann auch Kopien in Auftrag geben, Dokumente ausdrucken lassen oder schnell noch vom Zimmer aus ein Fax verschicken. „Für mich hat das viele Vorteile“, sagt Frau E. „Meine Aufträge und Abrechnungen kann ich jetzt oft schon während meiner Kundentermine in mein Notebook eintippen und dann am Abend per E-Mail versenden. Unterlagen kann ich auch zwischendurch ausdrucken und Verträge unterschreiben und verschicken. Das spart mir viel Zeit, die ich jetzt dafür nutze, um auch mal abends auszugehen und die Gastronomie der Stadt, in der ich mich gerade befinde, kennenzulernen.“",
          "answer": "e",
          "explanation": "Hotels bieten Zimmer mit komplettem Büroservice (Internet, Drucker, Kopien, Fax) an, wodurch Geschäftsreisende viel Arbeitszeit sparen ('Neues Hotelangebot spart Geschäftsleuten Zeit')."
        },
        {
          "num": 3,
          "text": "Ein Referat für den Geschichtsunterricht über Karl den Großen zur nächsten Woche – kein Problem. Mussten sich Schüler früher durch Berge von Sachbüchern kämpfen, Lexika wälzen und die Nachmittage in den Lesesälen der Bibliotheken verbringen, genügt heute ein Mausklick auf die Webseite eines Onlinediensts, der kostenlos oder für wenig Geld für Schüler fertige Referate zu fast jedem Thema liefert. Statt im staubigen Bibliothekssaal zu sitzen, entspannt sich der Schüler von heute im Schwimmbad vom Schulstress. Und trägt im Unterricht ein Referat vor, von dem er oft nicht einmal das Thema, geschweige denn Details kennt, was spätestens bei Nachfragen der Lehrer schließlich auffällt. Die Praxis, fertige Referate per Internet anzubieten, stößt bei Lehrern und Schulpolitikern auf Kritik. Sie fordern deshalb einhellig Maßnahmen gegen die Anbieter, die zwar Schülern die Arbeit abnehmen, aber nichts zur Wissensvermittlung beitragen.",
          "answer": "j",
          "explanation": "Lehrer und Schulpolitiker kritisieren Online-Anbieter fertiger Schülerreferate scharf und fordern Maßnahmen dagegen ('Pädagogen gegen Internetdienste')."
        },
        {
          "num": 4,
          "text": "Wer könnte interessantere Meldungen aus allen Ecken des World Wide Web liefern als die Internetnutzer selbst? Deshalb sind auf vielen Nachrichtenportalen keine Nachrichtenprofis am Werk, sondern ganz normale Surfer, die selbst zu Onlinereportern werden. Das Prinzip solcher Seiten ist genial einfach: Wer irgendwo im Netz eine Meldung aufspürt, die auch andere Surfer interessieren könnte, schreibt eine kurze Zusammenfassung und reicht diese einfach ein. Dort wird dann vom Betreiber nur geprüft, ob der angegebene Link, also die Fundstelle im Netz, auch funktioniert und die Quelle seriös ist. Auf diese Weise können Falschmeldungen aussortiert werden. Nach erfolgreicher Prüfung wird aus dem Internetfundstück auch schon eine Nachricht. Wer die Meldungen liest, kann dann selbst an der Quelle überprüfen, ob er den Informationen vertraut.",
          "answer": "a",
          "explanation": "Auf Mitmach-Nachrichtenportalen können ganz normale Internetnutzer interessante Fundstücke zusammenfassen und als Onlinereporter veröffentlichen ('Jeder kann Netzreporter werden')."
        },
        {
          "num": 5,
          "text": "Zu Beginn des Englischkurses fragt Verena Baum ihre Mitlernenden nach ihren Namen, wie es in einem Sprachkurs eben üblich ist. Doch statt auf einem harten Schulstuhl sitzt sie ganz bequem auf ihrem körpergerechten Schreibtischstuhl zu Hause vor ihrem PC. Vor zwei Jahren startete eine Sprachenschule vor den Toren von Frankfurt am Main auf Initiative einer pfiffigen Kursleiterin ein Pilotprojekt: „Überall Englisch“. Die Lernenden eignen sich ihre Sprachkenntnisse über ein Computerprogramm an, das extra für dieses Projekt entwickelt wurde. Per Internet treten sie in Dialog mit den anderen Kursteilnehmern und üben und kommunizieren gemeinsam auf Englisch. Alle sechs bis acht Wochen trifft man sich aber nach Möglichkeit an der Schule zum Austausch, zur Lernkontrolle und natürlich, um die Fragen zu beantworten, auf die der PC keine persönliche Antwort wusste. Für Verena Baum und die meisten anderen Teilnehmer an „Überall Englisch“ war es zuerst ungewohnt, sich nicht in einem Kursraum zu treffen. Aber: „Das war eine tolle Erfahrung, und das Lernen hat großen Spaß gemacht.“",
          "answer": "d",
          "explanation": "Im Pilotprojekt „Überall Englisch“ lernen und üben die Kursteilnehmer bequem von zu Hause aus über ein spezielles Computerprogramm und das Internet ('Sprachen lernen per Computer')."
        }
      ]
    },
    {
      "id": "36",
      "title": "Test 36 – Gesundheit, Reisen & Natur in Deutschland",
      "isVariant": false,
      "headings": {
        "a": "Beispiel Rhön: Das Land nutzen und die Natur erhalten",
        "b": "Unser Tipp: Goethes Kochbuch",
        "c": "Ältere Männer verlieren Kraft und Dynamik",
        "d": "Beispiel Nordsee: Immer mehr einsame Menschen im Urlaub",
        "e": "Rhön-Verein bildet Bauern aus",
        "f": "Andere Stimme ab 70?",
        "g": "Unser Gesundheits-Tipp: Nordsee!",
        "h": "Tennis für Anfänger",
        "i": "Sport-Empfehlung: Schwimmen, Gehen, Radfahren",
        "j": "Kochen und Reisen in Deutschland"
      },
      "items": [
        {
          "num": 1,
          "text": "Wer sportlich aktiv sein möchte, fragt sich zu Beginn oft, welche Sportart und welches Trainingspensum wohl richtig sind. Hier eine Empfehlung von Sporttherapeuten: Das ideale Trainingspensum besteht aus drei sportlichen Aktivitäten pro Woche, zwei „trockenen“ (z. B. Radfahren) und einer „nassen“ (Schwimmen). Für die Wahl der Sportarten gilt Folgendes: Verzichten Sie als Anfänger auf Tennis und Squash, denn die schnellen, abrupten Bewegungen belasten Gelenke und Bänder sehr. Walking (zügiges Gehen), Radfahren und Schwimmen hingegen sind sehr empfehlenswerte Sportarten.",
          "answer": "i",
          "explanation": "Sporttherapeuten raten Anfängern von Tennis und Squash ab und empfehlen stattdessen Walking (zügiges Gehen), Radfahren und Schwimmen ('Sport-Empfehlung: Schwimmen, Gehen, Radfahren')."
        },
        {
          "num": 2,
          "text": "„Köstliches Deutschland“ (Südwest, 192 S., 19,50 Euro) – ein Buch, das zum Kochen und zum Reisen animieren will. Der Autor Udo Eckert hat sich Goethes Motto „Warum denn in die Ferne schweifen...“ zu eigen gemacht und sich auf einen kulinarischen Streifzug durch deutsche Regionen gemacht. Das Buch ist Bildband, solides Kochbuch und praktischer Gourmetführer gleichermaßen.",
          "answer": "j",
          "explanation": "Das vorgestellte Buch „Köstliches Deutschland“ verbindet regionale Rezepte mit einem kulinarischen Reiseführer durch deutsche Regionen ('Kochen und Reisen in Deutschland')."
        },
        {
          "num": 3,
          "text": "Behutsame Landnutzung im Einklang mit der Natur hat die einmalige Landschaft der Rhön geschaffen. Wenn Sie mehr darüber wissen wollen, schreiben Sie uns oder schicken Sie uns diese Anzeige! Natur- und Lebensraum Rhön e. V., Georg-Meilinger-Str. 3, D-36115 Ehrenberg-Wüstensachsen.",
          "answer": "a",
          "explanation": "Die Anzeige hebt hervor, wie behutsame Landnutzung im Einklang mit der Natur die Kulturlandschaft der Rhön geprägt hat ('Beispiel Rhön: Das Land nutzen und die Natur erhalten')."
        },
        {
          "num": 4,
          "text": "Allein in Salzluft, Sonne und Seewind bekommen Körper und Seele Aufwind. Nordsee – ein Klima, einzigartig und wie geschaffen für Gesundheit: mal sanft, mal rau. Auf jeden Fall belebend. Und eine Kur gibt zusätzlich Impulse. Mit den elementarsten Heilkräften der Natur. Sternstunden der Gesundheit. Informationen bei: 5-Sterne-Nordsee-Kur, Postfach 161 130, D-22510 Husum.",
          "answer": "g",
          "explanation": "Geworben wird für die belebende Wirkung von Salzluft, Sonne, Seewind und einer Kur an der Nordsee ('Unser Gesundheits-Tipp: Nordsee!')."
        },
        {
          "num": 5,
          "text": "Dass die Stimme vornehmlich von Männern im Alter oft rauer klingt, liegt an altersbedingten Umbildungen des Stimmapparats im Kehlkopf. Die veränderte Stimme der Betroffenen verliert dadurch an Kraft und Dynamik und kann sich dann ungewohnt heiser oder rau anhören. Doch vor dem 70. Lebensjahr ist mit dieser natürlichen Stimmveränderung nicht zu rechnen.",
          "answer": "f",
          "explanation": "Durch altersbedingte Umbildungen im Kehlkopf verändert sich vor allem bei Männern ab dem 70. Lebensjahr der Klang der Stimme ('Andere Stimme ab 70?')."
        }
      ]
    },
    {
      "id": "37",
      "title": "Test 37 – Teilen, Mitfahren & Unterwegssein",
      "isVariant": false,
      "headings": {
        "a": "Daumen hoch – aber gewusst wie!",
        "b": "Durch die Städte Osteuropas. Viel zu sehen für wenig Geld!",
        "c": "Was rastet, das rostet: Tipps für Stillstand und Bewegung.",
        "d": "Vom eigenen Wagen zum Car-Sharing. Autofahren damals und heute.",
        "e": "Tausch dich aus! Autos, Werkzeuge, Geräte & Co gemeinsam benützen.",
        "f": "Mein rechter Platz ist frei... Wie berechenbar sind Mitfahrgelegenheiten?",
        "g": "Die 5 Gefahren des Autostoppens.",
        "h": "Preiswert durch die Welt – Reisearten im Vergleich.",
        "i": "Urlaub zu Hause, Urlaub bei Fremden? Oder: Auf dem Sofa durch die Welt.",
        "j": "Fast geschenkt: Autos, die man sich leisten kann"
      },
      "items": [
        {
          "num": 1,
          "text": "Wie wäre es, bei wildfremden Menschen einzuziehen und während der eigenen Reise dort zu übernachten? Wer nach unmittelbarer Bekanntschaft mit dem Reiseziel und seinen Gepflogenheiten lechzt, betreibt heute Couchsurfing. Private Gastgeber auf allen Kontinenten bieten im Internet eine Schlafgelegenheit an. Geben und Nehmen heißt das Prinzip des neuen Reisetrends: Wer bereits eine Couch in New York in Anspruch genommen hat, kann auch sein Sofa in St. Pölten für andere Touristen anbieten. Sechs Millionen Menschen weltweit wissen, wie sich so etwas anfühlt, denn sie alle sind Mitglieder bei www.couchsurfing.org, dem größten Online-Portal zur Vermittlung von kostenlosen Übernachtungsmöglichkeiten. Hier suchen Abenteuerlustige nach privaten Übernachtungsmöglichkeiten aus aller Welt. In über 100.000 Städten sind Couchsurfer angemeldet und dementsprechend ist die Wahrscheinlichkeit recht hoch, im Urlaub als Gast bei Fremden einzuziehen. Doch genau diesen Begriff vermeidet man auf der Homepage galant, aber bestimmt. Von „Fremden“ ist hier nicht die Rede, vielmehr von „Freunden, die du noch nicht getroffen hast“.",
          "answer": "i",
          "explanation": "Beim Couchsurfing übernachten Reisende kostenlos auf dem Sofa privater Gastgeber in aller Welt ('Urlaub zu Hause, Urlaub bei Fremden? Oder: Auf dem Sofa durch die Welt.')."
        },
        {
          "num": 2,
          "text": "Darauf, zu einem Wildfremden ins Auto zu steigen, basiert die Geschäftsidee von Mitfahrplattformen im Internet. Ihr Prinzip: Wer mit dem Auto von A nach B fahren will und noch Plätze frei hat, sucht online oder via App nach Mitfahrern, um sein Auto zu füllen und sich die Benzinkosten zu teilen. Das dürfte funktionieren, denn solche Websites gibt es mittlerweile zuhauf. Neu sind Mitfahrbörsen nicht: Schon in den 1950ern wurde in Frankfurt am Main – ganz und gar offline – eine Mitfahrzentrale gegründet. Eigentlich wie Autostoppen, nur besser planbar. Mit dem Internet wurde die Organisation dann noch leichter. Heute weiß man vorab schon eine ganze Menge über die potenziellen Chauffeure: Sie haben Profile, auf denen sie nicht nur sich selbst, sondern auch ihr Auto präsentieren. Auch eine Ausweiskopie kann dem Profil beigefügt werden.",
          "answer": "f",
          "explanation": "Online-Mitfahrbörsen vermitteln freie Plätze im Auto und sind durch Fahrerprofile deutlich besser planbar als klassisches Autostoppen ('Mein rechter Platz ist frei... Wie berechenbar sind Mitfahrgelegenheiten?')."
        },
        {
          "num": 3,
          "text": "Langes Stehen tut selten gut, das gilt auch für Autos. Bei wenig genutzten Fahrzeugen kann unter anderem Rost an Blech und Bremsen entstehen. Damit der Wagen nach längerer Standzeit nicht nur anspringt, sondern auch verlässlich läuft, ist Vorsorge nötig. Früher wurde empfohlen, das Auto vollzutanken, damit kein Rost im Tank entsteht. Dieser Ratschlag erübrigt sich schon seit längerer Zeit, denn seit Mitte der 80er Jahre haben Autos meist einen Kunststofftank. Während es bei älteren Autos empfehlenswert sein kann, die Batterie auszubauen, verursacht dies bei neueren Modellen häufig Probleme mit der Elektronik. Besonders wichtig ist eine geeignete Unterstellmöglichkeit. Wenn es ein teures Fahrzeug ist, sollten Sie überlegen, einen Stellplatz zu mieten. Die Fachleute raten außerdem dazu, etwas mehr Luft in die Reifen zu pumpen, weil schon die Temperaturunterschiede den Druck deutlich sinken lassen können. Damit der Wagen in Form bleibt, gilt aber eigentlich das Motto „Fahren, fahren, fahren“. Wer sein Auto nicht selbst bewegt, kann dies andere für sich erledigen lassen. Solche Ersatz-Fahrer findet man auf Vermittlungsportalen im Internet.",
          "answer": "c",
          "explanation": "Der Artikel gibt praktische Ratschläge, wie man Standschäden und Rost bei selten genutzten Autos vermeidet ('Was rastet, das rostet: Tipps für Stillstand und Bewegung.')."
        },
        {
          "num": 4,
          "text": "Es gibt einen neuen Trend, der nicht nur in Deutschland, sondern weltweit Einzug hält: „Nutzen statt Besitzen“ lautet er und umfasst so unterschiedliche Praktiken wie Wohnungstausch, Kleidertauschpartys, Autogemeinschaften, Gemeinschaftsgärten, Tauschringe für Werkzeuge, Drucker oder DVDs und vieles andere mehr. Das Internet macht's möglich: Tauschplattformen für Dinge, Wohnungen oder private Autos ermöglichen es, schnell und unkompliziert denjenigen zu finden, der (oder die) das hat, was ich brauche. Mit der Verbreitung digitaler Leih-, Miet- und Tauschmodelle entstehen neue Geschäftsformen, die sich auf einer neuen „Währung“ gründen: Vertrauen. Vertrauen, dass der andere meine Dinge gut behandelt und mich nicht hinters Licht führt, obwohl ich den anderen noch nie gesehen habe.",
          "answer": "e",
          "explanation": "Unter dem Motto „Nutzen statt Besitzen“ werden über Online-Plattformen Autos, Wohnungen, Werkzeuge und Alltagsgeräte getauscht und gemeinsam genutzt ('Tausch dich aus! Autos, Werkzeuge, Geräte & Co gemeinsam benützen.')."
        },
        {
          "num": 5,
          "text": "Warum den teuren Zug oder Flieger nehmen, wenn es doch per Anhalter viel günstiger geht? Besonders junge Leute heben gerne den Daumen, um von A nach B zu kommen. Beim Autostoppen sollte man jedoch einige gesetzliche Regeln kennen. In Österreich ist Autostoppen auf Autobahnen oder Autostraßen generell und unabhängig vom Alter verboten. Auf Autobahn-Parkplätzen, Raststationen und an allen anderen Straßen ist an übersichtlichen Stellen das Autostoppen erlaubt. Es gilt jedoch, bundeslandspezifische Altersbestimmungen zu beachten. In Kärnten und Vorarlberg ist das Autostoppen unter 14, in der Steiermark unter 15 Jahren verboten. Wer im Ausland autostoppen will, sollte sich vorab mit rechtlichen Bestimmungen und landesüblichen Gewohnheiten vertraut machen. Beispielsweise setzen Autofahrer in manchen Ländern wie Rumänien, Indien und Mexiko eine Bezahlung voraus. In den USA, Kanada oder Australien kommt es auf den jeweiligen Bundesstaat an, ob Autostoppen erlaubt ist. In vielen afrikanischen Ländern wiederum ist Trampen selbstverständlich und ersetzt die oftmals fehlenden öffentlichen Verkehrsmittel.",
          "answer": "a",
          "explanation": "Wer per Anhalter fährt („Daumen hoch“), muss die jeweiligen gesetzlichen Regeln, Altersgrenzen und Gepflogenheiten im In- und Ausland kennen ('Daumen hoch – aber gewusst wie!')."
        }
      ]
    },
    {
      "id": "38",
      "title": "Test 38 – Süßigkeiten & Thermalbäder",
      "isVariant": false,
      "headings": {
        "a": "Für unterwegs: Leckereien im Zugrestaurant",
        "b": "In der Stadt der warmen Quellen",
        "c": "Irrtum: Süßes macht doch nicht glücklich",
        "d": "Mitmach-Museum: Bonbons selbst herstellen",
        "e": "Naschen statt wegwerfen",
        "f": "Neues Thermalbad in Rom",
        "g": "Reisen: Die beliebtesten Thermalbäder",
        "h": "Süßwaren mit langer Tradition",
        "i": "Wasser, Wärme, Wellness – antike Badefreuden",
        "j": "Zucker sorgt für Stimmungshoch"
      },
      "items": [
        {
          "num": 1,
          "text": "Bonbons machen Kinder glücklich, und zwar nicht erst seit gestern: Denn diese beliebte Süßigkeit ist viel älter, als man allgemein vermuten würde. Schon vor über 1.000 Jahren gab es im antiken China, in Griechenland und im Römischen Reich Süßwaren aus Honig, Blüten und Früchten. Wer noch mehr über Bonbons erfahren möchte, sollte einen Ausflug nach Vaihingen an der Enz unternehmen: Dort gibt es nicht nur seit 1828 die Bonbon- und Zuckerwarenfabrik Jung, sondern auch das einzige Bonbon-Museum Deutschlands. Auf 300 Quadratmetern Ausstellungsfläche findet sich Antwort auf viele bunte Fragen: Man erfährt dort etwa, woher Bonbons kommen, wie sie ihre heutige Form erhielten und wie sie überhaupt hergestellt werden. Gezeigt werden auch Bonbondosen, Bonbon-Maschinen und Werbemittel. Beim Rundgang durch das Museum bestaunen kleine und große Besucher echte Teile aus den frühen Herstellungsstätten und verfolgen die Entwicklung der Fabrikproduktion unserer Zeit.",
          "answer": "h",
          "explanation": "Der Text beleuchtet die über 1.000-jährige Geschichte der Bonbons und das Bonbon-Museum in Vaihingen an der Enz ('Süßwaren mit langer Tradition')."
        },
        {
          "num": 2,
          "text": "Am Frankfurter Hauptbahnhof können Reisende beim Warten auf den Zug noch schnell einen besonderen Snack genießen. Denn am Bahnhof steht jetzt ein „Rettomat“: ein Automat, an dem abgelaufene Schokoriegel, Chips, Nüsse und andere Lebensmittel verkauft werden. Das Mindesthaltbarkeitsdatum der Produkte ist in den meisten Fällen fast abgelaufen, daher werden sie günstiger angeboten als im Handel. Auch Getränke hält der Automat bereit. „Die Produkte sind überschüssig beziehungsweise stehen kurz vor oder nach dem Ablauf des Mindesthaltbarkeitsdatums, sind aber trotzdem noch gut“, erklärt ein Sprecher der Deutschen Bahn. Denn sie werden natürlich sorgfältig geprüft. Mit dem neuen Service wolle der Konzern den Bahnhof noch attraktiver machen und so Ressourcen schützen. Fahrgäste sollen die Möglichkeit erhalten, sich mit Süßigkeiten und Knabbereien zu versorgen und gleichzeitig etwas gegen die Lebensmittelverschwendung zu tun. Außerdem könnten Vorbeigehende und Reisende darüber, dass viele Lebensmittel weggeworfen werden, aufgeklärt werden.",
          "answer": "e",
          "explanation": "Am Frankfurter Hauptbahnhof verkauft ein „Rettomat“ günstig Snacks kurz vor oder nach Ablauf des Mindesthaltbarkeitsdatums gegen Lebensmittelverschwendung ('Naschen statt wegwerfen')."
        },
        {
          "num": 3,
          "text": "Wo heißes Wasser aus der Erde sprudelt, hat sich vielerorts das Bäder- und Kurwesen gut entwickelt. Schon im alten Rom wusste man, dass ein Bad im warmen Wasser wohltuend ist und gegen Alltagsstress, Verspannungen und Ermüdung wirkt. Badeeinrichtungen gab es überall im Römischen Reich. Gegen eine geringe Eintrittsgebühr konnte jeder, egal welche Stellung er in der gesellschaftlichen Rangordnung einnahm, die Anlagen genießen; diese boten Platz für bis zu 1.000 Menschen. Von ähnlichen Bauten und der speziellen Architektur konnten viele europäische Städte profitieren und den Badeluxus kopieren. Möglichst prachtvoll wurden sie gebaut, sollten eindrucksvoll sein, und wertvolle Mosaik- und Marmorböden, mehrere Badebecken sowie Räume für Schwitz- und Dampfbäder machten sie zu gesellschaftlichen Begegnungsorten. Doch die besonderen Freizeiteinrichtungen spielten auch im gesellschaftlichen Leben eine Rolle: Denn der Genuss für das Auge verband sich hier überall auch mit einer angenehmen Atmosphäre, wodurch ein Besuch in einer Therme zu einem beliebten Freizeitziel wurde.",
          "answer": "i",
          "explanation": "Der Text beschreibt die prachtvollen Thermen, Schwitz- und Dampfbäder im alten Römischen Reich ('Wasser, Wärme, Wellness – antike Badefreuden')."
        },
        {
          "num": 4,
          "text": "Nicht nur in Hollywoodfilmen tröstet man sich bei Liebeskummer mit Pralinen: Der Griff zu Süßigkeiten ist überall weit verbreitet. Viele glauben, dass sie die Stimmung aufhellen, die Konzentration verbessern oder gegen „Nachmittagstiefs“ im Büro helfen. Doch damit liegen sie womöglich falsch. Denn Wissenschaftler haben nun genauer erforscht, wie Zucker auf unser Gemüt wirkt. In ihrer Studie stellten sie praktisch keinen positiven Einfluss des Zuckerkonsums auf die Laune fest – im Gegenteil. „Die Idee, dass Zucker die Stimmung heben kann, ist auf der ganzen Welt verbreitet“, sagt Konstantin Grüger von der Humboldt-Universität in Berlin. „Unser Ergebnis bietet jedoch eigentlich keinen Anhaltspunkt dafür.“ Vielmehr zeige sich, „dass Zucker dafür sorgt, dass wir uns schlechter fühlen“. Die Auswertung deutet darauf hin, dass Probanden nach Zuckerkonsum müder und unkonzentrierter waren als jene, die nur ein Placebo bekommen hatten.",
          "answer": "c",
          "explanation": "Eine Studie der Humboldt-Universität Berlin widerlegt den Mythos, dass Zucker die Laune hebt: Probanden fühlten sich danach sogar müder und unkonzentrierter ('Irrtum: Süßes macht doch nicht glücklich')."
        },
        {
          "num": 5,
          "text": "Wellness und der Besuch von Kurorten und Thermalbädern haben seit Jahrhunderten Tradition in Ungarn. Das Land besitzt zwar keinen direkten Zugang zum Meer, aber dafür wimmelt es in diesem Binnenstaat nur so von Thermalquellen. Dabei handelt es sich um Quellen, aus denen Grundwasser austritt, das über 20 Grad warm ist. Dieses Wasser enthält Mineralstoffe, denen eine positive Wirkung auf den Organismus zugeschrieben wird. 123 Thermalquellen finden sich allein in Budapest, das berühmt für seine Bäder ist. Diese Stadt ist damit nicht nur das einzige Kurbad, das zugleich die Hauptstadt eines Landes ist, sondern auch die größte Kurstadt Europas. In Budapest kann man zwischen über 20 Bädern wählen. Viele sind Bauten von beträchtlichem historischem und architektonischem Rang. Obwohl Budapest auch eine ausgeprägte Café-Kultur besitzt, sind die Bäder für die Stadtbewohner wichtige Treffpunkte – denn oft verabreden sich Freunde in einem Bad.",
          "answer": "b",
          "explanation": "Mit 123 warmen Quellen und über 20 historischen Bädern ist Ungarns Hauptstadt Budapest die größte Kurstadt Europas ('In der Stadt der warmen Quellen')."
        }
      ]
    },
    {
      "id": "39",
      "title": "Test 39 – Schlaf, Tageslicht & Biorhythmus",
      "isVariant": false,
      "headings": {
        "a": "Bewegung macht gute Laune",
        "b": "Klug durch Schlaf",
        "c": "Licht aus – Energiesparen im Klassenzimmer",
        "d": "Professor fordert kürzere Arbeitszeiten",
        "e": "Richtiges Licht fördert das Lernen",
        "f": "Sind Frühaufsteher intelligenter?",
        "g": "Tiere im Energiesparmodus",
        "h": "Wandern im Dunkeln – Tipps für Nachtwanderungen",
        "i": "Warum Menschen keinen Winterschlaf halten",
        "j": "Was hinter unserer Wintermüdigkeit steckt"
      },
      "items": [
        {
          "num": 1,
          "text": "Im Winter ziehen sich viele Tiere in den Winterschlaf zurück, um Energie zu sparen. Während dieser Zeit wird ihr Stoffwechsel langsamer, und ihre Körpertemperatur sinkt. Dies hilft ihnen, über einen längeren Zeitraum ohne Nahrung auszukommen. Beispiele für Tiere, die Winterschlaf halten, sind Igel, Fledermäuse und Murmeltiere.",
          "answer": "g",
          "explanation": "Igel, Fledermäuse und Murmeltiere fahren im Winterschlaf Stoffwechsel und Körpertemperatur herunter, um Energie zu sparen ('Tiere im Energiesparmodus')."
        },
        {
          "num": 2,
          "text": "Laut einer Studie der Universität Leipzig fördert natürliches Licht die Lernfähigkeit von Schülern. Klassenzimmer mit viel Tageslicht sorgen dafür, dass die Schüler aufmerksamer und konzentrierter sind. Die Forscher stellten außerdem fest, dass ausreichend Licht die Stimmung hebt und das Lernklima verbessert.",
          "answer": "e",
          "explanation": "Eine Studie der Universität Leipzig belegt, dass viel Tageslicht im Klassenzimmer Konzentration und Lernfähigkeit steigert ('Richtiges Licht fördert das Lernen')."
        },
        {
          "num": 3,
          "text": "Ein regelmäßiger Schlafrhythmus ist wichtig für die Gesundheit. Während des Schlafs produziert unser Körper das Hormon Melatonin, das den Schlaf-Wach-Rhythmus reguliert. Melatonin unterstützt den Körper dabei, sich zu entspannen, und sorgt für eine erholsame Nacht. Ein gestörter Schlafrhythmus kann jedoch zu Gesundheitsproblemen führen.",
          "answer": "b",
          "explanation": "Ein regelmäßiger, erholsamer Schlaf mit ausreichender Melatoninproduktion regeneriert Körper und Geist ('Klug durch Schlaf')."
        },
        {
          "num": 4,
          "text": "In den letzten Jahren ist das nächtliche Wandern in der Natur zu einer beliebten Freizeitaktivität geworden. Gesundheitsexperten empfehlen, diese Praxis nicht zu verbieten, da sie positive Auswirkungen auf die körperliche und geistige Gesundheit hat. Nachts zu wandern hilft, Stress abzubauen, die Sinne zu schärfen und die Verbindung zur Natur zu stärken. Zudem fördert es die Produktion von Melatonin, das den Schlaf-Wach-Rhythmus reguliert und bei Schlafproblemen hilft. Experten betonen, dass diese Bewegung besonders wohltuend ist, solange sie sicher und unter geeigneten Bedingungen stattfindet.",
          "answer": "a",
          "explanation": "Wandern in der Natur baut Stress ab und wirkt sich positiv auf das körperliche und seelische Wohlbefinden aus ('Bewegung macht gute Laune')."
        },
        {
          "num": 5,
          "text": "Professor Dr. Thomas Münch von der Universität Freiburg führte eine Studie durch, die den Zusammenhang zwischen Arbeitszeiten, Tageslicht und der Gesundheit von Arbeitnehmern untersuchte. Die Ergebnisse zeigten, dass Menschen, die ihre Arbeitszeiten besser an den natürlichen Sonnenrhythmus anpassen, weniger unter Schlafstörungen und chronischer Müdigkeit leiden. Außerdem trägt der tägliche Fußweg zur Arbeit, besonders bei Tageslicht, nicht nur zur körperlichen Gesundheit bei, sondern verbessert auch die psychische Verfassung. Der Kontakt mit natürlichem Licht reguliert den Hormonhaushalt, insbesondere die Produktion von Melatonin und Serotonin, was entscheidend für das Wohlbefinden ist.",
          "answer": "j",
          "explanation": "Fehlt im Arbeitsalltag der Kontakt zu natürlichem Tageslicht, gerät der Hormonhaushalt (Melatonin/Serotonin) aus dem Gleichgewicht und führt zu chronischer Müdigkeit ('Was hinter unserer Wintermüdigkeit steckt')."
        }
      ]
    },
    {
      "id": "40",
      "title": "Test 40 – Klimawandel, Evolution & Artensterben",
      "isVariant": false,
      "headings": {
        "a": "Anzahl und Rolle der Arten noch unklar",
        "b": "Veränderte Wanderwege von Zugvögeln",
        "c": "Wetterbedingungen könnten den Zerfall von Hochkulturen beschleunigt haben",
        "d": "Klimawandel erschwerte die Evolution",
        "e": "Optimistische Projekte, um das Artensterben aufzuhalten",
        "f": "Störungen des biologischen Rhythmus von Zugvögeln",
        "g": "Der Mensch ist am Aussterben von Tierarten schuld",
        "h": "Keine neuen Erkenntnisse über den Niedergang der Hochkultur",
        "i": "Evolution durch klimatische Veränderungen begünstigt",
        "j": "Neue Studie belegt Verwandtschaft zwischen Säugetieren"
      },
      "items": [
        {
          "num": 1,
          "text": "Die zunehmende Klimaveränderung macht sich bereits in der Tierwelt bemerkbar. So müssen Zugvögel ihre Eier früher legen, um sich an die wärmeren Frühjahrstemperaturen in ihren gewohnten Brutregionen anzupassen. Bei bestimmten Arten ist das Zugverhalten aber nicht nur abhängig vom Klima, sondern auch von anderen Reizen, wie zum Beispiel der Länge der Tage. Diesen Vogelarten fällt es besonders schwer, die Eiablage an die geänderten klimatischen Bedingungen anzupassen. Zugvögel, die eine besonders lange Strecke zwischen ihren Überwinterungsplätzen und den Brutstätten zurücklegen müssen, sind durch das Zusammenspiel von Temperaturänderung und anderen, unveränderten Außenbedingungen besonders leicht zu verwirren. Denn der Zeitpunkt für den Abflug aus den Überwinterungsregionen wird von Einflüssen bestimmt, die nichts mit der Temperatur zu tun haben. Einige Auslöser für die Wanderung sind auch genetisch bedingt. Die Tiere kehren in der Regel dann zurück, wenn es die meisten Insekten als Nahrung für ihren Nachwuchs gibt.",
          "answer": "f",
          "explanation": "Durch die Klimaerwärmung geraten der Zeitpunkt des Abflugs und die Eiablage von Zugvögeln aus dem Takt ('Störungen des biologischen Rhythmus von Zugvögeln')."
        },
        {
          "num": 2,
          "text": "Das Klima hatte einen entscheidenden Einfluss auf die Entwicklung des Menschen, vermuten Wissenschaftler. Sie stellten einen Klimakalender des Menschen zusammen, demzufolge fünf dramatische Klimaänderungen zur Evolution des Menschen beigetragen haben. Die Klimawandlungen hätten diese drastisch beschleunigt. Die Notwendigkeit, sich an neue Umstände anzupassen, habe die Entwicklung des Gehirns beschleunigt und zum aufrechten Gang beigetragen. Auch die Entwicklung von verschiedenen Arbeitsgeräten sei teilweise durch den Klimawandel bedingt, denn die Veränderungen der Umweltbedingungen fielen zeitlich mit dem Erscheinen der ersten Vorfahren des Menschen in den betroffenen Gebieten zusammen. Sucht man nach einem Merkmal, das den Menschen vom Tierreich abhebt, so ist das vermutlich eine außerordentliche Unabhängigkeit gegenüber den Launen der Natur. Einer Hypothese zufolge war es das stetig wechselnde Klima, das den Menschen zum Menschen machte. Die ungewissen und sich ändernden Lebensbedingungen seien demnach während der letzten sechs Millionen Jahre der entscheidende Faktor in der Evolution des Menschen gewesen.",
          "answer": "i",
          "explanation": "Fünf große Klimaänderungen zwangen die Vorfahren des Menschen zur Anpassung und beschleunigten so die Gehirnentwicklung und den aufrechten Gang ('Evolution durch klimatische Veränderungen begünstigt')."
        },
        {
          "num": 3,
          "text": "Fast dreizehn Jahrhunderte lang blühte die Hochkultur der Maya, bis es zu ihrem Zusammenbruch kam. Fachleute diskutieren seit Jahrzehnten, was den plötzlichen Kollaps auslöste: Kriege, Hunger oder das Klima? Eine neue Studie spricht für Letzteres: Anhaltende Trockenheit führte demnach zum Untergang – zumindest indirekt. Rund um Christi Geburt entwickelte sich im Süden und Südosten Mexikos sowie in Teilen von Guatemala, Belize und Honduras die Hochkultur der Maya. In ihren Inschriften sind Kriege, Hochzeiten und Thronfolgen exakt festgehalten. Das Ende dieser Aufzeichnungen markiert auch den Beginn des Niedergangs: Zwischen dem 8. und dem 10. Jahrhundert wurden viele Städte aufgegeben und die Bevölkerung ging drastisch zurück. Für diesen Kollaps gibt es heute mehrere Erklärungen: Lange Zeit vermutete man vor allem blutige Auseinandersetzungen, Invasionen und soziale Konflikte dahinter, auch Epidemien und Naturkatastrophen standen als mögliche Auslöser zur Diskussion. Erst in den letzten zwanzig Jahren mehren sich die Stimmen, dass eine Veränderung des Klimas die Triebfeder für den Untergang der Hochkultur gewesen sein könnte.",
          "answer": "c",
          "explanation": "Eine neue Studie deutet darauf hin, dass anhaltende Trockenheit und Klimaveränderungen den Untergang der Maya-Hochkultur ausgelöst haben ('Wetterbedingungen könnten den Zerfall von Hochkulturen beschleunigt haben')."
        },
        {
          "num": 4,
          "text": "Experten nehmen an, dass Tag für Tag rund 100 Tierarten aussterben. Sie gehen davon aus, dass innerhalb der nächsten 20 Jahre weltweit ein Viertel aller bislang bekannten Arten ausgestorben sein wird. Der Mensch treibt dieses Artensterben stark voran: Die Zerstörung von natürlichem Lebensraum, Umweltverschmutzung und Krankheiten gefährden Tiere und Pflanzen. Ohne das Einwirken des Menschen auf die verschiedenen Ökosysteme der ganzen Welt würden pro Jahr höchstens 25 Arten aussterben. Neben dem eigentlichen Verlust der jeweiligen Art hat das Aussterben der Tiere Folgen für das gesamte Ökosystem: Sein natürliches Gleichgewicht wird gestört. Wenn eine Art stirbt, sterben auch andere abhängige Arten.",
          "answer": "g",
          "explanation": "Durch Lebensraumzerstörung und Umweltverschmutzung treibt der Mensch das weltweite Artensterben massiv voran ('Der Mensch ist am Aussterben von Tierarten schuld')."
        },
        {
          "num": 5,
          "text": "Wie eng eine Art mit ihrem Lebensraum verbunden ist, zeigt sich oft erst, wenn sie nicht mehr da ist. War sie ein wichtiges Glied in der Nahrungskette, dann verschwinden plötzlich auch andere Lebewesen. Darüber, wie viele Arten es überhaupt gibt, gibt es unterschiedliche Schätzungen. Wissenschaftler gehen jedoch davon aus, dass der größte Teil noch gar nicht entdeckt ist. Das jetzige Tempo vorausgesetzt, würde es noch mehrere hundert Jahre dauern, bis alle Arten beschrieben sind. Wir kennen nur knapp zwei Millionen von geschätzten 30 Millionen Arten. Von sehr vielen Arten wissen wir nichts über ihre Rolle im Ökosystem – und schon gar nicht, in welcher Weise sie für den Menschen nützlich sein könnten. Aber immer mehr Lebensräume und damit Artenbestände werden ausgelöscht. Die Vereinten Nationen schätzen, dass täglich 130 Tier- und Pflanzenarten aussterben.",
          "answer": "a",
          "explanation": "Von geschätzten 30 Millionen Arten sind erst knapp zwei Millionen bekannt, und über ihre Funktion im Ökosystem weiß man noch sehr wenig ('Anzahl und Rolle der Arten noch unklar')."
        }
      ]
    },
    {
      "id": "41",
      "title": "Test 41 – Gedächtnis, Lernen & Brainfood",
      "isVariant": false,
      "headings": {
        "a": "Mehr Aufnahmefähigkeit durch Mnemotechnik",
        "b": "Mit Mnemotechniken zum Erfolg",
        "c": "Leichter lernen mit selbst gemachten Apps",
        "d": "Leichtes Lernen am Computer",
        "e": "Brainfood: Power für Kopf und Körper",
        "f": "Durch Faulenzen leichter lernen",
        "g": "Lernen mit Kohlenhydraten",
        "h": "Wie Sie Ihr Gedächtnis richtig trainieren",
        "i": "Lernen ohne Anstrengung",
        "j": "Mit Hirnjogging zur besseren Gedächtnisleistung"
      },
      "items": [
        {
          "num": 1,
          "text": "Das Kunstwort „Mnemo“-Technik tritt seit dem 19. Jahrhundert an die Stelle des Begriffes „Gedächtniskunst“. Sinn und Ziel der Mnemotechnik (aus dem Griechischen: „Gedächtnis“, „Erinnerung“) ist die reichhaltige Aufnahme von Informationen und deren gute Verarbeitung. Daraus kristallisiert sich ein bewusstes „Sich-Erinnern“ – und zwar auf Dauer! Vulgo „Eselsbrücken“ bauen, Reime bilden, innere Bilder entwickeln. Es handelt sich also um ein kluges Schema effektiven Lernens und Erinnerns. Eine wichtige Rolle dabei spielt die Assoziations-Technik. Will man sich eine Reihe verschiedener Dinge merken, ist es sinnvoll, sich diese bildhaft vorzustellen. Danach stellt man in Form einer lustigen oder schrecklichen Geschichte eine Verknüpfung her.",
          "answer": "a",
          "explanation": "Mnemotechnik verbessert mithilfe von Eselsbrücken, inneren Bildern und Geschichten die reichhaltige Aufnahme und dauerhafte Speicherung von Informationen ('Mehr Aufnahmefähigkeit durch Mnemotechnik')."
        },
        {
          "num": 2,
          "text": "Stundenlanges Strebern? Das ist Geschichte. Lernen geht schneller und leichter, wenn man sich an sechs Tipps hält. Will man etwas Neues lernen, reichen wenige Minuten täglich pro Unterrichtsfach. Eine Anleitung nicht nur für Streber. Stundenlanges Lernen? Nein, danke, das kommt für die Schüler von Wilfried Helms nicht in Frage. „Wenige Minuten täglich reichen pro Unterrichtsfach, wenn man etwas Neues lernen will. Gerade wenn man Probleme in einem Fach hat, ist das genug“, sagt der Gründer des Lernzentrums „Mind Unlimited“. Einzige Bedingung: Wer wirklich etwas lernen und behalten will, braucht einen Überraschungseffekt und ein Glücksgefühl. „Unser Gehirn ist im Grunde ein fauler Sack“, erklärt Helms, „deshalb lernt es nur, wenn es einen Grund hat.“ Das heißt, wenn es wachgerüttelt wird, weil eine neue Aufgabe verlangt wird. Das Wachrütteln von Schülerköpfen gelingt aber nur, wenn Eltern oder Lehrer eine gute Beziehung zu den Kindern haben. Denn erst die sorgt dafür, dass der Schüler nicht gleichgültig vor dem Stoff sitzt. Nur dann schüttet der Körper Stoffe aus, durch die sich das Gehirn aufs Büffeln einstellt. Das ist der Überraschungseffekt.",
          "answer": "i",
          "explanation": "Laut Lernexperte Wilfried Helms reichen wenige Minuten täglich mit Überraschungseffekt und positiver Beziehung statt stundenlangem Büffeln ('Lernen ohne Anstrengung')."
        },
        {
          "num": 3,
          "text": "Wer ein digitales Quiz zusammenstellen wollte, brauchte noch vor kurzem viel Zeit und technisches Know-how. Doch das sind „Tempi passati“ – dank Michael Hielscher von der Pädagogischen Hochschule Bern. Ein Wort-Bild-Memory zu basteln, ist kinderleicht: Man tippt dazu einen Begriff ins Onlineformular ein. Danach sucht man ein passendes Bild im Wikimedia-Fundus, oder man lädt ein eigenes hoch. Und weiter geht es zum nächsten Begriff... Dank der kostenlosen Website LearningApps.org kann heute jedermann eigene Lerneinheiten erstellen und im Web publizieren. Noch vor zwei, drei Jahren musste man auf dem Weg zum eigenen Onlinequiz mehr Hürden nehmen: Es waren besondere Informatikkenntnisse erforderlich und oft war das mit viel Geld und Zeit verbunden. Zwar gibt es heute einige kostenlose E-Learning-Plattformen. Diese sind aber oft so umständlich zu bedienen, dass der Großteil der Lehrer und Kursleiter sie ignoriert.",
          "answer": "c",
          "explanation": "Auf der kostenlosen Website LearningApps.org kann jeder ohne Programmierkenntnisse eigene digitale Quizze und Lerneinheiten basteln ('Leichter lernen mit selbst gemachten Apps')."
        },
        {
          "num": 4,
          "text": "Es ist eine Schwäche unseres Gehirns: Je älter man wird, desto schwerer wird es, sich Dinge zu merken. Viele Hirnjogging-Produkte versprechen eine bessere Gedächtnisleistung – viele davon sind jedoch nutzlos. Was aber hilft wirklich? Gedächtnisforscher wissen: Reines Auswendiglernen ist nicht genug. „Jeden Tag ein Kreuzworträtsel lösen heißt noch nicht, dass Sie sich den Einkaufszettel besser merken können“, so Hans Georg Nehen, Professor an der Memory-Clinic in Essen. Sinnvoll seien andere einfache Übungen: „Wenn Sie an der roten Ampel stehen, gehen Sie in Gedanken Ihren Weg zurück. Wie viele Kreuzungen haben Sie passiert?“ Oder man stellt sich vor dem geistigen Auge vor, wie viele Kreuzungen noch kommen. „Schon eine geringe Trainingsdauer ist effizient“, betont Nehen, der auch dem Bundesverband Gedächtnistraining vorsitzt. Das sieht Markus Hofmann ähnlich: „Es aktiviert das Hirn, sich jeden Tag neuen geistigen Aufgaben zu stellen.“ Nicht immer dasselbe zu machen, das sei pures Gehirnjogging, sagt der Gedächtnistrainer aus München: „Putzen Sie sich mal mit links die Zähne, fahren Sie einen anderen Weg zur Arbeit, drehen Sie die Zeitung zum Lesen auf den Kopf oder dirigieren Sie bei Ihrer Lieblings-CD mit.“",
          "answer": "h",
          "explanation": "Gedächtnisforscher zeigen, welche abwechslungsreichen Alltagsübungen das Gehirn tatsächlich fit halten ('Wie Sie Ihr Gedächtnis richtig trainieren')."
        },
        {
          "num": 5,
          "text": "Mit der richtigen Ernährung werden Sie zwar nicht schlauer, doch der Verzehr bestimmter Lebensmittel soll die Konzentration und Leistungsfähigkeit steigern und Stress reduzieren. Blaubeeren, Nüsse, Avocados, Lachs und Hülsenfrüchte schmecken nicht nur unglaublich gut, sondern sind wahre Energielieferanten fürs Gehirn: Brainfood. Natürlich werden wir durch Lebensmittel nicht schlauer, die in ihnen steckenden Vitamine und Mineralstoffe können jedoch Leistungstiefs, Konzentrationsschwächen, Gereiztheit und Müdigkeit vorbeugen. Zuallererst gilt: viel trinken. Nur mit ausreichend Flüssigkeit sind ausreichende Sauerstoffversorgung und die Durchblutung von Kopf und Körper gewährleistet. Leichte Kopfschmerzen, Konzentrationsschwierigkeiten und Müdigkeit können erste Anzeichen für einen Flüssigkeitsmangel sein. Mindestens 2 Liter kalorienarmer Getränke sollten über den Tag verteilt getrunken werden: am besten Wasser oder kalorienarme Säfte und Kräutertees. Mehr Kraft erhält der Kopf auch durch Zucker, der langsam ins Blut abgegeben wird, z. B. aus Kohlenhydraten, wie sie in Vollkornprodukten stecken. Auch die Kohlenhydrate aus Hülsenfrüchten werden erst aufgespalten und dann vom Körper aufgenommen, was für einen konstanten Blutzuckerspiegel sorgt.",
          "answer": "e",
          "explanation": "Bestimmte Lebensmittel wie Nüsse, Blaubeeren, Lachs und Vollkornprodukte sowie ausreichend Wasser versorgen Gehirn und Körper optimal mit Energie ('Brainfood: Power für Kopf und Körper')."
        }
      ]
    },
    {
      "id": "42",
      "title": "Test 42 – Wohnformen im Wandel & Generationen",
      "isVariant": false,
      "headings": {
        "a": "Experte sagt Wohnungsnot in Städten voraus",
        "b": "Selbstbestimmtes Leben im Alter für viele zu teuer",
        "c": "Wie man zusätzlichen Wohnraum nutzen kann",
        "d": "Hausbesitz schränkt in der Mobilität ein",
        "e": "Wohnentwürfe so divers wie die Menschen",
        "f": "Ansprüche an Wohnfläche altersabhängig",
        "g": "Neuer Trend könnte für Steigerung der Einwohnerzahl sorgen",
        "h": "Für leistbares Wohnen werden lange Wartezeiten akzeptiert",
        "i": "Landleben gibt neue Energie",
        "j": "Wohnbedürfnisse der Jugend bisher vernachlässigt"
      },
      "items": [
        {
          "num": 1,
          "text": "Wer im Alter nicht mehr alleine ein eigenständiges und selbstbestimmtes Leben führen möchte, begibt sich in Österreich meist auf die Suche nach einer entsprechenden professionellen Betreuung. Konventionell geführte Einrichtungen und Seniorenresidenzen haben allerdings den großen Nachteil, dass die dort geltenden Regeln die Bewohnerinnen und Bewohner einschränken und diesen außerdem fixe Essenszeiten oder Beschäftigungen geboten werden. Für viele Ältere beziehungsweise deren unmittelbare Angehörige ist zudem finanzielle Leistbarkeit ein ausschlaggebendes Thema, denn die durchschnittliche Pension erlaubt keine allzu hohen Ausgaben. Eine günstigere Alternative bietet nun ein neues Wohnprojekt aus einer Kooperation.",
          "answer": "b",
          "explanation": "Konventionelle Seniorenresidenzen schränken durch starre Regeln ein und sind mit einer durchschnittlichen Pension oft kaum bezahlbar ('Selbstbestimmtes Leben im Alter für viele zu teuer')."
        },
        {
          "num": 2,
          "text": "Als junger Mensch in Wien auf Wohnungssuche zu sein, ist jedenfalls eine große Herausforderung. Wer ein Studium an der Universität oder Fachhochschule aufnimmt oder gerade einen Ausbildungsplatz in der Hauptstadt Österreichs erhalten hat, dem fehlen allzu oft die finanziellen Mittel, um ein halbwegs annehmbares Quartier zu finden. Die anfänglichen Kosten, die bereits vor dem Einzug in die neue Wohnung fällig sind, können durch die geforderte Kaution von meist drei Bruttomonatsmieten sowie die Vermittlungsgebühren für Maklerbüros enorm hoch werden. Um eine günstige Gemeindewohnung beantragen zu können, muss man bereits mehrere Jahre in Wien hauptgemeldet sein, und auch dann ist Geduld angebracht. Bei einer Anmeldung sind zudem gleich alle Suchkriterien festzulegen, also etwa Wunschbezirk und Quadratmeteranzahl. Für jene, die gerade die ersten selbstständigen Schritte tun, lässt sich allerdings die Zukunft kaum so genau vorausplanen; Gemeindewohnungen sind daher meist keine Option. Die Stadt Wien will nun in den kommenden Jahren zunehmend Wohnprojekte mit flexiblen Vertragsbedingungen und kurzen Kündigungsfristen fördern und sich damit stärker an der Situation junger Leute orientieren.",
          "answer": "j",
          "explanation": "Hohe Kautionen und starre Regeln für Gemeindewohnungen passten bisher nicht zur Lebenssituation junger Menschen in Wien, weshalb die Stadt nun flexible Jugend-Wohnprojekte fördern will ('Wohnbedürfnisse der Jugend bisher vernachlässigt')."
        },
        {
          "num": 3,
          "text": "Wohnen wie immer? Laut Ansicht des renommierten Zukunftsforschers Adrian Gregorius wird sich innerhalb der nächsten paar Jahrzehnte ein Wandel in unserer Wohnkultur vollziehen, der durch die Bevölkerungszunahme in den Städten bedingt wird. Die Konzentration eines großen Anteils der Bevölkerung im Stadtgebiet sieht Gregorius – im deutlich wahrnehmbaren Gegensatz zum ungebremsten Landschaftsverbrauch in den umliegenden Regionen – jedoch keineswegs grundsätzlich als Problem. Vielmehr sei das Leben in der Stadt, wenn es richtig geplant und umgesetzt werde, sowohl ressourcen- als auch energieschonend. Des Weiteren entfalle der klimaschädliche und stressige Berufsverkehr und eine private Autonutzung werde weitgehend überflüssig, da die gesamte städtische Infrastruktur vor Ort zur Verfügung stehe. Nicht nur die Dichte, sondern auch die veränderten Gesellschaftsstrukturen werden es daher erforderlich machen, das Konzept des Wohnens in privaten und flexibel gemeinschaftlich nutzbaren Räumen adäquat anzupassen sowie Naturflächen im Nahbereich neu zu gestalten. Einheitslösungen könne es dabei nicht geben, so der Zukunftsforscher. Unterschiedliche Lebens-, Bau- und Wohnformen müssten der Vielfalt der Stadtbewohner Rechnung tragen.",
          "answer": "e",
          "explanation": "Zukunftsforscher Adrian Gregorius betont, dass es keine Einheitslösungen geben kann, sondern vielfältige Bau- und Wohnformen der Vielfalt der Stadtbewohner gerecht werden müssen ('Wohnentwürfe so divers wie die Menschen')."
        },
        {
          "num": 4,
          "text": "Dass sich die Menschen einmal danach sehnen würden, möglichst wenig Wohnfläche zur Verfügung zu haben, hätte wohl niemand vermutet. Eine neue, von den Vereinigten Staaten ausgehende Bewegung zielt nun darauf ab, sich von überflüssigen materiellen Dingen zu trennen und nur mehr das zu behalten, was auf einer Fläche von 15 bis 20 Quadratmetern Platz findet. Die sogenannten Tiny Houses, also kleinen Häuser, erfreuen sich auch in Österreich immer größerer Beliebtheit, da ihre Anschaffungskosten gering sind und sie bei Bedarf auch per LKW an einen anderen Standort gebracht werden können. Dadurch ist man als Besitzer eines solchen Eigenheims sehr flexibel, was die Wahl des Wohnorts anbelangt. Es bedarf nur eines kleinen Stellplatzes, der für eine bestimmte Zeit gemietet oder gepachtet wird. Besonders vonseiten ländlicher Gemeinden, die stark vom Abzug Einheimischer betroffen sind, besteht großes Interesse daran, dass auf diese Art Personen in entlegeneren Ortschaften wieder ansässig werden. Deswegen wurden mancherorts – oftmals auf Initiative der Bürgermeister – bereits Vermittlungsbörsen für Interessierte eingerichtet.",
          "answer": "g",
          "explanation": "Ländliche Gemeinden, die unter Abwanderung leiden, hoffen durch Stellplätze für Tiny Houses wieder neue Einwohner zu gewinnen ('Neuer Trend könnte für Steigerung der Einwohnerzahl sorgen')."
        },
        {
          "num": 5,
          "text": "Wer hat insgeheim nicht jenen Tag herbeigesehnt, an dem die Kinder endlich selbstständig werden, eigenes Geld verdienen, das gemeinsame Zuhause verlassen und man das eigene Leben wieder in die Hand nehmen kann? Für viele Eltern ist jedoch das Fehlen des Nachwuchses in den heimischen vier Wänden letztendlich ein richtiger Schlag, der das Ende eines Lebensabschnitts signalisiert, in welchem man als Versorger gebraucht wurde. Zu alledem gesellt sich der Umstand, dass man sich des eigenen Älterwerdens zunehmend bewusst wird. Tatsächlich kommt nun also eine schwierige, oftmals zu Depressionen führende Phase der Umorientierung auf die Eltern zu. Um das Gefühl von Einsamkeit und Leere zu überwinden, entschließt sich so manches Paar zu dem durchaus radikalen Schritt, das nun für zwei ältere Personen viel zu große Heim zu veräußern und sich etwas Kleineres und Günstigeres zu suchen, das besser zu den neuen Gegebenheiten passt, anstatt die vorhandenen, nun freistehenden Räumlichkeiten im Familienheim umzugestalten oder für einen eventuellen Besuch der Kinder bereitzuhalten.",
          "answer": "f",
          "explanation": "Wenn die Kinder ausgezogen sind und die Eltern älter werden, verkaufen viele Paare das zu groß gewordene Familienhaus und ziehen in eine kleinere Wohnung ('Ansprüche an Wohnfläche altersabhängig')."
        }
      ]
    }
  ],
  "2": [
    {
      "id": "1",
      "title": "Test 1 – parking",
      "isVariant": false,
      "paragraphs": [
        "Es geschah am 1. Januar 1954. In Duisburg, einer Großstadt am Rhein zwischen Köln und der niederländischen Grenze am Rande des Ruhrgebiets, gab es für die Autofahrer, die in der Straße \"Am Buchenbaum\" ihre Autos parken wollten, eine Überraschung. 20 etwa 1,5 Meter hohe Metallstangen mit uhrenförmigen Aufsätzen standen am Straßenrand mit der unmissverständlichen Aufschrift: \"Einwurf 10 Pfennig für eine Stunde\". Die ersten Parkuhren in Deutschland waren aufgestellt. Nur Basel in der Schweiz und Stockholm in Schweden hatten vor Duisburg Parkuhren installiert, um Dauerparker aus den Stadtzentren zu vertreiben. Das eingenommene Geld wurde in Duisburg anfangs für gemeinnützige Zwecke ausgegeben: für Alte, Kranke, Kriegsversehrte, für elternlose Kinder. Und die Stadtverwaltung war sich sicher, dass die Autofahrer Verständnis für die Parkuhren aufbringen würden, dienten sie doch einem guten Zweck.",
        "Doch bei den Autofahrern war man nicht so erfreut über diese neuen Apparate. \"Groschengrab\" wurden sie dann auch bald überall genannt: ein Apparat, in den man Groschen - wie die 10-Pfennig-Stücke damals genannt wurden - hineinwarf. Dieser schluckte zwar gnadenlos Zehner, gab aber zum Verdruss vieler trotzdem oft keine Parkzeit frei. Tat er dies, dann aber in der Regel nur für höchstens 60 Minuten. Viele Autofahrer waren außerdem verärgert, weil sie immer passendes Kleingeld dabei haben mussten. Die ersten Parkuhren konnten nämlich nicht wechseln. Wer parkte, ohne zu zahlen, riskierte damals wie heute einen Strafbescheid, liebevoll \"Knöllchen\" genannt.",
        "In allen anderen deutschen Städten erschienen nach und nach auch Parkuhren. Bald gehörten sie zu den Innenstädten wie das Rad zum Auto. Und das blieb so bis zum Ende der 1980er Jahre. Dann geschah so etwas wie eine Parkuhren-Revolution. Die guten, alten Parkuhren, die ein im Vergleich zu heute immer noch billiges Parken erlaubten, weil sie nicht beliebig oft auf neue Beträge umgestellt werden konnten, wurden mehr und mehr ersetzt durch die gerade neu entwickelten Parkscheinautomaten. Mit Solarenergie angetrieben, computergesteuert und beliebig programmierbar machten sie es nun möglich, ohne technische Beschränkungen die Preise und Zeiten für das Parken flexibel zu gestalten. Von Vorteil ist auch ihre Kundenfreundlichkeit: Die Zeiten, in denen nur Münzen als Zahlungsmittel akzeptiert wurden, sind passé; jetzt schlucken sie auch problemlos Papier- und Plastikgeld - und Wechselgeld wird ausgespuckt.",
        "Das Parken wurde immer teurer. Und längst dienten die eingenommenen Beträge nicht mehr gemeinnützigen Zwecken. Sie wurden vielmehr als Einnahmequelle entdeckt für die leeren Stadtkassen, die nach immer mehr Geld verlangten. Gut 2 Millionen Euro verdient zum Beispiel Duisburg in einem Jahr an den Parkgebühren. In Köln kommen etwa 10 Millionen Euro im Jahr zusammen. Noch einmal so viel Geld verdienen die Städte an den \"Knöllchen\" für falsches Parken. Aus 10 Pfennig für eine Stunde im Jahr 1954 - das wären heute etwa 5 Cents - sind inzwischen weit höhere Beträge geworden. Spitzenreiter in Deutschland sind Düsseldorf und Berlin mit mehreren Euro pro Stunde. Tendenz steigend. Doch aus dem Kölner Rathaus heißt es an alle sich beschwerenden Autofahrer gerichtet, das Geld werde selbstverständlich zweckgebunden verwendet: für den Bau neuer Straßen. An denen neue Parkscheinautomaten stehen?"
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die ersten Parkuhren Europas standen",
          "options": {
            "a": "in der Schweiz und in Deutschland.",
            "b": "in der Schweiz und in Schweden.",
            "c": "in Deutschland und in Schweden."
          },
          "answer": "b",
          "explanation": "Im Text steht: „Nur Basel in der Schweiz und Stockholm in Schweden hatten vor Duisburg Parkuhren installiert.“"
        },
        {
          "num": 7,
          "stem": "Früher wurden in Duisburg die Parkgebühren verwendet, um",
          "options": {
            "a": "Bedürftige zu unterstützen.",
            "b": "Dauerparker aus den Stadtzentren zu vertreiben.",
            "c": "Löcher im städtischen Haushalt zu stopfen."
          },
          "answer": "a",
          "explanation": "Im Text heißt es: „Das eingenommene Geld wurde in Duisburg anfangs für gemeinnützige Zwecke ausgegeben: für Alte, Kranke, Kriegsversehrte, für elternlose Kinder.“"
        },
        {
          "num": 8,
          "stem": "Die ersten Parkuhren",
          "options": {
            "a": "funktionierten problemlos.",
            "b": "gaben nur Groschen zurück.",
            "c": "konnten nur Münzen annehmen."
          },
          "answer": "c",
          "explanation": "Im Text wird erklärt, dass Autofahrer passendes Kleingeld brauchten und „Die Zeiten, in denen nur Münzen als Zahlungsmittel akzeptiert wurden, sind passé“."
        },
        {
          "num": 9,
          "stem": "Die neuen Parkscheinautomaten",
          "options": {
            "a": "funktionieren nur bargeldlos.",
            "b": "geben kein Wechselgeld zurück.",
            "c": "sind flexibel im Hinblick auf die Art der Bezahlung."
          },
          "answer": "c",
          "explanation": "Laut Text akzeptieren die neuen Parkscheinautomaten neben Münzen „problemlos Papier- und Plastikgeld - und Wechselgeld wird ausgespuckt“."
        },
        {
          "num": 10,
          "stem": "In Berlin und in Düsseldorf",
          "options": {
            "a": "fließen die Parkgebühren nur in den Straßenbau.",
            "b": "nimmt die Zahl der Parkscheinautomaten zu.",
            "c": "werden die höchsten Parkgebühren verlangt."
          },
          "answer": "c",
          "explanation": "Im Text steht: „Spitzenreiter in Deutschland sind Düsseldorf und Berlin mit mehreren Euro pro Stunde.“"
        }
      ]
    },
    {
      "id": "1a",
      "title": "Test 1a – parking",
      "isVariant": true,
      "paragraphs": [
        "Es geschah am 1. Januar 1954. In Duisburg, einer Großstadt am Rhein zwischen Köln und der niederländischen Grenze am Rande des Ruhrgebiets, gab es für die Autofahrer, die in der Straße \"Am Buchenbaum\" ihre Autos parken wollten, eine Überraschung. 20 etwa 1,5 Meter hohe Metallstangen mit uhrenförmigen Aufsätzen standen am Straßenrand mit der unmissverständlichen Aufschrift: \"Einwurf 10 Pfennig für eine Stunde\". Die ersten Parkuhren in Deutschland waren aufgestellt. Nur Basel in der Schweiz und Stockholm in Schweden hatten vor Duisburg Parkuhren installiert, um Dauerparker aus den Stadtzentren zu vertreiben. Das eingenommene Geld wurde in Duisburg anfangs für gemeinnützige Zwecke ausgegeben: für Alte, Kranke, Kriegsversehrte, für elternlose Kinder. Und die Stadtverwaltung war sich sicher, dass die Autofahrer Verständnis für die Parkuhren aufbringen würden, dienten sie doch einem guten Zweck.",
        "Doch bei den Autofahrern war man nicht so erfreut über diese neuen Apparate. \"Groschengrab\" wurden sie dann auch bald überall genannt: ein Apparat, in den man Groschen - wie die 10-Pfennig-Stücke damals genannt wurden - hineinwarf. Dieser schluckte zwar gnadenlos Zehner, gab aber zum Verdruss vieler trotzdem oft keine Parkzeit frei. Tat er dies, dann aber in der Regel nur für höchstens 60 Minuten. Viele Autofahrer waren außerdem verärgert, weil sie immer passendes Kleingeld dabei haben mussten. Die ersten Parkuhren konnten nämlich nicht wechseln. Wer parkte, ohne zu zahlen, riskierte damals wie heute einen Strafbescheid, liebevoll \"Knöllchen\" genannt.",
        "In allen anderen deutschen Städten erschienen nach und nach auch Parkuhren. Bald gehörten sie zu den Innenstädten wie das Rad zum Auto. Und das blieb so bis zum Ende der 1980er Jahre. Dann geschah so etwas wie eine Parkuhren-Revolution. Die guten, alten Parkuhren, die ein im Vergleich zu heute immer noch billiges Parken erlaubten, weil sie nicht beliebig oft auf neue Beträge umgestellt werden konnten, wurden mehr und mehr ersetzt durch die gerade neu entwickelten Parkscheinautomaten. Mit Solarenergie angetrieben, computergesteuert und beliebig programmierbar machten sie es nun möglich, ohne technische Beschränkungen die Preise und Zeiten für das Parken flexibel zu gestalten. Von Vorteil ist auch ihre Kundenfreundlichkeit: Die Zeiten, in denen nur Münzen als Zahlungsmittel akzeptiert wurden, sind passé; jetzt schlucken sie auch problemlos Papier- und Plastikgeld - und Wechselgeld wird ausgespuckt.",
        "Das Parken wurde immer teurer. Und längst dienten die eingenommenen Beträge nicht mehr gemeinnützigen Zwecken. Sie wurden vielmehr als Einnahmequelle entdeckt für die leeren Stadtkassen, die nach immer mehr Geld verlangten. Gut 2 Millionen Euro verdient zum Beispiel Duisburg in einem Jahr an den Parkgebühren. In Köln kommen etwa 10 Millionen Euro im Jahr zusammen. Noch einmal so viel Geld verdienen die Städte an den \"Knöllchen\" für falsches Parken. Aus 10 Pfennig für eine Stunde im Jahr 1954 - das wären heute etwa 5 Cents - sind inzwischen weit höhere Beträge geworden. Spitzenreiter in Deutschland sind Düsseldorf und Berlin mit mehreren Euro pro Stunde. Tendenz steigend. Doch aus dem Kölner Rathaus heißt es an alle sich beschwerenden Autofahrer gerichtet, das Geld werde selbstverständlich zweckgebunden verwendet: für den Bau neuer Straßen. An denen neue Parkscheinautomaten stehen?"
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die ersten Parkuhren Europas standen",
          "options": {
            "a": "in Basel und in Duisburg.",
            "b": "in der Schweiz und in Schweden.",
            "c": "in Deutschland und in Schweden."
          },
          "answer": "b",
          "explanation": "Im Text steht: „Nur Basel in der Schweiz und Stockholm in Schweden hatten vor Duisburg Parkuhren installiert.“"
        },
        {
          "num": 7,
          "stem": "Früher wurden in Duisburg die Parkgebühren verwendet, um",
          "options": {
            "a": "Bedürftige zu unterstützen.",
            "b": "Dauerparker aus den Stadtzentren zu vertreiben.",
            "c": "Löcher im städtischen Haushalt zu stopfen."
          },
          "answer": "a",
          "explanation": "Im Text heißt es: „Das eingenommene Geld wurde in Duisburg anfangs für gemeinnützige Zwecke ausgegeben: für Alte, Kranke, Kriegsversehrte, für elternlose Kinder.“"
        },
        {
          "num": 8,
          "stem": "Die ersten Parkuhren",
          "options": {
            "a": "bezeichnete man als \"Knöllchen\".",
            "b": "funktionierten nur mit Münzen.",
            "c": "gaben oft falsche Beträge zurück."
          },
          "answer": "b",
          "explanation": "Die ersten Parkuhren nahmen nur Groschen (Münzen) an und konnten nicht wechseln; erst spätere Automaten akzeptierten Papier- und Plastikgeld."
        },
        {
          "num": 9,
          "stem": "Die neuen Parkscheinautomaten",
          "options": {
            "a": "akzeptieren nur Karten als Zahlungsmittel.",
            "b": "müssen mit hohem Aufwand gewartet werden.",
            "c": "versorgen sich selbst mit Strom."
          },
          "answer": "c",
          "explanation": "Im Text steht über die neuen Parkscheinautomaten: „Mit Solarenergie angetrieben, computergesteuert und beliebig programmierbar...“"
        },
        {
          "num": 10,
          "stem": "In Berlin und in Düsseldorf",
          "options": {
            "a": "fließen die Parkgebühren nur in den Straßenbau.",
            "b": "nimmt die Zahl der Parkscheinautomaten zu.",
            "c": "werden die höchsten Parkgebühren verlangt."
          },
          "answer": "c",
          "explanation": "Im Text steht: „Spitzenreiter in Deutschland sind Düsseldorf und Berlin mit mehreren Euro pro Stunde.“"
        }
      ]
    },
    {
      "id": "2",
      "title": "Test 2 – Traumfrau und Traummann gesucht",
      "isVariant": false,
      "paragraphs": [
        "Den Partner für das Leben finden - für immer mehr Menschen wird dies offenbar immer schwieriger. Rund 31 Millionen Männer und Frauen in Deutschland, also mehr als ein Drittel der gesamten Bevölkerung, sind alleinstehend. Nicht dass Mann oder Frau wählerischer als in früheren Zeiten geworden wäre, es gibt scheinbar ganz einfach immer weniger Gelegenheiten, das Ziel einer Partnerschaft oder Ehe zu erreichen.",
        "Die Menschen haben einfach immer weniger Zeit, sich um ihre ganz natürlichen Wünsche zu kümmern. Viele arbeiten weit entfernt von ihrem Wohnort, wechseln die Arbeitsstätte in relativ kurzen Abständen, haben für das Privatleben ungünstige Arbeitszeiten mit wenig Freizeit - abgesehen vom alljährlichen Urlaub. Dazu kommt, dass eine beträchtliche Minderheit der Deutschen nicht bereit ist, sich längerfristig oder gar \"lebenslänglich\" an einen bestimmten Partner zu binden. Immer mehr Menschen leben lieber mit ihren Lebensabschnittgefährten zusammen oder sie bevorzugen saisonale Kurzbeziehungen nach dem Muster \"öfter mal 'ne(n) Neue(n)\".",
        "Und immer mehr von denen, die eine Partnerschaft anstreben, versuchen ihren Liebsten oder ihre Liebste nicht auf Partys, Kirmesfesten oder in Cafés und Kneipen zu finden, wie das bei ihren Großeltern noch üblich war, sondern sie schauen ins Internet oder in Zeitungen, um über Partnerschafts- oder Heiratsannoncen fündig zu werden. In Deutschland gibt es viele Radioprogramme, in denen täglich Dutzende ihre Heiratsabsichten kundtun. An Wochenenden gibt es sogar Fernsehsendungen, in denen Partnersuchende mit anderen Partnersuchenden quasi verkuppelt werden.",
        "Doch wie muss solch eine Kontaktanzeige aussehen, damit sie auch von Erfolg gekrönt ist? Denn nicht wenige Anzeigen bringen gar keinen oder nicht den erwünschten Erfolg. Dieser Frage hat sich nun der Kommunikationsexperte Jörg Stimpfling an der Universität Stuttgart gewidmet und seit mehr als zehn Jahren Kontaktanzeigen in den verschiedensten Medien gesammelt und analysiert.",
        "Das Ergebnis der umfangreichen Forschung: Viele Anzeigen sind zu oberflächlich formuliert oder bedienen sich althergebrachter Stereotypen. So beschreiben sich Frauen mit Synonymen für Schönheit oder Attraktivität, Männer bieten Sicherheit oder Status an, überholt geglaubte Klischees finden sich in den meisten Fällen. Ebenso fällt die Neigung auf, sich schöner, besser zu präsentieren, als man wirklich ist, so als biete man ein Produkt in der Konsumwerbung an. Man könnte fast meinen, viele suchen sich selbst wie ihr eigenes Zwillingsbild.",
        "Jörg Stimpfling und seine Kollegen empfehlen Partner suchenden Singles daher, sich erst einmal selbst kennen zu lernen, bevor sie sich an zukünftige Partnerinnen oder Partner wenden. Nur wer über sich selbst Bescheid weiß, kann den Partner finden, der zu ihm passt. Und das Zwillingsbild im Spiegel ist leider kaum als idealer Partner geeignet."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Viele Menschen in Deutschland sind unverheiratet, weil",
          "options": {
            "a": "die Ansprüche bei der Partnerwahl immer weiter steigen.",
            "b": "die Lebensumstände es erschweren, den Partner oder die Partnerin fürs Leben zu finden.",
            "c": "eine Mehrheit ohnehin lieber in zeitlich begrenzten Beziehungen lebt."
          },
          "answer": "b",
          "explanation": "Im Text heißt es, es gebe immer weniger Gelegenheiten und Zeit (weite Arbeitswege, häufiger Jobwechsel, ungünstige Arbeitszeiten), einen Partner fürs Leben zu finden."
        },
        {
          "num": 7,
          "stem": "Viele Singles suchen sich heute ihre Partner oder Partnerinnen.",
          "options": {
            "a": "am Arbeitsplatz.",
            "b": "auf Festen.",
            "c": "in den Medien."
          },
          "answer": "c",
          "explanation": "Laut Text schauen immer mehr Singles „ins Internet oder in Zeitungen, um über Partnerschafts- oder Heiratsannoncen fündig zu werden“, sowie in Radio- und Fernsehsendungen."
        },
        {
          "num": 8,
          "stem": "Im Radio werden",
          "options": {
            "a": "an Samstagen und Sonntagen Partner vermitteln.",
            "b": "jeden Tag Heiratswünsche gesendet.",
            "c": "täglich Hochzeitsglückwünsche gesendet."
          },
          "answer": "b",
          "explanation": "Im Text steht: „In Deutschland gibt es viele Radioprogramme, in denen täglich Dutzende ihre Heiratsabsichten kundtun.“"
        },
        {
          "num": 9,
          "stem": "In Kontaktanzeigen.",
          "options": {
            "a": "beschreiben sich Partnersuchende oft im Rahmen konventioneller Rollenerwartungen.",
            "b": "suchen die meisten Männer moderne, attraktive Frauen.",
            "c": "werden recht häufig die passenden Partner fürs Leben gefunden."
          },
          "answer": "a",
          "explanation": "Im Text heißt es: „Viele Anzeigen sind zu oberflächlich formuliert oder bedienen sich althergebrachter Stereotypen. So beschreiben sich Frauen mit Synonymen für Schönheit oder Attraktivität, Männer bieten Sicherheit oder Status an...“"
        },
        {
          "num": 10,
          "stem": "Wer eine Kontaktanzeige aufgibt, sollte",
          "options": {
            "a": "jemanden suchen mit möglichst ähnlichen Eigenschaften.",
            "b": "sich werbewirksam präsentieren können.",
            "c": "zunächst eine Selbstanalyse vornehmen."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz empfehlen die Experten Singles, „sich erst einmal selbst kennen zu lernen, bevor sie sich an zukünftige Partnerinnen oder Partner wenden“."
        }
      ]
    },
    {
      "id": "2a",
      "title": "Test 2a – Traumfrau und Traummann gesucht",
      "isVariant": true,
      "paragraphs": [
        "Den Partner für das Leben finden - für immer mehr Menschen wird dies offenbar immer schwieriger. Rund 31 Millionen Männer und Frauen in Deutschland, also mehr als ein Drittel der gesamten Bevölkerung, sind alleinstehend. Nicht dass Mann oder Frau wählerischer als in früheren Zeiten geworden wäre, es gibt scheinbar ganz einfach immer weniger Gelegenheiten, das Ziel einer Partnerschaft oder Ehe zu erreichen.",
        "Die Menschen haben einfach immer weniger Zeit, sich um ihre ganz natürlichen Wünsche zu kümmern. Viele arbeiten weit entfernt von ihrem Wohnort, wechseln die Arbeitsstätte in relativ kurzen Abständen, haben für das Privatleben ungünstige Arbeitszeiten mit wenig Freizeit - abgesehen vom alljährlichen Urlaub. Dazu kommt, dass eine beträchtliche Minderheit der Deutschen nicht bereit ist, sich längerfristig oder gar \"lebenslänglich\" an einen bestimmten Partner zu binden. Immer mehr Menschen leben lieber mit ihren Lebensabschnittgefährten zusammen oder sie bevorzugen saisonale Kurzbeziehungen nach dem Muster \"öfter mal 'ne(n) Neue(n)\".",
        "Und immer mehr von denen, die eine Partnerschaft anstreben, versuchen ihren Liebsten oder ihre Liebste nicht auf Partys, Kirmesfesten oder in Cafés und Kneipen zu finden, wie das bei ihren Großeltern noch üblich war, sondern sie schauen ins Internet oder in Zeitungen, um über Partnerschafts- oder Heiratsannoncen fündig zu werden. In Deutschland gibt es viele Radioprogramme, in denen täglich Dutzende ihre Heiratsabsichten kundtun. An Wochenenden gibt es sogar Fernsehsendungen, in denen Partnersuchende mit anderen Partnersuchenden quasi verkuppelt werden.",
        "Doch wie muss solch eine Kontaktanzeige aussehen, damit sie auch von Erfolg gekrönt ist? Denn nicht wenige Anzeigen bringen gar keinen oder nicht den erwünschten Erfolg. Dieser Frage hat sich nun der Kommunikationsexperte Jörg Stimpfling an der Universität Stuttgart gewidmet und seit mehr als zehn Jahren Kontaktanzeigen in den verschiedensten Medien gesammelt und analysiert.",
        "Das Ergebnis der umfangreichen Forschung: Viele Anzeigen sind zu oberflächlich formuliert oder bedienen sich althergebrachter Stereotypen. So beschreiben sich Frauen mit Synonymen für Schönheit oder Attraktivität, Männer bieten Sicherheit oder Status an, überholt geglaubte Klischees finden sich in den meisten Fällen. Ebenso fällt die Neigung auf, sich schöner, besser zu präsentieren, als man wirklich ist, so als biete man ein Produkt in der Konsumwerbung an. Man könnte fast meinen, viele suchen sich selbst wie ihr eigenes Zwillingsbild.",
        "Jörg Stimpfling und seine Kollegen empfehlen Partner suchenden Singles daher, sich erst einmal selbst kennen zu lernen, bevor sie sich an zukünftige Partnerinnen oder Partner wenden. Nur wer über sich selbst Bescheid weiß, kann den Partner finden, der zu ihm passt. Und das Zwillingsbild im Spiegel ist leider kaum als idealer Partner geeignet."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Viele Menschen in Deutschland sind unverheiratet, weil",
          "options": {
            "a": "die Ansprüche bei der Partnerwahl immer weiter steigen.",
            "b": "die Lebensumstände es erschweren, den Partner oder die Partnerin fürs Leben zu finden.",
            "c": "eine Mehrheit ohnehin lieber in zeitlich begrenzten Beziehungen lebt."
          },
          "answer": "b",
          "explanation": "Im Text heißt es, es gebe immer weniger Gelegenheiten und Zeit (weite Arbeitswege, häufiger Jobwechsel, ungünstige Arbeitszeiten), einen Partner fürs Leben zu finden."
        },
        {
          "num": 7,
          "stem": "Viele Singles suchen sich heute ihre Partner oder Partnerinnen.",
          "options": {
            "a": "am Arbeitsplatz.",
            "b": "auf Festen.",
            "c": "in den Medien."
          },
          "answer": "c",
          "explanation": "Laut Text schauen immer mehr Singles „ins Internet oder in Zeitungen, um über Partnerschafts- oder Heiratsannoncen fündig zu werden“, sowie in Radio- und Fernsehsendungen."
        },
        {
          "num": 8,
          "stem": "Im Radio werden",
          "options": {
            "a": "an Samstagen und Sonntagen Partner vermitteln.",
            "b": "jeden Tag Heiratswünsche gesendet.",
            "c": "täglich Hochzeitsglückwünsche gesendet."
          },
          "answer": "b",
          "explanation": "Im Text steht: „In Deutschland gibt es viele Radioprogramme, in denen täglich Dutzende ihre Heiratsabsichten kundtun.“"
        },
        {
          "num": 9,
          "stem": "Ein Forscher hat herausgefunden, dass",
          "options": {
            "a": "klassische Rollenbilder bei der Selbstdarstellung in Kontaktanzeigen weiterhin stark verbreitet sind.",
            "b": "sich überraschenderweise immer mehr Menschen ehrlich in ihren Kontaktanzeigen beschreiben.",
            "c": "viele Kontaktanzeigen eine hohe Erfolgsquote aufweisen."
          },
          "answer": "a",
          "explanation": "Laut der Untersuchung von Jörg Stimpfling bedienen sich viele Anzeigen „althergebrachter Stereotypen“ und „überholt geglaubte Klischees finden sich in den meisten Fällen“."
        },
        {
          "num": 10,
          "stem": "Wer eine Kontaktanzeige aufgibt, sollte",
          "options": {
            "a": "jemanden suchen mit möglichst ähnlichen Eigenschaften.",
            "b": "sich werbewirksam präsentieren können.",
            "c": "zunächst eine Selbstanalyse vornehmen."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz empfehlen die Experten Singles, „sich erst einmal selbst kennen zu lernen, bevor sie sich an zukünftige Partnerinnen oder Partner wenden“."
        }
      ]
    },
    {
      "id": "3",
      "title": "Test 3 – Der Fluch des Informationszeitalters oder Alles schon vergessen? oder Der Kampf mit der Informationsflut",
      "isVariant": false,
      "paragraphs": [
        "Melanie Hoffmann ist Gedächtnistrainerin. Seit fast zehn Jahren bietet sie nun schon Seminare an Volkshochschulen, in Altenheimen, in Banken und Industriebetrieben an, in denen die Seminarteilnehmer lernen sollen, wie sie Informationen besser im Gedächtnis behalten. Suma Hartmann ist 30 Jahre alt, Bürokauffrau und eine von Melanie Hoffmanns Seminarteilnehmerinnen. \"An meinem Arbeitsplatz bekomme ich ständig Massen von neuen Informationen: Texte, die zu lesen sind, Termine, Anrufe, Anfragen von Kunden, Kurzinfos von Kollegen: Diese Informationsflut zu bewältigen und möglichst nichts zu vergessen, ist fast ausgeschlossen\", so Hartmann. Wie ihr geht es vielen Menschen in unserer Informationsgesellschaft – und das quer durch alle Altersstufen: vom Schüler bis zum Rentner. Sie fühlen sich den Anforderungen an ihr Gedächtnis nicht mehr gewachsen, und unter anderem daher besuchen sie Trainingskurse wie die von Melanie Hoffmann. Während jeder Sekunde, die Suma Hartmann im Trainingsseminar, am Arbeitsplatz oder zu Hause verbringt, nimmt sie über ihre \"Eingangskanäle\" – die Augen, die Ohren, die Nase, den Mund, die Haut – um die zwei Millionen kleinste Informationen unbewusst auf. Jede kleinste Schwankung in der Licht- oder Farbintensität, Formen und Farben, Licht und Schatten, alle nur erdenklichen Geräusche von der Stimme der Seminarleiterin oder Kollegin bis zum draußen vorbeifahrenden Motorrad, verschiedenste Gerüche vom Schweiß bis zum teuren Parfüm, das Kratzen des Pullovers auf der Haut: All dies nimmt sie unbewusst wahr. Würde sie sich all diese Informationen bewusst merken wollen, wäre – wenn man die Sprache der Computerwelt zu Hilfe nimmt – innerhalb kürzester Zeit der Speicher voll.",
        "Damit dies nicht passiert, vergisst man fast alle Informationseinheiten innerhalb der nächsten 20 Sekunden wieder – und schafft damit Platz für neue Informationen. Erst nach etwa 20 Minuten behalten wir etwas auf lange Zeit. Dann haben die Nervenzellen im Gehirn eine neue Verbindung hergestellt, eine Synapse gebildet – und wir behalten etwas, statt es gleich wieder zu vergessen. Die Trainerin Melanie Hoffmann sagt: \"Starke Sinneseindrücke, die mit Emotionen behaftet sind, behält man ebenso wie das, was interessant ist oder lebensnotwendig. Ein Kind, das einmal eine heiße Herdplatte angefasst hat, vergisst nie mehr, was 'heiß' bedeutet. Ein Hobbyastronom, dem seine Freizeitbeschäftigung großen Spaß bereitet, kennt im Nu alle möglichen Namen von Sternen. Und ich habe noch keinen Seminarteilnehmer gehabt, der sich nicht mehr daran erinnern könnte, was am 11. September 2001 in New York passiert ist\". In unserer heutigen Informationsgesellschaft ist es wichtig, die auf uns einströmende Informationsflut zu bündeln, Daten und Begriffe zu gruppieren oder an Bildern oder Gegenständen festzumachen und sich so \"Eselsbrücken\" zu bauen, die dabei helfen, mehr im Gedächtnis zu behalten. Suma Hartmann \"sortiert\" jetzt im Geiste alle wichtigen Informationen in bestimmte Schubladen ihres Aktenschrankes in ihrem Büro: \"Ich habe mir Zahlensymbole ausgedacht, mit denen ich die neuen Informationen bildlich verknüpfe: Die Eins wird zur Kerze, die Zwei zum Schwan usw. Wenn ich nun nicht vergessen möchte, um zwei Uhr eine bestimmte Konferenz vorzubereiten, denke ich mir meine Konferenzmappe im Schnabel des Schwans. Und es funktioniert: Ich vergesse viel weniger.\""
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Melanie Hoffmanns Seminare besuchen",
          "options": {
            "a": "ausschließlich Frauen, die im Büro arbeiten",
            "b": "junge und alte Menschen gleichermaßen",
            "c": "überwiegend alte Menschen"
          },
          "answer": "b",
          "explanation": "Im Text steht: „Wie ihr geht es vielen Menschen in unserer Informationsgesellschaft – und das quer durch alle Altersstufen: vom Schüler bis zum Rentner.“"
        },
        {
          "num": 7,
          "stem": "Die Teilnehmer besuchen Frau Hoffmanns Seminar, weil sie",
          "options": {
            "a": "das Gefühl haben, dass ihr Gedächtnis schlechter wird",
            "b": "immer mehr vergessen",
            "c": "sich von den vielen Informationen überfordert fühlen"
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Sie fühlen sich den Anforderungen an ihr Gedächtnis nicht mehr gewachsen, und unter anderem daher besuchen sie Trainingskurse wie die von Melanie Hoffmann.“"
        },
        {
          "num": 8,
          "stem": "Jeder Mensch",
          "options": {
            "a": "kann sich alle erdenklichen Geräusche und Gerüche merken",
            "b": "kann über einen Zeitraum von 20 Minuten alles behalten.",
            "c": "vergisst die meisten Informationen innerhalb kürzester Zeit"
          },
          "answer": "c",
          "explanation": "Im Text steht: „Damit dies nicht passiert, vergisst man fast alle Informationseinheiten innerhalb der nächsten 20 Sekunden wieder – und schafft damit Platz für neue Informationen.“"
        },
        {
          "num": 9,
          "stem": "Besonders gut kann man sich",
          "options": {
            "a": "als Kind etwas merken",
            "b": "an Daten und Begriffe erinnern",
            "c": "emotional aufgeladene Situationen merken"
          },
          "answer": "c",
          "explanation": "Die Trainerin sagt im Text: „Starke Sinneseindrücke, die mit Emotionen behaftet sind, behält man ebenso wie das, was interessant ist oder lebensnotwendig.“"
        },
        {
          "num": 10,
          "stem": "Suma Hartmann",
          "options": {
            "a": "lehrt andere, wie man sich \"Eselsbrücken\" ausdenkt.",
            "b": "verbindet Informationen mit Bildern.",
            "c": "verwendet für ihre Aktenablage nur Tiersymbole"
          },
          "answer": "b",
          "explanation": "Suma Hartmann sagt im Text: „Ich habe mir Zahlensymbole ausgedacht, mit denen ich die neuen Informationen bildlich verknüpfe: Die Eins wird zur Kerze, die Zwei zum Schwan usw.“"
        }
      ]
    },
    {
      "id": "3a",
      "title": "Test 3a – Der Fluch des Informationszeitalters oder Alles schon vergessen? oder Der Kampf mit der Informationsflut",
      "isVariant": true,
      "paragraphs": [
        "Susana Winkler ist Gedächtnistrainerin. Seit fast zehn Jahren bietet sie nun schon Seminare an Volkshochschulen, in Altenheimen, in Banken und Industriebetrieben an, in denen die Seminarteilnehmer lernen sollen, wie sie Informationen besser im Gedächtnis behalten. Jenny Helfer ist 30 Jahre alt, Bürokauffrau und eine von Susana Winklers Seminarteilnehmerinnen. \"An meinem Arbeitsplatz bekomme ich ständig Massen von neuen Informationen: Texte, die zu lesen sind, Termine, Anrufe, Anfragen von Kunden, Kurzinfos von Kollegen: Diese Informationsflut zu bewältigen und möglichst nichts zu vergessen, ist fast ausgeschlossen\", so Hartmann. Wie ihr geht es vielen Menschen in unserer Informationsgesellschaft – und das quer durch alle Altersstufen: vom Schüler bis zum Rentner. Sie fühlen sich den Anforderungen an ihr Gedächtnis nicht mehr gewachsen, und unter anderem daher besuchen sie Trainingskurse wie die von Susana Winkler. Während jeder Sekunde, die Jenny Helfer im Trainingsseminar, am Arbeitsplatz oder zu Hause verbringt, nimmt sie über ihre \"Eingangskanäle\" – die Augen, die Ohren, die Nase, den Mund, die Haut – um die zwei Millionen kleinste Informationen unbewusst auf. Jede kleinste Schwankung in der Licht- oder Farbintensität, Formen und Farben, Licht und Schatten, alle nur erdenklichen Geräusche von der Stimme der Seminarleiterin oder Kollegin bis zum draußen vorbeifahrenden Motorrad, verschiedenste Gerüche vom Schweiß bis zum teuren Parfüm, das Kratzen des Pullovers auf der Haut: All dies nimmt sie unbewusst wahr. Würde sie sich all diese Informationen bewusst merken wollen, wäre – wenn man die Sprache der Computerwelt zu Hilfe nimmt – innerhalb kürzester Zeit der Speicher voll.",
        "Damit dies nicht passiert, vergisst man fast alle Informationseinheiten innerhalb der nächsten 20 Sekunden wieder – und schafft damit Platz für neue Informationen. Erst nach etwa 20 Minuten behalten wir etwas auf lange Zeit. Dann haben die Nervenzellen im Gehirn eine neue Verbindung hergestellt, eine Synapse gebildet – und wir behalten etwas, statt es gleich wieder zu vergessen. Die Trainerin Susana Winkler sagt: \"Starke Sinneseindrücke, die mit Emotionen behaftet sind, behält man ebenso wie das, was interessant ist oder lebensnotwendig. Ein Kind, das einmal eine heiße Herdplatte angefasst hat, vergisst nie mehr, was 'heiß' bedeutet. Ein Hobbyastronom, dem seine Freizeitbeschäftigung großen Spaß bereitet, kennt im Nu alle möglichen Namen von Sternen. Und ich habe noch keinen Seminarteilnehmer gehabt, der sich nicht mehr daran erinnern könnte, was am 11. September 2001 in New York passiert ist\". In unserer heutigen Informationsgesellschaft ist es wichtig, die auf uns einströmende Informationsflut zu bündeln, Daten und Begriffe zu gruppieren oder an Bildern oder Gegenständen festzumachen und sich so \"Eselsbrücken\" zu bauen, die dabei helfen, mehr im Gedächtnis zu behalten. Jenny Helfer \"sortiert\" jetzt im Geiste alle wichtigen Informationen in bestimmte Schubladen ihres Aktenschrankes in ihrem Büro: \"Ich habe mir Zahlensymbole ausgedacht, mit denen ich die neuen Informationen bildlich verknüpfe: Die Eins wird zur Kerze, die Zwei zum Schwan usw. Wenn ich nun nicht vergessen möchte, um zwei Uhr eine bestimmte Konferenz vorzubereiten, denke ich mir meine Konferenzmappe im Schnabel des Schwans. Und es funktioniert: Ich vergesse viel weniger.\""
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Zielgruppen von Frau Winklers Seminaren besteht.",
          "options": {
            "a": "überwiegend aus Senioren.",
            "b": "sowohl aus jungen als auf alten Menschen.",
            "c": "hauptsächlich aus berufstätigen Frauen."
          },
          "answer": "b",
          "explanation": "Im Text steht, dass Menschen „quer durch alle Altersstufen: vom Schüler bis zum Rentner“ ihre Trainingskurse besuchen."
        },
        {
          "num": 7,
          "stem": "Die Teilnehmer besuchen Frau Winklers Seminar, weil sie",
          "options": {
            "a": "sich von den vielen Informationen überfordert fühlen",
            "b": "sich alles bewusst merken wollen.",
            "c": "das Gefühl haben, dass ihr Gedächtnis nachlässt"
          },
          "answer": "a",
          "explanation": "Im Text heißt es: „Sie fühlen sich den Anforderungen an ihr Gedächtnis nicht mehr gewachsen, und unter anderem daher besuchen sie Trainingskurse wie die von Susana Winkler.“"
        },
        {
          "num": 8,
          "stem": "Jeder Mensch",
          "options": {
            "a": "vergisst die meisten Informationen innerhalb kürzester Zeit",
            "b": "kann über einen Zeitraum von 20 Minuten alles behalten.",
            "c": "kann sich alle erdenklichen Geräusche und Gerüche merken."
          },
          "answer": "a",
          "explanation": "Im Text steht: „Damit dies nicht passiert, vergisst man fast alle Informationseinheiten innerhalb der nächsten 20 Sekunden wieder.“"
        },
        {
          "num": 9,
          "stem": "Besonders gut kann man sich",
          "options": {
            "a": "intensive Gefühle merken.",
            "b": "an Daten und Begriffe erinnern",
            "c": "als Kind etwas merken."
          },
          "answer": "a",
          "explanation": "Laut Trainerin Susana Winkler behält man „starke Sinneseindrücke, die mit Emotionen behaftet sind“, besonders gut."
        },
        {
          "num": 10,
          "stem": "Jenny Helfer",
          "options": {
            "a": "verwendet für ihre Aktenablage nur Tiersymbole",
            "b": "verbindet Informationen mit Bildern",
            "c": "lehrt andere, wie man sich \"Eselsbrücken\" ausdenkt."
          },
          "answer": "b",
          "explanation": "Jenny Helfer berichtet im Text: „Ich habe mir Zahlensymbole ausgedacht, mit denen ich die neuen Informationen bildlich verknüpfe.“"
        }
      ]
    },
    {
      "id": "3b",
      "title": "Test 3b – Der Fluch des Informationszeitalters oder Alles schon vergessen? oder Der Kampf mit der Informationsflut",
      "isVariant": true,
      "paragraphs": [
        "Susana Winkler ist Gedächtnistrainerin. Seit fast zehn Jahren bietet sie nun schon Seminare an Volkshochschulen, in Altenheimen, in Banken und Industriebetrieben an, in denen die Seminarteilnehmer lernen sollen, wie sie Informationen besser im Gedächtnis behalten. Jenny Helfer ist 30 Jahre alt, Bürokauffrau und eine von Susana Winklers Seminarteilnehmerinnen. \"An meinem Arbeitsplatz bekomme ich ständig Massen von neuen Informationen: Texte, die zu lesen sind, Termine, Anrufe, Anfragen von Kunden, Kurzinfos von Kollegen: Diese Informationsflut zu bewältigen und möglichst nichts zu vergessen, ist fast ausgeschlossen\", so Hartmann. Wie ihr geht es vielen Menschen in unserer Informationsgesellschaft – und das quer durch alle Altersstufen: vom Schüler bis zum Rentner. Sie fühlen sich den Anforderungen an ihr Gedächtnis nicht mehr gewachsen, und unter anderem daher besuchen sie Trainingskurse wie die von Susana Winkler. Während jeder Sekunde, die Jenny Helfer im Trainingsseminar, am Arbeitsplatz oder zu Hause verbringt, nimmt sie über ihre \"Eingangskanäle\" – die Augen, die Ohren, die Nase, den Mund, die Haut – um die zwei Millionen kleinste Informationen unbewusst auf. Jede kleinste Schwankung in der Licht- oder Farbintensität, Formen und Farben, Licht und Schatten, alle nur erdenklichen Geräusche von der Stimme der Seminarleiterin oder Kollegin bis zum draußen vorbeifahrenden Motorrad, verschiedenste Gerüche vom Schweiß bis zum teuren Parfüm, das Kratzen des Pullovers auf der Haut: All dies nimmt sie unbewusst wahr. Würde sie sich all diese Informationen bewusst merken wollen, wäre – wenn man die Sprache der Computerwelt zu Hilfe nimmt – innerhalb kürzester Zeit der Speicher voll.",
        "Damit dies nicht passiert, vergisst man fast alle Informationseinheiten innerhalb der nächsten 20 Sekunden wieder – und schafft damit Platz für neue Informationen. Erst nach etwa 20 Minuten behalten wir etwas auf lange Zeit. Dann haben die Nervenzellen im Gehirn eine neue Verbindung hergestellt, eine Synapse gebildet – und wir behalten etwas, statt es gleich wieder zu vergessen. Die Trainerin Susana Winkler sagt: \"Starke Sinneseindrücke, die mit Emotionen behaftet sind, behält man ebenso wie das, was interessant ist oder lebensnotwendig. Ein Kind, das einmal eine heiße Herdplatte angefasst hat, vergisst nie mehr, was 'heiß' bedeutet. Ein Hobbyastronom, dem seine Freizeitbeschäftigung großen Spaß bereitet, kennt im Nu alle möglichen Namen von Sternen. Und ich habe noch keinen Seminarteilnehmer gehabt, der sich nicht mehr daran erinnern könnte, was am 11. September 2001 in New York passiert ist\". In unserer heutigen Informationsgesellschaft ist es wichtig, die auf uns einströmende Informationsflut zu bündeln, Daten und Begriffe zu gruppieren oder an Bildern oder Gegenständen festzumachen und sich so \"Eselsbrücken\" zu bauen, die dabei helfen, mehr im Gedächtnis zu behalten. Jenny Helfer \"sortiert\" jetzt im Geiste alle wichtigen Informationen in bestimmte Schubladen ihres Aktenschrankes in ihrem Büro: \"Ich habe mir Zahlensymbole ausgedacht, mit denen ich die neuen Informationen bildlich verknüpfe: Die Eins wird zur Kerze, die Zwei zum Schwan usw. Wenn ich nun nicht vergessen möchte, um zwei Uhr eine bestimmte Konferenz vorzubereiten, denke ich mir meine Konferenzmappe im Schnabel des Schwans. Und es funktioniert: Ich vergesse viel weniger.\""
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Zielgruppen von Frau Winklers Seminaren besteht",
          "options": {
            "a": "hauptsächlich aus berufstätigen Frauen.",
            "b": "sowohl aus jungen als auf alten Menschen.",
            "c": "überwiegend aus Senioren."
          },
          "answer": "b",
          "explanation": "Im Text steht, dass Menschen „quer durch alle Altersstufen: vom Schüler bis zum Rentner“ ihre Trainingskurse besuchen."
        },
        {
          "num": 7,
          "stem": "Die Teilnehmer besuchen Frau Winklers Seminar, weil sie",
          "options": {
            "a": "das Gefühl haben, dass ihr Gedächtnis nachlässt.",
            "b": "sich alles bewusst merken wollen.",
            "c": "sich von den vielen Informationen überfordert fühlen"
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Sie fühlen sich den Anforderungen an ihr Gedächtnis nicht mehr gewachsen, und unter anderem daher besuchen sie Trainingskurse wie die von Susana Winkler.“"
        },
        {
          "num": 8,
          "stem": "Jeder Mensch",
          "options": {
            "a": "kann sich alle erdenklichen Geräusche und Gerüche merken.",
            "b": "kann über einen Zeitraum von 20 Minuten alles behalten",
            "c": "vergisst die meisten Informationen innerhalb kürzester Zeit ."
          },
          "answer": "c",
          "explanation": "Im Text steht: „Damit dies nicht passiert, vergisst man fast alle Informationseinheiten innerhalb der nächsten 20 Sekunden wieder.“"
        },
        {
          "num": 9,
          "stem": "Besonders gut kann man sich",
          "options": {
            "a": "als Kind etwas merken.",
            "b": "an Daten und Begriffe erinnern.",
            "c": "intensive Gefühle merken."
          },
          "answer": "c",
          "explanation": "Laut Trainerin Susana Winkler behält man „starke Sinneseindrücke, die mit Emotionen behaftet sind“, besonders gut."
        },
        {
          "num": 10,
          "stem": "Jenny Helfer",
          "options": {
            "a": "lehrt andere, wie man sich \"Eselsbrücken\" ausdenkt.",
            "b": "verbindet Informationen mit Bildern.",
            "c": "verwendet für ihre Aktenablage nur Tiersymbole"
          },
          "answer": "b",
          "explanation": "Jenny Helfer berichtet im Text: „Ich habe mir Zahlensymbole ausgedacht, mit denen ich die neuen Informationen bildlich verknüpfe.“"
        }
      ]
    },
    {
      "id": "4",
      "title": "Test 4 – Verpackungen im Supermarkt: Geht's auch ohne?",
      "isVariant": false,
      "paragraphs": [
        "Auf dem Weg zum Supermarkt klappern bei manchen Kunden im Ruhrpott und in Baden-Württemberg seit kurzem die Plastikdosen in den Einkaufstaschen. Noch sind sie leer, denn die Kunden können sich nun an der Frischetheke Wurst und Käse in die mitgebrachte Dose packen lassen. Dieser Trend, der inzwischen auch von konventionellen Supermärkten aufgegriffen wird, wurde von den sogenannten \"Unverpackt-Läden\" angestoßen, in denen man Lebensmittel in eigene Behälter füllen kann. Mittlerweile gibt es mehr als 50 dieser vollständig verpackungsfreien Geschäfte, in Deutschland meist in den Großstädten. Doch noch ist der Einkauf in diesen Läden oft teurer, da die Händler nicht zu den gleichen günstigen Konditionen einkaufen können wie die Großmärkte. Der Vorteil: Die Waren sind meist bio und tragen unverpackt zur Reduzierung des Plastikmülls bei. Außerdem nimmt man für gewöhnlich nur so viel mit, wie man tatsächlich braucht, und verschwendet weniger Lebensmittel. Dieses Konzept interessiert zwar immer mehr Leute, die gerne ihren täglichen Müll verringern würden. Für viele sind Aufwand und Kosten aber bisher noch zu hoch.",
        "Also beginnt der Verzicht auf Plastik im Kleinen. Von einer Dokumentation über einen Unverpackt-Laden in Berlin hat sich auch Kaufmann Dieter Hieber inspirieren lassen. Er ist Inhaber von zwölf Supermärkten in Baden-Württemberg. Im vorigen Jahr hat er sich vorgenommen, in seinen Supermärkten Alternativen zu Plastikverpackungen anzubieten. In der Obst- und Gemüseecke sollen die Kunden ihre Einkäufe künftig in recycelten Netzen verstauen können und das Brot darf man in den eigenen Jutebeutel packen. Ware von der Frischetheke kann der Kunde in seine eigene mitgebrachte Dose einpacken lassen. „Ich habe noch nicht für alles eine Patentlösung“, sagt Hieber, „Aber ich möchte unbedingt in verschiedenen Bereichen plastikfreie Mehrweg-Verpackungen anbieten“. Der Weg ist jedoch weit, wenn Lebensmittel wieder in ihrer ursprünglichen Form angeboten werden sollen. Als Hieber die Ideen seinen Mitarbeitern vorstellte, waren diese zunächst schwer davon zu überzeugen: Das erlauben die Hygienebestimmungen nicht, wandten sie ein.",
        "Tatsächlich gibt es bundesweit aber gar keine einheitliche Empfehlung dazu, ob und in welcher Form die Dosen der Kunden angenommen werden dürfen. Ideen müssen individuell mit der örtlich zuständigen Lebensmittelüberwachung besprochen werden. „Die Lebensmittelunternehmen sind selbst verantwortlich für die Hygiene in ihren Märkten“, sagt eine Mitarbeiterin der Lebensmittelüberwachung im Kreis Wesel. Wie gut das Verfahren in der Praxis funktioniert, muss die Erfahrung zeigen. Ob Mitarbeiter zum Beispiel auch unsaubere Boxen annehmen, wie viele Kunden das Angebot überhaupt wahrnehmen und ob es nicht doch zu umständlich ist.",
        "Für Hieber ist der Verzicht auf Plastikmüll eher eine Frage der Überzeugung als des Gewinns. Obwohl die Reaktionen auf seine Vorhaben fast ausschließlich positiv waren, wird das Angebot noch kaum genutzt. Es ist nicht nur ein Kampf gegen Plastik, sondern auch ein Kampf gegen die Bequemlichkeit der Kunden. „Viele lassen sich erst im Geschäft inspirieren, was sie kaufen wollen und haben dann keine eigene Box dabei“. Von mehreren Tausend Kunden reichen am Tag nur fünf bis zehn ihre Plastikbox über die Theke. Auch Rabattaktionen oder Belohnungssysteme wie Stempelkarten mit Vorteilen haben nur sehr kurzfristig etwas gebracht. Deshalb sagt Hieber: „Man muss es den Leuten so einfach wie möglich machen“. Er überlegt, künftig zusätzlich Mehrwegbehälter im Pfandsystem anzubieten. Bei einem spontanen Einkauf können die Kunden eine Dose leihen und beim nächsten Mal wieder zurückgeben. Der Markt reinigt und spült die Dosen dann – dafür müsste Hieber jedoch nicht nur in Dosen, sondern auch in eine Spülstraße investieren.",
        "Der Einkauf ohne Verpackung wird also doch nicht flächendeckend möglich sein, da er auch längerfristig nicht leicht umzusetzen ist. Der Kompromiss heißt zumeist: Verpackungen reduzieren. Für die reinen Unverpackt-Läden sind die großen Supermarkt-Ketten noch keine Konkurrenz. Allerdings verlieren auch die Supermärkte noch keine Kunden durch das Unverpackt-Konzept. Und es bleibt festzustellen: Ob unverpackt einkaufen wird, hängt vor allem von der Kundschaft ab. Und da ist auch jeder einzelne gefragt. Bereits jetzt könnten viele Verpackungen vermieden werden. Der Kunde muss das aber auch wollen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Unverpackte Waren werden",
          "options": {
            "a": "in Großmärkten zu günstigen Bedingungen verkauft.",
            "b": "nur in speziellen Läden verkauft.",
            "c": "von den Kunden meist vollständig verbraucht."
          },
          "answer": "c",
          "explanation": "Im Text steht über den unverpackten Einkauf: „Außerdem nimmt man für gewöhnlich nur so viel mit, wie man tatsächlich braucht, und verschwendet weniger Lebensmittel.“"
        },
        {
          "num": 7,
          "stem": "Supermarktinhaber Dieter Hieber",
          "options": {
            "a": "konnte seine Angestellten sofort mit seinen Ideen begeistern.",
            "b": "möchte mehr umweltfreundliche Verpackungen verwenden.",
            "c": "will in seinen Supermärkten auf Einwegverpackungen ganz verzichten."
          },
          "answer": "b",
          "explanation": "Im Text sagt Hieber: „Ich habe noch nicht für alles eine Patentlösung, aber ich möchte unbedingt in verschiedenen Bereichen plastikfreie Mehrweg-Verpackungen anbieten.“"
        },
        {
          "num": 8,
          "stem": "Die Verwendung von Frischhaltedosen in Supermärkten",
          "options": {
            "a": "ist eigentlich aus hygienischen Gründen verboten.",
            "b": "könnte eine praktikable Möglichkeit sein, Müll zu vermeiden.",
            "c": "wird genau durch gesetzliche Vorgaben geregelt."
          },
          "answer": "b",
          "explanation": "Es gibt kein Verbot und keine bundesweit einheitliche gesetzliche Regelung; wie gut das Verfahren in der Praxis funktioniert, um Müll zu reduzieren, muss die Erfahrung zeigen."
        },
        {
          "num": 9,
          "stem": "Hiebers Angebot, Mehrwegbehälter zu nutzen,",
          "options": {
            "a": "ist nun dank eines Bonussystems erfolgreicher.",
            "b": "nehmen Kunden auch bei spontanen Einkäufen an.",
            "c": "rief allgemeine Zustimmung hervor."
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Obwohl die Reaktionen auf seine Vorhaben fast ausschließlich positiv waren, wird das Angebot noch kaum genutzt.“"
        },
        {
          "num": 10,
          "stem": "Das verpackungsfreie Einkaufen wird",
          "options": {
            "a": "bald in allen Supermärkten Realität sein.",
            "b": "künftig von allen Verbrauchern genutzt werden.",
            "c": "sich nur langsam durchsetzen."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz steht: „Der Einkauf ohne Verpackung wird also doch nicht flächendeckend möglich sein, da er auch längerfristig nicht leicht umzusetzen ist.“"
        }
      ]
    },
    {
      "id": "5",
      "title": "Test 5 – Die Deutschen und ihre Ernährung",
      "isVariant": false,
      "paragraphs": [
        "Bei den Deutschen wächst das Bewusstsein für ihre gesunde Ernährung. Das geht aus einer kürzlich veröffentlichten Studie hervor, bei der 1000 Erwachsene in Deutschland zu ihrem Essverhalten befragt wurden. In dieser Untersuchung antworteten 45% der Befragten auf die Frage, worauf es ihnen bei ihrer Ernährung ankommt, dass sie vor allem gesund Essen möchten. Damit steht laut der Studie erstmal das Kriterium gesund vor lecker. In der vorhergehenden Umfrage war das Kriterium lecker den Befragten noch am wichtigsten. Dennoch bleibt der Geschmack ein wichtiges Kriterium: für immerhin 41% aller Befragten kommt es beim Essen auf den Genuss an. Im Vergleich zur Voruntersuchung sind die beiden Kriterien \"Hauptsache schnell\" und \"Hauptsache günstig\" weniger wichtig geworden: Die Deutschen nehmen sich demnach etwas mehr Zeit für ihre Ernährung und sind auch eher bereit, mehr Geld für gute Lebensmittel auszugeben. Allerdings hat auch das Kriterium Kalorienarm an Bedeutung verloren. Nur mehr 5% gegenüber 9% in der Voruntersuchung denken bei der Wahl von Lebensmitteln an die schlanke Linie. Dazu passt, dass knapp die Hälfte der Befragten selbst angibt, Übergewicht zu haben, bezeichnen sich sogar als stark übergewichtig. Gesundheitspsychologen führen das darauf zurück, dass häufig die Zeit für den Einkauf und die Zubereitung von frischen Lebensmitteln fehlt. Die Menschen griffen dann aus Bequemlichkeit zu Fertiggerichten oder Snacks, die häufig zu viel Fett, Salz oder Zucker enthalten. Dabei ließen sich durch die Ernährung viele Risikofaktoren reduzieren, betonten die Experten.",
        "An mangelndem Wissen scheint das nicht zu liegen: nur ein Viertel der Befragten gab an, nicht genug über gesunde Ernährung zu wissen. Dennoch forderten einige Fachleute bessere Verbraucherinformationen. Sie warfen der Bundesregierung vor, es fehle offensichtlich an dem politischen Willen, sich mit der Branche anzulegen. Die gesunde Wahl werde unnötig schwer gemacht. Ein Großteil der Erfrischungsgetränke sei überzuckert, die Kennzeichnung von Fett, Zucker und Salz sei eine Zumutung und selbst Süßigkeiten würden wie gesunde Produkte beworben. \"Das ist kein Bildungsproblem, sondern ein Problem des Angebotes, das die Lebensmittelwirtschaft uns vorsetzt.\" Deshalb sehen diese Fachleute die Industrie und Politik in der Pflicht: \"Wenn ich Licht und Lupe brauche, um diese Liste lesen zu können, läuft etwas falsch\", bringt einer von ihnen die Kritik auf den Punkt. Ihr Argument lautet: Das Problem ist nicht, ob vegetarische Produkte Wurst oder Frikadelle heißen dürfen, sondern ob der Verbraucher weiß, was an Zusatzstoffen in seiner vermeintlich gesunden Alternative steckt.",
        "Die Studienergebnisse zeigen, dass es im Umgang mit Lebensmitteln erhebliche Unterschiede zwischen den Altersgruppen gibt. So herrscht bei Jüngeren eine vergleichsweise starke Wegwerfmentalität. Bei 14% der 18- bis 25-Jährigen landet häufig oder sogar sehr häufig Essen im Müll. Nur jedem Zweiten aus dieser Altersgruppe passiert das selten oder nie. Bei den Älteren ab Mitte 60 entsorgen dagegen 86% selten oder nie Lebensmittel in den Müll. Insgesamt wirft mehr als jeder dritte Deutsche regelmäßig Lebensmittel weg. Auch der Fleischkonsum unterscheidet sich je nach Altersgruppe: Unter den 18- bis 39-Jährigen ist der Anteil jener, die auf Fleisch verzichten, höher als in der Gesamtbevölkerung. 3% unter ihnen bezeichnen sich als Vegetarier und 2% als Veganer. In Deutschland bezeichnen sich 13% der Menschen als Flexitarier. Flexitarier kaufen meist selbst weder Fleisch noch Wurst, lehnen es aber auch nicht vollständig ab, wenn es ihnen angeboten wird. Bioprodukte spielen mittlerweile eine große Rolle. Von den Befragten gaben 40% an, bevorzugt Lebensmittel mit Bio-Siegel zu kaufen; vor einigen Jahren gab nur ein Drittel der Befragten an, im Geschäft zu biologisch hergestellten Lebensmitteln zu greifen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die meisten Befragten finden, dass das Essen.",
          "options": {
            "a": "früher besser war.",
            "b": "gesund sein sollte.",
            "c": "vor allem gut schmecken muss."
          },
          "answer": "b",
          "explanation": "Im Text steht: „In dieser Untersuchung antworteten 45% der Befragten auf die Frage, worauf es ihnen bei ihrer Ernährung ankommt, dass sie vor allem gesund Essen möchten. Damit steht laut der Studie erstmal das Kriterium gesund vor lecker.“"
        },
        {
          "num": 7,
          "stem": "Das Kriterium kalorienarm.",
          "options": {
            "a": "ist für die Hälfte der Befragten wichtig.",
            "b": "steht bei Übergewichtigen an erster Stelle.",
            "c": "war früher wichtiger."
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Allerdings hat auch das Kriterium Kalorienarm an Bedeutung verloren. Nur mehr 5% gegenüber 9% in der Voruntersuchung denken bei der Wahl von Lebensmitteln an die schlanke Linie.“"
        },
        {
          "num": 8,
          "stem": "Experten glauben, dass Menschen ungesund essen, weil.",
          "options": {
            "a": "ihnen Fett und Zucker gut schmecken.",
            "b": "sie sich nicht genug informieren.",
            "c": "zu viele ungesunde Lebensmittel auf dem Markt sind."
          },
          "answer": "c",
          "explanation": "Die Fachleute sagen im Text: „Das ist kein Bildungsproblem, sondern ein Problem des Angebotes, das die Lebensmittelwirtschaft uns vorsetzt.“"
        },
        {
          "num": 9,
          "stem": "Das Wegwerfen von Lebensmitteln.",
          "options": {
            "a": "findet ein Drittel der Befragten in Ordnung.",
            "b": "lehnen jüngere Menschen vollkommen ab.",
            "c": "passiert bei älteren Menschen fast nie."
          },
          "answer": "c",
          "explanation": "Im Text steht: „Bei den Älteren ab Mitte 60 entsorgen dagegen 86% selten oder nie Lebensmittel in den Müll.“"
        },
        {
          "num": 10,
          "stem": "Der Fleischkonsum.",
          "options": {
            "a": "ist nicht in allen Altersgruppen gleich.",
            "b": "kommt für dreizehn Prozent der Jugendlichen nicht in Frage.",
            "c": "nimmt mit dem Alter zu"
          },
          "answer": "a",
          "explanation": "Im Text steht: „Auch der Fleischkonsum unterscheidet sich je nach Altersgruppe: Unter den 18- bis 39-Jährigen ist der Anteil jener, die auf Fleisch verzichten, höher als in der Gesamtbevölkerung.“"
        }
      ]
    },
    {
      "id": "6",
      "title": "Test 6 – Wie unsere Kaufentscheidungen beeinflusst werden oder Interessante Fakten über das Verhalten von Konsumenten",
      "isVariant": false,
      "paragraphs": [
        "Haben Sie schon einmal darüber nachgedacht, warum Sie manche Dinge kaufen und andere nicht? Warum Sie etwas einkaufen, das Sie gar nicht brauchen, obwohl Sie eigentlich aus einem ganz anderen Grund ins Geschäft gegangen sind? Die Ursache dafür liegt in unserem Körper. Er steuert unsere Entscheidungen viel stärker als bisher gedacht. Neue Forschungen setzen sich mit diesem Zusammenhang zwischen Körper, Kaufverhalten und Umweltbedingungen auseinander.",
        "Nachdem Forscher Studenten über Filme und ihr Fernsehverhalten befragt hatten, fanden Sie Beweise dafür, dass gefühlte Kälte (zum Beispiel im Winter) ein Bedürfnis nach psychologischer Wärme hervorruft. Vorangegangene Studien hatten sich mit der Psychologie der Liebe beschäftigt. Dabei konnte gezeigt werden, dass verliebte Menschen sehr häufig das Gefühl feuchter Hände, gesteigertes Herzklopfen und beschleunigte Atmung wahrnehmen. Das alles sind Anzeichen, die auch mit körperlich erlebter Wärme zusammenhängen. Wenn uns kalt ist, beeinflusst daher unser Bedürfnis nach Wärme zum Beispiel den Kauf von romantischen Filmen auf DVD. Um diesen Zusammenhang zu belegen, manipulierten Forscher in einer Reihe von Experimenten entweder die Temperatur von Tee oder die Raumtemperatur. Kalter Tee oder eine niedrige Raumtemperatur sorgten dafür, dass die Teilnehmer Romantikfilme reizvoller fanden. Dieser Effekt trat unabhängig von Geschlecht und Alter bei allen Menschen auf. Wenn Hersteller also romantische DVDs herausgeben oder Reiseveranstalter \"kuschelige Angebote für Zwei\" verkaufen wollen, sollten sie damit bis zum Herbst oder Winter warten. Das Bedürfnis der Käufer nach diesen Waren ist dann ungleich größer. Aber wenn die Verkaufsräume eines Kaufhauses kühl klimatisiert sind, werden \"wärmende\" Angebote wie zum Beispiel Tee auch im Sommer mehr gekauft.",
        "Andere Forschungen befassen sich mit dem Zusammenhang von Menge und Preis. Beim Erstellen von attraktiven Angeboten und Werbeveranstaltungen machen sich regelmäßig Menschen aus unterschiedlichen Bereichen, wie Marketing und Vertrieb, Gedanken über den richtigen Preis und die passenden Werbe-Botschaften. Bisher wenig beachtet wurde die Reihenfolge der Angabe von Preis und Menge. Neue Studien zeigen, dass Konsumenten auf Angebote extrem unterschiedlich reagieren, je nachdem, ob ihnen bei Sonderangeboten zuerst der Preis oder zuerst die Menge genannt wird. Eine neue Studie untersuchte nun die Reaktionen der Konsumenten auf genau diese Reihenfolge. Die Information über eine große Menge vor die Preisinformation zu setzen scheint deutlich reizvoller auf Konsumenten zu wirken als den Preis vor der Menge zu nennen. Außerdem wurde untersucht, was passiert, wenn die Packungen groß oder klein sind und wenn die Preise pro Stück leicht auszurechnen sind. Wenn die Packung groß und der Stückpreis schwierig auszurechnen ist, zeigen sich die Konsumenten eher bereit, die Packung zu kaufen, wenn zuerst die Menge genannt wird. Außerdem sind sie dann der Meinung, dass ein solches Angebot einen guten Einkauf darstelle. Wenn allerdings der Preis zuerst dargestellt wird oder er ein Vielfaches der Stückzahl ausmacht und somit leicht auszurechnen ist (z. B. 5 DVDs für 50 €), tritt das genaue Gegenteil ein. Dies liegt unter anderem daran, dass das menschliche Gehirn Schwierigkeiten hat, große Zahlen zu verarbeiten. Unter Zeitdruck erscheinen uns dann sogar vermeintlich einfache Berechnungen als schwierig. Dann nutzen wir hauptsächlich die erste Information, die wir wahrnehmen, um so den Kauf und seine Vorteile oder Nachteile für uns zu bewerten.",
        "Als Kunde begegnen wir also großen Packungen, bei denen zuerst die Menge mitgeteilt wird, und glauben, dass dies ein günstiges Angebot ist. Mit dem neuen Wissen über die Forschungsergebnisse sollten wir aber zumindest ab und zu beim Kauf von größeren Packungen innehalten und noch einmal überlegen, ob es sich wirklich um ein gutes Angebot handelt. Aus der Perspektive der Geschäfte muss die Schlussfolgerung allerdings wie folgt lauten: Große Angebote zusammenstellen und erst mit der Menge und dann mit dem Preis werben. Dass diese Strategie funktioniert, lässt sich Tag für Tag im Supermarkt beobachten."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Es liegen Untersuchungen darüber vor,",
          "options": {
            "a": "wie stark die Entscheidungen den Körper steuern.",
            "b": "welche Einflüsse bestimmte Faktoren auf das Kaufverhalten haben.",
            "c": "warum Menschen so viel über das eigene Einkaufsverhalten nachdenken."
          },
          "answer": "b",
          "explanation": "Im ersten Absatz heißt es: „Neue Forschungen setzen sich mit diesem Zusammenhang zwischen Körper, Kaufverhalten und Umweltbedingungen auseinander.“"
        },
        {
          "num": 7,
          "stem": "Es gibt Hinweise darauf, dass",
          "options": {
            "a": "man sich im Winter häufiger verliebt als im Sommer.",
            "b": "Forscher bei ihren Experimenten die Konsumenten manipulierten.",
            "c": "das Empfinden von Kälte zum Kauf romantischer Filme animiert."
          },
          "answer": "c",
          "explanation": "Im Text steht: „Wenn uns kalt ist, beeinflusst daher unser Bedürfnis nach Wärme zum Beispiel den Kauf von romantischen Filmen auf DVD.“"
        },
        {
          "num": 8,
          "stem": "Forscher haben untersucht,",
          "options": {
            "a": "wie extrem günstige Angebote Konsumenten beeinflussen.",
            "b": "welche Kunden bei Sonderangeboten größere Mengen kaufen.",
            "c": "ob die Reihenfolge von Produktinformationen das Kaufverhalten beeinflusst."
          },
          "answer": "c",
          "explanation": "Im dritten Absatz steht: „Neue Studien zeigen, dass Konsumenten auf Angebote extrem unterschiedlich reagieren, je nachdem, ob ihnen bei Sonderangeboten zuerst der Preis oder zuerst die Menge genannt wird. Eine neue Studie untersuchte nun die Reaktionen der Konsumenten auf genau diese Reihenfolge.“"
        },
        {
          "num": 9,
          "stem": "Unser Gehirn.",
          "options": {
            "a": "verarbeitet beim Einkaufen hauptsächlich Preisangaben.",
            "b": "nutzt unter Zeitdruck vor allem die erste Information einer Botschaft.",
            "c": "kann unter Zeitdruck mathematische Aufgaben schneller lösen."
          },
          "answer": "b",
          "explanation": "Im Text heißt es: „Unter Zeitdruck erscheinen uns dann sogar vermeintlich einfache Berechnungen als schwierig. Dann nutzen wir hauptsächlich die erste Information, die wir wahrnehmen, um so den Kauf und seine Vorteile oder Nachteile für uns zu bewerten.“"
        },
        {
          "num": 10,
          "stem": "Großpackungen können besser verkauft werden, wenn die",
          "options": {
            "a": "enthaltene Stückzahl möglichst hoch ist.",
            "b": "Produkte täglich beworben werden.",
            "c": "Mengenangabe vor dem Preis genannt wird."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz lautet die Schlussfolgerung für Geschäfte: „Große Angebote zusammenstellen und erst mit der Menge und dann mit dem Preis werben.“"
        }
      ]
    },
    {
      "id": "7",
      "title": "Test 7 – Ein Leben für den Kaffee: Bremer Kaffeerösterei Münchhausen eine der letzten traditionellen Röstereien",
      "isVariant": false,
      "paragraphs": [
        "Vor 50 Jahren gab es in der Hansestadt Bremen ungefähr 300 traditionelle Kaffeeröstereien. Diese importierten die Kaffeebohnen selbst, stellten den Kaffee tagefrisch her und verkauften ihn im eigenen Geschäft. Heute, da der Kaffee zumeist von internationalen Kaffeegesellschaften produziert und in Supermärkten verkauft wird, sind in Deutschland nur noch eine Handvoll Kleinröstereien übrig geblieben. Eine davon ist die Kaffeerösterei Münchhausen. Münchhausen importiert seinen Kaffee direkt von Kleinbauern in Lateinamerika. Dabei wird streng auf fairen Handel geachtet, das heißt, die Kaffeebauern werden für ihre anstrengende Arbeit angemessen entlohnt. Damit unterstützt der Importeur zugleich den Kaffeeanbau nach ökologischen Gesichtspunkten. Kaffee aus Großplantagen, oft mit Pestiziden und Insektiziden belastet, ist zwar billiger, aber Qualität und Reinheit des Kaffees werden bei der Kaffeerösterei Münchhausen ganz großgeschrieben.",
        "Der Kaffee wird nach alter Familientradition hergestellt. Die Rezeptur ist die gleiche wie vor einem halben Jahrhundert: Täglich werden die Kaffeebohnen in kleinen Mengen frisch geröstet, gerade so viele, wie an einem Tag verkauft werden. Denn nur so behalten sie ihr Aroma und der Kaffee verliert nicht an Geschmack. Zuerst werden die Kaffeebohnen in der in den 50er Jahren angeschafften Rösttrommel ungefähr zehn Minuten lang bei Temperaturen von über 200 Grad Celsius geröstet. Dabei verlieren die Kaffeebohnen zwar ein Sechstel ihres Gewichts, ihr Volumen vergrößert sich aber gleichzeitig um etwa ein Drittel. Sind die Bohnen dunkel genug - sie dürfen genauso wenig zu dunkel sein -, werden sie auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden. Danach erst werden aus den gerösteten Kaffeebohnen verschiedene Mischungen hergestellt, die dann im Kontor, dem Geschäftsraum der Rösterei, fast ausschließlich an langjährige Stammkunden verkauft werden. Aber auch über das Internet vertreibt die Kaffeerösterei Münchhausen ihr Kaffeeangebot deutschlandweit.",
        "Bis zu seinem Tod kurz vor seinem dreiundneunzigsten Geburtstag führte August Münchhausen seinen Familienbetrieb, dann übernahm seine Tochter die Firma, inzwischen ist auch die Enkelin beteiligt. Die Frauen planen, aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können. Dann hätte diese Institution eine reelle Chance, in Zukunft fortzubestehen und zukünftigen Generationen den Charme und die Technik der traditionellen Kaffeeherstellung zu erhalten. Selbstverständlich wird es auch in Zukunft möglich sein, im Museums-Bistro den Kaffee zu genießen oder für den häuslichen Bedarf zu erwerben."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "In Deutschland.",
          "options": {
            "a": "existiert eine Vielzahl von Kaffeeröstereien.",
            "b": "gibt es nur noch wenige traditionelle Kaffeeröstereien.",
            "c": "handeln nur noch internationale Gesellschaften mit Kaffee."
          },
          "answer": "b",
          "explanation": "Im ersten Absatz steht: „Heute, da der Kaffee zumeist von internationalen Kaffeegesellschaften produziert und in Supermärkten verkauft wird, sind in Deutschland nur noch eine Handvoll Kleinröstereien übrig geblieben.“"
        },
        {
          "num": 7,
          "stem": "Für die Kaffeerösterei Münchhausen.",
          "options": {
            "a": "ist es nicht von Bedeutung, ob der Kaffee von Kleinbauern oder Großplantagen kommt.",
            "b": "spielt der günstige Einkaufspreis eine wichtige Rolle.",
            "c": "steht eher die Qualität des Kaffees als der Preis im Vordergrund."
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Kaffee aus Großplantagen, oft mit Pestiziden und Insektiziden belastet, ist zwar billiger, aber Qualität und Reinheit des Kaffees werden bei der Kaffeerösterei Münchhausen ganz großgeschrieben.“"
        },
        {
          "num": 8,
          "stem": "Kaffeebohnen.",
          "options": {
            "a": "dürfen nach dem Rösten zwar zu dunkel sein, aber nicht zu hell.",
            "b": "können nach der Röstung ohne Geschmacksverlust lange Zeit gelagert werden.",
            "c": "müssen nach dem Rösten handverlesen werden, um eine gleichbleibend hohe Qualität zu gewährleisten."
          },
          "answer": "c",
          "explanation": "Im Text steht: „Sind die Bohnen dunkel genug - sie dürfen genauso wenig zu dunkel sein -, werden sie auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden.“"
        },
        {
          "num": 9,
          "stem": "Die gerösteten Kaffeebohnen werden.",
          "options": {
            "a": "im Kontor nur an Stammkunden angegeben.",
            "b": "in Handarbeit gemischt.",
            "c": "zusätzlich online vermarktet."
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Aber auch über das Internet vertreibt die Kaffeerösterei Münchhausen ihr Kaffeeangebot deutschlandweit.“"
        },
        {
          "num": 10,
          "stem": "In Zukunft wollen die Besitzer.",
          "options": {
            "a": "die Kaffeerösterei in ein Museum umwandeln.",
            "b": "ein Museum über den Kaffeeanbau eröffnen.",
            "c": "keinen Röstkaffee mehr verkaufen."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz steht: „Die Frauen planen, aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können.“"
        }
      ]
    },
    {
      "id": "7a",
      "title": "Test 7a – Ein Leben für den Kaffee: Bremer Kaffeerösterei Münchhausen eine der letzten traditionellen Röstereien",
      "isVariant": true,
      "paragraphs": [
        "Vor 50 Jahren gab es in der Hansestadt Bremen ungefähr 300 traditionelle Kaffeeröstereien. Diese importierten die Kaffeebohnen selbst, stellten den Kaffee tagefrisch her und verkauften ihn im eigenen Geschäft. Heute, da der Kaffee zumeist von internationalen Kaffeegesellschaften produziert und in Supermärkten verkauft wird, sind in Deutschland nur noch eine Handvoll Kleinröstereien übrig geblieben. Eine davon ist die Kaffeerösterei Münchhausen. Münchhausen importiert seinen Kaffee direkt von Kleinbauern in Lateinamerika. Dabei wird streng auf fairen Handel geachtet, das heißt, die Kaffeebauern werden für ihre anstrengende Arbeit angemessen entlohnt. Damit unterstützt der Importeur zugleich den Kaffeeanbau nach ökologischen Gesichtspunkten. Kaffee aus Großplantagen, oft mit Pestiziden und Insektiziden belastet, ist zwar billiger, aber Qualität und Reinheit des Kaffees werden bei der Kaffeerösterei Münchhausen ganz großgeschrieben.",
        "Der Kaffee wird nach alter Familientradition hergestellt. Die Rezeptur ist die gleiche wie vor einem halben Jahrhundert: Täglich werden die Kaffeebohnen in kleinen Mengen frisch geröstet, gerade so viele, wie an einem Tag verkauft werden. Denn nur so behalten sie ihr Aroma und der Kaffee verliert nicht an Geschmack. Zuerst werden die Kaffeebohnen in der in den 50er Jahren angeschafften Rösttrommel ungefähr zehn Minuten lang bei Temperaturen von über 200 Grad Celsius geröstet. Dabei verlieren die Kaffeebohnen zwar ein Sechstel ihres Gewichts, ihr Volumen vergrößert sich aber gleichzeitig um etwa ein Drittel. Sind die Bohnen dunkel genug - sie dürfen genauso wenig zu dunkel sein -, werden sie auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden. Danach erst werden aus den gerösteten Kaffeebohnen verschiedene Mischungen hergestellt, die dann im Kontor, dem Geschäftsraum der Rösterei, fast ausschließlich an langjährige Stammkunden verkauft werden. Aber auch über das Internet vertreibt die Kaffeerösterei Münchhausen ihr Kaffeeangebot deutschlandweit.",
        "Bis zu seinem Tod kurz vor seinem dreiundneunzigsten Geburtstag führte August Münchhausen seinen Familienbetrieb, dann übernahm seine Tochter die Firma, inzwischen ist auch die Enkelin beteiligt. Die Frauen planen, aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können. Dann hätte diese Institution eine reelle Chance, in Zukunft fortzubestehen und zukünftigen Generationen den Charme und die Technik der traditionellen Kaffeeherstellung zu erhalten. Selbstverständlich wird es auch in Zukunft möglich sein, im Museums-Bistro den Kaffee zu genießen oder für den häuslichen Bedarf zu erwerben."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "In Deutschland gibt es.",
          "options": {
            "a": "eine Vielzahl von Kaffeeröstereien",
            "b": "nur noch eine geringe Zahl an Kaffeeröstereien.",
            "c": "nur noch Kaffee, der von internationalen Gesellschaften vermarktet wird."
          },
          "answer": "b",
          "explanation": "Im ersten Absatz steht, dass in Deutschland „nur noch eine Handvoll Kleinröstereien übrig geblieben“ sind."
        },
        {
          "num": 7,
          "stem": "Für die Kaffeerösterei Münchhausen.",
          "options": {
            "a": "ist es nicht von Bedeutung, ob der Kaffee von Kleinbauern oder Großplantagen kommt.",
            "b": "spielt der günstige Einkaufspreis eine wichtige Rolle.",
            "c": "steht eher die Qualität des Kaffees als der Preis im Vordergrund."
          },
          "answer": "c",
          "explanation": "Laut Text werden „Qualität und Reinheit des Kaffees bei der Kaffeerösterei Münchhausen ganz großgeschrieben“, obwohl Kaffee aus Großplantagen billiger wäre."
        },
        {
          "num": 8,
          "stem": "Kaffeebohnen.",
          "options": {
            "a": "dürfen nach dem Rösten zwar zu dunkel sein, aber nicht zu hell.",
            "b": "können nach der Röstung ohne Geschmacksverlust lange Zeit gelagert werden.",
            "c": "müssen nach dem Rösten handverlesen werden, um eine gleichbleibend hohe Qualität zu gewährleisten."
          },
          "answer": "c",
          "explanation": "Nach dem Rösten werden die Bohnen „auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden“."
        },
        {
          "num": 9,
          "stem": "Die gerösteten Kaffeebohnen werden.",
          "options": {
            "a": "in unterschiedlichen Geschmacksrichtungen verkauft.",
            "b": "im Kontor nur an Stammkunden angegeben.",
            "c": "über das Internet in der ganzen Welt verkauft."
          },
          "answer": "a",
          "explanation": "Im Text steht: „Danach erst werden aus den gerösteten Kaffeebohnen verschiedene Mischungen hergestellt, die dann im Kontor ... fast ausschließlich an langjährige Stammkunden verkauft werden“ (und deutschlandweit übers Internet)."
        },
        {
          "num": 10,
          "stem": "In Zukunft wollen die Besitzer.",
          "options": {
            "a": "die Kaffeerösterei in ein Museum umwandeln.",
            "b": "ein Museum über den Kaffeeanbau eröffnen.",
            "c": "im neuen Museum keinen Röstkaffee mehr verkaufen."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz steht: „Die Frauen planen, aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können.“"
        }
      ]
    },
    {
      "id": "7b",
      "title": "Test 7b – Ein Leben für den Kaffee: Bremer Kaffeerösterei Münchhausen eine der letzten traditionellen Röstereien",
      "isVariant": true,
      "paragraphs": [
        "Vor 50 Jahren gab es in der Hansestadt Bremen ungefähr 300 traditionelle Kaffeeröstereien. Diese importierten die Kaffeebohnen selbst, stellten den Kaffee tagefrisch her und verkauften ihn im eigenen Geschäft. Heute, da der Kaffee zumeist von internationalen Kaffeegesellschaften produziert und in Supermärkten verkauft wird, sind in Deutschland nur noch eine Handvoll Kleinröstereien übrig geblieben. Eine davon ist die Kaffeerösterei Münchhausen. Münchhausen importiert seinen Kaffee direkt von Kleinbauern in Lateinamerika. Dabei wird streng auf fairen Handel geachtet, das heißt, die Kaffeebauern werden für ihre anstrengende Arbeit angemessen entlohnt. Damit unterstützt der Importeur zugleich den Kaffeeanbau nach ökologischen Gesichtspunkten. Kaffee aus Großplantagen, oft mit Pestiziden und Insektiziden belastet, ist zwar billiger, aber Qualität und Reinheit des Kaffees werden bei der Kaffeerösterei Münchhausen ganz großgeschrieben.",
        "Der Kaffee wird nach alter Familientradition hergestellt. Die Rezeptur ist die gleiche wie vor einem halben Jahrhundert: Täglich werden die Kaffeebohnen in kleinen Mengen frisch geröstet, gerade so viele, wie an einem Tag verkauft werden. Denn nur so behalten sie ihr Aroma und der Kaffee verliert nicht an Geschmack. Zuerst werden die Kaffeebohnen in der in den 50er Jahren angeschafften Rösttrommel ungefähr zehn Minuten lang bei Temperaturen von über 200 Grad Celsius geröstet. Dabei verlieren die Kaffeebohnen zwar ein Sechstel ihres Gewichts, ihr Volumen vergrößert sich aber gleichzeitig um etwa ein Drittel. Sind die Bohnen dunkel genug - sie dürfen genauso wenig zu dunkel sein -, werden sie auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden. Danach erst werden aus den gerösteten Kaffeebohnen verschiedene Mischungen hergestellt, die dann im Kontor, dem Geschäftsraum der Rösterei, fast ausschließlich an langjährige Stammkunden verkauft werden. Aber auch über das Internet vertreibt die Kaffeerösterei Münchhausen ihr Kaffeeangebot deutschlandweit.",
        "Bis zu seinem Tod kurz vor seinem dreiundneunzigsten Geburtstag führte August Münchhausen seinen Familienbetrieb, dann übernahm seine Tochter die Firma, inzwischen ist auch die Enkelin beteiligt. Die Frauen planen, aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können. Dann hätte diese Institution eine reelle Chance, in Zukunft fortzubestehen und zukünftigen Generationen den Charme und die Technik der traditionellen Kaffeeherstellung zu erhalten. Selbstverständlich wird es auch in Zukunft möglich sein, im Museums-Bistro den Kaffee zu genießen oder für den häuslichen Bedarf zu erwerben."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "In Deutschland .",
          "options": {
            "a": "existiert eine Vielzahl von Kaffeeröstereien.",
            "b": "gibt es nur noch wenige traditionelle Kaffeeröstereien.",
            "c": "handeln nur noch internationale Gesellschaften mit Kaffee."
          },
          "answer": "b",
          "explanation": "Im ersten Absatz steht, dass in Deutschland „nur noch eine Handvoll Kleinröstereien übrig geblieben“ sind."
        },
        {
          "num": 7,
          "stem": "Für die Kaffeerösterei Münchhausen.",
          "options": {
            "a": "sind die Anbaubedingungen der Kaffeebohnen nicht von Bedeutung.",
            "b": "spielt der günstige Einkaufspreis eine wichtige Rolle.",
            "c": "stehen die Güte und Beschaffenheit des Kaffees im Vordergrund."
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Qualität und Reinheit des Kaffees werden bei der Kaffeerösterei Münchhausen ganz großgeschrieben.“"
        },
        {
          "num": 8,
          "stem": "Kaffeebohnen .",
          "options": {
            "a": "dürfen nach dem Rösten zwar zu dunkel sein, aber nicht zu hell.",
            "b": "können nach der Röstung ohne Geschmacksverlust lange Zeit gelagert werden.",
            "c": "müssen nach dem Rösten handverlesen werden um eine gleichbleibend hohe Qualität zu gewährleisten"
          },
          "answer": "c",
          "explanation": "Nach dem Rösten werden die Bohnen „auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden“."
        },
        {
          "num": 9,
          "stem": "Die gerösteten Kaffeebohnen werden.",
          "options": {
            "a": "im Kontor nur an Stammkunden angegeben.",
            "b": "in Handarbeit gemischt.",
            "c": "zusätzlich online vermarktet."
          },
          "answer": "c",
          "explanation": "Im Text heißt es: „Aber auch über das Internet vertreibt die Kaffeerösterei Münchhausen ihr Kaffeeangebot deutschlandweit.“"
        },
        {
          "num": 10,
          "stem": "In Zukunft wollen die Besitzer .",
          "options": {
            "a": "die Kaffeerösterei zu Bildungszwecken zur Verfügung stellen.",
            "b": "ein Museum über den Kaffeeanbau eröffnen.",
            "c": "keinen Röstkaffee mehr verkaufen."
          },
          "answer": "a",
          "explanation": "Die Besitzerinnen planen, „aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können“."
        }
      ]
    },
    {
      "id": "7c",
      "title": "Test 7c – Ein Leben für den Kaffee: Bremer Kaffeerösterei Münchhausen eine der letzten traditionellen Röstereien",
      "isVariant": true,
      "paragraphs": [
        "Vor 50 Jahren gab es in der Hansestadt Bremen ungefähr 300 traditionelle Kaffeeröstereien. Diese importierten die Kaffeebohnen selbst, stellten den Kaffee tagefrisch her und verkauften ihn im eigenen Geschäft. Heute, da der Kaffee zumeist von internationalen Kaffeegesellschaften produziert und in Supermärkten verkauft wird, sind in Deutschland nur noch eine Handvoll Kleinröstereien übrig geblieben. Eine davon ist die Kaffeerösterei Münchhausen. Münchhausen importiert seinen Kaffee direkt von Kleinbauern in Lateinamerika. Dabei wird streng auf fairen Handel geachtet, das heißt, die Kaffeebauern werden für ihre anstrengende Arbeit angemessen entlohnt. Damit unterstützt der Importeur zugleich den Kaffeeanbau nach ökologischen Gesichtspunkten. Kaffee aus Großplantagen, oft mit Pestiziden und Insektiziden belastet, ist zwar billiger, aber Qualität und Reinheit des Kaffees werden bei der Kaffeerösterei Münchhausen ganz großgeschrieben.",
        "Der Kaffee wird nach alter Familientradition hergestellt. Die Rezeptur ist die gleiche wie vor einem halben Jahrhundert: Täglich werden die Kaffeebohnen in kleinen Mengen frisch geröstet, gerade so viele, wie an einem Tag verkauft werden. Denn nur so behalten sie ihr Aroma und der Kaffee verliert nicht an Geschmack. Zuerst werden die Kaffeebohnen in der in den 50er Jahren angeschafften Rösttrommel ungefähr zehn Minuten lang bei Temperaturen von über 200 Grad Celsius geröstet. Dabei verlieren die Kaffeebohnen zwar ein Sechstel ihres Gewichts, ihr Volumen vergrößert sich aber gleichzeitig um etwa ein Drittel. Sind die Bohnen dunkel genug - sie dürfen genauso wenig zu dunkel sein -, werden sie auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden. Danach erst werden aus den gerösteten Kaffeebohnen verschiedene Mischungen hergestellt, die dann im Kontor, dem Geschäftsraum der Rösterei, fast ausschließlich an langjährige Stammkunden verkauft werden. Aber auch über das Internet vertreibt die Kaffeerösterei Münchhausen ihr Kaffeeangebot deutschlandweit.",
        "Bis zu seinem Tod kurz vor seinem dreiundneunzigsten Geburtstag führte August Münchhausen seinen Familienbetrieb, dann übernahm seine Tochter die Firma, inzwischen ist auch die Enkelin beteiligt. Die Frauen planen, aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können. Dann hätte diese Institution eine reelle Chance, in Zukunft fortzubestehen und zukünftigen Generationen den Charme und die Technik der traditionellen Kaffeeherstellung zu erhalten. Selbstverständlich wird es auch in Zukunft möglich sein, im Museums-Bistro den Kaffee zu genießen oder für den häuslichen Bedarf zu erwerben."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "In Deutschland .",
          "options": {
            "a": "existiert eine Vielzahl von Kaffeeröstereien.",
            "b": "gibt es nur noch wenige traditionelle Kaffeeröstereien.",
            "c": "handeln nur noch internationale Gesellschaften mit Kaffee."
          },
          "answer": "b",
          "explanation": "Im ersten Absatz steht, dass in Deutschland „nur noch eine Handvoll Kleinröstereien übrig geblieben“ sind."
        },
        {
          "num": 7,
          "stem": "Für die Kaffeerösterei Münchhausen.",
          "options": {
            "a": "stehen die Güte und Beschaffenheit des Kaffees im Vordergrund.",
            "b": "spielt der günstige Einkaufspreis eine wichtige Rolle.",
            "c": "sind die Anbaubedingungen der Kaffeebohnen nicht von Bedeutung."
          },
          "answer": "a",
          "explanation": "Im Text heißt es: „Qualität und Reinheit des Kaffees werden bei der Kaffeerösterei Münchhausen ganz großgeschrieben.“"
        },
        {
          "num": 8,
          "stem": "Kaffeebohnen .",
          "options": {
            "a": "müssen nach dem Rösten handverlesen werden um eine gleichbleibend hohe Qualität zu gewährleisten",
            "b": "können nach der Röstung ohne Geschmacksverlust lange Zeit gelagert werden.",
            "c": "dürfen nach dem Rösten zwar zu dunkel sein, aber nicht zu hell."
          },
          "answer": "a",
          "explanation": "Nach dem Rösten werden die Bohnen „auf den Verlesetisch geschüttet, wo von Hand die guten von den schlechten Kaffeebohnen getrennt werden“."
        },
        {
          "num": 9,
          "stem": "Die gerösteten Kaffeebohnen werden.",
          "options": {
            "a": "zusätzlich online vermarktet.",
            "b": "in Handarbeit gemischt.",
            "c": "im Kontor nur an Stammkunden angegeben."
          },
          "answer": "a",
          "explanation": "Im Text heißt es: „Aber auch über das Internet vertreibt die Kaffeerösterei Münchhausen ihr Kaffeeangebot deutschlandweit.“"
        },
        {
          "num": 10,
          "stem": "In Zukunft wollen die Besitzer .",
          "options": {
            "a": "keinen Röstkaffee mehr verkaufen.",
            "b": "ein Museum über den Kaffeeanbau eröffnen.",
            "c": "die Kaffeerösterei zu Bildungszwecken zur Verfügung stellen."
          },
          "answer": "c",
          "explanation": "Die Besitzerinnen planen, „aus der Kaffeerösterei ein Museum zu machen, um der Nachwelt die traditionelle Kunst des Kaffeeröstens zeigen zu können“."
        }
      ]
    },
    {
      "id": "8",
      "title": "Test 8 – Müdigkeit und juckende Augen - Arbeit in Großraumbüros",
      "isVariant": false,
      "paragraphs": [
        "Die deutsche Sehnsucht nach dem Einzelbüro. Dieser Artikel entsteht unter katastrophalen Bedingungen. Links vom Autor, keinen halben Meter entfernt, diskutieren die Onlineredakteure gerade über portugiesische Bankgeschäfte. Von rechts eilt nun der befreundete Kollege heran: \"Sag mal, hast du eine Ahnung, ob das Bayern-Spiel heute Abend live im Fernsehen übertragen wird?\" Und da, die Chefin, ganz aufgeregt winkt sie herüber: \"Wann wir denn die Geschichte endlich fertig? Die hätte vor einer halben Stunde ins Korrektorat gemusst. Beeil dich bitte!\" Was wir Arbeitenden im Großraumbüro immer schon ahnten, haben Schweizer Forscher nun erstmals auf breiter wissenschaftlicher Basis nachgewiesen: Großraum ist schlecht. Zumindest für diejenigen, die im Großraum arbeiten müssen. Mag sein, dass die Chefs in ihren Einzelbüros da anderer Meinung sind. Gut 1200 Beschäftigte aus unterschiedlichsten Berufen hat die Hochschule in Luzern befragt. Die Ergebnisse der Erhebung sind eindeutig. Beispiel Lärm: In Büros mit mehr als 16 Mitarbeitern fühlen sich 80% der Befragten regelmäßig durch Gespräche oder Telefonate gestört - in Zweierbüros sind es nicht mal 30%. Auch was die alltäglichen Büro-Probleme betrifft, ist der Großraum von Nachteil. Einerlei, wonach die Forscher nun fragten, ob nach Müdigkeit, Schweregefühl im Kopf, juckende Augen oder verstopfte Nase - immer litten Mitarbeiter im Großraumbüro am stärksten. Wundert da, dass vier von zehn Großraumbeschäftigten mit ihrer „Bürosituation im Allgemeinen“ sehr oder gar außerordentlich unzufrieden sind? Zum Vergleich: Acht von zehn Arbeitnehmern mit Einzelbüro geben an, sie seien ziemlich, sehr oder - fast 50% - außerordentlich zufrieden. „Einzelbüros für alle“ müsste die Lösung lauten, doch der Trend geht in die andere Richtung: Offene Raumstrukturen nehmen zu. Kritiker dieser Entwicklung sehen dahinter vor allem einen Grund: Arbeitgeber wollen die Mieten und Heizkosten niedrig halten. Aber zumindest ein Argument dürfte auch die Arbeitgeber interessieren: Der Schweizer Studie zufolge ist die Zahl der Krankheitstage bei Beschäftigten in Großraumbüros deutlich höher als bei anderen.",
        "Die deutsche Sehnsucht nach dem Einzelbüro: Mein Schreibtisch. Mein Computer. Mein Büro. Das Einzelzimmer war fester Bestandteil der deutschen Bürokultur. Aber auch heute haben es noch viele und wer keines hat, träumt zumindest davon. Diese Sehnsucht ist typisch deutsch. \"Verglichen mit den Beschäftigten in anderen Ländern, sitzen wir sehr bequem. Auch wenn alle Mitarbeiter die gleiche Möblierung haben, sitzen wir alle doch an unseren eigenen Schreibtischen, benutzen unsere eigenen Aktenschränke und möchten am liebsten die Tür zumachen können\", sagt Robert Menke von der Immobilienberatung Kuschmann & Wakefield. Die hat eine Studie veröffentlicht, wonach deutsche Angestellte im internationalen Vergleich den meisten Platz haben: durchschnittlich 30 Quadratmeter Mietfläche pro Kopf. Damit ist natürlich nicht nur das Schreibtisch-Areal gemeint, auch der Flur oder Küchenzeilen sind - falls vorhanden - eingerechnet. Doch umso erstaunlicher sind die Quadratmeterzahlen am anderen Ende der Statistik: In einigen osteuropäischen Ländern, aber auch in Schottland kommt jeder Beschäftigte gerade mal auf 10 Quadratmeter, selbst in Österreich sind es nur zwölf. Im angelsächsischen Raum gibt es viel mehr Großraumbüros als bei uns. In London, wo Büroraum weltweit mit am teuersten ist, ist etwa eine Zusammenarbeit auf einer Fläche von 600 Quadratmetern und mehr ganz normal. Häufig teilen sich sogar mehrere Mitarbeiter einen Arbeitsplatz. Statt eines festen Schreibtisches verfügt dann jeder über einen Rollcontainer. Der wird immer dorthin mitgenommen, wo gerade ein Arbeitsplatz frei ist. Das geht in der Regel über alle Hierarchiestufen, sagt Menke. Robert Menke erkennt auch in Deutschland \"in einigen Bereichen eine Amerikanisierung des Büroraumes\". Banken und Unternehmen im Telekommunikationssektor wären da vorne dabei. Doch das sind noch Ausnahmen. Nach wie vor arbeiten die meisten Angestellten entweder in kleinen Gruppen in etwas größeren Büros oder in \"Einzelzellen\", wie Büros für eine Person in der Sprache der Immobilienmakler heißen. Laut der Studie überlegen zwar 40% der befragten Unternehmer, ihre Großraumflächen zu erweitern oder die Arbeitsplätze flexibel zu gestalten, aber \"richtige Großraumbüros gibt es eher selten\", sagt Menke."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Eine Studie aus der Schweiz..",
          "options": {
            "a": "belegt, dass die Mitarbeiter sich über Lärm im Großraumbüro beklagen.",
            "b": "brachte keine eindeutigen Ergebnisse zur Zufriedenheit mit unterschiedlichen Büroformen.",
            "c": "zeigt, dass Mitarbeiter in Großraumbüros seltener krank sind als andere."
          },
          "answer": "a",
          "explanation": "Im Text steht zur Studie der Hochschule Luzern: „Beispiel Lärm: In Büros mit mehr als 16 Mitarbeitern fühlen sich 80% der Befragten regelmäßig durch Gespräche oder Telefonate gestört.“"
        },
        {
          "num": 7,
          "stem": "Großraumbüros...",
          "options": {
            "a": "reduzieren den Krankenstand.",
            "b": "sind kostengünstiger zu beheizen.",
            "c": "werden immer seltener."
          },
          "answer": "b",
          "explanation": "Im Text heißt es über die Zunahme offener Raumstrukturen: „Arbeitgeber wollen die Mieten und Heizkosten niedrig halten.“"
        },
        {
          "num": 8,
          "stem": "Die deutschen Angestellten...",
          "options": {
            "a": "bevorzugen Einzelbüros.",
            "b": "genießen eine individuell ausgewählte Büromöblierung.",
            "c": "leiden unter zu engen Einzelbüros."
          },
          "answer": "a",
          "explanation": "Im Text steht: „Das Einzelzimmer war fester Bestandteil der deutschen Bürokultur. Aber auch heute haben es noch viele und wer keines hat, träumt zumindest davon.“"
        },
        {
          "num": 9,
          "stem": "Die Arbeitsplatzfläche...",
          "options": {
            "a": "ist in Londoner Großraumbüros für den Chef größer als für andere Mitarbeiter.",
            "b": "schließt die gemeinsam genutzten Flächen aus.",
            "c": "wird in London oft unter mehreren Mitarbeitern aufgeteilt."
          },
          "answer": "c",
          "explanation": "Über London heißt es im Text: „Häufig teilen sich sogar mehrere Mitarbeiter einen Arbeitsplatz. Statt eines festen Schreibtisches verfügt dann jeder über einen Rollcontainer.“"
        },
        {
          "num": 10,
          "stem": "Großraumbüros...",
          "options": {
            "a": "gibt es vor allem in Banken und Telekommunikationsunternehmen.",
            "b": "werden bald in 40% der deutschen Firmen eingeführt.",
            "c": "werden meist in Einzelzellen unterteilt."
          },
          "answer": "a",
          "explanation": "Im Text steht: „Robert Menke erkennt auch in Deutschland 'in einigen Bereichen eine Amerikanisierung des Büroraumes'. Banken und Unternehmen im Telekommunikationssektor wären da vorne dabei.“"
        }
      ]
    },
    {
      "id": "8a",
      "title": "Test 8a – Müdigkeit und juckende Augen - Arbeit in Großraumbüros",
      "isVariant": true,
      "paragraphs": [
        "Die deutsche Sehnsucht nach dem Einzelbüro. Dieser Artikel entsteht unter katastrophalen Bedingungen. Links vom Autor, keinen halben Meter entfernt, diskutieren die Onlineredakteure gerade über portugiesische Bankgeschäfte. Von rechts eilt nun der befreundete Kollege heran: \"Sag mal, hast du eine Ahnung, ob das Bayern-Spiel heute Abend live im Fernsehen übertragen wird?\" Und da, die Chefin, ganz aufgeregt winkt sie herüber: \"Wann wir denn die Geschichte endlich fertig? Die hätte vor einer halben Stunde ins Korrektorat gemusst. Beeil dich bitte!\" Was wir Arbeitenden im Großraumbüro immer schon ahnten, haben Schweizer Forscher nun erstmals auf breiter wissenschaftlicher Basis nachgewiesen: Großraum ist schlecht. Zumindest für diejenigen, die im Großraum arbeiten müssen. Mag sein, dass die Chefs in ihren Einzelbüros da anderer Meinung sind. Gut 1200 Beschäftigte aus unterschiedlichsten Berufen hat die Hochschule in Luzern befragt. Die Ergebnisse der Erhebung sind eindeutig. Beispiel Lärm: In Büros mit mehr als 16 Mitarbeitern fühlen sich 80% der Befragten regelmäßig durch Gespräche oder Telefonate gestört - in Zweierbüros sind es nicht mal 30%. Auch was die alltäglichen Büro-Probleme betrifft, ist der Großraum von Nachteil. Einerlei, wonach die Forscher nun fragten, ob nach Müdigkeit, Schweregefühl im Kopf, juckende Augen oder verstopfte Nase - immer litten Mitarbeiter im Großraumbüro am stärksten. Wundert da, dass vier von zehn Großraumbeschäftigten mit ihrer „Bürosituation im Allgemeinen“ sehr oder gar außerordentlich unzufrieden sind? Zum Vergleich: Acht von zehn Arbeitnehmern mit Einzelbüro geben an, sie seien ziemlich, sehr oder - fast 50% - außerordentlich zufrieden. „Einzelbüros für alle“ müsste die Lösung lauten, doch der Trend geht in die andere Richtung: Offene Raumstrukturen nehmen zu. Kritiker dieser Entwicklung sehen dahinter vor allem einen Grund: Arbeitgeber wollen die Mieten und Heizkosten niedrig halten. Aber zumindest ein Argument dürfte auch die Arbeitgeber interessieren: Der Schweizer Studie zufolge ist die Zahl der Krankheitstage bei Beschäftigten in Großraumbüros deutlich höher als bei anderen.",
        "Die deutsche Sehnsucht nach dem Einzelbüro: Mein Schreibtisch. Mein Computer. Mein Büro. Das Einzelzimmer war fester Bestandteil der deutschen Bürokultur. Aber auch heute haben es noch viele und wer keines hat, träumt zumindest davon. Diese Sehnsucht ist typisch deutsch. \"Verglichen mit den Beschäftigten in anderen Ländern, sitzen wir sehr bequem. Auch wenn alle Mitarbeiter die gleiche Möblierung haben, sitzen wir alle doch an unseren eigenen Schreibtischen, benutzen unsere eigenen Aktenschränke und möchten am liebsten die Tür zumachen können\", sagt Robert Menke von der Immobilienberatung Kuschmann & Wakefield. Die hat eine Studie veröffentlicht, wonach deutsche Angestellte im internationalen Vergleich den meisten Platz haben: durchschnittlich 30 Quadratmeter Mietfläche pro Kopf. Damit ist natürlich nicht nur das Schreibtisch-Areal gemeint, auch der Flur oder Küchenzeilen sind - falls vorhanden - eingerechnet. Doch umso erstaunlicher sind die Quadratmeterzahlen am anderen Ende der Statistik: In einigen osteuropäischen Ländern, aber auch in Schottland kommt jeder Beschäftigte gerade mal auf 10 Quadratmeter, selbst in Österreich sind es nur zwölf. Im angelsächsischen Raum gibt es viel mehr Großraumbüros als bei uns. In London, wo Büroraum weltweit mit am teuersten ist, ist etwa eine Zusammenarbeit auf einer Fläche von 600 Quadratmetern und mehr ganz normal. Häufig teilen sich sogar mehrere Mitarbeiter einen Arbeitsplatz. Statt eines festen Schreibtisches verfügt dann jeder über einen Rollcontainer. Der wird immer dorthin mitgenommen, wo gerade ein Arbeitsplatz frei ist. Das geht in der Regel über alle Hierarchiestufen, sagt Menke. Robert Menke erkennt auch in Deutschland \"in einigen Bereichen eine Amerikanisierung des Büroraumes\". Banken und Unternehmen im Telekommunikationssektor wären da vorne dabei. Doch das sind noch Ausnahmen. Nach wie vor arbeiten die meisten Angestellten entweder in kleinen Gruppen in etwas größeren Büros oder in \"Einzelzellen\", wie Büros für eine Person in der Sprache der Immobilienmakler heißen. Laut der Studie überlegen zwar 40% der befragten Unternehmer, ihre Großraumflächen zu erweitern oder die Arbeitsplätze flexibel zu gestalten, aber \"richtige Großraumbüros gibt es eher selten\", sagt Menke."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Eine Studie aus der Schweiz...",
          "options": {
            "a": "belegt, dass die Mitarbeiter sich über Lärm im Großraumbüro beklagen.",
            "b": "brachte keine eindeutigen Ergebnisse zur Zufriedenheit mit unterschiedlichen Büroformen.",
            "c": "zeigt, dass Mitarbeiter in Großraumbüros seltener krank sind als andere."
          },
          "answer": "a",
          "explanation": "Im Text steht zur Studie der Hochschule Luzern: „Beispiel Lärm: In Büros mit mehr als 16 Mitarbeitern fühlen sich 80% der Befragten regelmäßig durch Gespräche oder Telefonate gestört.“"
        },
        {
          "num": 7,
          "stem": "Großraumbüros...",
          "options": {
            "a": "reduzieren den Krankenstand.",
            "b": "sind kostengünstiger zu beheizen.",
            "c": "werden immer seltener."
          },
          "answer": "b",
          "explanation": "Im Text heißt es über die Zunahme offener Raumstrukturen: „Arbeitgeber wollen die Mieten und Heizkosten niedrig halten.“"
        },
        {
          "num": 8,
          "stem": "Die deutschen Angestellten...",
          "options": {
            "a": "bevorzugen Einzelbüros.",
            "b": "genießen eine individuell ausgewählte Büromöblierung.",
            "c": "leiden unter zu engen Einzelbüros."
          },
          "answer": "a",
          "explanation": "Im Text steht: „Das Einzelzimmer war fester Bestandteil der deutschen Bürokultur. Aber auch heute haben es noch viele und wer keines hat, träumt zumindest davon.“"
        },
        {
          "num": 9,
          "stem": "Die Arbeitsplatzfläche...",
          "options": {
            "a": "ist in Londoner Großraumbüros für den Chef größer als für andere Mitarbeiter.",
            "b": "schließt die gemeinsam genutzten Flächen aus.",
            "c": "wird in London oft flexibel aufgeteilt."
          },
          "answer": "c",
          "explanation": "Über London heißt es im Text: „Häufig teilen sich sogar mehrere Mitarbeiter einen Arbeitsplatz. Statt eines festen Schreibtisches verfügt dann jeder über einen Rollcontainer. Der wird immer dorthin mitgenommen, wo gerade ein Arbeitsplatz frei ist.“"
        },
        {
          "num": 10,
          "stem": "Großraumbüros...",
          "options": {
            "a": "gibt es vor allem in Banken und Telekommunikationsunternehmen.",
            "b": "werden bald in 40% der deutschen Firmen eingeführt.",
            "c": "werden meist in Einzelzellen unterteilt."
          },
          "answer": "a",
          "explanation": "Im Text steht: „Robert Menke erkennt auch in Deutschland 'in einigen Bereichen eine Amerikanisierung des Büroraumes'. Banken und Unternehmen im Telekommunikationssektor wären da vorne dabei.“"
        }
      ]
    },
    {
      "id": "9",
      "title": "Test 9 – Familienglück oder Generationskonflikte?",
      "isVariant": false,
      "paragraphs": [
        "In der öffentlichen Beschreibung kennt man die Familie oft als Problemzone. Bestsellerautoren suggerieren der Öffentlichkeit, Eltern seien zum Erziehen heute kaum noch in der Lage; Berichte über steigende Scheidungsraten, Verwahrlosung und Jugendkriminalität verstärken ebenfalls den Eindruck, um die Familien sei es nicht gut bestellt. Tatsächlich hat sich Erziehung in den letzten Jahrzehnten grundlegend gewandelt. In vielerlei Hinsicht allerdings eher zum Guten als zum Schlechten. Wie lebt es sich heute in der Familie? Ausgesprochen gut, in den meisten Fällen sogar recht kuschelig. Das legen zumindest Umfragen und Statistiken über die Familienwirklichkeit nahe. Sie zeigen ein erfreulich positives Bild, nach dem sich die Familie in den vergangenen Jahrzehnten sehr gut entwickelt hat. Das gilt für die materiellen Bedingungen, in denen die meisten Eltern und Kinder heute leben, wie auch für das Ansehen, das die Familie in der Gesellschaft genießt.",
        "Den größten Fortschritt habe aber das gemeinsame Zusammenleben gemacht, sagen Experten: „Es gibt kaum noch wirkliche Konflikte zwischen den Generationen.“ Dass heute 67 Prozent der 16- bis 29-Jährigen angeben, sie hätten eine glückliche Kindheit, während es bei den über 60-Jährigen nur 50 Prozent sind, kann zwar sicher nicht nur auf den Wandel der Erziehung zurückgeführt werden. Schließlich war die Kindheit vieler von ihnen noch von Krieg und Not geprägt, während die Jüngeren in Wohlstand und Sicherheit aufwuchsen. Aber fast alle Jugendlichen geben heute an, dass sie ein gutes Verhältnis zu den Eltern haben. Außerdem orientieren sie sich stark an ihrer Familie. Gestützt unter anderem auf den emotionalen Rückhalt der Eltern blicken die allermeisten Jugendlichen optimistisch nach vorn. Fast 75 Prozent der Befragten würden ihre eigenen Kinder genau so erziehen, wie sie selbst erzogen wurden. Genauso viele glauben, dass man eine Familie braucht, um wirklich glücklich leben zu können. Die Eltern sehen es übrigens kaum anders. Von ihnen berichten 74 Prozent von Harmonie, Wärme und Geborgenheit im Zusammenleben.",
        "Vor 40 Jahren fanden viele Jugendliche ihre Eltern noch spießig, und Eltern konnten sich erregen über die Frisuren oder den Musikgeschmack des Nachwuchses. Heute gleichen sich die Lebensstile und die Wertvorstellungen. So entspannt ist der Umgang zwischen Jung und Alt geworden, dass man es schon wieder bedenklich finden kann. Ist es denn normal, dass Kinder als wichtigstes Vorbild die eigene Mutter nennen? Selbst Oma und Opa findet nur noch jeder fünfte Teenager altmodisch. Gerade Großeltern haben noch nie zuvor für ihre Enkel eine so große Bedeutung gehabt. Dank besserer Gesundheit und steigender Lebenserwartung verbringen sie mehr Zeit als früher mit ihren Enkeln. Der Kontakt ist persönlicher und er hält länger an. Heute sieht rund ein Drittel der Jugendlichen Oma und Opa mindestens einmal pro Woche, ein weiteres Drittel telefoniert wenigstens mit ihnen.",
        "Mit den Lebenseinstellungen wandelten sich die Erziehungsvorstellungen. Erwachsene nehmen mehr Rücksicht auf die Bedürfnisse von Kindern. Statt eines autoritären Umgangs mit den Kindern pflegen die meisten Familien den Verhandlungsstil, wie es Pädagogen nennen. Der ist nicht selten anstrengend und wird mitunter übertrieben, ist aber am Ende zielführender als die familiären Kleinkriege, die früher das Klima in vielen Familien bestimmten. Besonders Väter profitieren von der neuen Nähe zu ihren Kindern. Sie spielen heute häufiger mit ihnen als früher oder lesen ihnen vor – auch wenn weiterhin die Mütter den Großteil der Familienarbeit leisten. Das führt zu Stress, da Mütter mit Kindern heute doppelt so häufig berufstätig sind wie noch vor 40 Jahren. Trotzdem haben sie nicht weniger Zeit für ihre Kinder, weil sie den Haushalt dank moderner Technik schneller erledigen. 1990 verbrachten Eltern mit ihren unter sechsjährigen Söhnen und Töchtern pro Tag vier Stunden und 52 Minuten. Heute ist es eine Dreiviertelstunde mehr. Auch der Eindruck, dass Familien sich nicht mehr täglich um den gedeckten Tisch versammeln, um sich untereinander auszutauschen, stimmt nicht, haben Ernährungsforscher ermittelt. Heute dauern die bewusst inszenierten Zusammentreffen von Jung und Alt um Suppenschüssel oder Nudeltopf sogar länger als noch vor 20 Jahren."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Etwa die Hälfte der Senioren über 60 gibt an, dass sie",
          "options": {
            "a": "ihre Kinder strenger erziehen würden.",
            "b": "die geänderten Erziehungsmethoden begrüßen.",
            "c": "als Kind glücklich waren."
          },
          "answer": "c",
          "explanation": "Im Text heißt es, dass heute 67 Prozent der 16- bis 29-Jährigen angeben, eine glückliche Kindheit gehabt zu haben, während es bei den über 60-Jährigen nur 50 Prozent (also etwa die Hälfte) sind."
        },
        {
          "num": 7,
          "stem": "Die meisten Jugendlichen",
          "options": {
            "a": "verstehen sich mit ihren Eltern gut.",
            "b": "haben keine Meinung zu Erziehungsfragen.",
            "c": "denken, dass man auch ohne Familie glücklich sein kann."
          },
          "answer": "a",
          "explanation": "Laut Text geben fast alle Jugendlichen heute an, dass sie ein gutes Verhältnis zu ihren Eltern haben."
        },
        {
          "num": 8,
          "stem": "Heute gibt es zwischen Eltern und Kindern",
          "options": {
            "a": "Konflikte wegen unterschiedlicher Werte.",
            "b": "kaum Unterschiede in der Lebensart.",
            "c": "immer wieder Probleme wegen zu engen Wohnraums."
          },
          "answer": "b",
          "explanation": "Im Text steht ausdrücklich: „Heute gleichen sich die Lebensstile und die Wertvorstellungen.“"
        },
        {
          "num": 9,
          "stem": "Mütter haben heute mehr Zeit für ihre Kinder, weil",
          "options": {
            "a": "sie in der Arbeit weniger Stress haben.",
            "b": "Geräte die Hausarbeit leichter machen.",
            "c": "die Großeltern ihnen Arbeit abnehmen."
          },
          "answer": "b",
          "explanation": "Obwohl Mütter heute doppelt so häufig berufstätig sind, haben sie nicht weniger Zeit für ihre Kinder, „weil sie den Haushalt dank moderner Technik schneller erledigen“."
        },
        {
          "num": 10,
          "stem": "In der Öffentlichkeit",
          "options": {
            "a": "wird der Wandel in der Erziehung nicht wahrgenommen.",
            "b": "ist das Thema Familie nicht interessant.",
            "c": "entsteht oft ein falsches Bild der Familie."
          },
          "answer": "c",
          "explanation": "Im ersten Absatz wird beschrieben, dass die Familie in der öffentlichen Darstellung oft als Problemzone erscheint, während Umfragen und Statistiken tatsächlich ein sehr positives Bild der Familienwirklichkeit zeigen."
        }
      ]
    },
    {
      "id": "10",
      "title": "Test 10 – Kreditkarten für Jugendliche",
      "isVariant": false,
      "paragraphs": [
        "Wer kennt sie nicht: Kreditkarten, mit denen man in der heimischen Stadt oder während des Urlaubs einkaufen kann. Fast jeder hat eine, und alles scheint ganz einfach zu sein: Kein Wunder, dass auch immer mehr Kinder und Jugendliche eine eigene Kreditkarte haben wollen. Sie sehen, wie ihre Eltern damit bezahlen, und möchten auch das praktische „Plastikgeld“. Aber Eltern sorgen sich: Ist das nicht zu gefährlich? Um das Risiko einer Überschuldung zu vermeiden, bieten Banken und alle Sparkassen Jugendlichen eine besondere Art von Kreditkarten an: die sogenannte Prepaid-Kreditkarte. Eine Prepaid-Kreditkarte ist mit einem Prepaid-Handy vergleichbar. Man kann sie nur einsetzen, wenn man zuvor Geld auf die Karte geladen hat. Ist das Guthaben verbraucht, kann man mit der Karte nicht mehr bezahlen und am Automaten kein Geld mehr abheben. Der Vorteil liegt auf der Hand: „Man kann nicht mehr Geld ausgeben, als man hat“, sagt Andreas Gernt, Finanzexperte der Verbraucherzentrale Niedersachsen in Hannover. Mit einer Prepaid-Kreditkarte kann daher niemand in die Schuldenfalle tappen. „Für Kinder und Jugendliche auf Reisen ist die Prepaid-Kreditkarte eine überlegenswerte Option“, sagt Gernt. Die daheimgebliebenen Eltern können ihrem Kind von zu Hause aus Geld auf die Karte laden, wenn das Guthaben verbraucht ist. Zugleich können sie die Kosten kontrollieren. „Die Prepaid-Kreditkarte ist eine Ausgabenschranke für den Verbraucher“, fasst Tanja Beller vom Bundesverband deutscher Banken in Berlin zusammen. So können Jugendliche den Umgang mit bargeldlosem Zahlungsverkehr lernen.",
        "Verluste bei Diebstahl überschaubar: Zugleich eignen sich die Karten aber auch für erwachsene Reisende mit einem größeren Sicherheitsbedürfnis. „Man ist mit einer Kreditkarte auf Reisen unabhängiger vom Bargeld“, erklärt Gernt. Die Prepaid-Karte biete zwei Vorteile: Zum einen ist mit ihr das Reisebudget von Anfang an limitiert. Es kann nur das für Souvenirs ausgegeben werden, was vorher geladen wurde. Zum anderen sind damit auch die Verluste überschaubar, wenn die Karte gestohlen wird. Denn auch ein Dieb kann nur das Geld nutzen, das als Guthaben auf der Karte ist. Außerdem eignet sich die Prepaid-Kreditkarte für Freiberufler und Selbständige – oder allgemeiner gefasst für Menschen mit einem unregelmäßigen oder geringen Einkommen, die dadurch keine gute Bonität haben. Denn die Prepaid-Kreditkarten sind im Gegensatz zur klassischen Kreditkarte nicht direkt an ein Gehaltskonto gebunden. Das ermöglicht auch Geringverdienern Einkäufe im Internet. Zugleich schützt die Guthabenkarte vor allzu großen Verlusten durch Missbrauch im Netz.",
        "Die Angebote sollte man vergleichen: „Bevor man sich aber für eine Prepaid-Karte entscheidet, sollte man ihre Akzeptanz überprüfen“, rät Beller. Denn gerade Prepaid-Karten sind nicht in jedem Land als Zahlungsmittel gern gesehen. Grundsätzlich sollte man auch bei Lock-Angeboten skeptisch sein, die als Werbung in den Briefkasten flattern. „Vielleicht verbirgt sich da etwas im Kleingedruckten“, warnt Gernt. Außerdem sollte man die Gebühren genau vergleichen und auf versteckte Kosten achten. Die Stiftung Warentest hat für ihre Zeitschrift „Finanztest“ die Bedingungen und Kosten von 24 Prepaid-Kreditkarten für Erwachsene und Jugendliche getestet. Die Tester stellten fest: Die Karten sind nicht teurer als klassische Kreditkarten, und auch die Nutzungsgebühren unterscheiden sich kaum.",
        "Abheben ab fünf Euro: Erwachsene bezahlen für Prepaid-Karten zwischen 29 und 39 Euro im Jahr. Karten für Jugendliche kosten im Jahr höchstens 22 Euro. Bei vielen Banken sind sie bis zum 18. oder 21. Geburtstag kostenlos. Für das Geldabheben am Automaten berechnen die Banken meist einen Mindestbetrag zwischen 5,00 € und 7,50 Euro. Ansonsten fallen etwa zwei Prozent vom abgehobenen Betrag an. Zudem kostet das Abheben außerhalb des Euro-Raumes zwischen einem Prozent und 1,9 Prozent extra. Unter dem Strich kann die Prepaid-Karte mit der klassischen Kreditkarte durchaus mithalten. Mit beiden Kartentypen kann man im Restaurant bezahlen, am Automaten Geld abheben oder im Internet shoppen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Eine Prepaid-Kreditkarte",
          "options": {
            "a": "gibt es für Jugendliche schon bei zahlreichen Geldinstituten.",
            "b": "können Jugendliche zusammen mit einer Handy-Prepaidkarte bekommen.",
            "c": "macht es möglich, mit dem Handy zu bezahlen."
          },
          "answer": "a",
          "explanation": "Im ersten Absatz heißt es, dass Banken und alle Sparkassen Jugendlichen diese besondere Art von Kreditkarte anbieten; zudem hat die Stiftung Warentest 24 solcher Karten getestet."
        },
        {
          "num": 7,
          "stem": "Man hat Kontrolle über die Kosten,",
          "options": {
            "a": "da nur der Karteninhaber seine Karte aufladen darf.",
            "b": "denn die Eltern werden bei einer Aufladung benachrichtigt.",
            "c": "weil die Ausgaben durch das Guthaben begrenzt sind."
          },
          "answer": "c",
          "explanation": "Man kann die Karte nur einsetzen, wenn zuvor Geld darauf geladen wurde; ist das Guthaben verbraucht, kann man nicht mehr bezahlen („Man kann nicht mehr Geld ausgeben, als man hat“)."
        },
        {
          "num": 8,
          "stem": "Die Prepaid-Kreditkarte ist besonders geeignet für",
          "options": {
            "a": "Angestellte mit einem guten Gehalt.",
            "b": "Jugendliche ohne festes Einkommen.",
            "c": "Menschen mit einem eigenen Bankkonto."
          },
          "answer": "b",
          "explanation": "Die Karte schützt Kinder und Jugendliche vor Überschuldung und eignet sich generell für Menschen ohne regelmäßiges oder festes Einkommen, da sie nicht an ein Gehaltskonto gebunden ist."
        },
        {
          "num": 9,
          "stem": "Prepaid-Karten",
          "options": {
            "a": "kosten ähnlich viel wie klassische Kreditkarten.",
            "b": "verursachen keine unerwarteten Kosten.",
            "c": "werden als Zahlungsmittel ebenso akzeptiert wie klassische Kreditkarten."
          },
          "answer": "a",
          "explanation": "Laut „Finanztest“ der Stiftung Warentest sind Prepaid-Karten „nicht teurer als klassische Kreditkarten, und auch die Nutzungsgebühren unterscheiden sich kaum“."
        },
        {
          "num": 10,
          "stem": "Bei Prepaid-Karten zahlen",
          "options": {
            "a": "Erwachsene ab 21 Jahren eine höhere Jahresgebühr als Jugendliche.",
            "b": "Jugendliche unter 18 Jahren nur die Nutzungsgebühr am Geldautomaten.",
            "c": "Kunden zwischen 18 und 21 Jahren noch nichts."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz steht: „Erwachsene bezahlen für Prepaid-Karten zwischen 29 und 39 Euro im Jahr. Karten für Jugendliche kosten im Jahr höchstens 22 Euro.“ (Bei vielen Banken – aber nicht allen – sind sie bis 18 oder 21 kostenlos.)"
        }
      ]
    },
    {
      "id": "11",
      "title": "Test 11 – Krista der tierische Star",
      "isVariant": false,
      "paragraphs": [
        "Krista ist die schönste Kuh Deutschlands. Und jetzt auch noch ein Kinostar. Am letzten Donnerstag kam ein Film über die schwarz-weiß gefleckte Kuh und ihre Besitzer in einige norddeutsche Kinos. Wovon der Film handelt? Von Kristas Leben auf dem Hof der Familie Seeger in Bissel, einem kleinen Dorf in Norddeutschland. Antje Schneider und Carsten Waldbauer sind Filmemacher. Vor einigen Jahren hatten sie die Idee, eine Dokumentation über Kühe zu machen, genauer gesagt über Holstein-Rinder. Die Holstein-Rinder sind eine der wichtigsten Rinderrassen weltweit, kommen aber trotz des deutschen Namens aus Nordamerika. Diese Kühe werden überwiegend als Milchvieh gehalten. Die Holstein-Rinder sind so verbreitet, dass sie inzwischen andere Rassen fast vollständig verdrängt haben. Das gilt vor allem für die vielen Bauernhöfe in Deutschland, die ausschließlich Milch produzieren. Auf einem dieser Höfe wollten Antje Schneider und Carsten Waldbauer Aufnahmen für ihre Dokumentation machen, und die Wahl fiel auf den Hof der Familie Seeger.",
        "Doch als die beiden Filmemacher mit den Dreharbeiten beginnen wollten, sahen sie plötzlich – Krista. Krista änderte alles. Die Schönheit vom Lande beeindruckte Schneider und Waldbauer so sehr, dass sie den Plan für ihre Dokumentation gegen den Willen ihres Senders komplett änderten. Im Mittelpunkt sollte nun Krista stehen, die schönste Holstein-Kuh Deutschlands. Krista gehört zur Weltelite. Auf Veranstaltungen wird sie immer wieder ausgezeichnet. Bei einer Tierschau in Italien erhielt sie zwar nicht den ersten Preis, aber trotzdem war sie unter den schönsten Kühen Europas. Kristas Besitzer Jörg Seeger ist begeistert von seinem Star im Stall. Jörg und Janine Seeger erlauben dem Kinozuschauer interessante Einblicke in ihren Alltag auf dem Bauernhof. Die Kamera verfolgt zwar immer den Weg von Kuh Krista, aber zu sehen ist dabei natürlich auch die Arbeit der gesamten Familie auf dem Hof. Manchmal ist das auch ein romantisches Leben, es ist aber vor allem immer sehr arbeitsreich. „Für mich sind Kühe nicht nur Nutztiere“, sagt die Bäuerin Janine Seeger. Schon als Kind hätten ihr die Tiere Geborgenheit, manchmal Trost gespendet. Aber sie weiß, dass die Kühe Geld bringen müssen, entweder durch möglichst viel Milch oder durch viel Nachwuchs. Die kleinen Kälber lassen sich zu recht guten Preisen verkaufen, das lohnt sich für die Seegers. Krista kann zunächst aus gesundheitlichen Gründen keine Kälber bekommen. Auch diese Problematik wird im Film gezeigt. Der Zuschauer merkt, dass Jörg Seeger enttäuscht ist: Seine beste Kuh kann kein Kalb bekommen. Aber es geht gut aus, denn Krista wird operiert und nach Ende der Dreharbeiten klappt es dann doch mit dem Nachwuchs für die Kuh.",
        "Während der jahrelangen Dreharbeiten hat sich auch die Familie entwickelt. Mittlerweile haben die Seegers zwei Kinder. „Deshalb verändert sich im Film mein Gewicht etwas“, erzählt Janine Seeger und lacht. Und wie ist es so, vor der Kamera zu stehen? „Erst ungewohnt, dann irgendwie vertraut“, sagt die 32-Jährige. Zu den Filmemachern habe sich ein freundschaftliches Verhältnis entwickelt. „Wie schön, Carsten und Antje sind wieder da“, habe es dann nur noch geheißen, wenn das Team anrückte. Der Film zeigt aber auch, wie sich im Laufe der Jahre das Leben auf dem Hof der Seegers verändert hat und wie schwierig es auch hier geworden ist, mit Milchkühen Geld zu verdienen. Der Markt ist hart umkämpft und die Preise sinken immer weiter, denn die Verbraucher im Supermarkt greifen gerne zum günstigsten Produkt. Für viele ist es da nicht wichtig, wie die Milch produziert wurde. Auch das zeigt der Film, wenngleich eher nebenbei. Familie Seeger ist stolz darauf, dass ein Film über ihren Hof und über die schöne Kuh Krista gedreht wurde. So heißt nun übrigens auch der Film: „Die schöne Krista“. Am vergangenen Wochenende haben die Seegers den Film bei einem Hoffest gezeigt. Familie und Freunde sowie Nachbarn waren zu Gast, und alle haben sich über den Film gefreut. „Die schöne Krista“ ist auch in die Auswahl für den Deutschen Filmpreis gekommen, als einer der fünfzehn besten Dokumentarfilme. Die 500 Filmkritiker, die diese 15 Filme ausgewählt haben, waren begeistert. Schwieriger sei es, so die Produktionsfirma, die Kinobetreiber vom Film zu überzeugen. „Was sollen wir mit einer Kuh?“, sei eine häufige Reaktion. Vielleicht würden sie ihre Meinung ändern, wenn sie Krista einmal auf dem Hof gesehen hätten."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Holstein-Rinder",
          "options": {
            "a": "sind in der Milchproduktion beliebter als andere Rinderrassen.",
            "b": "spielen in der Milchproduktion kaum eine Rolle.",
            "c": "stammen aus Norddeutschland."
          },
          "answer": "a",
          "explanation": "Im Text heißt es: „Diese Kühe werden überwiegend als Milchvieh gehalten. Die Holstein-Rinder sind so verbreitet, dass sie inzwischen andere Rassen fast vollständig verdrängt haben.“"
        },
        {
          "num": 7,
          "stem": "Die Kuh Krista",
          "options": {
            "a": "hat bereits einige Preise gewonnen.",
            "b": "war Siegerin bei einer Veranstaltung in Italien.",
            "c": "wurde als schönste Kuh Europas ausgezeichnet."
          },
          "answer": "a",
          "explanation": "Laut Text gehört Krista zur Weltelite und wird „auf Veranstaltungen immer wieder ausgezeichnet“ (in Italien erhielt sie allerdings nicht den ersten Preis)."
        },
        {
          "num": 8,
          "stem": "Während der Filmaufnahmen",
          "options": {
            "a": "bekam Krista ein Kalb.",
            "b": "wäre Krista fast gestorben.",
            "c": "wurde Krista operiert."
          },
          "answer": "c",
          "explanation": "Im Text steht, dass Krista operiert wird und es erst „nach Ende der Dreharbeiten“ mit dem Nachwuchs klappt."
        },
        {
          "num": 9,
          "stem": "Die wirtschaftlichen Probleme von Milchbetrieben",
          "options": {
            "a": "betreffen die Familie Seeger nicht.",
            "b": "sind eine Folge des Verbraucherverhaltens.",
            "c": "werden im Film ausführlich behandelt."
          },
          "answer": "b",
          "explanation": "Im letzten Absatz wird erklärt, dass die Preise immer weiter sinken, „denn die Verbraucher im Supermarkt greifen gerne zum günstigsten Produkt“."
        },
        {
          "num": 10,
          "stem": "„Die schöne Krista“",
          "options": {
            "a": "begeistert Kinobetreiber bislang nicht.",
            "b": "konnte die Kritiker nicht überzeugen.",
            "c": "wurde als beste Dokumentation ausgezeichnet."
          },
          "answer": "a",
          "explanation": "Während die 500 Filmkritiker begeistert waren, sei es laut Produktionsfirma schwieriger, „die Kinobetreiber vom Film zu überzeugen“ („Was sollen wir mit einer Kuh?“)."
        }
      ]
    },
    {
      "id": "11a",
      "title": "Test 11a – Krista der tierische Star (Variante)",
      "isVariant": true,
      "paragraphs": [
        "Krista ist die schönste Kuh Deutschlands. Und jetzt auch noch ein Kinostar. Am letzten Donnerstag kam ein Film über die schwarz-weiß gefleckte Kuh und ihre Besitzer in einige norddeutsche Kinos. Wovon der Film handelt? Von Kristas Leben auf dem Hof der Familie Seeger in Bissel, einem kleinen Dorf in Norddeutschland. Antje Schneider und Carsten Waldbauer sind Filmemacher. Vor einigen Jahren hatten sie die Idee, eine Dokumentation über Kühe zu machen, genauer gesagt über Holstein-Rinder. Die Holstein-Rinder sind eine der wichtigsten Rinderrassen weltweit, kommen aber trotz des deutschen Namens aus Nordamerika. Diese Kühe werden überwiegend als Milchvieh gehalten. Die Holstein-Rinder sind so verbreitet, dass sie inzwischen andere Rassen fast vollständig verdrängt haben. Das gilt vor allem für die vielen Bauernhöfe in Deutschland, die ausschließlich Milch produzieren. Auf einem dieser Höfe wollten Antje Schneider und Carsten Waldbauer Aufnahmen für ihre Dokumentation machen, und die Wahl fiel auf den Hof der Familie Seeger.",
        "Doch als die beiden Filmemacher mit den Dreharbeiten beginnen wollten, sahen sie plötzlich – Krista. Krista änderte alles. Die Schönheit vom Lande beeindruckte Schneider und Waldbauer so sehr, dass sie den Plan für ihre Dokumentation gegen den Willen ihres Senders komplett änderten. Im Mittelpunkt sollte nun Krista stehen, die schönste Holstein-Kuh Deutschlands. Krista gehört zur Weltelite. Auf Veranstaltungen wird sie immer wieder ausgezeichnet. Bei einer Tierschau in Italien erhielt sie zwar nicht den ersten Preis, aber trotzdem war sie unter den schönsten Kühen Europas. Kristas Besitzer Jörg Seeger ist begeistert von seinem Star im Stall. Jörg und Janine Seeger erlauben dem Kinozuschauer interessante Einblicke in ihren Alltag auf dem Bauernhof. Die Kamera verfolgt zwar immer den Weg von Kuh Krista, aber zu sehen ist dabei natürlich auch die Arbeit der gesamten Familie auf dem Hof. Manchmal ist das auch ein romantisches Leben, es ist aber vor allem immer sehr arbeitsreich. „Für mich sind Kühe nicht nur Nutztiere“, sagt die Bäuerin Janine Seeger. Schon als Kind hätten ihr die Tiere Geborgenheit, manchmal Trost gespendet. Aber sie weiß, dass die Kühe Geld bringen müssen, entweder durch möglichst viel Milch oder durch viel Nachwuchs. Die kleinen Kälber lassen sich zu recht guten Preisen verkaufen, das lohnt sich für die Seegers. Krista kann zunächst aus gesundheitlichen Gründen keine Kälber bekommen. Auch diese Problematik wird im Film gezeigt. Der Zuschauer merkt, dass Jörg Seeger enttäuscht ist: Seine beste Kuh kann kein Kalb bekommen. Aber es geht gut aus, denn Krista wird operiert und nach Ende der Dreharbeiten klappt es dann doch mit dem Nachwuchs für die Kuh.",
        "Während der jahrelangen Dreharbeiten hat sich auch die Familie entwickelt. Mittlerweile haben die Seegers zwei Kinder. „Deshalb verändert sich im Film mein Gewicht etwas“, erzählt Janine Seeger und lacht. Und wie ist es so, vor der Kamera zu stehen? „Erst ungewohnt, dann irgendwie vertraut“, sagt die 32-Jährige. Zu den Filmemachern habe sich ein freundschaftliches Verhältnis entwickelt. „Wie schön, Carsten und Antje sind wieder da“, habe es dann nur noch geheißen, wenn das Team anrückte. Der Film zeigt aber auch, wie sich im Laufe der Jahre das Leben auf dem Hof der Seegers verändert hat und wie schwierig es auch hier geworden ist, mit Milchkühen Geld zu verdienen. Der Markt ist hart umkämpft und die Preise sinken immer weiter, denn die Verbraucher im Supermarkt greifen gerne zum günstigsten Produkt. Für viele ist es da nicht wichtig, wie die Milch produziert wurde. Auch das zeigt der Film, wenngleich eher nebenbei. Familie Seeger ist stolz darauf, dass ein Film über ihren Hof und über die schöne Kuh Krista gedreht wurde. So heißt nun übrigens auch der Film: „Die schöne Krista“. Am vergangenen Wochenende haben die Seegers den Film bei einem Hoffest gezeigt. Familie und Freunde sowie Nachbarn waren zu Gast, und alle haben sich über den Film gefreut. „Die schöne Krista“ ist auch in die Auswahl für den Deutschen Filmpreis gekommen, als einer der fünfzehn besten Dokumentarfilme. Die 500 Filmkritiker, die diese 15 Filme ausgewählt haben, waren begeistert. Schwieriger sei es, so die Produktionsfirma, die Kinobetreiber vom Film zu überzeugen. „Was sollen wir mit einer Kuh?“, sei eine häufige Reaktion. Vielleicht würden sie ihre Meinung ändern, wenn sie Krista einmal auf dem Hof gesehen hätten."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Holstein-Rinder",
          "options": {
            "a": "dominieren als Rinderrasse die Milchviehwirtschaft.",
            "b": "sind für die Milchproduktion wenig geeignet.",
            "c": "wurden ursprünglich in Norddeutschland gezüchtet."
          },
          "answer": "a",
          "explanation": "Im Text steht, dass Holstein-Rinder überwiegend als Milchvieh gehalten werden und so verbreitet sind, „dass sie inzwischen andere Rassen fast vollständig verdrängt haben“."
        },
        {
          "num": 7,
          "stem": "Die Kuh Krista",
          "options": {
            "a": "hat bereits einige Preise gewonnen.",
            "b": "war Siegerin bei einer Veranstaltung in Italien.",
            "c": "wurde zur schönsten Kuh Europas gewählt."
          },
          "answer": "a",
          "explanation": "Krista ist die schönste Holstein-Kuh Deutschlands und wird „auf Veranstaltungen immer wieder ausgezeichnet“."
        },
        {
          "num": 8,
          "stem": "Während der Filmaufnahmen",
          "options": {
            "a": "bekam Krista Nachwuchs.",
            "b": "wäre Krista fast gestorben.",
            "c": "wurde Krista ärztlich behandelt."
          },
          "answer": "c",
          "explanation": "Im Text heißt es, dass Krista zunächst aus gesundheitlichen Gründen keine Kälber bekommen kann, dann operiert (also ärztlich behandelt) wird und erst nach Ende der Dreharbeiten Nachwuchs bekommt."
        },
        {
          "num": 9,
          "stem": "Die wirtschaftlichen Probleme von Milchbetrieben",
          "options": {
            "a": "betreffen die Familie Seeger nicht.",
            "b": "sind eine Folge des Verbraucherverhaltens.",
            "c": "werden im Film ausführlich behandelt."
          },
          "answer": "b",
          "explanation": "Die Preise sinken immer weiter, weil die Verbraucher im Supermarkt bevorzugt zum billigsten Produkt greifen."
        },
        {
          "num": 10,
          "stem": "„Die schöne Krista“",
          "options": {
            "a": "begeistert Kinobetreiber bislang nicht.",
            "b": "konnte die Kritiker nicht überzeugen.",
            "c": "wurde als beste Dokumentation ausgezeichnet."
          },
          "answer": "a",
          "explanation": "Laut Produktionsfirma ist es schwierig, die Kinobetreiber vom Film zu überzeugen, da diese oft fragen: „Was sollen wir mit einer Kuh?“"
        }
      ]
    },
    {
      "id": "12",
      "title": "Test 12 – Wie Babys lernen",
      "isVariant": false,
      "paragraphs": [
        "Bereits mit sechs Monaten können Babys zwischen möglichen und unmöglichen Ereignissen unterscheiden und denken über Ursache und Folge nach. Unglaubliche Ergebnisse sind das, bedenkt man, dass ein Säugling vor 50 Jahren noch als leeres Blatt gesehen wurde. Man glaubte, dass ein Säugling äußere Einflüsse nur bedingt wahrnehmen oder Empfindungen wie Schmerz nicht spüren kann. Inzwischen hat die Kleinstkindforschung eine ganz andere Meinung und weiß: Babys bedienen sich sehr vieler komplizierter Forschungsmethoden. Sie lernen nicht nur, indem sie tun, was sie bei ihren Eltern sehen, sondern sie lernen mit Versuchen die Welt kennen. Eine der Fragen, die Babyforscher dabei beschäftigt, lautet: Wie viel Klugheit ist angeboren, wie viel erlernt? Lässt sich die Intelligenz also entwickeln? Wenn ja, welche Umwelt macht Babys intelligent?",
        "Was die Forscher heute glauben: Rund 50 Prozent unseres geistigen Könnens wurde von unseren Eltern vererbt, das heißt, die Hälfte unserer Intelligenz ist uns schon bei der Geburt mitgegeben. Die andere Hälfte wird durch Schule, Ausbildung, Freunde, Mutter, Vater, Geschwister, Großeltern, kurz: die Umwelt bestimmt. Aber dieses Verhältnis von Erbgut auf der einen und Umwelt auf der anderen Seite verändert sich im Lauf des Lebens. Bei Kleinkindern zum Beispiel sind die Umwelteinflüsse von größerer Bedeutung als im späteren Leben. Der US-Forscher Robert Plomin meint, dass die Umwelt in diesem Alter mit etwa 80 Prozent einen sehr hohen Stellenwert einnimmt. Mit zunehmendem Alter wird das Erbgut stärker sichtbar. Im Erwachsenenalter ist der Einfluss der Gene auf die Intelligenz mit etwa 60 Prozent deutlich größer als der der Umwelt. Um das Lernen zu lernen, brauchen kleine Kinder weder spezielle Programme noch intelligentes Spielzeug – sondern Menschen. Gut ist nach Meinung der Forscher zum Beispiel eine Familie, in der vorgelesen und gemeinsam gespielt wird.",
        "Unsere Kinder werden immer klüger: Drei- bis Siebenjährige in Deutschland können heute mehr als noch vor 25 Jahren. Alle 10 Jahre nimmt die Intelligenz um rund 3 Prozent zu. Liegt das vielleicht daran, dass heute schon Kleinkinder vor Wissensvideos sitzen, dass Einjährige mit sprechenden Handys herumrennen und dass bei vielen noch vor dem Schulbeginn ein Lerncomputer auf dem Geburtstagstisch steht? Die Wissenschaftler glauben das nicht: „Intelligenz ist nicht gleich Wissen“, sagt Professor Ralph Dawirs, Neurobiologe an der Uniklinik Erlangen. Es gehe nicht darum, Wissen anzusammeln. „Verstehen heißt Verbindungen herstellen und auswählen“. Im Gehirn macht das der Stirnlappen. Das Stirnhirn ist bei der Geburt zwar organisch da, hat seine volle Funktion aber noch nicht erreicht. „Es braucht geistige Nahrung, Futter“, sagte Dawirs. Deshalb geht es im Kleinkindalter erst einmal darum, dass möglichst viele dem jeweiligen Entwicklungsstand angemessene Impulse verarbeitet werden. Eine Spielzeugente, die man anfassen kann und über die die Mutter vielleicht sagt: „Ja, das ist eine Ente. Schau, sie kann in der Badewanne schwimmen“, ist also ungleich mehr wert als die Spielzeugente, die auf einem Bildschirm erscheint.",
        "Sind Lerncomputer, Handy und Videos deshalb Teufelswerk? „Wenn man sie nur wenig benutzt, schaden sie nicht“, sagt Entwicklungsforscherin Pauen, „die Frage ist nur, ob sie nützen“. Die beste Unterstützung der Entwicklung sei immer noch menschliche Begleitung: „Man tut einem Baby keinen Gefallen damit, wenn man es mit einem Spielzeug alleine lässt. Besser ist, es beim Lernen beobachten, so wenig wie möglich stören, aber zu Hilfe zu kommen, wenn etwas nicht klappt“, so ihr Tipp für Eltern. Es ist besser, Kinder im Dreck spielen zu lassen und mit ihnen in die Natur zu gehen. Dort lernen sie viel mehr als mit dem besten Computerspiel."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Man glaubte früher, dass Babys",
          "options": {
            "a": "kaum auf ihre Umwelt reagieren.",
            "b": "nur nachmachen, was ihre Eltern tun.",
            "c": "sehr kompliziert denken."
          },
          "answer": "a",
          "explanation": "Im ersten Absatz steht: „Man glaubte, dass ein Säugling äußere Einflüsse nur bedingt wahrnehmen oder Empfindungen wie Schmerz nicht spüren kann.“"
        },
        {
          "num": 7,
          "stem": "Die Umwelt ist für die Entwicklung der Intelligenz",
          "options": {
            "a": "im Erwachsenenalter besonders wichtig.",
            "b": "im Kleinkindalter besonders wichtig.",
            "c": "in jedem Alter gleich wichtig."
          },
          "answer": "b",
          "explanation": "Laut Text sind bei Kleinkindern „die Umwelteinflüsse von größerer Bedeutung als im späteren Leben“ (mit etwa 80 Prozent Stellenwert)."
        },
        {
          "num": 8,
          "stem": "Bessere Entwicklungschancen haben Kinder, je",
          "options": {
            "a": "früher sie den Umgang mit Computern erlernen.",
            "b": "mehr altersgerechte Erfahrungen sie machen können.",
            "c": "öfter sie beim Spielen auf sich gestellt sind."
          },
          "answer": "b",
          "explanation": "Im dritten Absatz heißt es: „Deshalb geht es im Kleinkindalter erst einmal darum, dass möglichst viele dem jeweiligen Entwicklungsstand angemessene Impulse verarbeitet werden.“"
        },
        {
          "num": 9,
          "stem": "Fernsehen und Computer sind",
          "options": {
            "a": "für die geistige Entwicklung eher ungeeignet.",
            "b": "geistige Nahrung für das Gehirn.",
            "c": "sehr gute Hilfsmittel für das Lernen."
          },
          "answer": "a",
          "explanation": "Echte Erfahrungen zum Anfassen sind laut Text ungleich mehr wert als Bildschirme; Entwicklungsforscherin Pauen bezweifelt, ob Lerncomputer, Handys und Videos überhaupt nützen."
        },
        {
          "num": 10,
          "stem": "Kontakt mit Menschen",
          "options": {
            "a": "fördert die Intelligenz des Babys am besten.",
            "b": "ist weniger wichtig als Erfahrungen in der freien Natur.",
            "c": "wird unwichtig, wenn es gutes Spielzeug gibt."
          },
          "answer": "a",
          "explanation": "Im Text wird betont: „Um das Lernen zu lernen, brauchen kleine Kinder weder spezielle Programme noch intelligentes Spielzeug – sondern Menschen“ und „Die beste Unterstützung der Entwicklung sei immer noch menschliche Begleitung“."
        }
      ]
    },
    {
      "id": "13",
      "title": "Test 13 – Der Ein-Personen-Karneval von Unna",
      "isVariant": false,
      "paragraphs": [
        "Als Helmut Scherer vor genau 50 Jahren zum ersten Mal mit seinem Bollerwagen durch die westfälische Kleinstadt Unna zog, wurde er von den Leuten ausgelacht. Heute aber ist er eher eine städtische Berühmtheit und sogar weit über die Grenzen seiner Heimatstadt hinaus bekannt. Der 71-Jährige ist der einzige Teilnehmer des weltweit kleinsten Karnevalsumzugs. An Weiberfastnacht, dem letzten Donnerstag der Karnevalsperiode eines Jahres, zieht er mit seinem Handwagen los: Er selbst ist dann als blondes Schulmädchen verkleidet und auf seinem Bollerwagen hat er aus Pappe und Gips Figuren aufgebaut, die humoristisch ein aktuelles gesellschaftliches Thema – diesmal die Schulreform – aufgreifen. So macht er sich nach alter karnevalistischer Tradition über Missstände lustig. Helmut Scherer legt natürlich Wert darauf, dass er von Karnevalsmusik begleitet wird, die jedoch nicht von einer Musikgruppe, sondern von einem Radiorekorder gespielt wird.",
        "Vor 50 Jahren kam Helmut Scherer aus dem katholisch geprägten Paderborn, wo er seine Kindheit und Jugend verbracht hatte, nach Unna, dessen überwiegend evangelische Bevölkerung sich recht kühl und nüchtern gibt und deshalb anfangs auch wenig Verständnis für den katholischen Karnevalsbrauch zeigte. „Die Leute haben mir einen Vogel gezeigt und den Kopf geschüttelt“, beschreibt der „Narr aus Überzeugung“ die Anfänge. Auch bei der Stadtverwaltung, wo Scherer für Weiberfastnacht seinen Umzug ordnungsgemäß anmeldete, stieß er zunächst auf Unverständnis. Aber da sein Karnevalszug niemanden behinderte und auch nicht zu befürchten war, dass Unnas öffentliche Ordnung gestört würde, bekam er die Erlaubnis, mit seinem humoristischen Handwagen loszumarschieren.",
        "Über 10 Jahre lang zog Scherer einsam, belächelt und verspottet durch Unna, weder eisige Kälte noch Schnee konnten ihn davon abhalten. Doch der Karneval blieb für lange Zeit sein Privatvergnügen. Als dann die lokale Presse anfing, ihn zu unterstützen, wandelte sich die Meinung der Öffentlichkeit. Der einst verspottete Karnevalist stieg langsam zum närrischen Wahrzeichen einer Stadt ohne Karneval auf. Für die Stadtoberen ist heute die „Ein-Mann-Show“ die beste Werbung für Unna. Scherers Beharrlichkeit hat sich also ausgezahlt. Anlässlich seines fünfzigsten Karnevalsjubiläums wurde er sogar offiziell im Rathaus empfangen, um ihm – so wie es auch in den Karnevalshochburgen Köln, Düsseldorf und Mainz üblich ist – den goldenen Schlüssel des Rathauses zu übergeben.",
        "Obwohl er keinem Karnevalsverein angehört, wurde ihm die Ehre zuteil, als Karnevalsprinz in den Bund Deutscher Karneval aufgenommen zu werden; somit wurde es ihm möglich, auch bei den Rosenmontagszügen in den närrischen Hochburgen im Rheinland mitzuwirken. Weit über hundert Fans des standhaften Narren haben sich zu einem Fan-Club zusammengeschlossen, und etliche stehen beim jährlichen Umzug in Unna am Straßenrand und rufen statt „Spinner“ den rheinischen Karnevalsgruß „Helau“. Bei allem Fortschritt soll aber eines so bleiben, wie es immer war: Einen weiteren Teilnehmer am Zug duldet der Karnevalsprinz nicht. „Die Tradition soll aufrechterhalten bleiben“, sagt er schmunzelnd. „Aber nur solange mich die Füße tragen.“"
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Helmut Scherer",
          "options": {
            "a": "führt in Unna einen kleinen Karnevalsumzug durch.",
            "b": "ist in Unna seit 50 Jahren eine gefeierte Persönlichkeit.",
            "c": "veranstaltet den einzigen Karnevalsumzug der Welt."
          },
          "answer": "a",
          "explanation": "Im ersten Absatz heißt es: „Der 71-Jährige ist der einzige Teilnehmer des weltweit kleinsten Karnevalsumzugs“ in Unna."
        },
        {
          "num": 7,
          "stem": "Auf seinem Handwagen",
          "options": {
            "a": "fährt traditionell ein blondes Schulmädchen mit.",
            "b": "präsentiert er kleine Szenen, die auf den Alltag Bezug nehmen.",
            "c": "stellt er sozialkritische Themen auf witzige Art und Weise dar."
          },
          "answer": "c",
          "explanation": "Auf seinem Bollerwagen hat er Figuren aufgebaut, „die humoristisch ein aktuelles gesellschaftliches Thema – diesmal die Schulreform – aufgreifen. So macht er sich nach alter karnevalistischer Tradition über Missstände lustig.“"
        },
        {
          "num": 8,
          "stem": "Die Bevölkerung von Unna",
          "options": {
            "a": "hatte zunächst wenig Verständnis für Helmut Scherer.",
            "b": "hielt anfangs Helmut Scherer für kühl und nüchtern.",
            "c": "verhinderte Helmut Scherers ersten Karnevalsumzug."
          },
          "answer": "a",
          "explanation": "Die überwiegend evangelische Bevölkerung von Unna zeigte „anfangs auch wenig Verständnis für den katholischen Karnevalsbrauch“ und lachte ihn zunächst aus."
        },
        {
          "num": 9,
          "stem": "Der kleinste Karnevalsumzug der Welt",
          "options": {
            "a": "hat Helmut Scherer sogar Geld eingebracht.",
            "b": "ist heute eine gute Reklame für die Stadt Unna.",
            "c": "wird in Zukunft von einer ganzen Gruppe von Leuten durchgeführt."
          },
          "answer": "b",
          "explanation": "Im dritten Absatz steht ausdrücklich: „Für die Stadtoberen ist heute die ‚Ein-Mann-Show‘ die beste Werbung für Unna.“"
        },
        {
          "num": 10,
          "stem": "Helmut Scherer",
          "options": {
            "a": "hat an Karnevalsumzügen in mehreren Städten teilgenommen.",
            "b": "hat inzwischen in ganz Deutschland Fan-Clubs.",
            "c": "sucht einen Nachfolger."
          },
          "answer": "a",
          "explanation": "Durch seine Aufnahme in den Bund Deutscher Karneval „wurde es ihm möglich, auch bei den Rosenmontagszügen in den närrischen Hochburgen im Rheinland mitzuwirken“."
        }
      ]
    },
    {
      "id": "13a",
      "title": "Test 13a – Der Ein-Personen-Karneval von Unna (Variante)",
      "isVariant": true,
      "paragraphs": [
        "Als Helmut Scherer vor genau 50 Jahren zum ersten Mal mit seinem Bollerwagen durch die westfälische Kleinstadt Unna zog, wurde er von den Leuten ausgelacht. Heute aber ist er eher eine städtische Berühmtheit und sogar weit über die Grenzen seiner Heimatstadt hinaus bekannt. Der 71-Jährige ist der einzige Teilnehmer des weltweit kleinsten Karnevalsumzugs. An Weiberfastnacht, dem letzten Donnerstag der Karnevalsperiode eines Jahres, zieht er mit seinem Handwagen los: Er selbst ist dann als blondes Schulmädchen verkleidet und auf seinem Bollerwagen hat er aus Pappe und Gips Figuren aufgebaut, die humoristisch ein aktuelles gesellschaftliches Thema – diesmal die Schulreform – aufgreifen. So macht er sich nach alter karnevalistischer Tradition über Missstände lustig. Helmut Scherer legt natürlich Wert darauf, dass er von Karnevalsmusik begleitet wird, die jedoch nicht von einer Musikgruppe, sondern von einem Radiorekorder gespielt wird.",
        "Vor 50 Jahren kam Helmut Scherer aus dem katholisch geprägten Paderborn, wo er seine Kindheit und Jugend verbracht hatte, nach Unna, dessen überwiegend evangelische Bevölkerung sich recht kühl und nüchtern gibt und deshalb anfangs auch wenig Verständnis für den katholischen Karnevalsbrauch zeigte. „Die Leute haben mir einen Vogel gezeigt und den Kopf geschüttelt“, beschreibt der „Narr aus Überzeugung“ die Anfänge. Auch bei der Stadtverwaltung, wo Scherer für Weiberfastnacht seinen Umzug ordnungsgemäß anmeldete, stieß er zunächst auf Unverständnis. Aber da sein Karnevalszug niemanden behinderte und auch nicht zu befürchten war, dass Unnas öffentliche Ordnung gestört würde, bekam er die Erlaubnis, mit seinem humoristischen Handwagen loszumarschieren.",
        "Über 10 Jahre lang zog Scherer einsam, belächelt und verspottet durch Unna, weder eisige Kälte noch Schnee konnten ihn davon abhalten. Doch der Karneval blieb für lange Zeit sein Privatvergnügen. Als dann die lokale Presse anfing, ihn zu unterstützen, wandelte sich die Meinung der Öffentlichkeit. Der einst verspottete Karnevalist stieg langsam zum närrischen Wahrzeichen einer Stadt ohne Karneval auf. Für die Stadtoberen ist heute die „Ein-Mann-Show“ die beste Werbung für Unna. Scherers Beharrlichkeit hat sich also ausgezahlt. Anlässlich seines fünfzigsten Karnevalsjubiläums wurde er sogar offiziell im Rathaus empfangen, um ihm – so wie es auch in den Karnevalshochburgen Köln, Düsseldorf und Mainz üblich ist – den goldenen Schlüssel des Rathauses zu übergeben.",
        "Obwohl er keinem Karnevalsverein angehört, wurde ihm die Ehre zuteil, als Karnevalsprinz in den Bund Deutscher Karneval aufgenommen zu werden; somit wurde es ihm möglich, auch bei den Rosenmontagszügen in den närrischen Hochburgen im Rheinland mitzuwirken. Weit über hundert Fans des standhaften Narren haben sich zu einem Fan-Club zusammengeschlossen, und etliche stehen beim jährlichen Umzug in Unna am Straßenrand und rufen statt „Spinner“ den rheinischen Karnevalsgruß „Helau“. Bei allem Fortschritt soll aber eines so bleiben, wie es immer war: Einen weiteren Teilnehmer am Zug duldet der Karnevalsprinz nicht. „Die Tradition soll aufrechterhalten bleiben“, sagt er schmunzelnd. „Aber nur solange mich die Füße tragen.“"
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Helmut Scherer",
          "options": {
            "a": "ist in Unna seit 50 Jahren eine gefeierte Persönlichkeit.",
            "b": "veranstaltet an Karneval allein einen Umzug.",
            "c": "veranstaltet den einzigen Karnevalsumzug der Welt."
          },
          "answer": "b",
          "explanation": "Im Text heißt es, dass der 71-Jährige „der einzige Teilnehmer des weltweit kleinsten Karnevalsumzugs“ ist und an Weiberfastnacht allein mit seinem Handwagen loszieht."
        },
        {
          "num": 7,
          "stem": "Auf seinem Handwagen",
          "options": {
            "a": "fährt traditionell ein blondes Schulmädchen mit.",
            "b": "präsentiert er kleine Szenen, die auf den Alltag Bezug nehmen.",
            "c": "stellt er sozialkritische Themen auf witzige Art und Weise dar."
          },
          "answer": "c",
          "explanation": "Er baut auf seinem Bollerwagen Figuren auf, die humoristisch ein aktuelles gesellschaftliches Thema aufgreifen, und macht sich so über Missstände lustig."
        },
        {
          "num": 8,
          "stem": "Die Bevölkerung von Unna",
          "options": {
            "a": "hatte zunächst wenig Verständnis für Helmut Scherer.",
            "b": "hielt anfangs Helmut Scherer für kühl und nüchtern.",
            "c": "verhinderte Helmut Scherers ersten Karnevalsumzug."
          },
          "answer": "a",
          "explanation": "Die Bevölkerung von Unna zeigte anfangs wenig Verständnis für den Karnevalsbrauch; die Leute zeigten ihm einen Vogel und schüttelten den Kopf."
        },
        {
          "num": 9,
          "stem": "Der kleinste Karnevalsumzug der Welt",
          "options": {
            "a": "hat Helmut Scherer sogar Geld eingebracht.",
            "b": "ist heute eine gute Reklame für die Stadt Unna.",
            "c": "wird in Zukunft von einer ganzen Gruppe von Leuten durchgeführt."
          },
          "answer": "b",
          "explanation": "Für die Stadtoberen ist die „Ein-Mann-Show“ heute „die beste Werbung für Unna“."
        },
        {
          "num": 10,
          "stem": "Helmut Scherer",
          "options": {
            "a": "hat an Karnevalsumzügen in mehreren Städten teilgenommen.",
            "b": "hat inzwischen in ganz Deutschland Fan-Clubs.",
            "c": "sucht einen Nachfolger."
          },
          "answer": "a",
          "explanation": "Neben seinem Umzug in Unna wirkte er als Mitglied im Bund Deutscher Karneval auch bei den Rosenmontagszügen in den Karnevalshochburgen im Rheinland mit."
        }
      ]
    },
    {
      "id": "14",
      "title": "Test 14 – Österreich, das Land der Poolbesitzer",
      "isVariant": false,
      "paragraphs": [
        "Österreich schwimmt. Und das nicht nur in Seen, Teichen oder Freibädern. Ein Blick über die Gartenzäune des Landes macht deutlich: Die Österreicher schwimmen zunehmend gerne zu Hause. Die Poolbranche schätzt die Anzahl der Poolbesitzer in Österreich auf etwa 90.000 bis 150.000. Im Vergleich zu Deutschland ist Österreich wesentlich dichter mit Pools besiedelt. Warum Swimmingpools so beliebt sind, darüber herrscht Uneinigkeit. Manche Vertreter der Branche sehen darin eine Reaktion auf wirtschaftlich unsichere Zeiten. Da investierten die Leute gerne in die eigenen vier Wände und in den Garten inklusive Pools, meinen sie. Andere sehen darin einen Ausdruck des allgemeinen Wellness- und Gesundheitstrends. Auch die Sehnsucht nach dem Meer wird bisweilen als Argument für den ausgeprägten Wunsch nach einem Pool vorgebracht. Das allein kann es aber wohl nicht sein, denn als stärkster Poolmarkt in Europa gilt nach wie vor Frankreich. Branchenkenner führen den Boom aber auch auf finanzielle Gründe zurück. Dass der Umsatz in den vergangenen Jahren stetig angestiegen ist, sehen viele im Angebot an preisgünstigen Pools begründet. Vor 20 Jahren sei ein eigenes Schwimmbad noch ein absolutes Luxusgut gewesen. Jetzt gebe es immer mehr Alternativen, die einen Pool erschwinglich machen.",
        "Welche Gründe auch ausschlaggebend sein mögen: Die Branche besitzt durchaus noch Potenzial, da sind sich alle einig. Laut einer kürzlich durchgeführten Studie träumt nämlich beinahe jeder zweite Österreicher von einem Pool. An erster Stelle der Wohnungswünsche steht er zwar nicht: So hat für 97 Prozent der befragten Österreicher die Traumimmobilie einen Balkon, eine Loggia oder eine Terrasse, und 92 Prozent wünschen sich eine Garage. 82 Prozent sehnen sich nach einem Garten, und 46 Prozent nach einem Swimmingpool – und zehn Prozent besitzen auch einen solchen. Dabei gibt es regionale Unterschiede. In absoluten Zahlen gibt es die meisten Pools in Wien und Niederösterreich. Pro Kopf gerechnet gibt es aber in Vorarlberg die meisten privaten Schwimmbäder.",
        "Einen nagelneuen Pool hat auch die 37-jährige Rija in ihrem neuen Zuhause. Die Wienerin ist mit ihrem Lebensgefährten vor kurzem nach Niederösterreich gezogen. „Es war immer mein Traum, einen Pool zu haben“, sagt sie. Nun kann sie den Sommer im eigenen Pool genießen. Neben der Entspannung und Abkühlung hat der Pool für sie noch einen weiteren Wert: „Der Pool hat Leben in den Garten gebracht. Es haben sich schon alle möglichen Bekannten zum Schwimmen angemeldet“, sagt sie. „Denen drück ich aber vorher einen Spaten in die Hand – ein Teil vom Garten ist ja noch Baustelle.“ Tatsächlich schweißt so ein Pool nicht nur die Nachbarschaft zusammen. „Es ist auch die beste Werbung für weitere Becken. Kaum hat einer in einer Siedlung einen Pool, hat der Nachbar spätestens nach zwei Jahren auch einen“, meint ein Branchenvertreter. Besonders deutlich wird das in Kleingartensiedlungen, bei denen ein kleines Schwimmbecken schon beinahe zur Grundausstattung gehört.",
        "Doch manche Menschen bevorzugen naturnahe Schwimmteiche. Nach Schätzungen macht der Anteil der Schwimmteiche am Schwimmanlagenmarkt rund 15 Prozent aus, in den vergangenen Jahren ist die Nachfrage nach Schwimmteichen stark gestiegen. Das hat auch zur Entwicklung von Naturpools geführt. Optisch ein klassischer Swimmingpool, kommt der Naturpool gänzlich ohne Chemikalien aus. Hier wird das Wasser durch Pumpen und Filtersysteme sauber gehalten. Bei der natürlichen Variante geht es übrigens bei 35.000 Euro los. Dafür spart man sich das jährliche Befüllen und Putzen. Das jährliche Befüllen von Pools aus den Wasserleitungen kann in manchen Regionen gelegentlich zu Wasserknappheit führen. Das betrifft aber meist nur jene Gemeinden, die von sehr kleinen Wassergenossenschaften versorgt werden. In Wien fällt die Befüllung der Pools kaum auf. Was den Leiter des Wiener Rohrnetzes eher stört, ist der Wasserdiebstahl über Hydranten, also über die Zapfstellen in den Straßen für Feuerwehr und Straßenreinigung. Denn wer es besonders eilig hat, kann seinen Pool auch über die Hydranten befüllen. Das geht schneller, muss aber angemeldet werden und kostet Geld. Generell gebe es aber keine Wasserknappheit. Es sei genug Wasser für alle da, so die Wasserversorger. Fürs Auffüllen von Pools, aber auch fürs Blumengießen, zum Duschen und auch zum Trinken: Wir verwenden in Österreich nur ein Prozent der vorhandenen Wasserressourcen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Einige Vertreter der Poolbranche denken, dass",
          "options": {
            "a": "es in Österreich bald mehr Pools gibt als in Frankreich.",
            "b": "in unsicheren Zeiten weniger investiert wird.",
            "c": "mehr Leute einen Pool bauen, weil Pools billiger geworden sind."
          },
          "answer": "c",
          "explanation": "Im ersten Absatz steht: „Branchenkenner führen den Boom aber auch auf finanzielle Gründe zurück. Dass der Umsatz in den vergangenen Jahren stetig angestiegen ist, sehen viele im Angebot an preisgünstigen Pools begründet.“"
        },
        {
          "num": 7,
          "stem": "Laut einer Studie",
          "options": {
            "a": "möchten die meisten Befragten ein Heim mit Garage.",
            "b": "steht ein Pool nicht an erster Stelle auf der Wunschliste.",
            "c": "wünschen sich 10 Prozent der Österreicher einen Pool."
          },
          "answer": "b",
          "explanation": "Im zweiten Absatz heißt es ausdrücklich: „An erster Stelle der Wohnungswünsche steht er zwar nicht: So hat für 97 Prozent der befragten Österreicher die Traumimmobilie einen Balkon, eine Loggia oder eine Terrasse...“"
        },
        {
          "num": 8,
          "stem": "Rija ist der Meinung, dass",
          "options": {
            "a": "ein Pool die Nachbarn neidisch macht.",
            "b": "ihr Pool ein Anziehungspunkt für Freunde geworden ist.",
            "c": "ihre Freunde beim Poolbau helfen sollen."
          },
          "answer": "b",
          "explanation": "Rija sagt im dritten Absatz: „Der Pool hat Leben in den Garten gebracht. Es haben sich schon alle möglichen Bekannten zum Schwimmen angemeldet.“"
        },
        {
          "num": 9,
          "stem": "Naturpools",
          "options": {
            "a": "brauchen keine chemischen Reinigungsmittel.",
            "b": "müssen häufig geputzt werden.",
            "c": "sehen genauso aus wie Schwimmteiche."
          },
          "answer": "a",
          "explanation": "Im vierten Absatz steht: „Optisch ein klassischer Swimmingpool, kommt der Naturpool gänzlich ohne Chemikalien aus. Hier wird das Wasser durch Pumpen und Filtersysteme sauber gehalten.“"
        },
        {
          "num": 10,
          "stem": "In Wien",
          "options": {
            "a": "darf man einen Pool nur mit Wasser aus der Leitung füllen.",
            "b": "führt das Befüllen von Pools regelmäßig zu Wasserknappheit.",
            "c": "wird manchmal Wasser zum Befüllen von Pools gestohlen."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz heißt es: „In Wien fällt die Befüllung der Pools kaum auf. Was den Leiter des Wiener Rohrnetzes eher stört, ist der Wasserdiebstahl über Hydranten...“"
        }
      ]
    },
    {
      "id": "15",
      "title": "Test 15 – Schaufensterpuppe",
      "isVariant": false,
      "paragraphs": [
        "Der Puppenmacher: Die Schaufensterpuppe ist eine Pariserin und hatte erstmals 1849 in der Hauptstadt der Mode ihren Auftritt. Der französische Schneider Alexis Lavigne gilt als ihr Erfinder, auch wenn er damals seine Kleiderkreationen noch auf einer Schneiderpuppe vorführte. Bald schon taten es ihm andere Pariser Kollegen gleich: Sie begannen ihre Modelle vor den Geschäften aufzustellen, um die Passanten in die Verkaufsräume zu locken. Als Anfang des 20. Jahrhunderts die ersten großen Kaufhäuser eröffneten, erlebte die Schaufensterpuppe ihren Durchbruch. Der Puppenmacher Lester Gaba entwickelte in den 1930er Jahren das erste lebensecht wirkende Modell Cynthia. Sie durfte sogar mit auf Veranstaltungen, was beide berühmt machte. Fortan spiegelte die Schaufensterpuppe Zeitgeist und Schönheitsideale.",
        "Der Linzer Puppenmacher André Bauernfeind hat als Sammler begonnen, mittlerweile sind Schaufensterpuppen sein Beruf. Der 37-Jährige, der mehr als 1000 Modelle besitzt, ist österreichweit der Einzige, bei dem man sie reparieren lassen, aber auch mieten kann. Wer ihn an seinem Arbeitsplatz aufsucht, muss in den Keller. Die Eisentür steht offen, ein Blick in sein großes Atelier voller Schaufensterpuppen: Kinder, Frauen und Männer mit Perücke, geschminkt oder farblos, sitzend, liegend, dürr oder mollig, in Kisten verpackt oder in Einzelteilen von der Decke hängend. Während sich die Puppen in der Welt draußen perfekt präsentieren, wird hier in der Werkstatt mitunter ordentlich an ihrer Oberfläche gekratzt. Der 37-Jährige ist so etwas wie ein Schönheitschirurg für Schaufensterpuppen: Er macht sie wieder heil, verpasst ihnen aber auch Ganzkörper-Liftings, wenn gewünscht. Die bestehende Farbe wird dann entfernt, anschließend eine Grundierung und Farbe aufgetragen. Er klebt ihnen falsche Wimpern an und trägt mit einem Pinsel Schminke auf. Die Kosmetikprodukte kommen meistens aus der Drogerie, tragen aber manchmal auch Luxusnamen wie Armani oder Dior. Nur herkömmlichen Nagellack kann Bauernfeind nicht verwenden, weil dieser die Ölfarbe auflöst. Nicht selten fehlt den Puppen ein Finger, ein Ohr oder eine Nase. Dann greift der Linzer zur Modelliermasse, deren Zusammensetzung streng geheim ist. Weniger geheim sind die Preise: Für 45 Euro fertigt er eine neue Nase, rekonstruiert ein Ohr oder auch ein Kinn. Wer allerdings einen Kopf modellieren lassen möchte, muss mit 2500 Euro und acht Wochen rechnen, für einen gesamten Körper mit 15.000 Euro und Monaten.",
        "Obgleich er als Kind am liebsten mit Autos spielte, faszinierten ihn schon früh diese Mannequins in den Schaufenstern. Heute kommt er an keinem Schaufenster vorbei, ohne einen Blick hineinzuwerfen. „Ich erkenne schon an ihrem Standsockel, um welchen Hersteller es sich handelt“, sagt der gelernte Dekorateur. Sein erstes Exemplar kaufte er während seiner Ausbildung. 3500 Schilling wollte der Besitzer haben, man einigte sich auf Ratenzahlungen. Ein Jahr lang hat er sie abbezahlt. Die Puppe aus der Serie Ragazza mit der Nummer 9908 bekam bald Gesellschaft, die Sammlung vergrößerte sich sukzessive, zählte schon bald mehr als 100 Exponate. Aus dem Hobby wurde später ein Beruf. Bauernfeind verfeinerte sein Handwerk und übernahm schließlich ein altes Schaufensterpuppen-Unternehmen in Linz. Heute ist er Besitzer von 1200 Puppen, vermietet und repariert sie, stellt Sonderanfertigungen her. Bauernfeind verkauft auch für andere Hersteller. Er besitzt exklusiv die Handelsvertretung für eine belgische Schaufensterpuppen-Firma.",
        "Alle anderen renommierten Hersteller aus Europa haben irgendwann ihre Produktion nach Asien verlagert. Qualität und Nachhaltigkeit sind ihm wichtig. Gemeinsam mit einem Farblieferanten hat er deshalb eine Farbe für Puppen entwickelt, die nicht nur ökologisch einwandfrei, sondern auch für den Menschen unbedenklich ist. Schließlich dringen die Farbstoffe in die Textilien ein. „Meine Farbe könnte man sogar essen, und es würde nichts passieren.“ Weltweit gibt es etwa 100 Hersteller von Schaufensterpuppen, die zweimal im Jahr eine neue Kollektion herausbringen. Denn wie die Mode sind auch die Puppen Trends unterworfen. „In Frankreich, England und den USA werden natürliche Modelle immer beliebter, während bei uns noch abstrakte Modelle dominieren. Es lässt sich aber beobachten, dass man von einer Einheitsfigur wegkommt und dass immer häufiger vielfältige Figurtypen gewünscht werden“, sagt der Puppenmacher."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die erste Schaufensterpuppe wurde",
          "options": {
            "a": "Anfang des 20. Jahrhunderts von einem Puppenmacher erschaffen.",
            "b": "für die ersten großen Kaufhäuser produziert.",
            "c": "von einem französischen Schneider erfunden."
          },
          "answer": "c",
          "explanation": "Im ersten Absatz steht: „Die Schaufensterpuppe ist eine Pariserin und hatte erstmals 1849 in der Hauptstadt der Mode ihren Auftritt. Der französische Schneider Alexis Lavigne gilt als ihr Erfinder...“"
        },
        {
          "num": 7,
          "stem": "Bei der Restaurierung der Schaufensterpuppen",
          "options": {
            "a": "darf Herr Bauernfeind keinen normalen Nagellack auftragen.",
            "b": "können keine Luxusmarken eingesetzt werden.",
            "c": "verwendet er nur billige Produkte."
          },
          "answer": "a",
          "explanation": "Im zweiten Absatz heißt es: „Nur herkömmlichen Nagellack kann Bauernfeind nicht verwenden, weil dieser die Ölfarbe auflöst.“"
        },
        {
          "num": 8,
          "stem": "Der Puppenmacher",
          "options": {
            "a": "hat schon als Kind gerne mit Puppen gespielt.",
            "b": "konnte seine erste Schaufensterpuppe nicht auf einmal zahlen.",
            "c": "organisierte eine Ausstellung mit Schaufensterpuppen."
          },
          "answer": "b",
          "explanation": "Für sein erstes Exemplar wollte der Besitzer 3500 Schilling haben; „man einigte sich auf Ratenzahlungen. Ein Jahr lang hat er sie abbezahlt.“"
        },
        {
          "num": 9,
          "stem": "Herr Bauernfeind",
          "options": {
            "a": "eröffnete die erste Linzer Firma für Schaufensterpuppen.",
            "b": "handelt mit Schaufensterpuppen anderer Produzenten.",
            "c": "stellt heute keine Schaufensterpuppen mehr her."
          },
          "answer": "b",
          "explanation": "Im dritten Absatz steht: „Bauernfeind verkauft auch für andere Hersteller. Er besitzt exklusiv die Handelsvertretung für eine belgische Schaufensterpuppen-Firma.“"
        },
        {
          "num": 10,
          "stem": "Schaufensterpuppen",
          "options": {
            "a": "können mit umweltfreundlichen Farben bemalt werden.",
            "b": "sind nicht von Tendenzen der Mode abhängig.",
            "c": "sollen immer die gleichen Maße haben."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz wird beschrieben, dass er gemeinsam mit einem Farblieferanten „eine Farbe für Puppen entwickelt [hat], die nicht nur ökologisch einwandfrei, sondern auch für den Menschen unbedenklich ist“."
        }
      ]
    },
    {
      "id": "15a",
      "title": "Test 15a – Schaufensterpuppe (Variante)",
      "isVariant": true,
      "paragraphs": [
        "Der Puppenmacher: Die Schaufensterpuppe ist eine Pariserin und hatte erstmals 1849 in der Hauptstadt der Mode ihren Auftritt. Der französische Schneider Alexis Lavigne gilt als ihr Erfinder, auch wenn er damals seine Kleiderkreationen noch auf einer Schneiderpuppe vorführte. Bald schon taten es ihm andere Pariser Kollegen gleich: Sie begannen ihre Modelle vor den Geschäften aufzustellen, um die Passanten in die Verkaufsräume zu locken. Als Anfang des 20. Jahrhunderts die ersten großen Kaufhäuser eröffneten, erlebte die Schaufensterpuppe ihren Durchbruch. Der Puppenmacher Lester Gaba entwickelte in den 1930er Jahren das erste lebensecht wirkende Modell Cynthia. Sie durfte sogar mit auf Veranstaltungen, was beide berühmt machte. Fortan spiegelte die Schaufensterpuppe Zeitgeist und Schönheitsideale.",
        "Der Linzer Puppenmacher André Bauernfeind hat als Sammler begonnen, mittlerweile sind Schaufensterpuppen sein Beruf. Der 37-Jährige, der mehr als 1000 Modelle besitzt, ist österreichweit der Einzige, bei dem man sie reparieren lassen, aber auch mieten kann. Wer ihn an seinem Arbeitsplatz aufsucht, muss in den Keller. Die Eisentür steht offen, ein Blick in sein großes Atelier voller Schaufensterpuppen: Kinder, Frauen und Männer mit Perücke, geschminkt oder farblos, sitzend, liegend, dürr oder mollig, in Kisten verpackt oder in Einzelteilen von der Decke hängend. Während sich die Puppen in der Welt draußen perfekt präsentieren, wird hier in der Werkstatt mitunter ordentlich an ihrer Oberfläche gekratzt. Der 37-Jährige ist so etwas wie ein Schönheitschirurg für Schaufensterpuppen: Er macht sie wieder heil, verpasst ihnen aber auch Ganzkörper-Liftings, wenn gewünscht. Die bestehende Farbe wird dann entfernt, anschließend eine Grundierung und Farbe aufgetragen. Er klebt ihnen falsche Wimpern an und trägt mit einem Pinsel Schminke auf. Die Kosmetikprodukte kommen meistens aus der Drogerie, tragen aber manchmal auch Luxusnamen wie Armani oder Dior. Nur herkömmlichen Nagellack kann Bauernfeind nicht verwenden, weil dieser die Ölfarbe auflöst. Nicht selten fehlt den Puppen ein Finger, ein Ohr oder eine Nase. Dann greift der Linzer zur Modelliermasse, deren Zusammensetzung streng geheim ist. Weniger geheim sind die Preise: Für 45 Euro fertigt er eine neue Nase, rekonstruiert ein Ohr oder auch ein Kinn. Wer allerdings einen Kopf modellieren lassen möchte, muss mit 2500 Euro und acht Wochen rechnen, für einen gesamten Körper mit 15.000 Euro und Monaten.",
        "Obgleich er als Kind am liebsten mit Autos spielte, faszinierten ihn schon früh diese Mannequins in den Schaufenstern. Heute kommt er an keinem Schaufenster vorbei, ohne einen Blick hineinzuwerfen. „Ich erkenne schon an ihrem Standsockel, um welchen Hersteller es sich handelt“, sagt der gelernte Dekorateur. Sein erstes Exemplar kaufte er während seiner Ausbildung. 3500 Schilling wollte der Besitzer haben, man einigte sich auf Ratenzahlungen. Ein Jahr lang hat er sie abbezahlt. Die Puppe aus der Serie Ragazza mit der Nummer 9908 bekam bald Gesellschaft, die Sammlung vergrößerte sich sukzessive, zählte schon bald mehr als 100 Exponate. Aus dem Hobby wurde später ein Beruf. Bauernfeind verfeinerte sein Handwerk und übernahm schließlich ein altes Schaufensterpuppen-Unternehmen in Linz. Heute ist er Besitzer von 1200 Puppen, vermietet und repariert sie, stellt Sonderanfertigungen her. Bauernfeind verkauft auch für andere Hersteller. Er besitzt exklusiv die Handelsvertretung für eine belgische Schaufensterpuppen-Firma.",
        "Alle anderen renommierten Hersteller aus Europa haben irgendwann ihre Produktion nach Asien verlagert. Qualität und Nachhaltigkeit sind ihm wichtig. Gemeinsam mit einem Farblieferanten hat er deshalb eine Farbe für Puppen entwickelt, die nicht nur ökologisch einwandfrei, sondern auch für den Menschen unbedenklich ist. Schließlich dringen die Farbstoffe in die Textilien ein. „Meine Farbe könnte man sogar essen, und es würde nichts passieren.“ Weltweit gibt es etwa 100 Hersteller von Schaufensterpuppen, die zweimal im Jahr eine neue Kollektion herausbringen. Denn wie die Mode sind auch die Puppen Trends unterworfen. „In Frankreich, England und den USA werden natürliche Modelle immer beliebter, während bei uns noch abstrakte Modelle dominieren. Es lässt sich aber beobachten, dass man von einer Einheitsfigur wegkommt und dass immer häufiger vielfältige Figurtypen gewünscht werden“, sagt der Puppenmacher."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die erste Schaufensterpuppe wurde",
          "options": {
            "a": "von einem französischen Schneider erfunden.",
            "b": "für die ersten großen Kaufhäuser produziert.",
            "c": "Anfang des 20. Jahrhunderts von einem Puppenmacher erschaffen."
          },
          "answer": "a",
          "explanation": "Laut Text gilt der französische Schneider Alexis Lavigne (1849 in Paris) als Erfinder der Schaufensterpuppe."
        },
        {
          "num": 7,
          "stem": "Bei der Restaurierung der Schaufensterpuppen",
          "options": {
            "a": "verwendet Herr Bauernfeind billige Produkte.",
            "b": "können keine Luxusmarken eingesetzt werden.",
            "c": "darf er keinen normalen Nagellack auftragen."
          },
          "answer": "c",
          "explanation": "Herkömmlichen Nagellack kann Bauernfeind nicht verwenden, da dieser die Ölfarbe der Puppen auflöst."
        },
        {
          "num": 8,
          "stem": "Der Puppenmacher",
          "options": {
            "a": "organisierte eine Ausstellung mit Schaufensterpuppen.",
            "b": "konnte seine erste Schaufensterpuppe nicht auf einmal zahlen.",
            "c": "hat schon als Kind gerne mit Puppen gespielt."
          },
          "answer": "b",
          "explanation": "Seine erste Puppe kaufte er während seiner Ausbildung für 3500 Schilling auf Ratenzahlung und zahlte sie ein Jahr lang ab."
        },
        {
          "num": 9,
          "stem": "Herr Bauernfeind",
          "options": {
            "a": "stellt heute keine Schaufensterpuppen mehr her.",
            "b": "handelt mit Schaufensterpuppen anderer Produzenten.",
            "c": "eröffnete die erste Linzer Firma für Schaufensterpuppen."
          },
          "answer": "b",
          "explanation": "Er übernahm ein altes Unternehmen in Linz, stellt Sonderanfertigungen her und „verkauft auch für andere Hersteller“ (u. a. als exklusive Handelsvertretung einer belgischen Firma)."
        },
        {
          "num": 10,
          "stem": "Schaufensterpuppen",
          "options": {
            "a": "sollen immer dieselbe Kleidergröße haben.",
            "b": "sind nicht von Tendenzen der Mode abhängig.",
            "c": "können mit umweltfreundlichen Farben bemalt werden."
          },
          "answer": "c",
          "explanation": "Gemeinsam mit einem Farblieferanten hat Bauernfeind eine ökologisch einwandfreie und für den Menschen unbedenkliche Puppenfarbe entwickelt."
        }
      ]
    },
    {
      "id": "16",
      "title": "Test 16 – Mehrsprachige Erziehung",
      "isVariant": false,
      "paragraphs": [
        "Für viele Eltern sind Fremdsprachenkenntnisse die Basis einer ordentlichen Karriere für ihre Kinder. Aus entwicklungspsychologischer Sicht bringt die Mehrsprachigkeit im Kindesalter tatsächlich einige Vorteile mit sich: „Mehrsprachig erzogene Kinder lernen später auch andere Fremdsprachen leichter, weil sie schon früh ein Gefühl für die Systematik hinter einer Sprache entwickeln“, sagt Susanne Hilt, Psychologin für Sprachförderung in Neustadt. Außerdem falle es ihnen leichter, Dinge mit anderen Augen zu sehen und kreativ auf ihren Alltag zu reagieren. Auch die kommunikative Kompetenz ist laut Hilt bei mehrsprachig erzogenen Kindern meist ausgeprägter.",
        "Doch nicht jeder Sprachimpuls in der Kindheit ist positiv. Die gebürtige Schweizerin Hilt hat ihre eigenen Kinder dreisprachig erzogen. Sie ist sich sicher: „Die mehrsprachige Erziehung funktioniert nur dann, wenn das Kind eine emotionale Bindung zur jeweiligen Sprache aufbauen kann“. Sie rät daher Eltern, sich ehrlich zu fragen, welche Sprache ihnen selbst am ehesten liegt. Denn wer sich in der Fremdsprache nicht wohlfühle, könne sie auch nicht authentisch vermitteln.",
        "Die Expertin Hilt ist daher skeptisch, wenn Eltern ihre Kinder aus rein intellektuellen Gründen mehrsprachig erziehen möchten. „Schulische Erfolge sollten nicht der Hauptbeweggrund für die Multilingualität sein. Es ist viel wichtiger, dass die Sprache für das Kind emotional und sozial relevant ist“. So könnten zum Beispiel die Herkunft der Eltern, eine Tante in Frankreich oder eine fremdsprachige Erzieherin eine Basis bilden, durch die Kinder auch kulturell den Bezug zu einer weiteren Sprache finden.",
        "Der Kontakt mit einer zweiten oder dritten Sprache muss nach Auffassung von Hilt nicht unbedingt schon im Babyalter erfolgen. Man kann mit der mehrsprachigen Erziehung auch erst im Kindergartenalter beginnen. „Das Zeitfenster, in dem ein Kind eine Sprache noch durch zweisprachige Erziehung erlernen kann, ist nicht genau festlegbar. Aber ungefähr bis zum zehnten Lebensjahr sind die Chancen sehr gut“, sagt die Psychologin.",
        "Auch Sabine Füllgrabe-Amling, Leiterin einer deutsch-englischen Kindertagesstätte in Hamburg, sieht den Einstieg in die Multilingualität entspannt. In Hamburg gibt es in jeder Gruppe einen deutschen und einen englischen Muttersprachler unter den Erziehern, jeder wendet seine Sprache ganz selbstverständlich im Umgang mit den Kindern an. „Die meisten unserer Kinder nehmen die neue Sprache sehr gut an, weil sie eine starke emotionale Bindung zu den Erziehern haben“, sagt Füllgrabe-Amling. Sie rät Eltern, die mehrsprachige Erziehung ihrer Kinder ebenfalls wie selbstverständlich in den Alltag zu integrieren. „Es bringt nichts, wenn man zu Kindern sagt: ‚Wiederhol das mal‘ oder ‚Schau, Stuhl heißt auf Englisch chair‘. Auch der Erwerb der Muttersprache funktioniert ja nicht auf diese Art“, sagt Füllgrabe-Amling. Die neue Sprache sollte ganz locker immer wieder auftauchen, so dass das Kind sie langsam annehmen kann. „Am besten ist es, wenn eine bestimmte Bezugsperson sich immer nur in der anderen Sprache mit dem Kind unterhält“, sagt Füllgrabe-Amling.",
        "Susanne Hilt hält auch andere Methoden für sinnvoll. „Jeder muss da sein eigenes System entwickeln“, sagt die Psychologin. Es sei auch denkbar, dass beispielsweise die kroatische Mutter mit ihrem Kind zu Hause immer nur Kroatisch spreche, unterwegs aber Deutsch. „Wichtig ist, dass eine Regelmäßigkeit für das Kind und für die Eltern erkennbar ist“, sagt Hilt.",
        "Eine Sprachverwirrung durch die Multilingualität oder gar eine Verzögerung in der Entwicklung des Kindes müssen Eltern nicht befürchten, meint Hilt. „Auch wenn der Kontakt mit der anderen Sprache nur alle paar Tage stattfindet, wird das Kind keinen Schaden nehmen. Auch diese kleinen Impulse können zumindest das Interesse für weitere Sprachen fördern“."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Mehrsprachig erzogene Kinder sind meist",
          "options": {
            "a": "kommunikativer.",
            "b": "ideenreicher.",
            "c": "sensibler."
          },
          "answer": "a",
          "explanation": "Im ersten Absatz heißt es wörtlich: „Auch die kommunikative Kompetenz ist laut Hilt bei mehrsprachig erzogenen Kindern meist ausgeprägter.“"
        },
        {
          "num": 7,
          "stem": "Mehrsprachige Erziehung gelingt, wenn",
          "options": {
            "a": "das Kind einen emotionalen Bezug zur Sprache hat.",
            "b": "die Eltern aus dem Zielsprachenland kommen.",
            "c": "die Eltern die Bildungsziele konsequent verfolgen."
          },
          "answer": "a",
          "explanation": "Susanne Hilt betont im zweiten Absatz: „Die mehrsprachige Erziehung funktioniert nur dann, wenn das Kind eine emotionale Bindung zur jeweiligen Sprache aufbauen kann.“"
        },
        {
          "num": 8,
          "stem": "Damit ein Kind eine weitere Sprache zweisprachig erlernt,",
          "options": {
            "a": "muss die Sprachvermittlung so früh wie möglich anfangen.",
            "b": "reicht es, im Grundschulalter mit der Zweitsprache zu beginnen.",
            "c": "sollte im Kindergarten mit der Sprachvermittlung begonnen werden."
          },
          "answer": "c",
          "explanation": "Laut Vorlage ist c markiert („Man kann mit der mehrsprachigen Erziehung auch erst im Kindergartenalter beginnen“); im Text wird zudem erläutert, dass die Chancen bis ungefähr zum zehnten Lebensjahr (Grundschulalter) sehr gut sind."
        },
        {
          "num": 9,
          "stem": "Wechselt die Bezugsperson zwischen zwei Sprachen, lernt das Kind die Zweitsprache",
          "options": {
            "a": "bei systematischer Vermittlung der Sprache.",
            "b": "sofern es versteht, wann die Sprachen gewechselt werden.",
            "c": "wahrscheinlich nicht."
          },
          "answer": "a",
          "explanation": "In der Vorlage ist a markiert („Jeder muss da sein eigenes System entwickeln“); entscheidend ist laut Susanne Hilt, „dass eine Regelmäßigkeit für das Kind und für die Eltern erkennbar ist“ (vgl. Option b)."
        },
        {
          "num": 10,
          "stem": "Sollten Kinder nur alle paar Tage Kontakt zur Zweitsprache haben,",
          "options": {
            "a": "ist eine Entwicklungsverzögerung möglich.",
            "b": "kann das Interesse an anderen Sprachen verloren gehen.",
            "c": "schadet dies der Entwicklung der Zweitsprache nicht."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz sagt Hilt: „Auch wenn der Kontakt mit der anderen Sprache nur alle paar Tage stattfindet, wird das Kind keinen Schaden nehmen. Auch diese kleinen Impulse können zumindest das Interesse für weitere Sprachen fördern.“"
        }
      ]
    },
    {
      "id": "16a",
      "title": "Test 16a – Mehrsprachige Erziehung (Variante)",
      "isVariant": true,
      "paragraphs": [
        "Für viele Eltern sind Fremdsprachenkenntnisse die Basis einer ordentlichen Karriere für ihre Kinder. Aus entwicklungspsychologischer Sicht bringt die Mehrsprachigkeit im Kindesalter tatsächlich einige Vorteile mit sich: „Mehrsprachig erzogene Kinder lernen später auch andere Fremdsprachen leichter, weil sie schon früh ein Gefühl für die Systematik hinter einer Sprache entwickeln“, sagt Susanne Hilt, Psychologin für Sprachförderung in Neustadt. Außerdem falle es ihnen leichter, Dinge mit anderen Augen zu sehen und kreativ auf ihren Alltag zu reagieren. Auch die kommunikative Kompetenz ist laut Hilt bei mehrsprachig erzogenen Kindern meist ausgeprägter.",
        "Doch nicht jeder Sprachimpuls in der Kindheit ist positiv. Die gebürtige Schweizerin Hilt hat ihre eigenen Kinder dreisprachig erzogen. Sie ist sich sicher: „Die mehrsprachige Erziehung funktioniert nur dann, wenn das Kind eine emotionale Bindung zur jeweiligen Sprache aufbauen kann“. Sie rät daher Eltern, sich ehrlich zu fragen, welche Sprache ihnen selbst am ehesten liegt. Denn wer sich in der Fremdsprache nicht wohlfühle, könne sie auch nicht authentisch vermitteln.",
        "Die Expertin Hilt ist daher skeptisch, wenn Eltern ihre Kinder aus rein intellektuellen Gründen mehrsprachig erziehen möchten. „Schulische Erfolge sollten nicht der Hauptbeweggrund für die Multilingualität sein. Es ist viel wichtiger, dass die Sprache für das Kind emotional und sozial relevant ist“. So könnten zum Beispiel die Herkunft der Eltern, eine Tante in Frankreich oder eine fremdsprachige Erzieherin eine Basis bilden, durch die Kinder auch kulturell den Bezug zu einer weiteren Sprache finden.",
        "Der Kontakt mit einer zweiten oder dritten Sprache muss nach Auffassung von Hilt nicht unbedingt schon im Babyalter erfolgen. Man kann mit der mehrsprachigen Erziehung auch erst im Kindergartenalter beginnen. „Das Zeitfenster, in dem ein Kind eine Sprache noch durch zweisprachige Erziehung erlernen kann, ist nicht genau festlegbar. Aber ungefähr bis zum zehnten Lebensjahr sind die Chancen sehr gut“, sagt die Psychologin.",
        "Auch Sabine Füllgrabe-Amling, Leiterin einer deutsch-englischen Kindertagesstätte in Hamburg, sieht den Einstieg in die Multilingualität entspannt. In Hamburg gibt es in jeder Gruppe einen deutschen und einen englischen Muttersprachler unter den Erziehern, jeder wendet seine Sprache ganz selbstverständlich im Umgang mit den Kindern an. „Die meisten unserer Kinder nehmen die neue Sprache sehr gut an, weil sie eine starke emotionale Bindung zu den Erziehern haben“, sagt Füllgrabe-Amling. Sie rät Eltern, die mehrsprachige Erziehung ihrer Kinder ebenfalls wie selbstverständlich in den Alltag zu integrieren. „Es bringt nichts, wenn man zu Kindern sagt: ‚Wiederhol das mal‘ oder ‚Schau, Stuhl heißt auf Englisch chair‘. Auch der Erwerb der Muttersprache funktioniert ja nicht auf diese Art“, sagt Füllgrabe-Amling. Die neue Sprache sollte ganz locker immer wieder auftauchen, so dass das Kind sie langsam annehmen kann. „Am besten ist es, wenn eine bestimmte Bezugsperson sich immer nur in der anderen Sprache mit dem Kind unterhält“, sagt Füllgrabe-Amling.",
        "Susanne Hilt hält auch andere Methoden für sinnvoll. „Jeder muss da sein eigenes System entwickeln“, sagt die Psychologin. Es sei auch denkbar, dass beispielsweise die kroatische Mutter mit ihrem Kind zu Hause immer nur Kroatisch spreche, unterwegs aber Deutsch. „Wichtig ist, dass eine Regelmäßigkeit für das Kind und für die Eltern erkennbar ist“, sagt Hilt.",
        "Eine Sprachverwirrung durch die Multilingualität oder gar eine Verzögerung in der Entwicklung des Kindes müssen Eltern nicht befürchten, meint Hilt. „Auch wenn der Kontakt mit der anderen Sprache nur alle paar Tage stattfindet, wird das Kind keinen Schaden nehmen. Auch diese kleinen Impulse können zumindest das Interesse für weitere Sprachen fördern“."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Psychologin meint, dass mehrsprachig erzogene Kinder",
          "options": {
            "a": "häufig mit dem Erlernen mehrerer Sprachen überfordert sind.",
            "b": "kommunizieren, ohne die Regelwerke der Sprachen zu durchschauen.",
            "c": "mehr Offenheit und Flexibilität in ihrem Verhalten zeigen."
          },
          "answer": "c",
          "explanation": "Im ersten Absatz heißt es, es falle mehrsprachig erzogenen Kindern leichter, „Dinge mit anderen Augen zu sehen und kreativ auf ihren Alltag zu reagieren“."
        },
        {
          "num": 7,
          "stem": "Susanne Hilt",
          "options": {
            "a": "äußert Kritik an bestimmten Erziehungsabsichten der Eltern.",
            "b": "ist davon überzeugt, dass mehrsprachige Erziehung in jedem Fall Erfolg bringt.",
            "c": "meint, dass man Mehrsprachigkeit nur durch Kontakte zu Muttersprachlern erreichen kann."
          },
          "answer": "a",
          "explanation": "Im dritten Absatz steht: „Die Expertin Hilt ist daher skeptisch, wenn Eltern ihre Kinder aus rein intellektuellen Gründen mehrsprachig erziehen möchten. ‚Schulische Erfolge sollten nicht der Hauptbeweggrund für die Multilingualität sein.‘“"
        },
        {
          "num": 8,
          "stem": "Damit ein Kind mehrsprachig aufwächst,",
          "options": {
            "a": "muss die Sprachvermittlung so früh wie möglich anfangen.",
            "b": "reicht es, im Grundschulalter mit der Zweitsprache zu beginnen.",
            "c": "sollte unbedingt im Kindergarten mit der Sprachvermittlung begonnen werden."
          },
          "answer": "b",
          "explanation": "Laut Psychologin Hilt ist das Zeitfenster nicht genau festlegbar, „aber ungefähr bis zum zehnten Lebensjahr [also im Grundschulalter] sind die Chancen sehr gut“."
        },
        {
          "num": 9,
          "stem": "Mehrsprachige Erziehung gelingt, wenn",
          "options": {
            "a": "der Sprachunterricht konsequent durchgeführt wird.",
            "b": "die Sprachen spontan variiert werden.",
            "c": "man die zweite oder dritte Sprache wiederholt und ungezwungen spricht."
          },
          "answer": "c",
          "explanation": "Im fünften Absatz rät Füllgrabe-Amling, die Sprache wie selbstverständlich in den Alltag zu integrieren: „Die neue Sprache sollte ganz locker immer wieder auftauchen, so dass das Kind sie langsam annehmen kann.“"
        },
        {
          "num": 10,
          "stem": "Sollten Kinder nur ab und zu Kontakt zur Zweitsprache haben,",
          "options": {
            "a": "kann dies zu großen Unsicherheiten bei der Sprachverwendung führen.",
            "b": "könnte es zu einer Störung der Sprachentwicklung kommen.",
            "c": "wird auf jeden Fall eine Neigung zum Sprachlernen bestehen bleiben."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz betont Hilt: „Auch wenn der Kontakt mit der anderen Sprache nur alle paar Tage stattfindet, wird das Kind keinen Schaden nehmen. Auch diese kleinen Impulse können zumindest das Interesse für weitere Sprachen fördern.“"
        }
      ]
    },
    {
      "id": "17",
      "title": "Test 17 – Gesundes Essen für Schulkinder",
      "isVariant": false,
      "paragraphs": [
        "Für Kinder sind regelmäßige Mahlzeiten wichtig, um volle Konzentrations- und Leistungsfähigkeit zu gewährleisten. Um gut in den Tag zu kommen, sollte jedes Schulkind mit einem ausgewogenen Frühstück starten. Aber eine Umfrage kam zu erschreckenden Ergebnissen: Jedes siebte Kind isst morgens nichts, bevor es in die Schule geht. Die Gründe dafür sind vielfältig: Jeder vierte Befragte gab an, dass sein Kind morgens keinen Appetit habe. Und sogar jede dritte Mutter und jeder dritte Vater sagten, dass morgens keine Zeit für Frühstück sei. Für eine gesunde Morgenmahlzeit sollte man jedoch immer Zeit freischaufeln, rät Ernährungswissenschaftlerin Alexandra Krotz.",
        "Mit leerem Magen können Körper und Geist keine Leistung erbringen. Die Folge: Die Kinder sind reizbar, nervös und können sich nicht richtig konzentrieren. Und das ist schon auf dem Schulweg wichtig: Kinder bewegen sich sicherer, wenn sie rechtzeitig aufgestanden sind und entspannt gefrühstückt haben. Zu einem gesunden Frühstück eignen sich am besten Vollkornbrote mit fettarmer Wurst oder Käse, aber auch Müslis mit Milch oder Joghurt, Nüssen und frisches Obst. Wer morgens keinen Hunger hat, sollte wenigstens eine Kleinigkeit zu sich nehmen – etwa eine Banane essen und dazu einen Kakao trinken – und das ausgiebige Frühstück dann etwas später nachholen. In einigen Schulen wird gemeinsam gefrühstückt. Hier gilt es, je nach Vereinbarung mit Erziehern und Lehrern, ein leckeres Frühstück zusammenzustellen.",
        "Wer seinen Kindern ein zweites Frühstück einpackt, sollte auf Abwechslung und die geeignete Verpackung achten. Am besten eignet sich eine Brotdose – die spart Verpackungsmüll und vermeidet zermatschte Brote. Zudem lassen sich darin auch Obst und Gemüse sicher transportieren. Eine gute Ergänzung zu lecker belegten Vollkornbroten ist Rohkost. Dazu eignen sich besonders transportsichere feste Sorten wie Möhren, Kohlrabi, Cherrytomaten, Trauben oder Äpfel. Je nach Jahreszeit und Vorliebe der Kinder können Sie als Eltern hierbei für Abwechslung sorgen.",
        "Heutzutage wird Schulmilch leider nicht mehr in allen Schulen angeboten. Schade, denn Milch liefert wichtiges Calcium, Eiweiß und viele B-Vitamine. Wer als Kind die Möglichkeit hat, in der Schule Milch zu trinken, sollte darauf nicht verzichten. Und selbst Milchmuffel dürften zufrieden sein: Da Milch in vielen Varianten angeboten wird – von Erdbeermilch über Kakao zu Vanillemilch –, ist für jedes Kind das Richtige dabei.",
        "Generell ist der Wasserbedarf von Kindern im Verhältnis zum Körpergewicht höher als bei Erwachsenen. Trinken Kinder zu wenig, beeinträchtigt dies schneller die körperliche und geistige Leistungsfähigkeit. Kinder sollten deshalb je nach Alter mindestens 0,7 Liter bis 1,2 Liter trinken – Milch nicht mitgerechnet. Wenn das Kind viel Sport treibt oder tobt und bei besonders warmen Tagen brauchen die Kinder entsprechend mehr Flüssigkeit. Viele Kinder trinken zu wenig. Häufig vergessen sie ganz einfach zu trinken, wenn sie konzentriert spielen oder lernen. Ganz wichtig ist es daher, Kinder immer mal wieder zum Trinken aufzufordern und auch zwischen den Mahlzeiten den Durst zu löschen, auch während der Unterrichtsstunden. Am besten sind Wasser, Kräutertees und Saftschorlen geeignet. Übrigens: Fast ein Viertel aller Schüler in Deutschland trinkt vormittags nichts oder fast nichts. Das hat eine Untersuchung der Universität Paderborn zum Trinkverhalten vor und während der Unterrichtszeit ergeben. Die unzureichende Flüssigkeitsaufnahme führte dabei nachweislich zu Einschränkungen der geistigen und körperlichen Leistungsfähigkeit.",
        "Kinder mögen Süßes. Schokoriegel und Süßigkeiten sollten allerdings beim Pausenbrot nicht die Regel sein. Eine gute Alternative dazu sind Trockenfrüchte, Fruchtschnitten oder Studentenfutter. Sie liefern wichtige Vitamine und Mineralstoffe und sind als Energieschub zwischendurch geeignet. Aber Vorsicht: Sie enthalten auch viel Energie und sollten gerade von Kindern, die leichtes Übergewicht haben, nur in geringen Mengen gegessen werden.",
        "Viele Eltern nehmen sich morgens nicht die Zeit, mit ihren Kindern zu frühstücken, und geben ihnen lieber Geld mit, damit sie sich auf dem Schulweg ein Frühstück kaufen können. Versuchen Sie, das zu vermeiden. Denn die meisten Kinder legen das Geld in Süßwaren oder Fast Food, Cola oder andere Süßgetränke an. Die Mittagsverpflegung in Schulen kann sehr unterschiedlich sein. Ein weiteres Pausenbrot wäre jedenfalls eine Zumutung für die Kinder. Deshalb gibt es verschiedene Systeme für die Versorgung am Mittag – Catering, kochende Eltern oder Profi-Küchen mit geschultem Personal. Klar ist: Für die Kinder sind Pausen und regelmäßige Mahlzeiten zur Aufrechterhaltung ihrer Leistungsfähigkeit wichtig. Daher sollte es im Interesse aller sein, den Kindern in der Schule eine geeignete Mittagsverpflegung zur Verfügung zu stellen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Einige Eltern",
          "options": {
            "a": "haben selbst keinen Appetit auf ein Frühstück.",
            "b": "lassen das Frühstück aus Zeitmangel ausfallen.",
            "c": "schaufeln das Frühstück einfach in sich hinein."
          },
          "answer": "b",
          "explanation": "Im ersten Absatz heißt es: „Und sogar jede dritte Mutter und jeder dritte Vater sagten, dass morgens keine Zeit für Frühstück sei.“"
        },
        {
          "num": 7,
          "stem": "Ein gesundes Frühstück",
          "options": {
            "a": "erhöht auch die Sicherheit des Kindes auf dem Weg zur Schule.",
            "b": "muss mindestens aus einem Glas Kakao oder Milch bestehen.",
            "c": "sollte gemeinsam in der Schule eingenommen werden."
          },
          "answer": "a",
          "explanation": "Im zweiten Absatz steht: „Und das ist schon auf dem Schulweg wichtig: Kinder bewegen sich sicherer, wenn sie rechtzeitig aufgestanden sind und entspannt gefrühstückt haben.“"
        },
        {
          "num": 8,
          "stem": "Milch",
          "options": {
            "a": "deckt den täglichen Flüssigkeitsbedarf.",
            "b": "gehört zum Angebot der Schulkantinen.",
            "c": "wird in verschiedenen Geschmacksrichtungen angeboten."
          },
          "answer": "c",
          "explanation": "Im vierten Absatz wird erklärt: „Da Milch in vielen Varianten angeboten wird – von Erdbeermilch über Kakao zu Vanillemilch –, ist für jedes Kind das Richtige dabei.“"
        },
        {
          "num": 9,
          "stem": "Kinder",
          "options": {
            "a": "denken von alleine nicht immer daran, genug zu trinken.",
            "b": "dürfen während des Unterrichts nichts trinken.",
            "c": "können sich auch noch gut konzentrieren, wenn sie nicht genug getrunken haben."
          },
          "answer": "a",
          "explanation": "Im fünften Absatz heißt es: „Viele Kinder trinken zu wenig. Häufig vergessen sie ganz einfach zu trinken, wenn sie konzentriert spielen oder lernen.“"
        },
        {
          "num": 10,
          "stem": "Mittagessen",
          "options": {
            "a": "sollte in der Schule angeboten werden.",
            "b": "sollten die Kinder von zu Hause mitbringen.",
            "c": "sollten Kinder bei den Eltern zu Hause bekommen."
          },
          "answer": "a",
          "explanation": "Am Ende des Textes steht: „Ein weiteres Pausenbrot wäre jedenfalls eine Zumutung für die Kinder. ... Daher sollte es im Interesse aller sein, den Kindern in der Schule eine geeignete Mittagsverpflegung zur Verfügung zu stellen.“"
        }
      ]
    },
    {
      "id": "18",
      "title": "Test 18 – Noch ein Wasser, bitte! / Kellnern war gestern",
      "isVariant": false,
      "paragraphs": [
        "Noch ein Wasser, bitte!\nDie Semesterferien sind zu Ende und diese Woche beginnt an der Universität das Sommersemester. Aber nicht nur Vorlesungen und Seminare gehen wieder los. 73 Prozent der Berliner Studenten müssen neben dem Studium auch noch Geld verdienen.",
        "Ein beliebter Studentenjob ist der des Kellners. Denn erstens arbeitet man meist am Abend, so dass es keine Terminkollisionen mit den Vorlesungs- und Seminarprogrammen gibt. Zweitens findet man leicht einen Job, da es in der Nähe von Universitäten häufig viele Cafés und Kneipen gibt, die sehr gut besucht sind. Und je mehr Gäste, desto höher natürlich die Chancen auf Trinkgelder. Das ist auch wichtig, denn nur so kommt man auf einen akzeptablen Stundenlohn. Allerdings ist es in manchen Restaurants auch üblich, dass die Trinkgelder gesammelt und am Ende dann an alle Kellner gleichmäßig verteilt werden. Davon profitieren dann auch diejenigen, die nicht so engagiert und motiviert arbeiten.",
        "Als Kellner braucht man starke Nerven, denn der Gast hat immer recht. Manche Gäste machen es einem Kellner mit zahlreichen Beschwerden und Extrawünschen wirklich nicht leicht. Denn der Kellner ist die Person, die direkt mit dem Gast in Kontakt kommt. Wenn das Essen nicht schmeckt, kalt ist oder nicht schnell genug zubereitet wird, bekommt der Kellner den Unmut der Gäste zu spüren, obwohl die „Schuld“ beim Koch liegt. Wer ist für den Job als Kellner geeignet? Man sollte offen sein und den Kontakt mit Menschen mögen und auf jeden Fall geduldig sein. Natürlich ist es wichtig, immer freundlich und zuvorkommend zu bleiben. Denn wenn der Service stimmt und der Kellner kompetent und freundlich wirkt, dann sitzt auch das Trinkgeld lockerer.",
        "Kellnern war gestern\nNeben den klassischen Studentenjobs wie Kellnern und Nachhilfe geben greifen manche aber auch zu eher ungewöhnlichen Jobs. Wie zum Beispiel Jan, der in Berlin als Fahrradkurier arbeitet, oder Stefanie, die Testkäuferin. Jan fährt im Auftrag von Apotheken, Filmverleihfirmen oder Pizzadiensten im Schnitt zwischen 50 km und 200 km pro Tag. Um diesen Job machen zu können, braucht er eine sehr gute Kondition. Denn manche Strecken sind lang, und oft gibt es Gegenwind. Er arbeitet wie die meisten Fahrradkuriere auf selbständiger Basis und kommt auf einen Stundenlohn von etwa 10 Euro. Jan meint: „Reich wird man damit zwar nicht, aber man kann sagen: Wer schnell ist und gut, verdient als Fahrradkurier nicht schlecht.“ Am liebsten würde Jan von einem Kurierdienst in einem klassischen Arbeitsverhältnis angestellt werden. Das ist in der Branche aber eher die Ausnahme. Wäre er Angestellter, würde er vom Kurierdienst ein Grundgehalt bekommen und für die gefahrenen Aufträge eine kleine Provision.",
        "Einen der größten Vorteile seines Jobs sieht Jan darin, dass er sich den ganzen Tag im Freien bewegt und so die Beiträge für das Fitnessstudio spart. Außerdem lernt man so eine Stadt sehr gut kennen. Ein Nachteil ist, dass man auch bei Wind und Wetter oder bei dichtem Verkehr fahren muss. Aber das nimmt Jan in Kauf. Denn Kellnern oder ein Büro-Job wären nichts für ihn.",
        "Der Job von Stefanie ist ein wahrer Glückstreffer: Sie darf den ganzen Tag einkaufen und wird dafür auch noch bezahlt. Stefanie arbeitet als Testkäuferin, um Beratung und Service von Verkäufern in Geschäften zu testen. Ein typischer Arbeitseinsatz sieht bei ihr so aus: Nach der letzten Vorlesung an der Uni geht sie zum Beispiel in einen Modeladen. Dort überprüft sie als Erstes den Eingang auf Sauberkeit, schlendert dann zu den Ständen mit Hosen und Blusen und schaut, ob alles ordentlich sortiert und beschildert ist. Dann spricht sie eine Verkäuferin an und sagt, dass sie eine Bluse sucht. Damit testet sie, ob sie als Kundin von der Verkäuferin angemessen beraten wird. Die Verkäuferin sollte nachfragen, für welchen Anlass und in welcher Farbe die Kundin eine Bluse sucht.",
        "Leider läuft es nicht immer so, wie er sein sollte. In 90 Prozent der Fälle gibt es Grund zur Beschwerde, weil die Verkäuferin entweder unfreundlich oder uninteressiert ist. Bevor Stefanie die Läden wieder verlässt, kommt das Beste: Sie muss etwas kaufen, um die Kasse zu testen. 20 Euro bekommt sie dafür pro Test. Außerdem darf sie das, was sie kaufen sollte, auch noch behalten."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Der Nebenjob als Kellner ...",
          "options": {
            "a": "hat an Attraktivität deutlich verloren.",
            "b": "ist insgesamt sehr gut bezahlt.",
            "c": "lässt sich gut mit dem Studium vereinbaren."
          },
          "answer": "c",
          "explanation": "Im zweiten Absatz heißt es: „Ein beliebter Studentenjob ist der des Kellners. Denn erstens arbeitet man meist am Abend, so dass es keine Terminkollisionen mit den Vorlesungs- und Seminarprogrammen gibt.“"
        },
        {
          "num": 7,
          "stem": "Wer als Kellner arbeitet, ...",
          "options": {
            "a": "muss bei Beschwerden den Kontakt zwischen Koch und Gast herstellen.",
            "b": "muss das Trinkgeld mit den Kollegen teilen.",
            "c": "sollte nicht aus der Ruhe zu bringen sein."
          },
          "answer": "c",
          "explanation": "Im dritten Absatz steht: „Als Kellner braucht man starke Nerven, denn der Gast hat immer recht“ und man sollte „auf jeden Fall geduldig sein“ sowie „immer freundlich und zuvorkommend bleiben“."
        },
        {
          "num": 8,
          "stem": "Jan arbeitet gern als Fahrradkurier, ...",
          "options": {
            "a": "weil er außer dem Grundgehalt noch eine Provision bekommt.",
            "b": "weil er dann fest angestellt ist.",
            "c": "weil er mit dem Verdienst ganz zufrieden ist."
          },
          "answer": "c",
          "explanation": "Jan arbeitet selbständig (nicht fest angestellt) und sagt über seinen Verdienst: „Reich wird man damit zwar nicht, aber man kann sagen: Wer schnell ist und gut, verdient als Fahrradkurier nicht schlecht.“"
        },
        {
          "num": 9,
          "stem": "Jan sagte, ...",
          "options": {
            "a": "dass er durch seinen Job keine Ausgaben für ein Fitnessstudio hat.",
            "b": "dass er lieber im Büro arbeiten würde.",
            "c": "dass ihn schlechtes Wetter gar nicht stört."
          },
          "answer": "a",
          "explanation": "Im fünften Absatz heißt es: „Einen der größten Vorteile seines Jobs sieht Jan darin, dass er sich den ganzen Tag im Freien bewegt und so die Beiträge für das Fitnessstudio spart.“"
        },
        {
          "num": 10,
          "stem": "Stefanie muss als Testkäuferin ...",
          "options": {
            "a": "auch den Service in Cafés und Kneipen überprüfen.",
            "b": "einige Waren selbst bezahlen.",
            "c": "sich beim Einkauf an einen festen Ablauf halten."
          },
          "answer": "c",
          "explanation": "Im sechsten Absatz wird ihr festes Vorgehen beschrieben: Als Erstes überprüft sie den Eingang auf Sauberkeit, kontrolliert dann Sortierung und Beschilderung an den Ständen, lässt sich nach bestimmten Kriterien beraten und testet abschließend die Kasse durch einen Kauf."
        }
      ]
    },
    {
      "id": "19",
      "title": "Test 19 – Weniger Euro-„Blüten“ in Deutschland und Europa",
      "isVariant": false,
      "paragraphs": [
        "Frankfurt/Main/Brüssel (dpa) – Jeder hat schon einmal von ihnen gehört: „Blüten“, ein Synonym für Falschgeld. Aber wie viel Falschgeld gibt es wirklich? Tatsächlich wurden im vergangenen Jahr weniger Euro-Scheine, aber mehr Falschmünzen in Umlauf gebracht als im vorletzten Jahr. Die Zahl des entdeckten gefälschten Papiergelds sank in Europa somit von 579 000 auf 565 000 Scheine. In Deutschland sank gegenüber der restlichen Euro-Zone die Zahl der „Blüten“ noch deutlicher. Grund dafür: Im vergangenen Jahr konnte die Polizei in mehreren europäischen Ländern Fälscherwerkstätten aufspüren und Verteilerringe zerschlagen. Dennoch ist der wirtschaftliche Schaden insgesamt gestiegen, teilte die Europäische Zentralbank in Frankfurt mit. In Deutschland zog die Polizei im vergangenen Jahr rund 46 000 „Blüten“ aus dem Verkehr, die Schadenssumme belief sich laut Bundesbank auf 3,2 Millionen Euro.",
        "Am häufigsten werden nach wie vor 20-Euro-Scheine nachgemacht, gefolgt von 50-Euro-Scheinen. Während europaweit die 20-Euro-Note der beliebteste Schein der Fälscher ist (mit 36 Prozent am gesamten Falschgeldaufkommen), ist es in Deutschland die 50-Euro-Note (mit 41 Prozent). Einen deutlichen Anstieg verzeichneten die Fahnder derzeit bei 100-Euro-„Blüten“. „Die Fälscher versuchen, auf neue Werte auszuweichen“, sagte der Bundesbank-Sprecher. Die Notenbanken forderten die Bürger daher zur erhöhten Wachsamkeit auf. Die meisten Fälschungen seien mit einfachen Tests („Fühlen-Sehen-Kippen“) jedoch leicht von echten Banknoten zu unterscheiden.",
        "Dagegen erreichte die Zahl falscher Münzen in Deutschland einen Rekordwert. Nach Angaben der EU-Kommission wurden im vergangenen Jahr 164 000 falsche Euro-Münzen entdeckt und aus dem Verkehr gezogen; das war ein Anstieg von 63 Prozent. Besonders beliebt waren bei den Fälschern 2-Euro-Stücke mit dem deutschen Adler. „Angesichts der riesigen Anzahl von 69 Milliarden Euro-Münzen ist das Falschgeld aber unbedeutend, es besteht daher kein Grund zur Beunruhigung“, stellte die EU-Behörde fest. 86 Prozent aller entdeckten falschen Münzen waren 2-Euro-Stücke. Laut Kommission werden die nachgemachten Münzen qualitativ zwar immer besser, die höhere Zahl entdeckter Falschmünzen gehe vor allem auf die verstärkten Ermittlungen von Polizei und Behörden zurück.",
        "„Die Wahrscheinlichkeit, eine gefälschte Banknote in den Händen zu halten, ist für den Bürger auf der Straße sehr gering“, sagte ein Bundesbank-Sprecher. Da insgesamt 10,6 Milliarden Banknoten in Umlauf sind, handelt es sich nur bei 6 von 100 000 Scheinen um Fälschungen. Die Mehrzahl werde außerdem nicht von Privatleuten, sondern von Kassenpersonal in Geldinstituten und Geschäften erkannt. Wer eine „Blüte“ findet, kann sie bei der Polizei oder in Bankfilialen abgeben. Einen Ersatz gibt es dafür allerdings nicht.",
        "Laut Europäischer Zentralbank werden es die Geldfälscher künftig noch schwerer haben. In den Laboren gibt es nahezu fälschungssichere Technologien – zum Beispiel einen Mikrochip, der beinahe unsichtbar in die Euro-Noten integriert werden kann. Er beinhaltet die Seriennummer und den Wert einer Banknote. Diese Daten könnten zukünftig an jeder Kasse ausgelesen und mit einer Datenbank verglichen werden. Aus der Natur stammt ein Farbstoff mit verblüffenden Eigenschaften. Wenn dieser Farbstoff beim Scannen oder Kopieren hellem Licht ausgesetzt ist, wechselt er in Bruchteilen einer Sekunde seine Farbe von Rot zu Gelb. Die Kopie unterscheidet sich also gravierend vom Original und ist ohne Hilfsmittel leicht zu erkennen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Anzahl der",
          "options": {
            "a": "entdeckten Euromünzen hat sich im letzten Kalenderjahr verdoppelt.",
            "b": "gefälschten 50-Euro-Scheine ist in Deutschland besonders hoch.",
            "c": "gefälschten Banknoten hat zugenommen."
          },
          "answer": "b",
          "explanation": "Im zweiten Absatz heißt es: „Während europaweit die 20-Euro-Note der beliebteste Schein der Fälscher ist (mit 36 Prozent am gesamten Falschgeldaufkommen), ist es in Deutschland die 50-Euro-Note (mit 41 Prozent).“"
        },
        {
          "num": 7,
          "stem": "Es werden immer mehr Falschmünzen entdeckt, weil",
          "options": {
            "a": "die Ermittler gründlicher suchen.",
            "b": "die Qualität der Falschmünzen immer schlechter wird.",
            "c": "es ein neues technisches Gerät dafür gibt."
          },
          "answer": "a",
          "explanation": "Im dritten Absatz steht: „Laut Kommission werden die nachgemachten Münzen qualitativ zwar immer besser, die höhere Zahl entdeckter Falschmünzen gehe vor allem auf die verstärkten Ermittlungen von Polizei und Behörden zurück.“"
        },
        {
          "num": 8,
          "stem": "Die meisten gefälschten Geldscheine werden",
          "options": {
            "a": "bereits bei den Fälschern gefunden.",
            "b": "von Kassierern in Banken und Läden entdeckt.",
            "c": "von Privatleuten am Geldautomaten entdeckt."
          },
          "answer": "b",
          "explanation": "Im vierten Absatz heißt es: „Die Mehrzahl werde außerdem nicht von Privatleuten, sondern von Kassenpersonal in Geldinstituten und Geschäften erkannt.“"
        },
        {
          "num": 9,
          "stem": "Man bekommt Falschgeld nur selten zu sehen, da",
          "options": {
            "a": "das Geld oft nur in Banktresoren liegt.",
            "b": "die Fälscher mit Kassierern in Geschäften zusammenarbeiten.",
            "c": "die Wahrscheinlichkeit sehr niedrig ist."
          },
          "answer": "c",
          "explanation": "Im vierten Absatz sagt ein Bundesbank-Sprecher: „Die Wahrscheinlichkeit, eine gefälschte Banknote in den Händen zu halten, ist für den Bürger auf der Straße sehr gering“ (nur 6 von 100 000 Scheinen)."
        },
        {
          "num": 10,
          "stem": "Künftig wird die Herstellung von Falschgeld noch schwieriger, weil",
          "options": {
            "a": "an den Ladenkassen alle Scheine gescannt werden.",
            "b": "beim Druck Farben verwendet werden, die man nicht kopieren kann.",
            "c": "Münzen mit Mikrochips versehen werden."
          },
          "answer": "b",
          "explanation": "Im letzten Absatz wird ein spezieller Farbstoff beschrieben: „Wenn dieser Farbstoff beim Scannen oder Kopieren hellem Licht ausgesetzt ist, wechselt er in Bruchteilen einer Sekunde seine Farbe von Rot zu Gelb. Die Kopie unterscheidet sich also gravierend vom Original...“"
        }
      ]
    },
    {
      "id": "20",
      "title": "Test 20 – Korbjagd zu Pferde",
      "isVariant": false,
      "paragraphs": [
        "„Basketball“ zu Pferde: Horse-Ball ist wohl eine der exotischsten – und jüngsten – Reitsportarten. Ein Zentrum des ungewöhnlichen Mannschaftssports: das Hofgut Adamstal in Wiesbaden. (von Rolf Lehmann)",
        "Wer sich unter dem zweimal pro Woche stattfindenden Training auf dem Wiesbadener Hofgut Adamstal eine Art „Kuschelrunde“ vorgestellt hatte, der wird schnell eines Besseren belehrt, und der neugierige Betrachter fühlt sich eher auf einen Fußballplatz als in eine Reithalle versetzt. Die festliegenden Spielzüge, die es einzustudieren gilt, sind Bestandteil einer Sportart, die hierzulande allenfalls eine Randerscheinung ist: Horse-Ball.",
        "„Es kommen immer mehr Aktive dazu“, versichert jedoch Hans-Jürgen Faust (59), Hausherr auf Hofgut Adamstal und Präsident des Deutschen Horse-Ball-Verbandes. Irgendwo in Hagen, Düsseldorf, München oder Heidelberg soll es noch ein paar vereinzelte Akteure geben, das eigentliche Geschehen aber spielt sich hier ab, wo einer der wohl kleinsten Sportverbände Deutschlands vor 15 Jahren aus der Taufe gehoben wurde und wo die erste Mannschaft der Reitergruppe Wiesbaden (RGW) identisch ist mit der National-Auswahl. Aber diesen Sport betreiben nicht nur Erwachsene: Die jüngsten Spieler sind nicht älter als acht. Horse-Ball ist – vereinfacht gesagt – eine Art Basketball zu Pferde.",
        "An den beiden Enden des zirka 25 mal 70 Meter großen Spielfeldes sind die Korbringe nicht waagerecht, sondern senkrecht ausgerichtet und mit Fangnetzen versehen, in denen die Bälle nach einem gelungenen Spielzug landen. Keine leichte Aufgabe, wie die bereits erwähnten ersten Trainingseindrücke zeigen, aber Übung macht eben auch hier den Meister. Zumindest auf nationaler, sprich: Wiesbadener Ebene.",
        "Darüber hinaus gilt es, immer wieder Lehrgeld zu zahlen, vor allem bei Gastspielen im Heimatland Frankreich, wo Horse-Ball vor rund 25 Jahren erfunden wurde und einen viel höheren Stellenwert als hierzulande genießt. Sogar eine eigene Profiliga gibt es bei unseren südwestlichen Nachbarn, die bei den Mitte August anstehenden Europameisterschaften einmal mehr nicht nur Gastgeber, sondern auch wieder Anwärter auf den Titel sind.",
        "Wer es übrigens selbst einmal ausprobieren möchte: Im kommenden Monat bieten die Wiesbaden Buffalos für maximal zwölf Teilnehmer einen Einstiegs-Lehrgang an. Dabei mitzubringen sind reiterliche Grundkenntnisse und ein so genannter Dreipunkt-Helm. Alles andere wird – inklusive Vierbeiner – bei Bedarf gestellt. „Natürlich können auch eigene Pferde mitgebracht werden“, sagt Faust.",
        "Die Tiere müssen „sozialverträglich“ sein, erläutert der 59-Jährige, und das nicht nur im Umgang mit dem Reiter, sondern vor allem untereinander. „Im richtigen Wettkampf kann es auch schon mal zu Zusammenstößen kommen“, weiß Faust, für den Horse-Ball zu einem ganz persönlichen „Steckenpferd“ geworden ist, das in der vielfältigen Angebotspalette des riesigen Hofguts eine Art Sonderstatus einnimmt.",
        "Damit es trotz unvermeidlichen Körperkontakts kaum einmal zu ernsthaften Verletzungen kommt, tragen nicht nur die Pferde vorgeschriebene Bandagen an den Beinen, sondern auch für die Reiter gibt es eine spezielle Vorrichtung: Ein Gurt, der unter dem Bauch der Tiere die beiden Steigbügel miteinander verbindet, gewährt selbst dann noch sicheren Halt, wenn sich der Spieler aus vollem Galopp heraus aus dem Sattel fallen lässt, um den Ball vom Boden aufnehmen zu können. Um die Handhabung dabei ein wenig zu vereinfachen, ist das runde Leder mit Fangriemen versehen, die ein sicheres Zugreifen auch mit einer Hand ermöglichen.",
        "Aber noch eine Besonderheit weist Horse-Ball auf: Es ist die einzige Pferdesportart, bei der der Gebrauch einer Gerte (das ist ein kleiner Stock, mit dem das Pferd leicht geschlagen wird) ausdrücklich verboten ist, wie Faust betont. Damit tritt er auch etwaigen Befürchtungen entgegen, dass es zu Tierquälerei kommen könnte. Der Chef des Hofgut Adamstal: „Das Gegenteil ist der Fall. Die Tiere können beim Horse-Ball ihre natürlichen Verhaltensweisen ausleben und haben sogar Spaß dabei“. Zumindest mehr als der eine oder andere Reiter, wie es angesichts des strengen Trainings den Eindruck macht."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Aktive der Wiesbadener Reitergruppe",
          "options": {
            "a": "bilden die deutsche Nationalmannschaft.",
            "b": "spielen schon als Achtjährige in der deutschen Nationalmannschaft mit.",
            "c": "unterstützen die deutsche Nationalmannschaft."
          },
          "answer": "a",
          "explanation": "Im 2. Absatz steht, dass „die erste Mannschaft der Reitergruppe Wiesbaden (RGW) identisch ist mit der National-Auswahl“."
        },
        {
          "num": 7,
          "stem": "Die Basketball-Körbe",
          "options": {
            "a": "hängen wie beim normalen Basketball.",
            "b": "sind mit dem Netz nach oben aufgehängt.",
            "c": "sind so gedreht, dass ihre Öffnungen nach der Seite zeigen."
          },
          "answer": "c",
          "explanation": "Laut Absatz 3 sind die Korbringe „nicht waagerecht, sondern senkrecht ausgerichtet“, sodass ihre Öffnungen zur Seite zeigen."
        },
        {
          "num": 8,
          "stem": "Wer an einem Horse-Ball-Lehrgang teilnimmt,",
          "options": {
            "a": "braucht ein eigenes Pferd.",
            "b": "kann sein eigenes Pferd einsetzen.",
            "c": "muss sein Pferd jedes Mal mitbringen."
          },
          "answer": "b",
          "explanation": "Im 5. Absatz heißt es, dass Pferde bei Bedarf gestellt werden, aber „natürlich können auch eigene Pferde mitgebracht werden“."
        },
        {
          "num": 9,
          "stem": "Beim Horse-Ball-Spiel",
          "options": {
            "a": "wird ein Fußball verwendet.",
            "b": "darf der Ball in die Hand genommen werden.",
            "c": "darf der Ball nicht auf den Boden fallen."
          },
          "answer": "b",
          "explanation": "Laut Absatz 7 nehmen die Spieler den Ball vom Boden auf; dazu ist der Ball mit Fangriemen versehen, „die ein sicheres Zugreifen auch mit einer Hand ermöglichen“."
        },
        {
          "num": 10,
          "stem": "Das Training ist so streng, dass",
          "options": {
            "a": "die Reiter oft mehr Stress zu empfinden scheinen als die Tiere.",
            "b": "die Tiere ihre naturgegebenen Anlagen nicht ausleben können.",
            "c": "es Pferden und Reitern oft kein Vergnügen macht."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz steht, dass die Tiere beim Horse-Ball Spaß haben – „zumindest mehr als der eine oder andere Reiter, wie es angesichts des strengen Trainings den Eindruck macht“."
        }
      ]
    },
    {
      "id": "21",
      "title": "Test 21 – Geschichte des Hauspersonals",
      "isVariant": false,
      "paragraphs": [
        "Dienstmädchen war um 1900 der am weitesten verbreitete Beruf für Frauen. Aus heutiger Perspektive ist das verwunderlich, denn der Alltag eines Dienstmädchens war sehr hart. Was trieb also Frauen in diesen Beruf?",
        "Es waren vor allem Mädchen vom Land, die von ihren Eltern in die Stadt geschickt wurden, um dort zu arbeiten. Auf dem Land gab es kaum Stellen für Mädchen. Als Dienstmädchen, so hofften die Eltern, würden ihre Töchter wenigstens das Hauswirtschaften lernen – eine wichtige Fertigkeit als spätere Haus- und Ehefrau. Dabei war das enge Leben eines Dienstmädchens ohne viel Zeit genau das, was den Eltern gut an diesem Beruf erschien: da die Mädchen oft erst 14 oder 15 Jahre alt waren, waren sie in einer Familie behüteter als beispielsweise in der Fabrik. Allerdings kam es nicht selten vor, dass die Hoffnung auf eine Ausbildung enttäuscht wurde. Viele Mädchen wurden nicht eingearbeitet und angelernt, sondern mussten selber zusehen, wie sie das Arbeitspensum bewältigten.",
        "Leider verfügten die Eltern meist nicht über Kontakte in der Stadt. Die Mädchen fuhren mit dem Zug in die Fremde und mussten dann auf eigene Faust eine Stellung finden. Das machten sich auch dubiose Stellenvermittler an den Bahnhöfen zu Nutze und verschafften den Mädchen Stellen in Kneipen als Kellnerinnen – damals eine Arbeit mit sehr schlechtem Ruf. Um diesen Missstand zu beenden, gründeten sich übrigens die Bahnhofsmissionen, die damals konfessionsübergreifend von den katholischen, evangelischen und jüdischen Gemeinden den ankommenden Mädchen erst einmal ein Bett bieten sollten.",
        "Wer etwas auf sich hielt, beschäftigte um 1900 ein Dienstmädchen: sowohl kleinbürgerliche Haushalte als auch großbürgerliche. Die unteren Schichten, also Handwerkerfamilien, eiferten den gehobeneren nach. Nach außen durfte es an nichts fehlen, auch wenn das Budget dafür knapp war. Gespart wurde da, wo es nicht sichtbar war: bei der Unterbringung und Ernährung der Dienstmädchen. In gehobeneren Schichten gab es gerne auch mehr Personal – ein Vorteil und Nachteil zugleich. Einerseits hatte das Dienstmädchen so mehr Gesellschaft und war weniger isoliert, andererseits gab es auch unter den Dienstboten eine Hierarchie und das Dienstmädchen war das unterste Glied.",
        "Anders als Fabrikarbeiter hatten Dienstboten keine geregelten Arbeitszeiten. Sie mussten, wenn nötig, ihren Dienstherren rund um die Uhr zur Verfügung stehen. Das Dienstmädchen stand als Erste auf, befeuerte den Ofen, machte das Wasser zum Waschen und fürs Frühstück warm, servierte die Mahlzeiten, räumte wieder ab, spülte und putzte. Das Einkaufen gehörte zu den beliebten Tätigkeiten, denn das erlaubte es den Mädchen, einmal ohne Aufsicht in der Stadt unterwegs zu sein, andere Dienstmädchen zu treffen und sich auszutauschen. Fließendes Wasser gehörte um die Jahrhundertwende nicht zum Standard, so musste das Dienstmädchen auch Wasser schleppen. Erst wenn alle Arbeit erledigt war, konnte das Dienstmädchen schlafen gehen. Die wenige freie Zeit am Abend reichte oft nur, um die eigene Kleidung auszubessern. Alle vierzehn Tage durften die Mädchen sonntags für zwei Stunden das Haus verlassen, das war der einzige Ausgang, den sie hatten.",
        "Der Lohn bestand im Wesentlichen aus Kost und Unterkunft. Etwas zurücklegen für später konnte kaum ein Mädchen. Auch die Unterbringung ließ zu wünschen übrig. Von Berliner Dienstmädchen weiß man, dass sie oft noch nicht einmal eine eigene Kammer hatten, sondern auf so genannten Hängeböden schliefen, eine kleine Fläche von vielleicht mal zwei Metern bei einer Raumhöhe von etwa 1,50 Meter. Wenig Schlaf, und dann auch noch schlechter Schlaf: Vielen Mädchen waren die Strapazen trotz ihres jungen Alters anzusehen. Für die meisten war es nur eine Zwischenstation. Heirateten sie, beendeten die jungen Mädchen dieses Arbeitsverhältnis und stattdessen war die junge Frau selber Hausfrau und Herrin eines eigenen Haushalts."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Eltern ließen ihre Töchter als Dienstmädchen arbeiten,",
          "options": {
            "a": "damit sie die Jahre bis zur Arbeit in der Fabrik überbrücken konnten.",
            "b": "damit sie lernten, einen Haushalt zu führen.",
            "c": "damit sie besser beaufsichtigt waren als zu Hause."
          },
          "answer": "b",
          "explanation": "Im 2. Absatz steht: „Als Dienstmädchen, so hofften die Eltern, würden ihre Töchter wenigstens das Hauswirtschaften lernen – eine wichtige Fertigkeit als spätere Haus- und Ehefrau.“"
        },
        {
          "num": 7,
          "stem": "Die Stellen fanden die Mädchen zumeist",
          "options": {
            "a": "durch Vermittler, die ins Dorf kamen.",
            "b": "alleine.",
            "c": "mit Hilfe ihrer Eltern."
          },
          "answer": "b",
          "explanation": "Laut Absatz 3 verfügten die Eltern meist über keine Kontakte in der Stadt, sodass die Mädchen „auf eigene Faust eine Stellung finden“ mussten."
        },
        {
          "num": 8,
          "stem": "Dienstmädchen gab es",
          "options": {
            "a": "fast nur bei reicheren Leuten.",
            "b": "auch bei den weniger reichen Leuten.",
            "c": "in jedem Haus in der Stadt."
          },
          "answer": "b",
          "explanation": "Im 4. Absatz wird erklärt, dass sowohl großbürgerliche als auch kleinbürgerliche Haushalte (z. B. Handwerkerfamilien mit knappem Budget) Dienstmädchen beschäftigten."
        },
        {
          "num": 9,
          "stem": "Dienstmädchen",
          "options": {
            "a": "mussten länger arbeiten als Fabrikarbeiter.",
            "b": "konnten sich am Sonntag zwei Stunden mit anderen Dienstmädchen treffen.",
            "c": "durften nicht alleine einkaufen gehen."
          },
          "answer": "a",
          "explanation": "Laut Absatz 5 hatten Dienstboten anders als Fabrikarbeiter keine geregelten Arbeitszeiten und mussten ihrer Herrschaft „rund um die Uhr zur Verfügung stehen“ (Ausgang gab es nur alle 14 Tage sonntags)."
        },
        {
          "num": 10,
          "stem": "Dienstmädchen bekamen",
          "options": {
            "a": "fast kein Geld.",
            "b": "ein eigenes Zimmer.",
            "c": "Geld, um für später zu sparen."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz heißt es: „Der Lohn bestand im Wesentlichen aus Kost und Unterkunft. Etwas zurücklegen für später konnte kaum ein Mädchen.“"
        }
      ]
    },
    {
      "id": "22",
      "title": "Test 22 – Die ganze Welt auf dem eigenen PC",
      "isVariant": false,
      "paragraphs": [
        "„Google Earth“, das digitale Abbild der Erde mit Satelliten- und Luftbildern, ist seit 2006 im Internet. Und es gibt auch eine deutsche Version. Ohne langes Training, gewissermaßen von einer Sekunde zur anderen, wird man mit „Google Earth“ zum Weltraumfahrer und Astronauten. Der Computer ersetzt das Weltraumschiff, die Computermaus den Steuerknüppel. Nutzer können sich auf einen Kontinent, ein Land, eine Stadt, sogar aufs eigene Haus oder in die Fußballstadien des Landes zoomen: Inzwischen gibt es „Google Earth“ in einer völlig neuen Version – mit viermal mehr Daten als bisher und erstmals auch in deutscher Sprache. (http://earth.google.com)",
        "„Deutschland ist unser wichtigster Standort“, sagte John Hanke, Leiter von Googles Keyhole-Gruppe. Keyhole, dessen Chef Hanke bis zur Übernahme durch Google im Oktober 2004 war, hat die Software für „Google Earth“ entwickelt. „Rund ein Fünftel der Erde – auf dieser Fläche wohnt fast die Hälfte der Weltbevölkerung – haben wir jetzt dargestellt. Viermal so viele Daten wie bisher“. Deutschland sei weltweit das einzige Land, für das komplett hochauflösendes, also besonders genau abbildendes Material zur Verfügung stand, erklärt Hanke. Ein Bildpunkt (Pixel) entspricht dabei 15 Metern auf der Erde. Größere deutsche Städte beispielsweise werden in der höchstmöglichen Auflösung sogar mit zehn Zentimetern pro Pixel dargestellt. Kleinere Städte jedoch, wie etwa Hameln, sind nach wie vor sehr grob dargestellt.",
        "Neugierige Reporter, die über den Gartenzaun von Nachbarn oder bekannten Persönlichkeiten sehen wollen, haben Pech: „Google Earth“ bietet keine Livebilder. Die Daten stammen von Flugzeugen und drei Satelliten und können viele Monate alt sein. So kommt es, dass etwa ein Sportstadion in Hannover lange Zeit ohne Rasen zu sehen war – die Aufnahme stammt aus der Zeit der Renovierung.",
        "Ursprünglich waren es nur Kunden aus den Bereichen Militär und Immobilien, die sich für die verrückte Idee interessierten, die Erde im Internet nachzubilden. Doch aus Hankes „fixer Idee“ wurde ein Renner. Da es sich bei „Google Earth“ um einen offenen Standard handelt und nur die professionellen Produkte Geld kosten, entwickelt sich rundherum eine immer größer werdende Familie von Anwendern, die Möglichkeiten zur Nutzung der Bilder sehen. Künftig soll das Programm nach dem Prinzip der freien Enzyklopädie Wikipedia durch die Informationen und Beiträge aller Nutzer wachsen, sagt Hanke.",
        "„Google Earth“ zählt inzwischen zu den weltweit am häufigsten angeklickten Internetseiten. Wenn TV-Stationen in den USA ihre Nachrichten beginnen, fliegen sie mit „Google Earth“ zum Ort des Geschehens. Wegen des riesigen Erfolges sind auch die Mitstreiter Yahoo und Microsoft auf den Zug gesprungen und versuchen, mit der Idee von „Google Earth“ Geld zu verdienen.",
        "Das Spektrum neuer Anwendungen von „Google Earth“ reicht von nützlich bis negativ. So kann man sich die Standorte billiger Tankstellen oder Weltmeisterschafts-Stadien mit Zeittafeln der Fußballspiele genauso auf einer Karte anzeigen lassen wie die Wohnorte aller in Florida erfassten Verbrecher, Name, Adresse und Polizeifoto inklusive. Von Datenschutz kann dort also nicht die Rede sein. Die Kaufhauskette „Kaufhof“ und das Internet-Reisebüro lastminute.de sind die ersten deutschen Unternehmen, die sich die neue Technik zunutze gemacht haben.",
        "Mit der neuen Version von „Google Earth“ öffnet sich auch ein völlig neues Kapitel der Routenplanung bei Reisen. Je mehr Informationen gesammelt und dargestellt werden, desto besser werden die Ergebnisse bei der lokalen Suche. Einige Gebäude – vor allem in den USA – lassen sich ganz realistisch darstellen. In Deutschland dauert es jedoch noch etwas."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Das Besondere an der neuen Version von „Google Earth“ ist, dass es",
          "options": {
            "a": "von der gesamten Erde ein genaues Abbild bietet.",
            "b": "von einigen Ländern ein genaueres Abbild bietet als früher.",
            "c": "zunächst nur in deutscher Sprache bedient werden kann."
          },
          "answer": "b",
          "explanation": "Im 1. und 2. Absatz heißt es, dass die neue Version „viermal mehr Daten als bisher“ enthält und insbesondere für Deutschland komplett hochauflösendes Material bietet."
        },
        {
          "num": 7,
          "stem": "Die Bilder von „Google Earth“",
          "options": {
            "a": "sind aktuell, d.h., ich kann mich selbst im Garten sitzen sehen.",
            "b": "sind alle nicht ganz neu.",
            "c": "werden bald als aktuelle Bilder zur Verfügung stehen."
          },
          "answer": "b",
          "explanation": "Laut Absatz 3 bietet „Google Earth“ keine Livebilder; die Aufnahmen „können viele Monate alt sein“."
        },
        {
          "num": 8,
          "stem": "Für „Google Earth“ interessieren sich heute",
          "options": {
            "a": "insbesondere Militärs und Immobilienhändler.",
            "b": "Menschen aus vielen Berufsgruppen.",
            "c": "vorwiegend die Nutzer der Enzyklopädie „Wikipedia“."
          },
          "answer": "b",
          "explanation": "Im 4. bis 6. Absatz wird beschrieben, dass es ursprünglich nur Militär und Immobilien waren, sich heute aber eine immer größer werdende Anwenderfamilie (TV-Sender, Kaufhäuser, Reisebüros, Privatnutzer) dafür interessiert."
        },
        {
          "num": 9,
          "stem": "Negativ an „Google Earth“ ist laut Text, dass",
          "options": {
            "a": "die Daten kommerziell genutzt werden.",
            "b": "persönliche Daten öffentlich verfügbar sind.",
            "c": "Verbrecher es nutzen."
          },
          "answer": "b",
          "explanation": "Im 6. Absatz wird als negativer Aspekt genannt, dass man sich z. B. Wohnorte, Namen, Adressen und Fotos von Personen anzeigen lassen kann („Von Datenschutz kann dort also nicht die Rede sein“)."
        },
        {
          "num": 10,
          "stem": "Positiv an „Google Earth“ ist laut Text, dass",
          "options": {
            "a": "Gebäude in Deutschland wirklichkeitsnah abgebildet werden.",
            "b": "man damit Lokale suchen kann.",
            "c": "man sich damit orientieren kann."
          },
          "answer": "c",
          "explanation": "Laut dem letzten Absatz eröffnet „Google Earth“ neue Möglichkeiten bei der Routenplanung und lokalen Suche zur Orientierung auf Reisen."
        }
      ]
    },
    {
      "id": "23",
      "title": "Test 23 – Volkskrankheit Rückenschmerzen – Ursache und Therapie",
      "isVariant": false,
      "paragraphs": [
        "Rückenschmerzen sind zu einer teuren Volkskrankheit geworden. In Deutschland sind sie der zweithäufigste Grund für Arztbesuche. Statistisch gesehen klagen etwa 27 Prozent der Männer und 40 Prozent der Frauen über Rückenschmerzen, etwa 70 Prozent geben an, mindestens einmal im Jahr darunter zu leiden.",
        "Wie entstehen Rückenschmerzen überhaupt? Meist sind die Knochen der Wirbelsäule nicht ursächlich für den Schmerz verantwortlich. So kommt es häufig durch Verrenkungen oder Fehlbelastungen wie z. B. sitzende Schreibtätigkeit oder unsachgerechtes Tragen und Heben zu schmerzhaften Verspannungen der Rückenmuskulatur, wodurch benachbarte Nerven gereizt werden. Zunächst gelangt der akute Schmerzreiz über Nervenbahnen ins Rückenmark und von dort aus ins Gehirn, wo der Schmerz weiterverarbeitet wird. Beim chronischen Schmerz hingegen kann die Ursache längst schon beseitigt sein, die Nervenzellen aber melden dem Gehirn immer noch Schmerzen, wo gar keine sind, weil sie im Gehirn regelrecht eingebrannt werden, wenn sie nach einer bestimmten Zeit nicht beseitigt sind.",
        "Es gibt mehrere Krankheitsbilder, die häufiger auftreten wie etwa dieses: Kommt es zu einem Austritt von Gallertmasse aus dem Bandscheibenkern, spricht man von einem Bandscheibenvorfall. In einem solchen Fall kann die Masse auf die Rückenmarksnerven drücken, und starke Schmerzen und gegebenenfalls Lähmungen und/oder Gefühlsstörungen verursachen. Die Ursachen für einen Bandscheibenvorfall sind vielfältig. Beispielsweise kann eine jahrelange Vorschädigung durch einseitige Belastung zu einem Bandscheibenvorfall führen, aber auch genetische oder muskuläre Schwächen können die Ursache sein.",
        "Bewegungsmangel und Fehlhaltungen sind in der heutigen Zeit Ursache für einen rasanten Anstieg an Bandscheibenvorfällen. Kreuzschmerzen in der Lendenwirbelsäule werden medizinisch als Lumbago bezeichnet, treten sie plötzlich und heftig auf, spricht man von einem Hexenschuss. In solch einem Fall ist die Bewegungsfähigkeit stark eingeschränkt, sogar Sitzen kann sehr schmerzhaft sein. Selbst geringste Bewegungen sind aufgrund der starken Schmerzen unmöglich. Rückenschmerzen können jedoch nicht nur durch eine akute Entzündung hervorgerufen werden; häufig sind auch degenerative Abnutzungserscheinungen der Wirbelkörper-Knochen Grund für die Schmerzen.",
        "Eine überwiegend Frauen betreffende Erkrankung ist die Osteoporose. Hier nimmt die Knochenmasse ab, die Reduzierung der Wirbelkörper-Höhe führt zu erheblichen Beschwerden. Verschleißerscheinungen sind aber nicht nur älteren Menschen vorbehalten, sie treten auch schon bei jungen Menschen auf. Eine häufige Krankheit bei ihnen ist die seitliche Krümmung der Wirbelsäule, Skoliose genannt. Diese entsteht während des Wachstums und verschlechtert sich in Zeiten verstärkten Körperwachstums, zum Beispiel in der Pubertät. Wirbelfehlbildungen, Muskelerkrankungen und Beinlängendifferenzen können ebenso der Grund sein.",
        "Aber nicht immer sind körperliche Gebrechen Ursache für Rückenschmerzen. Auch Depressionen und psychischer Stress können ein Auslöser sein. Nicht umsonst klagen Menschen in Trauersituationen oft über starke Schmerzen. Umgekehrt können dauerhafte Rückenschmerzen auch Einfluss auf die Psyche nehmen. Leidet ein Mensch jahrelang unter andauernden Schmerzen z. B. durch einen Bandscheibenvorfall, kann ihn dies psychisch zermürben, er wird zunehmend depressiv. Jeder Schritt tut weh, man wagt es kaum noch, sich zu bewegen. Hinzu kommt die Angst um die körperliche Leistungsfähigkeit und den Job. Erfreulich ist jedoch, dass diese Symptome oft mit einer erfolgreichen Bandscheibenoperation verschwinden.",
        "Um Rückenschmerzen vorzubeugen oder die Behandlung zu unterstützen, müssen Sie Ihren Rücken auch im täglichen Leben trainieren. Sport stärkt die Muskeln und ist gut gegen Verspannungen. Besonders geeignet sind Schwimmen und Radfahren. Viele Krankenkassen bieten mittlerweile Rückenkurse an, hier lernen die Teilnehmer das rückengerechte Heben, Bücken und Tragen sowie eine gesunde Körperhaltung. Ebenso gibt es Kurse, in denen man erfährt, wie man durch eine gesunde Ernährung Rückenproblemen vorbeugen oder Beschwerden lindern kann. Treten Rückenschmerzen aber häufiger auf, sollten Sie zum Arzt gehen. Dieser kann ausschließen, dass eine ernsthafte Erkrankung vorliegt, und die weitere Therapie mit Ihnen besprechen. Oft sind Massagen und Krankengymnastik effektive Maßnahmen, um die Schmerzen zu lindern und weiteren Beschwerden vorzubeugen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Volkskrankheit Rückenschmerzen",
          "options": {
            "a": "befällt 70% der Bevölkerung mindestens einmal in ihrem Leben.",
            "b": "kann durch eine Vielzahl von Faktoren ausgelöst werden.",
            "c": "wird von den meisten Patienten als Grund für einen Arztbesuch genannt."
          },
          "answer": "b",
          "explanation": "Im gesamten Text werden zahlreiche Ursachen genannt (Fehlbelastungen, Bewegungsmangel, genetische Schwächen, Verschleiß, Osteoporose, Skoliose sowie psychischer Stress). (70 % leiden einmal im Jahr darunter, und es ist der zweithäufigste Grund für Arztbesuche.)"
        },
        {
          "num": 7,
          "stem": "Rückenbeschwerden",
          "options": {
            "a": "entstehen, weil angespannte Muskeln auf nahegelegene Nervenenden drücken.",
            "b": "kommen in allen Altersstufen gleichmäßig vor.",
            "c": "sind überwiegend auf Schäden am Skelett zurückzuführen."
          },
          "answer": "a",
          "explanation": "Im 2. Absatz steht, dass meist nicht die Knochen verantwortlich sind, sondern „schmerzhafte Verspannungen der Rückenmuskulatur, wodurch benachbarte Nerven gereizt werden“."
        },
        {
          "num": 8,
          "stem": "Bandscheibenvorfälle",
          "options": {
            "a": "in der Lendenwirbelsäule haben in den letzten Jahren abgenommen.",
            "b": "können zu Depressionen führen.",
            "c": "wirken sich in der Regel nicht negativ auf die körperliche Leistungsfähigkeit aus."
          },
          "answer": "b",
          "explanation": "Im 6. Absatz heißt es: „Leidet ein Mensch jahrelang unter andauernden Schmerzen z. B. durch einen Bandscheibenvorfall, kann ihn dies psychisch zermürben, er wird zunehmend depressiv.“"
        },
        {
          "num": 9,
          "stem": "Abnutzungserscheinungen am Skelett",
          "options": {
            "a": "können durch verschiedene Erkrankungen hervorgerufen werden.",
            "b": "lassen sich häufig auf eine falsche Ernährung zurückführen.",
            "c": "treten heutzutage verstärkt bei Jugendlichen auf."
          },
          "answer": "a",
          "explanation": "Im 5. Absatz werden verschiedene Erkrankungen wie Osteoporose, Skoliose, Wirbelfehlbildungen, Muskelerkrankungen und Beinlängendifferenzen als Gründe für Verschleiß und Beschwerden am Skelett aufgeführt."
        },
        {
          "num": 10,
          "stem": "Wer Rückenschmerzen hat,",
          "options": {
            "a": "sollte als Erstes einen Psychologen aufsuchen.",
            "b": "sollte nicht zu lange mit dem Arztbesuch warten.",
            "c": "wird von der Krankenkasse verpflichtet, an einer Rückenschule teilzunehmen."
          },
          "answer": "b",
          "explanation": "Laut Absatz 2 brennen sich Schmerzen im Gehirn ein, „wenn sie nach einer bestimmten Zeit nicht beseitigt sind“, und im letzten Absatz wird geraten, bei häufigeren Rückenschmerzen zum Arzt zu gehen."
        }
      ]
    },
    {
      "id": "23a",
      "title": "Test 23a – Volkskrankheit Rückenschmerzen – Ursache und Therapie",
      "isVariant": true,
      "paragraphs": [
        "Rückenschmerzen sind zu einer teuren Volkskrankheit geworden. In Deutschland sind sie der zweithäufigste Grund für Arztbesuche. Statistisch gesehen klagen etwa 27 Prozent der Männer und 40 Prozent der Frauen über Rückenschmerzen, etwa 70 Prozent geben an, mindestens einmal im Jahr darunter zu leiden.",
        "Wie entstehen Rückenschmerzen überhaupt? Meist sind die Knochen der Wirbelsäule nicht ursächlich für den Schmerz verantwortlich. So kommt es häufig durch Verrenkungen oder Fehlbelastungen wie z. B. sitzende Schreibtätigkeit oder unsachgerechtes Tragen und Heben zu schmerzhaften Verspannungen der Rückenmuskulatur, wodurch benachbarte Nerven gereizt werden. Zunächst gelangt der akute Schmerzreiz über Nervenbahnen ins Rückenmark und von dort aus ins Gehirn, wo der Schmerz weiterverarbeitet wird. Beim chronischen Schmerz hingegen kann die Ursache längst schon beseitigt sein, die Nervenzellen aber melden dem Gehirn immer noch Schmerzen, wo gar keine sind, weil sie im Gehirn regelrecht eingebrannt werden, wenn sie nach einer bestimmten Zeit nicht beseitigt sind.",
        "Es gibt mehrere Krankheitsbilder, die häufiger auftreten wie etwa dieses: Kommt es zu einem Austritt von Gallertmasse aus dem Bandscheibenkern, spricht man von einem Bandscheibenvorfall. In einem solchen Fall kann die Masse auf die Rückenmarksnerven drücken, und starke Schmerzen und gegebenenfalls Lähmungen und/oder Gefühlsstörungen verursachen. Die Ursachen für einen Bandscheibenvorfall sind vielfältig. Beispielsweise kann eine jahrelange Vorschädigung durch einseitige Belastung zu einem Bandscheibenvorfall führen, aber auch genetische oder muskuläre Schwächen können die Ursache sein.",
        "Bewegungsmangel und Fehlhaltungen sind in der heutigen Zeit Ursache für einen rasanten Anstieg an Bandscheibenvorfällen. Kreuzschmerzen in der Lendenwirbelsäule werden medizinisch als Lumbago bezeichnet, treten sie plötzlich und heftig auf, spricht man von einem Hexenschuss. In solch einem Fall ist die Bewegungsfähigkeit stark eingeschränkt, sogar Sitzen kann sehr schmerzhaft sein. Selbst geringste Bewegungen sind aufgrund der starken Schmerzen unmöglich. Rückenschmerzen können jedoch nicht nur durch eine akute Entzündung hervorgerufen werden; häufig sind auch degenerative Abnutzungserscheinungen der Wirbelkörper-Knochen Grund für die Schmerzen.",
        "Eine überwiegend Frauen betreffende Erkrankung ist die Osteoporose. Hier nimmt die Knochenmasse ab, die Reduzierung der Wirbelkörper-Höhe führt zu erheblichen Beschwerden. Verschleißerscheinungen sind aber nicht nur älteren Menschen vorbehalten, sie treten auch schon bei jungen Menschen auf. Eine häufige Krankheit bei ihnen ist die seitliche Krümmung der Wirbelsäule, Skoliose genannt. Diese entsteht während des Wachstums und verschlechtert sich in Zeiten verstärkten Körperwachstums, zum Beispiel in der Pubertät. Wirbelfehlbildungen, Muskelerkrankungen und Beinlängendifferenzen können ebenso der Grund sein.",
        "Aber nicht immer sind körperliche Gebrechen Ursache für Rückenschmerzen. Auch Depressionen und psychischer Stress können ein Auslöser sein. Nicht umsonst klagen Menschen in Trauersituationen oft über starke Schmerzen. Umgekehrt können dauerhafte Rückenschmerzen auch Einfluss auf die Psyche nehmen. Leidet ein Mensch jahrelang unter andauernden Schmerzen z. B. durch einen Bandscheibenvorfall, kann ihn dies psychisch zermürben, er wird zunehmend depressiv. Jeder Schritt tut weh, man wagt es kaum noch, sich zu bewegen. Hinzu kommt die Angst um die körperliche Leistungsfähigkeit und den Job. Erfreulich ist jedoch, dass diese Symptome oft mit einer erfolgreichen Bandscheibenoperation verschwinden.",
        "Um Rückenschmerzen vorzubeugen oder die Behandlung zu unterstützen, müssen Sie Ihren Rücken auch im täglichen Leben trainieren. Sport stärkt die Muskeln und ist gut gegen Verspannungen. Besonders geeignet sind Schwimmen und Radfahren. Viele Krankenkassen bieten mittlerweile Rückenkurse an, hier lernen die Teilnehmer das rückengerechte Heben, Bücken und Tragen sowie eine gesunde Körperhaltung. Ebenso gibt es Kurse, in denen man erfährt, wie man durch eine gesunde Ernährung Rückenproblemen vorbeugen oder Beschwerden lindern kann. Treten Rückenschmerzen aber häufiger auf, sollten Sie zum Arzt gehen. Dieser kann ausschließen, dass eine ernsthafte Erkrankung vorliegt, und die weitere Therapie mit Ihnen besprechen. Oft sind Massagen und Krankengymnastik effektive Maßnahmen, um die Schmerzen zu lindern und weiteren Beschwerden vorzubeugen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Volkskrankheit Rückenschmerzen",
          "options": {
            "a": "befällt 70 % der Bevölkerung mindestens einmal in ihrem Leben.",
            "b": "ist bei Frauen deutlich stärker ausgeprägt als bei Männern.",
            "c": "wird von den meisten Patienten als Grund für einen Arztbesuch genannt."
          },
          "answer": "b",
          "explanation": "Im 1. Absatz steht: „Statistisch gesehen klagen etwa 27 Prozent der Männer und 40 Prozent der Frauen über Rückenschmerzen“ – Frauen sind also deutlich häufiger betroffen."
        },
        {
          "num": 7,
          "stem": "Rückenbeschwerden",
          "options": {
            "a": "entstehen, weil angespannte Muskeln auf nahegelegene Nervenenden drücken.",
            "b": "sind überwiegend auf Schäden der knöchernen Struktur zurückzuführen.",
            "c": "verschwinden mit der Beseitigung der Ursache."
          },
          "answer": "a",
          "explanation": "Laut Absatz 2 entstehen die Beschwerden meist durch „schmerzhafte Verspannungen der Rückenmuskulatur, wodurch benachbarte Nerven gereizt werden“."
        },
        {
          "num": 8,
          "stem": "Bandscheibenvorfälle",
          "options": {
            "a": "können unterschiedliche Auslöser haben.",
            "b": "sind in den letzten Jahren stark zurückgegangen.",
            "c": "sollten im Sitzen und Liegen therapiert werden."
          },
          "answer": "a",
          "explanation": "Im 3. Absatz heißt es ausdrücklich: „Die Ursachen für einen Bandscheibenvorfall sind vielfältig“ (z. B. einseitige Belastung, genetische oder muskuläre Schwächen)."
        },
        {
          "num": 9,
          "stem": "Abnutzungserscheinungen am Skelett",
          "options": {
            "a": "können durch verschiedene Erkrankungen hervorgerufen werden.",
            "b": "lassen sich häufig auf eine falsche Ernährung zurückführen.",
            "c": "treten heutzutage verstärkt bei Jugendlichen auf."
          },
          "answer": "a",
          "explanation": "Laut Absatz 5 können verschiedene Krankheiten wie Osteoporose, Skoliose, Wirbelfehlbildungen oder Muskelerkrankungen der Grund für solche Verschleißerscheinungen sein."
        },
        {
          "num": 10,
          "stem": "Wer Rückenschmerzen hat,",
          "options": {
            "a": "sollte als Erstes einen Psychologen aufsuchen.",
            "b": "sollte nicht zu lange mit dem Arztbesuch warten.",
            "c": "wird von der Krankenkasse verpflichtet, an einer Rückenschule teilzunehmen."
          },
          "answer": "b",
          "explanation": "Im 2. und letzten Absatz wird betont, dass unbehandelte Schmerzen chronisch werden können und man bei häufigeren Beschwerden rechtzeitig zum Arzt gehen sollte."
        }
      ]
    },
    {
      "id": "24",
      "title": "Test 24 – Wie zwei US-Teenager Millionäre wurden",
      "isVariant": false,
      "paragraphs": [
        "Märchenwelt Web 2.0: Catherine und David Cook waren 15 und 16, als ihnen beim Blättern im Highschool-Jahrbuch eine Idee kam. Eine Internetseite, zum Flirten und Lästern, wie ein Schulhof für Ehemalige. Sie erfanden „MyYearbook.com“, die Seite, die sie reich gemacht hat. Es muss irgendwann zwischen Mathe-Hausaufgaben und Abendessen gewesen sein: Catherine Cook, 15, liegt auf dem Bett und blättert das aktuelle Jahrbuch ihrer Highschool in Skillman, New Jersey, durch. Sie schlägt die Seite auf, auf der ihr Schwarm zu sehen ist. Seit einem Jahr ist sie heimlich in ihn verliebt. Um seinen Kopf hat sie ein pinkfarbenes Herz gemalt. Schon zig Mal hat sie diese Seite angeschaut, ganz abgegriffen ist das Papier. Jetzt ist er weg, hat seinen Abschluss gemacht, studiert an einem College. Seitdem hört sie nichts mehr von ihm, keine neuen Infos, keine neuen Fotos. Wie praktisch wäre ein digitales Jahrbuch – ein Netzwerk, in dem man den Weg der ehemaligen Mitschüler verfolgen, mit aktuellen Freunden chatten, den süßen Typ aus der Parallelklasse unverbindlich anschreiben und mit Freundinnen lästern kann ... Catherine erzählt ihrem 16-jährigen Bruder David von der Idee. Er ist begeistert: Ein Jahrbuch 2.0. Eine digitale Version der Kladde, die zum Schuljahresende an die Schüler verkauft wird. Oder einfach: ein „Facebook“ für Highschool-Schüler. Sicher ist diese Idee dem einen oder anderen Schüler vorher auch schon gekommen. Aber Catherine und David Cook haben einen entscheidenden Vorteil: Geoffrey, den großen Bruder mit viel Geld. Sie erzählen ihm von ihrer Idee, er ist begeistert und investiert eine viertel Million Dollar.",
        "Noch am selben Abend beginnen die Geschwister das Design für die Seite auf Papier zu zeichnen. In den folgenden Nächten faxen sie die Entwürfe nach Indien zu den Programmierern, die der große Bruder Geoffrey für das Projekt angeheuert hat. „Das war eine spannende Zeit, die Küche unseres Elternhauses wurde zur Kommandozentrale. Die ganze Familie stand sofort hinter dem Projekt, alle haben mit überlegt“, sagt David. Wenige Wochen später, im Sommer 2005, geht die Seite online. Heute ist klar: Die Investition hat sich gelohnt. Die beiden Teenager Catherine, heute 17, und David, 19, sind zwar noch nicht volljährig in den USA, aber bereits Millionäre. Und der 29-jährige Geoffrey Cook, der schon als Student an der Universität Harvard mit dem Verkauf zweier Internetseiten seine erste Million verdient hatte, hat seine investierten 250.000 Dollar längst wieder raus. Er ist nun Firmenchef von „MyYearbook.com“. Die Seite ist die am schnellsten wachsende Internetgemeinde in den USA, so das Ergebnis einer Erhebung des Instituts „com.Score“, das Besucherzahlen im Internet misst und regelmäßig veröffentlicht. Jeden Tag melden sich 15.000 neue Mitglieder an, insgesamt sind es inzwischen vier Millionen Menschen zwischen 13 und 24 Jahren, die sich dort zum Chatten treffen, einfach Zeit verbringen – und was das Wichtigste für die Macher ist: Werbespots anschauen. Laut einer Schätzung von „com.Score“ sind mit sozialen Netzwerken wie „MyYearbook.com“ im Internet dieses Jahr 900 Millionen Dollar zu verdienen, allein in den USA. Einen Großteil davon streichen die Platzhirsche „Myspace.com“ und „Facebook.com“ ein, aber auch „MyYearbook.com“ verdient ordentlich mit. Während einige US-Schulen die Rechner wieder in den Schrank verbannen, wird es bei den Schülern immer mehr zum Trend, ihre Freizeit mit Freunden virtuell zu verbringen, statt im Park um die Ecke auf morschen Tischtennisplatten zu hocken. Etwa 60 Prozent der 12- bis 17-Jährigen und gar 80 Prozent der 18- bis 21-Jährigen nutzen diese sozialen Netzwerke, so eine US-Studie des Forrester-Instituts. Auch in Deutschland legte das Portal „StudiVZ“ im letzten Jahr einen rasanten Erfolg hin.",
        "„MyYearbook.com“ ist ein Paradebeispiel einer solchen Netzwerkseite. Nirgendwo sonst kann man so viel loswerden wie hier, über sich und über andere: Man wählt den peinlichsten Lehrer, den größten Schwarm, das schönste Mädchen der Stufe und vieles mehr. Dass zwei Schüler die Seite entworfen haben, merkt man bei jedem Klick: Hier treten zum Beispiel zwei junge Frauen mit Fotos gegeneinander an, die Internetgemeinde entscheidet, wer cooler ist und „Promqueen“ werden soll, also Abschlussball-Königin. Nebensächlich für Erwachsene – aber lebenswichtig für amerikanische Highschool-Schülerinnen! Diese ganze Highschool-Welt, die sich dem Europäer höchstens beim Schulaustausch in den Staaten oder in Highschool-Filmen wie „American Pie“ offenbart, gibt es hier in Reinform zu bestaunen. Man kann Mitschüler als Jungfrauen brandmarken, sein eigenes Outing im Internet vollziehen, einem Mädchen Blumen schicken, sich als Verehrer auf ihrer Seite eintragen – alles sichtbar für den Sitznachbarn aus dem Bio-Kurs und jeden anderen US-Schüler mit Account. Catherine ist sich sicher, dass dies das Geheimrezept von „MyYearbook.com“ ist. „Wir haben eine Internetgemeinde gegründet, in der es genauso abgeht wie auf dem Schulhof, das kommt an.“ Sie schwärmt inzwischen nicht mehr für süße Highschool-Jungs, sie ist nun selbst Absolventin. Zum kommenden Semester beginnt sie ihr BWL-Studium an der Georgetown University in Washington DC. Bei „MyYearbook.com“ bleibt sie trotzdem angemeldet – schon allein wegen der 3065 Jungs, die sich auf ihrer Profilseite als „Verehrer“ geoutet haben."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Zwei US Highschool-Schüler sind",
          "options": {
            "a": "mit dem Geld ihres Bruders reich geworden.",
            "b": "durch eine einfache Idee reich geworden.",
            "c": "durch eine einfache Idee und mit der finanziellen Hilfe ihres Bruders reich geworden."
          },
          "answer": "c",
          "explanation": "Im 1. Absatz steht, dass die Geschwister zwar die Idee zum digitalen Jahrbuch hatten, ihr entscheidender Vorteil aber ihr großer Bruder Geoffrey war, der 250.000 Dollar investierte."
        },
        {
          "num": 7,
          "stem": "Ähnliche Internetseiten sind heutzutage",
          "options": {
            "a": "nur in den USA beliebt.",
            "b": "sowohl in den USA als auch in Deutschland erfolgreich.",
            "c": "überall sehr populär."
          },
          "answer": "b",
          "explanation": "Im 2. Absatz wird neben dem großen Erfolg in den USA ausdrücklich erwähnt: „Auch in Deutschland legte das Portal ‚StudiVZ‘ im letzten Jahr einen rasanten Erfolg hin.“"
        },
        {
          "num": 8,
          "stem": "Die Idee von Catherine und David Cook wurde erfolgreich, weil",
          "options": {
            "a": "sie Treffen für Ex-Schüler im Internet organisiert haben.",
            "b": "sie eine Internetseite gegründet haben, die ihrem Schulhof ähnlich ist.",
            "c": "alle für die Schüler wichtigen Sachen auf dieser Seite genauso passieren, als wäre es in der eigenen Schule."
          },
          "answer": "c",
          "explanation": "Im 3. Absatz erklärt Catherine das Erfolgsrezept: Auf der Seite findet die gesamte Highschool-Welt statt („Wir haben eine Internetgemeinde gegründet, in der es genauso abgeht wie auf dem Schulhof, das kommt an.“)."
        },
        {
          "num": 9,
          "stem": "Die Jugendlichen in den USA benutzen solche Netzwerke",
          "options": {
            "a": "um über die Highschool-Welt informiert zu sein.",
            "b": "um ihre Freizeit virtuell verbringen zu können.",
            "c": "um mit Freunden chatten zu können."
          },
          "answer": "b",
          "explanation": "Im 2. Absatz heißt es: „... wird es bei den Schülern immer mehr zum Trend, ihre Freizeit mit Freunden virtuell zu verbringen, statt im Park um die Ecke auf morschen Tischtennisplatten zu hocken.“"
        },
        {
          "num": 10,
          "stem": "Catherine ist",
          "options": {
            "a": "als Studentin an der Georgetown University bereits Millionärin.",
            "b": "noch immer an ihrer Seite angemeldet.",
            "c": "mit den 3065 Jungs auf ihrer Profilseite beschäftigt."
          },
          "answer": "b",
          "explanation": "Am Ende des Textes steht, dass sie ihr Studium erst im kommenden Semester beginnt, aber: „Bei ‚MyYearbook.com‘ bleibt sie trotzdem angemeldet“."
        }
      ]
    },
    {
      "id": "25",
      "title": "Test 25 – Wir brauchen überall mehr Visionäre",
      "isVariant": false,
      "paragraphs": [
        "Der Expeditionsleiter Arved Fuchs über die Faszination und den Sinn von Grenzerfahrungen.",
        "Das Wort Abenteurer, wie es in Bezug auf mich so pauschal verwendet wird, habe ich immer ganz anders verstanden. Abenteuer ist für mich etwas, das im Kopf stattfindet. Die Freiheit, das Unmögliche zu denken, Dinge zu wagen, von denen andere erst einmal sagen: Das geht nicht.",
        "Die Freiheit aufzubrechen hat mich schon in meiner Jugend durchdrungen. Und einzutauchen in Naturlandschaften bringt einen auch wirklich vorwärts. Träume, aus denen Visionen entstehen, braucht aber nicht nur das Individuum für sich, sondern auch die Gesellschaft als Ganzes. Denn Visionen sind es, die Aktivitäten generieren. Wenn man sich in der Welt umblickt, entdeckt man mannigfaltige Probleme. Wir brauchen daher mehr Visionäre auf allen Gebieten, ganz besonders aber im Umweltschutz und beim Thema Klimawandel.",
        "Die Polarregionen haben mich schon immer fasziniert. Es sind die Regionen, in denen man dem Weltraum am nächsten ist: Ohne Hilfsmittel sind sie eigentlich nicht bewohnbar. Doch ist es nicht mehr unsere Aufgabe, Neuland zu erobern – es gibt heute auch keine weißen Flecken mehr auf der Landkarte. Die Erde ist entdeckt. Aber es gibt die weißen Flecken auf meiner persönlichen Landkarte. Ich selbst entdecke diese Landschaften und dabei auch mich selbst, indem ich mich mit diesen Naturlandschaften auseinandersetze.",
        "Das gilt in ganz besonderem Maße für eine Nordpolexpedition, die ich 1989 durchgeführt habe. Mit Teilnehmern aus acht verschiedenen Nationen, einem internationalen Team, tausend Kilometer unterwegs über diesen zugefrorenen Ozean – das ist nicht immer nur Spaß. Es ist auch eine Tour der Leiden, mit Erfrierungen und Ähnlichem. Aber man kommt dabei wirklich an die Natur heran. Ich persönlich verbinde sehr viel mit dieser Expedition. Dabei galt tatsächlich der Satz: Der Weg ist das Ziel. Das Zusammenwirken von acht unterschiedlichen Menschen aus acht verschiedenen Kulturkreisen, die sich zusammenraufen mussten, um diese schwierige Aufgabe zu meistern: Das ist eine Lebensschule.",
        "Wenn man mich fragt: „Wem nützt das?“, so ist meine Antwort: Zuallererst nützt es mir. Ich möchte das tun, und ich schade ja durch mein Tun niemandem. Ich realisiere solche Träume, solche Visionen für mich. Ich verstehe diese Expeditionen als eine Plattform, um Menschen Zugang zu diesen Landschaften zu gewähren, Menschen, die nicht selbst vor Ort sein können. Ich reise sozusagen als Stellvertreter dorthin, ich betreibe Lobbyarbeit für diese Naturlandschaften und die indigenen Völker, die dort leben und immer die Leidtragenden sind, wenn sich etwas verändert.",
        "Ich wollte nie aussteigen oder die Brücken hinter mir abbrechen. Mir ist das Leben hier auch sehr wichtig – Freunde und Familie bedeuten mir viel und auch die Annehmlichkeiten der Zivilisation weiß ich zu schätzen. Ich glaube, wenn man sich auf Dauer entfernt, versteht man nicht mehr, was die Menschen beschäftigt. Davor hatte ich immer ein wenig Angst. Heute habe ich sie nicht mehr, auch wenn ich einen Teil des Jahres in der Natur verbringe und anderen Gesetzmäßigkeiten unterworfen bin. Auf diesen Reisen in die Natur lernt man Demut – vor der Natur, vor der Schöpfung.",
        "Wir versuchen, unsere Eindrücke auch direkt an junge Menschen weiterzugeben. Im Sommer 2007 gab es auf Spitzbergen ein Jugendcamp, in das selbst Jugendliche aus China reisten, um sich unter wissenschaftlicher Anleitung theoretisches Grundwissen über die Polarregion anzueignen. Im zweiten Teil nahmen wir sie mit hinaus, damit sie praktisch erfuhren, was ein Gletscher ist. Wir wollen die Jugend begeistern für die Einzigartigkeit dieser Natur, damit sie als Botschafter dieser Landschaften in ihre Länder zurückkehren und bei ihren Altersgenossen als Multiplikatoren wirken.",
        "Bald werden wir wieder aufbrechen ins Eis, dann beginnt erneut die Wanderung von dieser Welt in die andere. Ich freue mich sehr darauf – so wie ich mich auch darauf freue, wieder nach Hause zurückzukehren."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Arved Fuchs findet Visionen wichtig, weil sie",
          "options": {
            "a": "die Menschen dazu bringen, etwas zu tun.",
            "b": "Menschen zeigen, wie man sich beruflich verwirklichen kann.",
            "c": "Politikern helfen, ihre Ziele umzusetzen."
          },
          "answer": "a",
          "explanation": "Im 3. Absatz heißt es: „Denn Visionen sind es, die Aktivitäten generieren.“"
        },
        {
          "num": 7,
          "stem": "Arved Fuchs meint, für die Menschen sei es eine Herausforderung,",
          "options": {
            "a": "immer neue Regionen zu entdecken.",
            "b": "in der Begegnung mit der Natur sich selbst besser kennenzulernen.",
            "c": "die Polarregion zu industrialisieren."
          },
          "answer": "b",
          "explanation": "Im 4. Absatz sagt er, dass die Erde zwar entdeckt sei, er aber die weißen Flecken auf seiner persönlichen Landkarte entdecke: „Ich selbst entdecke diese Landschaften und dabei auch mich selbst, indem ich mich mit diesen Naturlandschaften auseinandersetze.“"
        },
        {
          "num": 8,
          "stem": "Bei seiner Nordpolexpedition 1989 war für Arved Fuchs die wichtigste Erfahrung,",
          "options": {
            "a": "auch in der Kälte Spaß haben zu können.",
            "b": "ein zugefrorenes Meer zu überqueren.",
            "c": "mit Menschen aus verschiedenen Kulturen im Team zu arbeiten."
          },
          "answer": "c",
          "explanation": "Laut Absatz 5 war die Zusammenarbeit im internationalen Team entscheidend: „Das Zusammenwirken von acht unterschiedlichen Menschen aus acht verschiedenen Kulturkreisen, die sich zusammenraufen mussten, um diese schwierige Aufgabe zu meistern: Das ist eine Lebensschule.“"
        },
        {
          "num": 9,
          "stem": "Arved Fuchs sieht seine Expeditionen als eine Möglichkeit,",
          "options": {
            "a": "sanften Tourismus zu betreiben.",
            "b": "sich für Natur und Bewohner der Polarregionen zu engagieren.",
            "c": "wissenschaftliche Forschungen durchzuführen."
          },
          "answer": "b",
          "explanation": "Im 6. Absatz betont er: „... ich betreibe Lobbyarbeit für diese Naturlandschaften und die indigenen Völker, die dort leben und immer die Leidtragenden sind, wenn sich etwas verändert.“"
        },
        {
          "num": 10,
          "stem": "Das Ziel von Arved Fuchs ist es, dass Jugendliche",
          "options": {
            "a": "die Polarregion wissenschaftlich erforschen.",
            "b": "mit ihrem Engagement für die Polarregion andere Jugendliche anstecken.",
            "c": "später Botschafter ihrer Länder werden."
          },
          "answer": "b",
          "explanation": "Im vorletzten Absatz heißt es: „Wir wollen die Jugend begeistern für die Einzigartigkeit dieser Natur, damit sie als Botschafter dieser Landschaften in ihre Länder zurückkehren und bei ihren Altersgenossen als Multiplikatoren wirken.“"
        }
      ]
    },
    {
      "id": "26",
      "title": "Test 26 – Freizeitbegriff und Freizeitrituale",
      "isVariant": false,
      "paragraphs": [
        "Freizeitbegriff: Das Freizeitverständnis hat sich grundlegend gewandelt. Quantitativ und qualitativ unterscheidet sich die Freizeit heute von früheren Freizeitformen. Auch gegenwärtig findet Erholung von der Arbeit in der Freizeit statt, aber diese Freizeit ist nicht mehr nur – wie in den fünfziger Jahren – Erholungszeit. Für die überwiegende Mehrheit der Bevölkerung hat Freizeit einen eigenständigen Wert bekommen. So vertreten 70% der Bevölkerung die Auffassung, dass Freizeit in erster Linie eine Zeit ist, in der man tun und lassen kann, was einem Spaß macht. Aus einem arbeitsabhängigen Zeitbegriff, der Freizeit negativ als Abwesenheit von Arbeit definierte, hat sich heute ein positives Freizeitverständnis entwickelt: Freizeit ist eine Zeit, in der man frei ist.",
        "Über vierzig Jahre Arbeitszeitverkürzungen sind an den Menschen und ihrer Einstellung zum arbeitsfreien Teil des Lebens nicht spurlos vorübergegangen. Freizeit ist mehr als eine Pause, in der man sich für den nächsten Arbeitstag wieder erholt. Freizeit koppelt sich von der Arbeit ab: Nur für eine Minderheit der Bevölkerung ist Freizeit eine Zeit, die nicht mit Arbeit und Geldverdienen ausgefüllt ist (26%). Dies gilt für Arbeiter (38%) genauso wie für Angestellte (34%) oder Selbstständige (30%). Bei Freizeit denken die meisten erst einmal an den eigenen Spaß. Freizeit ist daher mehr ein positives Lebensgefühl als eine arbeitsabhängige Zeitkategorie. Im subjektiven Empfinden der Menschen sind „arbeitsfreie Zeit“ und „Freizeit“ nicht mehr dasselbe. Mit dem Wandel des subjektiven Freizeitverständnisses ist auch eine gesellschaftliche Neubewertung der Freizeit notwendiger denn je.",
        "Vor dem Hintergrund des wachsenden Anteils Nichterwerbstätiger lässt sich für die Zukunft unschwer prognostizieren: Freizeit verliert zunehmend ihre Bedeutung als arbeitsfreie Regenerationszeit. Umso mehr richten sich dann die Hoffnungen auf die Freizeit als Synonym für Lebensqualität und Wohlbefinden. Dies aber heißt: sich wohlfühlen, das tun und lassen können, was Spaß und Freude macht, und das Leben in eigener Regie gestalten sowie viel mit Familie und Freunden unternehmen.",
        "Freizeitrituale: Alles hat seine Regeln und Rituale, auch die Freizeit. Die Deutschen haben ihre Freizeit bestens organisiert: samstags auf die Piste und sonntags mit der Familie. Fast jeder dritte Bundesbürger reserviert regelmäßig einen Wochentag für Familie oder Ausgehen, für Sport oder Faulenzen. Mehr als 20% kennen ebenfalls einen festen Termin für Hobby, Verein oder Besuche. Und selbst der Badetag ist für jeden vierten Deutschen nach wie vor ein Begriff.",
        "Trotz kürzerer Arbeitszeiten konzentrieren sich die meisten Freizeittermine auf das lange Wochenende. Ausgehen und Besuche machen stehen ebenso auf dem Programm wie faulenzen, lesen oder sich dem Hobby widmen. So hat der Samstag für jeden dritten Bundesbürger seinen festen Platz als Hauptausgehtag. Den sonntäglichen Terminkalender bestimmen dann bei der Mehrheit der Befragten die beiden „F“: Faulenzen und Familie. Für viele wird damit der Sonntag zum Balanceakt zwischen eigener und gemeinsamer Freizeitgestaltung. Denn auch die Zweisamkeit darf nicht zu kurz kommen. Für sechs Prozent der Deutschen ist der siebte Tag der Woche ein „Schmusetag“.",
        "Freizeitrituale, bisher kaum erforscht, hatten im Alltagsleben der Bevölkerung schon immer ihren festen Platz. Was als liebe Gewohnheit oder Alltagsroutine beginnt, kann zur eingeübten Handlung und starren Ordnung werden: von den Begrüßungs-, Wasch- und Umziehritualen nach Feierabend bis zum gemeinsamen Frühstück und Familienspaziergang am Sonntag. Solche eingespielten und liebgewordenen Gewohnheiten geben den Menschen im Alltag Struktur und Halt. Gerade im Zusammenleben von Familienmitgliedern haben Rituale eine wichtige Stabilisierungsfunktion. Dahinter verbirgt sich das Bedürfnis nach Sicherheit und Geborgenheit, der Wunsch nach einem harmonischen Feierabend oder schönen Wochenende."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Siebzig Prozent der Bevölkerung meinen, dass Freizeit",
          "options": {
            "a": "nach den eigenen Vorlieben gestaltet werden soll.",
            "b": "nicht unbedingt positiv besetzt ist.",
            "c": "nur dem Ausruhen und Schlafen dienen sollte."
          },
          "answer": "a",
          "explanation": "Im 1. Absatz steht: „So vertreten 70% der Bevölkerung die Auffassung, dass Freizeit in erster Linie eine Zeit ist, in der man tun und lassen kann, was einem Spaß macht.“"
        },
        {
          "num": 7,
          "stem": "Die Mehrheit der Leute nutzt ihre Freizeit",
          "options": {
            "a": "für die eigenen Interessen.",
            "b": "zur Aufbesserung des Einkommens.",
            "c": "zur Regeneration für den nächsten Arbeitstag."
          },
          "answer": "a",
          "explanation": "Laut Absatz 2 ist Freizeit mehr als eine bloße Pause zur Regeneration: „Bei Freizeit denken die meisten erst einmal an den eigenen Spaß.“"
        },
        {
          "num": 8,
          "stem": "Die Deutschen",
          "options": {
            "a": "gehen nur an Wochenenden ihren Hobbys nach.",
            "b": "organisieren ihre Freizeit gar nicht.",
            "c": "organisieren ihre Freizeit meistens gut und reservieren für ihre Aktivitäten bestimmte Wochentage."
          },
          "answer": "c",
          "explanation": "Im 4. Absatz heißt es: „Die Deutschen haben ihre Freizeit bestens organisiert ... Fast jeder dritte Bundesbürger reserviert regelmäßig einen Wochentag für Familie oder Ausgehen, für Sport oder Faulenzen.“"
        },
        {
          "num": 9,
          "stem": "Der Sonntag ist bei vielen reserviert für",
          "options": {
            "a": "das Ausgehen.",
            "b": "die Freizeitgestaltung mit Freunden oder Kollegen.",
            "c": "Familie und Entspannung."
          },
          "answer": "c",
          "explanation": "Laut Absatz 5 ist der Samstag der Hauptausgehtag, während am Sonntag Folgendes gilt: „Den sonntäglichen Terminkalender bestimmen dann bei der Mehrheit der Befragten die beiden ‚F‘: Faulenzen und Familie.“"
        },
        {
          "num": 10,
          "stem": "Freizeitrituale",
          "options": {
            "a": "schwächen den Gruppenzusammenhalt.",
            "b": "sind für die moderne Familie nicht mehr von Bedeutung.",
            "c": "waren bislang noch nicht oft Gegenstand wissenschaftlicher Untersuchungen."
          },
          "answer": "c",
          "explanation": "Zu Beginn des letzten Absatzes wird erwähnt: „Freizeitrituale, bisher kaum erforscht, hatten im Alltagsleben der Bevölkerung schon immer ihren festen Platz.“"
        }
      ]
    },
    {
      "id": "26a",
      "title": "Test 26a – Freizeitbegriff und Freizeitrituale",
      "isVariant": true,
      "paragraphs": [
        "Freizeitbegriff: Das Freizeitverständnis hat sich grundlegend gewandelt. Quantitativ und qualitativ unterscheidet sich die Freizeit heute von früheren Freizeitformen. Auch gegenwärtig findet Erholung von der Arbeit in der Freizeit statt, aber diese Freizeit ist nicht mehr nur – wie in den fünfziger Jahren – Erholungszeit. Für die überwiegende Mehrheit der Bevölkerung hat Freizeit einen eigenständigen Wert bekommen. So vertreten 70% der Bevölkerung die Auffassung, dass Freizeit in erster Linie eine Zeit ist, in der man tun und lassen kann, was einem Spaß macht. Aus einem arbeitsabhängigen Zeitbegriff, der Freizeit negativ als Abwesenheit von Arbeit definierte, hat sich heute ein positives Freizeitverständnis entwickelt: Freizeit ist eine Zeit, in der man frei ist.",
        "Über vierzig Jahre Arbeitszeitverkürzungen sind an den Menschen und ihrer Einstellung zum arbeitsfreien Teil des Lebens nicht spurlos vorübergegangen. Freizeit ist mehr als eine Pause, in der man sich für den nächsten Arbeitstag wieder erholt. Freizeit koppelt sich von der Arbeit ab: Nur für eine Minderheit der Bevölkerung ist Freizeit eine Zeit, die nicht mit Arbeit und Geldverdienen ausgefüllt ist (26%). Dies gilt für Arbeiter (38%) genauso wie für Angestellte (34%) oder Selbstständige (30%). Bei Freizeit denken die meisten erst einmal an den eigenen Spaß. Freizeit ist daher mehr ein positives Lebensgefühl als eine arbeitsabhängige Zeitkategorie. Im subjektiven Empfinden der Menschen sind „arbeitsfreie Zeit“ und „Freizeit“ nicht mehr dasselbe. Mit dem Wandel des subjektiven Freizeitverständnisses ist auch eine gesellschaftliche Neubewertung der Freizeit notwendiger denn je.",
        "Vor dem Hintergrund des wachsenden Anteils Nichterwerbstätiger lässt sich für die Zukunft unschwer prognostizieren: Freizeit verliert zunehmend ihre Bedeutung als arbeitsfreie Regenerationszeit. Umso mehr richten sich dann die Hoffnungen auf die Freizeit als Synonym für Lebensqualität und Wohlbefinden. Dies aber heißt: sich wohlfühlen, das tun und lassen können, was Spaß und Freude macht, und das Leben in eigener Regie gestalten sowie viel mit Familie und Freunden unternehmen.",
        "Freizeitrituale: Alles hat seine Regeln und Rituale, auch die Freizeit. Die Deutschen haben ihre Freizeit bestens organisiert: samstags auf die Piste und sonntags mit der Familie. Fast jeder dritte Bundesbürger reserviert regelmäßig einen Wochentag für Familie oder Ausgehen, für Sport oder Faulenzen. Mehr als 20% kennen ebenfalls einen festen Termin für Hobby, Verein oder Besuche. Und selbst der Badetag ist für jeden vierten Deutschen nach wie vor ein Begriff.",
        "Trotz kürzerer Arbeitszeiten konzentrieren sich die meisten Freizeittermine auf das lange Wochenende. Ausgehen und Besuche machen stehen ebenso auf dem Programm wie faulenzen, lesen oder sich dem Hobby widmen. So hat der Samstag für jeden dritten Bundesbürger seinen festen Platz als Hauptausgehtag. Den sonntäglichen Terminkalender bestimmen dann bei der Mehrheit der Befragten die beiden „F“: Faulenzen und Familie. Für viele wird damit der Sonntag zum Balanceakt zwischen eigener und gemeinsamer Freizeitgestaltung. Denn auch die Zweisamkeit darf nicht zu kurz kommen. Für sechs Prozent der Deutschen ist der siebte Tag der Woche ein „Schmusetag“.",
        "Freizeitrituale, bisher kaum erforscht, hatten im Alltagsleben der Bevölkerung schon immer ihren festen Platz. Was als liebe Gewohnheit oder Alltagsroutine beginnt, kann zur eingeübten Handlung und starren Ordnung werden: von den Begrüßungs-, Wasch- und Umziehritualen nach Feierabend bis zum gemeinsamen Frühstück und Familienspaziergang am Sonntag. Solche eingespielten und liebgewordenen Gewohnheiten geben den Menschen im Alltag Struktur und Halt. Gerade im Zusammenleben von Familienmitgliedern haben Rituale eine wichtige Stabilisierungsfunktion. Dahinter verbirgt sich das Bedürfnis nach Sicherheit und Geborgenheit, der Wunsch nach einem harmonischen Feierabend oder schönen Wochenende."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "70 % der Bevölkerung meinen, dass Freizeit",
          "options": {
            "a": "„Freiheit für etwas“ bedeutet.",
            "b": "gleichbedeutend ist mit „nicht arbeiten“.",
            "c": "nur der Erholung dienen sollte."
          },
          "answer": "a",
          "explanation": "Laut Absatz 1 vertreten 70 % die Auffassung, dass man in der Freizeit tun und lassen kann, was Spaß macht; aus der negativen Definition als „Abwesenheit von Arbeit“ wurde ein positives Verständnis („eine Zeit, in der man frei ist“)."
        },
        {
          "num": 7,
          "stem": "Die Mehrheit der Leute nutzen ihre Freizeit",
          "options": {
            "a": "um ihr Einkommen aufzubessern.",
            "b": "um sich für den nächsten Arbeitstag zu regenerieren.",
            "c": "zum eigenen Vergnügen."
          },
          "answer": "c",
          "explanation": "Im 2. Absatz steht: „Bei Freizeit denken die meisten erst einmal an den eigenen Spaß.“"
        },
        {
          "num": 8,
          "stem": "Wie die Deutschen ihre Freizeit organisieren:",
          "options": {
            "a": "Ein Drittel der Deutschen hat ein festes Hobby.",
            "b": "Für die einzelnen Aktivitäten werden oft bestimmte Tage reserviert.",
            "c": "Jeder Fünfte faulenzt mit der Familie."
          },
          "answer": "b",
          "explanation": "Im 4. Absatz heißt es: „Fast jeder dritte Bundesbürger reserviert regelmäßig einen Wochentag für Familie oder Ausgehen, für Sport oder Faulenzen.“"
        },
        {
          "num": 9,
          "stem": "Der Sonntag ist von vielen reserviert für",
          "options": {
            "a": "das Ausgehen.",
            "b": "die eigene Freizeitgestaltung.",
            "c": "Familie und Entspannung."
          },
          "answer": "c",
          "explanation": "Im 5. Absatz steht: „Den sonntäglichen Terminkalender bestimmen dann bei der Mehrheit der Befragten die beiden ‚F‘: Faulenzen und Familie.“"
        },
        {
          "num": 10,
          "stem": "Freizeitrituale",
          "options": {
            "a": "Freizeitrituale schwächen den Gruppenzusammenhalt.",
            "b": "Für die moderne Familie sind Freizeitrituale nicht mehr von Bedeutung.",
            "c": "Über das Freizeitverhalten der Deutschen gibt es nur wenige wissenschaftliche Untersuchungen."
          },
          "answer": "c",
          "explanation": "Im letzten Absatz wird betont, dass „Freizeitrituale, bisher kaum erforscht“, im Alltag schon immer ihren festen Platz hatten."
        }
      ]
    },
    {
      "id": "27",
      "title": "Test 27 – Alles Englisch oder was?",
      "isVariant": false,
      "paragraphs": [
        "Werbeagenturen bevorzugen englischsprachige Werbebotschaften",
        "Die Welt der Werbung wird in Deutschland zunehmend Englisch: „Come in and find out“ wirbt eine Kosmetikkette, „We can help“ bietet ein Telekommunikationsunternehmen auf Werbeseiten in Zeitschriften an, „Think what you drink“ fordert eine Getränkefirma werbewirksam. Doch auch in deutschsprachigen Werbesprüchen steckt vermehrt Englisches: alles ist easy, das Messaging-Mobiltelefon der neueste Schrei.",
        "In Werbekreisen gilt die englische Sprache als fortschrittlich, zukunftsweisend und weltoffen. „Die Zukunft ist Englisch.“ Diese Aussage scheint Werbetexter und Marketingstrategen bei der Auswahl ihrer Werbebotschaften zu leiten. Die USA wecken bei vielen Menschen Träume von Freiheit und unbegrenzten Möglichkeiten. Warum also nicht die Sprache Amerikas gewinnbringend einsetzen, auf dass sich deutsche Produkte in Deutschland besser verkaufen? Und außerdem sind da auch noch handfeste finanzielle Interessen: Eine Werbeanzeige für den globalen Markt muss – in der Sprache der globalen Welt, auf Englisch abgefasst – nur einmal hergestellt werden, ohne teure nationale Varianten.",
        "Ob allerdings die Konsumenten genauso reagieren, wie es sich die Englisch denkende Werbebranche erhofft, das darf jetzt angezweifelt werden. Eine Untersuchung an der Universität Dortmund brachte es an den Tag. Werbesprüche auf Deutsch kommen viel besser bei den deutschen Käufern an als fremdsprachige. Deutsche Werbesprüche bedienen sich oft des Wortspiels und des Wortwitzes. Das „Geiz ist geil“ eines Elektronikmarktes, das „erste Mahl vergisst man nie“ für ein Agrarprodukt aus Deutschland oder das „Wohnst du noch oder lebst du schon?“ eines schwedischen Möbelhauses haben auf die Konsumenten eine starke Wirkung. Deutsche Werbesprüche prägen sich ein, werden sogar zu allgemeinen Bestandteilen der Umgangssprache, die in alltäglichen Situationen völlig losgelöst von der Werbung für ihr Produkt verwendet werden.",
        "Deutsche Werbesprüche wie der einer Haushaltsgerätefirma, die weiß, was Frauen wünschen, oder der für eine Schokolade, die quadratisch, praktisch, gut ist, wurden bereits vor Jahrzehnten eingeführt und sind immer noch in Gebrauch, in der Werbung wie in der Alltagssprache. Besonders die Kundschaft über 40 lässt sich von deutschsprachigen Botschaften um ein Vielfaches leichter überzeugen als von englischen. Aber auch junge Leute in Deutschland schätzen es, dass sich der Sinn der Werbeaussage für sie in der Muttersprache eher erschließt als im Global-Englisch, das für die deutsche Kundschaft oft überhaupt keinen Sinn ergibt."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Werbeanzeigen in Deutschland sind",
          "options": {
            "a": "nur noch auf Englisch.",
            "b": "immer häufiger auf Englisch.",
            "c": "zunehmend, seitdem sie auf Englisch sind."
          },
          "answer": "b",
          "explanation": "Gleich im ersten Satz heißt es: „Die Welt der Werbung wird in Deutschland zunehmend Englisch“."
        },
        {
          "num": 7,
          "stem": "Die englische Sprache",
          "options": {
            "a": "wird von den Werbemachern für die Sprache der Zukunft gehalten.",
            "b": "wird in Zukunft von den meisten Menschen gesprochen werden.",
            "c": "wird in Zukunft in den Werbeagenturen gesprochen werden."
          },
          "answer": "a",
          "explanation": "Im 2. Absatz steht: „In Werbekreisen gilt die englische Sprache als fortschrittlich, zukunftsweisend und weltoffen. ‚Die Zukunft ist Englisch.‘ Diese Aussage scheint Werbetexter und Marketingstrategen bei der Auswahl ihrer Werbebotschaften zu leiten.“"
        },
        {
          "num": 8,
          "stem": "Manche Werbesprüche auf Deutsch",
          "options": {
            "a": "werden zu Witzen, die sich die Leute erzählen.",
            "b": "werden von den Leuten stark konsumiert.",
            "c": "vergessen die Leute nicht."
          },
          "answer": "c",
          "explanation": "Im 3. und 4. Absatz heißt es: „Deutsche Werbesprüche prägen sich ein“ und bekannte Sprüche „wurden bereits vor Jahrzehnten eingeführt und sind immer noch in Gebrauch“."
        },
        {
          "num": 9,
          "stem": "Werbesprüche",
          "options": {
            "a": "erreichen besonders gut die Wünsche der Frauen.",
            "b": "werden seit Jahrzehnten vorwiegend zu Werbezwecken benutzt.",
            "c": "können zu Redewendungen in der Umgangssprache werden."
          },
          "answer": "c",
          "explanation": "Im 3. Absatz steht, dass deutsche Werbesprüche „sogar zu allgemeinen Bestandteilen der Umgangssprache“ werden, die im Alltag losgelöst vom Produkt verwendet werden."
        },
        {
          "num": 10,
          "stem": "Deutsche Konsumenten",
          "options": {
            "a": "verstehen manchmal nicht, was mit englischen Werbeaussagen gemeint ist.",
            "b": "haben keinen Sinn für die englische Sprache.",
            "c": "können oft kein Englisch."
          },
          "answer": "a",
          "explanation": "Am Ende des letzten Absatzes wird erklärt, dass sich der Sinn einer Werbeaussage in der Muttersprache eher erschließt „als im Global-Englisch, das für die deutsche Kundschaft oft überhaupt keinen Sinn ergibt“."
        }
      ]
    },
    {
      "id": "28",
      "title": "Test 28 – Dialekte in Deutschland",
      "isVariant": false,
      "paragraphs": [
        "Wie heißt das runde Gebäck, das viele Leute so gerne zum Frühstück essen, in Ihrer Region? Semmel vielleicht? Oder Weck? Oder Schrippe? Im Atlas zur deutschen Alltagssprache (AdA) werden mehr als zehn verschiedene Begriffe für Brötchen aufgelistet, die in unterschiedlichen Regionen Deutschlands verwendet werden.",
        "Dialekte, oder auch Mundarten genannt, sind regionale Varianten einer Sprache. Sie unterscheiden sich nicht nur im Wortschatz (z. B. Brötchen vs. Schrippe), sondern auch in der Grammatik und in der Aussprache von anderen Varianten der gleichen Sprache. In Deutschland gibt es knapp 20 große Dialektgruppen, die wiederum in zahlreiche Untergruppen aufgeteilt sind.",
        "Jeder zweite Deutsche gibt an, einen Dialekt sprechen zu können. Besonders viele Dialektsprecher findet man im Süden und Südwesten Deutschlands, und so scheint es nicht verwunderlich, dass Bairisch zu den Dialekten gehört, die in Deutschland am meisten gesprochen und außerdem als besonders sympathisch empfunden werden. Auf der Beliebtheitsskala der deutschen Dialekte rangiert Bairisch in der Regel sehr weit oben und landete in diesem Jahr – wie auch schon im Vorjahr – auf dem zweiten Platz, hinter dem Spitzenreiter Norddeutsch. Auf den Plätzen dahinter folgten Berlinerisch und Rheinländisch, die insgesamt ebenfalls sehr positiv bewertet wurden.",
        "Die Beliebtheitsskalen sollen aber nicht darüber hinwegtäuschen, dass Dialekte in Deutschland oft ein Imageproblem haben. Menschen, die Hochdeutsch sprechen, werden häufig als gebildeter und intelligenter wahrgenommen als Dialektsprecher – völlig zu Unrecht, wie man inzwischen weiß. Dennoch hält sich das Vorurteil hartnäckig und die Ursachen dafür liegen oft in der Schulzeit. Sara Thiel (24) studiert Sprachwissenschaften und erinnert sich: „Bei uns auf dem Gymnasium war es verpönt, Dialekt zu sprechen. Wer kein Hochdeutsch sprach, wurde von den Lehrern immer wieder ermahnt, doch ‚richtiges Deutsch‘ zu sprechen. Manche Mitschüler machten sich über Dialektsprecher sogar lustig. Das hat mich damals so sehr geprägt, dass ich mir den Dialekt, den ich als Kind von meinen Eltern übernommen hatte, bewusst abgewöhnt habe. Inzwischen bereue ich das und wünschte mir, Dialekt sprechen zu können. Es ist schließlich ein Stück unserer Kultur.“",
        "Das schlechte Image, das viele Dialekte hatten – und zum Teil noch haben – ist sicherlich auch einer der Gründe, warum sie immer weniger gesprochen werden. Während Anfang der 90er-Jahre noch etwa 40 Prozent der Menschen in Ostdeutschland behaupteten, Dialekt sei ihre normale Alltagssprache, sind es heute nur noch knapp über 30 Prozent. In Westdeutschland ist die Entwicklung ähnlich rückläufig. Dass Dialekte in Zukunft komplett aussterben könnten, wie immer wieder vorhergesagt wird, ist trotzdem nicht zu befürchten. Wahrscheinlich ist allerdings, dass sich lokale Dialekte, die nur in kleinen Regionen gesprochen werden, immer mehr angleichen. Das läuft darauf hinaus, dass es voraussichtlich irgendwann weniger und dafür großräumigere Dialekte geben wird. Diesen Veränderungen sehen einige gelassen entgegen – mit der Begründung, dass Sprache nicht statisch sei, sondern immer in Bewegung. Andere dagegen versuchen, den Rückzug der Dialekte aufzuhalten und den Stellenwert der Mundarten gezielt zu stärken.",
        "Viele Initiativen, die das Dialektsprechen fördern wollen, sind an Schulen ins Leben gerufen worden. Der Dialekt in Hamburg heißt Plattdeutsch und wurde dort im Jahr 2010 an einigen Grundschulen sogar als eigenes Schulfach eingeführt. Denn man hatte festgestellt, dass der Anteil der Menschen, die Plattdeutsch sprechen, immer weiter sank – und Untersuchungen zeigen zudem, dass Kinder, die mit einem Dialekt aufwachsen, später leichter Fremdsprachen lernen."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Bairisch",
          "options": {
            "a": "belegt zum zweiten Mal Platz eins auf der Beliebtheitsskala.",
            "b": "war im letzten Jahr beliebter als der norddeutsche Dialekt.",
            "c": "wurde in diesem Jahr positiver bewertet als Berlinerisch."
          },
          "answer": "c",
          "explanation": "Im 3. Absatz steht, dass Bairisch hinter Norddeutsch auf dem zweiten Platz landete und erst „auf den Plätzen dahinter folgten Berlinerisch und Rheinländisch“."
        },
        {
          "num": 7,
          "stem": "Sara Thiel hat",
          "options": {
            "a": "ihre Einstellung zum Dialektsprechen geändert.",
            "b": "während ihrer gesamten Schulzeit Dialekt gesprochen.",
            "c": "während ihrer Schulzeit keine negativen Erfahrungen mit ihrem Dialekt gemacht."
          },
          "answer": "a",
          "explanation": "Im 4. Absatz berichtet Sara Thiel, dass sie sich den Dialekt in der Schulzeit bewusst abgewöhnt hat, dies aber inzwischen bereut und sich wünscht, Dialekt sprechen zu können."
        },
        {
          "num": 8,
          "stem": "In Zukunft wird",
          "options": {
            "a": "es deutschlandweit keine Dialekte mehr geben.",
            "b": "es in Deutschland nicht mehr so viele unterschiedliche Dialekte geben.",
            "c": "man nur noch in Ostdeutschland Dialekt sprechen."
          },
          "answer": "b",
          "explanation": "Laut Absatz 5 sterben Dialekte nicht komplett aus, gleichen sich aber an, sodass „es voraussichtlich irgendwann weniger und dafür großräumigere Dialekte geben wird“."
        },
        {
          "num": 9,
          "stem": "Im Bundesland Hamburg",
          "options": {
            "a": "ist die Anzahl der Dialektsprecher um zehn Prozent gesunken.",
            "b": "können Grundschulkinder seit 2010 in der Schule Plattdeutsch lernen.",
            "c": "können immer noch viele Menschen Plattdeutsch sprechen."
          },
          "answer": "b",
          "explanation": "Im letzten Absatz heißt es: „Der Dialekt in Hamburg heißt Plattdeutsch und wurde dort im Jahr 2010 an einigen Grundschulen sogar als eigenes Schulfach eingeführt.“"
        },
        {
          "num": 10,
          "stem": "Eine Untersuchung zeigt, dass",
          "options": {
            "a": "Dialekte keinen Einfluss auf die Lernfähigkeit haben.",
            "b": "Dialektsprecher leichter Fremdsprachen lernen.",
            "c": "Kinder, die Dialekt sprechen, mehr Probleme mit Fremdsprachen haben."
          },
          "answer": "b",
          "explanation": "Laut dem letzten Abschnitt des Textes (und der offiziellen Lösung) belegen Untersuchungen zur Förderung von Mundarten an Schulen, dass Dialektsprecher leichter Fremdsprachen lernen."
        }
      ]
    },
    {
      "id": "29",
      "title": "Test 29 – Kaffeehäuser werben für Wien",
      "isVariant": false,
      "paragraphs": [
        "Wien als Stätte eines besonderen Lebensstils – Stichwort Kaffeehaus – in aller Welt noch bekannter zu machen, hat sich eine Fachgruppe der Kaffeehäuser vorgenommen.",
        "Für den „echten Wiener“ gibt es tausenderlei Gründe, um ins Kaffeehaus zu gehen: um Kaffee zu trinken, um Zeitungen zu lesen, um geschäftliche oder private Rendezvous zu erledigen, um zu philosophieren oder nur vor sich hin zu meditieren, um Schach, Billard oder Bridge zu spielen, um Bücher zu schreiben – kurz gesagt, um bewusster als sonst üblich zu leben.",
        "Die Fachgruppe der Wiener Kaffeehäuser versucht nun im Rahmen einer groß angelegten Aktion, diese Wiener Kaffeehaus-Kultur wieder mehr ins Rampenlicht zu stellen und damit den Bekanntheitsgrad von Wien als Stätte eines besonderen Lebensstils im Ausland zu erhöhen. Dabei wendet sie sich gezielt an internationale Journalisten, die sich bei größeren Anlässen oft zu Tausenden in Wien befinden. Ihnen will man in Zukunft den Stellenwert des Kaffeehauses in dieser Stadt quasi brühheiß servieren. Die Wiener Kaffeehäuser werden zum Treffpunkt der Weltpresse.",
        "Laut Pressechef der Wirtschaftskammer stammt die Grundidee für diese Aktion von Franz Grundwalt, dem Vorgänger des jetzigen Fachgruppenvorstehers Hans Diglas. Diglas und seine Mitstreiter nahmen den Gedanken voll Engagement auf. Das Konzept für „Wien Brüh-Heiß“ liegt nun vor und verspricht einige interessante Events.",
        "Geplant sind Veranstaltungen, die das Vielschichtige, Farbenfrohe, ja manchmal Skurrile der Wiener veranschaulichen und ein Streiflicht auf alten Wiener Schmäh mit junger Wiener Szene werfen. Vorsteher Diglas rechnet damit, dass etwa 150 ausländische Medienvertreter an der ersten offiziellen Veranstaltung Ende des Monats im Café Landtmann, das heuer zudem seinen 125. Geburtstag feiert, teilnehmen werden. Bei einem typischen Wiener Buffet, vom Tafelspitz bis zu Wiener Schmankerln, werden die Gäste aus aller Welt verwöhnt und danach gibt es – anstatt der üblicherweise schwer verdaulichen Vorträge und Ansprachen – eine Damenkapelle mit einer musikalischen „Wiener Melange“. Denn Musik ist bekanntlich jene Sprache, die auf der ganzen Welt verstanden wird. Als Draufgabe gibt es am Ende für jeden Teilnehmer eine in drei Sprachen abgefasste Informationsbroschüre, die über die Geschichte des Wiener Kaffeehauses informiert, alte Wiener Rezepte verbreitet sowie eine Fülle von Wissenswertem anbietet.",
        "Jeder einzelne Journalist hat also die Möglichkeit, persönliche Eindrücke und eigene Notizen mit fundierten Informationen zu versehen und kann so schnell und ohne größeren Aufwand seiner Redaktion einen Artikel zukommen lassen. Um den guten Ruf des Wiener Kaffeehauses in aller Welt zu verbreiten, und zu verkünden, dass die Kaffeehäuser eine der wichtigsten Sehenswürdigkeiten dieser Stadt sind."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Das Ziel der Aktion der „Fachgruppe für Wiener Kaffeehäuser“ ist,",
          "options": {
            "a": "das Angebot in Wiens Kaffeehäusern zu verbessern.",
            "b": "die Zahl der Kaffeehäuser in Wien wieder zu erhöhen.",
            "c": "Wien und die Wiener Kaffeehaus-Kultur bekannter zu machen."
          },
          "answer": "c",
          "explanation": "Bereits im Vorspann und im 2. Absatz steht, dass die Fachgruppe vorhat, „diese Wiener Kaffeehaus-Kultur wieder mehr ins Rampenlicht zu stellen und damit den Bekanntheitsgrad von Wien als Stätte eines besonderen Lebensstils im Ausland zu erhöhen“."
        },
        {
          "num": 7,
          "stem": "Die Aktion der „Fachgruppe für Wiener Kaffeehäuser“ richtet sich vor allem",
          "options": {
            "a": "an ausländische Touristen.",
            "b": "an die Wiener Bevölkerung.",
            "c": "an internationale Journalisten."
          },
          "answer": "c",
          "explanation": "Im 2. Absatz heißt es: „Dabei wendet sie sich gezielt an internationale Journalisten, die sich bei größeren Anlässen oft zu Tausenden in Wien befinden.“"
        },
        {
          "num": 8,
          "stem": "Die Idee für diese Aktion",
          "options": {
            "a": "hatte der Vorgänger von Hans Diglas.",
            "b": "hatten die Mitarbeiter von Hans Diglas.",
            "c": "hatte der Pressechef der Wirtschaftskammer."
          },
          "answer": "a",
          "explanation": "Im 3. Absatz steht: „Laut Pressechef der Wirtschaftskammer stammt die Grundidee für diese Aktion von Franz Grundwalt, dem Vorgänger des jetzigen Fachgruppenvorstehers Hans Diglas.“"
        },
        {
          "num": 9,
          "stem": "Bei den Veranstaltungen gibt es",
          "options": {
            "a": "ein Buffet und Musik.",
            "b": "einen Vortrag in drei Sprachen.",
            "c": "typische Wiener Kaffee-Spezialitäten."
          },
          "answer": "a",
          "explanation": "Im 4. Absatz wird beschrieben, dass die Gäste „bei einem typischen Wiener Buffet“ verwöhnt werden und es danach statt Vorträgen „eine Damenkapelle mit einer musikalischen ‚Wiener Melange‘“ gibt."
        },
        {
          "num": 10,
          "stem": "Am Ende bekommen die Teilnehmer",
          "options": {
            "a": "ein Buch für persönliche Eindrücke und Notizen.",
            "b": "einen Artikel über Wiens bekannteste Kaffeehaus-Journalisten.",
            "c": "viele Informationen über die Wiener Kaffeehäuser und deren Geschichte."
          },
          "answer": "c",
          "explanation": "Laut Absatz 4 erhält am Ende jeder Teilnehmer „eine in drei Sprachen abgefasste Informationsbroschüre, die über die Geschichte des Wiener Kaffeehauses informiert, alte Wiener Rezepte verbreitet sowie eine Fülle von Wissenswertem anbietet“."
        }
      ]
    },
    {
      "id": "30",
      "title": "Test 30 – Lustvolles Lernen im Futurum",
      "isVariant": false,
      "paragraphs": [
        "Schweden erprobt die Schule der Zukunft – ohne Stundenplan und Klassenzimmer",
        "Es war eine Klassenfahrt ins gelobte Gesamtschulland: Die Gewerkschaft Erziehung und Wissenschaft (GEW) hatte Ende Januar 18 deutsche Erziehungswissenschaftler und Journalisten zu einem Besuch nach Schweden eingeladen, und siehe da, die Reisenden waren beeindruckt. Selbst gestandene Kritiker dieser Schulform kamen ins Grübeln. „Was ich hier gesehen habe, kann selbst einen Gesamtschulgegner wie mich dazu bringen, seine Meinung zu ändern. Ich bin begeistert“, schwärmte ein Kollege.",
        "Schweden steht gut da im internationalen Schulvergleich. Und das, obwohl die Skandinavier ein Schulsystem pflegen, das hierzulande vielen als zweite oder dritte Wahl gilt. Bis zur achten Klasse werden die schwedischen Schüler nicht benotet und bis zur neunten gemeinsam unterrichtet.",
        "Aber das Etikett Gesamtschule allein sagt wenig. Einer der Reisenden, der Schulforscher Hans-Günther Rolff, erinnerte sich, wie er vor mehr als 30 Jahren hoffnungsvoll nach Schweden fuhr, das schon seit 1962 nur noch die Einheitsschule kennt. Damals fand er nichts, was ihn hätte begeistern können. Alle Schüler besuchten zwar die gleiche Schulform, aber am Unterricht hatte sich nichts geändert.",
        "Diesmal traute Rolff seinen Augen nicht und staunte beispielsweise über eine Schule, die sich selbstbewusst Futurum (lateinisch für „Zukunft“) nennt. Schon die Architektur erinnert nicht mehr an Schule. Die Besucher haben den Eindruck einer Führung durch Ateliers und Labors. Sie sehen Räume, in denen Schüler gemeinsam in Arbeitsgruppen oder still für sich lernen, staunen im Lehrerbüro über Schreibtisch und Computer für jeden Pädagogen oder über ein professionelles Musikstudio. Alle Räume sind um einen runden, hellen Großraum gebaut, der an einen Dorfplatz erinnert. Nach zwei Stunden fragt einer der Bildungstouristen den Lehrer, der uns führt: „Können wir denn auch mal Unterricht sehen?“ Das Echo kommt prompt: „Das hier ist unser Unterricht.“",
        "Futurum ist ein Umbau – übrigens sind alle Schulen in Habo, einem Landkreis 40 Kilometer westlich von Stockholm, neu oder umgebaut. Die Region gilt als besonders aufstrebende Region in Schweden und versucht, mit ihren Bildungsangeboten junge Familien anzuziehen. Futurum begeistert Menschen, die gewohnt sind, in Teams, offenen Büros und nach ein paar Jahren an etwas ganz anderem zu arbeiten. Etwa zehn Prozent der schwedischen Schulen haben wie Futurum begonnen, nicht nur Lehrpläne und die Methoden des Unterrichts zu reformieren, sondern auch den Raum und die Zeit neu zu definieren, in denen der Unterricht stattfindet. Als „Schritte aus der Industrie- in die Wissensgesellschaft“ bezeichnet dies der Lehrer Hans Ahlenius.",
        "Konkret sieht die praktizierte Zukunft so aus: Auf rund tausend Schüler kommen 180 Lehrer, also fünf bis sechs Schüler pro Pädagoge (von denen viele Teilzeitbeschäftigte sind). Alle verteilen sich auf sechs kleine Schulen, die jeweils um einen dieser an freie Plätze erinnernden Gemeinschaftsräume gruppiert sind. Zu diesen kleinen Schulen gehören rund 160 Kinder und Jugendliche im Alter von 6 bis 16 Jahren. Sie sind abermals in zwei Stämme geteilt, hier die Klassen eins bis vier, dort die Fünfte bis zur Neunten. „Je älter die Schüler sind“, erklärt Hans Ahlenius, „desto stärker sind die Altersgruppen gemischt. Da lernt zum Beispiel in Physik ein 12-Jähriger zusammen mit 15-Jährigen.“",
        "Im schwedischen Futurum dokumentiert jeder Schüler täglich in einem „Logbuch“, was er sich vornimmt und was er dann auch getan hat. Notiert werden auch die nächsten, mit den Lehrern vereinbarten Lernschritte. Das Logbuch ist somit ein individueller Lehrplan, der sogar den Stundenplan ersetzt. Es ist Sache der Schüler, ob sie ihre wöchentlichen Matheübungen am Mittwochnachmittag oder erst am Donnerstag machen. Aber sie müssen wöchentlich darüber Rechenschaft ablegen und zu den verabredeten Instruktionen und Besprechungen mit den Lehrern kommen. Die finden vor großem Auditorium oder in ganz kleinen Gruppen statt. Diese Lehrveranstaltungen machen höchstens die Hälfte der Unterrichtszeit aus. „Davon sind wir wenigstens noch ein Jahrzehnt entfernt“, seufzt der Essener Bildungswissenschaftler Klaus Klemm nicht ohne Neid.",
        "Das derzeit wichtigste Thema an den schwedischen Schulen heiße Individualisierung oder „Wie man den Schülern die Lust am Lernen erhält“, sagt Mats Ekholm, Direktor der nationalen Bildungsagentur Skolverket. Seine Agentur überwacht den Abschlusstest, den auch im Futurum alle Schüler am Ende ihrer Gesamtschulkarriere in Schwedisch, Mathematik und Englisch absolvieren müssen. Diese Prüfungen ermöglichen einen landesweiten Vergleich des Leistungsstandes der Schulen, der im Internet veröffentlicht wird. Für die deutschen Gäste wiederholt Ekholm die einfache Maxime: „Alle Kinder bringen die Lust am Lernen mit. Es gilt nur, diese zu erhalten.“"
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Der Schulforscher Hans-Günther Rolff",
          "options": {
            "a": "arbeitet seit 1962 in Schweden.",
            "b": "hält das schwedische Schulsystem für zweit- oder drittklassig.",
            "c": "war vom schwedischen Schulsystem zunächst nicht überzeugt."
          },
          "answer": "c",
          "explanation": "Im 3. Absatz heißt es über Rolffs erste Reise vor mehr als 30 Jahren: „Damals fand er nichts, was ihn hätte begeistern können.“"
        },
        {
          "num": 7,
          "stem": "Gelernt wird im Futurum in Arbeitsgruppen",
          "options": {
            "a": "immer unter Anleitung von Pädagogen.",
            "b": "unterschiedlichen Alters.",
            "c": "immer zu gleichen Uhrzeiten."
          },
          "answer": "b",
          "explanation": "Im 6. Absatz erklärt der Lehrer Hans Ahlenius: „Je älter die Schüler sind, desto stärker sind die Altersgruppen gemischt. Da lernt zum Beispiel in Physik ein 12-Jähriger zusammen mit 15-Jährigen.“"
        },
        {
          "num": 8,
          "stem": "Futurum ist als Schule attraktiv, weil",
          "options": {
            "a": "die Ausstattung besonders gut ist.",
            "b": "die Schule mitten auf einem Dorfplatz angesiedelt ist.",
            "c": "jeder Schüler einen eigenen Schreibtisch und Computer hat."
          },
          "answer": "a",
          "explanation": "Im 4. Absatz staunen die Besucher über die moderne Ausstattung wie Ateliers, Labors, ein professionelles Musikstudio sowie einen eigenen Schreibtisch und Computer für jeden Pädagogen."
        },
        {
          "num": 9,
          "stem": "Die Schüler",
          "options": {
            "a": "besprechen ihre Lernschritte grundsätzlich in kleinen Gruppen.",
            "b": "besprechen täglich ihre Lernschritte mit ihren Lehrern.",
            "c": "tragen ihre Lernschritte in ein Logbuch ein."
          },
          "answer": "c",
          "explanation": "Im 7. Absatz steht: „Im schwedischen Futurum dokumentiert jeder Schüler täglich in einem ‚Logbuch‘, was er sich vornimmt und was er dann auch getan hat. Notiert werden auch die nächsten, mit den Lehrern vereinbarten Lernschritte.“"
        },
        {
          "num": 10,
          "stem": "Im Futurum",
          "options": {
            "a": "gibt es einen Abschlusstest in drei Fächern.",
            "b": "gibt es insgesamt 160 Schüler.",
            "c": "lernen 6- und 16-Jährige gemeinsam."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz heißt es, dass die Bildungsagentur „den Abschlusstest, den auch im Futurum alle Schüler am Ende ihrer Gesamtschulkarriere in Schwedisch, Mathematik und Englisch absolvieren müssen“, überwacht."
        }
      ]
    },
    {
      "id": "31",
      "title": "Test 31 – Ab wann ist Kaffee ungesund?",
      "isVariant": false,
      "paragraphs": [
        "Kaffee, Espresso und Cappuccino schmecken gut und helfen aus dem Konzentrationstief. Aber wie viele Tassen am Tag sind okay? Und wie schaffe ich es, weniger Kaffee zu trinken und trotzdem konzentriert zu arbeiten?",
        "Morgens gibt es nur eine Sache, die meine Mundwinkel nach oben schiebt: Ein starker Espresso, aufgegossen mit warmer Milch. Koffein bleibt den ganzen Tag über mein treuer Begleiter: Sobald ich merke, dass meine Konzentration nachlässt, trinke ich Kaffee. Jedes Mal, wenn ich eine Tasse geleert habe, fühle ich mich wieder fit und arbeitswillig. Am Tag komme ich so aber auf sechs Tassen Kaffee oder Espresso. Ist das noch gesund? Und wirkt der Kaffee überhaupt noch?",
        "Zunächst einmal: Kaffee hilft wirklich. Das enthaltene Koffein stimuliert das zentrale Nervensystem, erklärt die Ernährungswissenschaftlerin Isabelle Keller von der Deutschen Gesellschaft für Ernährung. Die Folge: Herz, Kreislauf, die inneren Organe und die Verdauungstätigkeiten werden angeregt. „Die Müdigkeit wird beseitigt, die Stimmungslage wird verbessert und wir können uns besser konzentrieren“, zählt Keller die Vorteile auf. Auch beim Sport ist die leistungssteigernde Wirkung von Koffein bekannt.",
        "Allerdings gibt es beim Koffein tatsächlich einen Gewöhnungseffekt: Bei Dauertrinkern wie mir ist die stimulierende Wirkung längst nicht so groß wie bei jemandem, der nur ab und zu eine Tasse Kaffee trinkt. Aber auch allgemein vertragen die Menschen Koffein unterschiedlich gut – es gibt einige, die viel Kaffee in kurzer Zeit trinken können und andere, für die das dann schon negative Effekte hat. Gesunde Menschen können über den Tag verteilt mit gutem Gewissen zwei bis drei große beziehungsweise drei bis vier kleine Tassen Kaffee trinken, so die Richtlinie der Deutschen Gesellschaft für Ernährung.",
        "Isabelle Keller warnt hingegen vor Koffeintabletten, die gerade bei Studenten in der Prüfungszeit immer beliebter werden: „Die Gefahr einer Überdosierung von Koffein ist damit einfach viel größer“, sagt sie. Denn wer es mit dem Koffein übertreibt, kann auch die negativen Folgen des Wirkstoffs zu spüren bekommen: Nervosität, Muskelzittern, Magen-Darm-Probleme, Schwindel und Kopfschmerzen.",
        "Und wie schaffe ich es dann beispielsweise in der Prüfungszeit, mich fit und konzentriert zu fühlen, ohne es mit dem Kaffee zu übertreiben? Genügend zu trinken sei dafür das Wichtigste, meint Isabelle Keller: „Schon bei einem geringen Flüssigkeitsdefizit kommt es zu Konzentrationsschwierigkeiten, das geht sehr schnell.“ Sie empfiehlt, am Tag mindestens 1,5 Liter Flüssigkeit zu sich zu nehmen, am besten Wasser oder andere kalorienarme Getränke wie beispielsweise Kräutertee. Bei starker Hitze oder körperlicher Betätigung kann der tägliche Wasserbedarf das Drei- bis Vierfache erreichen.",
        "Auch die Ernährung spielt eine wichtige Rolle dabei, wie leistungsfähig man sich fühlt. Doch hier möchte Isabelle Keller mit einem Vorurteil aufräumen: Leider lässt eine Tüte Studentenfutter die Konzentration nicht sofort in die Höhe schnellen, stattdessen muss auf eine anhaltend ausgewogene Ernährung geachtet werden. Die beinhaltet möglichst viele Vollkornprodukte, fettarme Milchprodukte, viel Gemüse und Obst sowie möglichst wenig Fleisch. Genauso langfristig sollte man die Sache mit dem Sport angehen. Durch regelmäßige Bewegung kann das Alltagsniveau von Kreislauf- und Nervensystem gesteigert werden – dadurch verbessert man auch seine Aufmerksamkeit und Konzentrationsfähigkeit."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Das im Kaffee enthaltene Koffein",
          "options": {
            "a": "schädigt den Kreislauf und die inneren Organe.",
            "b": "regt Herz und Kreislauf an und hilft gegen Müdigkeit.",
            "c": "hat keine besondere Wirkung."
          },
          "answer": "b",
          "explanation": "Im 3. Absatz steht: „Herz, Kreislauf, die inneren Organe und die Verdauungstätigkeiten werden angeregt. ‚Die Müdigkeit wird beseitigt ...‘“"
        },
        {
          "num": 7,
          "stem": "Wer regelmäßig Kaffee trinkt",
          "options": {
            "a": "gewöhnt sich daran.",
            "b": "verträgt immer weniger.",
            "c": "leidet unter den negativen Effekten."
          },
          "answer": "a",
          "explanation": "Im 4. Absatz heißt es: „Allerdings gibt es beim Koffein tatsächlich einen Gewöhnungseffekt: Bei Dauertrinkern wie mir ist die stimulierende Wirkung längst nicht so groß wie bei jemandem, der nur ab und zu eine Tasse Kaffee trinkt.“"
        },
        {
          "num": 8,
          "stem": "Nervosität und Muskelzittern sind",
          "options": {
            "a": "die Folge von Koffeintabletten.",
            "b": "die Folge einer Überdosierung von Koffein.",
            "c": "die Folge einer Magen-Darm-Erkrankung."
          },
          "answer": "b",
          "explanation": "Im 5. Absatz wird erklärt, dass bei einer Überdosierung von Koffein („wer es mit dem Koffein übertreibt“) negative Folgen wie „Nervosität, Muskelzittern, Magen-Darm-Probleme, Schwindel und Kopfschmerzen“ auftreten können."
        },
        {
          "num": 9,
          "stem": "Am wichtigsten ist für die Konzentration, dass",
          "options": {
            "a": "man genügend Kaffee trinkt.",
            "b": "man bei starker Hitze nicht viel körperliche Betätigung ausübt.",
            "c": "man ausreichend Flüssigkeit zu sich nimmt."
          },
          "answer": "c",
          "explanation": "Im 6. Absatz heißt es ausdrücklich: „Genügend zu trinken sei dafür das Wichtigste, meint Isabelle Keller: ‚Schon bei einem geringen Flüssigkeitsdefizit kommt es zu Konzentrationsschwierigkeiten ...‘“"
        },
        {
          "num": 10,
          "stem": "Bei der Ernährung und beim Sport",
          "options": {
            "a": "kommt es auf die Regelmäßigkeit an.",
            "b": "zeigen sich keine positiven Effekte auf die Leistungsfähigkeit.",
            "c": "sollte man nicht übertreiben."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz wird betont, dass man auf eine „anhaltend ausgewogene Ernährung“ achten muss und es „genauso langfristig ... mit dem Sport angehen“ sollte („Durch regelmäßige Bewegung ...“)."
        }
      ]
    },
    {
      "id": "32",
      "title": "Test 32 – Lehrkräftepreis: Lehrerin aus Frankfurt ausgezeichnet",
      "isVariant": false,
      "paragraphs": [
        "Fast 3000 Jahre sind vergangen, seit der griechische Dichter Homer eines der berühmtesten Werke der Weltliteratur, die Ilias, niedergeschrieben haben soll. Bei Schülern dafür heutzutage noch Interesse zu wecken, ist gewiss für jeden Lehrer eine Herausforderung. Doch Brigitte Vollmer gelingt es, ihre Schüler für die alten Texte zu begeistern – so spannend und plastisch sind ihre Schilderungen, mit denen sie die Heldensagen der Antike zum Leben erweckt. Mehreren Generationen von Schülern hat die 66-Jährige diese Werke nahegebracht. Seit 38 Jahren unterrichtet sie Griechisch, Latein und Philosophie am Heinrich-von-Gagern-Gymnasium in Frankfurt – dort hat sie direkt nach ihrem Referendariat angefangen und ist geblieben. Seit 22 Jahren fungiert sie außerdem als Fachbereichsleiterin. Vor Kurzem, wenige Monate vor Ende ihres Berufslebens, hat sie für ihr pädagogisches Wirken den Deutschen Lehrkräftepreis erhalten, für den sie von ihren Schülerinnen und Schülern nominiert worden war. Es war ihre erste Nominierung bei einem Wettbewerb, und diese hatte gleich durchschlagenden Erfolg, obwohl über 6000 Bewerbungen eingegangen waren.",
        "Ihre Liebe zu alten Sprachen wurde schon während ihrer Schulzeit in Marburg geweckt: „Ich hatte einen wunderbaren Griechischlehrer und einen fantastischen Lateinlehrer“, erzählt sie mit glänzenden Augen. Bald war ihr klar: Wenn ich irgendetwas studiere, dann diese Fächer. „Obwohl meine Eltern von den Plänen zunächst alles andere als beglückt waren“, erinnert sie sich. Die dachten wohl, ich müsste entweder einen reichen Mann heiraten, um über die Runden zu kommen, oder ins Lehramt gehen. Schließlich wusste sie schon seit jeher, dass ein solches Studium nicht auf einen typischen Nine-to-Five-Job hinausläuft. Dabei wussten ihre Eltern genau, dass das Lehramt das Naheliegendste war. Und trotzdem kam ihnen nicht in den Sinn: „Einen reichen Mann heirate ich nicht, dachte ich, also blieb mir das Lehramt, und die Hauptverdienerin in unserer Familie war dann meine Mutter.“",
        "Doch auch wenn sie selbst nie in eine finanziell prekäre Situation geraten konnte, sie also abgesichert war, kann sie sich gut vorstellen, warum ihre eigenen Schüler sich oft nicht trauen, Philosophie, Archäologie oder andere Geisteswissenschaften zu studieren – und auch nicht Griechisch, Latein und Philosophie auf Lehramt. „Das sind ja keine gefragten Studiengänge“, sagt sie. Vor Beginn ihres Referendariats in Darmstadt haben sie nämlich etliche Zweifel geplagt, erzählt sie: „Klar, Wissen vermitteln, anderen etwas erklären, das konnte ich. Aber ich habe mich daran erinnert, wie frech wir früher manchmal zu unseren Lehrern waren. Und ich dachte: Jetzt kriegst du das zurück.“ Doch weit gefehlt: Begeistert seien die Elftklässler gewesen, die sie damals unterrichtete. Wohl auch deshalb, weil sie beeindruckt waren von ihrem Wissen und vor allem von ihrer Leidenschaft für die Fächer, die sie unterrichtete. Der von der Vodafone-Stiftung vergebene Lehrkräftepreis wird jährlich verliehen. Dank dieser Initiative können Schüler besondere Anerkennung und Dankbarkeit für einen Lehrer oder eine Lehrerin ihrer Wahl zum Ausdruck bringen. Die Lehrer werden von Schülern aus dem laufenden oder vorherigen Abschlussjahr vorgeschlagen und in Texten, Fotos oder Videos präsentiert. Die Schüler arbeiten dabei entweder allein oder in einem Team. Sechs Abiturienten meldeten Brigitte Vollmer gemeinsam bei dem Wettbewerb an. „Kurz vor der Abiturprüfung haben wir von dem Preis erfahren und dachten sofort, dass Frau Vollmer die Richtige dafür ist“, erzählt der 19-jährige Leon Walter. „Kein Lehrer hat uns so gut auf das Abitur vorbereitet wie sie, dafür sind wir ihr wirklich dankbar.“ Um die Jury mit ihrem Beitrag zu überzeugen, drehten die Schüler zusammen ein Video, in dem sie Frau Vollmer vorstellen.",
        "Über den Lehrkräftepreis habe sie sich riesig gefreut, sagt sie. „Es ist für mich nicht leicht, dass ich mich nun in den Ruhestand verabschieden muss, aber das ist ein gelungener Abschluss meiner beruflichen Laufbahn.“ Auch wenn sie ihre Arbeit vermissen wird, blickt sie optimistisch in die Zukunft: Denn sie möchte nicht ganz mit dem Unterrichten aufhören, sondern unter anderem an der Volkshochschule Kurse geben. Ob sie nun erst einmal lange Urlaub machen wolle? „Danach steht mir jetzt eigentlich nicht der Sinn. Ich mache vielleicht ein paar kleine Wochenendausflüge, aber ich habe eigentlich ganz andere Pläne.“ Denn einige ihrer Abiturienten möchten mit ihr einen privaten Lesezirkel organisieren – eine Idee, die sie begeistert. Die Werke der antiken Dichter werden sie also weiterhin begleiten."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Brigitte Vollmer",
          "options": {
            "a": "erhielt kurz vor Eintritt in den Ruhestand einen Preis.",
            "b": "wechselte in ihrer beruflichen Laufbahn mehrmals die Schule.",
            "c": "wurde schon mehrfach für Auszeichnungen vorgeschlagen."
          },
          "answer": "a",
          "explanation": "Im 1. Absatz steht: „Vor Kurzem, wenige Monate vor Ende ihres Berufslebens, hat sie für ihr pädagogisches Wirken den Deutschen Lehrkräftepreis erhalten ... Es war ihre erste Nominierung ...“"
        },
        {
          "num": 7,
          "stem": "Frau Vollmers Eltern vermuteten, dass ihre Tochter",
          "options": {
            "a": "am liebsten direkt nach dem Studium heiraten wolle.",
            "b": "mit ihrem Studium gute Perspektiven haben werde.",
            "c": "womöglich nicht genug für ihren Lebensunterhalt verdienen könne."
          },
          "answer": "c",
          "explanation": "Im 2. Absatz erinnert sie sich, dass ihre Eltern von den Studienplänen nicht begeistert waren und dachten, sie „müsste entweder einen reichen Mann heiraten, um mit dem Lebensunterhalt hinzukommen, oder ins Lehramt gehen“."
        },
        {
          "num": 8,
          "stem": "Frau Vollmer befürchtete, dass",
          "options": {
            "a": "die Schüler sich im Unterricht schlecht benehmen würden.",
            "b": "die Schüler wenig Interesse an ihren Fächern hätten.",
            "c": "sie kein Talent für das Unterrichten hätte."
          },
          "answer": "a",
          "explanation": "Im 3. Absatz berichtet sie über ihre Zweifel vor dem Referendariat: „Aber ich habe mich daran erinnert, wie frech wir früher manchmal zu unseren Lehrern waren. Und ich dachte: Jetzt kriegst du das zurück.“"
        },
        {
          "num": 9,
          "stem": "Frau Vollmers Schüler",
          "options": {
            "a": "haben erst nach dem Abitur von dem Wettbewerb erfahren.",
            "b": "reichten für den Wettbewerb verschiedene Einzelbeiträge ein.",
            "c": "wollten ihr für die gelungene Prüfungsvorbereitung Anerkennung zeigen."
          },
          "answer": "c",
          "explanation": "Im 3. Absatz sagt der Schüler Leon Walter: „Kein Lehrer hat uns so gut auf das Abitur vorbereitet wie sie, dafür sind wir ihr wirklich dankbar.“"
        },
        {
          "num": 10,
          "stem": "Brigitte Vollmer freut sich darauf,",
          "options": {
            "a": "bald Zeit für ausgedehnte Reisen zu haben.",
            "b": "mit ehemaligen Schülern ein Projekt zu planen.",
            "c": "in die Pension zu gehen."
          },
          "answer": "b",
          "explanation": "Im letzten Absatz heißt es: „Denn einige ihrer Abiturienten möchten mit ihr einen privaten Lesezirkel organisieren – eine Idee, die sie begeistert.“"
        }
      ]
    },
    {
      "id": "33",
      "title": "Test 33 – Im Nachtzug durch Europa",
      "isVariant": false,
      "paragraphs": [
        "Nachtzüge wecken heute oft nostalgische Vorstellungen. Man denkt etwa an den Luxus des Orient Express, der seine meist gut betuchte Kundschaft innerhalb weniger Tage von Paris nach Istanbul brachte, an Landschaften, die an den Zugfenstern vorbeirauschen, und das sanfte Rattern eines Zuges, das einen in den Schlaf wiegt. Doch hält die Realität, was solche Bilder versprechen? ‚Teilweise‘, meint die Studentin Sofia Osterhasen. Sie ist schon im Nachtzug von München nach Florenz, von Oslo nach Bergen und von Stockholm nach Kiruna gereist. Bei ihrer ersten Fahrt habe sie vor Aufregung nicht geschlafen, erzählt sie. Und auch sonst seien die Nächte im Zug oft unruhig, dafür sorgten etwa schnarchende Passagiere.",
        "Natürlich wäre Fliegen schneller und auf vielen Strecken sogar günstiger. Doch die lange Anreise gebe ihr Zeit, sich mit Mitreisenden zu unterhalten. „Die Leute erzählen während einer Zugfahrt viel aus ihrem Leben, man erfährt mehr als es bei Zufallsbekanntschaften oft der Fall ist. Das fasziniert mich“, erklärt sie.",
        "Zutun und kamen völlig übermüdet am Zielort an! Doch als sein jüngster Sohn die Augen öffnete, rief er: Das war meine beste Reise! Ein fahrendes Bett! Ich will jetzt immer nur noch Nachtzug fahren. Vor allem der Kinder wegen haben die Schneiders auch für den diesjährigen Urlaub eine Fahrt im Nachtzug gebucht. Dass die Nachtzüge, die durch Europa fahren, nicht immer sonderlich bequem sind, darüber wird häufig geklagt. Fahrgäste bemängeln, dass die Waggons teilweise sehr in die Jahre gekommen sind und nur wenige Annehmlichkeiten bieten. Ist vielleicht auch dies ein Grund, warum Geschäftsreisende diese Transportmöglichkeit nur selten in Betracht ziehen? „Das würde für mich keine große Rolle spielen“, meint Florian Kirsch, Vertriebsleiter eines mittelständischen Unternehmens. Viel wichtiger sei der Faktor Zeit: Wer will schon zwei Nächte im Zug verbringen, bloß weil er einen Termin in einer anderen Stadt hat? Wenn Nachtzüge konkurrenzfähig sein wollen, müssen sie mehr Schnelligkeit bieten, erklärt Florian Kirsch. Er selbst nimmt für längere Geschäftsreisen ausschließlich das Flugzeug."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Sofia Osterhasen fährt gerne mit dem Nachtzug",
          "options": {
            "a": "weil sie im Vergleich zu Flügen günstiger ist.",
            "b": "weil man dort leicht mit Fahrgästen ins Gespräch kommt.",
            "c": "weil sie während der Fahrt meist gut schlafen kann."
          },
          "answer": "b",
          "explanation": "Im 2. Absatz heißt es: „Doch die lange Anreise gebe ihr Zeit, sich mit Mitreisenden zu unterhalten. ‚Die Leute erzählen während einer Zugfahrt viel aus ihrem Leben ... Das fasziniert mich‘“."
        },
        {
          "num": 7,
          "stem": "Die Deutsche Bahn",
          "options": {
            "a": "hat der österreichischen Bundesbahn einige Züge abgekauft.",
            "b": "möchte mehrere Verbindungen über Nacht anbieten.",
            "c": "verzichtete aus ökonomischen Gründen auf eigene Nachtzüge."
          },
          "answer": "c",
          "explanation": "Laut Lösungsschlüssel (und dem zugrundeliegenden Originalartikel zum Nachtzugverkehr in Europa) stellte die Deutsche Bahn ihre eigenen Nachtzüge aus wirtschaftlichen Gründen ein und verkaufte ihre Schlafwagen an die ÖBB."
        },
        {
          "num": 8,
          "stem": "Die Reise mit dem Nachtzug",
          "options": {
            "a": "empfand Tom Schneider insgesamt als erholsam.",
            "b": "hat Tom Schneiders Sohn begeistert.",
            "c": "möchte Tom Schneider nicht wiederholen."
          },
          "answer": "b",
          "explanation": "Im 3. Absatz steht: „Doch als sein jüngster Sohn die Augen öffnete, rief er: Das war meine beste Reise! Ein fahrendes Bett! Ich will jetzt immer nur noch Nachtzug fahren.“"
        },
        {
          "num": 9,
          "stem": "Florian Kirsch verzichtet auf längere Zugreisen, weil",
          "options": {
            "a": "er im Zug ungern arbeitet.",
            "b": "er mit dem Flugzeug Zeit spart.",
            "c": "es ihm an Bequemlichkeit fehlt."
          },
          "answer": "b",
          "explanation": "Im 3. Absatz erklärt Florian Kirsch, dass mangelnder Komfort für ihn keine große Rolle spiele, sondern viel wichtiger „der Faktor Zeit“ sei; deshalb nehme er für längere Geschäftsreisen das Flugzeug."
        },
        {
          "num": 10,
          "stem": "Die Züge des französischen Start-ups sollen",
          "options": {
            "a": "den Fahrgästen viel Privatsphäre bieten.",
            "b": "vor allem eine finanzkräftige Zielgruppe ansprechen.",
            "c": "zunächst Zielorte nördlich von Frankreich anfahren."
          },
          "answer": "a",
          "explanation": "Laut Lösungsschlüssel (und dem Originaltext über neue Nachtzug-Konzepte wie das französische Start-up Midnight Trains) sollen die neuen Züge den Reisenden durch eigene Abteile vor allem viel Privatsphäre und Komfort wie im Hotel bieten."
        }
      ]
    },
    {
      "id": "34",
      "title": "Test 34 – Wann geht es den Österreichern gut?",
      "isVariant": false,
      "paragraphs": [
        "Ihre Liebsten gehen den Österreichern über alles. Dies ergab eine jüngst veröffentlichte Umfrage eines Marktforschungsinstituts. Demnach fühlen sich 83 Prozent der Befragten besonders wohl in ihrer Haut, wenn in der Familie und in der Partnerschaft alles in Ordnung ist. Einen fast ebenso großen Stellenwert nimmt die eigene Gesundheit ein: Für 80 Prozent ist diese eine wichtige Voraussetzung, damit sie sich wohl fühlen. In diesen beiden Punkten sind sich Mann und Frau einig; sie stehen bei beiden Geschlechtern und quer durch alle Alters- und Bildungsschichten ganz oben auf der Liste der Wohlfühlzutaten. Zeit für die Familie ist für 65 Prozent ein Kriterium für das eigene Wohlgefühl. Erst danach kommt ein materieller Wert, Geld. Genügend Geld zur Verfügung und keine Schulden zu haben, nannten 62 Prozent als ein Kriterium für das eigene Wohlergehen.",
        "Zeit für Hobbys und Freizeitaktivitäten sowie die eigene Bestätigung sind jeweils für 59 Prozent der Befragten wichtig, um sich im Alltag wohl zu fühlen. Auch Zeit für Freunde und Bekannte gehört für mehr als die Hälfte, nämlich für 53 Prozent, dazu, wobei die jüngste Gruppe bis 29 Jahre mit 67 Prozent am meisten Wert darauf legt. Die Befragten in dieser Gruppe schlafen auch am liebsten aus und brauchen Sport, um sich gut zu fühlen. Über die Hälfte der Befragten geben an, dass Schmerzfreiheit und uneingeschränkte Bewegungsfreiheit ein Maßstab für Wohlbefinden ist – wobei dieses Kriterium bei Personen über 50 Jahre mehr zählte, nämlich zu über 62 Prozent, als bei den jüngeren Befragten. Aber auch bei diesen empfinden etwa die Hälfte Schmerz- und körperliche Bewegungsfreiheit als eine Bedingung, damit sie sich wohl fühlen.",
        "Die Studie ging daher näher auf diesen Punkt ein und fragte nach dem allgemeinen Gesundheitszustand der Österreicher. Eine breite Mehrheit (64 %) bezeichnet diesen als gut mit gelegentlichen kleinen Beschwerden, während 16 Prozent ihren Zustand als ausgezeichnet und 18 Prozent ihn als weniger gut mit einigen gesundheitlichen Problemen bezeichnen. Drei Prozent geben an, mit ernsten Gesundheitsproblemen zu kämpfen.",
        "Das Institut untersuchte auch den Zusammenhang zwischen Mußestunden und Gesundheit. Die Gruppen, die angeben, genug beziehungsweise zu wenige Stunden für Nichtstun und Genuss erübrigen zu können, sind mit jeweils 48 Prozent gleich groß. Wenngleich Nicht-Berufstätige und über 50-Jährige am meisten Raum finden für Muße, so scheint es ihnen ihre Gesundheit nicht zu danken: Fast 30 Prozent von ihnen haben einige oder ernsthafte gesundheitliche Probleme.",
        "Im Gegenzug stellte das Forschungsinstitut fest, dass die Gesunden sich leichter Zeit nehmen zum Genießen. 57 Prozent jener, die sich bester Gesundheit erfreuen, gönnen sich auch ausreichend Annehmlichkeiten, während das nur 39 Prozent der Befragten mit einem weniger erfreulichen Gesundheitszustand tun.",
        "Eine zweite, zeitgleich veröffentlichte Umfrage liefert weitere Hinweise darauf, was Österreicher zum Wohlergehen brauchen. Sie verrät nämlich, in welcher Gesellschaft sie sich am wohlsten fühlen: Diese Umfrage erhob Eigenschaften, welche die Österreicher an ihren Mitmenschen am meisten schätzen. Daraus ergibt sich das Bild des beliebtesten Österreichers: Er oder sie ist verlässlich, verantwortungsbewusst, lebensfroh, humorvoll und dazu intelligent. Ob die Personen, die so am meisten geschätzt werden, sportlich oder gut aussehend sind, ist den meisten Landsleuten herzlich egal.",
        "An erster Stelle unter den beliebtesten Eigenschaften steht mit fast 80 Prozent die Verlässlichkeit. 60 Prozent der Befragten beschreiben Personen, die sie besonders schätzen, als lebensfroh. Wie der Vergleich mit einer früher durchgeführten Umfrage zeigt, haben diese beiden Attribute in den vergangenen 20 Jahren deutlich an Wert gewonnen. Der Begriff humorvoll fiel 59 Prozent zu ihren liebsten Mitmenschen ein, verantwortungsbewusst 58 Prozent. Weitere Eigenschaften, die bei Menschen besonders geschätzt werden, sind Intelligenz, Toleranz, Gewissenhaftigkeit und Geselligkeit.",
        "Die Eigenschaften fantasievoll und kreativ haben über die Jahre hinweg an Attraktivität verloren: Rund ein Drittel der Befragten halten diese Charakterzüge für unwichtig. Am wenigsten Wert legen die Befragten aber eindeutig auf das Attribut sportlich – fast die Hälfte der Befragten reiht es unter die drei unwichtigsten Eigenschaften, gefolgt von gut aussehend."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Die Mehrheit der Befragten mag Personen am meisten,",
          "options": {
            "a": "die Freude am Leben haben.",
            "b": "die stets zum Ausgehen aufgelegt sind.",
            "c": "die über die Jahre an denselben Werten festhalten."
          },
          "answer": "a",
          "explanation": "Im 6. und 7. Absatz steht, dass zu den beliebtesten Eigenschaften „lebensfroh“ gehört: „60 Prozent der Befragten beschreiben Personen, die sie besonders schätzen, als lebensfroh.“"
        },
        {
          "num": 7,
          "stem": "In Bezug auf Wohlfühlen wird die Gesundheit",
          "options": {
            "a": "abhängig vom Bildungsgrad bewertet.",
            "b": "bei beiden Geschlechtern gleich hoch bewertet.",
            "c": "von kranken Menschen besonders betont."
          },
          "answer": "b",
          "explanation": "Im 1. Absatz heißt es über Familie und Gesundheit: „In diesen beiden Punkten sind sich Mann und Frau einig; sie stehen bei beiden Geschlechtern und quer durch alle Alters- und Bildungsschichten ganz oben auf der Liste der Wohlfühlzutaten.“"
        },
        {
          "num": 8,
          "stem": "Die Umfrage ergab, dass gesunde Menschen",
          "options": {
            "a": "besonders viel Sport treiben.",
            "b": "sich genug Zeit für angenehme Dinge nehmen.",
            "c": "weniger Genussmittel konsumieren."
          },
          "answer": "b",
          "explanation": "Im 5. Absatz steht: „Im Gegenzug stellte das Forschungsinstitut fest, dass die Gesunden sich leichter Zeit nehmen zum Genießen. 57 Prozent jener, die sich bester Gesundheit erfreuen, gönnen sich auch ausreichend Annehmlichkeiten ...“"
        },
        {
          "num": 9,
          "stem": "Die meisten Teilnehmenden an der Umfrage",
          "options": {
            "a": "ärgern sich über immer wieder auftretende Gesundheitsprobleme.",
            "b": "finden, dass sie bei guter Gesundheit sind.",
            "c": "können ihre eigene Gesundheit nicht beurteilen."
          },
          "answer": "b",
          "explanation": "Laut Absatz 3 bezeichnet „eine breite Mehrheit (64 %)“ ihren Gesundheitszustand als gut und weitere 16 Prozent sogar als ausgezeichnet."
        },
        {
          "num": 10,
          "stem": "Für die Gruppe der Befragten unter 30 Jahren",
          "options": {
            "a": "hat Sport einen hohen Stellenwert.",
            "b": "ist Ausschlafen etwas für ältere Leute.",
            "c": "ist Zeit für Freunde und Bekannte noch nicht so wichtig."
          },
          "answer": "a",
          "explanation": "Im 2. Absatz steht über die jüngste Gruppe bis 29 Jahre: „Die Befragten in dieser Gruppe schlafen auch am liebsten aus und brauchen Sport, um sich gut zu fühlen.“"
        }
      ]
    },
    {
      "id": "35",
      "title": "Test 35 – Thema Beziehungsangst: Die Angstsignale richtig deuten",
      "isVariant": false,
      "paragraphs": [
        "Dauerhafte Beziehungsangst hat viele Gründe und erfordert Ursachenforschung. Viele Menschen mit solch einer Angst erkennen ihre eigenen Angstsignale nicht und laufen Gefahr, ihren Traumpartner für immer zu verlieren.",
        "Nicht wenige Partnerschaften scheitern an Beziehungsangst. Diese Form von Angst wird von Betroffenen meist gar nicht selbst wahrgenommen und lässt eine Beziehung nach der anderen zerbrechen. Wer Beziehungsangst hat, fürchtet sich vor einer festen Beziehung, lässt innige Gefühle nicht zu und stößt seinen Partner schließlich von sich.",
        "Menschen mit Angst vor einer Beziehung sehen eine feste partnerschaftliche Bindung als Gefahr. Die Angst vermindert den Spaß an intimer Zweisamkeit und innigen Gefühlen. Solche Menschen konzentrieren sich anstatt auf das Glück mit dem Partner einzig auf die von ihnen als negativ aufgenommenen Folgen der Partnerschaft: Freiheitsverlust, partnerschaftliche Einengung, (zu) viel Verantwortung, Vertrauensmissbrauch, Angst davor, ein Stück von sich selbst aufgeben zu müssen.",
        "Es gibt auch eine gute Nachricht: Keine Beziehungsangst ist grundlos. Die Ursachenforschung beginnt oft in der Kindheit. Wenn die Eltern früh geschieden wurden oder Kinder in unglücklichen Familien aufgewachsen sind, äußert sich dieses Trauma aus der Kindheit nicht selten in Form von Angst vor festen Bindungen. Häufig zeigt sich auch eine frühere Partnerschaft verantwortlich: Hier wurde ein Partner schwer enttäuscht, verlassen oder tief verletzt und möchte sich partout nicht mehr auf Intimität einlassen.",
        "Menschen mit Beziehungsangst suchen sich oft Partner, mit denen keine gemeinsame Zukunft möglich ist. Mit professioneller Beratung kann eine Beziehungskrise wieder aus der Welt geschafft werden.",
        "Als junger und manchmal noch recht unerfahrener Mensch lernen viele ihren Partner fürs Leben kennen und gehen mitunter recht schnell eine Bindung ein.",
        "Was in früheren Jahren besiegelt wurde, reift aber im Laufe der Zeit. Beide Partner verändern sich und das vielleicht unabhängig voneinander. Manchmal kommt es dann zu einer mehr oder weniger schweren Beziehungskrise, aus der die Partner scheinbar aus eigener Kraft nicht mehr herausfinden. Ist das heiße Feuer der Leidenschaft erst mal erloschen und der Alltag mit Beruf und Kindern hat die beiden Partner eingeholt, sehen viele Paare keinen Sinn mehr darin, die Partnerschaft fortzuführen. Nicht wenige dieser Paare trennen sich sehr schnell. Viele möchten aber gar nicht so schnell aufgeben und sich von der Beziehungskrise nicht beeindrucken lassen.",
        "In diesen Fällen sollten die Partner über eine Beratung bei einer professionellen Person nachdenken. Voraussetzung für einen Erfolg solcher Gespräche ist jedoch, dass beide Partner auch wirklich ein echtes Interesse an der Klärung des Sachverhaltes haben. Hat einer bereits im Stillen das Handtuch geworfen, hat auch eine Paartherapie oft keinen Sinn mehr. Dann kann eine Krise wohl kaum mehr überwunden werden."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Viele Partnerschaften scheitern",
          "options": {
            "a": "an den Beziehungsängsten eines Partners.",
            "b": "weil ein Partner weit weg wohnt.",
            "c": "aufgrund unterschiedlicher Arbeitszeiten."
          },
          "answer": "a",
          "explanation": "Gleich zu Beginn des 2. Absatzes steht: „Nicht wenige Partnerschaften scheitern an Beziehungsangst.“"
        },
        {
          "num": 7,
          "stem": "Menschen mit Beziehungsangst konzentrieren sich nur auf",
          "options": {
            "a": "das Glück mit dem Partner.",
            "b": "die unangenehmen Eigenschaften einer Beziehung, wie z. B. mehr Verantwortung.",
            "c": "ihre eigene Person."
          },
          "answer": "b",
          "explanation": "Im 3. Absatz heißt es: „Solche Menschen konzentrieren sich anstatt auf das Glück mit dem Partner einzig auf die von ihnen als negativ aufgenommenen Folgen der Partnerschaft: Freiheitsverlust, partnerschaftliche Einengung, (zu) viel Verantwortung ...“"
        },
        {
          "num": 8,
          "stem": "Die Ursachen der Beziehungsangst liegen oft",
          "options": {
            "a": "an ungelösten Konflikten in der Partnerschaft.",
            "b": "in der frühen Kindheit oder in einer früheren Partnerschaft.",
            "c": "am anderen Partner."
          },
          "answer": "b",
          "explanation": "Im 4. Absatz wird erklärt: „Die Ursachenforschung beginnt oft in der Kindheit ... Häufig zeigt sich auch eine frühere Partnerschaft verantwortlich“."
        },
        {
          "num": 9,
          "stem": "Viele Paare trennen sich",
          "options": {
            "a": "wenn Alltag mit Beruf und Kindern in die Partnerschaft eingekehrt ist.",
            "b": "wegen gesundheitlicher Probleme.",
            "c": "wenn sie Haustiere haben."
          },
          "answer": "a",
          "explanation": "Im 7. Absatz steht: „Ist das heiße Feuer der Leidenschaft erst mal erloschen und der Alltag mit Beruf und Kindern hat die beiden Partner eingeholt, sehen viele Paare keinen Sinn mehr darin, die Partnerschaft fortzuführen. Nicht wenige dieser Paare trennen sich sehr schnell.“"
        },
        {
          "num": 10,
          "stem": "Voraussetzung für ein erfolgreiches therapeutisches Gespräch ist, dass",
          "options": {
            "a": "beide Partner dazu bereit sind.",
            "b": "mindestens ein Partner ein klärendes Gespräch sucht.",
            "c": "beide Partner sich in einer Beziehungspause befinden."
          },
          "answer": "a",
          "explanation": "Im letzten Absatz heißt es: „Voraussetzung für einen Erfolg solcher Gespräche ist jedoch, dass beide Partner auch wirklich ein echtes Interesse an der Klärung des Sachverhaltes haben.“"
        }
      ]
    },
    {
      "id": "36",
      "title": "Test 36 – Wie wichtig ist Nachhaltigkeit in österreichischen Unternehmen?",
      "isVariant": false,
      "paragraphs": [
        "In den letzten Jahren setzen immer mehr österreichische Unternehmen auf gesellschaftliche Verantwortung. Zog man anfangs dazu eher Experten von außen heran, so gründet man jetzt lieber eine eigene Abteilung, die sich mit dem Fachgebiet der Nachhaltigkeit befasst. Ausgewählte Personen, die zuerst in entsprechende Fortbildungsprogramme eingebunden werden, sind im Anschluss für nachhaltige Projekte zuständig und werden ausdrücklich dazu aufgefordert, ihr Wissen an die Kollegen weiterzugeben. Da es sich bei dieser Kursänderung also nicht nur um eine Strategie der Führungsspitze handelt, sondern jeder Einzelne im Team eigenverantwortlich seinen Beitrag dazu leistet, werden soziales Engagement, das Nutzen regionaler Ressourcen sowie Umweltbewusstsein systematisch in den Betrieb integriert.",
        "Nachhaltiges Handeln hat zunächst unmittelbare Auswirkungen auf die Mobilität. War es vor einigen Jahren noch übliche Praxis, bedenkenlos einen Flug zu buchen, um beruflich motivierte Termine wahrzunehmen, so ändert sich das gerade grundlegend. Immer mehr Unternehmen setzen auf Videokonferenzen und virtuelle Treffen. Ist eine körperliche Anwesenheit tatsächlich nötig, entsenden sie ihre Mitarbeiter bei überschaubaren Strecken mit der Bahn. Zudem arbeiten Unternehmen auch an Konzepten für den täglichen Arbeitsweg ihrer Mitarbeiter. Beispielsweise wird durch die Erstellung von Mitfahrplänen, die anzeigen, welcher Kollege zu einem bestimmten Zeitpunkt eine definierte Strecke fährt, die Bildung von Fahrgemeinschaften erleichtert. Schließlich gelingt es auch, das Personal durch die Bereitstellung von Dienstfahrrädern oder Tickets für öffentliche Verkehrsmittel hin zu umweltfreundlichen Mobilitätsentscheidungen zu lenken.",
        "Mit dem Fortschreiten der Technik zeichnet sich ein Wandel zum papierlosen Büro ab. Selbst Verträge können bereits rechtsgültig digital unterschrieben werden. Allerdings ist es ein Irrglaube, dass durch E-Mails keine Schadstoffe freigesetzt werden. Auf den Arbeitsplätzen nachhaltiger Unternehmen greift man deshalb öfter zum Telefon oder geht einfach ins Büro nebenan, um dienstliche Angelegenheiten persönlich zu besprechen.",
        "Trotz des Umstiegs auf elektronische Dokumente verzeichnet Österreich in puncto Papierverbrauch eine leichte Tendenz nach oben. Derzeit liegt dieser bei etwa 250 Kilogramm pro Kopf und Jahr – was aus ökologischer Sicht bedenklich ist. Umso bedenklicher ist es, wenn man überlegt, wie viele enorme Mengen an Ressourcen bei der Erzeugung verbraucht werden. Der wichtigste Faktor, mit dem der Einsatz von Papier reguliert und verringert werden kann, ist immer noch die Verwendung von Altpapier. Dieses System funktioniert in Österreich relativ gut: Dank eines Sammelbewusstseins wird eine Altpapier-Rücklaufquote von rund 50 % erreicht.",
        "Das Nachhaltigkeitsprinzip kann man problemlos auch auf den Einkauf von Büromaterialien anwenden. Dieser Bereich wird von Unternehmen noch vernachlässigt, zu wenig Bedeutung misst man ihm bislang bei. Dabei sollte gerade bei solchen stets im Einsatz befindlichen Produkten genau darauf geachtet werden, aus welchen Materialien sie gefertigt bzw. welcher Art die Inhaltsstoffe sind. Durch die Bereitstellung umweltgerechter Schreibutensilien können Dienstgeber vermeiden, dass ihre Angestellten bei der Arbeit mit gefährlichen und teilweise sogar giftigen Schadstoffen in Berührung kommen. Nachhaltige Alternativen zu herkömmlichen Produkten gibt es etwa für Kugelschreiber, Textmarker oder Filzstifte. Diese werden immer häufiger mit Tinte auf wasserlöslicher Basis befüllt und belasten somit die Umwelt wesentlich weniger. Auch die Stifte selbst sind bereits zum Teil aus biologisch abbaubarem Material gefertigt, womit sich die Abfallmengen reduzieren lassen. Diese Produkte sind zudem deutlich langlebiger als herkömmliche Schreibwaren, wodurch das häufig angeführte Gegenargument – der großzügig bemessene Preis – eindeutig widerlegt wird.",
        "Der Gedanke der Nachhaltigkeit darf sich jedoch nicht nur auf Umweltfragen beschränken. Allzu lange blieb die soziale Komponente völlig unterbewertet, ein Randthema, worüber man gelegentlich diskutierte. In Wirklichkeit handelt es sich dabei um einen Aspekt, der in jeden Bereich der Ökologie und Ökonomie hineinwirkt. Für Arbeitgeber rückt die Thematik der sozialen Nachhaltigkeit oftmals nur dann stärker in den Blickpunkt, wenn es einen Fachkräftemangel zu beklagen gibt und Anreize geschaffen werden müssen, um die Attraktivität der ausgeschriebenen Stellen zu erhöhen. Unternehmen, die ihre Verantwortung ernst nehmen, pflegen aber jederzeit einen besonders achtsamen Umgang mit ihren Mitarbeitern und gewährleisten sowohl zwischen Geschlechtern als auch Generationen Einkommensgerechtigkeit und Fairness sowie Arbeitsplatzsicherheit und Transparenz."
      ],
      "questions": [
        {
          "num": 6,
          "stem": "Nachhaltigkeit im Unternehmen soll erreicht werden, indem",
          "options": {
            "a": "der Austausch zur Thematik unter den Mitarbeitern gefordert wird.",
            "b": "die Chefetage die Einhaltung gewisser Zielvorgaben anordnet.",
            "c": "vermehrt externe Berater mit der Umsetzung beauftragt werden."
          },
          "answer": "a",
          "explanation": "Im 1. Absatz steht, dass ausgewählte Mitarbeiter nach Fortbildungen für nachhaltige Projekte zuständig sind „und werden ausdrücklich dazu aufgefordert, ihr Wissen an die Kollegen weiterzugeben“."
        },
        {
          "num": 7,
          "stem": "Im Bereich der nachhaltigen Mobilität",
          "options": {
            "a": "fördern Betriebe die Bereitschaft zur gemeinsamen Nutzung von Privat-PKWs.",
            "b": "haben Betriebe kaum Einfluss auf die Nutzung öffentlicher Verkehrsmittel.",
            "c": "machen zweckmäßige digitale Lösungen Dienstreisen komplett überflüssig."
          },
          "answer": "a",
          "explanation": "Im 2. Absatz heißt es: „Beispielsweise wird durch die Erstellung von Mitfahrplänen, die anzeigen, welcher Kollege zu einem bestimmten Zeitpunkt eine definierte Strecke fährt, die Bildung von Fahrgemeinschaften erleichtert.“"
        },
        {
          "num": 8,
          "stem": "Nachhaltige Büroartikel",
          "options": {
            "a": "gehören schon lange auf die Bestellliste bewusst handelnder Betriebe.",
            "b": "können einen Beitrag zum Erhalt der Mitarbeitergesundheit leisten.",
            "c": "sind bei genauer Durchrechnung für die Betriebe zu kostenintensiv."
          },
          "answer": "b",
          "explanation": "Im 5. Absatz wird betont: „Durch die Bereitstellung umweltgerechter Schreibutensilien können Dienstgeber vermeiden, dass ihre Angestellten bei der Arbeit mit gefährlichen und teilweise sogar giftigen Schadstoffen in Berührung kommen.“"
        },
        {
          "num": 9,
          "stem": "In Österreich",
          "options": {
            "a": "ist für die industrielle Herstellung von Papier viel Energie erforderlich.",
            "b": "lässt die Wiederverwertung von gebrauchtem Papier zu wünschen übrig.",
            "c": "verzeichnet man seit einigen Jahren einen Rückgang des Papierbedarfs."
          },
          "answer": "a",
          "explanation": "Im 4. Absatz heißt es über den hohen Papierverbrauch in Österreich, dass dieser umso bedenklicher ist, „wenn man überlegt, wie viele enorme Mengen an Ressourcen bei der Erzeugung verbraucht werden“."
        },
        {
          "num": 10,
          "stem": "Soziale Nachhaltigkeit",
          "options": {
            "a": "ist aufgrund ihrer Komplexität als eigene Disziplin zu betrachten.",
            "b": "setzen sich Betriebe bei hohen Arbeitslosenzahlen zum Ziel.",
            "c": "umfasst auch die Gleichbehandlung von Frauen und Männern."
          },
          "answer": "c",
          "explanation": "Im letzten Satz des Textes steht, dass verantwortungsbewusste Unternehmen „sowohl zwischen Geschlechtern als auch Generationen Einkommensgerechtigkeit und Fairness sowie Arbeitsplatzsicherheit und Transparenz“ gewährleisten."
        }
      ]
    }
  ]
};
