const MODULE_NAME = "sprechen";
const partLinks = [...document.querySelectorAll(".reading-parts a")];
const topicPicker = document.querySelector(".topic-panel");
const topicSearch = document.querySelector("#topic-search");
const topicList = document.querySelector("#topic-list");
const topicCount = document.querySelector("#topic-count");
const topicEmpty = document.querySelector("#topic-empty");
const exercise = document.querySelector("#reading-exercise");
const narrowScreen = window.matchMedia("(max-width: 920px)");

const parts = sprechenData;
const descriptions = {
  1: "Sprechen Teil 1 (Präsentation): Mögliche Fragen zu Buch, Film, Reise, Musikveranstaltung und Sportereignis.",
  2: "Sprechen Teil 2 (Diskussion): 54 Prüfungsthemen mit Ausgangstext und Diskussionsimpulsen.",
  3: "Sprechen Teil 3 (Gemeinsam etwas planen): 54 Aufgaben mit jeweils 10 konkreten Lösungsvorschlägen (DE/EN).",
};
const selections = new Map();
const drafts = new Map();
let currentPart;
let currentTopic;
let showEnglish = true;

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function normalize(text) {
  return text.toLocaleLowerCase("de").replace(/ß/g, "ss")
    .normalize("NFD").replace(/\p{Diacritic}/gu, "");
}

function topicTitle(topic) {
  return topic.title.replace(/^(?:Thema|Aufgabe|Planung|Test)\s+\S+\s*[–-]\s*/i, "");
}

function topicHash(part, id) {
  return `#teil-${part}/${id}`;
}

function topicQuestionCount(topic) {
  if (currentPart === 1) return topic.questions.length;
  if (currentPart === 2) return topic.discussion_points.length;
  return topic.suggestions.length;
}

function updatePartProgressBars() {
  for (const link of partLinks) {
    const p = Number(link.hash.replace("#teil-", ""));
    const pct = VokageiProgress.getPartProgressPercent(MODULE_NAME, p, parts[p], (t) => {
      if (p === 1) return t.questions.length;
      if (p === 2) return t.discussion_points.length;
      return t.suggestions.length;
    });
    link.style.setProperty("--progress", `${pct}%`);
  }
}

function renderTopics() {
  const terms = normalize(topicSearch.value.trim()).split(/\s+/).filter(Boolean);
  const allTopics = parts[currentPart];
  const matches = allTopics.filter((topic) => {
    const extra = topic.text || topic.prompt || (topic.questions || []).join(" ");
    const searchText = normalize(`${topic.id} ${topic.title} ${extra}`);
    return terms.every((word) => /^\d+$/.test(word)
      ? topic.id.startsWith(word)
      : searchText.includes(word));
  });
  const entries = matches.map((topic) => {
    const entry = element("li");
    const link = element("a");
    link.href = topicHash(currentPart, topic.id);
    link.dataset.topicId = topic.id;
    const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, topic.id, topicQuestionCount(topic));
    link.style.setProperty("--progress", `${pct}%`);
    if (topic.id === currentTopic.id) link.setAttribute("aria-current", "location");
    link.append(element("span", "topic-number", topic.id), element("span", "", topicTitle(topic)));
    entry.append(link);
    return entry;
  });
  topicList.replaceChildren(...entries);
  topicCount.textContent = `${matches.length} von ${allTopics.length} Themen`;
  topicEmpty.hidden = matches.length > 0;
  updatePartProgressBars();
}

function updateCurrentTopicProgressUI(draft) {
  const total = topicQuestionCount(currentTopic);
  VokageiProgress.saveDraft(MODULE_NAME, currentPart, currentTopic.id, draft, total);
  const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, currentTopic.id, total);
  const activeLink = topicList.querySelector(`a[data-topic-id="${CSS.escape(currentTopic.id)}"]`);
  if (activeLink) activeLink.style.setProperty("--progress", `${pct}%`);
  updatePartProgressBars();
  return pct;
}

function getDraft() {
  const key = topicHash(currentPart, currentTopic.id);
  if (!drafts.has(key)) {
    drafts.set(key, VokageiProgress.getDraft(MODULE_NAME, currentPart, currentTopic.id));
  }
  return drafts.get(key);
}

function renderContent(topic) {
  const draft = getDraft();
  const wrapper = element("div", "exercise-layout single-col");
  const panel = element("form", "answer-panel");
  const body = element("div", "passage reading-scroll");
  if (!showEnglish) body.classList.add("hide-en");

  const checkInputs = [];
  const total = topicQuestionCount(topic);

  if (currentPart === 1) {
    const introSec = element("section", "passage-entry");
    introSec.append(
      element("span", "passage-meta", "Mündliche Prüfung · Teil 1 – Präsentation"),
      element("h3", "", "Redemittel zum Einstieg")
    );
    topic.intro.forEach((line) => introSec.append(element("p", "", `• ${line}`)));
    body.append(introSec);

    const sampleSec = element("section", "passage-entry");
    sampleSec.append(
      element("h3", "", "Beispielantwort (A2–B1, leicht zu sprechen)"),
      element("p", "", topic.sample_answer_de)
    );
    body.append(sampleSec);

    const qSec = element("section", "passage-entry");
    qSec.append(element("h3", "", `Mögliche Fragen zur Präsentation (${topic.questions.length} Fragen)`));
    const qWrap = element("div", "question");
    topic.questions.forEach((qText, idx) => {
      const qNum = idx + 1;
      const lbl = element("label");
      const cb = element("input");
      cb.type = "checkbox";
      cb.name = String(qNum);
      cb.checked = draft.answers.get(qNum) === "1";
      checkInputs.push(cb);
      lbl.append(cb, element("span", "", `${qNum}. ${qText}`));
      qWrap.append(lbl);
    });
    qSec.append(qWrap);
    body.append(qSec);
  } else if (currentPart === 2) {
    const textSec = element("section", "passage-entry");
    const pdfBtn = element("a", "secondary-cta");
    pdfBtn.href = `assets/sprechen-thema-1.pdf#page=${topic.id}`;
    pdfBtn.target = "_blank";
    pdfBtn.rel = "noopener noreferrer";
    pdfBtn.textContent = `Artikel-PDF öffnen (Thema ${topic.id}) ↗`;
    pdfBtn.style.marginTop = ".75rem";
    pdfBtn.style.display = "inline-flex";
    textSec.append(
      element("span", "passage-meta", `Mündliche Prüfung · Teil 2 – Diskussion (Thema ${topic.id})`),
      element("h3", "", topicTitle(topic)),
      element("p", "", topic.text),
      pdfBtn
    );
    body.append(textSec);

    const dpSec = element("section", "passage-entry");
    dpSec.append(element("h3", "", "Checkliste für deine Diskussion"));
    const qWrap = element("div", "question");
    topic.discussion_points.forEach((pt, idx) => {
      const qNum = idx + 1;
      const lbl = element("label");
      const cb = element("input");
      cb.type = "checkbox";
      cb.name = String(qNum);
      cb.checked = draft.answers.get(qNum) === "1";
      checkInputs.push(cb);
      lbl.append(cb, element("span", "", pt));
      qWrap.append(lbl);
    });
    dpSec.append(qWrap);
    body.append(dpSec);
  } else {
    const promptSec = element("section", "passage-entry");
    promptSec.append(
      element("span", "passage-meta", `Mündliche Prüfung · Teil 3 – Gemeinsam etwas planen (Aufgabe ${topic.id})`),
      element("h3", "", "Aufgabenstellung"),
      element("p", "", topic.prompt)
    );
    body.append(promptSec);

    const sugSec = element("section", "passage-entry");
    sugSec.append(element("h3", "", "10 konkrete Vorschläge für das Planungsgespräch"));
    const qWrap = element("div", "question");
    topic.suggestions.forEach((sug, idx) => {
      const qNum = idx + 1;
      const lbl = element("label");
      const cb = element("input");
      cb.type = "checkbox";
      cb.name = String(qNum);
      cb.checked = draft.answers.get(qNum) === "1";
      checkInputs.push(cb);
      const textWrap = element("span", "");
      textWrap.append(
        element("strong", "", `Vorschlag ${qNum}: `),
        document.createTextNode(sug.de),
        element("span", "en-translation", ` (${sug.en})`)
      );
      lbl.append(cb, textWrap);
      qWrap.append(lbl);
    });
    sugSec.append(qWrap);
    body.append(sugSec);
  }

  const controls = element("div", "answer-controls");
  const completeAllBtn = element("button", "cta model-cta", "Alle als geübt markieren");
  completeAllBtn.type = "button";
  const resetBtn = element("button", "secondary-cta", "Zurücksetzen");
  resetBtn.type = "button";
  const result = element("p", "set-result");
  result.setAttribute("role", "status");
  controls.append(completeAllBtn, resetBtn, result);

  panel.append(body, controls);
  wrapper.append(panel);

  function updateUI() {
    const pct = updateCurrentTopicProgressUI(draft);
    controls.style.setProperty("--progress", `${pct}%`);
    result.textContent = `${draft.answers.size} von ${total} Punkten geübt`;
  }

  panel.addEventListener("change", (e) => {
    if (e.target.type !== "checkbox") return;
    const n = Number(e.target.name);
    if (e.target.checked) draft.answers.set(n, "1");
    else draft.answers.delete(n);
    draft.graded = draft.answers.size === total;
    updateUI();
  });

  completeAllBtn.addEventListener("click", () => {
    for (let i = 1; i <= total; i++) draft.answers.set(i, "1");
    checkInputs.forEach((cb) => { cb.checked = true; });
    draft.graded = true;
    updateUI();
  });

  resetBtn.addEventListener("click", () => {
    draft.answers.clear();
    draft.graded = false;
    checkInputs.forEach((cb) => { cb.checked = false; });
    VokageiProgress.clearDraft(MODULE_NAME, currentPart, currentTopic.id);
    updateUI();
  });

  updateUI();
  return wrapper;
}

function renderExercise(focusHeading) {
  const header = element("header", "exercise-heading");
  const titleWrap = element("div");
  const heading = element("h2", "", `${currentTopic.id}. ${topicTitle(currentTopic)}`);
  heading.tabIndex = -1;
  titleWrap.append(heading, element("p", "", descriptions[currentPart]));
  header.append(titleWrap);

  if (currentPart === 3) {
    const tools = element("div", "heading-tools");
    const enBtn = element("button", "tool-pill", showEnglish ? "English: an" : "English: aus");
    enBtn.type = "button";
    enBtn.setAttribute("aria-pressed", String(showEnglish));
    enBtn.addEventListener("click", () => {
      showEnglish = !showEnglish;
      renderExercise(false);
    });
    tools.append(enBtn);
    header.append(tools);
  }

  exercise.replaceChildren(header, renderContent(currentTopic));
  if (focusHeading) heading.focus({ preventScroll: true });
}

function showLocation(focusHeading = false) {
  const route = location.hash.match(/^#teil-([123])(?:\/([a-z0-9]+))?$/i);
  const part = Number(route?.[1] ?? 1);
  const id = route?.[2]?.toLowerCase() ?? selections.get(part);
  const topic = parts[part].find((candidate) => candidate.id === id) ?? parts[part][0];
  if (part !== currentPart) {
    topicSearch.value = "";
    topicList.scrollTop = 0;
    for (const link of partLinks) {
      if (link.hash === `#teil-${part}`) link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    }
  }
  if (part === currentPart && topic === currentTopic) {
    if (focusHeading) exercise.querySelector("h2").focus({ preventScroll: true });
    return;
  }
  currentPart = part;
  currentTopic = topic;
  selections.set(part, topic.id);
  renderTopics();
  renderExercise(focusHeading);
  window.scrollTo({ top: 0, behavior: "instant" });
}

function navigate(event) {
  const link = event.target.closest("a");
  if (!link || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  const fromPicker = topicList.contains(link);
  if (location.hash !== link.hash) history.pushState(null, "", link.hash);
  if (fromPicker && narrowScreen.matches) topicPicker.open = false;
  showLocation(fromPicker);
}

if (narrowScreen.matches) topicPicker.open = false;
document.querySelector(".reading-parts").addEventListener("click", navigate);
topicList.addEventListener("click", navigate);
topicSearch.addEventListener("input", renderTopics);
window.addEventListener("hashchange", () => showLocation());
window.addEventListener("popstate", () => showLocation());
showLocation();
