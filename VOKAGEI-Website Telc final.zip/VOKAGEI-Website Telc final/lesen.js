const MODULE_NAME = "lesen";
const partLinks = [...document.querySelectorAll(".reading-parts a")];
const topicPicker = document.querySelector(".topic-panel");
const topicSearch = document.querySelector("#topic-search");
const topicList = document.querySelector("#topic-list");
const topicCount = document.querySelector("#topic-count");
const topicEmpty = document.querySelector("#topic-empty");
const exercise = document.querySelector("#reading-exercise");
const narrowScreen = window.matchMedia("(max-width: 920px)");

const parts = { ...readingData, 3: readingPart3Data };
const descriptions = {
  1: "Wähle unter jedem Text die passende Überschrift aus (Aufgaben 1–5).",
  2: "Lies den Text und beantoworte die fünf Fragen (Aufgaben 6–10).",
  3: "Ziehe jede Situation in das passende Info-Text-Feld (oder klicke zum Zuordnen). Wähle X, wenn keiner passt (Aufgaben 11–20).",
};
const selections = new Map();
const drafts = new Map();
let currentPart;
let currentTopic;

// Shared popup dialog for Lesen Teil 1 & Teil 3 fallback picker
const popupDialog = document.createElement("dialog");
popupDialog.className = "option-popup-dialog";
popupDialog.innerHTML = `
  <div class="popup-head">
    <h3 id="popup-title">Auswahl</h3>
    <button type="button" class="popup-close">Schließen</button>
  </div>
  <div class="popup-list" id="popup-list"></div>
`;
document.body.append(popupDialog);
popupDialog.querySelector(".popup-close").addEventListener("click", () => popupDialog.close());
popupDialog.addEventListener("click", (e) => { if (e.target === popupDialog) popupDialog.close(); });

function openOptionPopup(titleText, choices, currentValue, usedValues, onPick) {
  popupDialog.querySelector("#popup-title").textContent = titleText;
  const listEl = popupDialog.querySelector("#popup-list");
  listEl.replaceChildren();

  if (currentValue) {
    const clearBtn = document.createElement("button");
    clearBtn.type = "button";
    clearBtn.className = "popup-choice";
    clearBtn.innerHTML = `<span class="popup-choice-key">×</span><span>Auswahl aufheben</span>`;
    clearBtn.addEventListener("click", () => { onPick(""); popupDialog.close(); });
    listEl.append(clearBtn);
  }

  for (const [key, labelText] of choices) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "popup-choice";
    const isSelected = currentValue === key;
    const isUsedElsewhere = key !== "x" && !isSelected && usedValues.has(key);
    btn.setAttribute("aria-selected", String(isSelected));
    btn.disabled = isUsedElsewhere;
    const keySpan = document.createElement("span");
    keySpan.className = "popup-choice-key";
    keySpan.textContent = key.toUpperCase();
    const txtSpan = document.createElement("span");
    txtSpan.textContent = labelText;
    btn.append(keySpan, txtSpan);
    btn.addEventListener("click", () => {
      onPick(key);
      popupDialog.close();
    });
    listEl.append(btn);
  }
  popupDialog.showModal();
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function normalize(text) {
  return text.toLocaleLowerCase("de").replace(/ß/g, "ss")
    .normalize("NFD").replace(/\p{Diacritic}/gu, "");
}

function topicTitle(topic) {
  return topic.title.replace(/^Test\s+\S+\s*[–-]\s*/i, "");
}

function topicHash(part, id) {
  return `#teil-${part}/${id}`;
}

function topicQuestionCount(topic) {
  return (topic.items ?? topic.questions).length;
}

function updatePartProgressBars() {
  for (const link of partLinks) {
    const p = Number(link.hash.replace("#teil-", ""));
    const pct = VokageiProgress.getPartProgressPercent(MODULE_NAME, p, parts[p], topicQuestionCount);
    link.style.setProperty("--progress", `${pct}%`);
  }
}

function renderTopics() {
  const terms = normalize(topicSearch.value.trim()).split(/\s+/).filter(Boolean);
  const allTopics = parts[currentPart];
  const matches = allTopics.filter((topic) => {
    const searchText = normalize(`${topic.id} ${topic.title} ${topic.keywords ?? ""}`);
    return terms.every((word) => /^\d+[a-z]?$/.test(word)
      ? topic.id.startsWith(word)
      : searchText.includes(word));
  });
  const entries = matches.map((topic) => {
    const entry = element("li");
    const link = element("a");
    link.href = topicHash(currentPart, topic.id);
    link.dataset.topicId = topic.id;
    const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, topic.id, topicQuestionCount(topic));
    link.style.setProperty("--progress", `${pct}%`);
    if (topic.id === currentTopic.id) link.setAttribute("aria-current", "location");
    link.append(element("span", "topic-number", topic.id), element("span", "", topicTitle(topic)));
    entry.append(link);
    return entry;
  });
  topicList.replaceChildren(...entries);
  topicCount.textContent = `${matches.length} von ${allTopics.length} Themen`;
  topicEmpty.hidden = matches.length > 0;
  updatePartProgressBars();
}

function updateCurrentTopicProgressUI(draft) {
  const total = topicQuestionCount(currentTopic);
  VokageiProgress.saveDraft(MODULE_NAME, currentPart, currentTopic.id, draft, total);
  const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, currentTopic.id, total);
  const activeLink = topicList.querySelector(`a[data-topic-id="${CSS.escape(currentTopic.id)}"]`);
  if (activeLink) activeLink.style.setProperty("--progress", `${pct}%`);
  updatePartProgressBars();
  return pct;
}

function getDraft() {
  const key = topicHash(currentPart, currentTopic.id);
  if (!drafts.has(key)) {
    drafts.set(key, VokageiProgress.getDraft(MODULE_NAME, currentPart, currentTopic.id));
  }
  return drafts.get(key);
}

function renderPart1Test(topic) {
  const draft = getDraft();
  const wrapper = element("div", "exercise-layout single-col");
  const panel = element("form", "answer-panel");
  const scrollArea = element("div", "passage reading-scroll");

  const itemsList = topic.items;
  const choices = Object.entries(topic.headings);

  const rowRefs = itemsList.map((q) => {
    const sec = element("section", "passage-entry");
    sec.append(element("h3", "", `Text ${q.num}`));
    sec.append(element("p", "", q.text));

    const barWrap = element("div", "inline-picker-wrap");
    const barBtn = element("button", "inline-picker-bar");
    barBtn.type = "button";
    const labelSpan = element("span", "");
    const chev = element("span", "inline-picker-chevron", "Liste öffnen ▾");
    barBtn.append(labelSpan, chev);
    barWrap.append(barBtn);

    const feedback = element("p", "answer-result");
    sec.append(barWrap, feedback);
    scrollArea.append(sec);

    barBtn.addEventListener("click", () => {
      const used = new Set(draft.answers.values());
      const cur = draft.answers.get(q.num) ?? "";
      openOptionPopup(
        `Überschrift für Text ${q.num} wählen`,
        choices,
        cur,
        used,
        (picked) => {
          if (picked) draft.answers.set(q.num, picked);
          else draft.answers.delete(q.num);
          draft.graded = false;
          updateUI();
        }
      );
    });

    return { q, barBtn, labelSpan, feedback };
  });

  const controls = element("div", "answer-controls");
  const submit = element("button", "cta model-cta", "Antworten prüfen");
  submit.type = "submit";
  const resetBtn = element("button", "secondary-cta", "Zurücksetzen");
  resetBtn.type = "button";
  const result = element("p", "set-result");
  result.setAttribute("role", "status");
  controls.append(submit, resetBtn, result);

  panel.append(scrollArea, controls);
  wrapper.append(panel);

  function updateUI() {
    let correctCount = 0;
    for (const { q, barBtn, labelSpan, feedback } of rowRefs) {
      const chosen = draft.answers.get(q.num) ?? "";
      const foundChoice = choices.find(([k]) => k === chosen);
      if (chosen) {
        barBtn.dataset.selected = "true";
        labelSpan.textContent = `${chosen.toUpperCase()} · ${foundChoice ? foundChoice[1] : chosen}`;
      } else {
        delete barBtn.dataset.selected;
        labelSpan.textContent = "Überschrift wählen (Klicken für Liste A–J)";
      }

      const correct = chosen === q.answer;
      if (correct) correctCount += 1;

      if (!draft.graded) {
        delete barBtn.dataset.state;
        feedback.textContent = "";
        delete feedback.dataset.state;
      } else if (!chosen) {
        delete barBtn.dataset.state;
        feedback.textContent = "Noch unbeantwortet.";
        delete feedback.dataset.state;
      } else {
        barBtn.dataset.state = correct ? "correct" : "incorrect";
        feedback.dataset.state = correct ? "correct" : "incorrect";
        const sol = choices.find(([k]) => k === q.answer)?.[1] ?? q.answer.toUpperCase();
        const expl = q.explanation ? ` ${q.explanation}` : "";
        feedback.textContent = correct
          ? `Richtig!${expl}`
          : `Richtige Antwort: ${q.answer.toUpperCase()} · ${sol}${expl}`;
      }
    }
    const pct = updateCurrentTopicProgressUI(draft);
    controls.style.setProperty("--progress", `${pct}%`);
    result.textContent = draft.graded
      ? `${correctCount} von ${rowRefs.length} richtig · ${rowRefs.length - draft.answers.size} offen`
      : `${draft.answers.size} von ${rowRefs.length} beantwortet`;
  }

  panel.addEventListener("submit", (e) => {
    e.preventDefault();
    draft.graded = true;
    updateUI();
  });
  resetBtn.addEventListener("click", () => {
    draft.answers.clear();
    draft.graded = false;
    VokageiProgress.clearDraft(MODULE_NAME, currentPart, currentTopic.id);
    updateUI();
  });

  updateUI();
  return wrapper;
}

function renderPart3Test(topic) {
  const draft = getDraft();
  const wrapper = element("div", "exercise-layout single-col");
  const panel = element("form", "answer-panel");
  const container = element("div", "reading-scroll");
  const grid = element("div", "teil3-grid");
  const adsCol = element("div", "teil3-ads-col");
  const sitCol = element("div", "teil3-situations-col");

  let selectedSitNum = null;

  function adKeyFromLabel(label, index) {
    const m = label.match(/(?:Text|Anzeige|Info-Text)\s*([A-L])\b/i) || label.match(/^([A-L])\b/i);
    return (m ? m[1] : String.fromCharCode(97 + index)).toLowerCase();
  }

  function assignSituation(sitNum, targetKey) {
    if (!targetKey) {
      draft.answers.delete(sitNum);
    } else {
      if (targetKey !== "x") {
        // One situation per Info-Text A–L
        for (const [k, v] of [...draft.answers.entries()]) {
          if (v === targetKey && k !== sitNum) draft.answers.delete(k);
        }
      }
      draft.answers.set(sitNum, targetKey);
    }
    draft.graded = false;
    selectedSitNum = null;
    updateUI();
  }

  function openSituationPickerForZone(targetKey, titleText) {
    const sitChoices = topic.questions.map((q) => [String(q.num), `${q.num}. ${q.stem}`]);
    const assignedMap = new Map();
    for (const [sNum, tKey] of draft.answers.entries()) {
      assignedMap.set(String(sNum), tKey);
    }
    // Current value in this zone (for A–L)
    let curSit = "";
    if (targetKey !== "x") {
      for (const [sNum, tKey] of draft.answers.entries()) {
        if (tKey === targetKey) curSit = String(sNum);
      }
    }
    openOptionPopup(
      titleText,
      sitChoices,
      curSit,
      new Set(),
      (pickedNumStr) => {
        if (!pickedNumStr) {
          if (curSit) assignSituation(Number(curSit), "");
        } else {
          assignSituation(Number(pickedNumStr), targetKey);
        }
      }
    );
  }

  const dropZones = new Map();
  const adFeedbacks = new Map();

  topic.ads.forEach((ad, idx) => {
    const key = adKeyFromLabel(ad.label, idx);
    const card = element("article", "teil3-ad-card");

    const dz = element("div", "drop-zone");
    dz.tabIndex = 0;
    dz.setAttribute("role", "button");
    dz.setAttribute("aria-label", `Antwortfeld für ${ad.label}`);
    dz.dataset.adKey = key;
    dropZones.set(key, dz);

    dz.addEventListener("dragover", (e) => { e.preventDefault(); dz.classList.add("is-over"); });
    dz.addEventListener("dragleave", () => dz.classList.remove("is-over"));
    dz.addEventListener("drop", (e) => {
      e.preventDefault();
      dz.classList.remove("is-over");
      const sNum = Number(e.dataTransfer.getData("text/plain"));
      if (sNum) assignSituation(sNum, key);
    });
    dz.addEventListener("click", (e) => {
      if (e.target.closest(".dropped-remove")) return;
      if (selectedSitNum !== null) {
        assignSituation(selectedSitNum, key);
      } else {
        openSituationPickerForZone(key, `Situation für ${ad.label} wählen`);
      }
    });
    dz.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        dz.click();
      }
    });

    card.append(dz);
    card.append(element("h4", "", ad.label));
    for (const p of ad.paragraphs) card.append(element("p", "", p));

    const fb = element("p", "answer-result");
    adFeedbacks.set(key, fb);
    card.append(fb);
    adsCol.append(card);
  });

  // Right column: Hint + Situations 11–20 + X Drop Box
  const hint = element("p", "teil3-hint", "Ziehe eine Situation auf „Hier Antwort ablegen“ – oder klicke eine Situation an und dann auf ein Info-Text-Feld.");
  sitCol.append(hint);

  const sitCards = new Map();
  for (const q of topic.questions) {
    const card = element("button", "situation-card");
    card.type = "button";
    card.draggable = true;
    card.dataset.sitNum = String(q.num);
    card.append(element("span", "situation-num", String(q.num)), element("span", "", q.stem));

    card.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", String(q.num));
      selectedSitNum = q.num;
      updateSelectionHighlight();
    });
    card.addEventListener("click", () => {
      selectedSitNum = selectedSitNum === q.num ? null : q.num;
      updateSelectionHighlight();
    });

    sitCards.set(q.num, card);
    sitCol.append(card);
  }

  // X · Kein passender Info-Text drop card
  const xCard = element("div", "x-drop-card");
  xCard.append(element("h4", "", "X · Kein passender Info-Text"));
  const xDz = element("div", "drop-zone");
  xDz.tabIndex = 0;
  xDz.setAttribute("role", "button");
  xDz.dataset.adKey = "x";
  dropZones.set("x", xDz);

  xDz.addEventListener("dragover", (e) => { e.preventDefault(); xDz.classList.add("is-over"); });
  xDz.addEventListener("dragleave", () => xDz.classList.remove("is-over"));
  xDz.addEventListener("drop", (e) => {
    e.preventDefault();
    xDz.classList.remove("is-over");
    const sNum = Number(e.dataTransfer.getData("text/plain"));
    if (sNum) assignSituation(sNum, "x");
  });
  xDz.addEventListener("click", (e) => {
    if (e.target.closest(".dropped-remove")) return;
    if (selectedSitNum !== null) {
      assignSituation(selectedSitNum, "x");
    } else {
      openSituationPickerForZone("x", "Situation für X (Kein passender Info-Text) wählen");
    }
  });
  const xFb = element("p", "answer-result");
  adFeedbacks.set("x", xFb);
  xCard.append(xDz, xFb);
  sitCol.append(xCard);

  grid.append(adsCol, sitCol);
  container.append(grid);

  const controls = element("div", "answer-controls");
  const submit = element("button", "cta model-cta", "Antworten prüfen");
  submit.type = "submit";
  const resetBtn = element("button", "secondary-cta", "Zurücksetzen");
  resetBtn.type = "button";
  const result = element("p", "set-result");
  result.setAttribute("role", "status");
  controls.append(submit, resetBtn, result);

  panel.append(container, controls);
  wrapper.append(panel);

  function updateSelectionHighlight() {
    for (const [num, card] of sitCards.entries()) {
      card.dataset.selected = selectedSitNum === num ? "true" : "false";
    }
  }

  function updateUI() {
    updateSelectionHighlight();
    for (const [num, card] of sitCards.entries()) {
      card.dataset.assigned = draft.answers.has(num) ? "true" : "false";
    }

    // Group assigned situations by ad key
    const byKey = new Map();
    for (const [sNum, tKey] of draft.answers.entries()) {
      if (!byKey.has(tKey)) byKey.set(tKey, []);
      byKey.get(tKey).push(sNum);
    }

    let correctCount = 0;
    for (const q of topic.questions) {
      if (draft.answers.get(q.num) === q.answer) correctCount += 1;
    }

    for (const [key, dz] of dropZones.entries()) {
      const assignedNums = byKey.get(key) || [];
      const fb = adFeedbacks.get(key);
      dz.replaceChildren();
      delete dz.dataset.state;
      fb.textContent = "";
      delete fb.dataset.state;

      if (assignedNums.length === 0) {
        delete dz.dataset.filled;
        dz.textContent = key === "x"
          ? "Situationen ohne passenden Info-Text hier ablegen"
          : "Hier Antwort ablegen";
        if (draft.graded && key !== "x") {
          const expectedQ = topic.questions.find((q) => q.answer === key);
          if (expectedQ) {
            fb.textContent = `Richtige Situation: ${expectedQ.num}`;
          }
        }
      } else {
        dz.dataset.filled = "true";
        const itemsWrap = element("div", "dropped-items");
        let allCorrectInZone = true;
        const notes = [];
        for (const sNum of assignedNums) {
          const q = topic.questions.find((item) => item.num === sNum);
          const pill = element("div", "dropped-pill");
          pill.append(element("span", "", `${sNum}. ${q ? q.stem : ""}`));
          const rmBtn = element("button", "dropped-remove", "×");
          rmBtn.type = "button";
          rmBtn.setAttribute("aria-label", `Situation ${sNum} entfernen`);
          rmBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            assignSituation(sNum, "");
          });
          pill.append(rmBtn);
          itemsWrap.append(pill);

          if (draft.graded && q) {
            if (q.answer === key) {
              notes.push(`Situation ${sNum}: Richtig!`);
            } else {
              allCorrectInZone = false;
              notes.push(`Situation ${sNum}: Richtig ist ${q.answer.toUpperCase()}`);
            }
          }
        }
        dz.append(itemsWrap);
        if (draft.graded) {
          dz.dataset.state = allCorrectInZone ? "correct" : "incorrect";
          fb.dataset.state = allCorrectInZone ? "correct" : "incorrect";
          fb.textContent = notes.join(" · ");
        }
      }
    }

    const pct = updateCurrentTopicProgressUI(draft);
    controls.style.setProperty("--progress", `${pct}%`);
    result.textContent = draft.graded
      ? `${correctCount} von ${topic.questions.length} richtig · ${topic.questions.length - draft.answers.size} offen`
      : `${draft.answers.size} von ${topic.questions.length} zugeordnet`;
  }

  panel.addEventListener("submit", (e) => {
    e.preventDefault();
    draft.graded = true;
    updateUI();
  });
  resetBtn.addEventListener("click", () => {
    draft.answers.clear();
    draft.graded = false;
    selectedSitNum = null;
    VokageiProgress.clearDraft(MODULE_NAME, currentPart, currentTopic.id);
    updateUI();
  });

  updateUI();
  return wrapper;
}

function renderPart2Test(topic) {
  const draft = getDraft();
  const box = element("section", "passage reading-scroll");
  box.tabIndex = 0;
  box.setAttribute("aria-label", "Lesetext");
  box.append(...topic.paragraphs.map((paragraph) => element("p", "", paragraph)));

  const form = element("form", "answer-panel");
  const questionList = element("div", "answer-scroll");
  questionList.tabIndex = 0;
  questionList.setAttribute("aria-label", "Aufgaben");

  const questions = topic.questions.map((question) => {
    const fieldset = element("fieldset", "question");
    fieldset.append(element("legend", "", `${question.num}. ${question.stem}`));
    const choices = Object.entries(question.options);
    const selected = draft.answers.get(question.num) ?? "";
    const inputs = [];
    for (const [key, option] of choices) {
      const optionLabel = element("label");
      const input = element("input");
      input.type = "radio";
      input.name = String(question.num);
      input.value = key;
      input.checked = selected === key;
      inputs.push(input);
      optionLabel.append(input, element("span", "", `${key.toUpperCase()} · ${option}`));
      fieldset.append(optionLabel);
    }
    const feedback = element("p", "answer-result");
    fieldset.append(feedback);
    questionList.append(fieldset);
    return { fieldset, question, feedback, choices, inputs };
  });

  const controls = element("div", "answer-controls");
  const submit = element("button", "cta model-cta", "Antworten prüfen");
  submit.type = "submit";
  const resetBtn = element("button", "secondary-cta", "Zurücksetzen");
  resetBtn.type = "button";
  const result = element("p", "set-result");
  result.setAttribute("role", "status");
  controls.append(submit, resetBtn, result);
  form.append(questionList, controls);

  function updateResult() {
    let correctCount = 0;
    for (const { question, choices, feedback } of questions) {
      const chosen = draft.answers.get(question.num);
      const correct = chosen === question.answer;
      if (correct) correctCount += 1;
      if (!draft.graded) {
        feedback.textContent = "";
        delete feedback.dataset.state;
      } else if (!chosen) {
        feedback.textContent = "Noch unbeantwortet.";
        delete feedback.dataset.state;
      } else {
        feedback.dataset.state = correct ? "correct" : "incorrect";
        const sol = choices.find(([k]) => k === question.answer)?.[1] ?? question.answer.toUpperCase();
        const expl = question.explanation ? ` ${question.explanation}` : "";
        feedback.textContent = correct
          ? `Richtig!${expl}`
          : `Richtige Antwort: ${question.answer.toUpperCase()} · ${sol}${expl}`;
      }
    }
    const pct = updateCurrentTopicProgressUI(draft);
    controls.style.setProperty("--progress", `${pct}%`);
    result.textContent = draft.graded
      ? `${correctCount} von ${questions.length} richtig · ${questions.length - draft.answers.size} offen`
      : `${draft.answers.size} von ${questions.length} beantwortet`;
  }

  form.addEventListener("change", (event) => {
    const number = Number(event.target.name);
    if (event.target.value) draft.answers.set(number, event.target.value);
    else draft.answers.delete(number);
    draft.graded = false;
    updateResult();
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    draft.graded = true;
    updateResult();
  });
  resetBtn.addEventListener("click", () => {
    draft.answers.clear();
    draft.graded = false;
    VokageiProgress.clearDraft(MODULE_NAME, currentPart, currentTopic.id);
    for (const { inputs } of questions) {
      for (const inp of inputs) inp.checked = false;
    }
    updateResult();
  });
  updateResult();

  const layout = element("div", "exercise-layout");
  layout.append(box, form);
  return layout;
}

function renderExercise(focusHeading) {
  const header = element("header", "exercise-heading");
  const titleWrap = element("div");
  const heading = element("h2", "", `Test ${currentTopic.id} – ${topicTitle(currentTopic)}`);
  heading.tabIndex = -1;
  titleWrap.append(heading, element("p", "", descriptions[currentPart]));
  header.append(titleWrap);
  const body = currentPart === 2
    ? renderPart2Test(currentTopic)
    : currentPart === 3
      ? renderPart3Test(currentTopic)
      : renderPart1Test(currentTopic);
  exercise.replaceChildren(header, body);
  if (focusHeading) heading.focus({ preventScroll: true });
}

function showLocation(focusHeading = false) {
  const route = location.hash.match(/^#teil-([123])(?:\/([a-z0-9]+))?$/i);
  const part = Number(route?.[1] ?? 1);
  const id = route?.[2]?.toLowerCase() ?? selections.get(part);
  const topic = parts[part].find((candidate) => candidate.id === id) ?? parts[part][0];
  if (part !== currentPart) {
    topicSearch.value = "";
    topicList.scrollTop = 0;
    for (const link of partLinks) {
      if (link.hash === `#teil-${part}`) link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    }
  }
  if (part === currentPart && topic === currentTopic) {
    if (focusHeading) exercise.querySelector("h2").focus({ preventScroll: true });
    return;
  }
  currentPart = part;
  currentTopic = topic;
  selections.set(part, topic.id);
  renderTopics();
  renderExercise(focusHeading);
  window.scrollTo({ top: 0, behavior: "instant" });
}

function navigate(event) {
  const link = event.target.closest("a");
  if (!link || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  const fromPicker = topicList.contains(link);
  if (location.hash !== link.hash) history.pushState(null, "", link.hash);
  if (fromPicker && narrowScreen.matches) topicPicker.open = false;
  showLocation(fromPicker);
}

if (narrowScreen.matches) topicPicker.open = false;
document.querySelector(".reading-parts").addEventListener("click", navigate);
topicList.addEventListener("click", navigate);
topicSearch.addEventListener("input", renderTopics);
window.addEventListener("hashchange", () => showLocation());
window.addEventListener("popstate", () => showLocation());
showLocation();
