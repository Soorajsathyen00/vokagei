const features = {
  about: {
    heading: "Über VOKAGEI",
    message: "VOKAGEI hilft dir bei der Vorbereitung auf alle fünf Teile der telc Deutsch B2-Prüfung: Lesen, Hören, Sprachbausteine, Schreiben und Sprechen.",
    underConstruction: false,
  },
  wortschatz: {
    heading: "B2-Wortschatz – Page under construction",
    message: "Diese Seite befindet sich noch im Aufbau.",
    underConstruction: true,
  },
  premium: {
    heading: "Premium – Page under construction",
    message: "Diese Seite befindet sich noch im Aufbau.",
    underConstruction: true,
  },
  modelltest: {
    heading: "B2-Model Test – Page under construction",
    message: "Diese Seite befindet sich noch im Aufbau.",
    underConstruction: true,
  },
};

const dialog = document.querySelector(".feature-dialog");
const title = document.querySelector("#dialog-title");
const copy = document.querySelector("#dialog-copy");
const iconBox = document.querySelector("#dialog-icon");

document.querySelectorAll("[data-feature]").forEach((button) => {
  button.addEventListener("click", () => {
    const entry = features[button.dataset.feature];
    if (!entry) return;
    if (iconBox) iconBox.hidden = !entry.underConstruction;
    title.textContent = entry.heading;
    copy.textContent = entry.message;
    dialog.showModal();
  });
});

function updateHomeProgressCards() {
  if (typeof VokageiProgress === "undefined") return;
  document.querySelectorAll(".practice-card[data-module]").forEach((card) => {
    const moduleName = card.dataset.module;
    const totalTests = Number(card.dataset.total || 0);
    const summary = VokageiProgress.getModuleSummary(moduleName, totalTests);
    card.style.setProperty("--progress", `${summary.percent}%`);
    const countEl = card.querySelector(".count");
    if (countEl) {
      const baseLabel = countEl.dataset.defaultLabel || `${totalTests} Übungssätze`;
      if (summary.completedTests > 0) {
        countEl.textContent = `${summary.completedTests} / ${totalTests} erledigt`;
      } else {
        countEl.textContent = baseLabel;
      }
    }
  });
}

updateHomeProgressCards();
window.addEventListener("pageshow", updateHomeProgressCards);
window.addEventListener("storage", updateHomeProgressCards);

(function initHeroSparkles() {
  const hero = document.querySelector(".hero");
  if (!hero) return;
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
  if (window.innerWidth <= 768) return;

  const canvas = document.createElement("canvas");
  canvas.className = "hero-sparkles";
  canvas.setAttribute("aria-hidden", "true");
  hero.append(canvas);

  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const palette = [
    "255, 224, 130", // warm gold
    "155, 220, 191", // soft mint-teal
    "255, 255, 255", // soft white
  ];
  const particles = [];
  let rafId = null;
  let lastSpawn = 0;

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = hero.getBoundingClientRect();
    canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();
  window.addEventListener("resize", resize);

  function spawnSparkle(x, y) {
    if (particles.length > 26) particles.shift();
    const angle = Math.random() * Math.PI * 2;
    const dist = Math.random() * 26;
    particles.push({
      x: x + Math.cos(angle) * dist,
      y: y + Math.sin(angle) * dist,
      vx: (Math.random() - 0.5) * 0.25,
      vy: -0.18 - Math.random() * 0.32,
      size: 2 + Math.random() * 2.8,
      life: 0,
      maxLife: 42 + Math.random() * 28,
      color: palette[Math.floor(Math.random() * palette.length)],
      isStar: Math.random() > 0.35,
      rot: Math.random() * Math.PI,
    });
  }

  function drawFourPointStar(x, y, r, rot) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);
    ctx.beginPath();
    const inner = r * 0.26;
    for (let i = 0; i < 4; i++) {
      const a = (i * Math.PI) / 2;
      ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      ctx.lineTo(Math.cos(a + Math.PI / 4) * inner, Math.sin(a + Math.PI / 4) * inner);
    }
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function tick() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life += 1;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += 0.015;
      const progress = p.life / p.maxLife;
      const alpha = progress < 0.25
        ? (progress / 0.25) * 0.58
        : (1 - (progress - 0.25) / 0.75) * 0.58;

      if (p.life >= p.maxLife || alpha <= 0.01) {
        particles.splice(i, 1);
        continue;
      }

      ctx.fillStyle = `rgba(${p.color}, ${alpha.toFixed(3)})`;
      if (p.isStar) {
        drawFourPointStar(p.x, p.y, p.size, p.rot);
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 0.45, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    if (particles.length > 0) {
      rafId = requestAnimationFrame(tick);
    } else {
      rafId = null;
    }
  }

  hero.addEventListener("pointerenter", () => hero.classList.add("is-hovering"));
  hero.addEventListener("pointerleave", () => hero.classList.remove("is-hovering"));
  hero.addEventListener("pointermove", (e) => {
    const rect = hero.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    hero.style.setProperty("--mx", `${x}px`);
    hero.style.setProperty("--my", `${y}px`);
    hero.classList.add("is-hovering");

    const now = performance.now();
    if (now - lastSpawn > 42) {
      lastSpawn = now;
      spawnSparkle(x, y);
      if (Math.random() > 0.55) spawnSparkle(x, y);
    }
    if (!rafId) rafId = requestAnimationFrame(tick);
  });
})();
