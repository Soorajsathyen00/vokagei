const sprechenData = {
  "1": [
    {
      "id": "1",
      "title": "Thema 1 – Buch (Mein Lieblingsbuch)",
      "intro": [
        "In meiner Präsentation möchte ich über ein Buch / mein Lieblingsbuch berichten.",
        "Als Thema meiner Präsentation habe ich ein Buch gewählt.",
        "Das Thema meiner Präsentation ist ein Roman, der mich sehr beeindruckt hat."
      ],
      "questions": [
        "Hast du auch andere Bücher von diesem Autor/von … gelesen?",
        "Wann hast du das Buch gelesen?",
        "Wie viele Seiten hat das Werk?",
        "Liest du nur Krimis/Romane/… oder auch andere Bücher?",
        "Was für Bücher liest du (noch) gern?",
        "Wurde aus diesem Buch auch ein Film gedreht?",
        "Kaufst du oft Bücher?",
        "Hast du das Buch gekauft oder von jemandem bekommen?",
        "Wann hast du dieses Buch gekauft/bekommen?",
        "Ist … dein Lieblingsautor/Lieblingsschriftsteller?",
        "Wer ist dein Lieblingsautor/Lieblingsschriftsteller?",
        "Wer hat dir dieses Buch empfohlen?",
        "Wem würdest du dieses Buch empfehlen?",
        "Hast du jeden Tag Zeit Bücher zu lesen?",
        "Hast du eine Lieblingsfigur in dem Werk?",
        "Wer ist deine Lieblingsfigur im Werk?",
        "Wie lange hast du das Werk/Buch gelesen?",
        "Wo kaufst du im Allgemeinen Bücher? In einer Buchhandlung oder im Internet?"
      ],
      "sample_answer_de": "Ich habe das Buch vor etwa einem Jahr gelesen, weil ein guter Freund es mir empfohlen hat. Es hat ungefähr 300 Seiten und lässt sich sehr flüssig lesen. Normalerweise kaufe ich meine Bücher gern in einer kleinen Buchhandlung, aber manchmal bestelle ich sie auch online. Ich würde dieses Buch allen empfehlen, die spannende Geschichten mögen."
    },
    {
      "id": "2",
      "title": "Thema 2 – Film",
      "intro": [
        "In meiner Präsentation möchte ich über meinen Lieblingsfilm berichten.",
        "Als Thema meiner Präsentation habe ich einen Film gewählt, den ich vor Kurzem gesehen habe.",
        "Das Thema meiner Präsentation ist ein sehr interessanter Film."
      ],
      "questions": [
        "Wie lange dauert der Film?/Ist der Film lang?",
        "Wann wurde der Film gedreht?",
        "Wann hast du diesen Film gesehen?",
        "Mit wem hast du diesen Film gesehen?",
        "Wo hast du diesen Film gesehen? Im Kino oder zu Hause?",
        "Wo siehst du lieber Filme? Im Kino oder zu Hause? Warum?",
        "Gehst du regelmäßig ins Kino?",
        "(Magst)/Siehst du nur (die) Krimis/Abenteuerfilme/Lustspiele/…, oder auch andere Filme?",
        "Welche Szene hat dir am besten gefallen?",
        "Wer hat dir diesen Film empfohlen?",
        "Wem würdest du diesen Film empfehlen?",
        "Welche(r) Schauspieler(in) spielt/spielen in dem Film?",
        "Ist/sind … dein(e) Lieblingsschauspieler(in)?",
        "Wer ist dein(e) Lieblingsschauspieler(in)?",
        "Wer ist der Regisseur des Films?",
        "Welche Figur (des Films) magst du/gefällt dir besonders?",
        "Hast du diesen Film nur einmal/schon mehrmals gesehen?",
        "Weißt du vielleicht, wer die Musik des Films komponiert hat?"
      ],
      "sample_answer_de": "Der Film dauert etwa zwei Stunden und wurde vor einigen Jahren gedreht. Ich habe ihn letztes Wochenende mit Freunden im Kino gesehen. Ich gehe gern ins Kino, weil die Atmosphäre und der Ton dort viel intensiver sind als zu Hause. Besonders die Filmmusik und das Ende haben mir sehr gut gefallen."
    },
    {
      "id": "3",
      "title": "Thema 3 – Reise",
      "intro": [
        "In meiner Präsentation möchte ich über eine besondere Reise berichten.",
        "Als Thema meiner Präsentation habe ich meine letzte Reise gewählt.",
        "Das Thema meiner Präsentation ist ein Urlaub, den ich nie vergessen werde."
      ],
      "questions": [
        "Wie lange hat die Fahrt gedauert?",
        "War die Fahrt anstrengend/langweilig?",
        "Wie war das Wetter unterwegs?",
        "Wie war das Wetter in …/während der Reise?",
        "Warst du schon früher in …?",
        "Möchtest du noch einmal nach … fahren?",
        "Welche Sehenswürdigkeit hat dir in … am besten/besonders gefallen?",
        "Welche Sehenswürdigkeit hast du am schönsten/interessantesten gefunden?",
        "Möchtest du vielleicht später/in der Zukunft in …/dort leben?",
        "Womit/Mit wem bist du nach …/dorthin gefahren?",
        "Was habt ihr vormittags/nachmittags/abends gemacht?",
        "Habt ihr jeden Tag in dem Hotel/auf dem Campingplatz/… gefrühstückt/zu Mittag gegessen?",
        "Wo hast du/habt ihr übernachtet?",
        "Wohin möchtest du dieses Jahr/diesen Sommer fahren?",
        "Was war dein bestes Erlebnis während der Reise?",
        "Mit welchem Verkehrsmittel fährst du am liebsten?",
        "Was hast du dort/in … gekauft?"
      ],
      "sample_answer_de": "Die Fahrt hat ungefähr vier Stunden gedauert und war überhaupt nicht langweilig, weil die Landschaft wunderschön war. Das Wetter war meistens sonnig und angenehm. Vormittags haben wir die Altstadt besichtigt und abends zusammen regional gegessen. Ich würde sehr gern noch einmal dorthin fahren."
    },
    {
      "id": "4",
      "title": "Thema 4 – Musikveranstaltung",
      "intro": [
        "In meiner Präsentation möchte ich über ein Konzert / eine Musikveranstaltung berichten.",
        "Als Thema meiner Präsentation habe ich eine unvergessliche Musikveranstaltung gewählt.",
        "Das Thema meiner Präsentation ist ein Live-Konzert, das ich besucht habe."
      ],
      "questions": [
        "Wie oft gehst du/Gehst du oft ins Konzert?",
        "Warum magst du ins Konzert gehen?",
        "Ist … deine Lieblingsgruppe?",
        "Welche Musikrichtung gefällt dir am besten/noch?",
        "Magst du nur diese Musikrichtung?",
        "Spielst du in einer Gruppe?",
        "Gab es viele Leute in dem Konzert?",
        "Was kostete die Eintrittskarte?/War die Eintrittskarte teuer?",
        "Hörst du nur Rock/Popmusik?",
        "Hörst du manchmal auch klassische Musik?",
        "Wo hat das Konzert stattgefunden?",
        "Wie lange dauerte das Konzert?",
        "Mit wem warst du dort/im Konzert?",
        "Wie war die Stimmung im Konzert?",
        "Wie hast du diese Gruppe kennen gelernt?",
        "Seit wann hörst du Rockmusik/leichte Musik?"
      ],
      "sample_answer_de": "Ich gehe zwar nicht jede Woche ins Konzert, aber ein- bis zweimal im Jahr besuche ich gern ein Live-Event. Das Konzert dauerte fast drei Stunden und die Stimmung im Publikum war fantastisch. Die Eintrittskarte war nicht ganz billig, aber das Erlebnis hat sich absolut gelohnt."
    },
    {
      "id": "5",
      "title": "Thema 5 – Sportereignis",
      "intro": [
        "In meiner Präsentation möchte ich über ein Sportereignis berichten.",
        "Als Thema meiner Präsentation habe ich ein spannendes Sportereignis gewählt.",
        "Das Thema meiner Präsentation ist ein wichtiges Spiel / Turnier."
      ],
      "questions": [
        "Welche Sportarten magst du/gefallen dir (besonders)?",
        "Treibst du (regelmäßig) Sport?",
        "Treibst du nur in der Schule (oder auch in deiner Freizeit) Sport?",
        "Seit wann spielst du Fußball/Handball/Korbball/…?",
        "Was kostete die Eintrittskarte?/War die Eintrittskarte teuer?",
        "Gab es viele Leute dort?",
        "Wie war die Stimmung?",
        "Hast du eine Lieblingsmannschaft?",
        "Ist … deine Lieblingsmannschaft?",
        "Nimmst du oft an Sportereignissen teil?",
        "Hast du einen Lieblingsspieler in der Mannschaft?",
        "Spielst du in einer Mannschaft/in einem Verein?",
        "Mit wem hast du an diesem Sportereignis teilgenommen?",
        "Wie lange hat das Spiel gedauert?",
        "Wo treibst du lieber Sport? In einer Halle oder im Freien?"
      ],
      "sample_answer_de": "Ich treibe in meiner Freizeit regelmäßig Sport, vor allem Krafttraining und Laufen, am liebsten im Freien. Bei dem Sportereignis waren tausende Zuschauer im Stadion, und die Stimmung war von der ersten bis zur letzten Minute großartig. Besonders beeindruckt hat mich der Teamgeist der Mannschaft."
    }
  ],
  "2": [
    {
      "id": "1",
      "title": "Thema 1 – Wie entwickelt sich das Rauchen in Deutschland?",
      "text": "Das Rauchen galt lange Zeit als etwas, das erwachsene Filmstars tun, während es Kindern nicht erlaubt ist. Obwohl die Gesamtzahl der Raucher abnimmt (ca. 21 Millionen), steigt die Zahl der gerauchten Zigaretten bei Jugendlichen und Frauen weiter an. Gründe sind Gruppenzwang, Nachahmung von Eltern oder Prominenten, Werbung sowie der Wunsch, erwachsen zu wirken oder Unsicherheiten zu überspielen.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "2",
      "title": "Thema 2 – Hochzeit nur zu zweit!",
      "text": "Christiane und Olaf Witte aus Marburg haben heimlich und ohne Gäste an der Nordseeküste geheiratet. Die gesamte Feier inklusive Flitterwochen kostete etwa 1.800 Euro. Viele Paare in Deutschland entscheiden sich heute für eine kleine, bescheidene Hochzeit statt teurer Großfeiern, um Stress und hohe Kosten zu vermeiden – auch wenn Familie und Freunde manchmal enttäuscht sind.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "3",
      "title": "Thema 3 – Eine Woche ohne Internet!",
      "text": "Ein Selbstexperiment „eine Woche ohne Netz“ zeigt, wie sehr das Internet unseren Alltag bestimmt: Vom schnellen Nachschlagen von Fakten über Online-Bestellungen bis zum Fahrkartenkauf und der Kommunikation mit Freunden. Ohne Netz dauert vieles länger, und spontane Planänderungen per E-Mail erreichen einen zu spät.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "4",
      "title": "Thema 4 – Soll digitales Unterrichtsmaterial in den Schulen eingesetzt werden?",
      "text": "Befürworter von E-Books und digitalen Materialien betonen Aktualität, Verlinkungen, Vorlese- und Notizfunktionen sowie die Förderung der Medienkompetenz. Kritiker verweisen auf hohe Investitionskosten, fehlende Langzeitstudien und darauf, dass gedruckte Bücher weniger ablenken.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "5",
      "title": "Thema 5 – Alternative Lebensform im Alter",
      "text": "Pflege-WGs bieten älteren Menschen Gemeinschaft und Schutz vor Einsamkeit bei gleichzeitiger professioneller Unterstützung. Sozialverbände warnen jedoch davor, dass Pflegebedürftige aus Kostengründen abgeschoben werden könnten, wenn die ambulante Betreuung nicht ausreicht.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "6",
      "title": "Thema 6 – Fast Food kann süchtig machen",
      "text": "US-Forscher (Paul Kenny & Paul Johnson) zeigten in Experimenten, dass extrem kalorien- und fettreiche Nahrung das Belohnungssystem im Gehirn ähnlich überreizt wie Drogen. Immer größere Mengen sind nötig, um dasselbe Wohlgefühl zu erreichen.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "7",
      "title": "Thema 7 – Rette Leben mit einer Blutspende",
      "text": "In Deutschland werden täglich rund 15.000 Blutspenden benötigt, doch nur 3–5 % der Bevölkerung spenden regelmäßig. Gesunde Erwachsene zwischen 18 und 68 Jahren (ab 50 kg) können nach einem kurzen Gesundheitscheck in 20–30 Minuten Leben retten.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "8",
      "title": "Thema 8 – Fernsehen bildet",
      "text": "Während reine Unterhaltungssendungen kaum Wissen vermitteln, bieten gut gemachte Wissens- und Informationssendungen verständliche Bilder und Erklärungen. Entscheidend ist die bewusste Auswahl der Programme – besonders bei Kindern.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "9",
      "title": "Thema 9 – Der Ruf nach mehr direkter Demokratie",
      "text": "Nach großen Infrastrukturprojekten fordern viele Bürger mehr Volksabstimmungen. Befürworter sehen darin stärkere Legitimation; Kritiker warnen vor Stimmungsmache, mangelnder Sachkenntnis und langsameren politischen Entscheidungen.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "10",
      "title": "Thema 10 – Ein Solarium im Winter – Gut für die Gesundheit?",
      "text": "Sonnenlicht hebt im Winter die Stimmung und fördert Vitamin D. Ärzte und Krankenkassen warnen jedoch vor Solarien mit hoher Strahlungsintensität wegen Hautschäden und Hautkrebsrisiko – besonders für junge und hellhäutige Menschen.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "11",
      "title": "Thema 11 – Elektroautos – Verkehrsmittel der nahen Zukunft?",
      "text": "Elektroautos punkten mit niedrigen Betriebskosten (~1,50 €/100 km), Steuer- und Versicherungsvorteilen sowie Umweltfreundlichkeit und geringer Lautstärke. Nachteile sind hohe Anschaffungskosten, begrenzte Reichweite (80–300 km), lange Ladezeiten und dünne Ladeinfrastruktur.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "12",
      "title": "Thema 12 – Gesund durch Lachen?",
      "text": "Kinder lachen bis zu 400-mal am Tag, Erwachsene nur etwa 15-mal. Eine Minute Lachen entspannt so stark wie 45 Minuten Entspannungstraining und lindert Schmerzen. Allerdings kann Lachen auch ausgrenzend wirken, wenn es auf Kosten anderer geschieht.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "13",
      "title": "Thema 13 – Selbst gekocht schmeckt es am besten",
      "text": "84 % der Deutschen bevorzugen Selbstgekochtes, weil man Qualität, Frische und Zutaten selbst kontrolliert und Konservierungs- sowie Allergie-Auslöser vermeiden kann – im Gegensatz zu Fast Food und Fertiggerichten.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "14",
      "title": "Thema 14 – Wahlen schon mit 16?",
      "text": "Befürworter des Wahlrechts ab 16 betonen politisches Interesse Jugendlicher und das demokratische Prinzip der Mitbestimmung bei langfristigen Entscheidungen. Kritiker befürchten fehlende Erfahrung oder Anfälligkeit für Extrempositionen.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "15",
      "title": "Thema 15 – Teilzeitarbeit auch für Männer?",
      "text": "Immer mehr Männer übernehmen familiäre Aufgaben in Teilzeit und entwickeln Organisationstalent und Flexibilität. Unternehmen profitieren durch Jobsharing und erhaltene Fachkompetenz, stehen aber vor höheren Verwaltungskosten.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "16",
      "title": "Thema 16 – Arbeiten bis 75 – eine utopische Vorstellung?",
      "text": "Da die Lebenserwartung stark gestiegen ist, wird über längeres Arbeiten oder ein flexibles Renteneintrittsalter diskutiert. Kritiker weisen darauf hin, dass viele ab 50 kaum noch Stellen finden und nicht jeder körperlich bis 75 arbeiten kann.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "17",
      "title": "Thema 17 – Die Schuluniform: Pro und Kontra",
      "text": "Schuluniformen können Markenzwang und soziale Ausgrenzung reduzieren und das Gemeinschaftsgefühl stärken. Gegner argumentieren, dass Uniformen keine Aggressionen verhindern und offene Gespräche wichtiger sind.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "18",
      "title": "Thema 18 – Leistungssport und Doping",
      "text": "Einige Stimmen fordern kontrollierte Freigabe gegen Verlogenheit, während Gegner Doping als ungesund, unfair und gefährliches Vorbild für den Breitensport ablehnen und wirksamere Kontrollen fordern.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "19",
      "title": "Thema 19 – Haushaltsgeräte erleichtern die Hausarbeit",
      "text": "Küchenmaschinen, Kaffeepad-Maschinen und Mixer sparen Zeit und Kraft und bieten moderne Sicherheitsfunktionen. Dennoch schätzen viele Verbraucher weiterhin einfache, langlebige Einzelgeräte.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "20",
      "title": "Thema 20 – Trinkgeld geben",
      "text": "Trinkgeld honoriert guten Service und bessert in manchen Berufen niedrige Grundgehälter auf. Da die Gepflogenheiten von Land zu Land stark variieren, sollte man sich vor Reisen informieren.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "21",
      "title": "Thema 21 – Gleiche Chancen für Männer und Frauen – gesetzlich geregelt",
      "text": "Die Frauenquote soll Benachteiligungen bei Einstellungen und Führungspositionen abbauen. Kritiker befürchten, dass formale Quoten über Qualifikation gestellt werden könnten; Einigkeit herrscht darüber, dass Gleichberechtigung auch im Denken verankert sein muss.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "22",
      "title": "Thema 22 – Musik statt Bohrgeräusche beim Zahnarzt",
      "text": "Antischall-Kopfhörer neutralisieren unangenehme Bohrgeräusche durch Gegenschall und könnten Zahnarztbesuche entspannter machen. Offene Fragen sind Kommunikation mit dem Zahnarzt und hohe Zusatzkosten.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "23",
      "title": "Thema 23 – Hausaufgaben – unnötig oder unvermeidlich?",
      "text": "Gegner kritisieren mangelnde Chancengleichheit (Elternhilfe) und Überlastung nach Ganztagsunterricht. Befürworter betonen eigenständiges Wiederholen, Vertiefen und Selbstdisziplin.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "24",
      "title": "Thema 24 – Gleicher Lohn für alle (Bedingungsloses Grundeinkommen)",
      "text": "Ein bedingungsloses Grundeinkommen soll Existenzangst nehmen und Bürokratie abbauen. Diskutiert werden Finanzierbarkeit über Steuern, Gerechtigkeit gegenüber Wohlhabenden und mögliche Auswirkungen auf die Arbeitsmotivation.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "25",
      "title": "Thema 25 – Zweisprachigkeit bei Kindern",
      "text": "Kinder lernen mehrere Sprachen meist intuitiv und profitieren kognitiv sowie interkulturell. Während frühere Bedenken widerlegt sind, wird weiter diskutiert, wie stark das Alter den Akzent beeinflusst.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "26",
      "title": "Thema 26 – Sollen Schönheitsoperationen bei Minderjährigen verboten werden?",
      "text": "Befürworter eines Verbots warnen vor unnötigen gesundheitlichen Risiken bei Jugendlichen. Gegner betonen Ausnahmen nach Unfällen, Elternrechte und dass Aufklärung wichtiger ist als Gesetze.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "27",
      "title": "Thema 27 – Wie lange dürfen Jugendliche abends ausgehen?",
      "text": "Das Jugendschutzgesetz regelt nur bestimmte öffentliche Orte; letztlich bestimmen die Eltern die Ausgehzeiten. Entscheidend ist eine Balance aus Schutz vor Risiken und Vertrauen in die Eigenverantwortung.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "28",
      "title": "Thema 28 – Pro und Contra Ganztagsschule",
      "text": "Immer mehr Schüler besuchen Ganztagsschulen. Befürworter schätzen längere Förderung und Vereinbarkeit mit dem Beruf der Eltern; Kritiker bemängeln unterschiedliche Konzepte, Kosten und weniger freie Familienzeit.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "29",
      "title": "Thema 29 – Spielen für die Karriere",
      "text": "Unternehmen wie Lufthansa nutzen Computersimulationen (Serious Games), damit Nachwuchskräfte Zusammenhänge spielerisch und nachhaltig lernen. Größter Nachteil sind hohe Entwicklungskosten.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "30",
      "title": "Thema 30 – Praktische Lerntipps",
      "text": "Mehrkanaliges Lernen (Hören + Sehen + Reden + Tun = 90 % Behaltensleistung), eigene Diagramme, regelmäßiges Wiederholen nach Kalender sowie Zeitmanagement und Pausen steigern den Lernerfolg deutlich.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "31",
      "title": "Thema 31 – Darf man behalten, was man findet?",
      "text": "Rechtlich müssen wertvolle Fundsachen beim Fundbüro abgegeben werden; bei unberechtigtem Behalten drohen Strafen (wie im Fall eines gefundenen Lottoscheins). Dem ehrlichen Finder steht oft ein Finderlohn zu.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "32",
      "title": "Thema 32 – Ist Schulqualität messbar?",
      "text": "PISA, VERA und Ländervergleiche messen Fachleistungen, erfassen aber nicht das soziale Schulklima, Kreativität oder individuelle Förderung schwächerer Schüler.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "33",
      "title": "Thema 33 – Sind Klassenfahrten sinnvoll?",
      "text": "Klassenfahrten stärken Gemeinschaft, Selbstständigkeit und das Verhältnis zwischen Schülern und Lehrern. Wichtig sind ein begrenztes Budget (z. B. max. 500 €), Fördermöglichkeiten und ein klarer Ablauf.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "34",
      "title": "Thema 34 – Fernsehen macht Kinder dumm",
      "text": "Studien zeigen Zusammenhänge zwischen übermäßigem TV-Konsum (>3 Stunden täglich) und schlechteren Schulabschlüssen sowie Bewegungsmangel. Experten empfehlen maximal eine Stunde täglich und keine Hausaufgaben vor dem Bildschirm.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "35",
      "title": "Thema 35 – Orthographie und Handschrift heute",
      "text": "Durch Tastatur, Smartphones und Rechtschreibkorrektur schreiben viele Menschen immer seltener mit der Hand. Während einige einen Kulturverlust beklagen, sehen andere darin eine praktische Anpassung an den digitalen Alltag.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "36",
      "title": "Thema 36 – Pro und Contra Tierversuche",
      "text": "Medizinische Durchbrüche bei Diabetes oder Krebs basierten oft auf Tierversuchen, da komplexe Organismen nicht vollständig simuliert werden können. Gegner fordern ethische Alternativen wie künstliche Organe und Computermodelle.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "37",
      "title": "Thema 37 – Tiere als Geschenkidee – Eine Überlegung wert?",
      "text": "Haustiere können Kindern Verantwortung und älteren Menschen Bewegung schenken, sind aber Lebewesen für viele Jahre. Unüberlegte Geschenke zu Weihnachten führen oft zu Überforderung.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "38",
      "title": "Thema 38 – Einkaufen mit dem elektronischen Personalausweis",
      "text": "Der E-Perso ermöglicht sichere Online-Identifikation, wird aber wegen Datenschutzsorgen, Lesegerät-Kosten und geringer Verbreitung bislang nur von einem Teil der Bürger aktiv genutzt.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "39",
      "title": "Thema 39 – Die Europäische Union – Pro und Contra",
      "text": "Die EU fördert Frieden, Freizügigkeit, zollfreien Handel und wirtschaftliche Zusammenarbeit. Herausforderungen sind unterschiedliche nationale Interessen, gemeinsame Währungspolitik und wirtschaftliche Ungleichgewichte.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "40",
      "title": "Thema 40 – Die Kleinen wollen es wissen (Kinderuniversitäten)",
      "text": "Kinderunis wecken ohne Notendruck Neugier an Wissenschaft. Kritiker wünschen sich jedoch neben der Förderung starker Schüler auch mehr Angebote für lernschwächere Kinder sowie genügend Bewegung.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "41",
      "title": "Thema 41 – Ist bequemes Essen gut für uns?",
      "text": "Convenience Food spart Zeit, enthält aber oft viel Salz, Zucker, Fett sowie Verpackungsmüll und verdrängt gemeinsames Kochen als soziales Erlebnis.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "42",
      "title": "Thema 42 – Spezielle Schulen für hochbegabte Schüler: Separation oder Integration?",
      "text": "Spezialschulen fördern Talente gezielt in Kleingruppen, während gemischte Klassen soziale Integration stärken. Entscheidend ist ein unterstützendes Umfeld für Motivation und Persönlichkeit.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "43",
      "title": "Thema 43 – Wie sinnvoll sind Nahrungsergänzungsmittel?",
      "text": "Bei ausgewogener Ernährung reichen frische Lebensmittel meist aus; gezielte Präparate können bei Zeitmangel oder veganer Ernährung sinnvoll sein, ersetzen aber keinen gesunden Lebensstil.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "44",
      "title": "Thema 44 – Verbot von Gewaltspielen: Pro und Kontra",
      "text": "Während Befürworter eines Verbots auf den Schutz Jugendlicher vor Gewaltverherrlichung verweisen, betonen Kritiker die Rolle von Elternhaus, Schule und sinnvollen Freizeitangeboten.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "45",
      "title": "Thema 45 – Kinder unterschätzen die Gefahren von Handy und Internet",
      "text": "Über 75–90 % der Kinder und Jugendlichen nutzen eigene Handys, unterschätzen aber Risiken wie Cybermobbing oder Datenmissbrauch und wenden sich bei Problemen oft zu spät an Erwachsene.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "46",
      "title": "Thema 46 – Haustausch",
      "text": "Haustausch im Urlaub spart Hotelkosten und ermöglicht authentische Einblicke in eine andere Kultur, birgt aber Risiken bei Vertrauen, Sauberkeit und fehlenden schriftlichen Haftungsverträgen.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "47",
      "title": "Thema 47 – Sparkonto für Kinder",
      "text": "Klassische Sparbücher bringen kaum noch Zinsen; Alternativen sind spezielle Kinder-Tagesgeldkonten, Festgeld oder langfristige ETF-Sparpläne mit breiter Risikostreuung.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "48",
      "title": "Thema 48 – Stadtwohnung oder Haus im Grünen?",
      "text": "Familien wünschen sich oft einen Garten und Ruhe auf dem Land, doch Zersiedelung erhöht Pendelverkehr, Umweltbelastung und die Abhängigkeit von Autos.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "49",
      "title": "Thema 49 – Tattoo – Schmuck für die Ewigkeit",
      "text": "Tattoos sind gesellschaftsfähig geworden, doch Motivwahl, Sichtbarkeit im Beruf und hohe Kosten sowie Schmerzen bei einer späteren Laser-Entfernung sollten gut überlegt sein.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "50",
      "title": "Thema 50 – Alkoholmissbrauch (Flatrate-Partys)",
      "text": "Flatrate-Partys fördern gefährlichen Alkoholkonsum bei Jugendlichen; Politik und Jugendschutz fordern konsequente Kontrollen und Verbote.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "51",
      "title": "Thema 51 – Antibiotika",
      "text": "Durch häufige unnötige Verschreibungen, Tierhaltung und vorzeitigen Therapieabbruch entstehen gefährliche Resistenzen. Aufklärung in der Arztpraxis und gezielter Einsatz sind entscheidend.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "52",
      "title": "Thema 52 – Englisch als weltweite Unternehmenssprache",
      "text": "Englisch erleichtert globale Geschäftskontakte und spart Übersetzungskosten, kann aber Mitarbeiter verunsichern, Ausdrucksmöglichkeiten einschränken und kulturelle Nuancen verdecken.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "53",
      "title": "Thema 53 – Glücklich ohne Geld und Karriere (Generation Praktikum)",
      "text": "Viele Praktikanten schätzen die praktische Berufserfahrung trotz geringer Bezahlung; dennoch wird politisch über faire Verträge und angemessene Vergütung diskutiert.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    },
    {
      "id": "54",
      "title": "Thema 54 – Wo sollen wir einkaufen? (Innenstadt vs. Einkaufszentrum)",
      "text": "Einkaufszentren am Stadtrand bieten Parkplätze und Komfort unter einem Dach, führen jedoch oft zur Verödung der Innenstädte und Fußgängerzonen.",
      "discussion_points": [
        "Fassen Sie den Kerngedanken des Textes kurz in eigenen Worten zusammen (ohne abzulesen).",
        "Nennen Sie mindestens zwei Pro- und zwei Contra-Argumente aus dem Text und Ihrer eigenen Erfahrung.",
        "Beziehen Sie Ihren Gesprächspartner aktiv ein: „Wie siehst du das?“ / „Hast du damit schon Erfahrungen gemacht?“"
      ]
    }
  ],
  "3": [
    {
      "id": "1",
      "title": "Aufgabe 1 – Wie entwickelt sich das Rauchen in Deutschland?",
      "prompt": "Mein Chef hat mir mitgeteilt, dass ich mich nächste Woche um eine Gruppe von Studenten und Studentinnen kümmern muss. Sie möchten unsere Stadt besichtigen. Kannst du mir helfen, damit wir gemeinsam ein gutes Programm erstellen können?",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Stadtbesichtigung für eine Studentengruppe festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Stadtbesichtigung für eine Studentengruppe together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "2",
      "title": "Aufgabe 2 – Hochzeit nur zu zweit!",
      "prompt": "Viele Teilnehmerinnen und Teilnehmer aus Ihrem Kurs möchten eine Reise in eines der deutschsprachigen Länder unternehmen. Sie sollen gemeinsam bei der Planung helfen. Überlegen Sie gemeinsam, was Sie tun können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Kursreise in ein deutschsprachiges Land festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Kursreise in ein deutschsprachiges Land together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "3",
      "title": "Aufgabe 3 – Eine Woche ohne Internet!",
      "prompt": "Ihr seid von einer Schule eingeladen worden, um aus eurer Sicht und euren Erfahrungen über die Notwendigkeit des Fremdsprachenlernens zu berichten. Sammelt Argumente und erstellt zusammen eine Liste mit Stichpunkten für eine 15-minütige Präsentation vor den Schülern.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine 15-minütige Präsentation über Fremdsprachenlernen festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine 15-minütige Präsentation über Fremdsprachenlernen together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "4",
      "title": "Aufgabe 4 – Soll digitales Unterrichtsmaterial in den Schulen eingesetzt werden?",
      "prompt": "Zum Frühlingsbeginn möchten Sie in Ihrem Stadtviertel einen Flohmarkt organisieren. Sie wollen Ihre Nachbarn zum gemeinsamen Organisieren einladen, ein passendes Datum und Örtlichkeiten festlegen und organisatorische Details besprechen.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Nachbarschafts-Flohmarkt zum Frühlingsbeginn festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Nachbarschafts-Flohmarkt zum Frühlingsbeginn together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "5",
      "title": "Aufgabe 5 – Alternative Lebensform im Alter",
      "prompt": "An einem Kulturzentrum in Ihrer Stadt soll eine Buchmesse stattfinden. Sie möchten bei der Planung helfen und überlegen, was Sie dazu beitragen können (z. B. Informationsmaterial oder Poster).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Buchmesse im Kulturzentrum festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Buchmesse im Kulturzentrum together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "6",
      "title": "Aufgabe 6 – Fast Food kann süchtig machen",
      "prompt": "Ihre Kursteilnehmer möchten ein Überraschungsfest für ihre Lehrerin organisieren, und Sie sollen bei der Planung helfen. Überlegen Sie gemeinsam, was Sie tun können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein Überraschungsfest für die Lehrerin festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein Überraschungsfest für die Lehrerin together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "7",
      "title": "Aufgabe 7 – Rette Leben mit einer Blutspende",
      "prompt": "An einer Gesundheitszentrale in Ihrer Stadt soll ein Infotag zum Thema Gesundheit stattfinden. Sie sollen bei der Planung helfen (z. B. Aufklärungskampagnen, Vorträge oder Ernährungspläne).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Infotag zum Thema Gesundheit festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Infotag zum Thema Gesundheit together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "8",
      "title": "Aufgabe 8 – Fernsehen bildet",
      "prompt": "Das dreizehnjährige Kind eines Freundes hat schlechte Noten in der Schule. Überlegen Sie, was Sie tun können, um ihm zu helfen, und entwickeln Sie gemeinsam einen Plan.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Lern- und Förderplan für ein 13-jähriges Kind festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Lern- und Förderplan für ein 13-jähriges Kind together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "9",
      "title": "Aufgabe 9 – Der Ruf nach mehr direkter Demokratie",
      "prompt": "Ein Jahr nach Abschluss des Sprachkurses möchten Sie ein Wochenendtreffen für die ehemaligen Kursteilnehmer organisieren. Planen Sie Aktivitäten am Vormittag sowie Überraschungsmöglichkeiten.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein Wochenendtreffen für ehemalige Kursteilnehmer festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein Wochenendtreffen für ehemalige Kursteilnehmer together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "10",
      "title": "Aufgabe 10 – Ein Solarium im Winter – Gut für die Gesundheit?",
      "prompt": "Für eine Informationsveranstaltung zu Schule, Ausbildung und Beruf an Ihrer Schule sollen Sie Referenten einladen und Rahmenbedingungen (Zeitpunkt, Räume, Dauer, Verpflegung, Technik) planen.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Infoveranstaltung zu Schule, Ausbildung und Beruf festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Infoveranstaltung zu Schule, Ausbildung und Beruf together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "11",
      "title": "Aufgabe 11 – Elektroautos – Verkehrsmittel der nahen Zukunft?",
      "prompt": "Ein Kulturzentrum in Ihrer Stadt benötigt Renovierungen, jedoch fehlen der Stadt die finanziellen Mittel. Überlegen Sie gemeinsam, wie Sie Spenden sammeln oder eine freiwillige Renovierungsaktion organisieren können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Renovierungs- und Spendenaktion für ein Kulturzentrum festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Renovierungs- und Spendenaktion für ein Kulturzentrum together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "12",
      "title": "Aufgabe 12 – Gesund durch Lachen?",
      "prompt": "Sie möchten in Ihrer Straße ein Sommer-Straßenfest mit allen Nachbarn organisieren (Bänke, Tische, selbstgemachtes Essen, Musik, Spiele für Kinder). Sammeln Sie Ideen und teilen Sie die Aufgaben auf.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein Nachbarschafts-Straßenfest im Sommer festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein Nachbarschafts-Straßenfest im Sommer together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "13",
      "title": "Aufgabe 13 – Selbst gekocht schmeckt es am besten",
      "prompt": "In Ihrer Stadt möchten Sie bei der Planung einer Sportveranstaltung für Kinder helfen. Überlegen Sie gemeinsam, was Sie organisieren können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Sportveranstaltung für Kinder festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Sportveranstaltung für Kinder together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "14",
      "title": "Aufgabe 14 – Wahlen schon mit 16?",
      "prompt": "An einem Bildungsinstitut in Ihrer Stadt soll ein Infotag zum Thema „Neue Medien“ (Internet, Smartphones usw.) stattfinden. Planen Sie Informationsmaterial, Poster, Vorträge und Werbung.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Infotag zum Thema Neue Medien festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Infotag zum Thema Neue Medien together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "15",
      "title": "Aufgabe 15 – Teilzeitarbeit auch für Männer?",
      "prompt": "Dein Freund hat ein wichtiges Vorstellungsgespräch. Überlegt zusammen, welche Tipps ihr ihm für einen guten Eindruck geben könnt (Körpersprache, Sprechweise, Fragen, Einstellung).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für die Vorbereitung eines Freundes auf ein Vorstellungsgespräch festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for die Vorbereitung eines Freundes auf ein Vorstellungsgespräch together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "16",
      "title": "Aufgabe 16 – Arbeiten bis 75 – eine utopische Vorstellung?",
      "prompt": "Ihr Freund möchte in eine andere Stadt umziehen und Sie wollen beim Umzug helfen. Überlegen Sie, wie Sie helfen können, und machen Sie Vorschläge.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für die Umzugshilfe für einen Freund festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for die Umzugshilfe für einen Freund together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "17",
      "title": "Aufgabe 17 – Die Schuluniform: Pro und Kontra",
      "prompt": "Ein Freund möchte in eine andere Stadt umziehen. Planen Sie gemeinsam den Transport, Kartons, Helfer und die Einrichtung der neuen Wohnung.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen kompletten Umzugsplan für einen Freund festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen kompletten Umzugsplan für einen Freund together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "18",
      "title": "Aufgabe 18 – Leistungssport und Doping",
      "prompt": "Sie planen ein Software-Seminar und möchten Ideen für Inhalte, Zeitplan, Referenten, Technik und interaktive Übungen sammeln.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein interaktives Software-Seminar festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein interaktives Software-Seminar together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "19",
      "title": "Aufgabe 19 – Haushaltsgeräte erleichtern die Hausarbeit",
      "prompt": "Sie möchten bei der Planung einer Ausstellung über Ihr Land in einem Kulturzentrum helfen (Poster, interaktive Elemente, Exponate, Werbung).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Kulturausstellung über das eigene Heimatland festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Kulturausstellung über das eigene Heimatland together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "20",
      "title": "Aufgabe 20 – Trinkgeld geben",
      "prompt": "Als Journalisten einer großen Zeitung haben Sie die Chance, ein Interview mit einem sehr bekannten Sänger zu führen. Bestimmen Sie die Person und bereiten Sie eine Fragenliste vor.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein Zeitungsinterview mit einem bekannten Sänger festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein Zeitungsinterview mit einem bekannten Sänger together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "21",
      "title": "Aufgabe 21 – Gleiche Chancen für Männer und Frauen – gesetzlich geregelt",
      "prompt": "Die Sprachschule plant jedes Jahr ein großes, ganztägiges multikulturelles Fest. Überlegen Sie Programmpunkte, Aufgabenverteilung und organisatorische Schritte.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein ganztägiges multikulturelles Sprachschulfest festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein ganztägiges multikulturelles Sprachschulfest together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "22",
      "title": "Aufgabe 22 – Musik statt Bohrgeräusche beim Zahnarzt",
      "prompt": "In einer Schule in Ihrer Stadt ist ein Infotag über den Arbeitsalltag in verschiedenen Berufen geplant. Überlegen Sie Vorträge, Videos, Berufe und Anschauungsmaterial.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Berufsorientierungs-Infotag an einer Schule festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Berufsorientierungs-Infotag an einer Schule together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "23",
      "title": "Aufgabe 23 – Hausaufgaben – unnötig oder unvermeidlich?",
      "prompt": "Sie planen eine Kochparty in Ihrem Deutschkurs und möchten zusammen mit Ihrem Partner ein abwechslungsreiches Programm entwickeln.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Kochparty im Deutschkurs festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Kochparty im Deutschkurs together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "24",
      "title": "Aufgabe 24 – Gleicher Lohn für alle (Bedingungsloses Grundeinkommen)",
      "prompt": "Sie organisieren eine Spendenaktion zur Renovierung des Kindergartens (Online-Kampagne, Tag der offenen Tür, Tombola, Verkaufsstände).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Spendenaktion für die Kindergarten-Renovierung festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Spendenaktion für die Kindergarten-Renovierung together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "25",
      "title": "Aufgabe 25 – Zweisprachigkeit bei Kindern",
      "prompt": "An einem Kulturzentrum in Ihrer Stadt soll eine Spiele-Messe stattfinden. Sie sollen bei der Planung helfen (z. B. Informationsmaterial, Poster, Programm).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Spiele-Messe im Kulturzentrum festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Spiele-Messe im Kulturzentrum together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "26",
      "title": "Aufgabe 26 – Sollen Schönheitsoperationen bei Minderjährigen verboten werden?",
      "prompt": "Sie organisieren gemeinsam eine zuverlässige Kinderbetreuung für eine befreundete Familie (Schulabholung, Hausaufgaben, Mahlzeiten, Spielzeit, Kommunikation mit den Eltern).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Kinderbetreuungsplan für eine Familie festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Kinderbetreuungsplan für eine Familie together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "27",
      "title": "Aufgabe 27 – Wie lange dürfen Jugendliche abends ausgehen?",
      "prompt": "An einer Gesundheitszentrale in Ihrer Stadt organisieren Sie eine Blutspendeaktion. Überlegen Sie gemeinsam, wie Sie informieren und den Ablauf planen.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Blutspendeaktion in der Gesundheitszentrale festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Blutspendeaktion in der Gesundheitszentrale together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "28",
      "title": "Aufgabe 28 – Pro und Contra Ganztagsschule",
      "prompt": "Ein Freund kommt aus Amerika nach Deutschland, um Urlaub zu machen. Sie wollen gemeinsam überlegen, wie Sie ihm helfen und ein schönes Programm planen können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein Deutschland-Urlaubsprogramm für einen Freund aus den USA festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein Deutschland-Urlaubsprogramm für einen Freund aus den USA together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "29",
      "title": "Aufgabe 29 – Spielen für die Karriere",
      "prompt": "In einem Rathaus in Ihrer Stadt soll eine Ausstellung mit dem Titel „Weltreise“ stattfinden. Überlegen Sie gemeinsam Informationsmaterial, Poster und Gestaltung.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für die Ausstellung „Weltreise“ im Rathaus festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for die Ausstellung „Weltreise“ im Rathaus together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "30",
      "title": "Aufgabe 30 – Praktische Lerntipps",
      "prompt": "Sie planen eine Überraschungshochzeit für einen gemeinsamen Freund. Überlegen Sie gemeinsam kreative Überraschungsideen und die Organisation.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Überraschungshochzeit für einen Freund festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Überraschungshochzeit für einen Freund together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "31",
      "title": "Aufgabe 31 – Darf man behalten, was man findet?",
      "prompt": "Unser Freund Valentin hat sich das Bein gebrochen und muss noch eine Woche im Krankenhaus bleiben. Entwickeln Sie gemeinsam einen Plan, wie Sie ihn aufmuntern können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein Aufmunterungs-Programm für einen Freund im Krankenhaus festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein Aufmunterungs-Programm für einen Freund im Krankenhaus together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "32",
      "title": "Aufgabe 32 – Ist Schulqualität messbar?",
      "prompt": "Sie planen mit Ihrem Sprachkurs eine Exkursion zu einem Museum im deutschsprachigen Raum (z. B. Pinakothek der Moderne in München) inklusive Führung und Rahmenprogramm.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Kurs-Exkursion in ein Museum festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Kurs-Exkursion in ein Museum together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "33",
      "title": "Aufgabe 33 – Sind Klassenfahrten sinnvoll?",
      "prompt": "Sie planen einen Besuch im Kinderkrankenhaus und möchten gemeinsam ein Programm entwerfen, um den Kindern Freude zu bereiten.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Besuch im Kinderkrankenhaus festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Besuch im Kinderkrankenhaus together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "34",
      "title": "Aufgabe 34 – Fernsehen macht Kinder dumm",
      "prompt": "Sie möchten gemeinsam Geld für Straßenkinder sammeln und kennen eine Hilfsorganisation mit einem 3-Monats-Programm. Diskutieren Sie Ideen und teilen Sie Aufgaben auf.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Spendenaktion für Straßenkinder festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Spendenaktion für Straßenkinder together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "35",
      "title": "Aufgabe 35 – Orthographie und Handschrift heute",
      "prompt": "Die Sprachschule plant einen Schreibwettbewerb für alle Kursteilnehmer (Textsorten, Themen, Preise, Zeitplan). Planen Sie gemeinsam die Organisation.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Schreibwettbewerb an der Sprachschule festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Schreibwettbewerb an der Sprachschule together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "36",
      "title": "Aufgabe 36 – Pro und Contra Tierversuche",
      "prompt": "Sie planen eine dreitägige Reise ans Meer mit einigen Teilnehmern aus Ihrem Sprachkurs. Überlegen Sie, was Sie benötigen, und planen Sie den Aufenthalt.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine dreitägige Kursreise ans Meer festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine dreitägige Kursreise ans Meer together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "37",
      "title": "Aufgabe 37 – Tiere als Geschenkidee – Eine Überlegung wert?",
      "prompt": "Ihre Schule nimmt an einem vierwöchigen Austauschprogramm mit deutschen Schülerinnen und Schülern teil. Organisieren Sie den gesamten Aufenthalt mit Programmvorschlägen.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen vierwöchigen Schüleraustausch festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen vierwöchigen Schüleraustausch together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "38",
      "title": "Aufgabe 38 – Einkaufen mit dem elektronischen Personalausweis",
      "prompt": "Ihre Sprachschule möchte einen Infotag zum Thema „Lernen mit Musik“ durchführen. Überlegen Sie Programm, Unterrichtsbeispiele und Ablauf.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Infotag „Lernen mit Musik“ festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Infotag „Lernen mit Musik“ together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "39",
      "title": "Aufgabe 39 – Die Europäische Union – Pro und Contra",
      "prompt": "Sie sollen für Ihre Klasse einen Wochenend-Kurztrip in eine europäische Stadt organisieren, der unterschiedliche Interessen (Kultur, Natur, Einkaufen, Entspannung) verbindet.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Wochenend-Kurztrip in eine europäische Stadt festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Wochenend-Kurztrip in eine europäische Stadt together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "40",
      "title": "Aufgabe 40 – Die Kleinen wollen es wissen (Kinderuniversitäten)",
      "prompt": "In Ihrer Stadt organisieren Sie ein interkulturelles Sportfest. Überlegen Sie gemeinsam, wie Sie das Fest planen und durchführen können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein interkulturelles Sportfest festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein interkulturelles Sportfest together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "41",
      "title": "Aufgabe 41 – Ist bequemes Essen gut für uns?",
      "prompt": "Sie organisieren ein Theaterstück und spenden den Erlös für wohltätige Zwecke. Planen Sie gemeinsam Aufführung, Werbung und Ablauf.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für ein Wohltätigkeits-Theaterstück festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for ein Wohltätigkeits-Theaterstück together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "42",
      "title": "Aufgabe 42 – Spezielle Schulen für hochbegabte Schüler: Separation oder Integration?",
      "prompt": "Am kommenden Freitag ist der letzte Tag des Deutschkurses und Sie planen, gemeinsam ins Kino zu gehen. Schmieden Sie einen Plan für das Kinoprogramm und den Abend.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen gemeinsamen Kinobesuch zum Kursabschluss festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen gemeinsamen Kinobesuch zum Kursabschluss together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "43",
      "title": "Aufgabe 43 – Wie sinnvoll sind Nahrungsergänzungsmittel?",
      "prompt": "Sie haben ein Stellenangebot im Ausland erhalten und planen, dort eine Weile zu leben. Überlegen Sie gemeinsam, wie Sie sich optimal darauf vorbereiten können.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für die Vorbereitung auf einen Job im Ausland festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for die Vorbereitung auf einen Job im Ausland together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "44",
      "title": "Aufgabe 44 – Verbot von Gewaltspielen: Pro und Kontra",
      "prompt": "Sie planen, mit Ihren Kolleginnen und Kollegen aus dem Sprachkurs ein Museum zu besuchen. Entwickeln Sie gemeinsam Vorschläge für den Besuch.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Museumsbesuch mit dem Sprachkurs festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Museumsbesuch mit dem Sprachkurs together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "45",
      "title": "Aufgabe 45 – Kinder unterschätzen die Gefahren von Handy und Internet",
      "prompt": "Ein Teilnehmer aus Ihrem Sprachkurs hat am Wochenende Geburtstag. Planen Sie gemeinsam Geschenkideen und den Ablauf der Geburtstagsfeier.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Geburtstagsfeier für einen Kursteilnehmer festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Geburtstagsfeier für einen Kursteilnehmer together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "46",
      "title": "Aufgabe 46 – Haustausch",
      "prompt": "Ihre Lehrerin hat Sie zu einer Lehrveranstaltung mit dem Titel „Deutsch als Fremdsprache“ eingeladen, und Sie möchten helfen. Überlegen Sie gemeinsame Unterstützungsmöglichkeiten.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für die Unterstützung einer DaF-Lehrveranstaltung festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for die Unterstützung einer DaF-Lehrveranstaltung together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "47",
      "title": "Aufgabe 47 – Sparkonto für Kinder",
      "prompt": "Sie organisieren eine Veranstaltung, bei der Sie Bücherspenden für die lokale Bibliothek in Ihrer Straße sammeln möchten. Teilen Sie Ideen und Aufgaben auf.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Bücherspenden-Aktion für die lokale Bibliothek festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Bücherspenden-Aktion für die lokale Bibliothek together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "48",
      "title": "Aufgabe 48 – Stadtwohnung oder Haus im Grünen?",
      "prompt": "Ihre Kursleiterin möchte den Kursraum freundlicher gestalten und bittet Sie um Hilfe. Überlegen Sie Vorschläge, Kosten und Helfer.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für die freundliche Gestaltung des Kursraums festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for die freundliche Gestaltung des Kursraums together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "49",
      "title": "Aufgabe 49 – Tattoo – Schmuck für die Ewigkeit",
      "prompt": "Sie möchten mit einigen Teilnehmern aus Ihrem Sprachkurs eine 3-tägige Fahrradtour machen. Einigen Sie sich auf Ziel, Tagesetappen, Übernachtung und Gepäck.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine 3-tägige Fahrradtour festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine 3-tägige Fahrradtour together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "50",
      "title": "Aufgabe 50 – Alkoholmissbrauch (Flatrate-Partys)",
      "prompt": "Um Geld für Straßenkinder zu sammeln, planen Sie eine gemeinsame Aktion und klären alle Details (wer, was, wann).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine Hilfsaktion für Straßenkinder festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine Hilfsaktion für Straßenkinder together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "51",
      "title": "Aufgabe 51 – Antibiotika",
      "prompt": "An einem Bildungsinstitut in Ihrer Stadt soll ein Infotag „Neue Medien: Internet, Smartphones und mehr“ stattfinden. Planen Sie Poster, Vorträge und Werbung.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Infotag zu Neuen Medien am Bildungsinstitut festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Infotag zu Neuen Medien am Bildungsinstitut together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "52",
      "title": "Aufgabe 52 – Englisch als weltweite Unternehmenssprache",
      "prompt": "Sie müssen gemeinsam ein Buch in Ihrer Klasse vorstellen (Buchauswahl, Struktur, Aufgabenverteilung, Vorlesen, Handzettel).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für eine gemeinsame Buchpräsentation in der Klasse festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for eine gemeinsame Buchpräsentation in der Klasse together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "53",
      "title": "Aufgabe 53 – Glücklich ohne Geld und Karriere (Generation Praktikum)",
      "prompt": "Eine Gruppe von Schülern macht eine Studienreise in Ihr Heimatland, um das Bildungssystem kennenzulernen. Einigen Sie sich auf ein Land und planen Sie das Programm.",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für das Studienreise-Programm für Schülergruppen festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for das Studienreise-Programm für Schülergruppen together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    },
    {
      "id": "54",
      "title": "Aufgabe 54 – Wo sollen wir einkaufen? (Innenstadt vs. Einkaufszentrum)",
      "prompt": "Organisieren Sie einen Betriebsausflug mit Ihren Kolleginnen und Kollegen aus der Firma (Ausflugsideen, Ziele, Kosten, Transport, Verpflegung).",
      "suggestions": [
        {
          "de": "Zuerst sollten wir gemeinsam einen klaren Termin und einen passenden Treffpunkt für einen Betriebsausflug für die Firma festlegen.",
          "en": "First, we should set a clear date and suitable meeting point for einen Betriebsausflug für die Firma together."
        },
        {
          "de": "Ich schlage vor, dass wir eine kurze Checkliste erstellen, damit wir keinen wichtigen Schritt vergessen.",
          "en": "I suggest creating a short checklist so we don't forget any important step."
        },
        {
          "de": "Wir könnten eine Umfrage in unserer Chat-Gruppe starten, um die Wünsche und die Verfügbarkeit aller zu sammeln.",
          "en": "We could start a poll in our chat group to gather everyone's wishes and availability."
        },
        {
          "de": "Was das Budget betrifft, sollten wir die Kosten fair aufteilen und günstige oder kostenlose Optionen prüfen.",
          "en": "Regarding the budget, we should split costs fairly and check affordable or free options."
        },
        {
          "de": "Ich kann ein übersichtliches Info-Blatt oder ein digitales Plakat mit allen wichtigen Details gestalten.",
          "en": "I can design a clear info sheet or digital poster with all key details."
        },
        {
          "de": "Für die Anreise bietet sich der öffentliche Nahverkehr an, zum Beispiel mit einem Gruppenticket oder dem Deutschlandticket.",
          "en": "For getting there, public transport works well, for example with a group ticket or the Deutschlandticket."
        },
        {
          "de": "Außerdem sollten wir an Verpflegung denken – am besten leichte Snacks, Wasser und auch vegetarische Alternativen.",
          "en": "We should also think about food and drinks—ideally light snacks, water, and vegetarian options too."
        },
        {
          "de": "Falls das Wetter nicht mitspielt oder etwas ausfällt, brauchen wir unbedingt einen Plan B (z. B. einen Innenraum).",
          "en": "In case the weather doesn't cooperate or something is canceled, we definitely need a Plan B (e.g., an indoor space)."
        },
        {
          "de": "Lass uns die Aufgaben klar verteilen: Ich kümmere mich um die Organisation und Einladungen, und du übernimmst die Buchung bzw. Abstimmung vor Ort.",
          "en": "Let's divide the tasks clearly: I'll take care of organization and invitations, and you handle booking or on-site coordination."
        },
        {
          "de": "Zum Abschluss können wir uns zwei Tage vorher noch einmal kurz abstimmen, ob alle Materialien und Zusagen vollständig sind.",
          "en": "Finally, we can check in briefly two days beforehand to make sure all materials and confirmations are complete."
        }
      ]
    }
  ]
};
