const readingPart3Data = [
  {
    "id": "1",
    "title": "Fernsehprogramm und Film",
    "sourcePage": 202,
    "keywords": "Was ist das passende Fernsehprogramm? Ein Bekannter möchte einen Film sehen, der nach dem Werk eines Schriftstellers gedreht wurde. Bekannte interessieren sich für Wintersportveranstaltungen. Sie suchen eine Musiksendung. Sie mögen besonders Klaviermusik. Sie mögen Filme mit viel Action und viel Spaß. Ihre Lieblingshelden können auch mal zuschlagen. Ein Bekannter interessiert sich für korsische Geschichte. Sie mögen Familienkomödien, besonders mit frechen Kindern. Eine Bekannte interessiert sich für die Geschichte des bis 1989 geteilten Berlins. Sie sehen gern spannende, aber auch spaßige Agentenfilme. Sie würden gern etwas über Großstadtjugendliche erfahren, die am Rand der Gesellschaft leben. Sie möchten im nächsten Urlaub bergsteigen und sich über die Risiken informieren.",
    "questions": [
      {
        "num": 11,
        "answer": "l",
        "stem": "Ein Bekannter möchte einen Film sehen, der nach dem Werk eines Schriftstellers gedreht wurde."
      },
      {
        "num": 12,
        "answer": "i",
        "stem": "Bekannte interessieren sich für Wintersportveranstaltungen."
      },
      {
        "num": 13,
        "answer": "b",
        "stem": "Sie suchen eine Musiksendung. Sie mögen besonders Klaviermusik."
      },
      {
        "num": 14,
        "answer": "h",
        "stem": "Sie mögen Filme mit viel Action und viel Spaß. Ihre Lieblingshelden können auch mal zuschlagen."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ein Bekannter interessiert sich für korsische Geschichte."
      },
      {
        "num": 16,
        "answer": "e",
        "stem": "Sie mögen Familienkomödien, besonders mit frechen Kindern."
      },
      {
        "num": 17,
        "answer": "a",
        "stem": "Eine Bekannte interessiert sich für die Geschichte des bis 1989 geteilten Berlins."
      },
      {
        "num": 18,
        "answer": "d",
        "stem": "Sie sehen gern spannende, aber auch spaßige Agentenfilme."
      },
      {
        "num": 19,
        "answer": "f",
        "stem": "Sie würden gern etwas über Großstadtjugendliche erfahren, die am Rand der Gesellschaft leben."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Sie möchten im nächsten Urlaub bergsteigen und sich über die Risiken informieren."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "23.15 3SAT Es geschah im August Ullrich Kasten und Hans-Hermann Hertle schildern in ihrer hervorragenden Dokumentation anhand von Archivmaterial minutiös sämtliche Stationen des Mauerbaus. Sie erzählen die Vorgeschichte der Berlin-Krise und beleuchten die Hintergründe der Teilung Deutschlands Ferner haben sie Zeitzeugen nach ihren Reaktionen auf das einschneidende Ereignis befragt. Zu Wort kommen in dem Film nicht nur namhafte Vertreter der internationalen Politik, sondern auch Grenzsoldaten, Flüchtlinge und Angehörige von Maueropfern."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "21.00 NDR Joja Wendt Ob Klassik, Rock'n'Roll oder Jazz, Joja Wendt, Hamburger Pianist mit enormen Entertainer-Qualitäten, variiert bekannte Songs und stellt seine Fingerfertigkeit auch ineigenen Kompositionen unter Beweis. Stargast in dem heutigen Fernseh-Special ist die Schlagersängerin Michelle mit dem Titel \"Ich schicke dir jetzt einen Engel\""
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Me — —— — —Z—ZZZ. nn — — — — nn 20.15 SATI Einfach unwiderstehlich Gut kochen kann Amanda nicht. Folglich steht ihr kleines, von der Mutter geerbtes Restaurant in Manhattan kurz vor dem Aus. Da entflieht plötzlich ein Krebs aus ihrem Einkaufskorb und sorgt mit seinen Zauberkünsten für lukullische Sensationen. Tom, Manager eines Gourmet-Restaurants an der Fifth Avenue, kommt als einer der ersten in deren Genuss. Amanda hat sich in ihn verliebt, als der schon bekannte Krebs unter Toms Hosenbein flüchtet. Seine Zauber-kräfte werden dringend gebraucht, denn Tom gehört zu den Männern, die ziemlich viel Angst vor Liebesbeziehungen haben.",
          "m — zz"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "22.00 HR New York Express",
          "Aus Sorge um die nationale Sicherheit versteckt der amerikanische Geheimdienst den genialen, aber vermeintlich psychisch kranken Physiker Arthur Vincenti. Der völlig verrückte New Yorker Psychiater Dr. Snow erhält den Auftrag, ihn zu heilen. Immer nachts wird er mit verbundenen Augen zu dem Versteck gebracht. Aber auch einige Gangster sind nicht untätig. Sie haben es auf das Wissen des Geheimnisträgers Vincenti abgesehen, das sie fremden Spionen verkaufen möchten"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "20.15 PRO? Kein Vater von gestern g Er schreit wie am Spieß, wenn er lange Hosen tragen soll, und lacht sich kaputt, wenn er die",
          "Katze in eine Mülltüte gesteckt hat. Alles ist einfacher, als sich um den 5-jährigen Calvin zu kümmern. Doch sein liebevoller Vater Russell, der den Jungen allein erzieht, meistert sämtliche Katastrophen mit Bravour und Geduld. Weil sich Kind und Karriere nicht unter einen Hut bringen ließen, verlor der Jurist einen tollen Job in einer renommierten Chicagoer Anwaltskanzlei. Jetzt sitzt er mit seinem Sohn in einem Dorf in Kansas und arbeitet in der Kanzlei eines Freundes. Die Bekanntschaft mit der attraktiven Beth bringt neuen Schwung in sein Leben. Doch da taucht Russells Ex-Ehefrau wieder auf."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "22.45 SAT.1 Nur nich’ nach Hause ! “Hier in Berlin bei meinen Freunden habe ich mein Zuhause hinter mir gelassen. Hier geht's mir h gut. Ich bin endlich frei\", sagt Sascha. Der 16-Jährige ist einer der Jugendlichen, die hierzulande 1 auf der Straße leben. Sie schlafen in Notunterkünften, Treppenhäusern und U-Bahn-Stationen, betteln tagsüber Passanten um Kleingeld an. Peter Schmidt hat Sascha mehrere Wochen lang begleitet und ihn nach seinen Wünschen und Hoffnungen gefragt. Zudem beleuchtet der Filmautor die individuelle Geschichte des Jugendlichen."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "2115 ARD Großer Kick auf schmalem Grat",
          "Mit Sandalen und T-Shirt hängen sie in den Felswänden, ihr Handy halten sie für eine Lebensversicherung, die Alpen für einen Freizeitpark, Vierzig Menschen verunglücken jedes Jahr tödlich am Montblanc, bis zu eintausend Einsätze fliegt die Bergwacht Chamonix pro Saison. Filmer Oliver Baumgart begleitet die Retter zwei Wochen lang,"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "20.15 RTL. Zwei Engel mit vier Fäusten: Schwere Jungs",
          "\"Schwere Jungs\" bildet den Auftakt zu einer sechsteiligen Reihe mit Actionkomödien: Hau-drauf-Filme, wie sie schon unzählige Male mit dem Schläger-Duo Terence Hill und Bud Spencer über den Bildschirm flimmerten. Die Beiden Gauner Joe und Bob fliehen aus dem Gefängnis und finden als Mönche getarnt Unterschlupf in einer Missionsstation."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "12.30 ZDF Olympia-Highlights Nach den Weltcup-Siegen in Willingen und Sapporo stehen die Chancen für das österreichische Team gut, beim Skispringen ganz weit vorn zu landen. Überflieger Gregor Schlierenzauer und sein Mannschaftskollege Thomas Morgenstern sind jedenfalls in blendender Verfassung. Die deutschen Springer Martin Schmitt und Jörg Ritzerfeld werden sich anstrengen müssen. Übertragung von der 120-Meter-Skisprungschanze im Utah Olympic Park."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "1415 DRS Basler Fasnacht Man darf gespannt sein, wie viel Spott die für ihre spitzen Zungen bekannten Basler Fasnächtler für das vergangene Jahr übrig haben. DRS überträgt die Straßenfasnacht, den Umzug der",
          "Pfeifen- und Trommlergruppen, die ihre Themen präsentieren, live. Die fachkundigen Kommentare zum Karneval am Oberrhein liefern Robert Pichler und der Basler Fastnachtsjournalist Roger Thiriet."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "0.05 BR Rockpalast",
          "Dreizehn Alben hat die vielköpfige korsische Gruppe \"I Muvrini\" um die Brüder Jean-Francois und Alain Bernardini bereits veröffentlicht. Hierzulande galten die \"wilden Schafe\" noch bis vor Kurzem als Geheimtipp. Inzwischen sind die Musiker mit ihrer Mischung aus korsischer Folklore, afrikanischen und keltischen Elementen, aber auch aus Jazz, Pop und Cajun bei uns bekannt."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "20.15 PHOENIX Mephisto Man sollte meinen, Schauspieler Hendrik Höfgen wäre gegen unmoralische Angebote gefeit. Schließlich feierte er zur Zeit der Weimarer Republik große Erfolge in der Rolle des Mephisto. Der Mann müsste also wissen, wie schnell es gehen kann, dass man seine Seele verkauft. Als die",
          "Nazis die Macht ergreifen, stellt Höfgen seine Kunst ganz in den Dienst der neuen Herrscher.",
          "Und bald wird er zum Intendanten des Staatstheaters ernannt. Das Drama um Kunst und",
          "Politik entstand nach dem gleichnamigen Roman von Klaus Mann."
        ]
      }
    ]
  },
  {
    "id": "1a",
    "title": "Fernsehprogramm und Film",
    "sourcePage": 205,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Ein Bekannter möchte einen Film sehen, der nach dem Werk eines Schriftstellers gedreht wurde. Ihre Bekannten verfolgen gern sportliche Wettkämpfe. Sie suchen eine abwechslungsreiche Musiksendung mit Klaviermusik. Sie mögen Filme mit viel Action und viel Spaß. Ihre Lieblingshelden können auch mal zuschlagen. Ein Bekannter interessiert sich für korsische Geschichte. Sie mögen Familienkomödien, besonders mit frechen Kindern. Eine Bekannte interessiert sich für informative Beiträge zur neueren Geschichte. Sie sehen gern spannende, aber auch spaßige Agentenfilme. Sie würden gern etwas über Großstadtjugendliche erfahren, die am Rand der Gesellschaft leben. Sie möchten im nächsten Urlaub bergsteigen und sich über die Risiken informieren. Ullrich Kasten und Hans-Hermann Hertle schildern in ihrer hervorragenden Dokumentation anhand von Archivmaterial minutiös sämtliche Stationen des Mauerbaus. Sie erzählen die Vorgeschichte der Berlin-Krise und beleuchten die Hintergründe der Teilung Deutschlands. Ferner haben sie Zeitzeugen nach ihren Reaktionen auf das einschneidende Ereignis befragt. Zu Wort kommen in dem Film nicht nur namhafte Vertreter der internationalen Politik, sondern auch Grenzsoldaten, Flüchtlinge und Angehörige von Maueropfern. Ob Klassik, Rock'n'Roll oder Jazz, Joja Wendt, Hamburger Pianist mit enormen Entertainer-Qualitäten, variiert bekannte Songs und stellt seine Fingerfertigkeit auch in eigenen Kompositionen unter Beweis. Stargast in dem heutigen Fernseh-Special ist die Schlagersängerin Michelle mit dem Titel \"Ich schicke dir jetzt einen Engel\". 20.15 RTL 17.30 ZDF 14.15 DRS Zwei Engel mit vier Fäusten: Schwere Jungs \"Schwere Jungs\" bildet den Auftakt zu einer sechsteiligen Reihe mit Actionkomödien: Hau-drauf-Filme, wie sie schon unzählige Male mit dem Schläger-Duo Terence Hill und Bud Spencer über den Bildschirm flimmerten. Die Beiden Gauner Joe und Bob fliehen aus dem Gefängnis und finden als Mönche getarnt Unterschlupf in einer Missionsstation. Nach den Weltcup-Siegen in Willingen und Sapporo stehen die Chancen für das österreichische Team gut, beim Skispringen ganz weit vorn zu landen. Überflieger Gregor Schlierenzauer und sein Mannschaftskollege Thomas Morgenstern sind jedenfalls in blendender Verfassung. Die deutschen Springer Martin Schmitt und Jörg Ritzerfeld werden sich anstrengen müssen. Übertragung von der 120-Meter-Skisprungschanze im Utah Olympic Park. Man darf gespannt sein, wie viel Spott die für ihre spitzen Zungen bekannten Basler Fasnächtler für das vergangene Jahr übrig haben. DRS überträgt die Straßenfasnacht, den Umzug der Pfeifen- und Trommlergruppen, die ihre Themen präsentieren, live. Die fachkundigen Kommentare zum Karneval am Oberrhein liefern Robert Pichler und der Basler Fastnachtsjournalist Roger Thiriet. Dreizehn Alben hat die vielköpfige korsische Gruppe \"I Muvrini\" um die Brüder Jean-Francois und Alain Bernardini bereits veröffentlicht. Hierzulande galten die \"wilden Schafe\" noch bis vor Kurzem als Geheimtipp. Inzwischen sind die Musiker mit ihrer Mischung aus korsischer Folklore, afrikanischen und keltischen Elementen, aber auch aus Jazz, Pop und Cajun bei uns Man sollte meinen, Schauspieler Hendrik Höfgen wäre gegen unmoralische Angebote gefeit. Schließlich feierte er zur Zeit der Weimarer Republik große Erfolge in der Rolle des Mephisto. Der Mann müsste also wissen, wie schnell es gehen kann, dass man seine Seele verkauft. Als die Nazis die Macht ergreifen, stellt Höfgen seine Kunst ganz in den Dienst der neuen Herrscher. Und bald wird er zum Intendanten des Staatstheaters ernannt. Das Drama um Kunst und Politik entstand nach dem gleichnamigen Roman von Klaus Mann.",
    "questions": [
      {
        "num": 11,
        "answer": "l",
        "stem": "Ein Bekannter möchte einen Film sehen, der nach dem Werk eines Schriftstellers gedreht wurde."
      },
      {
        "num": 12,
        "answer": "i",
        "stem": "Ihre Bekannten verfolgen gern sportliche Wettkämpfe."
      },
      {
        "num": 13,
        "answer": "b",
        "stem": "Sie suchen eine abwechslungsreiche Musiksendung mit Klaviermusik."
      },
      {
        "num": 14,
        "answer": "h",
        "stem": "Sie mögen Filme mit viel Action und viel Spaß. Ihre Lieblingshelden können auch mal zuschlagen."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ein Bekannter interessiert sich für korsische Geschichte."
      },
      {
        "num": 16,
        "answer": "e",
        "stem": "Sie mögen Familienkomödien, besonders mit frechen Kindern."
      },
      {
        "num": 17,
        "answer": "a",
        "stem": "Eine Bekannte interessiert sich für informative Beiträge zur neueren Geschichte."
      },
      {
        "num": 18,
        "answer": "d",
        "stem": "Sie sehen gern spannende, aber auch spaßige Agentenfilme."
      },
      {
        "num": 19,
        "answer": "f",
        "stem": "Sie würden gern etwas über Großstadtjugendliche erfahren, die am Rand der Gesellschaft leben."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Sie möchten im nächsten Urlaub bergsteigen und sich über die Risiken informieren."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "23.15 3SAT Es geschah im August Ullrich Kasten und Hans-Hermann Hertle schildern in ihrer hervorragenden Dokumentation anhand von Archivmaterial minutiös sämtliche Stationen des Mauerbaus. Sie erzählen die Vorgeschichte der Berlin-Krise und beleuchten die Hintergründe der Teilung Deutschlands. Ferner haben sie Zeitzeugen nach ihren Reaktionen auf das einschneidende Ereignis befragt. Zu Wort kommen in dem Film nicht nur namhafte Vertreter der internationalen Politik, sondern auch Grenzsoldaten, Flüchtlinge und Angehörige von Maueropfern."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "21.00/NDR] Joja Wendt Ob Klassik, Rock'n'Roll oder Jazz, Joja Wendt, Hamburger Pianist mit enormen Entertainer-Qualitäten, variiert bekannte Songs und stellt seine Fingerfertigkeit auch in eigenen",
          "Kompositionen unter Beweis. Stargast in dem heutigen Fernseh-Special ist die Schlagersängerin Michelle mit dem Titel \"Ich schicke dir jetzt einen Engel\"."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "De EEE nn 20.15 SATI Einfach unwiderstehlich Gut kochen kann Amanda nicht. Folglich steht ihr kleines, von der Mutter geerbtes Restaurant in Manhattan kurz vor dem Aus. Da entflieht plötzlich ein Krebs aus ihrem Einkaufskorb und sorgt mit seinen Zauberkünsten für lukullische Sensationen. Tom, Manager eines Gourmet-Restaurants an der Fifth Avenue, kommt als einer der ersten in deren Genuss. Amanda hat sich in ihn verliebt, als der schon bekannte Krebs unter Toms Hosenbein flüchtet. Seine Zauber-kräfte werden dringend gebraucht, denn Tom gehört zu den Männern, die ziemlich viel Angst vor Liebesbeziehungen haben. mm bs ——obcbh41/ÖÄ}$[7€_m ,_ ZU] m iü—"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "22.00 HR New York Express",
          "Aus Sorge um die nationale Sicherheit versteckt der amerikanische Geheimdienst den genialen, aber vermeintlich psychisch kranken Physiker Arthur Vincenti. Der völlig verrückte New Yorker Psychiater Dr. Snow erhält den Auftrag, ihn zu heilen. Immer nachts wird er mit verbundenen Augen zu dem Versteck gebracht. Aber auch einige Gangster sind nicht untätig. Sie haben es auf das Wissen des Geheimnisträgers Vincenti abgesehen, das sie fremden Spionen verkaufen möchten."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "20.15 PRO7 Kein Vater von gestern Er schreit wie am Spieß, wenn er lange Hosen tragen soll, und lacht sich kaputt, wenn er die Katze in eine Mülltüte gesteckt hat. Alles ist einfacher, als sich um den 5-jährigen Calvin zu kümmern. Doch sein liebevoller Vater Russell, der den Jungen allein erzieht, meistert sämtliche Katastrophen mit Bravour und Geduld. Weil sich Kind und Karriere nicht unter einen Hut bringen ließen, verlor der Jurist einen tollen Job in einer renommierten Chicagoer Anwaltskanzlei. Jetzt sitzt er mit seinem Sohn in einem Dorf in Kansas und arbeitet in der Kanzlei eines Freundes. Die Bekanntschaft mit der attraktiven Beth bringt neuen Schwung in sein Leben. Doch da taucht Hi Russells Ex-Ehefrau wieder auf."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "22.45 SAT.1 Nur nich’ nach Hause \"Hier in Berlin bei meinen Freunden habe ich mein Zuhause hinter mir gelassen. Hier geht's mir gut. Ich bin endlich frei”, sagt Sascha. Der 16-Jährige ist einer der Jugendlichen, die hierzulande auf der Straße leben. Sie schlafen in Notunterkünften, Treppenhäusern und U-Bahn-Stationen, s betteln tagsüber Passanten um Kleingeld an. Peter Schmidt hat Sascha mehrere Wochen lang L begleitet und ihn nach seinen Wünschen und Hoffnungen gefragt. Zudem beleuchtet der h Filmautor die individuelle Geschichte des Jugendlichen."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "2115 ARD Großer Kick auf schmalem Grat",
          "Mit Sandalen und T-Shirt hängen sie in den Felswänden, ihr Handy halten sie für eine Lebensversicherung, die Alpen für einen Freizeitpark, Vierzig Menschen verunglücken jedes Jahr tödlich am Montblanc, bis zu eintausend Einsätze fliegt die Bergwacht Chamonix pro Saison. Filmer Dliver Baumgart begleitet die Retter zwei Wochen lang."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "2015 RTL: Zwei Engel mit vier Fäusten: Schwere Jungs",
          "\"Schwere Jungs\" bildet den Auftakt zu einer sechsteiligen Reihe mit Actionkomödien: Hau-drauf-Filme, wie sie schon unzählige Male mit dem Schläger-Duo Terence Hill und Bud Spencer über den Bildschirm flimmerten. Die Beiden Gauner Joe und Bob fliehen aus dem Gefängnis und finden als Mönche getarnt Unterschlupf in einer Missionsstation."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "17.30 ZDF Olympia-Highlights Nach den Weltcup-Siegen in Willingen und Sapporo stehen die Chancen für das österreichische Team gut, beim Skispringen ganz weit vorn zu landen. Überflieger Gregor Schlierenzauer und sein Mannschaftskollege Thomas Morgenstern sind jedenfalls in blendender Verfassung. Die deutschen Springer Martin Schmitt und Jörg Ritzerfeld werden sich anstrengen müssen. Übertragung von der 120-Meter-Skisprungschanze im Utah Olympic Park."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "1415 DRS Basler Fasnacht",
          "Man darf gespannt sein, wie viel Spott die für ihre spitzen Zungen bekannten Basler Fasnächtler",
          "für das vergangene Jahr übrig haben. DRS überträgt die Straßenfasnacht, den Umzug der",
          "Pfeifen- und Trommlergruppen, die ihre Themen präsentieren, live. Die fachkundigen Kommentare zum Karneval am Oberrhein liefern Robert Pichler und der Basler Fastnachtsjournalist Roger Thiriet."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "0.05 BR Rockpalast",
          "Dreizehn Alben hat die vielköpfige korsische Gruppe Muvrini\" um die Brüder Jean-Francois und Alain Bernardini bereits veröffentlicht. Hierzulande galten die \"wilden Schafe\" noch bis vor Kurzem als Geheimtipp. Inzwischen sind die Musiker mit ihrer Mischung aus korsischer Folklore, afrikanischen und keltischen Elementen, aber auch aus Jazz, Pop und Cajun bei uns bekannt."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "20.15 PHOENIX Mephisto 1 Man sollte meinen, Schauspieler Hendrik Höfgen wäre gegen unmoralische Angebote gefeit. Schließlich feierte er zur Zeit der Weimarer Republik große Erfolge in der Rolle des Mephisto. Der Mann müsste also wissen, wie schnell es gehen kann, dass man seine Seele verkauft. Als die",
          "Nazis die Macht ergreifen, stellt Höfgen seine Kunst ganz in den Dienst der neuen Herrscher.",
          "Und bald wird er zum Intendanten des Staatstheaters ernannt. Das Drama um Kunst und 4 Politik entstand nach dem gleichnamigen Roman von Klaus Mann."
        ]
      }
    ]
  },
  {
    "id": "2",
    "title": "Wein, Reisen und Klimawandel",
    "sourcePage": 208,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "l",
        "stem": "Ein Nachbar sucht ein illustriertes Buch, um Insektenarten erkennen zu können."
      },
      {
        "num": 12,
        "answer": "j",
        "stem": "Ein Sturm hat Ihr Auto beschädigt. Sie möchten wissen, was Sie nun machen sollen"
      },
      {
        "num": 13,
        "answer": "a",
        "stem": "Eine Bekannte fährt in Urlaub und möchte wissen, wie das Wetter in Italien ist."
      },
      {
        "num": 14,
        "answer": "h",
        "stem": "Freunde von Ihnen möchten auf einer Reise im Ausland an Weinproben teilnehmen."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ihr Sohn möchte eine Weinbauschule besuchen."
      },
      {
        "num": 16,
        "answer": "c",
        "stem": "Ihre Freundin interessiert sich für Bio-Weine und möchte Reisen und Arbeiten verbin"
      },
      {
        "num": 17,
        "answer": "d",
        "stem": "Sie möchten gerne mehr über die Lebensbedingungen bei extremer Kälte erfahren."
      },
      {
        "num": 18,
        "answer": "i",
        "stem": "Sie planen für den Kindergeburtstag Ihrer Tochter einen lehrreichen Nachmittag. —_ 19) Sie sollen im Internet günstigen Wein für ein Familienfest bestellen."
      },
      {
        "num": 19,
        "answer": "e",
        "stem": "Sie sollen im Internet günstigen Wein für ein Familienfest bestellen."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Sie suchen Informationen über den Klimawandel."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Auf unserer Homepage finden Sie nicht nur aktuelle Wetterberichte für Ihren Wohnort, sondern auch ! verlässliche Vorhersagen für Ihre Region, für Europa und die ganze Welt. Wir geben laufend zeitnahe Unwetterwarnungen und stündlich aktualisierte Daten zu Schneehöhen und Wasserpegel. Allergiker und wetterfühlige Menschen bekommen bei uns gesundheitsbezogene Informationen zu Biowetter, Pollenflug oder Ozonwerten Über unsere Seite haben Sie Zugang zu einem dichten Netz von Webcams in ganz Deutschland und den Grenzregionen. Durch eine Mitgliedschaft bei WetterAktuell.com profitieren Sie von unseren zahlreichen Apps: >>mehr"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die beiden letzten Tage waren für die Winzer eine Katastrophe. Nachdem der Frühling überdurchschnittlich warm gewesen war, entfalteten sich die Reben viel früher als sonst. Deshalb traf der jüngste Kälteeinbruch die Blüten und Knospen besonders stark. Im Norden und Osten Frankreichs, in Deutschland und in der Schweiz wurden Temperaturen bis zu minus 8 Grad gemessen. Selbst in Italien, vor allem in der Toskana, wurden Minusgrade verzeichnet. Der Frost hat in der Chianti-Region große Schäden angerichtet .Details zur Entschädigung für Frostschäden im Weinbau finden Sie hier"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "[ SS Wir bauen seit vier Generationen Wein an und haben vor einigen Jahren auf ökologischen Weinbau umgestellt. Unser Weingut liegt in den sanften Hügeln Apuliens. Für die Weinernte im Oktober suchen wir Helfer im Austausch gegen Verpflegung und Unterkunft An fünf Tagen pro Woche hilfst du bei allen Tätigkeiten rund um den Wein. An deinen freien Tagen kannst du die wunderschöne Gegend erkunden. Du wohnst in einem eigenen Zimmer und hast auf Wunsch Familienanschluss. Neben Italienisch sprechen wir auch Deutsch und Englisch. Kontaktformular"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "23. November: Vortrag Zeinab Schmidt-Hussain,",
          "Dominikanerhaus, Stadtplatz 18.",
          "Die Klimaforscherin und Meteorologin Zeinab Schmidt-Hussain ist seit Anfang des Jahres die neue Leiterin des Silberberg-Observatoriums. Die junge Wissenschaftlerin hat bereits viel beachtete Forschungsergebnisse für unterschiedliche Bereiche der Klima- und Wetterkunde vorgelegt. In ihrem Vortrag spricht sie über ihre Zeit an einer Forschungsstation am Südpol, in der sie zwei Jahre verbracht hat. Sie zeigt außergewöhnliche Aufnahmen und berichtet dabei vom Alltag und den Arbeitsbedingungen bei Temperaturen, die auch im Sommer nicht über minus 40 Grad Celsius steigen. Beginn ist um 20:00 Uhr."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Sie sind auf der Suche nach dem besten Preis-Leistungs-Verhältnis? Dann sind Sie in unserem Online-Shop genau richtig! Bei uns finden Sie Sonderpreise, ohne auf Qualität verzichten zu müssen. Von Moselweinen bis zu französischem Rotwein wir halten das ganze Jahr über eine große Auswahl an attraktiven Sonderangeboten bereit. Wie das möglich ist? Wir kaufen große Mengen günstig ein und geben den niedrigen Preis an Sie weiter. Bei manchen Sorten sparen Sie bis zu 40 Prozent im Vergleich zum Preis im Geschäft. weiterlesen"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Die afrikanische Schlafkrankheit wird durch die Tsetsefliege auf Tiere und Menschen übertragen. Die Krankheit, die mit Nervenschädigungen und hohem Fieber verbunden ist, kann zum Tod führen. Ein Forscherteam zeigte nun, wie sich die Schlafkrankheit durch den f Klimawandel weiter ausdehnen könnte. Diese Wissenschaftler gingen davon aus, dass sich die Erde in den nächsten Jahrzehnten um mehr als fünf Grad erwärmen wird. Damit könnte die ! Tsetsefliege in Gebiete vordringen, die bisher zu kalt waren Hier geht es zu dem Artikel. he"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Mit Temperaturen von bis zu minus 20 Grad und starken Sturmböen herrschen in weiten Teilen Europas extreme Winterbedingungen. Unter dem Einfluss des heftigen Windes wurden in den letzten Tagen Fahrbahnen zugeweht, und stellenweise türmt sich der Schnee meterhoch. Autos blieben liegen, und vielerorts mussten die Rettungskräfte ausrücken, um Menschen aus ihren Fahrzeugen zu befreien. Brücken und Straßen mussten komplett gesperrt, der Fährenverkehr zu den Inseln eingestellt werden. In manchen Gegenden ist die Stromversorgung vollständig zusammengebrochen. Es scheint wie ein Wunder, dass unter diesen Bedingungen noch keine Opfer zu beklagen sind."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Für Liebhaber französischer Weine, die es individuell mögen: Wir planen und organisieren für Sie maßgeschneiderte Urlaubsreisen in die bedeutendsten Weinbaugebiete Frankreichs, zum Beispiel nach Burgund, Bordeaux oder in die Champagne. Zu unseren Partner betrieben gehören nicht nur große Namen, sondern auch kleinere Winzer. Unsere Unterkunftsmöglichkeiten reichen von einfachen Gästehäusern in kleinen Weindörfern bis zum luxuriösen 5-Sterne-Hotel. Besichtigen Sieberühmte Weingüter, erfahren Sie Interessantes rund um den Weinbau verkosten Sie die besten Weine und kaufen Sie Ihren Lieblingswein direkt vom Produzenten. Zu den Reisezielen"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Das Städtische Museum beherbergt auch eine bedeutende Insektensammlung. Der Hobby-Insektenforscher Rüdiger Wildhaber hat sie seiner Heimatstadt vermacht. In den Schaukästen und auf vergrößerten Fotos können die Besucher die unglaubliche Formen- und Farbenvielfalt der Insekten bewundern. Bei den Jüngsten besonders beliebt sind die beiden übergroßen Modelle einer Biene und eines Marienkäfers. In kind gerechten Vorträgen erzählen unsere Mitarbeiterinnen und Mitarbeiter täglich von 15:00 bis 17:00 Uhr Wissenswertes über die spannende Welt der Insekten, die artenreichste Klasse der Tiere. Themen und Termine finden Sie hier"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Der Sturm deckt das Dach Ihres Wohnhauses ab, nach den heftigen Regenfällen steht das Wasser in Ihrem Keller, oder die Schneelawine von Ihrem Dach verletzt Passanten: Unwetterschäden können sehr teuer werden. Wir helfen Ihnen, sich so gut wie möglich dagegen zu schützen. Erfahren Sie hier, welche Versicherungen wir Ihnen anbieten. Das Wetter können Sie nicht ändern, aber Sie können dazu beitragen, Schäden zu vermeiden. Hier lesen Sie, wie Sie Unwetterschäden vorbeugen können. Was tun, wenin doch ein Schaden auftritt? Das Vorgehen im Schadensfall erklären wir hier."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Weinverkostung – am 15. November, von 15.00 bis 19.00 Uhr, laden wir Genießer, Weinkenner und Fachleute zu unserer diesjährigen Weinverkostung Wir freuen uns besonders, unseren Besucherinnen und Besuchern einen Riesling vorzustellen, der bei zwei internationalen Wettbewerben ausgezeichnet wurde. Auf unserem Weingut in dem alten Schloss an der Mosel erwarten Sie neben der Verkostung auch attraktive Sonderangebote, die ausschließlich für Besucherinnen und Besucher am Tag der offenen Tür reserviert sind. Weinverkostungen bieten wir auf Wunsch auch an anderen Tagen an. Für Gruppen ab 20 Personen, 30 bis 45 Minuten."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Insektenwelten – der neue Insektenführer. In keiner anderen Tiergruppe gibt es so viele Arten wie bei den Insekten. in rund 1500 Einträgen gibt dieses neue Bestimmungsbuch eine Fi umfassende Übersicht über die Vielfalt der Insekten, die in Europa anzutreffen sind. Es umfasst Fi Fotos und detaillierte Zeichnungen in Farbe, die die charakteristischen Merkmale der einzelnen Arten hervorheben. Eine Fülle von populärwissenschaftlichen Informationen im handlichen Taschenbuchformat - damit ist dieser Führer ein Muss für jeden Insektenliebhaber. Blick ins",
          "Buch Taschenbuch, 395 Seiten 32, 80 EUR Kaufen"
        ]
      }
    ]
  },
  {
    "id": "3",
    "title": "Ausbildung und Bewerbungsgespräch",
    "sourcePage": 211,
    "keywords": "Wer zu seinem Vorstellungsgespräch eingeladen wird, sollte auf korrekte und saubere Kleidung achten. Für viele Firmen ist es wichtig, dass auch Auszubildende die Firma gegenüber den Kunden Zerrissene Jeans und selbst gefärbte T-Shirts mögen zwar trendy sein, zu einem Vorstellungsgespräch gehören sie aber nicht. In Zweifelsfällen ist es ratsam, sich bei Eltern oder Bekannten Rat zu holen. Für junge Leute kann das Internet zu einer Droge werden. Der typische Internet-Süchtige ist ca. 18 Jahre alt, männlich, Single und hat kaum soziale Kontakte. Er surft täglich um die 5 Stunden im World Wide Web und hat schlechte Laune, wenn er nicht vor dem Monitor sitzen kann. Pflichten werden oft vernachlässigt. Psychologen raten, die Surfzeiten schrittweise zu verringern und darüber ein Tagebuch zu führen sowie vor dem Surfen schriftlich zu notieren, was genau man im Internet suchen möchte. Wer diese strengen Regeln einhält, kann aus der Internetsucht aussteigen. Zu einem zunehmend größer werdenden Problem am Arbeitsplatz wird die immer größer werdende Kluft zwischen dem Sprachgebrauch junger und alter Kollegen. Viele junge Leute verstehen laut einer Studie der Universität Kiel traditionelle Redewendungen wie z. B. “Den Nagel auf den Kopf treffen” oder “Öl ins Feuer gießen” nicht mehr, während Ältere nichts mit “keinen Bock haben” anzufangen wissen. Dadurch, dass Jung und Alt heute nicht mehr so lange wie in früheren Zeiten zusammenleben, sondern unter sich bleiben, verstärkt sich das Auseinanderdriften der Jugendsprache und der Sprache der Alten \"GRUNDSÄTZLICH HAT JEDER DIE MÖGLICHKEIT, BEI UNS EINE AUSBILDUNG ZU MACHEN\" , heißt es bei der Sparkassen-Akademie in Bonn. Die Bewerber sollen aber gute bis sehr gute Noten in Deutsch und Mathematik von der Schule mitbringen, und sie müssen in Rollenspielen ihre kommunikativen Fähigkeiten unter Beweis stellen, etwa, wie sie mit einem aggressiven Kunden umgehen würden. Viele junge Leute flüchten sich in die virtuelle Scheinwelt, weil ihnen die Realität als eine zu große Belastung erscheint. Insbesondere Chatrooms verführen die Jugendlichen zu langen Sitzungen, die oft als Ersatz für mangelnde zwischenmenschliche Beziehungen herhalten. Häufige Folge: Vernachlässigung von Hausaufgaben und schlechte Zensuren. Eltern, die sich Sorgen um ihre Internetabhängigen Kinder machen, sollten viel mit ihnen sprechen - ohne Vorwürfe zu machen - und versuchen ihren Zöglingen Alternativen in der realen Welt aufzuzeigen.",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Ihre Schwägerin erwartet ein Kind. Sie ist nicht sicher, ob Sie in einem Vorstellungsgespräch darauf hinweisen muss."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Ihr Neffe sucht einen Ausbildungsplatz als Elektriker. Er weiß nicht genau, wie er seine Bewerbung korrekt schreiben soll."
      },
      {
        "num": 13,
        "answer": "g",
        "stem": "Eine Bekannte möchte eine Ausbildung machen und vielleicht später einmal studieren."
      },
      {
        "num": 14,
        "answer": "i",
        "stem": "Ein Freund surft täglich viele Stunden im Internet. Sie finden das zu viel und wollen ihm einen Rat geben."
      },
      {
        "num": 15,
        "answer": "k",
        "stem": "Ein Freund möchte wissen, welche schulischen Leistungen für die Vergabe von Ausbildungsplätzen im Bankgewerbe besonders wichtig sind."
      },
      {
        "num": 16,
        "answer": "f",
        "stem": "Ein älteres Ehepaar hat Goldene Hochzeit. Die Tochter möchte eine Rede halten und braucht dafür eine Anleitung."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Ein Bekannter ist Bankkaufmann und sucht eine Stelle."
      },
      {
        "num": 18,
        "answer": "h",
        "stem": "Eine Freundin sucht einen Ausbildungsplatz. Sie ist zu einem Vorstellungsgespräch eingeladen und ist sich nicht sicher, was sie dazu anziehen soll."
      },
      {
        "num": 19,
        "answer": "d",
        "stem": "Eine Freundin, 20 Jahre alt, muss oft vor Arbeitskollegen Referate halten. Ihr Hauptproblem ist ihre Nervosität."
      },
      {
        "num": 20,
        "answer": "l",
        "stem": "Eine befreundete Frau möchte ihren Sohn davon abhalten, ständig im Internet zu surfen, weil seine schulischen Leistungen rapide nachlassen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Bewerber sollten Bewerbungsgespräche um eine Stelle nicht dem Zufall überlassen. In der Regel fangen sie mit Smalltalk an: Man redet über das Wetter, den Verkehr und Ähnliches. Doch dabei kommt es schon auf das \"Wie?\" an. Wer viel kritisiert, hat schon verloren. Bei der Vorstellung ihrer Person sollten Bewerber darauf achten, dass sie ihre Fähigkeit und den Nutzen, den ihr potentiell zukünftiger Arbeitgeber von ihnen hat, in den Vordergrund stellen. Fragen nach Gesundheit, Familienplanung, Schwangerschaft oder Geld gehören nicht ins Bewerbungsgespräch. Sollten Sie dennoch gestellt werden, ist man nicht verpflichtet, diese wahrheitsgemäß zu beantworten."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Postbank gibt Bewerbern um einen Ausbildungsplatz ein Thema für ein Projekt. das sie ausarbeiten und dann präsentieren sollen. Nur wer diese Hürde nehmen kann und Engagement beweist, hat Chancen, aufgenommen zu werden. Schließlich sollen die Bewerber zeigen, dass sie belastbar und entscheidungsfähig sind. Der Banker von heute hat ein weit gestecktes Tätigkeitsfeld; Kassierer am Schalter, die nichts als Geld oder Formulare ausgeben oder entgegennehmen. wird es in Zukunft immer weniger geben."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "[ See EEE Rhetoriktrainer raten dazu, dem Anfang und dem Schluss eines Referats besonderes Augenmerk zu schenken. In den ersten zwei Minuten eines Vortrags entscheide sich nämlich, ob ein Zuhörer an dem Referat Interesse hat oder nicht. Daher sei ein effektvoll und interessant gestalteter Einstieg äußerst wichtig. Am Schluss soll man den Zuhörern noch einmal mit auf den Weg geben, was dem Vortragenden besonders wichtig erscheint.",
          "TE TTT T————nmRmg 1"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Robert Sonntag, Autor des Buches “Hilfe, ich muss reden” behauptet, die Angst vor einem größeren Publikum zu reden, sei ein Problem für die meisten Menschen. In Deutschland liegt in etwa 60 % der Menschen an diesem Phänomen. Dabei achten Zuhören nur zu ? % auf das, was jemand sagt, 93 % der Wirkung eines Vortrags erziele man durch Körpersprache und seine Stimme. Der Autor rät zu Entspannungstechniken wie dem Autogenen Training oder Yoga, um gelassener zu werden, und einer gründlichen Vorbereitung des Vortrags",
          "Seminarangebote unter www.rs-rethorik.de."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Bereiten Sie sich auf ein Vorstellungsgespräch intensiv vor. Überlegen Sie sich genau, was Sie Ihrer zukünftigen Firma an Nutzen bringen können, denn Sie werden danach gefragt werden, warum Siesich ® gerade bei dieser und nicht bei einer anderen Firma beworben haben. Analysieren Sielhrepersönlichen Stärken und Schwächen und überlegen Sie, wie Sie Ihre schwachen Seiten möglichst positiv präsentieren können. Überlegen Sie, was Ihre persönlichen Ziele sind. und sammeln Sie so viele $ Informationen wie möglich über Ihre zukünftige Arbeit und die Firma, bei der Sie sich beworben haben."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Nichts ist auf privaten Feierlichkeiten wie Hochzeiten, runden Geburtstagen oder sonstigen Jubiläen ä schlimmer als langatmige, nicht enden wollende Ansprachen von Familienmitgliedern. Deshalb bieten Li viele Volkshochschulen in Deutschland Wochenendseminare an. in denen der Aufbau und der Vortrag h einer guten Festansprache trainiert werden. Das Ziel dieser Seminare ist es, die zukünftigen ’ Teilnehmenden in die Lage zu versetzen, spritzige Reden frei halten zu können. h"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Ein Auszubildender bei einer Bank oder Sparkasse bekommt 690,- Euro im ersten Ausbildungsjahr. Am Ende seiner Ausbildung steigt die Vergütung auf 800,- Euro. Das Einstiegsgehalt für Bankangestellte liegt bei etwas über 2.000.- Euro monatlich. Aufstiegschancen haben die jungen Banker nur, wenn sie sich intensiv um ihre berufliche Fortbildung kümmern",
          "Dafür bieten die Banken ihren Mitarbeitern viele Möglichkeiten an, wie das BankCollege der Volksbanken oder die Sparkassen-Akademie. Manche Banken geben besonders qualifizierten Mitarbeitern sogar Stipendien für ein Studium."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Wer zu seinen Vorstellungsgespräch eingeladen wird, sollte auf korrekte und saubere Kleidung achten. Für viele Firmen ist es wichtig, dass auch Auszubildende die Firma gegenüber den Kunden repräsentieren können.",
          "Zerrissene Jeans und selbst gefärbte T-Shirts mögen zwar trendy sein, zu einem Vorstellungsgespräch gehören sie aber nicht. In Zweifelsfällen ist es ratsam, sich bei Eltern oder Bekannten Rat zu holen."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Für junge Leute kann das Internet zu einer Droge werden. Der typische Internet-Süchtige ist ca. 3ahre alt, männlich, Single und hat kaum sozlale Kontakte. Er surft täglich um die 5 Stunden im World Wide Web und hat schlechte Laune, wenn er nicht vor dem Monitor sitzen kann. Pflichten werden oft vernachlässigt. Psychologen raten, die Surfzeiten schrittweise zu verringern und darüber ein Tagebuch zu ! führen sowie vor dem Surfen schriftlich zu notieren, was genau man im Internet suchen möchte. Wer diese strengen Regeln einhält, kann aus der Internetsucht aussteigen."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Zu einem zunehmend größer werdenden Problem am Arbeitsplatz wird die immer größer werdende Kluft zwischen dem Sprachgebrauch junger und alter Kollegen. Viele junge Leute verstehen laut einer Studie der Universität Kiel traditionelle Redewendungen wie z. B. Den Nagel auf den Kopf treffen'oder Üins Feuer gießen’nicht mehr, während ere nichts mit keinen Bock haben’anzufangen wissen. Dadurch, dass Jung und Alt heute nicht mehr so lange wie in früheren Zeiten zusammenleben, sondern unter sich bleiben, verstärkt sich das Auseinanderdriften der Jugendsprache und der Sprache der Alten immer mehr."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "\"GRUNDSÄTZLICH HAT JEDER DIE MÖGLICHKEIT, BEI UNS EINE AUSBILDUNG ZU MACHEN\",",
          "heißt es bei der Sparkassen-Akademie in Bonn.",
          "Die Bewerber sollen aber gute bis sehr gute Noten in Deutsch und Mathematik von der Schule mitbringen, und sie müssen in Rollenspielen ihre kommunikativen Fähigkeiten unter Beweis stellen, etwa, wie sie mit einem aggressiven Kunden umgehen würden."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Viele junge Leute flüchten sich in die virtuelle Scheinwelt, weil ihnen die Realität als eine zu große Fi Belastung erscheint. Insbesondere Chatrooms verführen die Jugendlichen zu langen Sitzungen, die oft als Ersatz für mangelnde zwischenmenschliche Beziehungen herhalten. Häufige Folge:",
          "Vernachlässigung von Hausaufgaben und schlechte Zensuren. Eltern, die sich Sorgen um ihre Internetabhängigen Kinder machen, sollten viel mit ihnen sprechen - ohne Vorwürfe zu machen - und 4 versuchen ihren Zöglingen Alternativen in der realen Welt aufzuzeigen."
        ]
      }
    ]
  },
  {
    "id": "3a",
    "title": "Ausbildung und Bewerbungsgespräch",
    "sourcePage": 214,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Ihre Schwägerin erwartet ein Kind. Sie ist nicht sicher, ob Sie in einem Vorstellungsgespräch darauf hinweisen muss."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Ihr Neffe sucht einen Ausbildungsplatz als Elektriker. Er weiß nicht genau, wie er seine Bewerbung korrekt schreiben soll."
      },
      {
        "num": 13,
        "answer": "d",
        "stem": "Eine Freundin, 20 Jahre alt, muss oft vor Arbeitskollegen Referate halten. Ihr Hauptproblem ist ihre Nervosität."
      },
      {
        "num": 14,
        "answer": "h",
        "stem": "Eine Freundin sucht einen Ausbildungsplatz. Sie ist zu einem Bewerbungsgespräch eingeladen und weiß nicht, was sie zu diesem Anlass anziehen soll."
      },
      {
        "num": 15,
        "answer": "l",
        "stem": "19 Eine Bekannte sucht Rat bei Ihnen, weil ihr Sohn ständig im Internet surft und dabei die Schule vernachlässigt."
      },
      {
        "num": 16,
        "answer": "g",
        "stem": "Eine Bekannte möchte eine Ausbildung machen und vielleicht später einmal studieren."
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "Ein Freund surft täglich viele Stunden im Internet. Sie finden das zu viel und wollen ihm einen Rat geben."
      },
      {
        "num": 18,
        "answer": "k",
        "stem": "Ein Freund möchte wissen, welche schulischen Leistungen bei der Vergabe von Ausbildungsplätzen im Bankgewerbe besonders wichtig sind."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Ein Bekannter ist Bankkaufmann und sucht eine Stelle."
      },
      {
        "num": 20,
        "answer": "f",
        "stem": "Ein älteres Ehepaar hat Goldene Hochzeit. Die Tochter möchte eine Rede halten und braucht dafür eine Anleitung."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Das Vorstellungsgespräch ist eine wichtige Hürde bei der Suche nach einem Arbeitsplatz. In der Regel fangen sie mit Smalltalk an: Man redet über das Wetter, den Verkehr und Ähnliches. Doch dabei kommt es schon ! auf das \"Wie?\" an. Wer viel kritisiert, hat schon verloren. Bei der Vorstellung ihrer Person sollten Bewerber darauf achten, dass sie ihre Fähigkeit und den Nutzen, den ihr potentiell zukünftiger Arbeitgeber von ihnen hat, in den Vordergrund stellen. Fragen nach Gesundheit, Familienplanung, Schwangerschaft oder Geld gehören nicht ins Bewerbungsgespräch. Sollten Sie dennoch gestellt werden, ist man nicht verpflichtet, diese wahrheitsgemäß zu beantworten."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Postbank gibt Bewerbern um einen Ausbildungsplatz ein Thema für ein Projekt. das sie ausarbeiten und dann präsentieren sollen. Nur wer diese Hürde nehmen kann und Engagement beweist, hat Chancen, aufgenommen zu werden. Schließlich sollen die Bewerber zeigen, dass sie belastbar und entscheidungsfähig sind. Der Banker von heute hat ein weit gestecktes Tätigkeitsfeld; Kassierer am Schalter, die nichts als Geld oder Formulare ausgeben oder entgegennehmen. wird es in Zukunft immer weniger geben."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "[ See EEE Rhetoriktrainer raten dazu, dem Anfang und dem Schluss eines Referats besonderes Augenmerk zu schenken. In den ersten zwei Minuten eines Vortrags entscheide sich nämlich, ob ein Zuhörer an dem Referat Interesse hat oder nicht. Daher sei ein effektvoll und interessant gestalteter Einstieg äußerst wichtig. Am Schluss soll man den Zuhörern noch einmal mit auf den Weg geben, was dem Vortragenden besonders wichtig erscheint.",
          "TE TTT T————nmRmg 1"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Robert Sonntag, Autor des Buches “Hilfe, ich muss reden” behauptet, die Angst vor einem größeren Publikum zu reden, sei ein Problem für die meisten Menschen. In Deutschland liegt in etwa 60 % der Menschen an diesem Phänomen. Dabei achten Zuhören nur zu ? % auf das, was jemand sagt, 93 % der Wirkung eines Vortrags erziele man durch Körpersprache und seine Stimme. Der Autor rät zu Entspannungstechniken wie dem Autogenen Training oder Yoga, um gelassener zu werden, und einer gründlichen Vorbereitung des Vortrags",
          "Seminarangebote unter www.rs-rethorik.de."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Bereiten Sie sich auf ein Vorstellungsgespräch intensiv vor. Überlegen Sie sich genau, was Sie Ihrer zukünftigen Firma an Nutzen bringen können, denn Sie werden danach gefragt werden, warum Siesich ® gerade bei dieser und nicht bei einer anderen Firma beworben haben. Analysieren Sielhrepersönlichen Stärken und Schwächen und überlegen Sie, wie Sie Ihre schwachen Seiten möglichst positiv präsentieren können. Überlegen Sie, was Ihre persönlichen Ziele sind. und sammeln Sie so viele $ Informationen wie möglich über Ihre zukünftige Arbeit und die Firma, bei der Sie sich beworben haben."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Nichts ist auf privaten Feierlichkeiten wie Hochzeiten, runden Geburtstagen oder sonstigen Jubiläen ä schlimmer als langatmige, nicht enden wollende Ansprachen von Familienmitgliedern. Deshalb bieten Li viele Volkshochschulen in Deutschland Wochenendseminare an. in denen der Aufbau und der Vortrag h einer guten Festansprache trainiert werden. Das Ziel dieser Seminare ist es, die zukünftigen ’ Teilnehmenden in die Lage zu versetzen, spritzige Reden frei halten zu können. h"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Ein Auszubildender bei einer Bank oder Sparkasse bekommt 690,- Euro im ersten Ausbildungsjahr. Am Ende seiner Ausbildung steigt die Vergütung auf 800,- Euro. Das Einstiegsgehalt für Bankangestellte liegt bei etwas über 2.000.- Euro monatlich. Aufstiegschancen haben die jungen Banker nur, wenn sie sich intensiv um ihre berufliche Fortbildung kümmern",
          "Dafür bieten die Banken ihren Mitarbeitern viele Möglichkeiten an, wie das BankCollege der Volksbanken oder die Sparkassen-Akademie. Manche Banken geben besonders qualifizierten Mitarbeitern sogar Stipendien für ein Studium."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Wer zu seinem Vorstellungsgespräch eingeladen wird, sollte auf korrekte und saubere Kleidung achten. Für viele Firmen ist es wichtig, dass auch Auszubildende die Firma gegenüber den Kunden repräsentieren können.",
          "Zerrissene Jeans und selbst gefärbte T-Shirts mögen zwar trendy sein, zu einem Vorstellungsgespräch gehören sie aber nicht. In Zweifelsfällen ist es ratsam, sich bei Eltern oder Bekannten Rat zu holen."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Für junge Leute kann das Internet zu einer Droge werden. Der typische Internet-Süchtige ist ca.18 Jahre alt, männlich, Single und hat kaum sozlale Kontakte. Er surft täglich um die 5 Stunden im World Wide Web und hat schlechte Laune, wenn er nicht vor dem Monitor sitzen kann. Pflichten werden oft vernachlässigt. Psychologen raten, die Surfzeiten schrittweise zu verringern und darüber ein Tagebuch zu führen sowie vor dem Surfen schriftlich zu notieren, was genau man im Internet suchen möchte. Wer diese strengen Regeln einhält, kann aus der Internetsucht aussteigen"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Zu einem zunehmend größer werdenden Problem am Arbeitsplatz wird die immer größer werdende Kluft zwischen dem Sprachgebrauch junger und alter Kollegen. Viele junge Leute verstehen laut einer Studie der Universität Kiel traditionelle Redewendungen wie z. B. \"Den Nagel auf den Kopf treffen” oder “Öl ins Feuer gießen” nicht mehr, während Ältere nichts mit \"keinen Bock haben” anzufangen wissen Dadurch, dass Jung und Alt heute nicht mehr so lange wie in früheren Zeiten zusammenleben, sondern unter sich bleiben, verstärkt sich das Auseinanderdriften der Jugendsprache und der Sprache der Alten immer mehr auseinander."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "\"GRUNDSÄTZLICH HAT JEDER DIE MÖGLICHKEIT, BEI UNS EINE AUSBILDUNG ZU MACHEN”,",
          "heißt es bei der Sparkassen-Akademie in Bonn.",
          "Die Bewerber sollen aber gute bis sehr gute Noten in Deutsch und Mathematik von der Schule mitbringen, und sie müssen in Rollenspielen ihre kommunikativen Fähigkeiten unter Beweis stellen, etwa, wie sie mit einem aggressiven Kunden umgehen würden"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Viele junge Leute flüchten sich in die virtuelle Scheinwelt, weil ihnen die Realität als eine zu große & Belastung erscheint. Insbesondere Chatrooms verführen die Jugendlichen zu langen Sitzungen, die oft als Ersatz für mangelnde zwischenmenschliche Beziehungen herhalten. Häufige Folge: Vernachlässigung von Hausaufgaben und schlechte Zensuren. Eltern, die sich Sorgen um ihre Internetabhängigen Kinder machen, sollten viel mit ihnen sprechen - ohne Vorwürfe zu machen - und Fi versuchen ihren Zöglingen Alternativen in der realen Welt aufzuzeigen. 8"
        ]
      }
    ]
  },
  {
    "id": "4",
    "title": "Buchmesse, Gesang und Hunde",
    "sourcePage": 217,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "b",
        "stem": "Ein Bekannter möchte alte Romane verschenken."
      },
      {
        "num": 12,
        "answer": "l",
        "stem": "Ein Freund braucht nur noch einen Hundekorb für seinen kleinen Hund."
      },
      {
        "num": 13,
        "answer": "f",
        "stem": "Eine Freundin möchte günstige Bücher für ihre achtjährige Tochter kaufen."
      },
      {
        "num": 14,
        "answer": "c",
        "stem": "Ihr Mann singt gerne und möchte Mitglied in einem Gesangverein werden."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ihr Sohn möchte in seiner Freizeit Hunde ausführen"
      },
      {
        "num": 16,
        "answer": "g",
        "stem": "Ihre Familie möchte sich mit Menschen aus anderen Ländern treffen"
      },
      {
        "num": 17,
        "answer": "h",
        "stem": "Ihre Tochter wünscht sich einen Hund. Sie möchten sich zuerst informieren"
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Sie interessieren sich für die Arbeit in einer Buchhandlung"
      },
      {
        "num": 19,
        "answer": "i",
        "stem": "Sie möchten einen Kulturverein gründen und sich informieren."
      },
      {
        "num": 20,
        "answer": "a",
        "stem": "Sie suchen nach einem jungen Hund für Ihre Familie."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Vier herzallerliebste Mopswetpen, drei Weibchen und ein Männchen, in gute Hände abzugeben. Die Hundebabys können uns in ca sechs Wochen verlassen und in ihr neues Heim einziehen. Unsere Welpen wachsen gemeinsam mit Katzen und Pferden auf. Sie sind an Erwachsene und kleine Kinder gewöhnt und eignen sich deshalb Hervorragend als Familienhunde. Bei Abgabe sind die jungen Tiere gechipt Und haben alle ublichen Impfungen bekommen. Sie wurden entwurmt und besitzen ein tierärztliches Gesundheitszeugnis. Vereinbaren Sie jetzt einen Besuchstermin. Bitte nur bei ernsthaften Interesse! karina_mayer@outlook.com"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Herbstzeit ist Lesezeit! Wir veranstalten auch dieses Jahr wieder Unseren traditionellen Bücher Flohmarkt Sie finden bei uns Spannenden Lesestoff in über 40 Kategorien, von A wie Abenteuerromane bis Z wie Zeitschriften. Außerdem gibt es gebrauchte CDs",
          "und Spielesamnlungen. Spannendes, Lustiges, Lehrreiches: Lesefutter gibt es schon Für 1 Euro Für Kaffee und Kuchen zur Stärkung ist auch gesorgt. 15. September, 10:00",
          "bis 18:00 Uhr, im Pfarrsaal. Buchspenden werden ab sofort Im Pfarrbüro, Riederweg 14, entgegengenommen. Die Einnahmen vom Verkauf sind für soziale Zwecke"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Auenbacher Bach-Verein Auf den folgenden Seiten finden Sie Informationen zu unserem gemischten Chor Derzeit zählt unser Chor 30 Mitglieder. Nach vielen Jahren als Chormitglied hat Lisa Akgül im letzten Herbst die Chorleitung übernommen. Wir proben in der Regel jeden Donnerstag von 20:00 bis 22:00 Uhr in der Musikschule Auenbach. Wenn Sie wissen möchten, wie unser Chor klingt. klicken Sie hier auf Hörprobe. Um unserem Chor beizutreten. ist keine Gesangsausbildung erforderlich. Wir freuen uns immer über Verstärkung. Schauen Sie doch einfach bei einer unserer Proben vorbei! Natürlich können Sie auch unser Kontaktformular nutzen."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Hundezubehör günstig abzugeben: Hundekörbchen, schwarz, 60 50 x 20 cm ‚Sehr schones, fast unbenutztes Lederhalsband, 23 cm. Futter oder Wasserschüssel aus Keramik, Durchmesser 18 cmMaulkorb, silberfarbiger Draht Größe 1 . Regenmantel für kleine Hunde, Größe 25M, passend z. B. für Malteser oder Pinscher, für eine Rückenlänge von ca. 25 cm. Diverses Hundespielzeug (Ball am Seil, Quietscher, Knotenseil...) Nur als Gesamtpaket abzugeben! Preis nach Vereinbarung. ‚Anfrage telefonisch unter 069-96 12 17 22, bitte nur zwischen 18:00 und 20:00 Uhr"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Die Leipziger Buchmesse ist Deutschlands zweitgrößte Buchmesse. Sie findet jedes Jahr Mitte März auf dem Messegelände im Norden Leipzig statt. Die Verlage präsentieren dort ihre Neuerscheinungen. Die Leipziger Buchmesse richtet sich vor allem an das allgemeine Lesepublikum. Die Begegnung zwischen Autoren und Besuchern soll im Mittelpunkt stehen. Während der vier Messetage haben Leserinnen und Leser im Rahmen des Lesefestivals ‚Leipzig liest\" die Möglichkeit, aus rund 1 800 Leseveranstaltungen zu wählen. Jedes Jahr bekommt ein anderes sogenanntes Schwerpunktland die Gelegenheit, einem breiten Publikum seine Literatur vorzustellen."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Nach 30 Jahren am Völkerpark schließen wir im Frühjahr unseren Laden und verabschieden uns in die Rente. Wir möchten uns bei allen Kundinnen und Kunden bedanken, die uns über viele Jahre die Treue gehalten haben. Deshalb startet ab sofort der große Bücherausverkauf: [; Sachbücher, Bildbände: 30% Rabatt -Romane, Lyrik, gebundene Ausgaben: 40 % Rabatt Taschenbücher: 50 % Rabatt Kinderbücher: bis zu 70 % Rabatt Buchhandlung Bücherstand, Am Völkerpark 3, 44388 Dortmund solange der Vorrat reichtl. !"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Neugründung eines interkulturellen Vereins",
          "Gemeinsam singen, musizieren, kochen, essen und Diskutierendas hat sich der neugegründete Verein SANNU auf seine Fahnen geschrieben. Zum Angebot Zählen auch Lesungen, Konzerte und Vorträge. Der Schwerpunkt liegt aber auf dem gegenseitigen Kennenlernen. Die Gründerinnen und Gründer von SANNU möchten vor allem Familien ansprechen und Eine Begegnungsstätte für Menschen aus aller Welt Und aller Altersgruppen schaffen. >> mehr Infos zum Angebot"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Sie möchten einen Hund kaufen? Ein solcher Schritt sollte gut überlegt sein. Es gibt Vieles zu bedenken: Erlaubt Ihr Mietvertrag einen Hund in Ihrer Wohnung? Wohnen Sie in einer Gegend, die für einen Hund geeignetist? Auch Ihre Lebenssituation spielt eine wichtige Rolle. Sind Sie berufstätig? Können Sie den Hund mit zur Arbeit nehmen? Reichen Ihre finanziellen Mittel für eine Hundehaltung? Über solche und viele andere Überlegungen vor dem Hundekauf können Sie mit Frau Dr. Ines Sperber diskutieren. Am 12. März, VHS, Raum 101 18:30 Uhr"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Sportvereine, Musikvereine, Tanzvereine, Anglervereine, die Liste ist lang: In Deutschland sind B mehr als eine halbe Million Vereine registriert. Die Organisation von Vereinen ist in Deutschland genau geregelt. Am kommenden Dienstag geht es in der Vortragsreihe Bürger Aktiv um die gesetzlichen Bestimmungen zur Gründung eines Vereins. Interessenten bekommen hier alle nötigen Infos. Das Treffen findet im Haus der Begegnung am Uferweg 22 statt, Beginn um 19:30 Uhr. Die Teilnahme ist kostenlos. Anmeldung unter begegnung@hausder.de."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Günstige Bücher für Studenten",
          "Bei uns können Sie gebrauchte Fachbücher zu diversen Themen kaufen oder Verkaufen, z. B.:",
          "Architektur, Chemie, Germanistik, Kunst, Mathematik, Pädagogik, u. v. a.",
          "Sie brauchen sich nicht zu registrieren. Machen Sie einfach online Ihr Angebot Oder erstellen Sie",
          "kostenlos Ihr Verkaufsinserat im Kleinanzeiger für Studentinnen Und Studenten. Mit Ihrem Text",
          "können Sie Bis zu drei Bilder hochladen.",
          "Angebote.",
          "Anzeige aufgeben ma a a oo os oo gs oe go od"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Sie haben erfolgreich einen neuen Verein gegründet und bemühen sich nun um neue Mitglieder?",
          "Damit Sie einen großen Kreis von Interessenten ansprechen und Mitglieder für Ihren Neuen Verein werben können, brauchen Sie Öffentliche Aufmerksamkeit. Dazu können Sie Aufwändige Broschüren drucken lassen oder Teure Anzeigen aufgeben.",
          "Oder Sie kommen zu uns: Bei uns haben Sie die Möglichkeit, Ihren Verein mit einer direkten Verknüpfung zu Ihrer Homepage eintragen zu lassen. Die Registrierung ist für Sie mit keinerlei Kosten verbunden. >> weiter zur kostenlosen Registrierung"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "In unserem Shop finden Sie mehr als 3000 verschiedene Produkte. Sie können aus 30 Marken Hundefutter wählen, von besonders günstigem Futter bis zu hochwertigem Futter ohne",
          "chemische Zusatzstoffe und veganem Hundefutter, Im Bereich Hundezubehör finden Sie",
          "alles, was Hundehalter brauchen, zum Beispiel Leinen & Halsbänder, Boren, Schlafplätze und Spielzeug. Beachten Sie auch unsere Sonderangebote und unsere neuen Produkte. Wir",
          "bieten Ihnen einen Neukundenrabatt von fünf Prozent und portofreie Zusendung ab einem Bestellwert von 25 Euro.",
          "Viel Spaß beim Einkauf in unserem Online-Hundeshop."
        ]
      }
    ]
  },
  {
    "id": "5",
    "title": "Gärten, Natur und Ausflüge",
    "sourcePage": 220,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "x",
        "stem": "Ein Bekannter hat Gartenbau studiert und sucht eine Stelle als Gartenbau-Ingenieur in einem Botanischen Garten."
      },
      {
        "num": 12,
        "answer": "h",
        "stem": "Ein Kollege sammelt Bücher über Gartengestaltung in unterschiedlichen Ländern und Epochen."
      },
      {
        "num": 13,
        "answer": "e",
        "stem": "Eine Kollegin interessiert sich für Kultur- und Stadtgeschichte."
      },
      {
        "num": 14,
        "answer": "a",
        "stem": "Ihr Nachbar beschäftigt sich gerne mit Architektur. Er möchte an einem freien Nachmittag spazierengehen und dabei interessante Bauwerke ansehen."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ihr Onkel möchte auf einer Weltreise berühmte Park- und Gartenanlagen besichtigen."
      },
      {
        "num": 16,
        "answer": "i",
        "stem": "Ihre Mutter möchte den Garten neu gestalten und sucht Tipps aus der Praxis."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Ihre Nichte studiert Kunst und möchte sich Bilder mit Naturmotiven ansehen."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "Ihre Schwester sucht einen Garten, in dem sie sich von ihrem anstrengenden Beruf erholen kann."
      },
      {
        "num": 19,
        "answer": "d",
        "stem": "Ihre Tante möchte exotische Vögel beobachten."
      },
      {
        "num": 20,
        "answer": "b",
        "stem": "Sie möchten mit Ihrem zehnjährigen Sohn in der freien Natur einen abenteuerlichen und unterhaltsamen Nachmittag verbringen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Die \"Gärten der Welt\" sind zehn Themengärten, die im Erholungspark Marzahn angelegt sind. Auf 43 Hektar laden sie zu einer Reise durch verschiedene Teile der Welt und Epochen ein: Zu besichtigen sind chinesische, japanische, europäische und auch orientalische Gartenkunst. Brücken, Brunnen, Pavillons und Gebäude wie ein chinesisches Teehaus zeigen die Bautradition ! der verschiedenen Gartenkulturen. Über das Parkgelände verteilen sich Wiesen, Blumenbeete, Spiel- und Liegewiesen"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Nach rechts, nach links oder geradeaus? Der in einer idyllischen Landschaft gelegene Irrgarten in Vilpian lädt Groß und Klein, Jung und Alt ein, sich auf die Suche nach dem richtigen Weg zu begeben. Kinder und Erwachsene irren durch zahlreiche Gänge und Sackgassen zwischen",
          "hohen Hecken. Und nicht alle Wege führen zum Aussichtsturm in der Mitte. Doch bisher hat noch jeder hinausgefunden. Mit einer Weglänge von 4 km bietet das Labyrinth Spannung und Nervenkitzel auch für Erwachsene. Ein Freizeitspaß für die ganze Familie."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "er eeee Obst und Gemüse im Garten anbauen - das ist auch möglich. wenn Sie in der Stadt leben. Wenn Ihnen ein paar Blumenkästen auf dem Balkon nicht genug sind, Sie gerne draußen Ihre Freizeit verbringen und sich auf Ihrer Wiese sonnen möchten - dann werden Sie Mitglied im Kleingartenverein Engers. Wie verfügen über eine Anlage mit insgesamt 103 Kleingärten. Zum Jahresende werden einige Gärten frei, die neu vergeben werden können. Wenn Sie gerne einen Kleingarten bewirtschaften möchten, nehmen Sie mit uns Kontakt auf.",
          "— TG To"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Palmen in der Großstadt",
          "Mitten in Frankfurt können Besucher Pflanzen und Gewächse aus allen Teilen der Welt entdecken. Zwischen Spazierwegen, Liegewiesen, Grünflächen und Blumenbeeten finden sich in dem 1868 gegründeten Palmengarten verschiedene thematische Gärten und Gewächshäuser. Wenn der Besucher das 18 m hohe Palmenhaus betritt, findet er sich in einer subtropischen Landschaft mit riesigen Palmen wieder. In großzügigen Käfigen attern Papageien, Kakadus und Nymphensittiche; tropische Fische lassen sich in Aquarien bestaunen. Ein ständig wechselndes Ausstellungsprogramm bietet Blumenschauen, Führungen, Vorträge und Konzerte."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Baden und Schwimmen ist nicht nur gesund, sondern bereitet Kindern und Erwachsenen viel Freude! Und das nicht erst seit gestern: Schon im Mittelalter kannte man Badestuben oder erfrischte sich bei 4 einem Flussbad im Main. Badehäuser und Schwimmbäder gehören zum Stadtbild und legen Zeugnisab von der Kultur und Architektur ihrer Epoche. Die kulturhistorische Ausstellung \"Badekultur in Frankfurt” zeigt anhand vieler Fotos, Abbildungen und Karten die lange Tradition des Badewesens in der Stadt. Sie ist noch bis September im ehemaligen Karmeliterkloster zu besichtigen. Hi PENIS ENEEENEEEEEEEEIREEIREEEEREEREEE."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Erholung vom Alltagsstress und Ruhe findet man im Garten, bei der Arbeit an der frischen Luft. Doch seit Jahrhunderten beflügeln Gärten auch die Phantasie der Maler und lassen diese zwar nicht zum Spaten, , aber doch zum Pinsel greifen. Die Ausstellung \"Gartenglück\" widmet sich Gartenbildern: Die Kuratoren haben über 100 herausragende Gemälde und Zeichnungen aus Museen und Privatsammlungen zusammengetragen. Zu sehen sind Exponate vom Mittelalter bis zur Gegenwart. Diese zeigen, welche Bedeutung dieser idyllische Ort für Künstler hatte: In ihren Werken ß halten sie die Schönheit der vom Menschen gestalteten Natur fest."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Blumenaquarelle",
          "Blumen gehören in der Malerei zu den beliebtesten Motiven. Sie faszinieren durch ihre Farben, zieren Fensterbänke und Balkons, finden sich auch in der Großstadt in Parkanlagen. Wir haben sie zwar immer vor Augen, doch es ist nicht leicht, sie bildlich festzuhalten. In diesem Kurs lernen Sie, wie Ihnen dies gelingt: Sie erfahren, wie man Blumen und Blüten detailgetreu und lebendig farbig darstellen kann. Grundkenntnisse zu Aquarellmaltechniken und Erfahrung in der Aquarellmalerei sind für die Teilnahme notwendig."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Meisterwerke der Gartenarchitektur",
          "Gärten sind Paradiese von Menschenhand: Natur und Architektur werden eins. Von den Gärten der Antike ausgehend, präsentiert dieser Bildband große historische Gartentypen, darunter den italienischen, französischen und englischen Garten ebenso wie die Wunderwelt des chinesischen Gartens sowie die japanische Gartenkunst. Spektakuläre Fotografen erlauben auch Einblicke in kleine private Gärten und verborgene königliche Hofgärten. Den Abschluss bilden Gärten der Moderne"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Einen Garten ganz nach den eigenen Vorstellungen anlegen, Gemüse anbauen, die Schönheit von Blumen und Ziersträuchern genießen: Das wünschen sich viele Hobbygärtner. Das Buch \"Gartenbau heute” gibt Anfängern wie auch erfahrenen Gärtnern wertwolle Anleitungen zur praktischen Umsetzung. Es enthält zahlreiche Beispiele, umfangreiches Bildmaterial sowie graphische Darstellungen. Der Autor Ri ist Gartenbau-Ingenieur und erklärt alles über Gartenstile, die Planung und den Entwurf eines Gartens bis hin zur Bepflanzung. Außerdem werden Hinweise zur modernen Gartenarchitektur gegeben."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Im Kletterwald Höhr-Grenzhausen erwartet Kletterfreunde ein Abenteuer der besonderen Art. Fünf Routen mit unterschiedlichen Schwierigkeitsgraden führen in bis zu 18 m Höhe. Erwachsene und Jugendliche ab 14 Jahren finden hier eine spannende Herausforderung in einer Welt aus Seilen, Brücken, Rutschen und Plattformen, und das alles inmitten einer traumhaften Waldkulisse. In unserem Seilpark erwarten Sie Unterhaltung, Bewegung in der freien Natur und vieles mehr. Klettererfahrung ist nicht notwendig. Die Kletterausrüstung wird gestellt und Sie werden von einem professionellen Trainier begleitet."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Wer flattert denn da in meinem Garten herum? Vögel zu beobachten macht vielen Hobby-Gärtnern große Freude. In dem Ratgeber \"Gefiederte Gäste im Garten” finden Sie ausführliche Porträts der verschiedenen Arten und zahlreiche nützliche Ratschläge. Außerdem erfahren Sie, wie Sie Gartenvögel durch Nistkästen, Futter, das Schaffen von Trink- und Badeplätzen unterstützen und sie vor Gefahren schützen können. Das Buch informiert auch über typische Verhaltensweisen der Vögel und liefert faszinierende Einblicke in die heimische Vogelwelt."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Der Botanische Garten in Koblenz bildet seit vielen Jahren erfolgreich Gärtner aus. Zu den zahlreichen Vorteilen, die dieser Ausbildungsplatz zu bieten hat, gehört die Vielfalt seltener Pflanzenarten, die die Auszubildenden dort entdecken und studieren können. Außerdem arbeiten sie in einem Team aus erfahrenen Gärtnern, die ihnen beratend zur Seite stehen. Voraussetzung für die Ausbildung ist ein Realschulabschluss. Die Ausbildung dauert in der Regel drei Jahre. Da die meisten Arbeiten im Freien erfolgen, sind körperliche Fitness und Freude an körperlicher Betätigung ebenfalls Voraussetzung für diese Tätigkeit. &"
        ]
      }
    ]
  },
  {
    "id": "6",
    "title": "Sport, Feuerwehr und Stadtrundgang",
    "sourcePage": 223,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "h",
        "stem": "Ein Freund von Ihnen möchte gerne bei einer Sportveranstaltung mitarbeiten."
      },
      {
        "num": 12,
        "answer": "g",
        "stem": "Sie interessieren sich für Videos von besonderen Rettungseinsätzen."
      },
      {
        "num": 13,
        "answer": "a",
        "stem": "Sie möchten mehr über die psychischen Aspekte von Klettersport erfahren."
      },
      {
        "num": 14,
        "answer": "j",
        "stem": "Sie möchten mithelfen, ihre Stadt schöner zu machen."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ihr Vater plant, eine Familienchronik zu schreiben."
      },
      {
        "num": 16,
        "answer": "e",
        "stem": "Sie möchten einem Freund ein besonderes Sporterlebnis schenken."
      },
      {
        "num": 17,
        "answer": "k",
        "stem": "Ihre sechzehnjährige Cousine beschäftigt sich gerne mit kleinen Kindern."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "Sie suchen Informationen zu den gesundheitlichen Auswirkungen von Sport."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Sie suchen Informationen über eine Versicherung gegen Sportverletzungen."
      },
      {
        "num": 20,
        "answer": "l",
        "stem": "Ihr kleiner Bruder möchte einmal ein Feuerwehrauto aus der Nähe sehen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Gerlinde Kaltenbrunner Die Osterreicherin Gerlinde Kaltenbrunner zählt zu den bekanntesten Bergsteigerinnen der Welt. Als erste Frau hat sie aus eigener Kraft, das heißt ohne Träger und ohne Sauerstoff, alle 14 Achttausender bestiegen. Schon sehr früh entdeckte sie ihre Begeisterung für die Berge ihrer oberösterreichischen Heimat. Ihren ersten Achttausender bestieg sie mit 23 Jahren und seit mehr als zehn Jahren ist sie Profibergsteigerin. In ihrem Vortrag spricht Gerlinge Kaltenbrunner über ihre Erlebnisse und ihre Pläne, über Leidenschaft, Willensstärke, Disziplin und Geduld. Höhenbergsteigerin Gerlinde Kaltenbrunner, 14. Mai, Kulturzentrum, 20.00 Uhr"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Senlorenwohnhaus \"Zur alten Linde”",
          "Sie möchten sich gerne ehrenamtlich im sozialen Bereich engagieren? Wir bieten Ihnen eine ganze Reihe von Möglichkeiten dazu: Besuchsdienste, Begleitung und Hilfestellung bei Behördenwegen, Spazierengehen und vieles mehr. Wenn Sie sich für alte Menschen und ihre Geschichten interessieren, wenn sie Einfühlungsvermögen haben und gerne zuhören, dann füllen Sie doch einfach den Fragebogen aus. Anschließend vereinbaren wir einen Termin für ein Erstgespräch",
          "Wir freuen uns auf Ihre Nachricht."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "[oe EEE Neue Studie erschienen Eine neue Studie stellt intensiv betriebenem körperlichem Training kein gutes Zeugnis aus. Dabei hatte die Studie den Aspekte des hohen Gefahrenpotentials und die damit verbundenen Unfallverletzungen bewusst ausgeklammert. Es ging lediglich um die Fragestellung, ob ein Mehr an körperlichem Training auch gesünder sei. Dass regelmäßige Bewegung gesund ist, steht außer Frage. Wer sich täglich körperlich betätigt, senkt sein Risiko für viele Krankheiten wie zum Beispiel Diabetes und Herzerkrankungen. Der Studie zufolge soll extremes Training dieses Risiko allerdings wieder erhöhen. Zu den ausführlichen Ergebnissen der Studie gelangen Sie hier. ———-\"PÖM“’T] JA -\"\"Ö\"\"!\"!)F"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Historische Fotos für das Stadtjubiläurn",
          "Für die geplante Ausstellung zum bevorstehenden Stadtjubiläum sucht das Kulturamt noch historische Aufnahmen. Dazu werden alle Bürgerinnen und Bürger ganz herzlich gebeten, alte Bilder und Fotos zu Verfügung zu stellen. Von Interesse sind nicht nur geschichtlich relevante Aufnahmen, sondern auch private Bilder, die vom Leben in unserer Stadt erzählen. Weil in diesem Jahr auch der Städtische Sportclub sein 100-jähriges Bestehen feiert, soll es eine eigene Bilderabteilung geben, die historischen Sportveranstaltungen gewidmet ist. Der Termin und der Ort, zu dem Sie ihre Erinnerungsstücke zur Sichtung bringen können, werden noch bekannt gegeben."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Nervenkitzel pur: Bungee-Jumping Wir bieten euch unvergessliche Erlebnisse rund um die Extremsportart Bungee-Jumping. In einer g traumhaften Landschaft, mehr als 100 Meter über dem Wasser, verschaffen wir euch den ultimativen Kick! im Sommer haben wir wieder täglich von Dienstag bis Sonntag jeweils ab Mittag geöffnet - geeignetes Wetter vorausgesetzt. Für Sprünge am Tag ist eine Reservierung nicht zwingend notwendig, g aber besonders bei Schönwetter empfehlenswert. Im August bieten wir auch zwei Nachtsprungtermine an. Für diese müsst ihr mindestens sechs Personen sein und euch auch verbindlich anmelden. Hier geht es zur Terminreservierung. Weitere Infos zu Preisen, Lage und Anfahrt gibt es hier. 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Freiwillige Feuerwehr Die Freiwilligen Feuerwehren rücken nicht nur an, wenn es brennt, sondern vermitteln auch L Wissenswertes zum Thema Brandschutz. Gemeinsam mit Pädagogen hat unsere Freiwillige Feuerwehr ! ein Programm entwickelt, mit dem sie das Bewusstsein der Kinder und Jugendlichen für das Thema ! Sicherheit und Gefahrenvermeidung schärfen möchte. Im Rahmen dieses Projektes wurden gemeinsam mit Pädagogen und Pädagoginnen besondere Arbeitsunterlagen für Trainingseinheiten an ! Bildungsstätten vorbereitet. Interessierte Schulen und Kindergärten haben noch bis Ende April die Möglichkeit, sich zu dem training anzumelden. Tel.: 0677-4567489"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Spektakuläre Feuerwehrübung",
          "Übung für den Ernstfall: Gemeinsam mit anderen Einsatzorganisationen veranstaltete die örtliche Feuerwehr eine besonders eindrucksvolle Einsatzübung. Dabei wurde simuliert, dass sich bei einer Führung durch das Rathaus ein Unfall im Turm ereignet und mehrere schwerverletzte Menschen geborgen werden müssen. Nach der Erstversorgung durch einen Notarzt in schwindelnder Höhe gelang es, die angeblichen Schwerverletzten über die Drehleiter zu bergen. Hier der Film des spektakulären Finsatzes"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "[6 Helfer und Helferinnen gesucht Für unseren Halbmarathon am 20. Juli suchen wir noch Freiwillige, die uns bei der Benefizveranstaltung unterstützen möchten. Es gibt viele Bereiche, in denen ihr uns helfen könnt: vom Aufbau von Zuschauerbarrieren über Streckensicherung und Startnummernausgabe bis zum Einsatz an den Verpflegungsposten - jede helfende Hand ist uns herzlich willkommen. Die Veranstaltung dient einem guten Zweck. Die Startgelder und 10 Prozent der Einnahmen aus der Gastronomie gehen an gemeinnützige Vereine unserer Stadt. Anmelden könnt ihr euch auf der Webseite der Stadtverwaltung unter Veranstaltungen/ Halbmarathon/ Freiwillige"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Märchenwanderung für Kinder von 8 bis 12 Jahren Wir wandern entlang des Märchenwanderwegs, der durch eine abwechslungsreiche Landschaft führt, mit herrlicher Aussicht auf die Berge. Am Ende des Weges gelangen wir zu einem Wildgehege. Was ihr braucht: feste Schuhe, bei unbeständigen Wetter einen Regenschutz (bitte keine Schirme) und Kleidung, die ruhig schmutzig werden dar. Treffpunkt: vor der Kirche, um 10.00 Uhr. ! Dauer: 4 Stunden ( Wander- und Erzählzeit) Teilnahmegebühr: 17 Euro inklusive Mittagessen. Leitung: Märchentante Gerlinde, unterstützt von zwei freiwilligen Helferinnen. Wir wandern ohne Eltern oder Begleitpersonen."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "‚Aktion \"Sauberes Grün”",
          "Die Aktion \"Sauberes grün” findet dieses Jahr nicht wie bisher an einem einzigen Tag statt, sondern dauert gleich drei Tage. Wir rufen Kindergärten, Schulen und Vereine dazu auf, sich auch dieses Jahr wieder zahlreich an unserer gemeinnützigen Putzaktion zu beteiligen. Ausgerüstet mit Handschuhen und Säcken, werden die Teilnehmerinnen und Teilnehmer Grünflächen, Parks und Spielplätze in der Stadt säubern. Auch Einzelpersonen sind herzlich willkommen! Am Samstag gibt es dann wieder das große Abschlussfest",
          "Unsere jährliche Aktion für eine saubere Stadt, dieses Jahr vom 2. bis 4. Mai.",
          "Anmeldungen bei den städtischen Reinigungsbetrieben: 0240-191980"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Tag der offenen Tür in der städtischen Bücherei",
          "Zum Anlass des Welttags des Buches am 23 April möchten wir uns ganz den jungen Lesern widmen Unser Kinderprogramm umfasst auch spannende Lesungen, für die wir noch Freiwillige unter achtzehn suchen. Nicht Lehrer oder Eltern, sondern junge Menschen sollen den ganz Kleinen aus alten und neuen Kinderbüchern vorlesen.",
          "Wenn du gerne (vor)liest, dann bist du am 23. April bei uns genau richtig! Schick uns einfach deine Daten und einen Lesevorschlag per Mail an: info@buecherei-stadt.com.",
          "Übrigens: Als kleine Belohnung darfst du dich bei unserem Bücher-Flohmarkt bedienen!"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "150 Jahre Stadtfeuerwehr 1 Zum Jubiläum \"150 Stadtfeuerwehr” laden die Feuerwehr und Katastrophenschutz zu einer Leistungsschau. Zu besichtigen: das \"brandneue” Löschfahrzeug, das auch dank der großzügigen Unterstützung von Sponsoren angeschafft werden konnte. Weiter: einige abenteuerliche Bergungen 4 durch aktive Mitglieder der Freiwilligen Feuerwehr. Dann eine spektakuläre Löschaktion. Und zum Schluss: Grillfeuer für alle! Wann? Samstag 23. Juli ab 16.00 Uhr, am alten Messegelände. Die Freiwillige Feuerwehr hofft auf großes Interesse! 8"
        ]
      }
    ]
  },
  {
    "id": "6a",
    "title": "Sport, Feuerwehr und Stadtrundgang",
    "sourcePage": 226,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "c",
        "stem": "Sie suchen Informationen zu den gesundheitlichen Auswirkungen von Sport."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Sie suchen Informationen über eine Versicherung gegen Sportverletzungen."
      },
      {
        "num": 13,
        "answer": "g",
        "stem": "Sie interessieren sich für Videos von besonderen Rettungseinsätzen."
      },
      {
        "num": 14,
        "answer": "a",
        "stem": "Sie möchten mehr über die psychischen Aspekte von Klettersport erfahren."
      },
      {
        "num": 15,
        "answer": "e",
        "stem": "Sie möchten einem Freund ein besonderes Sporterlebnis schenken."
      },
      {
        "num": 16,
        "answer": "j",
        "stem": "Sie möchten dazu beitragen, Ihre Stadt schöner zu machen."
      },
      {
        "num": 17,
        "answer": "k",
        "stem": "Ihre sechzehnjährige Cousine beschäftigt sich gerne mit kleinen Kindern."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Ihr Vater plant, eine Familienchronik zu schreiben."
      },
      {
        "num": 19,
        "answer": "l",
        "stem": "Ihr kleiner Bruder möchte einmal ein Feuerwehrauto aus der Nähe sehen."
      },
      {
        "num": 20,
        "answer": "h",
        "stem": "Ein Freund von Ihnen möchte gerne bei einer Sportveranstaltung mitarbeiten."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Gerlinde Kaltenbrunner Die Osterreicherin Gerlinde Kaltenbrunner zählt zu den bekanntesten Bergsteigerinnen der Welt. Als erste Frau hat sie aus eigener Kraft, das heißt ohne Träger und ohne Sauerstoff, alle 14 Achttausender bestiegen. Schon sehr früh entdeckte sie ihre Begeisterung für die Berge ihrer oberösterreichischen Heimat. Ihren ersten Achttausender bestieg sie mit 23 Jahren und seit mehr als zehn Jahren ist sie Profibergsteigerin. In ihrem Vortrag spricht Gerlinge Kaltenbrunner über ihre Erlebnisse und ihre Pläne, über Leidenschaft, Willensstärke, Disziplin und Geduld. Höhenbergsteigerin Gerlinde Kaltenbrunner, 14. Mai, Kulturzentrum, 20.00 Uhr"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Senlorenwohnhaus \"Zur alten Linde”",
          "Sie möchten sich gerne ehrenamtlich im sozialen Bereich engagieren? Wir bieten Ihnen eine ganze Reihe von Möglichkeiten dazu: Besuchsdienste, Begleitung und Hilfestellung bei Behördenwegen, Spazierengehen und vieles mehr. Wenn Sie sich für alte Menschen und ihre Geschichten interessieren, wenn sie Einfühlungsvermögen haben und gerne zuhören, dann füllen Sie doch einfach den Fragebogen aus. Anschließend vereinbaren wir einen Termin für ein Erstgespräch",
          "Wir freuen uns auf Ihre Nachricht."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Deere tl EEE nn",
          "Neue Studie erschienen",
          "Eine neue Studie stellt intensiv betriebenem körperlichem Training kein gutes Zeugnis aus. Dabei hatte",
          "die Studie den Aspekte des hohen Gefahrenpotentials und die damit verbundenen Unfallverletzungen",
          "bewusst ausgeklammert. Es ging lediglich um die Fragestellung, ob ein Mehr an körperlichem Training",
          "auch gesünder sei. Dass regelmäßige Bewegung gesund ist, steht außer Frage. Wer sich täglich",
          "körperlich betätigt, senkt sein Risiko für viele Krankheiten wie zum Beispiel Diabetes und",
          "Herzerkrankungen. Der Studie zufolge soll extremes Training dieses Risiko allerdings wieder erhöhen.",
          "Zu den ausführlichen Ergebnissen der Studie gelangen Sie hier. ———-\"PÖM“’T] JA -\"\"Ö\"\"!\"!)F"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Historische Fotos für das Stadtjubiläurn",
          "Für die geplante Ausstellung zum bevorstehenden Stadtjubiläum sucht das Kulturamt noch historische Aufnahmen. Dazu werden alle Bürgerinnen und Bürger ganz herzlich gebeten, alte Bilder und Fotos zu Verfügung zu stellen. Von Interesse sind nicht nur geschichtlich relevante Aufnahmen, sondern auch private Bilder, die vom Leben in unserer Stadt erzählen. Weil in diesem Jahr auch der Städtische Sportclub sein 100-jähriges Bestehen feiert, soll es eine eigene Bilderabteilung geben, die historischen Sportveranstaltungen gewidmet ist. Der Termin und der Ort, zu dem Sie ihre Erinnerungsstücke zur Sichtung bringen können, werden noch bekannt gegeben."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Nervenkitzel pur: Bungee-Jumping Wir bieten euch unvergessliche Erlebnisse rund um die Extremsportart Bungee-Jumping. In einer g traumhaften Landschaft, mehr als 100 Meter über dem Wasser, verschaffen wir euch den ultimativen Kick! im Sommer haben wir wieder täglich von Dienstag bis Sonntag jeweils ab Mittag geöffnet - geeignetes Wetter vorausgesetzt. Für Sprünge am Tag ist eine Reservierung nicht zwingend notwendig, g aber besonders bei Schönwetter empfehlenswert. Im August bieten wir auch zwei Nachtsprungtermine an. Für diese müsst ihr mindestens sechs Personen sein und euch auch verbindlich anmelden. Hier geht es zur Terminreservierung. Weitere Infos zu Preisen, Lage und Anfahrt gibt es hier. 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Freiwillige Feuerwehr Die Freiwilligen Feuerwehren rücken nicht nur an, wenn es brennt, sondern vermitteln auch L Wissenswertes zum Thema Brandschutz. Gemeinsam mit Pädagogen hat unsere Freiwillige Feuerwehr ! ein Programm entwickelt, mit dem sie das Bewusstsein der Kinder und Jugendlichen für das Thema ! Sicherheit und Gefahrenvermeidung schärfen möchte. Im Rahmen dieses Projektes wurden gemeinsam mit Pädagogen und Pädagoginnen besondere Arbeitsunterlagen für Trainingseinheiten an ! Bildungsstätten vorbereitet. Interessierte Schulen und Kindergärten haben noch bis Ende April die Möglichkeit, sich zu dem training anzumelden. Tel.: 0677-4567489"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Spektakuläre Feuerwehrübung",
          "Übung für den Ernstfall: Gemeinsam mit anderen Einsatzorganisationen veranstaltete die örtliche Feuerwehr eine besonders eindrucksvolle Einsatzübung. Dabei wurde simuliert, dass sich bei einer Führung durch das Rathaus ein Unfall im Turm ereignet und mehrere schwerverletzte Menschen geborgen werden müssen. Nach der Erstversorgung durch einen Notarzt in schwindelnder Höhe gelang es, die angeblichen Schwerverletzten über die Drehleiter zu bergen. Hier der Film des spektakulären Finsatzes"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Vc Helfer und Helferinnen gesucht Für unseren Halbmarathon am 20. Juli suchen wir noch Freiwillige, die uns bei der Benefizveranstaltung unterstützen möchten. Es gibt viele Bereiche, in denen ihr uns helfen könnt: vom Aufbau von Zuschauerbarrieren über Streckensicherung und Startnummernausgabe bis zum Einsatz an den Verpflegungsposten - jede helfende Hand ist uns herzlich willkommen. Die Veranstaltung dient einem guten Zweck. Die Startgelder und 10 Prozent der Einnahmen aus der Gastronomie gehen an gemeinnützige Vereine unserer Stadt. Anmelden könnt ihr euch auf der Webseite der Stadtverwaltung unter Veranstaltungen/ Halbmarathon/ Freiwillige"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Märchenwanderung für Kinder von 8 bis 12 Jahren Wir wandern entlang des Märchenwanderwegs, der durch eine abwechslungsreiche Landschaft führt, mit herrlicher Aussicht auf die Berge. Am Ende des Weges gelangen wir zu einem Wildgehege. Was ihr braucht: feste Schuhe, bei unbeständigen Wetter einen Regenschutz (bitte keine Schirme) und Kleidung, die ruhig schmutzig werden dar. Treffpunkt: vor der Kirche, um 10.00 Uhr. ! Dauer: 4 Stunden ( Wander- und Erzählzeit) Teilnahmegebühr: 17 Euro inklusive Mittagessen. Leitung: Märchentante Gerlinde, unterstützt von zwei freiwilligen Helferinnen. Wir wandern ohne Eltern oder Begleitpersonen."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "‚Aktion \"Sauberes Grün”",
          "Die Aktion \"Sauberes grün” findet dieses Jahr nicht wie bisher an einem einzigen Tag statt, sondern dauert gleich drei Tage. Wir rufen Kindergärten, Schulen und Vereine dazu auf, sich auch dieses Jahr wieder zahlreich an unserer gemeinnützigen Putzaktion zu beteiligen. Ausgerüstet mit Handschuhen und Säcken, werden die Teilnehmerinnen und Teilnehmer Grünflächen, Parks und Spielplätze in der Stadt säubern. Auch Einzelpersonen sind herzlich willkommen! Am Samstag gibt es dann wieder das große Abschlussfest",
          "Unsere jährliche Aktion für eine saubere Stadt, dieses Jahr vom 2. bis 4. Mai.",
          "Anmeldungen bei den städtischen Reinigungsbetrieben: 0240-191980"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Tag der offenen Tür in der städtischen Bücherei",
          "Zum Anlass des Welttags des Buches am 23 April möchten wir uns ganz den jungen Lesern widmen Unser Kinderprogramm umfasst auch spannende Lesungen, für die wir noch Freiwillige unter achtzehn suchen. Nicht Lehrer oder Eltern, sondern junge Menschen sollen den ganz Kleinen aus alten und neuen Kinderbüchern vorlesen.",
          "Wenn du gerne (vor)liest, dann bist du am 23. April bei uns genau richtig! Schick uns einfach deine Daten und einen Lesevorschlag per Mail an: info@buecherei-stadt.com.",
          "Übrigens: Als kleine Belohnung darfst du dich bei unserem Bücher-Flohmarkt bedienen!"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "150 Jahre Stadtfeuerwehr 1 Zum Jubiläum \"150 Stadtfeuerwehr” laden die Feuerwehr und Katastrophenschutz zu einer Leistungsschau. Zu besichtigen: das \"brandneue” Löschfahrzeug, das auch dank der großzügigen Unterstützung von Sponsoren angeschafft werden konnte. Weiter: einige abenteuerliche Bergungen 4 durch aktive Mitglieder der Freiwilligen Feuerwehr. Dann eine spektakuläre Löschaktion. Und zum Schluss: Grillfeuer für alle! Wann? Samstag 23. Juli ab 16.00 Uhr, am alten Messegelände. Die Freiwillige Feuerwehr hofft auf großes Interesse! 8"
        ]
      }
    ]
  },
  {
    "id": "7",
    "title": "Urlaub, Ausflüge und Gesundheit",
    "sourcePage": 229,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "g",
        "stem": "Ein Bekannter möchte miterleben, wie spektakuläre Filmszenen gedreht werden."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Eine Bekannte interessiert sich für CDs mit klassischer Musik."
      },
      {
        "num": 13,
        "answer": "d",
        "stem": "Eine Bekannte möchte eine mehrtägige Fußwanderung machen und dabei etwas über die kulturelle Vergangenheit der Region erfahren."
      },
      {
        "num": 14,
        "answer": "l",
        "stem": "Eine Bekannte möchte sich in einem Kurort von der Hektik des Alltags erholen."
      },
      {
        "num": 15,
        "answer": "c",
        "stem": "Ein Bekannter möchte im Urlaub auf einem See Boot fahren."
      },
      {
        "num": 16,
        "answer": "i",
        "stem": "Eine Familie möchte mit ihren Kindern einen aktiven und lustigen Tag verbringen."
      },
      {
        "num": 17,
        "answer": "j",
        "stem": "Ein Bekannter hat ein neues Kniegelenk bekommen und sucht eine geeignete Kur."
      },
      {
        "num": 18,
        "answer": "f",
        "stem": "Eine Bekannte ist Hobbyzoologin und interessiert sich für den Lebensraum \"Küste\"."
      },
      {
        "num": 19,
        "answer": "a",
        "stem": "Ein Bekannter liebt die Bergwelt, kann aber keine steilen und anstrengenden Wege mehr gehen."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Eine Bekannte möchte Geschichten über Ritter und Burgen lesen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Urlaubsregion Allgäuer Alpen Die Urlaubsregion Allgäuer Alpen ist mit eine der schönsten Deutschlands. Mit Bussen und Bahnen gelangt man zu Burgen, Schlössern, Kirchen und Klöstern. Das kulinarische Angebot bietet für jeden Geschmack genügend Auswahl. Bergwanderer schätzen - vor allem im Spätsommer - Hüttenwanderungen auf den gut ausgebauten Höhenwegen. Bergbahnen und Sessellifte nehmen viel von der Mühe des Aufstiegs ab. Auch für die Wassersportler ist ausreichend gesorgt."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "m an mn m a m nn a a m Ritter und Burgfräulein für ein Wochenende Seit vielen Jahrhunderten gibt es in Deutschland Burgen. Hoch über mittelalterlichen Städten",
          "und oft in romantischer Landschaft ragen sie als touristische Attraktionen empor. Für Geschichtsinteressierte inszeniert man im alten Gemäuer bunte Feste, die das Mittelalter originaltreu zum Leben erwecken. Hier erleben Sie Ritterturniere, Minnesang und zünftige Gelage. Beliebt sind auch Bauernmärkte mit traditionsreicher Handwerkskunst, Maskentreiben und Volkstheater, deren Stücke an die Sagen und Märchen anknüpfen, die sich um jede Burg ranken. Anmeldune unter info@mittelalter.com"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "[OP EEEEE Ferien im Harz Der Harz erhebt sich inselartig über der Norddeutschen Tiefebene und verbindet die Länder Sachsen-Anhalt, Niedersachsen und Thüringen. Er ist zugleich das höchste Mittelgebirge nördlich des Mains, im Brockenmassiv auf 1142 Meter ansteigend. Der Romkerhaller Wasserfall, der aus großer Höhe in die Tiefe stürzt, ist im Okertal neben der Okertalsperre ein beliebtes Fotomotiv. Fast jede Form von Wassersport ist hier möglich - Surfen, Paddeln, Rudern etc. —mmmammmmm— — 1;Z|;:—Z _,|_—,.,—"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Auf den Spuren des römischen Dichters Ausonius",
          "Von Bingen am Rhein bis nach Trier an der Mosel führt dieser nach dem römischen Dichter Ausonius benannte Wanderweg. Auf der ehemaligen römischen Heerstraße geht es stets über die Höhenrücken des Hunsrück. Durch Wälder und vorbei an Hunsrücker Dörfern ist die römische Vergangenheit an der Strecke und in Museen allgegenwärtig. Der 140 Kilometer lange Weg, den auch Ausonius bereiste, führt über die Höhen und durchschneidet die Bachtäler in stetigem Auf und Ab, um dann ab Neumagen die Mosel bis nach Trier zu begleiten."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Extra für Musicalfans MAMMA MIA! ist eine mitreißende Musical-Komödie mit den 22 größten Hits von ABBA - und keine langweilige Biografie. Alle Songs werden auf Deutsch gesungen, so ist ein schwungvoller und unterhaltsamer Abend garantiert. Die mitreißende Musical-Komödie von Benny Andersson und Björn Ulvaeus hat weltweit schon über 24 Millionen Zuschauer begeistert. MAMMA MIA! - ein grandiöses Stück über Liebe, Familie und Freundschaft.",
          "Vorstellungen jeden Abend um 18 und 20.30 Uhr.",
          "Hamburg",
          "Operettenhaus Hamburg",
          "Spielbudenplatz 1",
          "D-20369 Hamburg"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Durch das Watt Es gibt eine Steigerung zum \"normalen\" Strandspaziergang: die Wattwanderung. An der Nordseefinden Sie die größte zusammenhängende Wattlandschaft der Welt. Hier gibt es viel zu entdecken: gleich drei Nationalparks im Wattenmeer mit faszinierenden Landschaften und Tausenden von Tierarten. Ein Li Höhepunkt sind bestimmt die Seehundbänke im Nationalpark Hamburgisches Wattenmeer. Eine Li weitere Spezialität für fortgeschrittene Wattfans sind die Halligen, kleine Reste ehemals großer ! Marschinseln, die während der winterlichen Sturmfluten mehrmals \"landunter\" gehen."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "‚Achtung, Kamera läuft!",
          "Und Action! Besucher des Movie Park Deutschland sollten sich nicht wundern, wenn sie sich plötzlich an einem Set befinden und den Anweisungen des Regisseurs folgen oder spektakuläre Stunts hautnah erleben. In Bottrop, mitten im Ruhrgebiet, dreht sich alles um Filme mit viel Action und Spannung Gehen auch Sie den Geheimnissen des Bermuda-Dreiecks auf den Grund, wagen Sie selbst eine aufregende Verfolgung im Flugsimulator oder testen Sie Ihre Nerven auf einer der größten Achterbahnen Deutschlands! Aus Sicherheitsgründen Zutritt nur für Erwachsene"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Wiesbaden - internationaler Treffpunkt \"Gesundheit\"",
          "Das Mineralheilbad Wiesbaden liegt in einer milden, gemäßigten Klimazone. Bereits 1836 wurde hier die erste \"Orthopädische Heilanstalt\" eröffnet. Die Kurstadt mit ihrem historischen Charme ist unter anderem für ihre natriumchloridhaltigen Thermalquellen berümtt, die für vielfältige Kuren genutzt werden. In erster Linie werden sie bei rheumatischen Erkrankungen und Katarrhen der Atmungsorgane, aber auch bei Erkrankungen des Nervensystems und psychosomatischen Leiden eingesetzt."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Spiel und Spaß am Bodensee Auf die Plätze - die kleinen grauen Zellen anknipsen - und los geht's auf eine Erlebnisreise durch das Ravensburger Spieleland. In dem Freizeitpark am Bodensee spielt die ganze Familie mit, pumpt beim ! Feuerwehrspiel um die Wette, fitzt mit dem Fix & Foxi-Raketenblitz und sagt Käpt'n Blaubär \"Guten Tag\". Bekannte Ravensburger Brettspiele wie das Verrückte Labyrinth sind riesengroß. Und wo sonst kann man Memory-Kärtchen vom Hubschrauber aus bedienen? Das geht nur im Freitzeitpark Ravensburger Spieleland. Mitten in der schönsten Natur und ganz in der Nähe des Bodensees warten50 Attraktionen auf 25 Hektar darauf, entdeckt zu werden. f"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Bad Elster - heilendes Wasser aus sprudelnden Quellen In Bad Elster sprudeln gleich drei Trinkquellen unterschiedlicher Zusammensetzung und Heilwirkung. Das Herzstück einer Trink- und Badekur sind die Moritz- und die Marienquelle, die sich in der Nähe des Badeplatzes befinden. Bereits 1669 wurde den Quellen eine heilende Kraft bestätigt: Mineral- und Sprudelbäder beugen Herz- und Kreislauferkrankungen vor, Naturmoorbäder und Packungen helfen gegen Rheuma, Arthritis, bei Frauenleiden, dem Ausheilen von Sport- und Unfallverletzungen sowie bei der operativen Nachsorge und Reha-Maßnahmen. Und Trinkkuren unterstützen die Heilung bei Stoffwechsel-, Nieren- und Harnwegserkrankungen."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Ein besonderer Weihnachtsmarkt",
          "Willkommen auf dem Striezelmarkt, dem ältesten Weihnachtsmarkt Deutschlands. Gegründet 1434, verdankt er seinen Namen dem Hefestriezel, längst berühmt als Original Dresdner Christstollen. Alljährlich ist ihm zum Stollenfest, am Samstag vor dem 2. Advent, ein riesiger Festumzug gewidmet. Bestaunen Sie im Mittelpunkt des Marktes die mit 14 Metern höchste Weihnachtspyramide der Welt. Traditionelle Handwerksarbeiten vom Feinsten aus Dresden und Umgebung wie Pyramiden, Räuchermänner, Schwibbögen, Töpferwaren und Herrenhuter Adventssterne werden auch Sie verzaubern."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Bad Homburg - in einzigartiger Badekultur entspannen wie Könige & In Bad Homburg steht das heilsame und wohltuende Thermalwasser von höchster Qualität als heilendes Element im Vordergrund. Es enthält für den Körper wichtige Mineralstoffe. Gleich sechs kalte, kohlensäurehaltige Kochsalzquellen, ein Solesprudel und zwei Stahlquellen werden für Trinkkuren und & Mineralbäder verwendet. Man erlebt aktive Entspannung mit Gesundheits-, Fitness- und Sportprogramm. Individuelle Therapien und Verfahren helfen bei Bewältigung von Stressproblemen. Moderne medizinische und therapeutische Erkenntnisse haben das Kurangebot Bad Homburgs in den letzten hundert Jahren wesentlich beeinflusst."
        ]
      }
    ]
  },
  {
    "id": "8",
    "title": "Wohnen, Reisen und Rechtsberatung",
    "sourcePage": 232,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "k",
        "stem": "Einem Bekannten wurde die Arbeitsstelle gekündigt. Er möchte bei einem Anwalt um Rat fragen."
      },
      {
        "num": 12,
        "answer": "e",
        "stem": "Ihr Bekannter ist beruflich oft unterwegs und sucht eine Alternative zu Hotels. Es soll dort aber Internetzugang und Frühstück geben."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Sie reisen gerne und oft und möchten nun Informationen zu einer Reiseversicherung."
      },
      {
        "num": 14,
        "answer": "a",
        "stem": "Sie möchten durch Europa reisen und privat übernachten."
      },
      {
        "num": 15,
        "answer": "c",
        "stem": "Eine Bekannte malt sehr gut und sucht eine Gelegenheit, anderen ihre Bilder zu zeigen oder sie zu verkaufen."
      },
      {
        "num": 16,
        "answer": "h",
        "stem": "Sie möchten im Urlaub zwar nicht verreisen, aber trotzdem etwas unternehmen."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Sie haben Streit mit ihrem Vermieter wegen der Nebenkosten und möchten sich beraten lassen."
      },
      {
        "num": 18,
        "answer": "j",
        "stem": "Sie möchten ausprobieren, ob Ihnen Zeichnen Spaß macht."
      },
      {
        "num": 19,
        "answer": "b",
        "stem": "Ihre Möbel sehen nicht mehr so gut aus. Daran möchten Sie etwas ändern."
      },
      {
        "num": 20,
        "answer": "g",
        "stem": "Sie möchten mit Freunden durch Deutschland reisen und dabei günstig übernachten."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Urlaub auf dem Sofa Im Urlaub zu Hause bleiben und sich auf dem Sofa ausruhen? Das fanden wir zu langweilig! Sofa ja, aber nicht das eigene - so lässt sich unsere Urlaubsidee zusammenfassen. Wenn Sie durch Deutschland, Frankreich, England oder andere europäische Länder reisen und dabei nicht nur Hotelzimmer, sondern ganz normale Leute kennenlernen wollen, dann buchen Sie jetztbei uns. In unserer Datenbank bieten Menschen aus ganz Europa einen Schlafplatz füreine Person in ihrer Wohnung an - manchmal ein Zimmer, manchmal ein Sofa. Gegen eine geringe Gebühr kann man dort übernachten und das Frühstück ist auch mit dabei. So lernen Sie Länder, Städte, Menschen mal von einer ganz anderen Seite kennen! Infos und Buchung unter www.schlafplätzeineuropa.eu"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Alte Möbel aufarbeiten Viele Menschen hängen an ihren alten Möbeln und möchten sie nicht gegen andere tauschen, obwohl sie die besten Tage schon hinter sich haben. Wir bieten Ihnen für wenig Geld die Restauration Ihrer Möbel an. Mit einer anderen Farbe wirken viele Stücke wieder wie neu! Und",
          "falls ein Anstrich nicht reicht, zeigt Ihnen unsere Werkstatt, was noch möglich ist: z.B. neue Türen an Schränken oder neue Bezüge für ihre Sessel und Sofas. Wir kommen gern zu Ihnen",
          "nach Hauıca ıınd marhan Ihnan ain Irnetanincac Anmahnt! unınu erhrainar da"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Kunstmarkt In unseren Ausstellungsräumen am Plantanenhof bieten wir an jedem ersten Samstag im Monat jungen Künstlerinnen und Künstlern die Möglichkeit, sich und einige ihrer Werke vorzustellen. Wenn Sie an einer Ausstellung interessiert sind, melden Sie sich bitte spätestens sechs Wochen vor dem gewünschten Termin bei uns an. Aber auch Besucher sind herzlich willkommen! Gegen einen geringen Eintritt erwartet Sie nicht nur neue Kunst, auch Kaffee und Tee werden serviert und natürlich haben Sie auch die Gelegenheit, ein Werk gleich zu kaufen und mitzunehmen. Weitere Informationen und Anmeldung unter: www.galeria.de"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Die eigene Wohnung",
          "Für viele ist die eigene Wohnung ein Traum - aber es gibt auch Fragen und Probleme. Wir bieten extra für alle, die zum ersten Mal die eigenen vier Wände beziehen, Infoabende an, in denen sie alles Wichtige zur Haushaltsführung erfahren: Wir bewahrt man Lebensmittel richtig auf? Wie viele Vorräte braucht man? Wie putzt man richtig und welches Mittel ist am besten geeignet? Wie spart man Strom und Heizkosten? Erfahren Sie alles, was wichtig ist, von Omas Spar-Rezepte bis hin zumoderner Küchentechnik. Die Teilnahme ist kostenlos, um Anmeldung wird aber gebeten. AWO Kirchhellen,",
          "Tel. 0800 / 61619012"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Unser neues Wohnkonzept |; Unser Angebot: 1-Zimmerwohnungen mit kompletter Ausstattung, auch Telefon und Internet, außerdem 1 morgens kostenlose Tageszeitung nach Wunsch sowie ein komplettes Frühstück. Alle Wohnungen verfügen über großzügige Arbeitsplätze sowie Drucker, Fax etc. In über 25 Städten buchbar. Außerdem 2 auf Wunsch persönlicher Service (Kurierdienst, Abholung vom Bahnhof/Flughafen etc.). Wir gestalten Ihre Geschäftsreise so angenehm wie möglich - für alle, denen Hotels zu unpersönlich sind. % Informationen unter: www.wohnkonzept.de ‘"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Ihr gutes Recht Wenn es um Rechtsfragen geht, kann es schnell teuer werden. Anwalt- und vielleicht auch h Gerichtskosten werden fällig - von den Nerven, die man verliert, ganz zu schweigen. Wir bieten eine günstige und zuverlässige alternative in allen Fragen rund um das Mietrecht: Ihre Miete wurde erhöht f oder ihr Vermieter repariert Schäden in der Wohnung nicht? Oder haben Sie eine Kündigung von Ihrem f Vermieter erhalten, obwohl Sie immer pünktlich die Miete überwiesen haben und auch sonst alles in Y Ordnung war? Dann vereinbaren Sie einen kostenlosen Beratungstermin bei uns! Wenn wir Sie von Ä unserem Angebot überzeugt haben, können Sie anschließend Mitglied in unserem Verein werden - für nur 75,00 Euro pro Jahr! Mieterschutzbund Brandenburg. f"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Günstig wohnen in über 70 Städten in Deutschland",
          "Wir bieten Ihnen die preiswerte Alternative zum teuren Hotelzimmer: erleben Sie Deutschland und wohnen Sie in über ?0 Städten von Flensburg bis Konstanz in einer unserer neuen Pensionen. Wir bieten gemütliche Mehrbettzimmer, einige auch mit Bad. Unsere Häuser sind jeweils zentral gelegen und somit gut zu erreichen. Wir bieten Ihnen zwar keine Mahlzeiten an, aber fast überall in der Nähe unserer Pensionen finden Sie kleine Cafes. Ideal für alle, die günstig reisen möchten! Weitere Informationen und Buchung unter www.pensionen.de"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Zuhause bleiben und trotzdem was erleben Urlaub zu Hause - für viele das schönste Urlaubserlebnis! Wir haben Tipps, wie Sie Ihren Urlaub noch schöner machen können: Veranstaltungstipps (Konzerte, Theater, ...), Kurse (Kochkurse, Singen, Musikinstrumente, ...), Sport und Ausflugtipps für Ihre Region. Ob allein, zu zweit oder mit der ganzen Familie - bei uns finden Sie das Passende! Registrieren Sie sich jetzt und Sie können auswählen, welche Tipps wir Ihnen zuschicken sollen. Natürlich kostenlos! Infos und Registrierung unter www.urlaubzuhause.info"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Guter Ratistnichtteuer Probleme mit Arbeitgeber oder Vermieter? Hatten Sie einen Unfall und niemand will die Kosten für Ihren Krankenhausaufenthalt zahlen? In solchen Fragen ist es gut, wenn man einen Anwalt an seiner Seite hat ! - und ihn auch bezahlen kann. Schließen Sie deshalb unsere kostengünstige Rechtsschutzversicherung |: ab. Wir zahlen den Anwalt und die Gerichtskosten - je nach Tarif komplett oder zum Teil. Informieren Sie sich auch über unsere günstige Familientarife! Rufen Sie an: Thüringer Versicherungen, Tel. 08074 f 55339. Wichtig: Sie können die Leistungen erst 6 Monate nach Vertragsabschluss in Anspruch nehmen!"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Kunst und Kultur für Einsteiger Nicht nur im Urlaub möchten viele Menschen in der Freizeit Neues ausprobieren. Wir bieten Schnupperkurse zu verschiedenen Freizeitaktivitäten an: Malen war schon immer Ihre Leidenschaft? Sie wollten schon lange probieren, welches Instrument zu Ihnen passt? Dann besuchen Sie einfach unsere Schnupperkurse \"Kurs und Kultur für Einsteiger”! Nur 60 Minuten pro Kurs, danach können Sie entscheiden, ob sie einen anderen Kurs ausprobieren möchten oder sich gleich für einen “richtigen” Kurs anmelden wollen. Malerei, Musik, Literatur, Geschichte stehen auf dem Programm. Informieren Sie sich jetzt: Kunst Schule Heckmann, Tel. 0800 444509434 a er m en a u nn ar u a u u"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Ihr kompetenter Partner für Rechtsberatung seit über 20 Jahren",
          "Ihre kompetente Rechtsberatung in ganz Deutschland! Unsere Anwälte vertreten Ihre Interessen zügig und zuverlässig im Bereich ‘Arbeit. Vom Arbeitsvertrag über Probleme am Arbeitsplatz bis hin zu Kündigungen oder auch Problemen bei der Zahlung des Arbeitslosengeldes unterstützen wir Sie sowohl vor Gericht als auch außerhalb. Unsere Erfahrung ist ihr Vorteil. Natürlich ist eine Abrechnung über Ihre Rechtschutzversicherung möglich, sprechen Sie uns einfach an und vereinbaren Sie einen Beratungstermin! Kanzlei Hummel und Schröder, Torstraße 211, 80121 München, Tel. 089 1234567."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Immer das richtige Möbel - ob Büro oder Wohnzimmer Egal, ob sie beruflich oft unterwegs sind oder viel Wert auf ein gemütliches zu Hause legen: Sie wissen. dass es bei Möbeln und weiterer Ausstattung auf die Details ankommt. Wir bieten für jeden Bedarf das Richtige an: Schreibtische mit integrierten Kabel für Telefon- oder Internetverbindungen, Sofas mit praktischer Bettfunktion und farblich passenden Leuchten. Wir bieten auch gebrauchte Möbel günstig an, natürlich nur in bestem Zustand. Schauen Sie sich unsere Ausstellung an! & Möbel Weber GmbH, Am Langen Hahn 24, 42188 Dortmund. 8"
        ]
      }
    ]
  },
  {
    "id": "8a",
    "title": "Wohnen, Reisen und Rechtsberatung",
    "sourcePage": 235,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "k",
        "stem": "Einem Bekannten wurde die Arbeitsstelle gekündigt. Er möchte bei einem Anwalt um Rat fragen."
      },
      {
        "num": 12,
        "answer": "e",
        "stem": "Ihr Bekannter ist beruflich oft unterwegs und sucht eine Alternative zu Hotels. Es soll dort aber Internetzugang und Frühstück geben."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Sie reisen gerne und oft und möchten nun Informationen zu einer Reiseversicherung."
      },
      {
        "num": 14,
        "answer": "a",
        "stem": "Sie möchten durch Europa reisen und privat übernachten."
      },
      {
        "num": 15,
        "answer": "c",
        "stem": "Eine Bekannte malt sehr gut und sucht eine Gelegenheit, anderen ihre Bilder zu zeigen oder sie zu verkaufen."
      },
      {
        "num": 16,
        "answer": "h",
        "stem": "Sie möchten im Urlaub zwar nicht verreisen, aber trotzdem etwas unternehmen."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Sie haben Streit mit ihrem Vermieter wegen der Nebenkosten und möchten sich beraten lassen."
      },
      {
        "num": 18,
        "answer": "j",
        "stem": "Sie möchten ausprobieren, ob Ihnen Zeichnen Spaß macht."
      },
      {
        "num": 19,
        "answer": "b",
        "stem": "Ihre Möbel sehen nicht mehr so gut aus. Daran möchten Sie etwas ändern."
      },
      {
        "num": 20,
        "answer": "g",
        "stem": "Sie möchten mit Freunden durch Deutschland reisen und dabei günstig übernachten."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Urlaub auf dem Sofa Im Urlaub zu Hause bleiben und sich auf dem Sofa ausruhen? Das fanden wir zu langweilig! Sofa ja, aber nicht das eigene - so lässt sich unsere Urlaubsidee zusammenfassen. Wenn Sie durch Deutschland, Frankreich, England oder andere europäische Länder reisen und dabei nicht nur Hotelzimmer, sondern ganz normale Leute kennenlernen wollen, dann buchen Sie jetztbei uns. In unserer Datenbank bieten Menschen aus ganz Europa einen Schlafplatz füreine Person in ihrer Wohnung an - manchmal ein Zimmer, manchmal ein Sofa. Gegen eine geringe Gebühr kann man dort übernachten und das Frühstück ist auch mit dabei. So lernen Sie Länder, Städte, Menschen mal von einer ganz anderen Seite kennen! Infos und Buchung unter www.schlafplätzeineuropa.eu"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Alte Möbel aufarbeiten Viele Menschen hängen an ihren alten Möbeln und möchten sie nicht gegen andere tauschen, obwohl sie die besten Tage schon hinter sich haben. Wir bieten Ihnen für wenig Geld die Restauration Ihrer Möbel an. Mit einer anderen Farbe wirken viele Stücke wieder wie neu! Und",
          "falls ein Anstrich nicht reicht, zeigt Ihnen unsere Werkstatt, was noch möglich ist: z.B. neue Türen an Schränken oder neue Bezüge für ihre Sessel und Sofas. Wir kommen gern zu Ihnen",
          "nach Hauıca ıınd marhan Ihnan ain Irnetanincac Anmahnt! unınu erhrainar da"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "EN © X Kunstmarkt In unseren Ausstellungsräumen am Plantanenhof bieten wir an jedem ersten Samstag im Monat jungen Künstlerinnen und Künstlern die Möglichkeit, sich und einige ihrer Werke vorzustellen. Wenn Sie an einer Ausstellung interessiert sind, melden Sie sich bitte spätestens sechs Wochen vor dem gewünschten Termin bei uns an. Aber auch Besucher sind herzlich willkommen! Gegen einen geringen Eintritt erwartet Sie nicht nur neue Kunst, auch Kaffee und Tee werden serviert und natürlich haben Sie auch die Gelegenheit, ein Werk gleich zu kaufen und mitzunehmen. Weitere Informationen und Anmeldung unter: www.galeria.de"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Die eigene Wohnung",
          "Für viele ist die eigene Wohnung ein Traum - aber es gibt auch Fragen und Probleme. Wir bieten extra für alle, die zum ersten Mal die eigenen vier Wände beziehen, Infoabende an, in denen sie alles Wichtige zur Haushaltsführung erfahren: Wir bewahrt man Lebensmittel richtig auf? Wie viele Vorräte braucht man? Wie putzt man richtig und welches Mittel ist am besten geeignet? Wie spart man Strom und Heizkosten? Erfahren Sie alles, was wichtig ist, von Omas Spar-Rezepte bis hin zumoderner Küchentechnik. Die Teilnahme ist kostenlos, um Anmeldung wird aber gebeten. AWO Kirchhellen,",
          "Tel. 0800 / 61619012"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Unser neues Wohnkonzept |; Unser Angebot: 1-Zimmerwohnungen mit kompletter Ausstattung, auch Telefon und Internet, außerdem 1 morgens kostenlose Tageszeitung nach Wunsch sowie ein komplettes Frühstück. Alle Wohnungen verfügen über großzügige Arbeitsplätze sowie Drucker, Fax etc. In über 25 Städten buchbar. Außerdem 2 auf Wunsch persönlicher Service (Kurierdienst, Abholung vom Bahnhof/Flughafen etc.). Wir gestalten Ihre Geschäftsreise so angenehm wie möglich - für alle, denen Hotels zu unpersönlich sind. % Informationen unter: www.wohnkonzept.de ‘"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Ihr gutes Recht Wenn es um Rechtsfragen geht, kann es schnell teuer werden. Anwalt- und vielleicht auch h Gerichtskosten werden fällig - von den Nerven, die man verliert, ganz zu schweigen. Wir bieten eine günstige und zuverlässige alternative in allen Fragen rund um das Mietrecht: Ihre Miete wurde erhöht f oder ihr Vermieter repariert Schäden in der Wohnung nicht? Oder haben Sie eine Kündigung von Ihrem f Vermieter erhalten, obwohl Sie immer pünktlich die Miete überwiesen haben und auch sonst alles in Y Ordnung war? Dann vereinbaren Sie einen kostenlosen Beratungstermin bei uns! Wenn wir Sie von Ä unserem Angebot überzeugt haben, können Sie anschließend Mitglied in unserem Verein werden - für nur 75,00 Euro pro Jahr! Mieterschutzbund Brandenburg. f"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Günstig wohnen in über 70 Städten in Deutschland",
          "Wir bieten Ihnen die preiswerte Alternative zum teuren Hotelzimmer: erleben Sie Deutschland und wohnen Sie in über ?0 Städten von Flensburg bis Konstanz in einer unserer neuen Pensionen. Wir bieten gemütliche Mehrbettzimmer, einige auch mit Bad. Unsere Häuser sind jeweils zentral gelegen und somit gut zu erreichen. Wir bieten Ihnen zwar keine Mahlzeiten an, aber fast überall in der Nähe unserer Pensionen finden Sie kleine Cafes. Ideal für alle, die günstig reisen möchten! Weitere Informationen und Buchung unter www.pensionen.de"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "we Zuhause bleiben und trotzdem was erleben Urlaub zu Hause - für viele das schönste Urlaubserlebnis! Wir haben Tipps, wie Sie Ihren Urlaub noch schöner machen können: Veranstaltungstipps (Konzerte, Theater, ...), Kurse (Kochkurse, Singen, Musikinstrumente, ...), Sport und Ausflugtipps für Ihre Region. Ob allein, zu zweit oder mit der ganzen Familie - bei uns finden Sie das Passende! Registrieren Sie sich jetzt und Sie können auswählen, welche Tipps wir Ihnen zuschicken sollen. Natürlich kostenlos! Infos und Registrierung unter www.urlaubzuhause.info"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Guter Ratistnichtteuer Probleme mit Arbeitgeber oder Vermieter? Hatten Sie einen Unfall und niemand will die Kosten für Ihren Krankenhausaufenthalt zahlen? In solchen Fragen ist es gut, wenn man einen Anwalt an seiner Seite hat ! - und ihn auch bezahlen kann. Schließen Sie deshalb unsere kostengünstige Rechtsschutzversicherung |: ab. Wir zahlen den Anwalt und die Gerichtskosten - je nach Tarif komplett oder zum Teil. Informieren Sie sich auch über unsere günstige Familientarife! Rufen Sie an: Thüringer Versicherungen, Tel. 08074 f 55339. Wichtig: Sie können die Leistungen erst 6 Monate nach Vertragsabschluss in Anspruch nehmen!"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Kunst und Kultur für Einsteiger Nicht nur im Urlaub möchten viele Menschen in der Freizeit Neues ausprobieren. Wir bieten Schnupperkurse zu verschiedenen Freizeitaktivitäten an: Malen war schon immer Ihre Leidenschaft? Sie wollten schon lange probieren, welches Instrument zu Ihnen passt? Dann besuchen Sie einfach unsere Schnupperkurse \"Kurs und Kultur für Einsteiger”! Nur 60 Minuten pro Kurs, danach können Sie entscheiden, ob sie einen anderen Kurs ausprobieren möchten oder sich gleich für einen “richtigen” Kurs anmelden wollen. Malerei, Musik, Literatur, Geschichte stehen auf dem Programm. Informieren Sie sich jetzt: Kunst Schule Heckmann, Tel. 0800 444509434 a er m en a u nn ar u a u u"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Ihr kompetenter Partner für Rechtsberatung seit über 20 Jahren",
          "Ihre kompetente Rechtsberatung in ganz Deutschland! Unsere Anwälte vertreten Ihre Interessen zügig und zuverlässig im Bereich ‘Arbeit. Vom Arbeitsvertrag über Probleme am Arbeitsplatz bis hin zu Kündigungen oder auch Problemen bei der Zahlung des Arbeitslosengeldes unterstützen wir Sie sowohl vor Gericht als auch außerhalb. Unsere Erfahrung ist ihr Vorteil. Natürlich ist eine Abrechnung über Ihre Rechtschutzversicherung möglich, sprechen Sie uns einfach an und vereinbaren Sie einen Beratungstermin! Kanzlei Hummel und Schröder, Torstraße 211, 80121 München, Tel. 089 1234567."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Immer das richtige Möbel - ob Büro oder Wohnzimmer Egal, ob sie beruflich oft unterwegs sind oder viel Wert auf ein gemütliches zu Hause legen: Sie wissen. dass es bei Möbeln und weiterer Ausstattung auf die Details ankommt. Wir bieten für jeden Bedarf das Richtige an: Schreibtische mit integrierten Kabel für Telefon- oder Internetverbindungen, Sofas mit praktischer Bettfunktion und farblich passenden Leuchten. Wir bieten auch gebrauchte Möbel günstig an, natürlich nur in bestem Zustand. Schauen Sie sich unsere Ausstellung an! & Möbel Weber GmbH, Am Langen Hahn 24, 42188 Dortmund. 8"
        ]
      }
    ]
  },
  {
    "id": "9",
    "title": "Musik, Instrumente und Veranstaltungen",
    "sourcePage": 238,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "l",
        "stem": "Ein Bekannter spielt Gitarre und möchte ein weiteres Instrument lernen."
      },
      {
        "num": 12,
        "answer": "c",
        "stem": "Ein Kollege möchte mit fünf Freunden eine mehrtägige Musikveranstaltung besuchen."
      },
      {
        "num": 13,
        "answer": "b",
        "stem": "Ein Bekannter hat bei der Messe Frankfurt gearbeitet und sucht eine andere Stelle in diesem Bereich."
      },
      {
        "num": 14,
        "answer": "e",
        "stem": "Sie möchten einer Freundin Eintrittskarten für eine Musikveranstaltung schenken."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Sie interessieren sich für Bücher und möchten eine Messe besuchen."
      },
      {
        "num": 16,
        "answer": "i",
        "stem": "Die sechsjährige Tochter eines Nachbarn würde gerne mit andere Kindern Musik machen."
      },
      {
        "num": 17,
        "answer": "g",
        "stem": "Ein Bekannter muss eine Jubiläumsfeier organisieren und sucht Unterstützung."
      },
      {
        "num": 18,
        "answer": "d",
        "stem": "Sie mögen Musik und möchten in dem Bereich einen Job."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Ihre Nachbarin möchte ihre Violine verkaufen."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Eine Bekannte ist Musikerin und sucht Möglichkeiten, mit ihrer Gruppe aufzutreten."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Sport, Theater & mehr... ..bieten wir ihnen in unserem Online-Kartenshop. Wir sind spezialisiert auf Tickets für Sportveranstaltungen in Deutschland, Theaterkarten (auch im europäischen Ausland) und bieten Ihnen darüber hinaus auch Eintrittskarten zu bekannten Fernseh-Talkshows an. Sicher haben wir auch für Sie Ä das passende Angebot. Wahlen Sie Ihre Wunschplätze einfach im Internet aus und nur zwei Tagespäter |! erhalten Sie Ihre Karten mit der Post. Bequem, sicher, schnell. Selbstverständlich bieten wir Ihnen aber auch eine persönliche Beratung unter einer kostenfreien Rufnummer an. Schauen Sie doch gleich online vorbeil www.ticketprofis.eu"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Veranstaltungsprofis",
          "Seit mehr als zwanzig Jahren organisieren wir Messen (Buchmessen, Verbrauchermessen, Fahrradmessen, Automessen, Spielemessen) in ganz Europa. Wenn auch Sie sich für eine Tätigkeit im Bereich Messeorganisation und -durchführung interessieren, haben wir ein interessantes Angebot für Sie: Ab Herbst suchen wir für unser Junges motiviertes Team Verstärkung. Wenn Sie eine abgeschlossene Ausbildung",
          "im Veranstaltungs- oder Logistiksektor haben, neben Ihrer Muttersprache noch mindestens eine weitere Sprache fließend beherrschen und reisefreudig sind, melden Sie sich bei uns! Weitere Informationen finden Sie auch auf unserer Website oder sprechen Sie unsere zuständige Mitarbeiterin, Frau Klimke, direkt an.",
          "www.die-veranstaltungsprofis.eu",
          "klimke@die-veranstaltungsprofis.eu"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "SS EEE.",
          "Gemeinsam mehr erleben",
          "Gruppenreisen bieten wir Ihnen bereits ab fünf Personen an - Städtereisen. Wellnesswochenenden und",
          "neu im Angebot auch Reisen zu kulturellen Veranstaltungen. Fahren Sie mit uns zum Beispiel Ende",
          "August zum Jazzfestival in Brandenburg (25.-29.8.) oder im darauffolgenden Monat zur Klassikwoche",
          "nach Wien. Von Anreise und Hotel (verschiedene Kategorien) bis hin zur Eintrittskarte organisieren wir",
          "für Sie alles. Genießen Sie entspannte Tage mit Werner Reisen GmbH.",
          "Weitere Informationen und auch Buchungsformulare finden Sie unter www.wernerreisen.eu. Oder rufen",
          "Sie uns an: 0800/9900100 [rm äs"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Musikfestival Taubertal: 24. Juli bis 3. August",
          "Auch in diesem Jahr kommen wieder viele bekannte Bands und interessante neue Künstler. Das Festival ist schon längst ausverkauft, aber ihr könnt trotzdem noch hinkommen: Wir suchen noch Unterstützung für den Aufbau der Stände, die Betreuung der Musiker und auch für die Ticketkontrolle. Bewerbt euch einfach per E-Mail. Wichtig: Wenn ihr beim Festival arbeitet, könnt ihr zwar auch Musik hören, aber ihr habt keine Gelegenheit, euch die Auftritte in Ruhe anzusehen. Trotzdem macht die Arbeit viel Spaß, und ihr könnt die Musiker sogar hinter der Buhne sehen und kennenlernen.",
          "E-Mail: info@musikfestivaltaubertal.eu"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "‚Alle Veranstaltungen aus einer Hand Ob Jazz, Rock, Klassik, Musical: Bei uns finden Sie Veranstaltungen aus allen Musikbereichen! Reservieren Sie noch heute Karten für Ihre Lieblingsband, wählen Sie Ihren Platz online und drucken Sie Ihre Tickets sofort selbst aus. Oder kaufen Sie Geschenkgutscheine, die man ebenfalls bequem online Fi einlösen kann: die ideale Möglichkeit für alle, die noch keine bestimmte Veranstaltung ausgesucht haben. Besuchen Sie gleich unseren Online-Shop. Bestellungen sind bei uns übrigens auch ohne Registrierung 1 möglich! www.die-veranstaltungsspezialisten.eu 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Malländer Scala, Deutsche Oper Berlin und vieles mehr Der etwas andere Zugang zur Musik: Wir organisieren Besichtigungen von bekannten Opernhäusern ! oder Konzertsälen. Schauen Sie sich die Technik und Räume vor Ort an, nehmen Sie an einer L interessanten Führung teil und lernen Sie so die Geschichte der Häuser und auch der Orchester kennen. h Gerne organisieren wir nach Möglichkeit auch Treffen mit Musikern oder Konzertdirektoren, mit denen Sie spannende Gespräche führen und mehr über deren Arbeit erfahren können. Bitte haben Sie 1 Verständnis, dass wir diese Treffen erst ab zehn Teilnehmern organisieren können. Weitere 1 Informationen: f} Musikreisen Gerhardt, Tel 0800/223 997 880"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Feste felern?",
          "Wir organisieren Veranstaltungen in verschiedenen Größenordnungen - von der kleinen Familienfeier mit zehn Personen bis hin zu großen Firmenveranstaltungen mit mehreren Hundert Teilnehmern. Lehnen Sie sich zurück und wir machen die Arbeit! Alternativ bieten wir Ihnen aber auch unsere kompetente Beratung an, damit Sie Ihre Veranstaltung selbst planen können. Unsere Mitarbeiter kommen dann gerne zu Ihnen oder stehen Ihnen telefonisch und per E-Mail zur Verfügung. Sprechen Sie uns an!",
          "TMC GmbH, info@tmcgmbh.eu"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "N Künstleragentur Lippmann Bei der Künstleragentur Lippmann sind über 100 Künstler registriert, die Sie für Veranstaltungen buchen können. Sie suchen einen Komiker? Kein Problem! Sie möchten auf Ihrer Veranstaltung Schauspieler auftreten lassen? Wir können sie vermitteln! Sie brauchen musikalische Untermalung? Bei uns sind einzelne Musiker ebenso registriert wie Bands. Melden Sie sich noch heute kostenlos und unverbindlich an und schauen Sie in Ruhe alle Angebote durch - einschließlich der Preise und freien Termine. Sicher finden Sie bei uns, was Sie suchen. www.agentur-lippmann.eu"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Gitarre, Violine & Co. ! Im Musikverein Wohlklang lernen schon die ganz Kleinen den spielerischen Umgang mit Instrumenten. Aber auch für die ‚größeren Kleinen” bieten wir Musikförderung und auch individuellen Unterricht an. In verschiedenen Gruppen (Alter von zwei bis acht Jahren) können Ihre Kinder bei uns Instrumente lernen, singen oder tanzen, kurz: Spaß mit Musik haben und auch selbst das Musizieren lernen. Die ersten beiden Probestunden bieten wir Ihnen kostenlos an, damit Sie und Ihre Kinder uns in Ruhe kennenlernen können. Vereinbaren Sie doch gleich einen Termin unter der 0800/5615 6514. Wohlklang e.V., Neue Straße 218, 77933 Lahr"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Instrumente, Noten, Musikbücher",
          "Das Musikhaus Hohenzollern hat jetzt wieder besondere Angebote für alle Interessierten. Wir haben die Preise von allen Instrumenten bis kommenden Samstag reduziert. Auch zahlreiche Bücher und Notenhefte finden Sie ab sofort in unserem neuen Online-Shop zu günstigen Preisen. Unser Einstiegsangebot: alle Bestellungen im Online-Shop ohne Versandkosten! Schauen Sie sich doch mal im Internet um oder kommen Sie direkt bei uns vorbei. Wir freuen uns auf ihren Besuch!",
          "Musikhaus Hohenzollern, Steeler Str. 789, 45276 Essen",
          "www.musikhaus-hohenzollern.eu"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Rhein/Ruhr-Festival",
          "Im kommenden Herbst findet zum ersten Mal das neue Rhein/Ruhr-Festival statt - und wir benötigen noch Hilfe. Im Rahmen des Festivals werden auf fünf unterschiedlichen Bühnen Künstler auftreten. Wir möchten verschiedene Stilrichtungen präsentieren, Solokünstler ebenso wie größere Musikgruppen. Und noch sind Plätze frei! Die Chance also für alle, die sich gerne bei unserem Festival präsentieren möchten. Kurzbewerbungen können ab sofort per E-Mail an office@rheinruhrfestival.eu gesendet werden.",
          "Bitte schicken Sie keine größeren Dateianhänge! Vielen Dank"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Musiker gesucht & Seit einem Jahr vermitteln wir „Musiktandems“ - Musiker suchen Musiker und geben sich gegenseitig Unterricht. Ob Instrument, Gesang, Komposition - alles wird gesucht! Registrieren Sie sich kostenlos auf unserer Homepage www.musiktandems.eu und finden Sie heute noch das Angebot, das Sie schon lange suchen. Wichtig: Sie können sich nur für das Musiktandem anmelden, wenn Sie selbst auch Unterricht anbieten können, also zum Beispiel ein Instrument spielen. Auf unserer Website finden Sie auch weitere Informationen zum Ablauf und können den Service kontaktieren. &"
        ]
      }
    ]
  },
  {
    "id": "9a",
    "title": "Musik, Instrumente und Veranstaltungen",
    "sourcePage": 241,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "l",
        "stem": "Ein Bekannter 55 Alter spielt Gitarre und möchte ein weiteres Instrument lernen."
      },
      {
        "num": 12,
        "answer": "c",
        "stem": "Ein Kollege möchte mit sechs Freunden eine mehrtägige Musikveranstaltung besuchen."
      },
      {
        "num": 13,
        "answer": "b",
        "stem": "Ein Bekannter hat bei der Veranstaltung Frankfurt gearbeitet und sucht eine andere Stelle in diesem Bereich."
      },
      {
        "num": 14,
        "answer": "e",
        "stem": "Sie möchten einer Freundin Eintrittskarten für eine Musikveranstaltung schenken."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Sie interessieren sich für Bücher und möchten eine Messe besuchen."
      },
      {
        "num": 16,
        "answer": "i",
        "stem": "Die sechsjährige Tochter eines Nachbarn würde gerne mit andere Kindern Musik machen."
      },
      {
        "num": 17,
        "answer": "g",
        "stem": "Ein Bekannter muss eine Jubiläumsfeier organisieren und sucht Unterstützung."
      },
      {
        "num": 18,
        "answer": "d",
        "stem": "Sie mögen Musik und möchten in dem Bereich einen Job."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Ihre Nachbarin möchte ihre Violine verkaufen."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Eine Bekannte ist Musikerin und sucht Möglichkeiten, mit ihrer Gruppe aufzutreten."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Sport, Theater & mehr... ..bieten wir ihnen in unserem Online-Kartenshop. Wir sind spezialisiert auf Tickets für Sportveranstaltungen in Deutschland, Theaterkarten (auch im europäischen Ausland) und bieten Ihnen darüber hinaus auch Eintrittskarten zu bekannten Fernseh-Talkshows an. Sicher haben wir auch für Sie Ä das passende Angebot. Wahlen Sie Ihre Wunschplätze einfach im Internet aus und nur zwei Tagespäter |! erhalten Sie Ihre Karten mit der Post. Bequem, sicher, schnell. Selbstverständlich bieten wir Ihnen aber auch eine persönliche Beratung unter einer kostenfreien Rufnummer an. Schauen Sie doch gleich online vorbeil www.ticketprofis.eu"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Veranstaltungsprofis",
          "Seit mehr als zwanzig Jahren organisieren wir Messen (Buchmessen, Verbrauchermessen, Fahrradmessen, Automessen, Spielemessen) in ganz Europa. Wenn auch Sie sich für eine Tätigkeit im Bereich Messeorganisation und -durchführung interessieren, haben wir ein interessantes Angebot für Sie: Ab Herbst suchen wir für unser Junges motiviertes Team Verstärkung. Wenn Sie eine abgeschlossene Ausbildung",
          "im Veranstaltungs- oder Logistiksektor haben, neben Ihrer Muttersprache noch mindestens eine weitere Sprache fließend beherrschen und reisefreudig sind, melden Sie sich bei uns! Weitere Informationen finden Sie auch auf unserer Website oder sprechen Sie unsere zuständige Mitarbeiterin, Frau Klimke, direkt an.",
          "www.die-veranstaltungsprofis.eu",
          "klimke@die-veranstaltungsprofis.eu"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "SS EEE.",
          "Gemeinsam mehr erleben",
          "Gruppenreisen bieten wir Ihnen bereits ab fünf Personen an - Städtereisen. Wellnesswochenenden und",
          "neu im Angebot auch Reisen zu kulturellen Veranstaltungen. Fahren Sie mit uns zum Beispiel Ende",
          "August zum Jazzfestival in Brandenburg (25.-29.8.) oder im darauffolgenden Monat zur Klassikwoche",
          "nach Wien. Von Anreise und Hotel (verschiedene Kategorien) bis hin zur Eintrittskarte organisieren wir",
          "für Sie alles. Genießen Sie entspannte Tage mit Werner Reisen GmbH.",
          "Weitere Informationen und auch Buchungsformulare finden Sie unter www.wernerreisen.eu. Oder rufen",
          "Sie uns an: 0800/9900100 [rm äs"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Musikfestival Taubertal: 24. Juli bis 3. August",
          "Auch in diesem Jahr kommen wieder viele bekannte Bands und interessante neue Künstler. Das Festival ist schon längst ausverkauft, aber ihr könnt trotzdem noch hinkommen: Wir suchen noch Unterstützung für den Aufbau der Stände, die Betreuung der Musiker und auch für die Ticketkontrolle. Bewerbt euch einfach per E-Mail. Wichtig: Wenn ihr beim Festival arbeitet, könnt ihr zwar auch Musik hören, aber ihr habt keine Gelegenheit, euch die Auftritte in Ruhe anzusehen. Trotzdem macht die Arbeit viel Spaß, und ihr könnt die Musiker sogar hinter der Buhne sehen und kennenlernen.",
          "E-Mail: info@musikfestivaltaubertal.eu"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "‚Alle Veranstaltungen aus einer Hand Ob Jazz, Rock, Klassik, Musical: Bei uns finden Sie Veranstaltungen aus allen Musikbereichen! Reservieren Sie noch heute Karten für Ihre Lieblingsband, wählen Sie Ihren Platz online und drucken Sie Ihre Tickets sofort selbst aus. Oder kaufen Sie Geschenkgutscheine, die man ebenfalls bequem online Fi einlösen kann: die ideale Möglichkeit für alle, die noch keine bestimmte Veranstaltung ausgesucht haben. Besuchen Sie gleich unseren Online-Shop. Bestellungen sind bei uns übrigens auch ohne Registrierung 1 möglich! www.die-veranstaltungsspezialisten.eu 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Malländer Scala, Deutsche Oper Berlin und vieles mehr Der etwas andere Zugang zur Musik: Wir organisieren Besichtigungen von bekannten Opernhäusern ! oder Konzertsälen. Schauen Sie sich die Technik und Räume vor Ort an, nehmen Sie an einer L interessanten Führung teil und lernen Sie so die Geschichte der Häuser und auch der Orchester kennen. h Gerne organisieren wir nach Möglichkeit auch Treffen mit Musikern oder Konzertdirektoren, mit denen Sie spannende Gespräche führen und mehr über deren Arbeit erfahren können. Bitte haben Sie 1 Verständnis, dass wir diese Treffen erst ab zehn Teilnehmern organisieren können. Weitere 1 Informationen: f} Musikreisen Gerhardt, Tel 0800/223 997 880"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Feste felern?",
          "Wir organisieren Veranstaltungen in verschiedenen Größenordnungen - von der kleinen Familienfeier mit zehn Personen bis hin zu großen Firmenveranstaltungen mit mehreren Hundert Teilnehmern. Lehnen Sie sich zurück und wir machen die Arbeit! Alternativ bieten wir Ihnen aber auch unsere kompetente Beratung an, damit Sie Ihre Veranstaltung selbst planen können. Unsere Mitarbeiter kommen dann gerne zu Ihnen oder stehen Ihnen telefonisch und per E-Mail zur Verfügung. Sprechen Sie uns an!",
          "TMC GmbH, info@tmcgmbh.eu"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "N Künstleragentur Lippmann Bei der Künstleragentur Lippmann sind über 100 Künstler registriert, die Sie für Veranstaltungen buchen können. Sie suchen einen Komiker? Kein Problem! Sie möchten auf Ihrer Veranstaltung Schauspieler auftreten lassen? Wir können sie vermitteln! Sie brauchen musikalische Untermalung? Bei uns sind einzelne Musiker ebenso registriert wie Bands. Melden Sie sich noch heute kostenlos und unverbindlich an und schauen Sie in Ruhe alle Angebote durch - einschließlich der Preise und freien Termine. Sicher finden Sie bei uns, was Sie suchen. www.agentur-lippmann.eu"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Gitarre, Violine & Co. ! Im Musikverein Wohlklang lernen schon die ganz Kleinen den spielerischen Umgang mit Instrumenten. Aber auch für die ‚größeren Kleinen” bieten wir Musikförderung und auch individuellen Unterricht an. In verschiedenen Gruppen (Alter von zwei bis acht Jahren) können Ihre Kinder bei uns Instrumente lernen, singen oder tanzen, kurz: Spaß mit Musik haben und auch selbst das Musizieren lernen. Die ersten beiden Probestunden bieten wir Ihnen kostenlos an, damit Sie und Ihre Kinder uns in Ruhe kennenlernen können. Vereinbaren Sie doch gleich einen Termin unter der 0800/5615 6514. Wohlklang e.V., Neue Straße 218, 77933 Lahr"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Instrumente, Noten, Musikbücher",
          "Das Musikhaus Hohenzollern hat jetzt wieder besondere Angebote für alle Interessierten. Wir haben die Preise von allen Instrumenten bis kommenden Samstag reduziert. Auch zahlreiche Bücher und Notenhefte finden Sie ab sofort in unserem neuen Online-Shop zu günstigen Preisen. Unser Einstiegsangebot: alle Bestellungen im Online-Shop ohne Versandkosten! Schauen Sie sich doch mal im Internet um oder kommen Sie direkt bei uns vorbei. Wir freuen uns auf ihren Besuch!",
          "Musikhaus Hohenzollern, Steeler Str. 789, 45276 Essen",
          "www.musikhaus-hohenzollern.eu"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Rhein/Ruhr-Festival",
          "Im kommenden Herbst findet zum ersten Mal das neue Rhein/Ruhr-Festival statt - und wir benötigen noch Hilfe. Im Rahmen des Festivals werden auf fünf unterschiedlichen Bühnen Künstler auftreten. Wir möchten verschiedene Stilrichtungen präsentieren, Solokünstler ebenso wie größere Musikgruppen. Und noch sind Plätze frei! Die Chance also für alle, die sich gerne bei unserem Festival präsentieren möchten. Kurzbewerbungen können ab sofort per E-Mail an office@rheinruhrfestival.eu gesendet werden.",
          "Bitte schicken Sie keine größeren Dateianhänge! Vielen Dank"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Musiker gesucht & Seit einem Jahr vermitteln wir „Musiktandems“ - Musiker suchen Musiker und geben sich gegenseitig Unterricht. Ob Instrument, Gesang, Komposition - alles wird gesucht! Registrieren Sie sich kostenlos auf unserer Homepage www.musiktandems.eu und finden Sie heute noch das Angebot, das Sie schon lange suchen. Wichtig: Sie können sich nur für das Musiktandem anmelden, wenn Sie selbst auch Unterricht anbieten können, also zum Beispiel ein Instrument spielen. Auf unserer Website finden Sie auch weitere Informationen zum Ablauf und können den Service kontaktieren. &"
        ]
      }
    ]
  },
  {
    "id": "10",
    "title": "Haushalt, Torten und Berufsausbildung",
    "sourcePage": 242,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "d",
        "stem": "Ein Bekannter sucht eine Haushaltshilfe, die manchmal im Garten hilft."
      },
      {
        "num": 12,
        "answer": "f",
        "stem": "Eine Bekannte möchte lernen, wie man Schaufenster gestaltet."
      },
      {
        "num": 13,
        "answer": "i",
        "stem": "Eine Freundin möchte eine besondere Party für ihre siebenjährige Tochter organisieren."
      },
      {
        "num": 14,
        "answer": "c",
        "stem": "Eine Freundin möchte einmal einen Tag lang in einer Bäckerei arbeiten."
      },
      {
        "num": 15,
        "answer": "k",
        "stem": "Ihr Neffe liest gerne und möchte sein Hobby zu seinem Benuf machen."
      },
      {
        "num": 16,
        "answer": "g",
        "stem": "Ihre Mutter braucht jemanden, der im Haushalt hilft und manchmal kocht."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Ihre Nachbarin sucht eine Stelle als Haushaltshilfe."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Ihre Tochter mag Cupcakes. Sie sucht nach einem Buch mit leckeren Rezepten."
      },
      {
        "num": 19,
        "answer": "j",
        "stem": "Sie möchten für Ihren Sohn eine Geburtstagstorte bestellen. Ihr Sohn verträgt keine Laktose."
      },
      {
        "num": 20,
        "answer": "b",
        "stem": "Sie möchten in Ihrem Haushalt weniger Plastik verwenden."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Wenn Milchprodukte Bauchweh bereiten — viele Erwachsene, auch Kinder, kennen das Problem: ! Ein Stück Torte, eine Kugel Eis oder ein Glas Milch, und bald machen sich Bauchschmerzen und f Verdauungsprobleme bemerkbar. Das kann ein Zeichen für Laktoseintoleranz sein. Laktose ist der in Milch und Milchprodukten enthaltene Zucker. Die Unverträglichkeit gegenüber Laktose ist eine der am Weitesten verbreiteten ! Nahrungsmittelunverträglichkeiten. 1 Rund um das Thema Laktoseunverträglichkeit beantworten Ihnen in diesem Forum zwei Kinderärzte Ihre Fragen. Häufig gestellte Fragen: FAQ ! Mehr Infos? Stellen Sie hier Ihre Frage. !"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Produktion und der Verbrauch von Kunststoff steigen Weltweit offenbar unaufhaltsam an. Kunststoff ist allgegenwärtig, und wir können uns ein Leben",
          "ohne ihn kaum mehr vorstellen.",
          "Dabei ist es gar nicht so schwer, den Verpackungsmüll gering zu halten.",
          "Unsere Redaktion hat sich einige Gedanken dazu gemacht, wie der Verzicht",
          "auf Kunststoff im eigenen Haushalt schrittweise gelingen kann. Hier präsentieren wir die Ergebnisse und hoffen, dass möglichst viele Nutzer unsere Vorschläge aufgreifen werden. Ideen für weniger Kunststoff im Haushalt » ansehen",
          "Wenn ihr weitere gute Ideen habt, teilt sie doch bitte mit uns » teilen"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "BÄCKEREI - KONDITOREI BROTECKE N Bei uns gibt es einige Ausbildungsmöglichkeiten:",
          "Bäcker . Konditor . Verkauf . Büro",
          "Du interessierst dich für einen dieser Berufe und",
          ". Hast Freude an Backwaren aller Art . Bist genau, zuverlässig und kreativ .",
          "Hast Fingerspitzengefühl und bist freundlich? Dann bist du in der BROTECKE genau richtig! Neben der ausgezeichneten fachlichen Aus- und Weiterbildung wird bei uns auch",
          "der Teamgeist großgeschrieben, so veranstalten wir z. B gemeinsame Exkursionen.",
          "Interessiert?",
          "Du kannst gerne einen Schnuppertag oder ein Praktikum vereinbaren."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Brauchen Sie Unterstützung im Haushalt?",
          "Dann schreiben Sie mir Gerne helfe ich Ihnen. Ich arbeite schnell und gründlich, bin ehrlich und zuverlässig mit langjähriger Erfahrung in Privathaushalten. Ich übernehme auch gerne Putzarbeiten in einem Restaurant, Büro, Hotel oder einer Arztpraxis.",
          "Zusätzlich zu normalen Hausarbeiten wie Saugen, Putzen und Bügeln, erledige ich gerne auch Gartenarbeit. Auf Ihre Nachricht freue ich mich!",
          "Kontaktformular"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Zum 8. Mal findet dieses Jahr im September wieder die Nacht des Genusses statt. In diesem Rahmen öffnet auch die Bäckerei Holzofen wieder ihre Türen für Groß und Klein. Bäckermeister Carlo Menzinger führt durch die Backstube und beantwortet gerne Ihre Fragen rund um die Themen Brot und Backen. Er und sein Team freuen sich darauf,",
          "Ihnen das Bäckerhandwerk aus der Nähe zu zeigen.",
          "Natürlich gibt es auch leckere Kostproben gratis!",
          "Führungen um 18:00 und 20:00 Uhr, begrenzte Teilnehmerzahl."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Intensivkurs zur Dekorateurin/zum Dekorateur Sie lernen innerhalb von nur vier Wochen, wie man Produkte wirkungsvoll und 5 ansprechend präsentiert. Kursinhalte: Grundzüge der Dekoration ‚Werkstoffe ‚Arbeitstechniken .Drapieren, Bespannen und; Tapezieren .Licht und Farben .Schriften .Preisauszeichnung Ä Der Lehrgang richtet sich an Interessentinnen und Interessenten, die selbstständig Auslagen und , Verkaufsräume dekorieren wollen. Er schließt mit einer theoretischen und einer schriftlichen Prüfung ab. 1 Kurstermine P Für diesen Kurs gibt es unter bestimmten Voraussetzungen Förderungen. Bitte prüfen Sie hier selbst, ob Sie, persönlich die.V/oraussetzungen erfüllen, uam an am m mn mn mm m mn mn mm nm mn mn"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Rebecca, 38. Ich bin auf der Suche nach Familien, die Unterstützung im Haushalt brauchen. Sauberkeit, Genauigkeit, Pünktlichkeit und Zuverlässigkeit sind ebenso selbstverständlich wie Verschwiegenheit. Ich habe Erfahrung und viele zufriedene Kunden. Ich biete:",
          "‚Aufräumen, Müll wegbringen .Böden reinigen .Staub wischen .Fenster putzen",
          "‚Putzen von Bad & WC .Küche reinigen .Wäsche waschen und bügeln .Mahlzeiten zubereiten ‚Kinderbetreuung",
          "2-3 Arbeitstage pro Woche möglich, Preis 15 /Stunde",
          "(+ Anfahrtskosten bei Entfernungen von mehr als 5 Km)",
          "Tel.: 0 69/98 14 19 24 (bitte werktags 16:00-21:00 Uhr)"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "IA Das duale Berufsausbildungssystem in Deutschland kombiniert praktische und theoretische Lehrinhalte. In der dualen Berufsausbildung gibt es jedes Jahr rund 600.000 Ausbildungsplätze in mehr als 340 anerkannten Ausbildungsberufen. Im Wechsel mit der Anleitung in einem Betrieb wird in der Berufsschule unterrichtet. Während in den Praxisphasen die Lerninhalte mit erfahrenen Kollegen erarbeitet werden, stehen in der Berufsschule allgemeinbildende Fächer wie Deutsch, Englisch oder Mathematik im Vordergrund. In einem Sonderprogramm unterstützt die Bundesregierung auch Jugendliche aus dem europäischen Ausland, die eine Ausbildung in Deutschland machen möchten."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "TORTEN UND MEHR..... Wir backen nicht nur Torten, sondern bieten auch Kurse rund ums Thema Backen an. Ganz aktuell: Cupcakes. Sie erlernen die Basis-Rezepte für Cupcakes und Auflagen. Ein besonderer: Schwerpunkt liegt auf den Techniken zum Verzieren mit Spritzbeutel und Tüllen. Dieser Kurs eignet sich besonders gut für kleine Naschkätzchen: In Gruppen von 5 bis max. 10 Personen lernen die Kinder (6-10 Jahre) Cupcakes backen und dekorieren. Ideal für Geburtstagsfeiern oder ähnliche Anlässe. Jedes Kind verziert ca. 5 Cupcakes und darf seine Kunstwerke mit nach Hause nehmen. Buchen"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "LIZZIS BACKSTUBE",
          "Nach abgeschlossener Patisserieausbildung habe ich mir meinen Herzenswunsch erfüllt und meine eigene Konditorei eingerichtet. Nun entstehen in Lizzis Backstube auf Bestellung kleine und große Köstlichkeiten: von Pralinen und Konfekt über Törtchen und Cupcakes bis hin zu mehrstöckigen Hochzeitstorten. In meine Teige und Dekorationen Kommen nur Freilandeier und frische Zutaten-Qualität ist oberstes Gebot Besondere Wünsche wie gluten- oder laktosefreie Teige und Cremes sind kein Problem. Ich biete auch Torten ganz ohne tierische Produkte an. Fraugen Sie einfach nach!",
          "office@lizzisbackstube.com 0 69/97 131823 (Mi-Sa 10:00 bis 13:00 Uhr)"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Während der dreijährigen Ausbildung zur Buchhändlerin bzw. Zum Buchhändler lernst du, unsere Sortimente ansprechend im Schaufenster und im Verkaufsraum zu präsentieren. Wir vermitteln dir buchhändlerisches Fachwissen sowie Verkaufstechniken und Kenntnisse im Bereich Personal- und Rechnungswesen. Zu deinen Aufgaben gehören unter anderem die Recherche in Datenbanken sowie die Organisation von Events und Autorenlesungen. Neben buchhändlerischem Fachwissen vermitteln",
          "wir verschiedene Verkaufstechniken sowie betriebswirtschaftliche Kenntnisse im Bereich Personal-und Rechnungswesen. Bei uns bekommst du eine spannende und umfangreiche Ausbildung in einem guten ‚Arbeitsklima. Wenn Bücher deine Welt sind, dann bist du hier richtig!",
          "Jetzt online bewerben"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Die Hausratversicherung bietet Ihnen Schutz vor dem Verlust oder einer Beschädigung Ihres Eigentums, Beispiel nach einem Einbruch oder einem Wasserschaden. Sie deckt Schäden an allen beweglichen Gegenständen in den eigenen vier Wänden ab, z. B. an Möbeln, Teppichen oder Elektrogeräten Darüber ‘ hinaus können Sie auch für sich und Ihre Familie eine Haftpflichtversicherung bei uns abschließen. Fi Haftpflichtschutz bedeutet, dass die Versicherung für Schäden aufkommt, die Sie oder Ihre Familienmitglieder anderen Personen zugefügt haben, zum Beispiel, wenn Ihr Kind auf der Straße mit dem Fahrrad ein parkendes ‚Auto beschädigt hat. >>> weiterlesen 8"
        ]
      }
    ]
  },
  {
    "id": "11",
    "title": "Beruf, Weiterbildung und Studium",
    "sourcePage": 245,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "x",
        "stem": "Ein Freund interessiert sich für Musikinstrumente des europäischen Mittelalters."
      },
      {
        "num": 12,
        "answer": "b",
        "stem": "An Ihrem Arbeitsplatz müssen Sie viele deutsche Geschäftsbriefe schreiben, sind aber oft unsicher und suchen einen entsprechenden Kurs."
      },
      {
        "num": 13,
        "answer": "d",
        "stem": "Ihr Freund ist Vorsitzender eines Golfclubs und muss immer wieder Informationen an die Medien geben. Er möchte diese Aufgabe professionell erledigen."
      },
      {
        "num": 14,
        "answer": "k",
        "stem": "Eine Bekannte wird zur Erzieherin ausgebildet. Sie sucht einen Kurs, indem sie die Fähigkeit zu bildlichen Darstellung entwickeln kann."
      },
      {
        "num": 15,
        "answer": "g",
        "stem": "Sie suchen eine Berufsausbildung, bei der Sie viel mit Menschen zu tun haben. Und Sie interessieren sich für alles, was mit Gesundheit zu tun hat."
      },
      {
        "num": 16,
        "answer": "f",
        "stem": "Ihre Freundin zögert häufig, sich auf eine Sache festzulegen. Hat sie schließlich einen Entschluß gefasst, bereut sie diesen bisweilen."
      },
      {
        "num": 17,
        "answer": "l",
        "stem": "Sie wollen Rezepte aus der fernöstlichen Küche kennen lernen."
      },
      {
        "num": 18,
        "answer": "i",
        "stem": "Sie beginnen gerade mit Ihrem Studium, beherrschen die wissenschaftlichen Arbeitstechniken noch nicht."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Sie sollen in Kürze eine Powerpoint-Präsentation machen und suchen einen geeigneten Kurs."
      },
      {
        "num": 20,
        "answer": "j",
        "stem": "Sie haben sich auf eine Arbeitsstelle beworben und wollen sich gut vorbereiten, falls man Sie persönlich kennen lernen möchte."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Didgeridoo - der klingende Stock Australiens (Samstag 9.30 - 19.30 Uhr) Erlernt werden die Herstellung und das Spiel auf diesem wahrscheinlich ältesten Blasinstrument der Welt. Von den Aborigines - den Ureinwohnern Australiens - zur Begleitung von Tanz und Gesang undbei ! Heilungsritualien verwendet, wird es heute als Musikinstrument in der Therapie sowie in Musikgruppen und Orchestern auf der ganzen Welt eingesetzt. Die heilende Wirkung des Didgeridoo-Spiels beruht Ä darauf, dass durch die besondere Klangcharakteristik und die Zirkuläratmung, die es ermöglicht, den Ton beliebig lange ohne Unterbrechung zu halten, der Zugang zu einer gesteigerten Wahrnehmung erleichtert wird und man so einen Zustand tiefer Entspannung erreicht."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Deutsch im Beruf (Samstag 9:00 - 17.30 Uhr) Wie schreibt man heute richtig? Welche Regeln sind beim Telefonieren zu beachten? Worauf muss ich",
          "beim Schreiben von E-Mails achten? Wie gestalte ich Briefe am besten? Und wo hole ich mir Hilfe, wenn ich mir nicht sicher bin? Der Tageskurs soll kurz und bündig das Wichtigste bieten, worauf man",
          "aufpassen muss. Damit lassen sich sicher 80-90% der häufigsten Fehler vermeiden, was den Eindruck ihrer Firma nach außen wesentlich verbessert. Ihr Chef wird bemerken, dass sie hinzugelernt haben. f"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Xpert - Europäischer Computerpass (Dienstag, 1815-21-15 Uhr, Dauer: IO Wochen) In diesem Semester bitte die FAFA zum Einstieg in das Lehrgangssystem von Xpert das neue Pflichtmodul Win@internet 1 an. Im nächsten Halbjahr werden dann das Pflichtmodul Textverarbeitung Basics und das Wahlmodul Präsentation folgen. Wenn sie sich prüfen lassen, « wissen Sie, woraus ein einfaches Computersystem besteht, « können Sie Windows bedienen und Ordner verwalten, « haben sie die Fähigkeit, die wichtigsten Internetdienste und E-Mail-Dienste anzuwenden und haben Einblick in die Gefahren, die sich aus der Nutzung ergeben. ZZ € [ [ — — — —"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Grundlagen der Pressearbeit für Vereine",
          "(Samstag, 10.00 - 12.00 Uhr)",
          "Nach welchen Kriterien haben Themen eine Chance, in die Medien zu gelangen? In diesem Seminar lernen Sie Grundlagen effektiver Pressearbeit kennen. Es wird aber nicht nur theoretisches Wissen vermittelt. Sie haben Gelegenheit zu praktischen Übungen und können lernen, eine aktuelle Pressemitteilung für Ihren Verein zu formulieren. Das Angebot richtet sich vor allem an Aktive in Vereinen und Initiativen, die neu in die Pressearbeit einsteigen wollen. Den Teilnehmenden wird ein zusätzliches späteres Treffen angeboten, um die Erfahrungen aus der ersten Anwendung der im Seminar erworbenen Kenntnisse auszutauschen."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Glücklich miteinander - wie Partnerschaft gelingt (Dienstag, 19.30 - 21.00 Uhr)",
          "Am Anfang der Partnerschaft sind wir verliebt und glücklich. Sehr bald allerdings gerät die Liebe in Gefahr",
          "- sowohl durch die Belastungen des Alltags als auch durch die beiderseitigen Fehler. Der Vortrag zeigt, worauf es in einer guten Partnerschaft ankommt, und stellt dazu die neuesten Forschungsergebnisse Hi aus der Paarforschung vor. Außerdem berichtet die Referentin aus ihrer Praxis als Paar- und Fi Familientherapeutin und gibt Hinweise, was die Partner selbst aktiv für ihre Liebe tun können. Die Veranstaltung findet in Kooperation mit dem Psychologischen Institut der Universität statt."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Entscheidungen leichter fällen (Samstag, 10.00 - 13.00 Uhr) \"Diese oder jene Wohnung nehmen und nach welchen Kriterien entscheiden?\" \"Trotz schlechter Fi Arbeitsmarktlage den Job wechseln oder lieber auf Nummer sicher gehen?“ Oder einfach nur: “Was soll [; ich heute kochen?\" Entscheidungen müssen wir täglich treffen - einige fallen uns leichter, andere ! schwerer. Nicht selten ist man aber hinterher mit der Entscheidung unzufrieden und fragt sich, ob man IE nicht alles hätte anders machen sollen. Das muss nicht sein. Eine optimale Entscheidung zu treffen j lässt sich lernen. Unterschiedliche Techniken werden vorgestellt, gezielt geübt und man lernt, dieseauf , die individuelle Situation anzuwenden, so dass man in Zukunft jede Entscheidung leichter fällen kann."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Physiotherapie",
          "(Beginn: I. September, 9.00 Uhr, Dauer: 4 Semester)",
          "Physiotherapie ist ein wichtiger Bestandteil der modernen Medizin. Die Physiotherapeutin, der Physiotherapeut kann mit vielen Behandlungskonzepten und Techniken zum Erhalt oder zur Wiederbereitstellung aller Funktionen der Patienten beitragen. Die Ausbildung endet mit einer staatlichen Prüfung. Nach bestandener Prüfung wird gemäß S 2 des \"Gesetzes über die Berufe in der Physiotherapie” die Erlaubnis zur Führung der Berufsbezeichnung “Physiotherapeut/in” von den zuständioen Rehärden erteilt. |lm an der Aushildiung teilnehmen zu kännen. müssen Sie mindestens"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "‚Außenwirtschaft- und länderkundliche Beraterin:",
          "(täglich, 8.00 - 12.10 Uhr, Dauer: 10 Monate)",
          "Ziel ist es, an einer Tätigkeit im kaufmännischen Bereich interessierte Frauen mit Migrationshintergrund und zumindest guten Grundkenntnissen der deutschen Sprache auf eine Tätigkeit im Import/Exportbereich vorzubereiten und in eine feste Anstellung zu vermitteln. Durch die Aneignung der dafür erforderlichen sprachlichen und fachlichen Kompetenzen ist es möglich, den MigrantInnen",
          "« einen beruflichen Einstieg in den Bereich Außenwirtschaft,",
          "« eine Anknüpfung an eine bereits im Herkunftsland ausgeübte oder erlernte Tätigkeit",
          "« eine anschließende Regelausbildung im Außenhandel oder Import-Export-Bereich",
          "« eine Existenzgründung im Consultingbereich (als länderkundliche Beraterin)",
          "zu ermöglichen."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Referate und Hausarbeiten erfolgreich meistern (Mittwoch und Freitag, 18.30 - 21.00 Uhr, Dauer: 10 Wochen) Wie kann ich mich optimal an Lehrveranstaltungen beteiligen? Wie halte ich mündliche Referate? Was erwartet mich in einer mündlichen Prüfung? Wie soll eine E-Mail an Dozentinnen und Dozenten aussehen? Wie fertige ich Mitschriften und Exzerpte an? Wie schreibe ich eine Hausarbeit, wie zitiereich? Wie schreibe ich schriftliche Klausuren? - Besonders in den ersten Semestern haben Anfänger ihreliebe Not mit den universitären Textsorten und Aufgabenstellungen. Mit den Schwerpunkten Referat und Hausarbeit bietet der Kurs Übungen, um Routine für schriftliche und mündliche Leistungsnachweise zu entwickeln. Das Lehrmaterial wird zu Kursbeginn bekannt gegeben. Kopierkosten werden mit dem Dozenten abgerechnet"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Souverän in Vorstellungsgesprächen (Freitag-Sonntag, 10.30 - 17.00 Uhr) Im Vorstellungsgespräch müssen Sie Ihren zukünftigen Arbeitgeber von Ihren Fähigkeiten und Ihrer Persönlichkeit überzeugen. Dieses Seminar vermittelt Ihnen, was im Vorstellungsgespräch von Ihnen erwartet wird, was Sie sagen oder nicht sagen sollten und wie Sie Ihr Profil darstellen. Mithilfe von Rollenspielen und Videoaufzeichnungen sehen Sie ein Bild von sich selbst. Sofort-Tipps und Feedback unterstützen eine Verhaltensänderung, die den Erfolg Ihres Vorstellungsgespräches unterstützt. Nachdem Sie viel geübt haben, werden Sie in Zukunft ohne Bauchschmerzen zum Vorstellungsgespräch gehen können"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Zeichnen für Anfänger",
          "(Samstag und Sonntag, 10.30 - 17.00 Uhr)",
          "Sind Sie auch der Meinung, dass Sie nicht zeichnen können? Dann sind Sie in diesem Kurs genau richtig! An verschiedenen Alltagsgegenständen schulen wir unsere Wahrnehmung und lernen, Proportionen, Licht und Schatten richtig zu erfassen und zeichnerisch wiederzugeben. Ihnen schwirrt der Kopf, wenn Sie Begriffe wie Horizontlinie oder Fluchtpunkt hören und leichte Verzweiflung erfasst Sie? Was es damit auf sich hat, erfahren Sie in zeichnerischen Übungen und lernen eckige Gegenstände, Innenräume und Hausansichten perspektivisch richtig darzustellen. Wir arbeiten mit Bleistift. Bitte mitbringen: Bleistifte HB, 2B, 4B, 6B, 8B, Radiergummi, Spitzer und Zeichenblock DIN A3."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Traditionelle thailändische Speisen (Samstag und Sonntag, 10.30 - 17.00 Uhr) Thailändische Gerichte sind dafür berühmt, viel Geschmack, gleichzeitig jedoch weniger Kalorien zu liefern. Die thailändische Küche bietet genussvolle und köstliche Speisen. Vorspeisen, Hauptgerichte und die berühmten Suppen und Salate werden gemeinsam zubereitet. Der Kurs soll ein Einstieg in die Feinheiten der thailändischen Küche sein. & An jedem Kursabend wird ein vielseitiges und köstliches Menü zusammengestellt und anschließend gemeinsam gegessen. Angerichtet wird der Kurs durch landestypische Dekorationsideen. Bitte bringen 8"
        ]
      }
    ]
  },
  {
    "id": "11a",
    "title": "Beruf, Weiterbildung und Studium",
    "sourcePage": 248,
    "keywords": "Außenwirtschaft- und länderkundliche Beraterin: (täglich, 8.00 - 12.10 Uhr, Dauer: 10 Monate) Ziel ist es, an einer Tätigkeit im kaufmännischen Bereich interessierte Frauen mit Migrationshintergrund und zumindest guten Grundkenntnissen der deutschen Sprache auf eine Tätigkeit im Import/Exportbereich vorzubereiten und in eine feste Anstellung zu vermitteln. Durch die Aneignung der dafür erforderlichen sprachlichen und fachlichen Kompetenzen ist es möglich, den MigrantInnen • einen beruflichen Einstieg in den Bereich Außenwirtschaft, • eine Anknüpfung an eine bereits im Herkunftsland ausgeübte oder erlernte Tätigkeit. • eine anschließende Regelausbildung im Außenhandel oder Import-Export-Bereich • eine Existenzgründung im Consultingbereich (als länderkundliche Beraterin) Referate und Hausarbeiten erfolgreich meistern (Mittwoch und Freitag, 18.30 - 21.00 Uhr, Dauer: 10 Wochen) Wie kann ich mich optimal an Lehrveranstaltungen beteiligen? Wie halte ich mündliche Referate? Was erwartet mich in einer mündlichen Prüfung? Wie soll eine E-Mail an Dozentinnen und Dozenten aussehen? Wie fertige ich Mitschriften und Exzerpte an? Wie schreibe ich eine Hausarbeit, wie zitiere ich? Wie schreibe ich schriftliche Klausuren? - Besonders in den ersten Semestern haben Anfänger ihre liebe Not mit den universitären Textsorten und Aufgabenstellungen. Mit den Schwerpunkten Referat und Hausarbeit bietet der Kurs Übungen, um Routine für schriftliche und mündliche Leistungsnachweise zu entwickeln. Das Lehrmaterial wird zu Kursbeginn bekannt gegeben. Kopierkosten werden mit dem Souverän in Vorstellungsgesprächen (Freitag-Sonntag, 10.30 - 17.00 Uhr) Im Vorstellungsgespräch müssen Sie Ihren zukünftigen Arbeitgeber von Ihren Fähigkeiten und Ihrer Persönlichkeit überzeugen. Dieses Seminar vermittelt Ihnen, was im Vorstellungsgespräch von Ihnen erwartet wird, was Sie sagen oder nicht sagen sollten und wie Sie Ihr Profil darstellen. Mithilfe von Rollenspielen und Videoaufzeichnungen sehen Sie ein Bild von sich selbst. Sofort-Tipps und Feedback unterstützen eine Verhaltensänderung, die den Erfolg Ihres Vorstellungsgespräches unterstützt. Nachdem Sie viel geübt haben, werden Sie in Zukunft ohne Bauchschmerzen zum Vorstellungsgespräch (Samstag und Sonntag, 10.30 - 17.00 Uhr) Sind Sie auch der Meinung, dass Sie nicht zeichnen können? Dann sind Sie in diesem Kurs genau richtig! An verschiedenen Alltagsgegenständen schulen wir unsere Wahrnehmung und lernen, Proportionen, Licht und Schatten richtig zu erfassen und zeichnerisch wiederzugeben. Ihnen schwirrt der Kopf, wenn Sie Begriffe wie Horizontlinie oder Fluchtpunkt hören und leichte Verzweiflung erfasst Sie? Was es damit auf sich hat, erfahren Sie in zeichnerischen Übungen und lernen eckige Gegenstände, Innenräume und Hausansichten perspektivisch richtig darzustellen. Wir arbeiten mit Bleistift. Bitte mitbringen: Bleistifte HB, 2B, 4B, 6B, 8B, Radiergummi, Spitzer und Zeichenblock DIN A3. Traditionelle thailändische Speisen (Samstag und Sonntag, 10.30 - 17.00 Uhr) Thailändische Gerichte sind dafür berühmt, viel Geschmack, gleichzeitig jedoch weniger Kalorien zu liefern. Die thailändische Küche bietet genussvolle und köstliche Speisen. Vorspeisen, Hauptgerichte und die berühmten Suppen und Salate werden gemeinsam zubereitet. Der Kurs soll ein Einstieg in die Feinheiten der thailändischen Küche sein. An jedem Kursabend wird ein vielseitiges und köstliches Menü zusammengestellt und anschließend gemeinsam gegessen. Angerichtet wird der Kurs durch landestypische Dekorationsideen. Bitte bringen Sie zwei Geschirrtücher, Vorratsdosen für Reste und Ihr eigenes Getränk mit. Die Lebensmittelkosten in Höhe von ca. 8 EUR pro Abend werden direkt mit den Dozenten abgerechnet.",
    "questions": [
      {
        "num": 11,
        "answer": "x",
        "stem": "Ein Freund interessiert sich für Musikinstrumente des europäischen Mittelalters."
      },
      {
        "num": 12,
        "answer": "b",
        "stem": "An Ihrem Arbeitsplatz müssen Sie viele deutsche Geschäftsbriefe schreiben, sind aber oft unsicher und suchen einen entsprechenden Kurs."
      },
      {
        "num": 13,
        "answer": "d",
        "stem": "Ihr Freund ist Vorsitzender eines Golfclubs und muss immer wieder Informationen an die Medien geben. Er möchte diese Aufgabe professionell erledigen."
      },
      {
        "num": 14,
        "answer": "k",
        "stem": "Eine Bekannte wird zur Erzieherin ausgebildet. Sie sucht einen Kurs, indem sie die Fähigkeit zu bildlichen Darstellung entwickeln kann."
      },
      {
        "num": 15,
        "answer": "g",
        "stem": "Sie suchen eine Berufsausbildung, bei der Sie viel mit Menschen zu tun haben. Und Sie interessieren sich für alles, was mit Gesundheit zu tun hat."
      },
      {
        "num": 16,
        "answer": "f",
        "stem": "Ihre Freundin zögert häufig, sich auf eine Sache festzulegen. Hat sie schließlich einen Entschluß gefasst, bereut sie diesen bisweilen."
      },
      {
        "num": 17,
        "answer": "l",
        "stem": "Sie wollen Rezepte aus der fernöstlichen Küche kennen lernen."
      },
      {
        "num": 18,
        "answer": "i",
        "stem": "Sie beginnen gerade mit Ihrem Studium, beherrschen die wissenschaftlichen Arbeitstechniken noch nicht."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Sie sollen in Kürze eine Powerpoint-Präsentation machen und suchen einen geeigneten Kurs."
      },
      {
        "num": 20,
        "answer": "j",
        "stem": "Sie haben sich auf eine Arbeitsstelle beworben und wollen sich gut vorbereiten, falls man Sie persönlich kennen lernen möchte."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Didgeridoo - der klingende Stock Australiens (Samstag 9.30 - 19.30 Uhr) Erlernt werden die Herstellung und das Spiel auf diesem wahrscheinlich ältesten Blasinstrument der Welt. Von den Aborigines - den Ureinwohnern Australiens - zur Begleitung von Tanz und Gesang undbei ! Heilungsritualien verwendet, wird es heute als Musikinstrument in der Therapie sowie in Musikgruppen und Orchestern auf der ganzen Welt eingesetzt. Die heilende Wirkung des Didgeridoo-Spiels beruht Ä darauf, dass durch die besondere Klangcharakteristik und die Zirkuläratmung, die es ermöglicht, den Ton beliebig lange ohne Unterbrechung zu halten, der Zugang zu einer gesteigerten Wahrnehmung erleichtert wird und man so einen Zustand tiefer Entspannung erreicht."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Deutsch im Beruf (Samstag 9:00 - 17.30 Uhr) Wie schreibt man heute richtig? Welche Regeln sind beim Telefonieren zu beachten? Worauf muss ich",
          "beim Schreiben von E-Mails achten? Wie gestalte ich Briefe am besten? Und wo hole ich mir Hilfe, wenn ich mir nicht sicher bin? Der Tageskurs soll kurz und bündig das Wichtigste bieten, worauf man",
          "aufpassen muss. Damit lassen sich sicher 80-90% der häufigsten Fehler vermeiden, was den Eindruck ihrer Firma nach außen wesentlich verbessert. Ihr Chef wird bemerken, dass sie hinzugelernt haben. f"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "m nn 1 € Xpert - Europäischer Computerpass (Dienstag, 1815-21-15 Uhr, Dauer: IO Wochen) In diesem Semester bitte die FAFA zum Einstieg in das Lehrgangssystem von Xpert das neue Pflichtmodul Win@internet 1 an. Im nächsten Halbjahr werden dann das Pflichtmodul Textverarbeitung Basics und das Wahlmodul Präsentation folgen. Wenn sie sich prüfen lassen, « wissen Sie, woraus ein einfaches Computersystem besteht, « können Sie Windows bedienen und Ordner verwalten, « haben sie die Fähigkeit, die wichtigsten Internetdienste und E-Mail-Dienste anzuwenden und haben Einblick in die Gefahren, die sich aus der Nutzung ergeben. ZZ € [ [ — — — —"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Grundlagen der Pressearbeit für Vereine",
          "(Samstag, 10.00 - 12.00 Uhr)",
          "Nach welchen Kriterien haben Themen eine Chance, in die Medien zu gelangen? In diesem Seminar lernen Sie Grundlagen effektiver Pressearbeit kennen. Es wird aber nicht nur theoretisches Wissen vermittelt. Sie haben Gelegenheit zu praktischen Übungen und können lernen, eine aktuelle Pressemitteilung für Ihren Verein zu formulieren. Das Angebot richtet sich vor allem an Aktive in Vereinen und Initiativen, die neu in die Pressearbeit einsteigen wollen. Den Teilnehmenden wird ein zusätzliches späteres Treffen angeboten, um die Erfahrungen aus der ersten Anwendung der im Seminar erworbenen Kenntnisse auszutauschen."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Glücklich miteinander - wie Partnerschaft gelingt (Dienstag, 19.30 - 21.00 Uhr)",
          "Am Anfang der Partnerschaft sind wir verliebt und glücklich. Sehr bald allerdings gerät die Liebe in Gefahr",
          "- sowohl durch die Belastungen des Alltags als auch durch die beiderseitigen Fehler. Der Vortrag zeigt, worauf es in einer guten Partnerschaft ankommt, und stellt dazu die neuesten Forschungsergebnisse Hi aus der Paarforschung vor. Außerdem berichtet die Referentin aus ihrer Praxis als Paar- und Fi Familientherapeutin und gibt Hinweise, was die Partner selbst aktiv für ihre Liebe tun können. Die Veranstaltung findet in Kooperation mit dem Psychologischen Institut der Universität statt."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Entscheidungen leichter fällen (Samstag, 10.00 - 13.00 Uhr) \"Diese oder jene Wohnung nehmen und nach welchen Kriterien entscheiden?\" \"Trotz schlechter Fi Arbeitsmarktlage den Job wechseln oder lieber auf Nummer sicher gehen?“ Oder einfach nur: “Was soll [; ich heute kochen?\" Entscheidungen müssen wir täglich treffen - einige fallen uns leichter, andere ! schwerer. Nicht selten ist man aber hinterher mit der Entscheidung unzufrieden und fragt sich, ob man IE nicht alles hätte anders machen sollen. Das muss nicht sein. Eine optimale Entscheidung zu treffen j lässt sich lernen. Unterschiedliche Techniken werden vorgestellt, gezielt geübt und man lernt, dieseauf , die individuelle Situation anzuwenden, so dass man in Zukunft jede Entscheidung leichter fällen kann."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Physiotherapie",
          "(Beginn: I. September, 9.00 Uhr, Dauer: 4 Semester)",
          "Physiotherapie ist ein wichtiger Bestandteil der modernen Medizin. Die Physiotherapeutin, der Physiotherapeut kann mit vielen Behandlungskonzepten und Techniken zum Erhalt oder zur Wiederbereitstellung aller Funktionen der Patienten beitragen. Die Ausbildung endet mit einer staatlichen Prüfung. Nach bestandener Prüfung wird gemäß S 2 des \"Gesetzes über die Berufe in der Physiotherapie” die Erlaubnis zur Führung der Berufsbezeichnung “Physiotherapeut/in” von den zuständioen Rehärden erteilt. |lm an der Aushildiung teilnehmen zu kännen. müssen Sie mindestens"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "‚Außenwirtschaft- und länderkundliche Beraterin:",
          "(täglich, 8.00 - 12.10 Uhr, Dauer: 10 Monate)",
          "Ziel ist es, an einer Tätigkeit im kaufmännischen Bereich interessierte Frauen mit Migrationshintergrund und zumindest guten Grundkenntnissen der deutschen Sprache auf eine Tätigkeit im Import/Eportbereich vorzubereiten und in eine feste Anstellung zu vermitteln. Durch die Aneignung der dafür erforderlichen sprachlichen und fachlichen Kompetenzen ist es möglich, den MigrantInnen",
          "« einen beruflichen Einstieg in den Bereich Außenwirtschaft,",
          "« eine Anknüpfung an eine bereits im Herkunftsland ausgeübte oder erlernte Tätigkeit.",
          "« eine anschließende Regelausbildung im Außenhandel oder Import-Export-Bereich",
          "+ eine Existenzgründung im Consultingbereich (als länderkundliche Beraterin)",
          "zu ermöglichen."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Referate und Hausarbeiten erfolgreich meistern (Mittwoch und Freitag, 18.30 - 21.00 Uhr, Dauer: 10 Wochen) Wie kann ich mich optimal an Lehrveranstaltungen beteiligen? Wie halte ich mündliche Referate? Was f erwartet mich in einer mündlichen Prüfung? Wie soll eine E-Mail an Dozentinnen und Dozenten aussehen? Wie fertige ich Mitschriften und Exerpte an? Wie schreibe ich eine Hausarbeit, wie zitiereich? Wie schreibe ich schriftliche Klausuren? - Besonders in den ersten Semestern haben Anfänger ihreliebe Not mit den universitären Teksorten und Aufgabenstellungen. Mit den Schwerpunkten Referat und Hausarbeit bietet der Kurs Übungen, um Routine für schriftliche und mündliche Leistungsnachweise zu entwickeln. Das Lehrmaterial wird zu Kursbeginn bekannt gegeben. Kopierkosten werden mit dem Dozenten abgerechnet."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Souverän in Vorstellungsgesprächen (Freitag-Sonntag, 10.30 - 17.00 Uhr) Im Vorstellungsgespräch müssen Sie Ihren zukünftigen Arbeitgeber von Ihren Fähigkeiten und Ihrer Persönlichkeit überzeugen. Dieses Seminar vermittelt Ihnen, was im Vorstellungsgespräch von Ihnen erwartet wird, was Sie sagen oder nicht sagen sollten und wie Sie Ihr Profil darstellen. Mithilfe von Rollenspielen und Videoaufzeichnungen sehen Sie ein Bild von sich selbst. Sofort-Tipps und Feedback unterstützen eine Verhaltensänderung, die den Erfolg Ihres Vorstellungsgespräches unterstützt. Nachdem Sie viel geübt haben, werden Sie in Zukunft ohne Bauchschmerzen zum Vorstellungsgespräch gehen können."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Zeichnen für Anfänger",
          "(Samstag und Sonntag, 10.30 - 17.00 Uhr)",
          "Sind Sie auch der Meinung, dass Sie nicht zeichnen können? Dann sind Sie in diesem Kurs genau richtig! An verschiedenen Alltagsgegenständen schulen wir unsere Wahrnehmung und lernen, Proportionen, Licht und Schatten richtig zu erfassen und zeichnerisch wiederzugeben. Ihnen schwirrt der Kopf, wenn Sie Begriffe wie Horizontlinie oder Fluchtpunkt hören und leichte Verzweiflung erfasst Sie? Was es damit auf sich hat, erfahren Sie in zeichnerischen Übungen und lernen eckige Gegenstände, Innenräume und Hausansichten perspektivisch richtig darzustellen. Wir arbeiten mit Bleistift. Bitte mitbringen: Bleistifte HB, 2B, 4B, 6B, 8B, Radiergummi, Spitzer und Zeichenblock DIN A3."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Traditionelle thailändische Speisen",
          "(Samstag und Sonntag, 10.30 - 17.00 Uhr) Thailändische Gerichte sind dafür berühmt, viel Geschmack, gleichzeitig jedoch weniger Kalorien zu",
          "liefern. Die thailändische Küche bietet genussvolle und köstliche Speisen. Vorspeisen, Hauptgerichte und ° die berühmten Suppen und Salate werden gemeinsam zubereitet. Der Kurs soll ein Einstieg in die Feinheiten der thailändischen Küche sein.",
          "An jedem Kursabend wird ein vielseitiges und köstliches Menü zusammengestellt und anschließend 3 gemeinsam gegessen. Angerichtet wird der Kurs durch landestpische Dekorationsideen. Bitte bringen"
        ]
      }
    ]
  },
  {
    "id": "12",
    "title": "Weihnachten, Theater und Musik",
    "sourcePage": 251,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Ihre Schwester interessiert sich für die Biographien großer Musiker. Sie leben Auftritte von herausragenden Musik. Sie lieben künstlerische Vielfalt und Vielseitigkeit und wollen Weihnachten ausgehen. Sie möchten alte und neue Weihnachtslieder hören. Sie möchten mit Ihrer zwölfjährigen Tochter ein altersgerechtes Theaterstück sehen. Sie suchen einen Kinderfilm für ihren kleinen Sohn. Sie suchen für sportliche Sprachkursteilnehmer eine Möglichkeit, Bonn zu zeigen. Sie wollen ihrem Freund, der Tanztheater liebt, eine Eintrittskarte zum Geburtstag schenken. Sie wollen mit ihren Kindern eine etwas andere, eher lustige Seite von Weihnachten erleben. Sie wollen mit Bekannten ausgehen um mal wieder so richtig lachen. In Pollekes elfjährigem Leben scheint im Augenblick etwas falsch zu laufen. Es stört sie ja gar nicht, dass ihre Eltern geschieden sind. Sie hat ihren Papa sehr lieb, und sie hat eine prima Mama. Ihr Lehrer ist eigentlich auch ganz in Ordnung, aber muss der sich gleich in ihre Mama verlieben? Und dann ist Polleke sogar selbst schuld an allem. Aber sie gibt die Hoffnung nicht auf, dass am Ende doch alles gut wird, auch mit Mimun, dem liebsten Jungen auf der ganzen Erde Datum: 01.11., Uhrzeit: 16.00 Uhr, Ort: Theaterwerkstatt, Alter: ab 9 Jahren Rasmus und der Landstreicher Nach dem Kinderbuch von Astrid Lindgren Rasmus ist in einem Kinderheim aufgewachsen, er hat keine Eltern. Eines Tages läuft er davon und will sich Eltern suchen. Die erste Nacht schläft er in einer Scheune im Stroh, und am Morgen entdeckt er neben sich Oskar. Oskar ist ein Landstreicher, der keine Wohnung hat. Zuerst hat Rasmus Angst vor ihm, aber schon bald merkt er, dass Oskar ein prächtiger Mensch ist. Gemeinsam suchen sie Eltern für Rasmus. Doch als sie endlich prima Eltern gefunden haben, da wollen die beiden sich nicht mehr trennen. Datum: 6.11., Uhrzeit: 15.00 Uhr, Ort: Bürgerkino, Alter: ab 5 Jahren Drei Flöhe und das Jesuskind Im Jahr 1 machten sich drei Flöhe aus Deutschland auf den Weg nach Israel, um einmal so richtig zu entspannen. Leider war zu diesem Zeitpunkt eine Volkszählung im vollen Gange und die einzige Übernachtungsmöglichkeit fanden sie in einem Stall bei Bethlehem. Dass sie diese Unterkunft auch noch mit einem kleinen Kind teilen müssten, damit rechnete keiner der drei Flöhe. Und dass dieses Kind auch noch eine Berühmtheit war, machte die ganze Sache für die drei Flöhe zu einem aufregenden Abenteuer. Dieses neue Kinderstück aus der Feder von Dirk Zimmer erzählt die Weihnachtsgeschichte auf humorvolle und gefühlvolle Weise aus der Sicht der drei Flöhen. Datum: 26.11. - 22.12., Uhrzeit: jeweils, 15.00 Uhr, Ort: Innenhof des Rathauses, \"Stille Nacht\" trifft \"Last Christmas\", Gospel umarmt Soul, und Pop küsst Klassik. Als 1997 die Idee entstand, eine Weihnachtsshow zu entwickeln, die die schönsten Weihnachtslieder aller Zeiten und aller Genre in sich vereint, konnte sich keiner so recht vorstellen, dass diese Show einmal zur erfolgreichsten Weihnachtsshow Deutschlands avancieren würde. Seit zehn Jahren begeistert nun die Band \"Christmast Moments\" von Thomas Schwab & Band das Publikum sowohl in den großen Konzerthallen der Republik (unter anderem Arena Trier, Phönixhalle Mainz) als auch vor den Fernsehern (ARD- Ausstrahlungen seit 2004). \"Christmas Moments\" trifft mitten ins Herz und konnte in den letzten Jahren mehr als 500.000 Datum: 11.12., Uhrzeit: 20.00 Uhr, Jazz vom Feinsten mit durchaus gewollten konservativen Zügen. Der Trompeter Lasse Lindgren ist einer der innovativen Spitzen-Trompeter der aktuellen Jazzszene in Schweden, der in vielen internationalen Bigbands und zusammen mit anderen berühmten Jazzmusikern gespielt hat. Von der Tageszeitung \"Svenska Dagbladet\" wurde er als \"einer der kompetentesten Trompetenspieler dieses Landes\" bezeichnet und Randy Brecker schrieb: \"Es ist so erfrischend, etwas zu hören, was wirklich originell ist! Lass Lindgren, Du bist ein wundervoller Spieler und Komponist\". Sein neuestes Projekt ist ein Glaubensbekenntnis an die Kraft und Energie des Jazz mit eigener Handschrift: Lasse Lindgren hat eine virtuose, immer transparente Hingabe zu seinem Instrument. Datum: 1.11., Uhrzeit : 19.00 Uhr, Ort: Irish Pub im Stadtzentrum Unglaublich! 10 Jahre ist es bereits her, seit FÜR DIE KATZ wie ein Faustschlag ins Licht der Öffentlichkeit traten und sich binnen kürzester Zeit in die Spitzenriege der deutschen Komiker katapultierten. Heute befinden sich die beiden mit Preisen überhäuften Weltbürger Benno Rex und Karl Salzburger auf dem vorläufigen Höhepunkt ihrer eindrucksvollen Karriere und gelten als die vielseitigsten, kreativsten und für Presse wie Fans schlichtweg lustigsten Komödianten Deutschlands. Ihre Wortschöpfungen und Charaktere erweisen sich immer wieder als richtungsweisende Leitsterne für die gesamte Comedy-Branche. Datum: 5.11., Uhrzeit: 20.00 Uhr, Weihnachtsvarieté im Café Spitz Das Weihnachtsvarieté erwartet Sie auch in diesem Jahr mit atemberaubender Akrobatik, traumhafter Jonglage, ergänzt von Livemusikern. Seien Sie dabei und staunen Sie vielleicht mit ihrer Familie, mit ihren Lieblingskollegen oder der ganzen Firma oder einfach nur mit ihrem oder Ihrer Liebsten. Karl-Heinz Helmschrot hat auch in diesem Jahr wieder eine faszinierende Gruppe von sehr unterschiedlichen Künstlern zusammengestellt. Zum 10-jährigen Jubiläum - 10 Künstler! Nicht zuständig ist er für Ihr leibliches Wohl! Dafür haben die Köche des Café Spitz internationale Karte zusammengestellt, also freuen Sie sich auf Köstlichkeiten aus aller Welt. Datum: 9.12., Uhrzeit: 21.00 Uhr, Ort: Café Spitz",
    "questions": [
      {
        "num": 11,
        "answer": "e",
        "stem": "Ihre Schwester interessiert sich für die Biographien großer Musiker."
      },
      {
        "num": 12,
        "answer": "j",
        "stem": "Sie leben Auftritte von herausragenden Musik."
      },
      {
        "num": 13,
        "answer": "l",
        "stem": "Sie lieben künstlerische Vielfalt und Vielseitigkeit und wollen Weihnachten ausgehen."
      },
      {
        "num": 14,
        "answer": "i",
        "stem": "Sie möchten alte und neue Weihnachtslieder hören."
      },
      {
        "num": 15,
        "answer": "a",
        "stem": "Sie möchten mit Ihrer zwölfjährigen Tochter ein altersgerechtes Theaterstück sehen."
      },
      {
        "num": 16,
        "answer": "b",
        "stem": "Sie suchen einen Kinderfilm für ihren kleinen Sohn."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Sie suchen für sportliche Sprachkursteilnehmer eine Möglichkeit, Bonn zu zeigen."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Sie wollen ihrem Freund, der Tanztheater liebt, eine Eintrittskarte zum Geburtstag schenken."
      },
      {
        "num": 19,
        "answer": "h",
        "stem": "Sie wollen mit ihren Kindern eine etwas andere, eher lustige Seite von Weihnachten erleben."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Sie wollen mit Bekannten ausgehen um mal wieder so richtig lachen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Beateıhb In Pollekes elfjährigem eben scheint im Augenblick etwas falsch zu laufen. Es stört sie ja gar nicht, dass ihre Eltern geschieden sind. Sie hat ihren Papa sehr lieb, und sie hat eine prima Mama. Ihr Bhrer ist eigentlich auch ganz in Ordnung, aber muss der sich gleich in ihre Mama ! verliebenUnd dann ist Polleke sogar selbst schuld an allem. Aber sie gibt die Hoffnung nicht auf, dass am Ende doch alles gut wird, auch mit Mimun, dem liebsten Jungen auf der ganzen Erde und im ganzen Weltall... Datum:0lN., Uhrzeit:1MO Uhr, Ort:Theaterwerkstatt, Alter:ab Jahren"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Rsmus und deindsteicher Nach dem Kinderbuch von Astrid Lindgren Rasmus ist in einem Kinderheim aufgewachsen, er hat keine Eltern. Eines Tages läuft er davon und will sich Eltern suchen. Die erste Nacht schläft er in einer Scheune im Stroh, und am",
          "Morgen entdeckt er neben sich Oskar. Oskar ist ein Bndstreicher, der keine Wohnung hat. Zuerst hat Rasmus Angst vor ihm, aber schon bald merkt er, dass Oskar ein prächtiger Mensch",
          "ist. Gemeinsam suchen sie Eltern für Rasmus. Doch als sie endlich prima Eltern gefunden haben, da wollen die beiden sich nicht mehr trennen."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "EEE 1. Claus von Wagner: Im Feld Die Verfilmung des Buches \"Im Feld” handelt von einem jungen Mann, der bisher mit den Wölfen geheult hat. Er hat stets gemacht, was alle gemacht haben, und sich nach der Mehrheit gerichtet: Führerschein, Studium, Beruf, Freundin, iPod. In dieser Reihenfolge. Nun soll er plötzlich Vater werden. Doch der Antiheld ergreift die Flucht, um nachzudenken. Verfolgt von städtischen Beamten, der Polizei, den Reportern eines regionalen Hörfunksenders und seinen eigenen Ängsten, stürzt er sich in pointenreiche Analysen des Weltzustandes... Datum: 30.10. bis 01.1., Uhrzeit: 20.00 Uhr, Ort: Kinopolis",
          "— [TFT ZJw Ja"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Geschlossene Gesellschaft: Drama von Jean-Paul-Sartre",
          "Drei Personen, ein Mann und zwei Frauen, werden nach ihrem Tod in einem Zimmer eingesperrt, das keiner der drei jemals wieder verlassen und niemand anderes je betreten wird: Der Ort des Geschehens ist die Hölle. Alle drei sind sich bewusst, dass sie sich in der Hölle befinden, und machen sich auf das Schlimmste gefasst, aber die erwartete Folter und die körperlichen Qualen stellen sich nicht ein, nur eine leichte Hitze ist zu verspüren. Tastend versuchen Sie, voneinander den Grund für die Höllenfahrt zu erfahren, ohne jedoch ihre eigene Schuld zu offenbaren.",
          "Datum: O1... Uhrzeit: 20.00 Uhr, Ort: Euro Theater Central"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Beethovens Bonn Im Dezember 1770 erblickte Ludwig von Beethoven in der Bonngasse 20 das Licht der Welt. Wer ahnte damals, dass mit ihm ein musikalisches Genie geboren wurde, dessen Musik heute in aller Welt bekannt ist? Bis 1792 lebte Beethoven in Bonn, bevor er nach Wien ging und zu einem der berühmtesten Komponisten der Welt wurde. Es werden Orte und Plätze aufgesucht, wo der weltberühmte Komponist wirkte und die faszinierende Einblicke in das Alltagsleben dieses großen Bonners ermöglichen. & Datum: O112. bis 3112., Ort: Touristeninformation 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Radtour am Rhein Hinweis: Diese Tour ist nur von Gruppen auf Anfrage buchbar! Die Fahrräder sind mitzubringen. [ Die Tour wird vom ADFC angeboten und verläuft am Rhein, einem der geschichtsträchtigsten Flüsse der ! Welt. Er symbolisiert wie für viele Rheinanwohner auch für Bonn über Jahrhunderte hinweg bisaufden heutigen Tag die Lebensader der Stadt. Entlang des linksrheinischen Rheinufers sprechen die steinernen 1 Zeitzeugen der Bonner Geschichte für sich, wobei auch die zukunftsweisenden Aspekte der Stadt nicht fi zu kurz kommen. Datum: 01.02. bis 3112, Ort und Uhrzeit: nach Vereinbarung"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Weihnachtsmarkt in Koblenz",
          "Über 100 festlich geschmückte Holzhäuschen, der Duft von Lebkuchen und Glühwein liegt in der Luft, Weihnachtsmelodien erklingen im malerischen Ambiente der historischen Altstadt unweit der Einkaufsstraßen: Das ist der Koblenzer Weihnachtsmarkt 2007. Alles, was das Herz in der Weihnachtszeit begehrte, findet sich hier wieder, denn auch in diesem Jahr warten wieder ein umfangreiches Angebot an Kunsthandwerk und Weihnachtsschmuck und eine riesige Auswahl an Geschenkartikeln auf die Besucher. Abgerundet durch Weihnachtsbäckerei und viele Attraktionen, wird der Besuch auf dem Koblenzer Weihnachtsmarkt zu einem Erlebnis, das Sie sich nicht entgehen lassen sollen.",
          "Datum: 2311. - 2312.,"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Bei Föh und dassind 14 Im Jahr 1 machten sich drei Flöhe aus Deutschland auf den Weg nach Israel, um einmal so richtig zu entspannen. Leider war zu diesem Zeitpunkt eine Volkszählung im vollen Gange und die einzige beernachtungsmöglichkeit fanden sie in einem Stall bei Bethlehem. Dass sie diese Unterkunft auch noch",
          "mit einem kleinen Kind teilen müssten, damit rechnete keiner der drei Flöhe. Und dass dieses Kind auch",
          "noch eine Berühmtheit war, machte die ganze Sache für die drei Flöhe zu einem aufregenden Abenteuer. Dieses neue Kinderstück aus der Feder von Dirk Zimmer erzählt die Weihnachtsgeschichte auf",
          "humorvolle und gefühlvolle Weise aus der Sicht der drei Flöhen.",
          "Datum: 2611. - 22.12., Uhrzeit: jeweils, 15.00 Uhr, Ort: Innenhof des Rathauses,",
          "Alter: ab 5 Jahre"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Whataw Stille Nacht\" trifft Last Christmas’ Gospel umarmt Soul, und Pop küsst Klassik. Als 1997 die Idee entstand, eine Weihnachtsshow zu entwickeln, die die schönsten Weihnachtslieder aller Zeiten und aller Genre in sich vereint, konnte sich keiner so recht vorstellen, dass diese Show einmal zur erfolgreichsten Weihnachtsshow Deutschlands avancieren würde. Seit zehn Jahren begeistert nun die Band Christmast Moments’von Thomas Schwab 8and das Publikum sowohl in den großen Konzerthallen der Republik (unter anderem Arena Trier, Phönixhalle Mainz) als auch vor den Fernsehern (ARD- Ausstrahlungen seit 200% Christmas Moments'trifft mitten ins Herz und konnte in den letzten Jahren mehr als 500.000 Zuschauer begeistern. Datum: 1112., Uhrzeit: 20.00 Uhr, Ort: Rhein-Mosel-Halle"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "be Indgen Bemble Jazz vom Feinsten mit durchaus gewollten konservativen Zügen. Der Trompeter LasseLiindgren isteiner der innovativen Spitzen-Trompeter der aktuellen Jazzszene in Schweden, der in vielen internationalen Bigbands und zusammen mit anderen berühmten Jazzmusikern gespielt hat. Von der Tageszeitung Svenska Dagbladet'wurde er als &iner der kompetentesten Trompetenspieler dieses Landes”",
          "bezeichnet und RandyBrecker schrieb: Es ist so erfrischend, etwas zu hören, was wirklich originell ist! Lass Lindgren, Du bist ein wundervoller Spieler und Komponist! Sein neuestes Projekt ist ein Glaubensbekenntnis an die Kraft und Energie des Jazz mit eigener Handschrift: Lasse Lindgren hat eine virtuose, immer transparente Hingabe zu seinem Instrument. Datum: 11., Uhrzeit 19.00 Uhr,",
          "Ort: Irish Pub im Stadtzentrum"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Unglaublich! 10 Jahre ist es bereits her, seit FÜDIE KATZ wie ein Faustschlag ins Licht der",
          "Bentlichkeit traten und sich binnen kürzester Zeit in die Spitzenriege der deutschen Komiker katapultierten. Heute befinden sich die beiden mit Preisen überhäuften Weltbürger Benno Rex und Karl Salzburger auf dem vorläufigen Höhepunkt ihrer eindrucksvollen Karriere und gelten als die vielseitigsten, kreativsten und für Presse wie Fans schlichtweg lustigsten Komödianten Deutschlands. Ihre Wortschöpfungen und Charaktere erweisen sich immer wieder als richtungsweisende Leitsterne für die gesamte ComedyBranche.",
          "Datum: 5.ll., Uhrzeit: 20.00 Uhr,",
          "Ort: Haus des Kabaretts"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Whatsrietem Gf&jtz",
          "Das Weihnachtsvariete erwartet Sie auch in diesem Jahr mit atemberaubender Akrobatik, traumhafter Fi Jonglage, ergänzt von Livemusikern. Seien Sie dabei und staunen Sie vielleicht mit ihrer Familie, mit 4 ihren Lieblingskollegen oder der ganzen Firma oder einfach nur mit ihrem oder Ihrer Liebsten.",
          "Karl-Heinz Helmschrot hat auch in diesem Jahr wieder eine faszinierende Gruppe von sehr unterschiedlichen Künstlern zusammengestellt. Zum 10-jährigen Jubiläum - 10 Künstler! Nicht zuständig ist er für Ihr leibliches Wohl! Dafür haben die Köche des Cafe Spitz wieder eine"
        ]
      }
    ]
  },
  {
    "id": "12a",
    "title": "Weihnachten, Theater und Musik",
    "sourcePage": 254,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Ihre Schwester interessiert sich für die Biographien großer Musiker. Sie leben Auftritte von herausragenden Musik. Sie lieben künstlerische Vielfalt und Vielseitigkeit und wollen Weihnachten ausgehen. Sie möchten alte und neue Weihnachtslieder hören. Sie möchten mit Ihrer zwölfjährigen Tochter ein altersgerechtes Theaterstück sehen. Sie suchen einen Kinderfilm für ihren kleinen Sohn. Sie suchen für sportliche Sprachkursteilnehmer eine Möglichkeit, Bonn zu zeigen. Sie wollen ihrem Freund, der Tanztheater liebt, eine Eintrittskarte zum Geburtstag schenken. Sie wollen mit ihren Kindern eine etwas andere, eher lustige Seite von Weihnachten erleben. Sie wollen mit Bekannten ausgehen um mal wieder so richtig lachen. In Pollekes elfjährigem Leben scheint im Augenblick etwas falsch zu laufen. Es stört sie ja gar nicht, dass ihre Eltern geschieden sind. Sie hat ihren Papa sehr lieb, und sie hat eine prima Mama. Ihr Lehrer ist eigentlich auch ganz in Ordnung, aber muss der sich gleich in ihre Mama verlieben? Und dann ist Polleke sogar selbst schuld an allem. Aber sie gibt die Hoffnung nicht auf, dass am Ende doch alles gut wird, auch mit Mimun, dem liebsten Jungen auf der ganzen Erde Datum: 01.11., Uhrzeit: 16.00 Uhr, Ort: Theaterwerkstatt, Alter: ab 9 Jahren Rasmus und der Landstreicher Nach dem Kinderbuch von Astrid Lindgren Rasmus ist in einem Kinderheim aufgewachsen, er hat keine Eltern. Eines Tages läuft er davon und will sich Eltern suchen. Die erste Nacht schläft er in einer Scheune im Stroh, und am Morgen entdeckt er neben sich Oskar. Oskar ist ein Landstreicher, der keine Wohnung hat. Zuerst hat Rasmus Angst vor ihm, aber schon bald merkt er, dass Oskar ein prächtiger Mensch ist. Gemeinsam suchen sie Eltern für Rasmus. Doch als sie endlich prima Eltern gefunden haben, da wollen die beiden sich nicht mehr trennen. Datum: 6.11., Uhrzeit: 15.00 Uhr, Ort: Bürgerkino, Alter: ab 5 Jahren Drei Flöhe und das Jesuskind Im Jahr 1 machten sich drei Flöhe aus Deutschland auf den Weg nach Israel, um einmal so richtig zu entspannen. Leider war zu diesem Zeitpunkt eine Volkszählung im vollen Gange und die einzige Übernachtungsmöglichkeit fanden sie in einem Stall bei Bethlehem. Dass sie diese Unterkunft auch noch mit einem kleinen Kind teilen müssten, damit rechnete keiner der drei Flöhe. Und dass dieses Kind auch noch eine Berühmtheit war, machte die ganze Sache für die drei Flöhe zu einem aufregenden Abenteuer. Dieses neue Kinderstück aus der Feder von Dirk Zimmer erzählt die Weihnachtsgeschichte auf humorvolle und gefühlvolle Weise aus der Sicht der drei Flöhen. Datum: 26.11. - 22.12., Uhrzeit: jeweils, 15.00 Uhr, Ort: Innenhof des Rathauses, \"Stille Nacht\" trifft \"Last Christmas\", Gospel umarmt Soul, und Pop küsst Klassik. Als 1997 die Idee entstand, eine Weihnachtsshow zu entwickeln, die die schönsten Weihnachtslieder aller Zeiten und aller Genre in sich vereint, konnte sich keiner so recht vorstellen, dass diese Show einmal zur erfolgreichsten Weihnachtsshow Deutschlands avancieren würde. Seit zehn Jahren begeistert nun die Band \"Christmast Moments\" von Thomas Schwab & Band das Publikum sowohl in den großen Konzerthallen der Republik (unter anderem Arena Trier, Phönixhalle Mainz) als auch vor den Fernsehern (ARD- Ausstrahlungen seit 2004). \"Christmas Moments\" trifft mitten ins Herz und konnte in den letzten Jahren mehr als 500.000 Datum: 11.12., Uhrzeit: 20.00 Uhr, Jazz vom Feinsten mit durchaus gewollten konservativen Zügen. Der Trompeter Lasse Lindgren ist einer der innovativen Spitzen-Trompeter der aktuellen Jazzszene in Schweden, der in vielen internationalen Bigbands und zusammen mit anderen berühmten Jazzmusikern gespielt hat. Von der Tageszeitung \"Svenska Dagbladet\" wurde er als \"einer der kompetentesten Trompetenspieler dieses Landes\" bezeichnet und Randy Brecker schrieb: \"Es ist so erfrischend, etwas zu hören, was wirklich originell ist! Lass Lindgren, Du bist ein wundervoller Spieler und Komponist\". Sein neuestes Projekt ist ein Glaubensbekenntnis an die Kraft und Energie des Jazz mit eigener Handschrift: Lasse Lindgren hat eine virtuose, immer transparente Hingabe zu seinem Instrument. Datum: 1.11., Uhrzeit : 19.00 Uhr, Ort: Irish Pub im Stadtzentrum Unglaublich! 10 Jahre ist es bereits her, seit FÜR DIE KATZ wie ein Faustschlag ins Licht der Öffentlichkeit traten und sich binnen kürzester Zeit in die Spitzenriege der deutschen Komiker katapultierten. Heute befinden sich die beiden mit Preisen überhäuften Weltbürger Benno Rex und Karl Salzburger auf dem vorläufigen Höhepunkt ihrer eindrucksvollen Karriere und gelten als die vielseitigsten, kreativsten und für Presse wie Fans schlichtweg lustigsten Komödianten Deutschlands. Ihre Wortschöpfungen und Charaktere erweisen sich immer wieder als richtungsweisende Leitsterne für die gesamte Comedy-Branche. Datum: 5.11., Uhrzeit: 20.00 Uhr, Weihnachtsvarieté im Café Spitz Das Weihnachtsvarieté erwartet Sie auch in diesem Jahr mit atemberaubender Akrobatik, traumhafter Jonglage, ergänzt von Livemusikern. Seien Sie dabei und staunen Sie vielleicht mit ihrer Familie, mit ihren Lieblingskollegen oder der ganzen Firma oder einfach nur mit ihrem oder Ihrer Liebsten. Karl-Heinz Helmschrot hat auch in diesem Jahr wieder eine faszinierende Gruppe von sehr unterschiedlichen Künstlern zusammengestellt. Zum 10-jährigen Jubiläum - 10 Künstler! Nicht zuständig ist er für Ihr leibliches Wohl! Dafür haben die Köche des Café Spitz internationale Karte zusammengestellt, also freuen Sie sich auf Köstlichkeiten aus aller Welt. Datum: 9.12., Uhrzeit: 21.00 Uhr, Ort: Café Spitz",
    "questions": [
      {
        "num": 11,
        "answer": "e",
        "stem": "Ihre Schwester interessiert sich für die Biographien großer Musiker."
      },
      {
        "num": 12,
        "answer": "j",
        "stem": "Sie leben Auftritte von herausragenden Musik."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Sie lieben künstlerische Vielfalt und Vielseitigkeit und wollen Weihnachten ausgehen."
      },
      {
        "num": 14,
        "answer": "i",
        "stem": "Sie möchten alte und neue Weihnachtslieder hören."
      },
      {
        "num": 15,
        "answer": "a",
        "stem": "Sie möchten mit Ihrer zwölfjährigen Tochter ein altersgerechtes Theaterstück sehen."
      },
      {
        "num": 16,
        "answer": "b",
        "stem": "Sie suchen einen Kinderfilm für ihren kleinen Sohn."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Sie suchen für sportliche Sprachkursteilnehmer eine Möglichkeit, Bonn zu zeigen."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Sie wollen ihrem Freund, der Tanztheater liebt, eine Eintrittskarte zum Geburtstag schenken."
      },
      {
        "num": 19,
        "answer": "h",
        "stem": "Sie wollen mit ihren Kindern eine etwas andere, eher lustige Seite von Weihnachten erleben."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Sie wollen mit Bekannten ausgehen um mal wieder so richtig lachen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Beateıhb In Pollekes elfjährigem eben scheint im Augenblick etwas falsch zu laufen. Es stört sie ja gar nicht, dass ihre Eltern geschieden sind. Sie hat ihren Papa sehr lieb, und sie hat eine prima Mama. Ihr Bhrer ist eigentlich auch ganz in Ordnung, aber muss der sich gleich in ihre Mama ! verliebenUnd dann ist Polleke sogar selbst schuld an allem. Aber sie gibt die Hoffnung nicht auf, dass am Ende doch alles gut wird, auch mit Mimun, dem liebsten Jungen auf der ganzen Erde und im ganzen Weltall... Datum:0lN., Uhrzeit:1MO Uhr, Ort:Theaterwerkstatt, Alter:ab Jahren"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Rsmus und deindsteicher Nach dem Kinderbuch von Astrid Lindgren Rasmus ist in einem Kinderheim aufgewachsen, er hat keine Eltern. Eines Tages läuft er davon und will sich Eltern suchen. Die erste Nacht schläft er in einer Scheune im Stroh, und am",
          "Morgen entdeckt er neben sich Oskar. Oskar ist ein Bndstreicher, der keine Wohnung hat. Zuerst hat Rasmus Angst vor ihm, aber schon bald merkt er, dass Oskar ein prächtiger Mensch",
          "ist. Gemeinsam suchen sie Eltern für Rasmus. Doch als sie endlich prima Eltern gefunden haben, da wollen die beiden sich nicht mehr trennen."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "EEE Claus von Wagner: Im Feld Die Verfilmung des Buches \"Im Feld” handelt von einem jungen Mann, der bisher mit den Wölfen geheult hat. Er hat stets gemacht, was alle gemacht haben, und sich nach der Mehrheit gerichtet: Führerschein, Studium, Beruf, Freundin, iPod. In dieser Reihenfolge. Nun soll er plötzlich Vater werden. Doch der Antiheld ergreift die Flucht, um nachzudenken. Verfolgt von städtischen Beamten, der Polizei, den Reportern eines regionalen Hörfunksenders und seinen eigenen Ängsten, stürzt er sich in pointenreiche Analysen des Weltzustandes... Datum: 30.10. bis 01.1., Uhrzeit: 20.00 Uhr, Ort: Kinopolis a ———— L ——J"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Geschlossene Gesellschaft: Drama von Jean-Paul-Sartre",
          "Drei Personen, ein Mann und zwei Frauen, werden nach ihrem Tod in einem Zimmer eingesperrt, das keiner der drei jemals wieder verlassen und niemand anderes je betreten wird: Der Ort des Geschehens ist die Hölle. Alle drei sind sich bewusst, dass sie sich in der Hölle befinden, und machen sich auf das Schlimmste gefasst, aber die erwartete Folter und die körperlichen Qualen stellen sich nicht ein, nur eine leichte Hitze ist zu verspüren. Tastend versuchen Sie, voneinander den Grund für die Höllenfahrt zu erfahren, ohne jedoch ihre eigene Schuld zu offenbaren.",
          "Datum: O1... Uhrzeit: 20.00 Uhr, Ort: Euro Theater Central"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Beethovens Bonn Im Dezember 1770 erblickte Ludwig von Beethoven in der Bonngasse 20 das Licht der Welt. Wer ahnte damals, dass mit ihm ein musikalisches Genie geboren wurde, dessen Musik heute in aller Welt bekannt ist? Bis 1792 lebte Beethoven in Bonn, bevor er nach Wien ging und zu einem der berühmtesten Komponisten der Welt wurde. Es werden Orte und Plätze aufgesucht, wo der weltberühmte Komponist wirkte und die faszinierende Einblicke in das Alltagsleben dieses großen Bonners ermöglichen. & Datum: O112. bis 3112., Ort: Touristeninformation 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Radtour am Rhein Hinweis: Diese Tour ist nur von Gruppen auf Anfrage buchbar! Die Fahrräder sind mitzubringen. [ Die Tour wird vom ADFC angeboten und verläuft am Rhein, einem der geschichtsträchtigsten Flüsse der ! Welt. Er symbolisiert wie für viele Rheinanwohner auch für Bonn über Jahrhunderte hinweg bisaufden heutigen Tag die Lebensader der Stadt. Entlang des linksrheinischen Rheinufers sprechen die steinernen 1 Zeitzeugen der Bonner Geschichte für sich, wobei auch die zukunftsweisenden Aspekte der Stadt nicht fi zu kurz kommen. Datum: 01.02. bis 3112, Ort und Uhrzeit: nach Vereinbarung"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Weihnachtsmarkt in Koblenz",
          "Über 100 festlich geschmückte Holzhäuschen, der Duft von Lebkuchen und Glühwein liegt in der Luft, Weihnachtsmelodien erklingen im malerischen Ambiente der historischen Altstadt unweit der Einkaufsstraßen: Das ist der Koblenzer Weihnachtsmarkt 2007. Alles, was das Herz in der Weihnachtszeit begehrte, findet sich hier wieder, denn auch in diesem Jahr warten wieder ein umfangreiches Angebot an Kunsthandwerk und Weihnachtsschmuck und eine riesige Auswahl an Geschenkartikeln auf die Besucher. Abgerundet durch Weihnachtsbäckerei und viele Attraktionen, wird der Besuch auf dem Koblenzer Weihnachtsmarkt zu einem Erlebnis, das Sie sich nicht entgehen lassen sollen.",
          "Datum: 2311. - 2312.,"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Bei Föh und dassind RR= Im Jahr 1 machten sich drei Flöhe aus Deutschland auf den Weg nach Israel, um einmal so richtig zu entspannen. Leider war zu diesem Zeitpunkt eine Volkszählung im vollen Gange und die einzige beernachtungsmöglichkeit fanden sie in einem Stall bei Bethlehem. Dass sie diese Unterkunft auch noch",
          "mit einem kleinen Kind teilen müssten, damit rechnete keiner der drei Flöhe. Und dass dieses Kind auch",
          "noch eine Berühmtheit war, machte die ganze Sache für die drei Flöhe zu einem aufregenden Abenteuer. Dieses neue Kinderstück aus der Feder von Dirk Zimmer erzählt die Weihnachtsgeschichte auf",
          "humorvolle und gefühlvolle Weise aus der Sicht der drei Flöhen.",
          "Datum: 2611. - 22.12., Uhrzeit: jeweils, 15.00 Uhr, Ort: Innenhof des Rathauses,",
          "Alter: ab 5 Jahre"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Whataw Stille Nacht\" trifft Last Christmas’ Gospel umarmt Soul, und Pop küsst Klassik. Als 1997 die Idee entstand, eine Weihnachtsshow zu entwickeln, die die schönsten Weihnachtslieder aller Zeiten und aller Genre in sich vereint, konnte sich keiner so recht vorstellen, dass diese Show einmal zur erfolgreichsten Weihnachtsshow Deutschlands avancieren würde. Seit zehn Jahren begeistert nun die Band Christmast Moments’von Thomas Schwab 8and das Publikum sowohl in den großen Konzerthallen der Republik (unter anderem Arena Trier, Phönixhalle Mainz) als auch vor den Fernsehern (ARD- Ausstrahlungen seit 200% Christmas Moments'trifft mitten ins Herz und konnte in den letzten Jahren mehr als 500.000 Zuschauer begeistern. Datum: 1112., Uhrzeit: 20.00 Uhr, Ort: Rhein-Mosel-Halle"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "be Indgen Bemble Jazz vom Feinsten mit durchaus gewollten konservativen Zügen. Der Trompeter LasseLiindgren isteiner der innovativen Spitzen-Trompeter der aktuellen Jazzszene in Schweden, der in vielen internationalen Bigbands und zusammen mit anderen berühmten Jazzmusikern gespielt hat. Von der Tageszeitung Svenska Dagbladet'wurde er als &iner der kompetentesten Trompetenspieler dieses Landes”",
          "bezeichnet und RandyBrecker schrieb: Es ist so erfrischend, etwas zu hören, was wirklich originell ist! Lass Lindgren, Du bist ein wundervoller Spieler und Komponist! Sein neuestes Projekt ist ein Glaubensbekenntnis an die Kraft und Energie des Jazz mit eigener Handschrift: Lasse Lindgren hat eine virtuose, immer transparente Hingabe zu seinem Instrument. Datum: 11., Uhrzeit 19.00 Uhr,",
          "Ort: Irish Pub im Stadtzentrum"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Unglaublich! 10 Jahre ist es bereits her, seit FÜDIE KATZ wie ein Faustschlag ins Licht der",
          "Bentlichkeit traten und sich binnen kürzester Zeit in die Spitzenriege der deutschen Komiker katapultierten. Heute befinden sich die beiden mit Preisen überhäuften Weltbürger Benno Rex und Karl Salzburger auf dem vorläufigen Höhepunkt ihrer eindrucksvollen Karriere und gelten als die vielseitigsten, kreativsten und für Presse wie Fans schlichtweg lustigsten Komödianten Deutschlands. Ihre Wortschöpfungen und Charaktere erweisen sich immer wieder als richtungsweisende Leitsterne für die gesamte ComedyBranche.",
          "Datum: 5.ll., Uhrzeit: 20.00 Uhr,",
          "Ort: Haus des Kabaretts"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Whatsrietem Gf&jtz",
          "Das Weihnachtsvariete erwartet Sie auch in diesem Jahr mit atemberaubender Akrobatik, traumhafter Fi Jonglage, ergänzt von Livemusikern. Seien Sie dabei und staunen Sie vielleicht mit ihrer Familie, mit 4 ihren Lieblingskollegen oder der ganzen Firma oder einfach nur mit ihrem oder Ihrer Liebsten.",
          "Karl-Heinz Helmschrot hat auch in diesem Jahr wieder eine faszinierende Gruppe von sehr unterschiedlichen Künstlern zusammengestellt. Zum 10-jährigen Jubiläum - 10 Künstler! Nicht zuständig ist er für Ihr leibliches Wohl! Dafür haben die Köche des Cafe Spitz wieder eine"
        ]
      }
    ]
  },
  {
    "id": "12b",
    "title": "Weihnachten, Theater und Musik",
    "sourcePage": 257,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11. Sie wollen mit Ihren Kindern eine etwas andere, eher lustige Seite von Weihnachten 12. Sie möchten mit Ihrer zwölfjährigen Tochter ein altersgerechtes Theaterstück besuchen. 13. Sie wollen eine Stadtbesichtigung mit ein wenig Sport verbinden. 14. Sie möchten an einem Abend alte und neue Weihnachtslieder hören. 15. Sie lieben Auftritte von herausragenden Musikern. 16. Sie möchten zusammen mit Ihrem kleinen Neffen einen Kinderfilm sehen. 17. Sie möchten im Dezember essen gehen und ein buntes, künstlerisches Programm 18. Sie wollen Ihrem Freund, der Tanztheater liebt, eine Eintrittskarte zum Geburtstag 19. Ihre Schwester interessiert sich für die Biographien großer Musiker. 20. Sie wollen mit Bekannten ausgehen und mal wieder herzhaft lachen.",
    "questions": [
      {
        "num": 11,
        "answer": "h",
        "stem": "Sie wollen mit Ihren Kindern eine etwas andere, eher lustige Seite von Weihnachten erleben."
      },
      {
        "num": 12,
        "answer": "a",
        "stem": "Sie möchten mit Ihrer zwölfjährigen Tochter ein altersgerechtes Theaterstück besuchen."
      },
      {
        "num": 13,
        "answer": "f",
        "stem": "Sie wollen eine Stadtbesichtigung mit ein wenig Sport verbinden."
      },
      {
        "num": 14,
        "answer": "i",
        "stem": "Sie möchten an einem Abend alte und neue Weihnachtslieder hören."
      },
      {
        "num": 15,
        "answer": "j",
        "stem": "Sie lieben Auftritte von herausragenden Musikern."
      },
      {
        "num": 16,
        "answer": "b",
        "stem": "Sie möchten zusammen mit Ihrem kleinen Neffen einen Kinderfilm sehen."
      },
      {
        "num": 17,
        "answer": "l",
        "stem": "Sie möchten im Dezember essen gehen und ein buntes, künstlerisches Programm genießen."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Sie wollen Ihrem Freund, der Tanztheater liebt, eine Eintrittskarte zum Geburtstag schenken."
      },
      {
        "num": 19,
        "answer": "e",
        "stem": "Ihre Schwester interessiert sich für die Biographien großer Musiker."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Sie wollen mit Bekannten ausgehen und mal wieder herzhaft lachen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Beateıhb In Pollekes elfjährigem eben scheint im Augenblick etwas falsch zu laufen. Es stört sie ja gar nicht, dass ihre Eltern geschieden sind. Sie hat ihren Papa sehr lieb, und sie hat eine prima Mama. Ihr Bhrer ist eigentlich auch ganz in Ordnung, aber muss der sich gleich in ihre Mama ! verliebenUnd dann ist Polleke sogar selbst schuld an allem. Aber sie gibt die Hoffnung nicht auf, dass am Ende doch alles gut wird, auch mit Mimun, dem liebsten Jungen auf der ganzen Erde und im ganzen Weltall... Datum:0lN., Uhrzeit:1MO Uhr, Ort:Theaterwerkstatt, Alter:ab Jahren"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Rsmus und deindsteicher Nach dem Kinderbuch von Astrid Lindgren Rasmus ist in einem Kinderheim aufgewachsen, er hat keine Eltern. Eines Tages läuft er davon und will sich Eltern suchen. Die erste Nacht schläft er in einer Scheune im Stroh, und am",
          "Morgen entdeckt er neben sich Oskar. Oskar ist ein Bndstreicher, der keine Wohnung hat. Zuerst hat Rasmus Angst vor ihm, aber schon bald merkt er, dass Oskar ein prächtiger Mensch",
          "ist. Gemeinsam suchen sie Eltern für Rasmus. Doch als sie endlich prima Eltern gefunden haben, da wollen die beiden sich nicht mehr trennen."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "EEE 1. Claus von Wagner: Im Feld Die Verfilmung des Buches \"Im Feld” handelt von einem jungen Mann, der bisher mit den Wölfen geheult hat. Er hat stets gemacht, was alle gemacht haben, und sich nach der Mehrheit gerichtet: Führerschein, Studium, Beruf, Freundin, iPod. In dieser Reihenfolge. Nun soll er plötzlich Vater werden. Doch der Antiheld ergreift die Flucht, um nachzudenken. Verfolgt von städtischen Beamten, der Polizei, den Reportern eines regionalen Hörfunksenders und seinen eigenen Ängsten, stürzt er sich in pointenreiche Analysen des Weltzustandes... Datum: 30.10. bis 01.1., Uhrzeit: 20.00 Uhr, Ort: Kinopolis",
          "— [TFT ZJw Ja"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Geschlossene Gesellschaft: Drama von Jean-Paul-Sartre",
          "Drei Personen, ein Mann und zwei Frauen, werden nach ihrem Tod in einem Zimmer eingesperrt, das keiner der drei jemals wieder verlassen und niemand anderes je betreten wird: Der Ort des Geschehens ist die Hölle. Alle drei sind sich bewusst, dass sie sich in der Hölle befinden, und machen sich auf das Schlimmste gefasst, aber die erwartete Folter und die körperlichen Qualen stellen sich nicht ein, nur eine leichte Hitze ist zu verspüren. Tastend versuchen Sie, voneinander den Grund für die Höllenfahrt zu erfahren, ohne jedoch ihre eigene Schuld zu offenbaren.",
          "Datum: O1... Uhrzeit: 20.00 Uhr, Ort: Euro Theater Central"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Beethovens Bonn Im Dezember 1770 erblickte Ludwig von Beethoven in der Bonngasse 20 das Licht der Welt. Wer ahnte damals, dass mit ihm ein musikalisches Genie geboren wurde, dessen Musik heute in aller Welt bekannt ist? Bis 1792 lebte Beethoven in Bonn, bevor er nach Wien ging und zu einem der berühmtesten Komponisten der Welt wurde. Es werden Orte und Plätze aufgesucht, wo der weltberühmte Komponist wirkte und die faszinierende Einblicke in das Alltagsleben dieses großen Bonners ermöglichen. & Datum: O112. bis 3112., Ort: Touristeninformation 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Radtour am Rhein Hinweis: Diese Tour ist nur von Gruppen auf Anfrage buchbar! Die Fahrräder sind mitzubringen. [ Die Tour wird vom ADFC angeboten und verläuft am Rhein, einem der geschichtsträchtigsten Flüsse der ! Welt. Er symbolisiert wie für viele Rheinanwohner auch für Bonn über Jahrhunderte hinweg bisaufden heutigen Tag die Lebensader der Stadt. Entlang des linksrheinischen Rheinufers sprechen die steinernen 1 Zeitzeugen der Bonner Geschichte für sich, wobei auch die zukunftsweisenden Aspekte der Stadt nicht fi zu kurz kommen. Datum: 01.02. bis 3112, Ort und Uhrzeit: nach Vereinbarung"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Weihnachtsmarkt in Koblenz",
          "Über 100 festlich geschmückte Holzhäuschen, der Duft von Lebkuchen und Glühwein liegt in der Luft, Weihnachtsmelodien erklingen im malerischen Ambiente der historischen Altstadt unweit der Einkaufsstraßen: Das ist der Koblenzer Weihnachtsmarkt 2007. Alles, was das Herz in der Weihnachtszeit begehrte, findet sich hier wieder, denn auch in diesem Jahr warten wieder ein umfangreiches Angebot an Kunsthandwerk und Weihnachtsschmuck und eine riesige Auswahl an Geschenkartikeln auf die Besucher. Abgerundet durch Weihnachtsbäckerei und viele Attraktionen, wird der Besuch auf dem Koblenzer Weihnachtsmarkt zu einem Erlebnis, das Sie sich nicht entgehen lassen sollen.",
          "Datum: 2311. - 2312.,"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Bei Föh und dassind 14 Im Jahr 1 machten sich drei Flöhe aus Deutschland auf den Weg nach Israel, um einmal so richtig zu entspannen. Leider war zu diesem Zeitpunkt eine Volkszählung im vollen Gange und die einzige beernachtungsmöglichkeit fanden sie in einem Stall bei Bethlehem. Dass sie diese Unterkunft auch noch",
          "mit einem kleinen Kind teilen müssten, damit rechnete keiner der drei Flöhe. Und dass dieses Kind auch",
          "noch eine Berühmtheit war, machte die ganze Sache für die drei Flöhe zu einem aufregenden Abenteuer. Dieses neue Kinderstück aus der Feder von Dirk Zimmer erzählt die Weihnachtsgeschichte auf",
          "humorvolle und gefühlvolle Weise aus der Sicht der drei Flöhen.",
          "Datum: 2611. - 22.12., Uhrzeit: jeweils, 15.00 Uhr, Ort: Innenhof des Rathauses,",
          "Alter: ab 5 Jahre"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Whataw Stille Nacht\" trifft Last Christmas’ Gospel umarmt Soul, und Pop küsst Klassik. Als 1997 die Idee entstand, eine Weihnachtsshow zu entwickeln, die die schönsten Weihnachtslieder aller Zeiten und aller Genre in sich vereint, konnte sich keiner so recht vorstellen, dass diese Show einmal zur erfolgreichsten Weihnachtsshow Deutschlands avancieren würde. Seit zehn Jahren begeistert nun die Band Christmast Moments’von Thomas Schwab 8and das Publikum sowohl in den großen Konzerthallen der Republik (unter anderem Arena Trier, Phönixhalle Mainz) als auch vor den Fernsehern (ARD- Ausstrahlungen seit 200% Christmas Moments'trifft mitten ins Herz und konnte in den letzten Jahren mehr als 500.000 Zuschauer begeistern. Datum: 1112., Uhrzeit: 20.00 Uhr, Ort: Rhein-Mosel-Halle"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "be Indgen Bemble Jazz vom Feinsten mit durchaus gewollten konservativen Zügen. Der Trompeter LasseLiindgren isteiner der innovativen Spitzen-Trompeter der aktuellen Jazzszene in Schweden, der in vielen internationalen Bigbands und zusammen mit anderen berühmten Jazzmusikern gespielt hat. Von der Tageszeitung Svenska Dagbladet'wurde er als &iner der kompetentesten Trompetenspieler dieses Landes”",
          "bezeichnet und RandyBrecker schrieb: Es ist so erfrischend, etwas zu hören, was wirklich originell ist! Lass Lindgren, Du bist ein wundervoller Spieler und Komponist! Sein neuestes Projekt ist ein Glaubensbekenntnis an die Kraft und Energie des Jazz mit eigener Handschrift: Lasse Lindgren hat eine virtuose, immer transparente Hingabe zu seinem Instrument. Datum: 11., Uhrzeit 19.00 Uhr,",
          "Ort: Irish Pub im Stadtzentrum"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Unglaublich! 10 Jahre ist es bereits her, seit FÜDIE KATZ wie ein Faustschlag ins Licht der",
          "Bentlichkeit traten und sich binnen kürzester Zeit in die Spitzenriege der deutschen Komiker katapultierten. Heute befinden sich die beiden mit Preisen überhäuften Weltbürger Benno Rex und Karl Salzburger auf dem vorläufigen Höhepunkt ihrer eindrucksvollen Karriere und gelten als die vielseitigsten, kreativsten und für Presse wie Fans schlichtweg lustigsten Komödianten Deutschlands. Ihre Wortschöpfungen und Charaktere erweisen sich immer wieder als richtungsweisende Leitsterne für die gesamte ComedyBranche.",
          "Datum: 5.ll., Uhrzeit: 20.00 Uhr,",
          "Ort: Haus des Kabaretts"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Whatsrietem Gf&jtz",
          "Das Weihnachtsvariete erwartet Sie auch in diesem Jahr mit atemberaubender Akrobatik, traumhafter Fi Jonglage, ergänzt von Livemusikern. Seien Sie dabei und staunen Sie vielleicht mit ihrer Familie, mit 4 ihren Lieblingskollegen oder der ganzen Firma oder einfach nur mit ihrem oder Ihrer Liebsten.",
          "Karl-Heinz Helmschrot hat auch in diesem Jahr wieder eine faszinierende Gruppe von sehr unterschiedlichen Künstlern zusammengestellt. Zum 10-jährigen Jubiläum - 10 Künstler! Nicht zuständig ist er für Ihr leibliches Wohl! Dafür haben die Köche des Cafe Spitz wieder eine"
        ]
      }
    ]
  },
  {
    "id": "13",
    "title": "Auslandsaufenthalt, Au-pair und Austausch",
    "sourcePage": 258,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "x",
        "stem": "Sie suchen ein Au-pair-Mädchen, das im Haushalt heifen und mit ihren Kindern Englisch sprechen soll."
      },
      {
        "num": 12,
        "answer": "c",
        "stem": "Ihre 14-jährige Nichte möchte sich über einen Auslandsaufenthalt informieren"
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Ihr Sohn möchte als Koch im Ausland arbeiten. Er sucht nach einer passenden Stelle."
      },
      {
        "num": 14,
        "answer": "g",
        "stem": "Eine französische Bekannte ist Übersetzerin und möchte gelegentlich arbeiten."
      },
      {
        "num": 15,
        "answer": "f",
        "stem": "Ihre kinderlose Nachbarsfamilie möchte für einige Zeit einen jungen Menschen aufnehmen."
      },
      {
        "num": 16,
        "answer": "d",
        "stem": "Sie sollen die neue Webseite Ihrer Firma ins Englische übersetzen lassen."
      },
      {
        "num": 17,
        "answer": "h",
        "stem": "Sie kochen gerne und suchen nach Rezepten aus anderen Ländern."
      },
      {
        "num": 18,
        "answer": "e",
        "stem": "Im Herbst beginnt Ihre Tochter ein Studium. Sie möchte ein Bankkonto eröttnen."
      },
      {
        "num": 19,
        "answer": "a",
        "stem": "Sie wollen Geld nach Kanada überweisen. Sie möchten wissen, wie viel Sie für die Überweisung bezahlen"
      },
      {
        "num": 20,
        "answer": "b",
        "stem": "Ei Freund aus Salzburg will sich in Frankreich bewerben. Er möchte seine Zeugnisse übersetzen lassen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "infos zur Auslandsüberweisung Bitte verwenden Sie die Funktion Auslandsüberweiung für Zahlungen in Länder, die nicht zum SEPA -Zahlungsraum gehören, Zum SEPA-Zahlungrum gehören die Mitgliedsstaaten der Europäischen Union sowie die Länder Island, Norwegen, Liechtenstein, die Schweiz und Monaco. In diesem Raum gilt die Inlandsüberweisungen. Bürgerinnen und Bürger können damit günstiger überweisen. Für alle anderen Länder gilt die Auslandsüberweisung. Bitte beachten Sie, dass bei Ausindsüberweisungen in der Regel Spesen zu zahlen sind. Für nähere 1} Auskünfte über deren Höhe wenden Sie sich bitte direkt an die Kundenbetreuung Kontakt Run un"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Französische Muttersprachler",
          "bieten Übersetzungenen Deutsch-Französisch und Englisch-Französisch von",
          "+ Schulzeugnissen, Lebensläufen, Bewerbungen (Anschreiben & Motivationsschreiben)",
          "»Arbeitszeugnissen usw.",
          "»Arbeitsverträgen",
          "Versicherungsverträgen",
          "» Auf Wunsch erstellen wir Ihre Jobanzeigen für den französischsprachigen Raum angepasst an die jeweils landesübliche Anzeigengestaltung.",
          "Einwandfreie Qualität; schnell, garantiert termingerecht und zu einem fairen Preis. Kostenvoranschläge innerhall von zwei Tagen Standort Wien, Lieferungen innerhalb der EU."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "SEE EEE ‚aber auch Länder auf einem anderen Kontinent, wie zum Beispiel Amerika oder Australien. In dem Land deiner Wahl ‚du bei einer Gastfamilie. Du besuchst die reguläre Schule, gemeinsam mit Schülerinnen und Schülern aun deinem jastland. So lernst du die Lebensweise und die Traditionen anderer Menschen kennen. Natürlich lernat du auch die Sprı Ideines Gastlandes. Wir bieten Informationsveranstaltungen in allen Bundeslanädern an. Dort beantworten wir alle deine Fragen. Schau doch einfach bei —esÖJ}$"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "‚Als gebürtige Engländerin, mit einem Studienabschluss in Englisch, lebe ich seit vielen Jahren in Österreich. Ich biete Übersetzungen vom Deutschen ins Englische an: Lebensläufe, Ausbildungsunteriagen, Präsentationen, Websites, Produktbeschreibungen, Firmenflyer usw Ich habe 20 Jahre Erfahrung mit Übersetzungen. Zu meinen zufriedenen Kunden zählen namhafte",
          "Unternehmen aus dem In- und Ausland Auf Wunsch schicke ich Ihnen gerne eine Liste mit Referenzen zu Wenn es einmal besonders schnell gehen muss, übernehme ich Expressarbeiten auch an Wochenenden Effizient und zu einem angemessenen Preis.susan@language.at www.susanlanguage.at"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Mit einem Konto bei der RUFA profitieren Sie von attraktiven Angeboten und von persönlicher Beratung. Wir haben das passende Konto für Sie - vom Girokonto bis zum Gratiskonto für Jugendliche. Jetzt aktuell: GRATIS Studentenkonto.",
          "Ihnen steht ein persönlicher Berater zur Seite, wenn Sie Auskunft oder Hilfe brauchen. Zusätzlich bietet Ihnen das Konto einige Vorteile, z. B. eine gratis Unfallversicherung bis 24 Jahre. Mit Ihrer RUFA-Clubkarte bekommen Sie außerdem Ermäßigungen in ausgewählten Shops und bei beötimmten Veranstaltungen"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Wir laden Sie dazu ein, internationale Schülerinnen und Schüler bei Ihnen aufzunehmen. Dabei bieten Sie einem jungen Menschen mehr als nur einen Platz zum Schlafen und etwas zu essen. Sie helfen ihm, sich in einer fremden % Umgebung zurechtzufinden, andere Sitten und Gebräuche und eine fremde Sprache kennenzulernen. Eine Gastschülerin oder einen Gastschüler aufzunehmen ist eine wunderbare Möglichkeit, selbst eine andere Kultur kennenzulernen und ’ gleichzeitig die eigene Kultur zu teilen. Im Alltag können Sie gemeinsam kulturelle Unterschiede entdecken und schätzen lernen. Egal ob Sie selbst Kinder haben, allein oder in einem klassischen Familienhaushalt leben: Wir freuen uns auf Ihre = Bewerbung!"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "'ranzösi: ? Wir eine in inen Mitarbeiter für Übersetzungen vom Deutschen ins Französischen. Sie arbeiten fallweise und von zu Hause aus (keine feste Ansteilung)",
          "Ihr Aufgabenbereich: as von einfachen , kurzen Texten(Anfragen, Beantwortung von ‚Anfragen, Reaktion auf Beschwerden usw. Wenn nötig , führen Sie auch kurze Telefonate mit französischen Kundinnen oder Kunden. Sie werden von uns eingearbeitet .Sie lernen unsere Produkte und das Fachvokabular anhand zweisprachiger Unterlagen kennen. Bei Fragen stehen Ihnen unsere Mitarbeiter gerne zur Verfügung. Interessiert? Wir freuen uns auf Ihre Orline-Bewerbung"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Ein Tag im Zeichen der guten Nachbarschaft",
          "Im Rahmen des europäischen Nachbarschaftstages wurde auch heuer wieder in unserem Bezirk zu gemeinsamem Kochen und Genießen eingeladen.",
          "Solche Veranstaltungen dienen dazu, andere Menschen und Kulturen besser kennenzulernen.",
          "Wie auch in den vergangenen Jahren wurde das Fest wieder sehr gut aufgenommen. Die Veranstalter hielten begeisterte Mails. Da viele Leute die zahlreichen Spezialitäten aus aller Welt nach kochen möchten, finden Sie hier unser Online- Kochbuch"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Konto-Neuheiten Mit der neuen BaZa-App erledigen Sie Ihre Bankgeschäfte, wann und wo Sie wollen. Für die schnelle 1 Überweisung unterwegs, mit ein paar Klicks: Geben Sie einfach den Namen Ihres Baza-Kontaktes an, alles andere erledigt die App für Sia. Oder per Smartphone-Kamera: Se fotografieren einen Zahischein, und die App erfasst die Daten automatisch Mit der App können Sie auch direkt mit Ihrer Kundenbetreuerin oder Ihrem Kundenbetreuer Kontakt aufnehmen eine Nachricht schicken, einen Termin vereinbaren oder um einen Rückruf bitten. Für alle, die schon ein BaZa-Konto haben: jetzt die neue App herunterladen! Zum Download"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Seit einigen Jahren bietet die Volkshochschule Laiendolmetscherinnen und Laiendolmetscher an, die r fremdsprachigen Eltern den Kontakt mit der Schule erleichtern sollen. Das Angebot soll dazu beitragen, die Beziehungen zwischen Eltern, Lehrerinnen und Lehrern sowie der Schulleitung zu verbessern. Das Ziel ist ein besseres Miteinander und mehr Verständnis füreinander. Die Laiendolmetscher werden von der VHS aufihre Aufgabe vorbereitet",
          "Momentan bietet die VHS Laiendolmetscher in den Sprachen Albanisch, Bosnisch, Kroatisch, Serbisch, Slowakisch, Rumänisch, Türkisch, Spanisch und allenisch an. In Zukunft sol! das Angebot um weitere Sprachen erweitert werden. I"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "{ ] Speziatttäten aus der Küche Viele klassische Gerichte, die in Österreich auf den Tisch kommen, stammen aus den ehemaligen Kronländern der Monarchie: das Schnitzel aus italien, die Palatschinken aus Ungarn, Golatschen und Knödel aus dem heutigen Tschechien. Dazu kommen zahlreiche regionale Spezialitäten wie Kasnudeln aus Kärnten, Steirisches Wurzeifleisch oder Salzburger Nockerl. Dies und vieles mehr können Sie bei einem unserer Kochkurse kennenlernen, Besonders wilkommen sind Menschen, die aus anderen Ländern zu uns gekommen sind. Die Liste der Veranstaltungen finden Sie weiter unten."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "'spartag zur Baı Der Weitspartag wurde am 1. Internationalen Sparkassenkongress in Mailand im Oktober 1924 ins Leben gerufen, um die Bevölkerung zum Sparen zu bringen. Offiziell wird der Weltspartag am 31. Oktober gefeiert, in Österreich manchmal auch am letzten Werktag vor dem 31. Oktober. Denn an diesem speziellen Tag sollen die Banken für Kunden geöffnet haben. Besonders bei Kindern ist der Weltspartag sehr beliebt. Sie erhalten nämlich kleine Geschenke, wenn sie an diesem Tag mit ihrem Sparschwein zur Bank kommen. Aber auch für Erwachsene gibt es am Weltspartag oft besondere Angebote."
        ]
      }
    ]
  },
  {
    "id": "14",
    "title": "Lernen, Auftreten und Ratgeber",
    "sourcePage": 261,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Eine Bekannte interessiert sich für Bücher über den Tennissport. Ein befreundetes Ehepaar steht andauernd unter Stress und möchte wieder mehr Zeit für Eine Bekannte möchte bei ihren Partys eine perfekte Gastgeberin sein. Eine Studentin sucht Informationen, wie sie besser und systematischer lernen kann. Ein Bekannter möchte wissen, welche Botschaften durch Gestik und Mimik transportiert Eine Bekannte möchte ihr äußeres Erscheinungsbild optimieren. Ein Bekannter ist sich noch unsicher, wie er sich bei einem Vorstellungsgespräch am besten Ein Bekannter schreibt an einer Hausarbeit über gesellschaftliche Normen und Verhaltensregeln verschiedener Jahrhunderte. Ein Bekannter möchte Kalligraphie (Schmuckschriften) lernen. Eine Bekannte ist sehr verunsichert, weil sie auf Konferenzen immer wieder Angst hat, frei Im Katalog eines Buchversands finden Sie folgende Angebote: Die Nachfrage nach individueller Farb- und Stilberatung ist groß. Denn wer heute im Geschäfts- wie auch im Privatleben erfolgreich sein möchte, muss sich in Outfit und Benehmen vorteilhaft präsentieren können. Der Leitfaden zeigt Ihnen, wie Sie sich selbst am besten in Szene setzen. Von der passenden und farblich stimmigen Garderobe über Make-up und Accessoires bis zu modernen Umgangsformen. Nutzen Sie also diesen \"Kurs\" als Eintrittskarte in diese reizvolle Welt der Selbstdarstellung. Sie werden garantiert mit einem überzeugenden und gewinnenden persönlichen Auftritt davon profitieren. Die meisten Menschen kennen keine Strategien, wie sie ihr Lernverhalten und die Fähigkeit, sich Informationen zu merken, gezielt trainieren können. Dieses Buch gibt zunächst einen Überblick, wie das menschliche Gedächtnis funktioniert, und bietet dann eine Fülle von Techniken an, mit denen auch Ungeübte sich das Lernen und Arbeiten leichter machen können. Ken Best \"Dein Körper lügt nicht\" Der Körper lügt nicht, Gesten und Gebärden decken die Ebene des Unbewusstsein auf: Wer einen erhobenen Zeigefinger oder eine gerümpfte Nase sieht, versteht sofort, was der Gesprächspartner meint, auch wenn der mit Worten etwas anderes sagt. Dieses Buch gibt einen anschaulichen Überblick über die Signale, die wir ständig mit unserem Körper senden, und hilft uns zu verstehen, was jemand in Wahrheit gerade denkt und meint. Rolph Barth \"Basiswissen: Bewerbungstraining\" Die Konkurrenz auf dem Arbeitsmarkt um immer knapper werdende freie Stellen ist groß. Umso wichtiger ist es zu wissen, wie man sich richtig bewirbt. Dieses Buch gibt Arbeitsuchenden umfassende Informationen zur erfolgreichen Bewerbung und bereitet optimal auf das Vorstellungsgespräch vor. Im Übungsteil werden gute Formulierungen für das Anschreiben und das sichere Auftreten des Bewerbers im Gespräch trainiert. Brigitte Hübner \"Richtig präsentieren\" Dieses Buch ist ein Leitfaden für alle, die Teamsitzungen, Besprechungen, Workshops und Konferenzen durchführen. Anhand vieler praktischer Beispiele erhält der Leser Anregungen zum gekonnten visualisieren, zur gut geplanten und sicher durchgeführten Präsentation und zur effektiv gestalteten Besprechung. Es zeigt, wie durch den Einsatz von Bildern und Grafiken Präsentationen aufgelockert und Informationen besser verstanden werden können. Helga Sinn-Krummacher \"Delfin oder Delphin? So schreibt man das jetzt richtig\" Dieses Trainingsbuch ist für den Arbeitsplatz und für zu Hause gedacht. Auf humorvolle Art werden die neuen Rechtschreibregeln der deutschen Sprache vorgestellt und eingeübt. Es enthält außerdem die neue amtliche Wortliste zur Rechtschreibung und die neuen Erika Tack \"Zeitmanagement\" Viele Menschen wissen nicht mehr, wo Ihnen der Kopf steht. Zu viele Termine und Aufgaben stellen Sie unter ständigen Zeitdruck. Mit Zeitmanagement lernen Sie, wie Sie Ihre Zeit so einteilen können, dass Sie wieder Zeit zum Leben haben. Sie erkennen Ihre persönlichen Zeitdiebe, Sie lernen, Prioritäten und erreichbare Ziele zu setzen. Durch das Führen eines Zeitplanbuchs lernen Sie wieder (und dauerhaft), aus der Zeitfalle herauszukommen.",
    "questions": [
      {
        "num": 11,
        "answer": "d",
        "stem": "Eine Bekannte interessiert sich für Bücher über den Tennissport."
      },
      {
        "num": 12,
        "answer": "l",
        "stem": "Ein befreundetes Ehepaar steht andauernd unter Stress und möchte wieder mehr Zeit für sich und andere haben."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Eine Bekannte möchte bei ihren Partys eine perfekte Gastgeberin sein."
      },
      {
        "num": 14,
        "answer": "b",
        "stem": "Eine Studentin sucht Informationen, wie sie besser und systematischer lernen kann."
      },
      {
        "num": 15,
        "answer": "h",
        "stem": "Ein Bekannter möchte wissen, welche Botschaften durch Gestik und Mimik transportiert werden."
      },
      {
        "num": 16,
        "answer": "a",
        "stem": "Eine Bekannte möchte ihr äußeres Erscheinungsbild optimieren."
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "Ein Bekannter ist sich noch unsicher, wie er sich bei einem Vorstellungsgespräch am besten präsentiert."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "Ein Bekannter schreibt an einer Hausarbeit über gesellschaftliche Normen und Verhaltensregeln verschiedener Jahrhunderte."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Ein Bekannter möchte Kalligraphie (Schmuckschriften) lernen."
      },
      {
        "num": 20,
        "answer": "e",
        "stem": "Eine Bekannte ist sehr verunsichert, weil sie auf Konferenzen immer wieder Angst hat, frei zu sprechen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Die Nachfrage nach individueller Farb- und Stilberatung ist groß. Denn wer heute im Geschäfts- wie auch im Privatleben erfolgreich sein möchte, muss sich in Outfit und Benehmen vorteilhaft präsentieren können. Der Leitfaden zeigt Ihnen, wie Sie sich selbst am besten in Szene setzen. Von der passenden und farblich stimmigen Garderobe über Make-up und Accessoires bis zu modernen Umgangsformen. Nutzen Sie also diesen \"Kurs\" als Eintrittskarte in diese reizvolle Welt der Selbstdarstellung. Sie werden garantiert mit einem überzeugenden und gewinnenden persönlichen Auftritt davon profitieren."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die meisten Menschen kennen keine Strategien, wie sie ihr Lernverhalten und die Fähigkeit,",
          "sich Informationen zu merken, gezielt trainieren können. Dieses Buch gibt zunächst einen",
          "Berblick, wie das menschliche Gedächtnis funktioniert, und bietet dann eine Fülle von",
          "Techniken an, mit denen auch Ungeübte sich das Lernen und Arbeiten leichter machen können. gay Er a u an m a a m zn a Kr N, en je en au vn en ef"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Adolph Freiherr von Knigge – Über den Umgang mit Menschen",
          "ee Dieses erstmals 1788 erschienene Buch handelt von dem Umgang der Menschen miteinander und gibt Ratschläge, wie man sich im Umgang mit Menschen verschiedenster Alters- und Rangstufen richtig verhält. Es definiert, was Gutes und was schlechtes Verhalten ist, und galt so lange Zeit als ein Leitfaden für “richtiges” Benehmen.",
          ""
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Tim Gallwey entwickelte die Theorie vom Tennis-Spiel, das sich im Kopf abspielt. Er zeigt, wie jeder sein Leben frei von Angst und mit Eleganz spielen kann, ohne in Selbstzweifel oder Unkonzentriertheit zu verfallen. Das Gallwey’sche Tennisspiel setzt ungeahnte Energien frei und zeigt das grenzenlose Potential des menschlichen Körpers und Geistes, wenn es darum geht, seine Lebensziele zu verfolgen und zu erreichen."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Jeder Mensch kann seine kommunikativen Möglichkeiten entdecken und damit sein Leben ‘ bereichern. Die Themen des Buches sind: Die Grundlagen der Kommunikation, Rede und Vortrag, Gespräche erfolgreich führen, Sicherheit gewinnen und Redeängste überwinden, ‘ Zeitmanagement für Redner und Konferenzleiter und vieles mehr. ‘ Ein ausführlicher Praxisteil mit zahlreichen Übungen ermöglicht es dem Leser, seine % rhetorischen Fähigkeiten zu trainieren."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Gute Umgangsformen sind wieder \"in\". Aber gilt das auch in der Schule? Auf humorvolle Weise I erzählt die Autorin aus ihrem Alltag als Lehrerin an einer Realschule. Von gutem Benehmen kann da nicht immer die Rede sein - übrigens auch nicht bei den Eltern. f"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Frieder Schulze \"Reden wir miteinander oder aneinander vorbei?\"",
          "Manche Missverständnisse entstehen, wenn Menschen miteinander reden, besonders im privaten Bereich erleben wir das oft. Wenn Kommunikation erfolgreich sein soll, ist die Fähigkeit erforderlich, den anderen zu durchschauen und seelische Vorgänge und menschliche Probleme zu erkennen. Viele Beispiele zeigen, wie psychologische Aspekte menschliche Kommunikation verkomplizieren können und wie man damit am besten klar kommen kann."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Ken Best \"Dein Körper lügt nicht\" Der Körper lügt nicht, Gesten und Gebärden decken die Ebene des Unbewusstsein auf: Wer einen erhobenen Zeigefinger oder eine gerümpfte Nase sieht, versteht sofort, was der Gesprächspartner meint, auch wenn der mit Worten etwas anderes sagt. Dieses Buch gibt einen anschaulichen Überblick über die Signale, die wir ständig mit unserem Körper senden, und hilft uns zu verstehen, was jemand in Wahrheit gerade denkt und meint."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Rolph Barth \"Basiswissen: Bewerbungstraining\" Die Konkurrenz auf dem Arbeitsmarkt um immer knapper werdende freie Stellen ist groß. Umso wichtiger ist es zu wissen, wie man sich richtig bewirbt. Dieses Buch gibt Arbeitsuchenden umfassende Informationen zur erfolgreichen Bewerbung und bereitet optimal auf das Vorstellungsgespräch vor. Im Übungsteil werden gute Formulierungen für das Anschreiben und das sichere Auftreten des Bewerbers im Gespräch trainiert."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Brigitte Hübner \"Richtig präsentieren\" Dieses Buch ist ein Leitfaden für alle, die Teamsitzungen, Besprechungen, Workshops und Konferenzen durchführen. Anhand vieler praktischer Beispiele erhält der Leser Anregungen zum gekonnten visualisieren, zur gut geplanten und sicher durchgeführten Präsentation und zur effektiv gestalteten Besprechung. Es zeigt, wie durch den Einsatz von Bildern und Grafiken Präsentationen aufgelockert und Informationen besser verstanden werden können."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Helga Sinn-Krummacher \"Delfin oder Delphin? So schreibt man das jetzt richtig\" Dieses Trainingsbuch ist für den Arbeitsplatz und für zu Hause gedacht. Auf humorvolle Art werden die neuen Rechtschreibregeln der deutschen Sprache vorgestellt und eingeübt. Es enthält außerdem die neue amtliche Wortliste zur Rechtschreibung und die neuen Zeichensetzungsregeln."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Erika Tack \"Zeitmanagement\" Viele Menschen wissen nicht mehr, wo Ihnen der Kopf steht. Zu viele Termine und Aufgaben stellen Sie unter ständigen Zeitdruck. Mit Zeitmanagement lernen Sie, wie Sie Ihre Zeit so einteilen können, dass Sie wieder Zeit zum Leben haben. Sie erkennen Ihre persönlichen Zeitdiebe, Sie lernen, Prioritäten und erreichbare Ziele zu setzen. Durch das Führen eines Zeitplanbuchs lernen Sie wieder (und dauerhaft), aus der Zeitfalle herauszukommen."
        ]
      }
    ]
  },
  {
    "id": "14a",
    "title": "Lernen, Auftreten und Ratgeber",
    "sourcePage": 264,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "d",
        "stem": "Eine Bekannte interessiert sich für Bücher über den Tennissport."
      },
      {
        "num": 12,
        "answer": "l",
        "stem": "Ein befreundetes Ehepaar steht andauernd unter Stress und möchte wieder mehr Zeit für sich und andere haben."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Eine Bekannte möchte ihre Wohnung renovieren und sucht Tipps zu Tapeten und Wandfarben."
      },
      {
        "num": 14,
        "answer": "b",
        "stem": "Eine Studentin sucht Informationen, wie sie besser und systematischer lernen kann."
      },
      {
        "num": 15,
        "answer": "h",
        "stem": "Ein Bekannter möchte wissen, welche Botschaften durch Gestik und Mimik transportiert werden."
      },
      {
        "num": 16,
        "answer": "a",
        "stem": "Eine Bekannte möchte ihren Kleidungsstil verbessern."
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "Ein Bekannter ist sich noch unsicher, wie er sich bei einem Vorstellungsgespräch am besten präsentiert."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "Ein Bekannter schreibt an einer Hausarbeit über Höflichkeit und Benimmregeln in früheren Jahrhunderten"
      },
      {
        "num": 19,
        "answer": "k",
        "stem": "Ein Bekannter möchte lernen ‚wie man gute Geschäftsbriefe schreibt."
      },
      {
        "num": 20,
        "answer": "e",
        "stem": "Eine Bekannte ist sehr verunsichert, weil sie auf Konferenzen immer wieder Angst hat, frei zu sprechen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Monika Wirth – Die „Graue Maus“ ist out.",
          "Die Nachfrage nach individueller Farb- und Stilberatung ist groß. Denn wer heute im Geschäfts- wie auch im Privatleben erfolgreich sein möchte, muss sich in Outfit und Benehmen vorteilhaft j präsentieren können. Der Leitfaden zeigt Ihnen, wie Sie sich selbst am besten inSzene setzen. ! Von der passenden und farblich stimmigen Garderobe über Make-up und Accessoires bis zu ! modernen Umgangsformen. Nutzen Sie also diesen \"Kurs\" als Eintrittskarte in diese reizvolle Welt der Selbstdarstellung. Sie werden garantiert mit einem überzeugenden und gewinnenden persönlichen Auftritt davon profitieren."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "‚Günter Abe ! Strategisch lernen und arbeiten IE mn un nen;",
          "Die meisten Menschen kennen keine Strategien. wie sie ihr Lernverhalten und die Fähigkeit,",
          "sich Informationen zu merken. gezielt trainieren können. Dieses Buch gibt zunächst einen j",
          "Überblick. wie das menschliche Gedächtnis funktioniert. und bietet dann eine Fülle von",
          "Techniken an, mit denen auch Ungeübte sich das Lernen und Arbeiten leichter machen können.",
          "seses esse se ss esse el"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "‚Adolph Freiherr von Knigge Über den Umgang mit Menschen",
          "Dieses erstmals 1788 erschienene Buch handelt von dem Umgang der Menschen miteinander und gibt Ratschläge, wie man sich im Umgang mit Menschen verschiedenster Alters- und Rangstufen richtig verhält. Es definiert, was Gutes und was schlechtes Verhalten ist, und galt so lange Zeit als ein Leitfaden für “richtiges” Benehmen.",
          "—— — a — —"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Tim Gallwey",
          "Das Spiel im Kopf Bestseller - Autor Till Gallwey zeigt , wie jeder sein Leben frei von Angst und mit Eleganz spielen kann ‚ohne in Selbstzweifel oder Unkonzentriertheit zu verfallen . Seine Technik vergleicht er mit einem Tennis - Spiel ‚das sich im Kopf abspielt Dieses setzt ungeahnte Energien frei und zeigt das grenzenlose Potenzial des menschlichen Körpers und Geistes , wenn es darum geht ‚seine Lebensziele zu verfolgen und zu erreichen ."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Hans-Jürgen Hantschel / Paul Krieger – Praxis-Handbuch Rhetorik.",
          "Jeder Mensch kann seine kommunikativen Möglichkeiten entdecken und damit sein Leben 1 bereichern. Die Themen des Buches sind: Die Grundlagen der Kommunikation, Rede und Vortrag. Gespräche erfolgreich führen. Sicherheit gewinnen und Redeängste überwinden. ’ Zeitmanagement für Redner und Konferenzleiter und vieles mehr. j Ein ausführlicher Praxisteil mit zahlreichen Übungen ermöglicht es dem Leser, seine N rhetorischen Fähigkeiten zu trainieren."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Inge Fuchs – Benimm dich richtig!",
          "Gute Umgangsformen sind wieder “in” Aber gilt das auch in der Schule? Auf humorvolle Weise ° erzählt die Autorin aus ihrem Alltag als Lehrerin an einer Realschule. Von gutem Benehmen h kann da nicht immer die Rede sein - übrigens auch nicht bei den Eltern."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Frieder Schulze \"Reden wir miteinander oder aneinander vorbei?”",
          "Manche Missverständnisse entstehen, wenn Menschen miteinander reden. besonders im privaten Bereich erleben wir das oft. Wenn Kommunikation erfolgreich sein soll. ist die Fähigkeit erforderlich, den anderen zu durchschauen und seelische Vorgänge und menschliche Problerne zu erkennen. Viele Beispiele zeigen, wie psychologische Aspekte menschliche Kommunikation verkomplizieren können und wie man damit am besten klar kommen kann."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Ken Best \"Dein Körper lügt nicht”",
          "Der Körper lügt nicht, Gesten und Gebärden decken die Ebene des Unbewusstsein auf: Wer einen erhobenen Zeigefinger oder eine gerümpfte Nase sieht. versteht sofort. was der Gesprächspartner meint. auch wenn der mit Worten etwas anderes sagt. Dieses Buch gibt einen anschaulichen Überblick über die Signale, die wir ständig mit unserem Körper senden. und hilft uns zu verstehen, was jemand in Wahrheit gerade denkt und meint."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Die Konkurrenz auf dem Arbeitsmarkt um immer knapper werdende freie Stellen ist groß. Umso wichtiger ist es zu wissen, wie man sich richtig bewirbt. Dieses Buch gibt Arbeitsuchenden umfassende Informationen zur erfolgreichen Bewerbung und bereitet optimal auf das. Vorstellungsgespräch vor. Im Übungsteil werden gute Formulierungen für das Anschreiben und das sichere Auftreten des Bewerbers im Gespräch trainiert."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Brigitte Hübner \"Richtig präsentieren” Dieses Buch ist ein Leitfaden für alle, die Teamsitzungen. Besprechungen. Workshops und Konferenzen durchführen. Anhand vieler praktischer Beispiele erhält der Leser Anregungen 1} zum gekonnten visualisieren, zur gut geplanten und sicher durchgeführten Präsentation und zur effektiv gestalteten Besprechung. Es zeigt. wie durch den Einsatz von Bildern und Grafiken Präsentationen aufgelockert und Informationen besser verstanden werden können."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Helga Sinn-Krummacher \"Delfin oder Delphin? So schreibt man das jetzt richtig” Dieses Trainingsbuch ist für den Arbeitsplatz und für zu Hause gedacht. Auf humorvolle Art werden die neuen Rechtschreibregeln der deutschen Sprache vorgestellt und eingeübt. Es enthält außerdem die neue amtliche Wortliste zur Rechtschreibung und die neuen Zeichensetzungsregeln."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Erika Tack \"Zeitmanagement\"",
          "Viele Menschen wissen nicht mehr, wo Ihnen der Kopf steht. Zu viele Termine und Aufgaben stellen Sie unter ständigen Zeitdruck. Mit Zeitmanagement lernen Sie, wie Sie Ihre Zeit so einteilen können, dass Sie wieder Zeit zum Leben haben. Sie erkennen Ihre persönlichen Zeitdiebe, Sie lernen. Prioritäten und erreichbare Ziele zu setzen. Durch das Führen eines Zeitplanbuchs lernen Sie wieder (und dauerhaft). aus der Zeitfalle herauszukommen."
        ]
      }
    ]
  },
  {
    "id": "14b",
    "title": "Lernen, Auftreten und Ratgeber",
    "sourcePage": 267,
    "keywords": "Adolph Freiherr von Knigge Über den Umgang mit Menschen Dieses erstmals 1788 erschienene Buch handelt von dem Umgang der Menschen miteinander und gibt Ratschläge. wie man sich im Umgang mit Menschen verschiedenster Alters- und Rangstufen richtig verhält. Es definiert. was Gutes und was schlechtes Verhalten ist. und galt so lange Zeit als ein Leitfaden für \"richtiges· Benehmen. m �as ;piel�m ;o;f Bestseller-Autor Till Gallwey zeigt, wie jeder sein Leben frei von Angst und mit Eleganz spielen kann , ohne in Selbstzweifel oder Un konzentriertheit zu verfallen . Seine Technik vergleicht er mit einem Tennis - Spiel. das sich im Kopf abspielt: Dieses setzt unge ahnte Energien frei und zeigt das grenzen lose Poten2ial des menschlichen Körpers , und Geistes . wenn es darum geht , seine Lebensziele zu verfolgen und zu erreichen . Hans - Jürgen Hantschel / Paul Krieger Praxis - Handbuch Rhetorik Jeder Mensch kann seine kommunikativen Möglichkeiten entdecken und damit sein Leben bereichern. Die Themen des Buches sind: Die Grundlagen der Kommunikation. Rede und Vortrag. Gespräche erfolgreich führen. Sicherheit gewinnen und Redeängste überwinden. Zeitmanagement für Redner und Konferenzleiter und vieles mehr. Ein ausführlicher Praxisteil mit zahlreichen Übungen ermöglicht es dem Leser. seine rhetorischen Fähigkeiten zu trainieren. J,n9e_f �.c�s -�!.\"!�.':\" _ d!Eh_ ri�hJiQ, ! _ , ..... , ... _ .. .. .... .... .. .. .. .. .. .. .. .. .. .. .. .. .. , Gute Umgangsformen sind wieder \"in� Aber gilt das auch in der Schule? Auf humorvolle Weise erzählt die Autorin aus ihrem Alltag als Lehrerin an einer Realschule. Von gutem Benehmen kann da nicht immer die Rede sein - übrigens auch nicht bei den Eltern. ·---------- -- -- --- -------------- - - - - - ----------· G Friede, Schulze \"Reden wir miteinander oder aneinander vorbei?\" Manche Missverständnisse entstehen, wenn Menschen miteinander reden. besonders im privaten Bereich erleben wir das oft. Wenn Kommunikation erfolgreich sein soll. ist die Fähigkeit erforderlich. den anderen zu durchschauen und seelische Vorgänge und menschliche Probleme zu erkennen. Viele Beispiele zeigen, wie psychologische Aspekte menschliche Kommunikation verkomplizieren können und wie man damit am besten klar kommen kann.",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Eine Bekannte möchte ihren Kleidungsstil verbessern."
      },
      {
        "num": 12,
        "answer": "l",
        "stem": "Ein befreundetes Ehepaar steht andauernd unter Stress und möchte wieder mehr Zeit für sich und andere haben."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Eine Bekannte möchte ihre Wohnung renovieren und sucht Tipps zu Tapeten und Wandfarben"
      },
      {
        "num": 14,
        "answer": "b",
        "stem": "Eine Studentin sucht Informationen, wie sie besser und systematischer lernen kann."
      },
      {
        "num": 15,
        "answer": "h",
        "stem": "Ein Bekannter möchte wissen, welche Botschaften durch Gestik und Mimik transportiert werden."
      },
      {
        "num": 16,
        "answer": "d",
        "stem": "Ein Bekannte interessiert sich für Bücher über den Tennissport"
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "Ein Bekannter ist sich noch unsicher, wie er sich bei einem Vorstellungsgespräch am besten präsentiert."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "Ein Bekannter schreibt an einer Hausarbeit über Höflichkeit und Benimmregeln in früheren Jahrhunderten"
      },
      {
        "num": 19,
        "answer": "k",
        "stem": "Ein Bekannter möchte lernen, wie man gute Geschäftsbriefe schreibt."
      },
      {
        "num": 20,
        "answer": "e",
        "stem": "Eine Bekannte ist sehr verunsichert, weil sie auf Konferenzen immer wieder Angst hat, frei zu sprechen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "„Monika Wirth Die „Graue Maus“ ist out. Die Nachfrage nach individueller Farb- und Stilberatung ist groß. Denn wer heute im Geschäfts- wie auch im Privatleben erfolgreich sein möchte, muss sich in Outfit und Benehmen vorteilhaft präsentieren können. Der Leitfaden zeigt Ihnen. wie Sie sich selbst am besten in Szene setzen. Von der passenden und farblich stimmigen Garderobe über Make-up und Accessoires bis zu ! modernen Umgangsformen. Nutzen Sie also diesen \"Kurs\" als Eintrittskarte in diese reizvolle Welt der Selbstdarstellung. Sie werden garantiert mit einem überzeugenden und gewinnenden persönlichen Auftritt davon profitieren."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Günter Abe ! Strategisch lernen und arbeiten",
          "nen ces... ,-j3 Die meisten Menschen kennen keine Strategien, wie sie ihr Lernverhalten und die Fähigkeit, sich Informationen zu merken, gezielt trainieren können. Dieses Buch gibt zunächst einen Überblick. wie das menschliche Gedächtnis funktioniert. und bietet dann eine Fülle von Techniken an, mit denen auch Ungeübte sich das Lernen und Arbeiten leichter machen können. ses es este, ==8el"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Adolph Freiherr von Knigge Über den Umgang mit Menschen Dieses erstmals 1788 erschienene Buch handelt von dem Umgang der Menschen miteinander und gibt Ratschläge. wie man sich im Umgang mit Menschen verschiedenster Alters- und Rangstufen richtig verhält. Es definiert. was Gutes und was schlechtes Verhalten ist. und galt so lange Zeit als ein Leitfaden für \"richtiges· Benehmen."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Tim Gallwey: Das Spiel im Kopf Bestseller-Autor Till Gallwey zeigt, wie jeder sein Leben frei von Angst und mit Eleganz spielen kann , ohne in Selbstzweifel oder Unkonzentriertheit zu verfallen . Seine Technik vergleicht er mit einem Tennis-Spiel, das sich im Kopf abspielt: Dieses setzt ungeahnte Energien frei und zeigt das grenzenlose Potenzial des menschlichen Körpers und Geistes . wenn es darum geht , seine Lebensziele zu verfolgen und zu erreichen ."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Hans - Jürgen Hantschel / Paul Krieger Praxis - Handbuch Rhetorik Jeder Mensch kann seine kommunikativen Möglichkeiten entdecken und damit sein Leben bereichern. Die Themen des Buches sind: Die Grundlagen der Kommunikation. Rede und Vortrag. Gespräche erfolgreich führen. Sicherheit gewinnen und Redeängste überwinden. Zeitmanagement für Redner und Konferenzleiter und vieles mehr. Ein ausführlicher Praxisteil mit zahlreichen Übungen ermöglicht es dem Leser. seine rhetorischen Fähigkeiten zu trainieren."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Inge Fuchs – Benimm dich richtig!",
          "Gute Umgangsformen sind wieder “in” Aber gilt das auch in der Schule? Auf humorvolle Weise ‘ erzählt die Autorin aus ihrem Alltag als Lehrerin an einer Realschule. Von gutem Benehmen Y kann da nicht immer die Rede sein - übrigens auch nicht bei den Eltern. a"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Friede, Schulze \"Reden wir miteinander oder aneinander vorbei?\" Manche Missverständnisse entstehen, wenn Menschen miteinander reden. besonders im privaten Bereich erleben wir das oft. Wenn Kommunikation erfolgreich sein soll. ist die Fähigkeit erforderlich. den anderen zu durchschauen und seelische Vorgänge und menschliche Probleme zu erkennen. Viele Beispiele zeigen, wie psychologische Aspekte menschliche Kommunikation verkomplizieren können und wie man damit am besten klar kommen kann."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Ken Best \"Dein Körper lügt nicht\" Der Körper lügt nicht. Gesten und Gebärden decken die Ebene des Unbewusstsein auf: Wer einen erhobenen Zeigefinger oder eine gerümpfte Nase sieht. versteht sofort. was der Gesprächspartner meint, auch wenn der mit Worten etwas anderes sagt. Dieses Buch gibt einen",
          "anschaulichen Überblick über die Signale, die wir ständig mit unserem Körper senden, undhiltt uns zu verstehen, was jemand in Wahrheit gerade denkt und meint."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Rolph Barth \"Basiswissen: Bewerbungstraining” Die Konkurrenz auf dem Arbeitsmarkt um immer knapper werdende freie Stellen ist groß. Umso ! wichtiger ist es zu wissen, wie man sich richtig bewirbt. Dieses Buch gibt Arbeitsuchenden umfassende Informationen zur erfolgreichen Bewerbung und bereitet optimal auf das Vorstellungsgespräch vor. Im Übungsteil werden gute Formulierungen für das Anschreibenund das sichere Auftreten des Bewerbers im Gespräch trainiert."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Brigitte Hübner \"Richtig präsentieren” Dieses Buch ist ein Leitfaden für alle, die Teamsitzungen. Besprechungen. Workshops und Konferenzen durchführen. Anhand vieler praktischer Beispiele erhält der Leser Anregungen zum gekonnten visualisieren, zur gut geplanten und sicher durchgeführten Präsentation und zur effektiv gestalteten Besprechung. Es zeigt. wie durch den Einsatz von Bildern und Grafiken I Präsentationen aufgelockert und Informationen besser verstanden werden können."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Helga Sinn-Krummacher \"Delfin oder Delphin? So schreibt man das jetzt richtig” Dieses Trainingsbuch ist für den Arbeitsplatz und für zu Hause gedacht. Auf humorvolle Art werden die neuen Rechtschreibregeln der deutschen Sprache vorgestellt und eingeübt. Es enthält außerdem die neue amtliche Wortliste zur Rechtschreibung und die neuen Zeichensetzungsregeln."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Erika Tack \"Zeitmanagement\"",
          "Viele Menschen wissen nicht mehr, wo Ihnen der Kopf steht. Zu viele Termine und Aufgaben stellen Sie unter ständigen Zeitdruck. Mit Zeitmanagement lernen Sie, wie Sie Ihre Zeit so einteilen können, dass Sie wieder Zeit zum Leben haben. Sie erkennen Ihre persönlichen Zeitdiebe, Sie lernen. Prioritäten und erreichbare Ziele zu setzen. Durch das Führen eines Zeitplanbuchs lernen Sie wieder (und dauerhaft), aus der Zeitfalle herauszukommen."
        ]
      }
    ]
  },
  {
    "id": "15",
    "title": "Wohnen, Möbel und Familienausflüge",
    "sourcePage": 270,
    "keywords": "C Geschichten fur Kinder Neu Im Programm Klnderbucher schreiben der Basiskurs Klnder sind besondere Leser. Sie wollen Spaß und Spannung erleben und neue Welten ent- decken Das Ist eine große. aber auch schone Herausforderung für Autoren. Unser Baslskllfs vermtllelt das notwendige handwerkliche Konnen dafur. Themen:• kindgerechte Geschichten erzahlen ein Buchkonzept entwickeln· Figuren entwerfen· lllustrauonen für Klnderbucher Veroffenthchung und Verlagssuche Fur Einsteiger und Fortgeschnnene, fLlr ange- hende Kinderbuchautoren und ror alle, die nur mal reinschnuppern möchten. Schreibakademie Konstanz. Info und Kontakt mall@schreibakademte-l<onstanz.de fnT H�lden der Kindheit Pippi Langstrumpf, der kleme Wassermann und viele andere Helden aus Kinderbuchem smd � 1m Hlstonschen Museum zu Gast! Korn- men Sie mit auf eine Entdeckungstour durch die Phantaslewelten der Kmderbuchltteratur des 20. und 21. Jahrhunderts. Ausgestellt werden zahlreiche Ongmalfigu- ren und Requ1srten aus Verfilmungen und Puppenspielen, unter anderem das Fahr- zeug aus ,Robbi, Tobbt und das Fhewatuüt und e1mge Mobel aus der Villa Kunterbunt. Die Ausstellung gibt auch Einblicke m die Arbeit von Kinderbuchautoren. Zahlreiche Spiele laden Kinder und Erwachsene zum Mitmachen em. H1stonsches Museum Kassel, Konrad•ZuseStr. Henrike Derendorf: Das neue Wohnbuch- 1000 Ideen fur ein schönes Zuhause Hier werden Wohnträume wahr! Wie plant man das ideale Wohnzimmer oder ein gemütliches Schlafzimmer und wie macht man das Beste aus kleinen Raumen? Passt die gelbe oder die blaue Tapete besser? Dieses Buch liefert die Antworten, führt in die Kunst der optimalen Raumgestaltung ein und erklärt verschiedene Stilrichtungen. Die Text� sind vielfältig, infor- matIv und enthalten zahlreiche Hinweise von Experten. Ausführliche Produktinformationen und eine Hersteller- sowie Shop-Liste runden das Angebot dieses Wohnratgebers ab. F H�ui� sdl� ;� ;;;o\";ge';; d�nken W;lche Tr;,d; �;rd�n°da; W�h��- l�d; z;;. k�nii (;ag�:; W�e :e�de; v.71� 1� Äit;; ,;be�� ; • ::�f����:Vn a�:����on���;:;:i,��:,:!'u!��e;�����er ;��n���::e�i:::;�:�proJekte : 1 vorgestellt, dJe zeigen , wie man In Zukunft undauch schon heute wohnen und leben kann Referent: Dr. Anton Schroeter • i Montag. 15. 9, 19.30 Uhr Tellnahmegebuhr: 10 {. Anmeld1.1n9 erfor• derflch vhs•Zentrum Am Marktplatz 8 06108 Halle ! ·-------------------------- - - - - - -------- -- - ze, Papagei, Meerschweinchen ... was ist erlaubt? Muss ich den Vermieter fragen, weM' mir ein Haustier anschaffen will? Was soll ,eh tun, wenn die Nachbarn sich beschweren? Solche und ähnliche Fragen stellen sich viele Mieter, die gerne Haustiere hätten. In unserer Vortragsreihe rund um das Mietrecht versuchen wir, sie zu beantworten. Unser nächster Vortrag findet am Dienstag, 7. Juli, um 19 Uhr statt. Die Juristin Dr. Anke Wischnewski spricht über das Thema ,Tiere im Mietrecht\". Volkshochschule Bendorf, Hauptstr. 4, 56170",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Alle Ihre Schränke sind voll mit Sachen und Sie haben kaum mehr Platz in der Wohnung Sie suchen Ideen, wie Sie das ändern können."
      },
      {
        "num": 12,
        "answer": "j",
        "stem": "Eine Bekannte möchte mit ihrer Familie einen Ausflug machen und dabei am liebsten Tiere beobachten"
      },
      {
        "num": 13,
        "answer": "e",
        "stem": "Eine Bekannte zieht um und sucht Tipps zu Einrichtung und Wandfarben."
      },
      {
        "num": 14,
        "answer": "b",
        "stem": "Ihr Bruder sucht ein hochwertiges neues Sofa."
      },
      {
        "num": 15,
        "answer": "l",
        "stem": "Ihr Vater interessiert sich für alte wertvolle Möbel"
      },
      {
        "num": 16,
        "answer": "x",
        "stem": "Ihr Cousine studiert und würde gern in eine Wohngemeinschaft ziehen."
      },
      {
        "num": 17,
        "answer": "g",
        "stem": "Ihre Schwester möchte wissen, ob sie in ihre Mietwohnung einen Hund halten darf."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Ihre Tochter geht zur Schule und sucht einen Praktikumsplatz"
      },
      {
        "num": 19,
        "answer": "d",
        "stem": "Sie möchten eine Ausstellung besuchen, die auch für Ihre Kinder interessant ist."
      },
      {
        "num": 20,
        "answer": "i",
        "stem": "Sie suchen ein Kinderbuch für Ihren siebenjahrigen Sohn. Er möchte gerne mehr über Tiere"
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Das große Aufräumbuch Mit ihrer Aufräummethode hat die aus dem Fernsehen bekannte Wohnberaterin und Bestsellerautorin Mila Komanek das Leben vieler Menschen verändert. Nun hat sie einen neuen, schön illustrierten Ratgeber erstellt. Ihr Tipp: Behalten Sie nur Gegenstände, die Ihnen wichtig sind! Ihre Schritt-für-Schritt-Anleitungen helfen Ihnen dabei, Dinge, die Sie nicht mehr brauchen, auszusortieren und wegzuwerfen: zum Beispiel alte Kleidung und Schuhe, Bücher und Papiere oder Kochutensilien, die nie benutzt werden . Außerdem zeigt Mila Komanek, wie man perfekt} Schubladen und Schränke organisiert. Denn sie ist überzeugt: Durch die richtige Ordnung in der Wohnung wird das ganze Leben leichter. Gebundene Ausgabe: 19 € er NEE EEE"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Einrichtungshaus Unterberg - das exklusive Möbelhaus Im Zentrum der Stadt Hildesheim findet sich auf über 5 Etagen eine exzellente Auswahl erstklassiger moderner Möbel. Wenn Sie Wert auf eine erlesene Wohnungseinrichtung legen, finden Sie bei uns alles nach Ihrem Geschmack. Erleben Sie eine der schönsten Möbelausstellungen Niedersachsens und lassen Sie sich inspirieren. Bei unserer Auswahl an neuen Möbeln legen wir großen Wert auf hervorragende Verarbeitung, beste Materialien und überzeugendes Design. Wir verkaufen Polstermöbel, Wohnzimmereinrichtungen, Garten- und Balkonmöbel, Garderoben und",
          "mehr. Einrichtungshaus Unterberg Neue Straße 8 31134 Hildesheim"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Geschichten für Kinder – Neu im Programm: Kinderbücher schreiben (Der Basiskurs). Kinder sind besondere Leser. Sie wollen Spaß und Spannung erleben und neue Welten entdecken Das Ist eine große. aber auch schone Herausforderung für Autoren. Unser Basiskurs vermittelt das notwendige handwerkliche Können dafür. Themen:• kindgerechte Geschichten erzählen ein Buchkonzept entwickeln· Figuren entwerfen· Illustrationen für Kinderbücher Veröffentlichung und Verlagssuche Fur Einsteiger und Fortgeschnnene, fLlr angehende Kinderbuchautoren und ror alle, die nur mal reinschnuppern möchten. Schreibakademie Konstanz. Info und Kontakt mail@schreibakademie-konstanz.de"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Hlden der Kindheit Pippi Langstrumpf, der kleine Wassermann und viele andere Helden aus Kinderbüchern sind im Historischen Museum zu Gast! Kommen Sie mit auf eine Entdeckungstour durch die Phantasiewelten der Kinderbuchliteratur des 20. und 21. Jahrhunderts. Ausgestellt werden zahlreiche Originalfiguren und Requisiten aus Verfilmungen und Puppenspielen, unter anderem das Fahrzeug aus „Robbi, Tobbi und das Fliewatüüt“ und einige Möbel aus der Villa Kunterbunt. Die Ausstellung gibt auch Einblicke m die Arbeit von Kinderbuchautoren. Zahlreiche Spiele laden Kinder und Erwachsene zum Mitmachen ein. Historisches Museum Kassel, Konrad-Zuse-Str. 3, 34123 Kassel"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Henrike Derendorf: Das neue Wohnbuch- 1000 Ideen für ein schönes Zuhause Hier werden Wohnträume wahr! Wie plant man das ideale Wohnzimmer oder ein gemütliches Schlafzimmer und wie macht man das Beste aus kleinen Räumen? Passt die gelbe oder die blaue Tapete besser? Dieses Buch liefert die Antworten, führt in die Kunst der optimalen Raumgestaltung ein und erklärt verschiedene Stilrichtungen. Die Texte sind vielfältig, informativ und enthalten zahlreiche Hinweise von Experten. Ausführliche Produktinformationen und eine Herstellersowie Shop-Liste runden das Angebot dieses Wohnratgebers ab."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Heute schon an morgen denken Welche Trends werden das Wohnen in der Zukunft prägen? Wie werden wir im Alter leben? Wohngemeinschaften nicht nur für Studenten, sondern auch für Senioren, Mehrgeneratio-nenhäuser oder ganz was anderes? Neue, innovative Wohnkonzepte werden immer wich-tiger. In dem Vortrag werden einige gelungene Wohnprojekte",
          "vorgestellt, die zeigen, wie man in Zukunft und auch schon heute wohnen und leben kann. Referent: Dr. Anton Schroeter ? Montag, 15.9, 19:30 Uhr Teilnahmegebühr: 10 €, Anmeldung erforderlich vhs-Zentrum Am Marktplatz 8 06108 Halle !"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "ze, Papagei, Meerschweinchen ... was ist erlaubt? Muss ich den Vermieter fragen, wenn ich mir ein Haustier anschaffen will? Was soll ich tun, wenn die Nachbarn sich beschweren? Solche und ähnliche Fragen stellen sich viele Mieter, die gerne Haustiere hätten. In unserer Vortragsreihe rund um das Mietrecht versuchen wir, sie zu beantworten. Unser nächster Vortrag findet am Dienstag, 7. Juli, um 19 Uhr statt. Die Juristin Dr. Anke Wischnewski spricht über das Thema ,Tiere im Mietrecht\". Volkshochschule Bendorf, Hauptstr. 4, 56170 Bendorf"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "und erleben spannende Abenteuer. Die liebevoll illustrierten Geschichten vermitteln kindgerecht interessantes Wissen. Wir bieten Praktikanten die Möglichkeit, die verschiedenen Aufgaben im Verlagswesen kennenzulernen, z. B. Pressearbeit, Programmplanung, Lektorat, Marketing, Vertrieb. Wir suchen Studenten (m/w), die im Rahmen eines Praktikums unsere Buchprojekte begleiten wollen. Voraussetzung ist, dass Sie schon mindestens zwei Semester an einer Hochschule studiert haben. Kontakt: Kinderbuchverlag Maus & Sandmann, Schifferstr. 8, 09116 Chemnitz www. maus-und-sandmann.de/praktikum"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Rat mal, wo die Tiere wohnen! Wie schlau sind Bienen? Welche Tiere leben im Garten? Der Zoologe Dirk Gorissen nimmt junge Forscher mit auf eine Entdeckungsreise. Er lädt dazu ein, die Welt der heimischen Tiere zu erkunden - und direkt vor der Haustür damit zu 1 beginnen. Er begleitet uns zu den Tieren im Wald, im Garten, am Wasser und im Haus. Vom Glühwürmchen bis zum Fuchs - man wird eine Menge Neues über Tiere erfahren! Für alle Kinder und Neugierigen ab 6 Jahren - zum Vorlesen und Selberlesen. Gebundenes Buch, 18 €"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Tiere hautnah erleben Bei uns finden heimische Wildtiere, aber auch Exoten aus aller Welt ein artgerechtes Zuhause. Für die kleinen und großen Besucher des Waldzoos gibt es bei einem Rundgang viel zu bestaunen! Gehen Sie auf Tuchfühlung mit unseren Lieblingen! Viele unserer Tiere lassen sich gerne mal streicheln. Auch das Füttern ist hier und da möglich. Sind Sie schon neugierig geworden? Dann nichts wie los! Öffnungszeiten: Dienstag bis Sonntag: 10 bis 18 Uhr Eintritt: Erwachsene 2,50 €, Kinder 2 € Waldzoo Montabaur, Waldstr. 12,56410 Montabaur _ _ __L LU I."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Allst du Tierexperie wer Jann komm ins Fami [rum Linz. fen Ternen wir alles über die Tiere in Haus und Hof und beantworten Fragen wie: Wo schlafen Kühe? Darf ich einen fremden Hund streicheln? Was frisst mein Kaninchen am liebsten? Außerdem machen wir spannende Ausflüge und am Ende bekommst du sogar ein Diplom. Tierärztin Karla Herbst lädt Kinder zwischen 7 und 12 Jahren ein, mehr über die Bedürfnisse von Tieren zu erfahren. Wir freuen uns auf dich! Familienzentrum Linz in Zusammenarbeit mit dem Tierheim Linz, Teilnahmegebühr 4 €, Anmeldung: info@familienzentrum-linz.net"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Wohnen in der Gründerzeit In einer Ausstellung im Schloss Britz erfahren die Besucher alles über die Wohnungseinrichtung in der Gründerzeit. Die originalen Möbel vermitteln anschaulich und lebendig das Wohn- und Lebensgefühl des ausgehenden 19. Jahrhunderts. In der Gründerzeit (1870 bis 1914) entstand eine besondere Wohnkultur. Das aufstrebende Bürgertum wollte seinen neu errungenen Wohlstand in einer repräsentativen Architektur des Hauses und einer luxuriösen Innenausstattung mit hochwertigem Mobiliar zeigen. Öffnungszeiten: dienstags bis sonntags von 11 bis 18 Uhr Eintritt: 3 Euro, ermäßigt 2 Euro, bis 12 Jahre frei Schloss Britz, Alt-Britz 73, 12359 Berlin"
        ]
      }
    ]
  },
  {
    "id": "16",
    "title": "Gesundheit, Ernährung und Schwangerschaft",
    "sourcePage": 273,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Eine Bekannte ist schwanger und sucht Informationen, welche Sportarten erlaubt sind. Ein Bekannter fliegt im Urlaub ans Meer. Sie möchten ihn über mögliche Risiken der Sonnenstrahlung informieren. Ein Bekannter möchte sich modische Schuhe kaufen. Er weiß aber nicht, ob er sich das leisten Sie möchten durch pflanzliche Ernährung Ihren Körper vor schweren Krankheiten schützen. Eine Bekannte, die ein Kind erwartet, sucht Ernährungstipps. Ein älteres Ehepaar sucht Informationen über einen rühigen Urlaub am Meer. Ihre Freundin denkt darüber nach, alle hochhackigen Schuhe wegzuwerfen, weil sie negative Auswirkungen auf ihre Gelenke befürchtet. Eine Freundin hat viel Stress und möchte einen Ausgleich finden, der auch mit sportlichen Aktivitäten verbunden ist. Eine Freundin bekommt ein Baby. Sie hat oft Schmerzen. Welche Möglichkeit gibt es, ihr Ein Bekannter hat oft Kopfschmerzen. Er möchte jedoch keine Tabletten nehmen. Wenn eine schwangere Frau erkrankt oder unter starken Schmerzen leidet, kann sie in den meisten Fällen keine Medikamente einnehmen. Zu groß wäre die Gefahr für das noch ungeborene Kind, denn Schmerzmittel oder Antibiotika können das Baby schädigen. Als Ausweg empfehlen deutsche Ärzte und Krankenkassen daher alternative Heilmethoden wie die Akupuntur. Bei dieser uralten aus China stammenden Heilmethode werden kleine Nadeln in bestimmte Nervenbahnen gestochen. Dabei werden die Nerven gereizt und die Übermittlung von Schmerzsignalen wird gehemmt. Für das Kind besteht keine Gefahr. Eine alte und höchst effektive Methode zur Entspannung ist die Klangmassage. Sie stammt aus Tibet, kann leicht erlernt und jederzeit angewendet werden. Dabei werden tibetanische Klangschalen auf den Körper gesetzt und mit einem weichen Klöppel aus Filz angeschlagen. Die auf diese Weise entstehende Vibration in der Klangschale überträgt sich auf den Körper und vermittelt das Gefühl einer wohltuenden Massage. In der Sonne liegen und eine braune Haut bekommen, das ist nach wie vor ein wichtiges Ziel vieler Urlauber, die ihre Ferien an den Mittelmeerstränden verbringen. An zweiter Stelle stehen sportliche Aktivitäten und Fitnesstraining. Dafür werden sogar Unannehmlichkeiten wie überfüllte Strände, überteuerte Sportangebote und mittelmäßiges Die kulturelle Bildung, der Besuch von Museen und kulturellen Denkmälern in den Urlaubsländern, steht lediglich bei älteren Reisenden hoch im Kurs. Die Fußreflexzonenmassage entwickelte im Jahr 1913 der amerikanische, Arzt William Fitzgerald. Sie beruht auf der Vorstellung, dass bestimmten Regionen an der Fußsohle, an der Fußinnenseite und an den Zehen bestimmte Organe des Körpers zugeordnet sind. Durch die Massage der entsprechenden Reflexzonen am Fuß werden Nervenreize ausgelöst, die Spannungen und Blockaden auflösen, und die Selbstheilungskraft des Korpers wird aktiviert. Besonders bei Problemen mit der Verdauung, bei Kopf- und Rückenschmerzen hat sich die Fußreflexzonenmassage bewährt. Ältere Reisende bevorzugen am Urlaubsziel Ruhe und mäßige Aktivität. Viele reisen deswegen in die Mittelgebirge und verbringen ihren Urlaub mit Wandern und ausgedehnten Spaziergängen in der Natur. Sie legen jedoch auch großen Wert auf eine angenehme und komfortable Unterkunft und auf gutes Essen. Beliebte Reiseziele sind in Deutschland der Schwarzwald, der Bayerische Wald, die Rhön sowie Hunsrück und Eifel. Ins Ausland zieht es die Senioren oft nach Österreich, in die Schweiz oder nach Norditalien. Tai Chi Chuan ist ein alter chinesischer Begriff. Er bedeutet \"über allem stehen\". Beim chinesischen Schattenboxen stehen langsame, weiche und fließende Bewegungen im Einklang mit den natürlichen Bewegungsabläufen des Körpers. Sie führen, wenn sie regelmäßig geübt werden, zu innerer Ruhe und Harmonie, zur Steigerung der Konzentration und der Ausdauer. Ein chinesischer Spruch lautet: \"Wer Tai Chi nutzt, wird beweglich wie ein Kind, stark wie ein Krieger und ruhig wie ein Weiser\". Gute Schuhe müssen nicht unbedingt teuer sein. Zu diesem Ergebnis kommt ein Test, der von einem deutschen Fernsehender durchgeführt wurde. Mehrere Schuh- und Modespezialisten sollten unter ähnlich aussehenden Modellen das jeweils am besten verarbeitete, das schönste und das teuerste Modell herausfinden. Dabei waren jeweils ein Designerschuhpaar, zwei Mittelklassemodelle und zwei Paar aus billigen Schuhketten. Im Ergebnis waren die Spezialisten oft nicht in der Lage, die Qualität zu unterscheiden. In einem Fall wurde sogar das billigste Modell für einen Designerschuh gehalten.",
    "questions": [
      {
        "num": 11,
        "answer": "x",
        "stem": "Eine Bekannte ist schwanger und sucht Informationen, welche Sportarten erlaubt sind."
      },
      {
        "num": 12,
        "answer": "d",
        "stem": "Ein Bekannter fliegt im Urlaub ans Meer. Sie möchten ihn über mögliche Risiken der Sonnenstrahlung informieren."
      },
      {
        "num": 13,
        "answer": "l",
        "stem": "Ein Bekannter möchte sich modische Schuhe kaufen. Er weiß aber nicht, ob er sich das leisten kann."
      },
      {
        "num": 14,
        "answer": "c",
        "stem": "Sie möchten durch pflanzliche Ernährung Ihren Körper vor schweren Krankheiten schützen."
      },
      {
        "num": 15,
        "answer": "e",
        "stem": "Eine Bekannte, die ein Kind erwartet, sucht Ernährungstipps."
      },
      {
        "num": 16,
        "answer": "x",
        "stem": "Ein älteres Ehepaar sucht Informationen über einen rühigen Urlaub am Meer."
      },
      {
        "num": 17,
        "answer": "g",
        "stem": "Ihre Freundin denkt darüber nach, alle hochhackigen Schuhe wegzuwerfen, weil sie negative Auswirkungen auf ihre Gelenke befürchtet."
      },
      {
        "num": 18,
        "answer": "k",
        "stem": "Eine Freundin hat viel Stress und möchte einen Ausgleich finden, der auch mit sportlichen Aktivitäten verbunden ist."
      },
      {
        "num": 19,
        "answer": "a",
        "stem": "Eine Freundin bekommt ein Baby. Sie hat oft Schmerzen. Welche Möglichkeit gibt es, ihr zu helfen?"
      },
      {
        "num": 20,
        "answer": "i",
        "stem": "Ein Bekannter hat oft Kopfschmerzen. Er möchte jedoch keine Tabletten nehmen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Wenn eine schwangere Frau erkrankt oder unter starken Schmerzen leidet, kann sie in den meisten Fällen keine Medikamente einnehmen. Zu groß wäre die Gefahr für das noch ungeborene Kind, denn Schmerzmittel oder Antibiotika können das Baby schädigen. Als Ausweg empfehlen deutsche Ärzte und Krankenkassen daher alternative Heilmethoden wie die Akupuntur. Bei dieser uralten aus China stammenden Heilmethode werden kleine Nadeln in bestimmte Nervenbahnen gestochen. Dabei werden die Nerven gereizt und die Übermittlung von Schmerzsignalen wird gehemmt. Für das Kind besteht keine Gefahr."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "B Eine alte und höchst effektive Methode zur Entspannung ist die Klangmassage. Sie stammt aus Tibet, kann leicht erlernt und jederzeit angewendet werden. Dabei werden tibetanische Klangschalen auf den Körper gesetzt und mit einem weichen Klöppel aus Filz angeschlagen. Die auf diese Weise entstehende Vibration in der Klangschale überträgt sich auf den Körper und vermittelt das Gefühl einer wohltuenden Massage."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Dr nn.",
          "Die regelmäßige Ernährung mit Tomaten senkt das Risiko von Krebserkrankungen um fast",
          "50%. Zu diesem Ergebnis kommen Studien der Harvard University. Für die Schutzwirkung",
          "verantwortlich ist die rote Farbe der Tomaten, die durch den Stoff Lycopin erzeugt wird. Dabei",
          "muss man jedoch beachten, dass die gesundheitsfördernde Wirkung nur eintritt, wenn die",
          "Tomaten gekocht und mit ein wenig Fett, z. B. Olivenöl, serviert werden. Aus rohen Tomaten",
          "kann der Körper das Lycopin nicht verwerten. Spaghetti Bolognese ist demnach gesünder als",
          "Tomatensalat. Tomaten sind in der Mittelmeerküche ein beliebter und unverzichtbarer",
          "Bestandteil. mm bs ——obcbh41/ÖÄ}$[7€_m ,_ ZU] m iü—"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Dass zu langes In-der-Sonne-Liegen nicht gut ist, wissen im Prinzip alle. Trotzdem lassen sich Jahr für Jahr unzählige Touristen an den Stränden des Mittelmeeres in der Sonne rösten, bis sie einen Sonnenbrand oder schlimmstenfalls sogar schwere Verbrennungen bekommen haben. Doch auch der als harmlos geltende leichte Sonnenbrand ist nicht so ungefährlich, wie viele meinen. Deshalb rät die Dermatologische Gesellschaft in Jena allen Sonnenanbetern, sich regelmäßig auf erste Anzeichen von Hautkrebs untersuchen zu lassen. Nur wenn der Krebs im Anfangsstadium entdeckt wird, bestünden gute Heilungsaussichten, so ein Sprecher der Gesellschaft."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "In der Schwangerschaft haben Frauen einen stark erhöhten Bedarf an Vitaminen und Mineralstoffen. Schwangere Frauen sollten daher ihre Nahrung sorgfältig aussuchen und naturbelassene Produkte bevorzugen. Obst, Gemüse und Getreide sollten zu den Grundbausteinen der Ernährung gehören. Milchprodukte, besonders Butter und Sahne, liefern das für den Knochenaufbau des Babys wichtige Calcium. Auch Fleisch sollte auf dem Speiseplan nicht fehlen, da es das für den Blutaufbau wichtige Eisen enthält. Es sollte aber nicht zu fett sein. Auf keinen Fall sollte eine Frau während der Schwangerschaft eine Abmagerungsdiätmachen, der Verlust an Vitaminen und Nährstoffen könnte sich auf die Entwicklung negativ auswirken. 8"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "NE Ist Butter gesünder oder Margarine? Ernährungsberater betonen, dass es hinsichtlich Zusammensetzung und Geschmack keine ! Hinweise darauf gibt, welches der beiden Nahrungsmittel das bessere oder gesündere ist. Da L sowohl Butter als auch Margarine viel Fett enthält, sollten sie sparsam benutzt werden. Insbesondere Personen, die an Fettstottwechselerkrankungen leiden, sollten von beiden Nahrungsmitteln so wenig wie möglich verwenden. Ri"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Damenschuhe mit hohen Absätzen schaden der Gesundheit, insbesondere der Rücken, die Knie und die Wirbelsäule würden geschädigt. So lautete viele Jahre lang das Urteil vieler Orthopäden. Dass es sich hierbei nur um ein Vorurteil handelt, berichtet jetzt die britische Fachzeitschrift \"Ärztliche Praxis”.",
          "In einer Langzeitstudie bewiesen die britischen Forscher, dass die Häufigkeit von Knie- oder Rückenerkrankungen bei Probandinnen, die über mehrere Jahre keine bzw. ausschließlich Schuhe mit hohen Absätzen getragen hatten, nicht verschieden war. Die Höhe der"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "In der Sonne liegen und eine braune Haut bekommen, das ist nach wie vor ein wichtiges Ziel vieler Urlauber, die ihre Ferien an den Mittelmeerstränden verbringen. An zweiter Stelle stehen sportliche Aktivitäten und Fitnesstraining. Dafür werden sogar Unannehmlichkeiten wie überfüllte Strände, überteuerte Sportangebote und mittelmäßiges Essen in Kauf genommen. Die kulturelle Bildung, der Besuch von Museen und kulturellen Denkmälern in den Urlaubsländern, steht lediglich bei älteren Reisenden hoch im Kurs."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Die Fußreflexzonenmassage entwickelte im Jahr 1913 der amerikanische Arzt William Fitzgerald. Sie beruht auf der Vorstellung, dass bestimmten Regionen an der Fußsohle, an der Fußinnenseite und an den Zehen bestimmte Organe des Körpers zugeordnet sind. Durch die Massage der entsprechenden Reflexzonen am Fuß werden Nervenreize ausgelöst, die Spannungen und Blockaden auflösen, und die Selbstheilungskraft des Korpers wird aktiviert. Besonders bei Problemen mit der Verdauung, bei Kopf- und Rückenschmerzen hat sich die Fußreflexzonenmassage bewährt."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Ältere Reisende bevorzugen am Urlaubsziel Ruhe und mäßige Aktivität. Viele reisen deswegen in die Mittelgebirge und verbringen ihren Urlaub mit Wandern und ausgedehnten Spaziergängen in der Natur. Sie legen jedoch auch großen Wert auf eine angenehme und komfortable Unterkunft und auf gutes Essen. Beliebte Reiseziele sind in Deutschland der Schwarzwald, der Bayerische Wald, die Rhön sowie Hunsrück und Eifel. Ins Ausland zieht es die Senioren oft nach Österreich, in die Schweiz oder nach Norditalien."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Tai Chi Chuan ist ein alter chinesischer Begriff. Er bedeutet \"über allem stehen\". Beim chinesischen Schattenboxen stehen langsame, weiche und fließende Bewegungen im Einklang mit den natürlichen Bewegungsabläufen des Körpers. Sie führen, wenn sie regelmäßig geübt werden, zu innerer Ruhe und Harmonie, zur Steigerung der Konzentration und der Ausdauer. Ein chinesischer Spruch lautet: \"Wer Tai Chi nutzt, wird beweglich wie ein Kind, stark wie ein Krieger und ruhig wie ein Weiser\"."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Gute Schuhe müssen nicht unbedingt teuer sein. Zu diesem Ergebnis kommt ein Test, der von einem deutschen Fernsehsender durchgeführt wurde. Mehrere Schuh- und Modespezialisten sollten unter ähnlich aussehenden Modellen das jeweils am besten verarbeitete, das schönste und das teuerste Modell herausfinden. Dabei waren jeweils ein Designerschuhpaar, zwei Mittelklassemodelle und zwei Paar aus billigen Schuhketten. Im Ergebnis waren die Spezialisten oft nicht in der Lage, die Qualität zu unterscheiden. In einem Fall wurde sogar das billigste Modell für einen Designerschuh gehalten."
        ]
      }
    ]
  },
  {
    "id": "17",
    "title": "Ausflüge, Schiffsreisen und Technik",
    "sourcePage": 276,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Sie möchten einen Ganztagesausflug machen und sich dabei bewegen. Sie möchten eine Fahrt durch den Hamburger Hafen buchen. Eine Bekannte organisiert einen großen Kindergeburtstag und braucht Hilfe. Sie interessieren sich für Technikgeschichte. Ein Freund möchte gerne eine Schiffsreise machen. Sie möchten helfen, Ihren Stadtteil zu gestalten. Sie wollen mit einer Bekannten essen gehen. Sie mag amerikanische Küche. Sie sind neu in der Stadt und möchten Ihren Stadtteil kennenlernen. Ein Freund möchte mehr über die Geschichte deutscher Städte erfahren. über die Homepage der VHS gebeten. Sie möchten etwas mit Ihrer 6-jährigen Nichte unternehmen, die gerne ins Museum geht. Ab dem kommenden Monat bietet die Volkshochschule in Zusammenarbeit mit der Bürgerschaft in unserem Stadtteil Führungen an. Alle Interessierten können an fünf Wochenenden den Stadtteil erkunden. Die Führungen richten sich besonders an neue Bürger oder solche, die bald hierher ziehen wollen. Bei den etwa zweistündigen Spaziergängen lernen Sie alle wichtigen Einrichtungen von Behörden über das kulturelle, sportliche und auch das gastronomische Angebot kennen und können auch Kontakte zu anderen knüpfen. Die Teilnahme ist kostenfrei, es wird aber um vorherige Anmeldung Gesunde Ernährung ist wichtig, auch schon für die Kleinen. Nur wer von Anfang an lernt, wie frisches Gemüse und Obst schmecken, wie man mit einfachen Mitteln und auch wenig Zeit leckere Gerichte zubereiten kann, wird sich dauerhaft gesund ernähren. Deshalb bietet die Kochschule “Kochlöffel” ab sofort Kochkurse für Eltern und Kinder ab sechs Jahren an. Die Kurse werden zu unterschiedlichen Tageszeiten angeboten und finden auch schon bei wenigen Anmeldungen statt. Nutzen Sie die Gelegenheit, mit ihrem Kind gemeinsam zu kochen und dabei natürlich auch Spaß zu haben! Infos und Anmeldung: www.kochloeffel-kochschule.eu Nur auf Reisen lernt der Mensch Seit fast fünf Jahrzehnten bietet die überregionale Bildungsakademie “Lernform e.V.” allen interessierten Bürgerinnen und Bürgern Ausflüge zu wichtigen Orten der deutschen Geschichte an. Anlässlich unseres Jubiläums veranstalten wir in den kommenden Monaten nun auch mehrtägige Fahrten in große deutsche Städte, um uns dort mit der Geschichte und Entwicklung der Stadt zu beschäftigen. Die Reisen führen beispielsweise nach Berlin, Köln oder München. Informieren Sie sich jetzt oder buchen Sie sofort unter www.ba-lernform.eu. Die bewegte Geschichte eines Stadtteils Unser Stadtteil kann auf eine bewegte Geschichte zurückblicken. Die Mitarbeiter des Stadtteil-Archivs wollen deshalb ein Buch veröffentlichen, in dem die Geschichte lebendig und für Alt- und Neu-Bürger anschaulich wird. Noch bis Jahresende bittet das Archiv alle Bürger, persönliche Erinnerungen einzureichen, sei es in Form kurzer Geschichten oder in Form von Fotos. Auch historische Zeitungsartikel sind willkommen, da nicht alle Zeitungen im Archiv vorhanden sind. Melden Sie sich einfach persönlich im Archiv am Dreiringplatz. Deutschland aus einer anderen Perspektive Lernen Sie die schönsten deutschen Landschaften vom Fluss aus mit einer unserer Flusskreuzfahrten kennen. Auf geräumigen modernen Schiffen fahren Sie über Rhein, Mosel oder Donau, sehen die wunderschöne Natur längs der Flüsse und besichtigen auch die kleinen Ortschaften bei Ausflügen an Land. Wir haben Angebote für Reisende aller Altersklassen, für Individual- oder Gruppenreisende. Fordern Sie unser Informationsmaterial an unter der Rufnummer 0800/445592. Unser Stadtteil ist lebendig Deshalb planen wir, im kommenden Jahr auf allen Plätzen des Stadtteils ein Fest durchzuführen. Noch stehen wir am Anfang unserer Planung, sammeln Ideen und suchen vor allem weitere Helfer. Wer möchte das Fest und unseren Stadtteil mitgestalten, Ideen entwickeln oder die konkrete Planung übernehmen? Noch ist alles möglich! Wir, die Einwohner unseres Stadtteils, wollen unsere Plätze noch schöner, bunter und lebendiger machen. Wir freuen uns über jeden Helfer, für das Fest und für die Wer mitmachen möchte, kann sich per E-Mail melden bei a.yildrim@online.eu . Technik - spannend und verständlich Sie kennen die typische Kinderfrage: ”Wie geht das?” Oder Sie haben selbst als Kind einmal eine Uhr geöffnet, weil Sie wissen wollten, was darin war. Kinder sind neugierig, Kinder interessieren sich für Technik - und zwar nicht nur, wenn sie damit spielen können. Kinder wollen auch wissen, wie die Sachen funktionieren, aber leider können nicht alle Erwachsenen das gut erklären. Deshalb wurde jetzt in Oberhausen das erste Technik-Museum für Kinder eröffnet. Besucher zwischen 6 und 12 Jahren erfahren dort (natürlich in Begleitung eines Erwachsenen) spielerisch oder bei kindgerechten Führungen alles, was sie über Technik wissen wollen. Informationen: www.technik-museum-oberhausen.de .",
    "questions": [
      {
        "num": 11,
        "answer": "d",
        "stem": "Sie möchten einen Ganztagesausflug machen und sich dabei bewegen."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Sie möchten eine Fahrt durch den Hamburger Hafen buchen."
      },
      {
        "num": 13,
        "answer": "f",
        "stem": "Eine Bekannte organisiert einen großen Kindergeburtstag und braucht Hilfe."
      },
      {
        "num": 14,
        "answer": "c",
        "stem": "Sie interessieren sich für Technikgeschichte."
      },
      {
        "num": 15,
        "answer": "j",
        "stem": "Ein Freund möchte gerne eine Schiffsreise machen."
      },
      {
        "num": 16,
        "answer": "k",
        "stem": "Sie möchten helfen, Ihren Stadtteil zu gestalten."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Sie wollen mit einer Bekannten essen gehen. Sie mag amerikanische Küche."
      },
      {
        "num": 18,
        "answer": "a",
        "stem": "Sie sind neu in der Stadt und möchten Ihren Stadtteil kennenlernen."
      },
      {
        "num": 19,
        "answer": "h",
        "stem": "Ein Freund möchte mehr über die Geschichte deutscher Städte erfahren."
      },
      {
        "num": 20,
        "answer": "l",
        "stem": "Sie möchten etwas mit Ihrer 6-jährigen Nichte unternehmen, die gerne ins Museum geht."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Neues Angebot der VHS Ab dem kommenden Monat bietet die Volkshochschule in Zusammenarbeit mit der Bürgerschaft in unserem Stadtteil Führungen an. Alle Interessierten können an fünf Wochenenden den Stadtteil erkunden. Die Führungen richten sich besonders an neue Bürger oder solche, die bald hierher ziehen wollen. Bei den etwa zweistündigen Spaziergängen lernen Sie alle wichtigen Einrichtungen von Behörden über das kulturelle, sportliche und auch das gastronomische Angebot kennen und können auch Kontakte zu anderen knüpfen. Die Teilnahme ist kostenfrei, es wird aber um vorherige Anmeldung über die Homepage der VHS gebeten."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Essen erleben Gesunde Ernährung ist wichtig, auch schon für die Kleinen. Nur wer von Anfang an lernt, wie frisches Gemüse und Obst schmecken, wie man mit einfachen Mitteln und auch wenig Zeit leckere Gerichte zubereiten kann, wird sich dauerhaft gesund ernähren. Deshalb bietet die Kochschule “Kochlöffel” ab sofort Kochkurse für Eltern und Kinder ab sechs Jahren an. Die Kurse werden zu unterschiedlichen Tageszeiten angeboten und finden auch schon bei wenigen Anmeldungen statt. Nutzen Sie die Gelegenheit, mit ihrem Kind gemeinsam zu kochen und dabei natürlich auch Spaß zu haben! Infos und Anmeldung: www.kochloeffel-kochschule.eu"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "nn Kurzreise nach München Studienreisen Studius bietet Ihnen einen besonderen Ausflug an: Fahren Sie mit unserem modernen Reisebus am frühen Morgen von Köln nach München zum Deutschen Museum und nehmen Sie an einer exklusiven Führung teil, die sich auf die Geschichte der Technik konzentriert. Die Rückreise erfolgt am frühen Abend, so dass Sie in der Nacht wieder in Köln ankommen. Im Reisepreis sind der Eintritt sowie die Führung bereits enthalten. Ohne Übernachtung, daher besonders günstig! Begrenzte Plätze, buchen Sie schnell telefonisch unter 0221/809043 oder über unsere Homepage.",
          "——, A ee )\"- —_,_-—{—„*>"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Entspannung am Wasser",
          "Von März bis September (bei schönem Wetter auch länger) können Sie bei unserem Bootsverleih \"Wasserfall\" das Gefährt Ihrer Wahl ausleihen, um einen unvergesslichen Tag am und auf dem Baldeneysee zu verbringen. Mit einem Ruderboot oder Tretboot können Sie ein wenig Sport treiben und gleichzeitig die Natur genießen. Wenn Ihnen das zu anstrengend ist, können Sie auch ein Motorboot ausleihen. Voraussetzung ist der entsprechende Führerschein. Ausleihfristen: zwischen zwei und zwölf Stunden. Wir bieten auch Rabatte für Gruppen oder regelmäßige Besucher an. Fragen Sie uns einfach! Telefon 0201/7185790"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Als echter Hamburger... ‘ kennt man natürlich den Hafen der Hansestadt und seine Wirtschaftskraft. Für alle Interessierten, die darüber erst noch etwas erfahren wollen, bietet das Bildungszentrum Buxtehude am nächsten Freitag einen zweistündigen Vortrag an, in dem man Wissenswertes über die wirtschaftliche Bedeutung des $ Hamburger Hafens erfährt. Von der Gründung des Freihafens bis zu den heutigen modernen Anlagen wird die spannende Entwicklung des größten deutschen Hafens unter ökonomischen Aspekten dargelegt. Weitere Informationen und Anmeldung im Internet unter www.buxtehude.eu. Fi"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Schiffe versenken, Marmorkuchen und selbstgebastelte Papierhüte Das bietet Ihnen unser Service \"Kinderfeiern leicht gemacht. Mit uns wird jeder Kindergeburtstag zum Erfolg, auch wenn Sie selbst nur wenig Zeit für die Vorbereitung haben. Wir übernehmen auf Wunsch die Dekoration, liefern Speisen und Getränke (beispielsweise Kuchen/Kekse, Salate, Frikadellen und vieles 1 mehr), planen lustige Spiele und bringen auch alles mit, was für die Spiele gebraucht wird. Weitere Informationen unter 01805/713192. f"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Hamburger & Co.",
          "Sie mögen Fast Food? Sie glauben aber, dass Fast Food nicht gesund sein kann? Wir zeigen Ihnen das Gegenteil. Lernen Sie viele Gerichte aus den USA in unserem Kochkurs \"Hamburger & Co! neu kennen. An drei Wochenenden zeigen wir Ihnen, dass man Hamburger auch so zubereitet kann, dass sie gar nicht so viele Kalorien haben. Und schmecken werden sie natürlich auch.",
          "Anmeldung bis nächsten Samstag telefonisch unter 0800/1398700."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Nur auf Reisen lernt der Mensch Seit fast fünf Jahrzehnten bietet die überregionale Bildungsakademie “Lernform e.V.” allen interessierten Bürgerinnen und Bürgern Ausflüge zu wichtigen Orten der deutschen Geschichte an. Anlässlich unseres Jubiläums veranstalten wir in den kommenden Monaten nun auch mehrtägige Fahrten in große deutsche Städte, um uns dort mit der Geschichte und Entwicklung der Stadt zu beschäftigen. Die Reisen führen beispielsweise nach Berlin, Köln oder München. Informieren Sie sich jetzt oder buchen Sie sofort unter www.ba-lernform.eu."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Die bewegte Geschichte eines Stadtteils Unser Stadtteil kann auf eine bewegte Geschichte zurückblicken. Die Mitarbeiter des Stadtteil-Archivs wollen deshalb ein Buch veröffentlichen, in dem die Geschichte lebendig und für Alt- und Neu-Bürger anschaulich wird. Noch bis Jahresende bittet das Archiv alle Bürger, persönliche Erinnerungen einzureichen, sei es in Form kurzer Geschichten oder in Form von Fotos. Auch historische Zeitungsartikel sind willkommen, da nicht alle Zeitungen im Archiv vorhanden sind. Melden Sie sich einfach persönlich im Archiv am Dreiringplatz."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Deutschland aus einer anderen Perspektive Lernen Sie die schönsten deutschen Landschaften vom Fluss aus mit einer unserer Flusskreuzfahrten kennen. Auf geräumigen modernen Schiffen fahren Sie über Rhein, Mosel oder Donau, sehen die wunderschöne Natur längs der Flüsse und besichtigen auch die kleinen Ortschaften bei Ausflügen an Land. Wir haben Angebote für Reisende aller Altersklassen, für Individual- oder Gruppenreisende. Fordern Sie unser Informationsmaterial an unter der Rufnummer 08004/ 455992."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Unser Stadtteil ist lebendig Deshalb planen wir, im kommenden Jahr auf allen Plätzen des Stadtteils ein Fest durchzuführen. Noch stehen wir am Anfang unserer Planung, sammeln Ideen und suchen vor allem weitere Helfer. Wer möchte das Fest und unseren Stadtteil mitgestalten, Ideen entwickeln oder die konkrete Planung übernehmen? Noch ist alles möglich! Wir, die Einwohner unseres Stadtteils, wollen unsere Plätze noch schöner, bunter und lebendiger machen. Wir freuen uns über jeden Helfer, für das Fest und für die Umsetzung unserer Pläne. Wer mitmachen möchte, kann sich per E-Mail melden bei a.yildrim@online.eu ."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Technik - spannend und verständlich Sie kennen die typische Kinderfrage: ”Wie geht das?” Oder Sie haben selbst als Kind einmal eine Uhr geöffnet, weil Sie wissen wollten, was darin war. Kinder sind neugierig, Kinder interessieren sich für Technik - und zwar nicht nur, wenn sie damit spielen können. Kinder wollen auch wissen, wie die Sachen funktionieren, aber leider können nicht alle Erwachsenen das gut erklären. Deshalb wurde jetzt in Oberhausen das erste Technik-Museum für Kinder eröffnet. Besucher zwischen 6 und 12 Jahren erfahren dort n( atürlich in Begleitung eines Erwachsenen) spielerisch oder bei kindgerechten Führungen alles, was sie über Technik wissen wollen. Informationen: www.technik-museum-oberhausen.de ."
        ]
      }
    ]
  },
  {
    "id": "17a",
    "title": "Ausflüge, Schiffsreisen und Technik",
    "sourcePage": 279,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Sie möchten einen Ganztagesausflug machen und sich dabei bewegen. Sie möchten eine Fahrt durch den Hamburger Hafen buchen. Ihr Sohn möchte einen Freier und braucht Hilfe. Sie interessieren sich für Technikgeschichte. Ein Freund möchte gerne eine Schiffsreise machen. Sie möchten helfen, Ihren Stadtteil zu gestalten. Sie wollen mit einer Bekannten essen gehen. Sie mag amerikanische Küche. Sie sind neu in der Stadt und möchten Ihren Stadtteil kennenlernen. Ein Freund möchte mehr über die Geschichte deutscher Städte erfahren. Sie möchten etwas mit Ihrer 6-jährigen Nichte unternehmen, die gerne ins Museum geht.",
    "questions": [
      {
        "num": 11,
        "answer": "d",
        "stem": "Sie möchten einen Ganztagesausflug machen und sich dabei bewegen."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Sie möchten eine Fahrt durch den Hamburger Hafen buchen."
      },
      {
        "num": 13,
        "answer": "f",
        "stem": "Ihr Sohn möchte einen Freier und braucht Hilfe."
      },
      {
        "num": 14,
        "answer": "c",
        "stem": "Sie interessieren sich für Technikgeschichte."
      },
      {
        "num": 15,
        "answer": "j",
        "stem": "Ein Freund möchte gerne eine Schiffsreise machen."
      },
      {
        "num": 16,
        "answer": "k",
        "stem": "Sie möchten helfen, Ihren Stadtteil zu gestalten."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Sie wollen mit einer Bekannten essen gehen. Sie mag amerikanische Küche."
      },
      {
        "num": 18,
        "answer": "a",
        "stem": "Sie sind neu in der Stadt und möchten Ihren Stadtteil kennenlernen."
      },
      {
        "num": 19,
        "answer": "h",
        "stem": "Ein Freund möchte mehr über die Geschichte deutscher Städte erfahren."
      },
      {
        "num": 20,
        "answer": "l",
        "stem": "Sie möchten etwas mit Ihrer 6-jährigen Nichte unternehmen, die gerne ins Museum geht."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Neues Angebot der VHS Ab dem kommenden Monat bietet die Volkshochschule in Zusammenarbeit mit der Bürgerschaft in unserem Stadtteil Führungen an. Alle Interessierten können an fünf Wochenenden den Stadtteil erkunden. Die Führungen richten sich besonders an neue Bürger oder solche, die bald hierher ziehen wollen. Bei den etwa zweistündigen Spaziergängen lernen Sie alle wichtigen Einrichtungen von Behörden über das kulturelle, sportliche und auch das gastronomische Angebot kennen und können auch Kontakte zu anderen knüpfen. Die Teilnahme ist kostenfrei, es wird aber um vorherige Anmeldung über die Homepage der VHS gebeten."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Essen erleben Gesunde Ernährung ist wichtig, auch schon für die Kleinen. Nur wer von Anfang an lernt, wie frisches Gemüse und Obst schmecken, wie man mit einfachen Mitteln und auch wenig Zeit leckere Gerichte zubereiten kann, wird sich dauerhaft gesund ernähren. Deshalb bietet die Kochschule “Kochlöffel” ab sofort Kochkurse für Eltern und Kinder ab sechs Jahren an. Die Kurse werden zu unterschiedlichen Tageszeiten angeboten und finden auch schon bei wenigen Anmeldungen statt. Nutzen Sie die Gelegenheit, mit ihrem Kind gemeinsam zu kochen und dabei natürlich auch Spaß zu haben! Infos und Anmeldung: www.kochloeffel-kochschule.eu"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "nn Kurzreise nach München Studienreisen Studius bietet Ihnen einen besonderen Ausflug an: Fahren Sie mit unserem modernen Reisebus am frühen Morgen von Köln nach München zum Deutschen Museum und nehmen Sie an einer exklusiven Führung teil, die sich auf die Geschichte der Technik konzentriert. Die Rückreise erfolgt am frühen Abend, so dass Sie in der Nacht wieder in Köln ankommen. Im Reisepreis sind der Eintritt sowie die Führung bereits enthalten. Ohne Übernachtung, daher besonders günstig! Begrenzte Plätze, buchen Sie schnell telefonisch unter 0221/809043 oder über unsere Homepage.",
          "——, A ee )\"- —_,_-—{—„*>"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Entspannung am Wasser",
          "Von März bis September (bei schönem Wetter auch länger) können Sie bei unserem Bootsverleih \"Wasserfall\" das Gefährt Ihrer Wahl ausleihen, um einen unvergesslichen Tag am und auf dem Baldeneysee zu verbringen. Mit einem Ruderboot oder Tretboot können Sie ein wenig Sport treiben und gleichzeitig die Natur genießen. Wenn Ihnen das zu anstrengend ist, können Sie auch ein Motorboot ausleihen. Voraussetzung ist der entsprechende Führerschein. Ausleihfristen: zwischen zwei und zwölf Stunden. Wir bieten auch Rabatte für Gruppen oder regelmäßige Besucher an. Fragen Sie uns einfach! Telefon 0201/7185790"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Als echter Hamburger... ‘ kennt man natürlich den Hafen der Hansestadt und seine Wirtschaftskraft. Für alle Interessierten, die darüber erst noch etwas erfahren wollen, bietet das Bildungszentrum Buxtehude am nächsten Freitag einen zweistündigen Vortrag an, in dem man Wissenswertes über die wirtschaftliche Bedeutung des $ Hamburger Hafens erfährt. Von der Gründung des Freihafens bis zu den heutigen modernen Anlagen wird die spannende Entwicklung des größten deutschen Hafens unter ökonomischen Aspekten dargelegt. Weitere Informationen und Anmeldung im Internet unter www.buxtehude.eu. Fi"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Schiffe versenken, Marmorkuchen und selbstgebastelte Papierhüte Das bietet Ihnen unser Service \"Kinderfeiern leicht gemacht. Mit uns wird jeder Kindergeburtstag zum Erfolg, auch wenn Sie selbst nur wenig Zeit für die Vorbereitung haben. Wir übernehmen auf Wunsch die Dekoration, liefern Speisen und Getränke (beispielsweise Kuchen/Kekse, Salate, Frikadellen und vieles 1 mehr), planen lustige Spiele und bringen auch alles mit, was für die Spiele gebraucht wird. Weitere Informationen unter 01805/713192. f"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Hamburger & Co.",
          "Sie mögen Fast Food? Sie glauben aber, dass Fast Food nicht gesund sein kann? Wir zeigen Ihnen das Gegenteil. Lernen Sie viele Gerichte aus den USA in unserem Kochkurs \"Hamburger & Co! neu kennen. An drei Wochenenden zeigen wir Ihnen, dass man Hamburger auch so zubereitet kann, dass sie gar nicht so viele Kalorien haben. Und schmecken werden sie natürlich auch.",
          "Anmeldung bis nächsten Samstag telefonisch unter 0800/1398700."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Nur auf Reisen lernt der Mensch Seit fast fünf Jahrzehnten bietet die überregionale Bildungsakademie “Lernform e.V.” allen interessierten Bürgerinnen und Bürgern Ausflüge zu wichtigen Orten der deutschen Geschichte an. Anlässlich unseres Jubiläums veranstalten wir in den kommenden Monaten nun auch mehrtägige Fahrten in große deutsche Städte, um uns dort mit der Geschichte und Entwicklung der Stadt zu beschäftigen. Die Reisen führen beispielsweise nach Berlin, Köln oder München. Informieren Sie sich jetzt oder buchen Sie sofort unter www.ba-lernform.eu."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Die bewegte Geschichte eines Stadtteils Unser Stadtteil kann auf eine bewegte Geschichte zurückblicken. Die Mitarbeiter des Stadtteil-Archivs wollen deshalb ein Buch veröffentlichen, in dem die Geschichte lebendig und für Alt- und Neu-Bürger anschaulich wird. Noch bis Jahresende bittet das Archiv alle Bürger, persönliche Erinnerungen einzureichen, sei es in Form kurzer Geschichten oder in Form von Fotos. Auch historische Zeitungsartikel sind willkommen, da nicht alle Zeitungen im Archiv vorhanden sind. Melden Sie sich einfach persönlich im Archiv am Dreiringplatz."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Deutschland aus einer anderen Perspektive Lernen Sie die schönsten deutschen Landschaften vom Fluss aus mit einer unserer Flusskreuzfahrten kennen. Auf geräumigen modernen Schiffen fahren Sie über Rhein, Mosel oder Donau, sehen die wunderschöne Natur längs der Flüsse und besichtigen auch die kleinen Ortschaften bei Ausflügen an Land. Wir haben Angebote für Reisende aller Altersklassen, für Individual- oder Gruppenreisende. Fordern Sie unser Informationsmaterial an unter der Rufnummer 08004/ 455992."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Unser Stadtteil ist lebendig Deshalb planen wir, im kommenden Jahr auf allen Plätzen des Stadtteils ein Fest durchzuführen. Noch stehen wir am Anfang unserer Planung, sammeln Ideen und suchen vor allem weitere Helfer. Wer möchte das Fest und unseren Stadtteil mitgestalten, Ideen entwickeln oder die konkrete Planung übernehmen? Noch ist alles möglich! Wir, die Einwohner unseres Stadtteils, wollen unsere Plätze noch schöner, bunter und lebendiger machen. Wir freuen uns über jeden Helfer, für das Fest und für die Umsetzung unserer Pläne. Wer mitmachen möchte, kann sich per E-Mail melden bei a.yildrim@online.eu ."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Technik - spannend und verständlich Sie kennen die typische Kinderfrage: ”Wie geht das?” Oder Sie haben selbst als Kind einmal eine Uhr geöffnet, weil Sie wissen wollten, was darin war. Kinder sind neugierig, Kinder interessieren sich für Technik - und zwar nicht nur, wenn sie damit spielen können. Kinder wollen auch wissen, wie die Sachen funktionieren, aber leider können nicht alle Erwachsenen das gut erklären. Deshalb wurde jetzt in Oberhausen das erste Technik-Museum für Kinder eröffnet. Besucher zwischen 6 und 12 Jahren erfahren dort n( atürlich in Begleitung eines Erwachsenen) spielerisch oder bei kindgerechten Führungen alles, was sie über Technik wissen wollen. Informationen: www.technik-museum-oberhausen.de ."
        ]
      }
    ]
  },
  {
    "id": "18",
    "title": "Studium, Nachhilfe und Umzug",
    "sourcePage": 280,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Sie brauchen Unterstützung in Mathematik und möchten in einer kleinen Gruppe lernen. Sie möchten Physik studieren und möchten sich zunächst informieren. Sie möchten einen Sprachkurs in einem anderen Land machen. Sie möchten in einer anderen Stadt eine Ausbildung machen und suchen dort eine Wohnung. Sie ziehen wegen einer Ausbildung um und suchen so günstig wie möglich Umzugshelfer. Sie sind gerade umgezogen und möchten neue Leute kennenlernen. Sie suchen einen Nachmieter und wollen eine kostenlose Anzeige aufgeben. Sie wollen gerne noch eine Sprache lernen und suchen einen festen Lernpartner. Sie wollen umziehen, haben aber eigentlich gar keine Zeit, sich darum zu kümmern. gibt's weitere Informationen. Sie suchen für eine 18-jährige Bekannte einen bezahlten Job außerhalb von Deutschland. ...kann man in anderen Ländern machen, sondern auch etwas lernen. Die Agentur für Arbeit vermittelt Schülerinnen und Schülern, aber auch Studierenden Praktikumsplätze im Ausland! Nutzt die Gelegenheit, möglichst früh Euren Wunschberuf kennenzulernen, auch wenn Ihr für das Praktikum nicht bezahlt werdet. Meldet euch gleich in der nächsten Filiale oder besucht unsere Homepage, auch dort Du bist gerade “auf dem Sprung”, willst umziehen und suchst noch eine passende Bleibe? Dann haben wir das Richtige für dich: In unserem Internetportal findest du günstige Wohnungen oder WG-Zimmer in zahlreichen Städten Deutschlands - und sogar über die Grenzen Deutschlands hinaus. Unsere Suchfunktion erlaubt es dir, Details einzugeben wie ”maximale Miete”, “zentrale Lage” usw. Schau einfach mal vorbei, die Suche ist natürlich kostenlos! Und noch etwas: Du kannst auch gerne ein Wohnungsangebot bei uns einstellen, wenn du einen Nachmieter oder einen Mitbewohner suchst - für nur 0,49 Euro. Alle Informationen auf einer Seite Die neue Internetseite www.studium.de bietet Ihnen alles rund um das Thema”Studium”. So finden Sie neben Informationen zu allen deutschen Hochschulen auch genaue Beschreibungen aller Studiengänge und -fächer auf auf unserer Webseite. Ob sie etwas Naturwissenschaftliches studieren möchten, etwas Wirtschaftswissenschaftliches, ein Fach mit Bezug zu Kultur oder eine Sprache - bei uns finden Sie alles und erfahren natürlich auch, wo Sie was Und als besonderen Service bieten wir Ihnen auch einen BAföG-Rechner an: Ermitteln sie gleich, ob Ihnen Unterstützung während des Studiums zusteht. Studierende und Auszubildende müssen oft umziehen, ohne dass sie viel Geld dafür hätten. Deshalb haben wir unser Netzwerk “Studis und Azubis ziehen um” gegründet. Bei uns sind viele fleißige Helfer registriert, die gerne beim Umzug helfen: Kisten packen, Möbel abbauen, die Sachen zu neuen Wohnung Und das Beste daran: Es kostet keinen Cent! Wie das funktioniert? Ganz einfach. Registriert euch bei uns - natürlich ebenfalls kostenfrei -, und wenn jemand anders Hilfe braucht, tragt ihr eben auch mal Kartons und baut Möbel auf. Wir helfen uns gegenseitig! Weitere Infos unter: www.umzugshelferlein.eu Ihr seid umgezogen und habt eine Ausbildung oder ein Studium hier in der Stadt begonnen? Ihr sucht neue Kontakte, Leute, mit denen ihr die Freizeit verbringen könnt? Der Verein “Triff dich!” organisiert einmal pro Woche eine Stammtisch für alle, die neue Leute treffen wollen. Kommt einfach vorbei - und wenn es euch nicht gefällt, könnt ihr ja jederzeit wieder gehen! Weitere Informationen sowie den Ort und das genaue Datum für unser nächstes Treffen erhaltet ihr Unser neues Lernprogramm “Sprachenfix” bietet Ihnen die Möglichkeit, eine Sprache zu lernen, wann und wo Sie möchten, ob allein zu Hause oder unterwegs. Das Programm bietet alles, was Sie brauchen: von Erklärungen und Wortschatz über Lesetexte und Hörbeispiele bis hin zu Videos mit kleinen authentischen Szenen aus dem Alltag. Unser Online-Service bietet darüber hinaus Zusatzmaterialien. Auf Wunsch können Sie auch in einem durch Passwort geschützten Bereich Ihre eigenen Texte durch unsere Lehrkräfte korrigieren und Das Programm ist für zahl-reiche Sprachen verfügbar, sprechen Sie uns an. Sprachfix GmbH, Eiderstädt, Tel, 01800/81890132 Einige Fächer sind schon in der Schule nicht beliebt, und das ändert sich auch später in der Berufsschule oder an der Universität nicht. Für viele sind Naturwissenschaften oder Mathematik echte Bei uns wird das anders. Unsere Lehrkräfte sind nicht nur fachlich gut ausgebildet, sondern sie haben auch eine spezielle pädagogische Ausbildung. Probieren Sie es einfach aus! Egal, ob in der Schule, in der Ausbildung, im Studium oder “einfach nur so” - bei uns finden Sie, was Sie brauchen. Bei uns lernen Sie in Lerngruppen von drei bis fünf Teilnehmenden, so können Sie sich auch gegenseitig unterstützen. Weitere Informationen unter info@lernenmachtspass.eu",
    "questions": [
      {
        "num": 11,
        "answer": "l",
        "stem": "Sie brauchen Unterstützung in Mathematik und möchten in einer kleinen Gruppe lernen."
      },
      {
        "num": 12,
        "answer": "h",
        "stem": "Sie möchten Physik studieren und möchten sich zunächst informieren."
      },
      {
        "num": 13,
        "answer": "d",
        "stem": "Sie möchten einen Sprachkurs in einem anderen Land machen."
      },
      {
        "num": 14,
        "answer": "b",
        "stem": "Sie möchten in einer anderen Stadt eine Ausbildung machen und suchen dort eine Wohnung."
      },
      {
        "num": 15,
        "answer": "i",
        "stem": "Sie ziehen wegen einer Ausbildung um und suchen so günstig wie möglich Umzugshelfer."
      },
      {
        "num": 16,
        "answer": "j",
        "stem": "Sie sind gerade umgezogen und möchten neue Leute kennenlernen."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Sie suchen einen Nachmieter und wollen eine kostenlose Anzeige aufgeben."
      },
      {
        "num": 18,
        "answer": "e",
        "stem": "Sie wollen gerne noch eine Sprache lernen und suchen einen festen Lernpartner."
      },
      {
        "num": 19,
        "answer": "g",
        "stem": "Sie wollen umziehen, haben aber eigentlich gar keine Zeit, sich darum zu kümmern."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Sie suchen für eine 18-jährige Bekannte einen bezahlten Job außerhalb von Deutschland."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Nicht nur Urlaub... ...kann man in anderen Ländern machen, sondern auch etwas lernen. Die Agentur für Arbeit vermittelt Schülerinnen und Schülern, aber auch Studierenden Praktikumsplätze im Ausland! Nutzt die Gelegenheit, möglichst früh Euren Wunschberuf kennenzulernen, auch wenn Ihr für das Praktikum nicht bezahlt werdet. Meldet euch gleich in der nächsten Filiale oder besucht unsere Homepage, auch dort gibt's weitere Informationen. www, agenturfuerarbeit.de"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Neues Ziel, neues Glück! Du bist gerade a“ uf dem Sprung,” willst umziehen und suchst noch eine passende Bleibe? Dann haben wir das Richtige für dich: In unserem Internetportal findest du günstige Wohnungen oder WG-Zimmer in zahlreichen Städten Deutschlands - und sogar über die Grenzen Deutschlands hinaus. Unsere Suchfunktion erlaubt es dir, Details einzugeben wie ”maximale Miete,” “zentrale Lage” usw. Schau einfach mal vorbei, die Suche ist natürlich kostenlos! Und noch etwas: Du kannst auch gerne ein Wohnungsangebot bei uns einstellen, wenn du einen Nachmieter oder einen Mitbewohner suchst - für nur 0,94 Euro. Du findest uns unter www.ueberallwohnen.eu"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "f IN Superlearning Sie möchten in kurzer Zeit ihre Sprachkenntnisse besonders schnell verbessern und suchen hierfür die beste Methode? Sie möchten sich während des Aufenthaltes gleichzeitig entspannen und etwas für Ihre Gesundheit tun? Dann dürfte dieses Programm für Sie genau das Richtige sein! Nach der Methode des berühmten bulgarischen Arztes Lozanov lernen Sie in entspannter Umgebung und dennoch hoch konzentriert mit Untermalung durch klassische Musik und praxisnahen kommunikativen Übungen. Durch unser ganzheitliches System können Sie Ihre Lernleistung erheblich steigern, so dass sich der vergleichsweise hohe Preis schnell bezahlt macht. Wir informieren Sie gerne über unser Angebot an Superintensivkursen. info@superlearning.de Tl"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Andere Länder, ...",
          "... andere Sprachen. Und wo lernt man eine Sprache am besten? Genau - in dem Land, in dem sie gesprochen wird. Wir bieten Ihnen die Möglichkeit, Sprachen auf der ganzen Welt zu lernen. Vom Einzelunterricht bis hin zu einem Kurs für eine ganze Gruppe, von A wie Arabisch bis Z wie Zulu. Entdecken Sie die Welt und die Welt der Sprachen. Wir gehen flexibel auf Ihre Wünsche ein. Sprechen Sie uns an. Egal welche Sprache Sie lernen möchten, wir haben bestimmt auch für Sie das passende Angebot!",
          "Weitere Informationen unter: info@sprachenderwelt.eu"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Was bedeutet “Tandemlernen”? 7 Zwei Menschen mit verschiedenen Muttersprachen treffen sich und helfen sich gegenseitig beim Lernen der jeweiligen Fremdsprache. Tandemlernen hat keine festgelegten Strukturen, sondern kann ganz nach ‘ Lust und Laune ablaufen. ‘ Was, wann, wo und wie du lernst, hängt von dir und deinem Tandempartner ab. Außerdem hast du die Chance, durch Tandemlernen einen interessanten Einblick in eine andereKultur ® zu bekomme. Und das Beste: es kostet nichts. Schau nach unter www.tandemboerse.de"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Interesse an einer Ausbildung? Auf unserem Azubi-Portal finden Sie Informationen zu allen Ausbildungsberufen, die es derzeit in Deutschland gibt. Sie erfahren, welche Voraussetzungen Sie für eine Ausbildung benötigen, was genau ‚ Sie in der Ausbildung lernen, wie Ihr späteres Berufsleben aussieht - und natürlich erfahren Sie auch alles rund um das Thema Lohn. 1 Auch wertvolle Bewerbungstipps finden Sie bei uns. Fr Schauen Sie doch mal vorbei: www.azubiportal.eu"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Umzug mal anders",
          "Wer kennt das nicht: Wenn man umziehen will oder muss, gibt es viel zu erledigen. Man muss den Umzug organisieren, sich um Papiere kümmern, die neue Adresse bekanntgeben und vieles mehr. Dabei hat man auch gar keine Zeit, denn arbeiten oder studieren muss man ja auch noch. Deshalb bieten wir einen kompletten Umzugs-Service an. Sie müssen nur noch von einer Stadt in die nächste Fahren - und den Rest erledigen wir.",
          "Das alles zu einem fairen Preis. Sprechen Sie uns an!"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Alle Informationen auf einer Seite Die neue Internetseite www.studium.de bietet Ihnen alles rund um das Thema”Studium.” So finden Sie neben Informationen zu allen deutschen Hochschulen auch genaue Beschreibungen aller Studiengänge und -fächer auf auf unserer Webseite. Ob sie etwas Naturwissenschaftliches studieren möchten, etwas Wirtschaftswissenschaftliches, ein Fach mit Bezug zu Kultur oder eine Sprache - bei uns finden Sie alles und erfahren natürlich auch, wo Sie was studieren können. Und als besonderen Service bieten wir Ihnen auch einen BAföG-Rechner an: Ermitteln sie gleich, ob Ihnen Unterstützung während des Studiums zusteht."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Hilfe gesucht? Studierende und Auszubildende müssen oft umziehen, ohne dass sie viel Geld dafür hätten. Deshalb haben wir unser Netzwerk S“ tudis und Azubis ziehen um” gegründet. Bei uns sind viele fleißige Helfer registriert, die gerne beim Umzug helfen: Kisten packen, Möbel abbauen, die Sachen zu neuen Wohnung bringen und so weiter. Und das Beste daran: Es kostet keinen Cent! Wie das funktioniert? Ganz einfach. Registriert euch bei uns - natürlich ebenfalls kostenfrei -, und wenn jemand anders Hilfe braucht, tragt ihr eben auch mal Kartons und baut Möbel auf. Wir helfen uns gegenseitig! Weitere Infos unter: www.umzugshelferlein.eu"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Neu in der Stadt? Ihr seid umgezogen und habt eine Ausbildung oder ein Studium hier in der Stadt begonnen? Ihr sucht neue Kontakte, Leute, mit denen ihr die Freizeit verbringen könnt? Der Verein “Triff dich!” organisiert einmal pro Woche eine Stammtisch für alle, die neue Leute treffen wollen. Kommt einfach vorbei - und wenn es euch nicht gefällt, könnt ihr ja jederzeit wieder gehen! Weitere Informationen sowie den Ort und das genaue Datum für unser nächstes Treffen erhaltet ihr unter: info@triffdich.eu"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Wie es Ihnen gefällt Unser neues Lernprogramm S“ prachenfix” bietet Ihnen die Möglichkeit, eine Sprache zu lernen, wann und wo Sie möchten, ob allein zu Hause oder unterwegs. Das Programm bietet alles, was Sie brauchen: von Erklärungen und Wortschatz über Lesetexte und Hörbeispiele bis hin zu Videos mit kleinen authentischen Szenen aus dem Alltag. Unser Online-Service bietet darüber hinaus Zusatzmaterialien. Auf Wunsch können Sie auch in einem durch Passwort geschützten Bereich Ihre eigenen Texte durch unsere Lehrkräfte korrigieren und kommentieren lassen. Das Programm ist für zahl-reiche Sprachen verfügbar, sprechen Sie uns an. Sprachfix GmbH, Eiderstädt, Tel, 0180081/ 908 132"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Aller Anfang ist schwer. Einige Fächer sind schon in der Schule nicht beliebt, und das ändert sich auch später in der Berufsschule oder an der Universität nicht. Für viele sind Naturwissenschaften oder Mathematik echte “Problemfächer.” Bei uns wird das anders. Unsere Lehrkräfte sind nicht nur fachlich gut ausgebildet, sondern sie haben auch eine spezielle pädagogische Ausbildung. Probieren Sie es einfach aus! Egal, ob in der Schule, in der Ausbildung, im Studium oder e“ infach nur so” - bei uns finden Sie, was Sie brauchen. Bei uns lernen Sie in Lerngruppen von drei bis fünf Teilnehmenden, so können Sie sich auch gegenseitig unterstützen."
        ]
      }
    ]
  },
  {
    "id": "19",
    "title": "Freizeit, Wandern und Tagesausflüge",
    "sourcePage": 283,
    "keywords": "",
    "questions": [
      {
        "num": 11,
        "answer": "l",
        "stem": "Ein Kollege interessiert sich für schnelle Wasserfahrzeuge."
      },
      {
        "num": 12,
        "answer": "k",
        "stem": "Ein Bekannter möchte barfuß am Meer spazieren gehen."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Eine Freundin sucht in Köln und Umgebung für vier Tage ein am Rhein gelegenes 4-Sterne-Hotel."
      },
      {
        "num": 14,
        "answer": "i",
        "stem": "Ihre Nachbarn möchten, dass ihre 7- und 9-jährigen Töchter mehr über den Umgang mit Tieren lernen."
      },
      {
        "num": 15,
        "answer": "a",
        "stem": "Ein befreundetes Ehepaar macht gern Tageswanderungen in Gesellschaft."
      },
      {
        "num": 16,
        "answer": "c",
        "stem": "Eine Bekannte möchte gute Laufschuhe kaufen."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Ein Bekannter interessiert sich für die Geschichte der Erde und möchte sich weiterbilden."
      },
      {
        "num": 18,
        "answer": "b",
        "stem": "Ihr Bruder interessiert sich für alte Fahrzeuge und möchte eine Tagesfahrt machen."
      },
      {
        "num": 19,
        "answer": "e",
        "stem": "Ein Freund sammelt Bücher mit den Autogrammen der Autoren."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Eine Bekannte ist Goldschmiedin und sucht Schmucksteine für ihre Werkstatt."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Auf den Höhen des Rheins",
          "Die Wanderung beginnt im Rheingau-Städtchen Rauenthal. Von hier aus geht es über die hügelige Taunuslandschaft - immer wieder mit Blick auf den Rhein - über die Hallgarter Zange nach Oestrich mit ‚seinem historischen Ortskern und dem berühmten Alten Kran. Festes Schuhwerk ist unbedingt empfehlenswert. Gaststätten gibt es auf der Hallgarter",
          "Zange und in Oestrich. Von dort aus gibt es auch gute Busverbindungen nach Wiesbaden und Rüdesheim.",
          "Info unter: Wanderdub Die Wanderrögel,",
          "Tel: 0611-45453326",
          "Gruppentreff: samstags 13.00 Uhr, sonntags",
          "11.00 Uhr, Bushaltestelle Rathaus Rauenthal",
          "ıInsabahan"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Eine Rheinfahrt, die ist lustig",
          "Eine Fahrt für Freunde nostalgischen Reisens: Mit dem 1908 gebauten Schaufelraddampfer Neptun fahren wir von Mainz vorbei am Binger Mäuseturm und an der Loreley in das Städtchen Sankt Goarshausen. Hier erwartet uns ein leckeres ‚Abendessen mit Wein und Gesang. Da fehlt natür-",
          "lich auch nicht die Loreley, die für uns von ihrem Felsen herabsteigt und alte Volksweisen und Lieder vorträgt. Zurück nach Mainz geht es dann mit einer historischen Dampflok. Information und Anmeldung bei: Touristen-Information Mittelrhein, Tel: 06134- 9988663"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Der Wanderladen am Rathausplatz 4 in Wangen",
          "Wir haben alles, was Sie zum Wandern und Bergsteigen brauchen. Auf fast 200 m? finden Sie Markenprodukte bekannter Sportausstatter: Textilien, Pulsmessgeräte, Wanderkarte, Ausrüstungen für Freeclimbing, Nordic Walking, Trekking, Jogging usw. Kurzum: Wir bieten alles",
          "© Der Wanderladen am Rathausplatz 4 in nen 72747",
          "vom Spazierstock bis zum Stiefel. Natürlich bieten wir jedem Kunden unsere persönliche fachkundige Beratung an. Weitere Informationen zum Angebot sowie unseren Öffnungszeiten unter 01804- 5532210 oder schauen Sie sich unsere Internetseite an: www.wanderladen.de"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Mit dem Schiff nach Holland",
          "Ruhe, Erholung, Entspannung und dabei Kultur genießen und köstlich essen und trinken - das alles können Sie während unserer viertägigen Kreuzfahrt ‚auf dem Rhein erleben. Auf einem unserer schwimmenden 4-Sterne-Hotels werden Sie sich sicher wohl fühlen. Alle Schiffe verfügen über Einzel- und Doppelzimmer mit Bad und WC, Restaurant, Bistro,",
          "Tanzcafe, Fitnessraum und einem Swimmingpool auf dem Sonnendeck. Start der Reise ist Frankfurt am Main. Etappenziele sind Koblenz, Köln und Düsseldorf. Unser Reiseziel Rotterdam erreichen wir am vierten Tag. Fordern Sie unseren Katalog an unter 0180-3287549"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Geschichte und Geschichten vom Rhein",
          "Die alten Römer und Germanen sowie die mittelalterlichen Burgherren sind längst Geschichte. Zahlreiche Sagen und Anekdoten ranken sich bis heute um Bauwerke und Menschen, die am Rhein gelebt haben; Schriftsteller und Dichter wurden zu Werken über und rund um den Rhein inspiriert. Die Stadtbibliothek Bingen hat diesen historischen wie unter-",
          "haltsamen Geschichten eine Ausstellung gewidmet, die täglich außer montags von 10 bis 18 Uhr im Bibliotheksgebäude besucht werden kann. Außerdem lesen jeden Sonntag um 20 Uhr im Juli und August Schriftsteller aus ihren Werken - mit Büchertisch und ‚Autogrammstunden. Der Eintritt zu der Ausstellung ist frei, für die Lesungen beträgt er 8 Euro."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Der Rhein und seine Geschichte7—25111",
          "Das Geologische Institut der Johannes-Gutenberg- Universität Mainz bietet im kommenden Semester im Rahmen des Studium generale eine Vortragsreihe an zum Thema: Der Rhein und seine Geschichte. Was verraten uns bestimmte Gesteinsformationen im Untergrund? Wie kommen versteinerte Meeres-",
          "bewohner als Fossilien in die rheinhessische Erde? Wie sah es hier vor Jahrmillionen aus? Die Vortragsreihe startet am 1.November und findet jeweils mittwochs um 18.30 Uhr im Auditorium maximum der Universität statt."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Edelstein-Erlebniswelt",
          "Edle Entspannung bieten Ihnen die Höhlen und schernden Quellen und einem feurig glühenden Grotten der Edelstein-Erlebnisweit in Idar-Oberstein. Vulkan. Die Besucher können die Kraft der Kristalle Mit zauberhaften Licht- und Farbspielen präsentiert und Mineralien spüren und so die Wunderwerke der sich eine geheimnisvolle Höhlenlandschaft mit plät- Natur sinnlich erfahren."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Ohne Schuhwerk wandern",
          "Besuchen Sie Deutschlands ersten und einzigen Barfußpfad - ein Riesenspaß für jedes Alter. Der Barfußpfad in Bad Sobernheim zählt zu den beliebtesten Ausflugszielen an dem Fluss Nahe. Die wohltuende Kühle des Lehmbodens und der Wasser-",
          "tretbecken erfrischt müde und schwere Beine. Über verschiedene Geschicklichkeitsparcours gelangen Sie zur Nahefurt Hier können Sie die Nahe mit Hilfe von zwei Halteseilen überqueren. Gehen Sie barfuß durch die Natur - ein unvergessliches Abenteuer!"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Ein Zoo für Jung und Alt",
          "Ein Besuch im Opel-Zoo bietet zu jeder Jahreszeit ein besonderes Erlebnis. In den monatlich stattfindenden pädagogischen Führungen für Kinder und Jugendliche erläutern unsere Zoopädagogen die verschiedensten zoologischen Themen. Darüber hinaus gibt es regelmäßig auch spezielle Ferien-",
          "programme. Für die Kleinen gibt es auch einen Streichelzoo und einen großen Abenteuerspielplatz sowie Kamel- oder Ponyreiten. Für die Großen gibt es Picknick- und Grillplätze, ein Restaurant und vieles mehr. Ein Besuch im Opel-Zoo ist ein unvergessliches Erlebnis für Alt und Jung."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Tiere erleben",
          "Mehr als 600 Tiere haben im Safaripark eine neue Heimat gefunden. Hier wurde fürsieein Lebensraum geschaffen, der ihrer ursprünglichen natürlichen Umgebung weitgehend entspricht. Im Safaripark sitzen nicht die Tiere, sondem die Besucher „hinter Gittern‘: Im eigenen Auto fährt man durch die gro-",
          "Ben Tiergehege. Oder man nutzt den Safar-Zug (2,50 € pro Person). Kostenlos ist der Affenzug, der durch das Affengehege fährt. 40 Berberaffen leben hier frei, klettern, springen, toben. Und die Besucher fahren in einer vergitterten Bahn gemächlich durch das Gehege."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Zweimal täglich gibt das Wasser den Meeresboden frei - es ist die Zeit der Ebbe. Unter sachkundiger Führung können Wattwanderungen zum Beispiel zur Hallig Süderoog, zur Hallig Hooge oder zu Kulturspuren ehemaliger Siedlungen unternommen werden. Barfuß ist Wattwanderm am schönsten. Dann ‚spürt man den Wattboden unmittelbar. Wer empfind-",
          "liche Füße hat, sollte sich ein paar alte Socken oder Tumschuhe anziehen. Wattwanderungen mit erfahrenen Wattführern sind sicherer und erlebnisreicher als auf eigene Faust loszuziehen. Deshalb sollten erste und größere Wattwanderungen in einer geführten Gruppe unternommen werden. Die Tour dauert jeweils 2-2% Stunden."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Die Nordseeküste wirbt für sich am Rhein",
          "Besuch hat sich angesagt, und zwar vom 21. bis zum 23. Apri: Die Nordsee kommt nach Düsseldorf. Auf der Promenade am Altstadtufer präsentieren sich in einer Zeltiandschaft, verbunden mit einer Aktionsbühne, alle niedersächsischen Küstenorte unddiesieben Ostfriesischen Inseln, die Reedereien, Fluggesellschaften und Hotels. Auf dem Rhein",
          "erwartet ein feuerroter Katamaran Besucher zu Sonderfahrten. Der CAT Nr. 1 - sonst auf der Nordsee unterwegs - ist zu besichtigen und zeigt auf dem Rhein seine Stärke: Stolze 12.633 PS schaffen flotte 40 Knoten, das sind 74 km/h - das schnellste Passagierschiff, das jemals den Rhein befuhr"
        ]
      }
    ]
  },
  {
    "id": "20",
    "title": "Gesundheit, Versicherung und Kurse",
    "sourcePage": 286,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Ein Kollege hat seit ein paar Tagen Hautprobleme und weiß nicht, was die Ursache sein könnte. Sie möchten etwas mit ihrer 7-jährigen Tochter Unternehmen. Ihre Bekannte hat Fieber, möchte aber keine Tabletten nehmen. Das Ehepaar, das unter Ihnen wohnt, möchte etwas über Computer lernen. Sie wollen Informationen über eine Zahnversicherung, ohne telefonieren zu müssen. Ihre Nachbarin ist seit einer Woche erkältet. Natürliche Heilmittel haben nicht geholfen. Sie bekommen Besuch und möchten am Sonntagvormittag etwas Interessantes unternehmen. Ihre Freundin interessiert sich für japanische Medizin. Sie suchen als Geburtstagsgeschenk ein Buch zu diesem Thema. Sie haben ein Haustier, das im letzten Jahr viel Geld für den Tierarzt gekostet hat. Sie suchen eine Möglichkeit, Kosten zu sparen. Ratgeber “Was bei Erkältung hilft” Teelöffel Salze) oder Salbeitee trinken. Sie möchten eine Versicherung für Ihren Neuwagen abschließen und sofort wissen, was es Erkältungen gehören leider zum Leben. Sie kommen immer wieder wie Frühling, Sommer, Herbst und Winter. Jetzt ist wieder Erkältungssaison. Hier sind einige wichtige Tipps. Bei Fieber: mindestens 2-3 Liter Tee oder Wasser pro Tag trinken. Feuchte Wadenwickel können helfen. Ist das Fieber nach zwei Tagen nicht weg, unbedingt zum Arzt gehen. Bei Halsweh mit Salzwasser gurgeln (1 Glas Wasser ein Wir zeigen den kosten die Zähne! Für alle, die noch viel vorhaben: Sichern Sie sich Top-Leistung zu Top-Konditionen! Genießen Sie den maßgeschneiderten privaten Versicherungsschutz für Zähne und die zuverlässige Sicherheit der WORMSER. Da lohnt sich der Wechsel: bis zum 31.12. handeln und dauerhaft von Beitrags-Vorteil profitieren. Ein Leben lang! Mehr Informationen kostenfrei unter 0700/432000. warum teilen schwer und betteln grausam ist Dass es viel einfacher ist, egoistisch zu sein als mitfühlend, weiß fast jeder. Dass aber auch Menschen, die Hilfe brauchen, der egoistisch sein können, zeig das Stück “Der gute Mensch von Sezuan” von Bertolt Brecht. Und er erzählt es so, dass auch Kinder es verstehen können. Im Theater an der Parkaue wir das Stück am Sonntag um 14 Uhr in der Originalfassung gezeigt. Regisseurin Claudia Kipfel: “Dieses Stück kann man so lassen, wie es ist. Kinder verstehen es sofort.” Karten: 0179-666453110, für Kinder ab 8 Jahren. Preise: 12 Euro, Kinder bis 12 Jahre: 7 Euro. Wann nehmen Sie Omnitamol? Bei leichten bis mäßig starken Schmerzen. Bei Fieber und Erkältungen. Wichtig: Nehmen Sie Omnitamol nur 3-4 Tage ein, danach gehen Sie bitte unbedingt zu Ihrem Arzt oder Zahnarzt, wenn ihre Beschwerden sich nicht gebessert haben. Was ist bei Kindern zu berücksichtigen? Omnitamol 500 Tabletten sind nicht geeignet für Kinder unter 6 Jahren. Für Kinder bieten wir Ihnen gesonderte Präparate an. Fragen Sie Ihren Arzt oder Apotheker. Neue Kleidung kann krank machen Das neue Hemd passt prima zu Lieblingsjeans. Warum also nicht gleich anziehen? Doch Vorsicht: Neue Textilien können Allergien und Hautreizungen auslösen, vor allem bei Kindern und Menschen mit empfindlicher Haut. Grund: Viele Textilien enthalten Farbstoffe oder andere Chemikalien. Tipp: neue Kleidungsstücke vor dem ersten Tragen waschen. Für Babys und Kleinkinder ist Second-Hand-Kleidung eine gute Alternative, da die Schadstoffe schon ausgewaschen sind. Erkältungszeit = Theaterzeit Zu einem hoffentlich husten- und schnupfenfreien Nachmittag für die ganze Familie lädt das Puppentheater \"Die Langohren\" am morgigen Sonntag um 15 Uhr ein. Das Ensemble um die professionelle Puppenspielerin Margit Hallmann spielt “Hätschi, kleine Anna” und verspricht ein Theatererlebnis für Erwachsene und Kinder ab 6 Jahren. Die Veranstaltung ist fast ausverkauft. Tickets unter Telefon (0564) 5404420 Liebe Leserin, lieber Leser, gepflegte Zähne hängen oft von der finanziellen Möglichkeiten des Patienten ab. Mit der Krankenkasse alleine kommt oft nicht weit. Mit der DENTAL VERSICHEUNG 100Plus von WarnstädtHyper verdoppeln Sie bei Zahnersatz den Zuschuss Ihrer gesetzlichen Krankenkasse. Keine Altersbegrenzung, günstige Monatsbeiträge. Nutzen Sie noch heute diese wichtigen Vorteile. Rufen sie an: 069-780086753 oder informieren Sie sich im Internet unter www.neue-zaehne.eu. Wir schicken Ihnen die Unterlagen zu.",
    "questions": [
      {
        "num": 11,
        "answer": "j",
        "stem": "Ein Kollege hat seit ein paar Tagen Hautprobleme und weiß nicht, was die Ursache sein könnte."
      },
      {
        "num": 12,
        "answer": "k",
        "stem": "Sie möchten etwas mit ihrer 7-jährigen Tochter Unternehmen."
      },
      {
        "num": 13,
        "answer": "a",
        "stem": "Ihre Bekannte hat Fieber, möchte aber keine Tabletten nehmen."
      },
      {
        "num": 14,
        "answer": "e",
        "stem": "Das Ehepaar, das unter Ihnen wohnt, möchte etwas über Computer lernen."
      },
      {
        "num": 15,
        "answer": "l",
        "stem": "Sie wollen Informationen über eine Zahnversicherung, ohne telefonieren zu müssen."
      },
      {
        "num": 16,
        "answer": "i",
        "stem": "Ihre Nachbarin ist seit einer Woche erkältet. Natürliche Heilmittel haben nicht geholfen."
      },
      {
        "num": 17,
        "answer": "c",
        "stem": "Sie bekommen Besuch und möchten am Sonntagvormittag etwas Interessantes unternehmen."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Ihre Freundin interessiert sich für japanische Medizin. Sie suchen als Geburtstagsgeschenk ein Buch zu diesem Thema."
      },
      {
        "num": 19,
        "answer": "g",
        "stem": "Sie haben ein Haustier, das im letzten Jahr viel Geld für den Tierarzt gekostet hat. Sie suchen eine Möglichkeit, Kosten zu sparen."
      },
      {
        "num": 20,
        "answer": "f",
        "stem": "Sie möchten eine Versicherung für Ihren Neuwagen abschließen und sofort wissen, was es kostet."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Ratgeber “Was bei Erkältung hilft” Erkältungen gehören leider zum Leben. Sie kommen immer wieder wie Frühling, Sommer, Herbst und Winter. Jetzt ist wieder Erkältungssaison. Hier sind einige wichtige Tipps. Bei Fieber: mindestens 2-3 Liter Tee oder Wasser pro Tag trinken. Feuchte Wadenwickel können helfen. Ist das Fieber nach zwei Tagen nicht weg, unbedingt zum Arzt gehen. Bei Halsweh mit Salzwasser gurgeln (1 Glas Wasser ein Teelöffel Salze) oder Salbeitee trinken."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Wir zeigen den kosten die Zähne! Für alle, die noch viel vorhaben: Sichern Sie sich Top-Leistung zu Top-Konditionen! Genießen Sie den maßgeschneiderten privaten Versicherungsschutz für Zähne und die zuverlässige Sicherheit der WORMSER. Da lohnt sich der Wechsel: bis zum 31.12. handeln und dauerhaft von Beitrags-Vorteil profitieren. Ein Leben lang! Mehr Informationen kostenfrei unter 0700/4332000."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "ee rereeeeeeeereeezizp, hun Kochen und waschen um 1900 lautet das Thema, wenn Anita Kramer am kommenden Sonntag durch das Museum für Stadtgeschichte führt. Wie wurde damals gekocht und gewaschen? Wie haben unsere Ur- Ur- Großeltern damals gelebt? Kühlschrank, Mikrowelle und andere moderne Geräte gab es ja in jener Zeit noch nicht. Wie hat man Speisen haltbar gemacht? Wie wurde gebügelt? Auf all diese Fragen hat Frau Krämer eine Antwort. Auch Kinder sind herzlich willkommen. Sie werden auch erfahren, wie oft Kinder damals gewaschen wurden. Wie sah es mit der Zahnpflege aus? Eine spannende und unterhaltsame Reise in die Zeit von vor 100 Jahren. Der Eintritt ist frei. Die Führung findet immer in Gruppen von 10 Personen ab I0 Uhr zu jeder vollen Stunde statt. Museum für Stadtgeschichte, Alte Waldstraße 11. TEE"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Lesen, was gesund macht",
          "Jetzt in der neuen Apotheken-Revue:",
          "- Ohrprobleme: endlich wieder gut hören!",
          "- Hautpflege: gut geschützt durch jede Jahreszeit",
          "- Kampo: heilen mit traditioneller japanischer Medizin",
          "Diese und noch viele weitere interessante Themen rund um Ihre Gesundheit, plus Rätselspaß und tollen Gewinnspiel",
          "Alle 14 Tage neu in Ihrer Apotheke. Kostenlos!"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Nachhilfe 4 Wenn es um den Computer geht, wissen viele Kinder längst besser Bescheid als Erwachsene. Fast die ‘",
          "Hälfte (47%) der 10- bis 19-Jährigen, in deren Haushalt ein Computer steht, wird vom Vater, Mutter, aber auch von Oma und Opa um Rat gefragt. In der Heinrich-Mann-Schule geben computerbegeisterte Schüler jetzt jeden Samstag von 10-12 Uhr sogar extra Nachhilfekurse für Erwachsene. Start ist am kommenden Samstag, der Schülerservice ist kostenlos! Interessierte Schülerinnen und Schüler, die ihre Erfahrungen weitergeben möchten, können auch gern vorbeikommen und mitmachen. 3"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Vienna CONEKT ! Versichern Sie Ihr Auto ab 35 Cent am Tag. Sparen Sie zusätzlich mit dem Bonusprogramm und bleiben Sie flexibel: Sie können jederzeit monatlich kündigen. Jetzt Beitrag direkt berechnen:",
          "vienna-conekt.de",
          "018084-33556474 Mit der Vienna Conekt haben sie direkt mehr Vorteile: immer günstig, immer erreichbar (24-Stunden-Schaden-hotline), Ersatzwagengarantie!"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Sofort-Versicherung",
          "Die Behandlung kommt vom Arzt.",
          "Die Fürsorge von ihnen.",
          "Die Finanzspritze von uns.",
          "Der umfassende Schutz bei Krankheit und Unfall.",
          "Auch liebe kann nicht verhindern, dass Ihr Haustier mal krank wird oder einen Unfall hat.",
          "Die dadurch notwendige Behandlung oder Operation kann schnell bis zu 1000 Euro kosten.",
          "Die neue care-securitas Tierschutzversicherung schützt Sie vor diesem Risiko. Küummern Sie sich also"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Kindertheater: warum teilen schwer und betteln grausam ist Dass es viel einfacher ist, egoistisch zu sein als mitfühlend, weiß fast jeder. Dass aber auch Menschen, die Hilfe brauchen, der egoistisch sein können, zeig das Stück “Der gute Mensch von Sezuan” von Bertolt Brecht. Und er erzählt es so, dass auch Kinder es verstehen können. Im Theater an der Parkaue wir das Stück am Sonntag um 14 Uhr in der Originalfassung gezeigt. Regisseurin Claudia Kipfel: “Dieses Stück kann man so lassen, wie es ist. Kinder verstehen es sofort.” Karten: 0179-666453110, für Kinder ab 8 Jahren. Preise: 12 Euro, Kinder bis 12 Jahre: 7 Euro."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Omnitamol 500 Tabletten Wann nehmen Sie Omnitamol? Bei leichten bis mäßig starken Schmerzen. Bei Fieber und Erkältungen. Wichtig: Nehmen Sie Omnitamol nur 3-4 Tage ein, danach gehen Sie bitte unbedingt zu Ihrem Arzt oder Zahnarzt, wenn ihre Beschwerden sich nicht gebessert haben. Was ist bei Kindern zu berücksichtigen? Omnitamol 500 Tabletten sind nicht geeignet für Kinder unter 6 Jahren. Für Kinder bieten wir Ihnen gesonderte Präparate an. Fragen Sie Ihren Arzt oder Apotheker."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Neue Kleidung kann krank machen Das neue Hemd passt prima zu Lieblingsjeans. Warum also nicht gleich anziehen? Doch Vorsicht: Neue Textilien können Allergien und Hautreizungen auslösen, vor allem bei Kindern und Menschen mit empfindlicher Haut. Grund: Viele Textilien enthalten Farbstoffe oder andere Chemikalien. Tipp: neue Kleidungsstücke vor dem ersten Tragen waschen. Für Babys und Kleinkinder ist Second-Hand-Kleidung eine gute Alternative, da die Schadstoffe schon ausgewaschen sind."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Erkältungszeit = Theaterzeit Zu einem hoffentlich husten- und schnupfenfreien Nachmittag für die ganze Familie lädt das Puppentheater \"Die Langohren\" am morgigen Sonntag um 15 Uhr ein. Das Ensemble um die professionelle Puppenspielerin Margit Hallmann spielt “Hätschi, kleine Anna” und verspricht ein Theatererlebnis für Erwachsene und Kinder ab 6 Jahren. Die Veranstaltung ist fast ausverkauft. Es gibt noch Restkarten. Tickets unter Telefon (0564) 5404420"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Zusatz-Versicherung Liebe Leserin, lieber Leser, gepflegte Zähne hängen oft von der finanziellen Möglichkeiten des Patienten ab. Mit der Krankenkasse alleine kommt oft nicht weit. Mit der DENTAL VERSICHEUNG 100Plus von WarnstädtHyper verdoppeln Sie bei Zahnersatz den Zuschuss Ihrer gesetzlichen Krankenkasse. Keine Altersbegrenzung, günstige Monatsbeiträge. Nutzen Sie noch heute diese wichtigen Vorteile. Rufen sie an: 069-780086753 oder informieren Sie sich im Internet unter www.neue-zaehne.eu. Wir schicken Ihnen die Unterlagen zu."
        ]
      }
    ]
  },
  {
    "id": "21",
    "title": "Winterurlaub, Silvester und Reisen",
    "sourcePage": 289,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Sie möchten Ihren Eltern zur Silberhochzeit eine besondere Schiffsreise auf dem Meer Ihre Freundin möchte mit ihrem Mann Silvester und Neujahr im Urlaub feiern, aber nicht Ein Bekannter möchte im Winter ein besinnliches Wochenende in den Bergen verbringen, denn er mag es, durch die verschneite Natur zu laufen. Eine Bekannte aus dem Rhein-Main-Gebiet sucht Vorschläge für Ein-Tages-Ausflüge, denn sie übernachtet nicht gern in fremden Betten. Sie wollen wie jedes Jahr in der zweiten Jahreshälfte eine zirka einwöchige organisierte Urlaubsreise in Europa machen und sich dabei viel mit dem Fahrrad fortbewegen. Sie möchten einen netten Abend mit Freunden bei gutem Essen und außergewöhnlichem Unterhaltungsprogramm verleben. Sie suchen für eine prunkvolle Hochzeitsfeier geeignete festliche Räumlichkeiten in einer stimmungsvollen klösterlichen Umgebung für zirka 50 Personen. Sie sind neu in Frankfurt a. M. und suchen deshalb nach nützlichen Informationen und praktischen Tipps, um sich schnell in der neuen Umgebung einzuleben. Sie interessieren sich für Bücher über Architektur und Gartenarchitektur deutscher Norwegen: Kirkenes-Bergen E-Mail: info@eiligruten.de, www.eiligruten.de. Sie suchen gute Kriminalromane, deren Handlung im Rhein-Main-Gebiet und besonders in Die schönste Seereise der Welt - von Anfang April bis Ende Oktober. 6-Tage-Seereise 2009 ab 69,- € p. P. Eindrucksvolle Landschaften entdecken. Die Seele baumeln lassen. Natur mit allen Sinnen genießen. Mit einer Postschiffreise können Sie das unglaubliche Panorama, das Ihnen die norwegische Küste wie im Bilderbuch darbietet, genießen. Erleben Sie die Einzigartigkeit der atemberaubenden Gebirgsketten, der artenreichen Tierwelt und der idyllisch gelegenen Hafenstädte, die wir im Liniendienst anfahren. Buchen Sie innerhalb der nächsten 6 Wochen - und sichern Sie sich Ihre Wunschkabine und einen Frühbucher-Bonus bis 25%. Information, aktueller Katalog und Buchung unter: Tel.: (040) 367 53-496, Mal was ganz anderes machen Winterurlaub am Meer. Denn Nord- und Ostseeküste bieten auch in der kalten Jahreszeit Aktivitäten, die der ganzen Familie Spaß machen. Zum Beispiel \"Boßeln\". Welche Mannschaft kullert die bleigefüllte Holzkugel auf den gefrorenen Wegen am weitesten? Zwischendurch gibt es heißen Früchtetee oder Glühwein, hinterher traditionell Grünkohl für alle. Tierfreunde können auf einer Robbensafari zusehen, wie die Robbenmütter ihre Babys säugen. Wer will, kann die Winterlandschaft dick eingemummt von der Pferdekutsche aus genießen. Gleichmäßig stapfen die Hufe im Sand, der Leuchtturm ist das ferne Ziel. Und danach aufwärmen am knisternden Kamin, mit süßem Punsch und Bratapfel. Braucht da noch jemand Berge? Infos unter: www.schleswig-holstein.de. Wenn die Tage kürzer und die Nächte kälter werden, ist es Zeit für Artistik, Comedy und Gaumenfreuden. Magier, Jongleure, Akrobaten und ein Vier-Gang-Gourmet-Menü im Schein hunderter Kerzen: Ein Abend im Palladio verspricht unterhaltsame Stunden mit perfektem Genuss im stilvollen Ambiente des traumhaft schönen, nostalgischen Spiegelpalastes. Das Gourmet-Theater Palladio serviert Ihnen seine charmante Mixtur aus hochkarätigem Entertainmente und exquisiter Kochkunst. Freuen Sie sich auf köstliche Menükreationen und erleben Sie dreieinhalb Stunden voller Humor und Lebensfreude. Lassen Sie sich verwöhnen und verzaubern! Dienstags bis sonntags sind wir für Sie da: Beginn ist jeweils um 20.00 Uhr. Foyer und Bar sind bereits 90 Minuten vor Showbeginn geöffnet. Kloster Eberbach mit seinen eindrucksvollen mittelalterlichen und barocken Bauten bietet seinen Gästen einzigartige Voraussetzungen für eine stilvolle Veranstaltung in altehrwürdigen Klostermauern. Sie können viele unserer repräsentativen Säle und prachtvollen Räume für Veranstaltungen anmieten. Ob Sie einen festlichen Empfang oder ein nobles Bankett planen oder ob Ihnen eine stilvolle Produktpräsentation vorschwebt: Hier lässt sich all dies hervorragend inszenieren. Die breite Palette unserer Räumlichkeiten und Gärten gibt Raum für Gesellschaften von 20 bis 1.000 Personen und lässt im Zusammenspiel mit dem Ambiente der Klosteranlage jede Veranstaltung zu einem ganz besonderen Ereignis werden. Hier finden Sie den richtigen Rahmen für Ihre Familienfeier, Ihr Seminar, Ihren Betriebsausflug, ein festliches Bankett oder eine Vortragsveranstaltung. Einige Räume sind zudem für Hochzeiten, Konzerte und Lesungen geeignet. Stadt-Führer Frankfurt am Main. Kultur & mehr Viel Lob von der Lokalpresse für einen neuen Stadt-Führer über die Mainmetropole: Anne Schütz: Frankfurt am Main. Kultur & mehr. Paul Müller Verlag, 15,95 €. Dieser umfangreiche Reise-Führer wartet mit einer ganz besonderen Mischung auf: Rundgänge zur Stadtgeschichte stehen neben einer geballten Ladung an praktischen Informationen. Besonders gelungen ist es, wie die Autorin historische Details mit Spaziergängen verzahnt. Sie rennt keinen Trends hinterher, sondern führt als kenntnisreiche Begleiterin durch ihre Stadt. Ein praktischer Stadtkulturführer für Einheimische und Besucher mit Hunderten von Tipps, Adressen, Öffnungszeiten und Preisen von Parks und Bädern über schöne Lokale bis zu Museen, Theatern und Veranstaltungsorten. Tour zu Schauplätzen der berühmtesten Kriminalfälle Frankfurts Der Historiker und Stadtfüher Peter Glock begleitet Sie auf einer interessanten zweistündigen Tour durch die Innenstadt zu Schauplätzen der berühmtesten Kriminalfälle in der Geschichte Frankfurts. Sie erfahren alles über spektakuläre Verbrechen, wie z. B. den Mord an Rosemarie Nitribitt, die Hinrichtung von Vinzenz Fettmilch im Jahre 1616 oder die Ermordung des Klavierhändlers Lichtenstein im Jahre 1904, als erstmals ein Mordfall durch die Abnahme von Fingerabdrücken aufgeklärt wurde. Die Führung findet jeden Sonntag ab 14.00 Uhr statt. Treffpunkt: Café Hauptwache. Statistisches Jahrbuch der Stadt Frankfurt An einem durchschnittlichen Tag in Frankfurt werden 19 Babya geboren, sieben Brautpaare heiraten, aber fünf Ehepaare lassen sich scheiden. 136 Frankfurter ziehen im Stadtgebiet um, sechs neue Wohnungen werden fertiggestellt und acht Ausländer eingebürgert. Im Statistischen Jahrbuch der Stadt Frankfurt werden alle wichtigen Zahlen zum Leben, Arbeiten und Wohnen in der Stadt erfasst. Das Bürgeramt, Zeil 3, gibt den Bericht alljährlich heraus. Interessierte können das Statistische Jahrbuch im Internet herunterladen (www.frankfurt.de). Der Download ist kostenfrei.",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Sie möchten Ihren Eltern zur Silberhochzeit eine besondere Schiffsreise auf dem Meer schenken."
      },
      {
        "num": 12,
        "answer": "b",
        "stem": "Ihre Freundin möchte mit ihrem Mann Silvester und Neujahr im Urlaub feiern, aber nicht schon wieder im Gebirge."
      },
      {
        "num": 13,
        "answer": "c",
        "stem": "Ein Bekannter möchte im Winter ein besinnliches Wochenende in den Bergen verbringen, denn er mag es, durch die verschneite Natur zu laufen."
      },
      {
        "num": 14,
        "answer": "g",
        "stem": "Eine Bekannte aus dem Rhein-Main-Gebiet sucht Vorschläge für Ein-Tages-Ausflüge, denn sie übernachtet nicht gern in fremden Betten."
      },
      {
        "num": 15,
        "answer": "d",
        "stem": "Sie wollen wie jedes Jahr in der zweiten Jahreshälfte eine zirka einwöchige organisierte Urlaubsreise in Europa machen und sich dabei viel mit dem Fahrrad fortbewegen."
      },
      {
        "num": 16,
        "answer": "h",
        "stem": "Sie möchten einen netten Abend mit Freunden bei gutem Essen und außergewöhnlichem Unterhaltungsprogramm verleben."
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "Sie suchen für eine prunkvolle Hochzeitsfeier geeignete festliche Räumlichkeiten in einer stimmungsvollen klösterlichen Umgebung für zirka 50 Personen."
      },
      {
        "num": 18,
        "answer": "j",
        "stem": "Sie sind neu in Frankfurt a. M. und suchen deshalb nach nützlichen Informationen und praktischen Tipps, um sich schnell in der neuen Umgebung einzuleben."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Sie interessieren sich für Bücher über Architektur und Gartenarchitektur deutscher Klosteranlagen."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Sie suchen gute Kriminalromane, deren Handlung im Rhein-Main-Gebiet und besonders in Frankfurt spielt."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Norwegen: Kirkenes-Bergen Die schönste Seereise der Welt - von Anfang April bis Ende Oktober. 6-Tage-Seereise 2009 ab 99,6 - € p. P. Eindrucksvolle aL ndschaften entdecken. Die Seele baumeln lassen. Natur mit allen Sinnen genießen. Mit einer Postschiffreise können Sie das unglaubliche Panorama, das Ihnen die norwegische Küste wie im Bilderbuch darbietet, genießen. Erleben Sie die Einzigartigkeit der atemberaubenden Gebirgsketten, der artenreichen Tierwelt und der idyllisch gelegenen Hafenstädte, die wir im Liniendienst anfahren. Buchen Sie innerhalb der nächsten 6 Wochen - und sichern Sie sich Ihre Wunschkabine und einen Frühbucher-Bonus bis 25%. Information, aktueller Katalog und Buchung unter: Tel.: 0( 40) 367 53-96,4 E-Mail: info@eiligruten.de, www.eiligruten.de."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Mal was ganz anderes machen Winterurlaub am Meer. Denn Nord- und Ostseeküste bieten auch in der kalten Jahreszeit Aktivitäten, die der ganzen Familie Spaß machen. Zum Beispiel \"Boßeln\". Welche Mannschaft kullert die bleigefüllte Holzkugel auf den gefrorenen Wegen am weitesten? Zwischendurch gibt es heißen Früchtetee oder Glühwein, hinterher traditionell Grünkohl für alle. Tierfreunde können auf einer Robbensafari zusehen, wie die Robbenmütter ihre Babys säugen. Wer will, kann die Winterlandschaft dick eingemummt von der Pferdekutsche aus genießen. Gleichmäßig stapfen die Hufe im Sand, der eL uchtturm ist das ferne Ziel. Und danach aufwärmen am knisternden Kamin, mit süßem Punsch und Bratapfel. Braucht da noch jemand Berge? Infos unter: www.schleswig-holstein.de."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Bee EEE nn Meditation im Schnee Nur die Schritte knirschen gleichmäßig im Schnee. Sonst ist es absolut still. Rechts und links ragen die Berge schroff in den blauen Himmel. Strahlend weiß glitzert die Landschaft wie von Tausenden kleiner Diamanten. Wer in meditativer Stimmung durch den Schnee stapfen möchte, ist auf einer Schneeschuhwanderung in den Ostschweizer Bergen richtig. Beim Schneeschuh-Wochenende wandert man mit großflächigen Schuhen ausgerüstet durch den Tiefschnee. Später fahren dann alle mit dem Schlitten ins Tal, wo im Gasthaus schon eine heiße Suppe auf dem Herd dampft und ein warmes Bett wartet. Für mehr Informationen besuchen Sie unsere Internet-Seite: www.meditation-im-schnee.ch.",
          "[rm äs"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Fluss- und Radreise durch Belgien",
          "8 Tage Fluss- und Radreise durch Belgien. Abseits der Hauptstraßen fahren Sie mit Schiff und Rad durch die flache Polderlandschaft Belgiens, die dafür ideal geeignet ist. Die Städte Brügge und Brüssel bilden den Anfangs- und Endpunkt der Reise. Im Reisepreis enthalten: Bahnreise in der 2. Klasse ab Frankfurt, Transfers vom Bahnhof zum Schiff und zurück. 7 Nächte in Außenkabinen an Board der \"Quo Vadis”, Frühstück, Mittagessen oder Lunchpaket für Fahrradtouren, Abendessen. Tägliche Tourenbesprechungen, Landkarten, alle Hafen-, Schleusen- und Brückengebühren, Leihgebühr für ein 7-Gang-Unisex-Rad, qualifizierte, ortskundige Reiseleitung. Die Radstrecke beträgt ca. 296 km. Termin: 19. bis 26. September. Preis: 1199 € p. P in Zweibettkabine."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Radwandern durch das Veneto 8",
          "Radwandern durch das Veneto",
          "8 Tage Radwandern durch das Veneto. Sogar Goethe war sprachlos - so schön ist Norditalien. Ruhige,",
          "flache Wege geleiten Sie vom Gardasee über Verona nach Vicenza. Durchs Etschtal und über die Lagunen",
          "kommen Sie nach Venedig. Im Reisepreis enthalten: Bahnreise 2. Klasse von Frankfurt nach Verona und",
          "zurück von Venedig inklusive Schafwagen. Tranfer von und zum Bahnhof in Verona und Venedig. 6",
          "Übernachtungen in ausgewählten Hotels inkl. Frühstück, 6 Abendessen, Picknickservice, Leih-Tourenrad",
          "mit 8-Gang-Schaltung, sämtliche Eintritte laut Programm, qualifizierte, ortskundige Reiseleitung,",
          "Kleinbus als Begleitfahrzeug, Gepäcktransport. Termin: 5. bis 12. April. Preis: 1399 € p. P. im DZ. 1"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Übernachten \"Im Namen der Rose” Li Berühmt wurde Kloster Eberbach 1988 als Schauplatz für die Innenaufnahmen zum Film \"DerNameder ! Rose\". Zwar gibt es heute kein klösterliches Leben mehr, aber das in seinen Baukörpern erhaltene ! Kloster gilt als das bedeutendste mittelalterliche Gesamtkunstwerk Hessens. Die jahrhundertealte ’ Weinbautradition hat sich bis heute fortgesetzt. Wer völlig unbeschwert die Weinverkostungen erleben L möchte, kann das \"Herbst-Winter-Wochenend-Spezial\" nutzen, das die Gastronomiebetriebe im Kloster Eberbach zusammengestellt haben. Das Angebot umfasst auch eine Übernachtung im Doppelzimmer 1 von Samstag auf Sonntag. Es beinhaltet zudem ein reichhaltiges Früstücksbuffet und ein 1 Vier-Gänge-Überraschungsmenü am Abend. Der Preis pro Person beträgt 97,- €. Weitere Informationen , gibt es bei den Gastronomiebetrieben im Kloster Eberbach, Eltville, unter Telefon 06723/993-0. I"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Tagestouren in Rheinhessen und im Rheingau",
          "Mit der Zahnstangenbahn auf den Wiesbadener Neroberg fahren, in Geisenheim mediterran kochen lernen, wandern mit Lamas und Alpakas als Begleiter, in Siefersheim mit Kräuterfrauen nach vergessenen Pflanzen suchen oder eine Führung durch Kloster Eberrbach mit anschließender Weinprobe - Ill Tipps für Tagestouren in Rheinhessen und im Rheingau stellt der neue Band \"Ein <rhänar Tao” unr Narıınter <ind atırh arhta Kahaimtinne Tim Raicniel wie Racııcher im Mainzer Nam"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Abend im Palladio Wenn die Tage kürzer und die Nächte kälter werden, ist es Zeit für Artistik, oC medy und Gaumenfreuden. Magier, Jongleure, Akrobaten und ein Vier-Gang-Gourmet-Menü im Schein hunderter Kerzen: Ein Abend im Palladio verspricht unterhaltsame Stunden mit perfektem Genuss im stilvollen Ambiente des traumhaft schönen, nostalgischen Spiegelpalastes. Das Gourmet-Theater Palladio serviert Ihnen seine charmante Mixtur aus hochkarätigem Entertainmente und exquisiter Kochkunst. Freuen Sie sich auf köstliche Menükreationen und erleben Sie dreieinhalb Stunden voller Humor und Lebensfreude. Lassen Sie sich verwöhnen und verzaubern! Dienstags bis sonntags sind wir für Sie da: Beginn ist jeweils um 20.00 Uhr. Foyer und Bar sind bereits 90 Minuten vor Showbeginn geöffnet."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Kloster Eberbach Kloster Eberbach mit seinen eindrucksvollen mittelalterlichen und barocken Bauten bietet seinen Gästen einzigartige Voraussetzungen für eine stilvolle Veranstaltung in altehrwürdigen Klostermauern. Sie können viele unserer repräsentativen Säle und prachtvollen Räume für Veranstaltungen anmieten. Ob Sie einen festlichen Empfang oder ein nobles Bankett planen oder ob Ihnen eine stilvolle Produktpräsentation vorschwebt: Hier lässt sich all dies hervorragend inszenieren. Die breite Palette unserer Räumlichkeiten und Gärten gibt Raum für Gesellschaften von 20 bis 1.000 Personen und lässt im Zusammenspiel mit dem Ambiente der Klosteranlage jede Veranstaltung zu einem ganz besonderen Ereignis werden. Hier finden Sie den richtigen Rahmen für Ihre Familienfeier, Ihr Seminar, Ihren Betriebsausflug, ein festliches Bankett oder eine Vortragsveranstaltung. Einige Räume sind zudem für Hochzeiten, Konzerte und Lesungen geeignet."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Stadt-Führer Frankfurt am Main. Kultur & mehr Viel Lob von der Lokalpresse für einen neuen Stadt-Führer über die Mainmetropole: Anne Schütz: Frankfurt am Main. Kultur & mehr. Paul Müller Verlag, 15,95 €. Dieser umfangreiche Reise-Führer wartet mit einer ganz besonderen Mischung auf: Rundgänge zur Stadtgeschichte stehen neben einer geballten Ladung an praktischen Informationen. Besonders gelungen ist es, wie die Autorin historische Details mit Spaziergängen verzahnt. Sie rennt keinen Trends hinterher, sondern führt als kenntnisreiche Begleiterin durch ihre Stadt. Ein praktischer Stadtkulturführer für Einheimische und Besucher mit Hunderten von Tipps, Adressen, Öffnungszeiten und Preisen von Parks und Bädern über schöne Lokale bis zu Museen, Theatern und Veranstaltungsorten."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Tour zu Schauplätzen der berühmtesten Kriminalfälle Frankfurts Der Historiker und Stadtfüher Peter Glock begleitet Sie auf einer interessanten zweistündigen Tour durch die Innenstadt zu Schauplätzen der berühmtesten Kriminalfälle in der Geschichte Frankfurts. Sie erfahren alles über spektakuläre Verbrechen, wie z. B. den Mord an Rosemarie Nitribitt, die Hinrichtung von Vinzenz Fettmilch im Jahre 1616 oder die Ermordung des Klavierhändlers Lichtenstein im Jahre 1904, als erstmals ein Mordfall durch die Abnahme von Fingerabdrücken aufgeklärt wurde. Die Führung findet jeden Sonntag ab 14.00 Uhr statt. Treffpunkt: aC fé Hauptwache."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Statistisches Jahrbuch der Stadt Frankfurt An einem durchschnittlichen Tag in Frankfurt werden 19 Babya geboren, sieben Brautpaare heiraten, aber fünf Ehepaare lassen sich scheiden. 136 Frankfurter ziehen im Stadtgebiet um, sechs neue Wohnungen werden fertiggestellt und acht Ausländer eingebürgert. Im Statistischen Jahrbuch der Stadt Frankfurt werden alle wichtigen Zahlen zum Leben, Arbeiten und Wohnen in der Stadt erfasst. Das Bürgeramt, Zeil 3, gibt den Bericht alljährlich heraus. Interessierte können das Statistische Jahrbuch im Internet herunterladen (www.frankfurt.de). Der Download ist kostenfrei."
        ]
      }
    ]
  },
  {
    "id": "22",
    "title": "Stadtführungen, Ausstellungen und Freizeit",
    "sourcePage": 292,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. ___11)Eine Bekannter möchte mit seiner zehnjährigen Tochter eine Ausstellung besuchen, es sollte auch Angebot für Kinder geben. ___12)Eine Freundin würde gerne als Stadtführerin arbeiten, hat aber noch keine Berufserfahrung. ___13)Eine Freundin kocht gerne und sucht neue Anregungen. ___14)Ihr Bruder möchte einen Vortrag zu einem historischen Thema hören. ___15)Ihr Nachbar plant eine Reise nach Berlin und sucht einen Stadtführer. ___16)Ihre Schwester möchte bald ihr Bad renovieren lassen. Sie sucht Bilder von modernen ___17)Ihre Tante möchte einen Vortrag über die Sehenswürdigkeiten Roms besuchen. ___18)Sie möchten im Urlaub an einer besonderen Stadtführung teilnehmen. ___19)Sie möchten wissen, wie Pflegeprodukte hergestellt werden. ___20)Sie mögen leichte Unterhaltung und würden gerne mal wieder richtig lachen Baden wie vor 2000 Jahren Das Museum der Badekultur lädt große und kleine Besucher zu einer informativen und kurz- weiligen Reise durch 2000 Jahre Badekultur ein. Die Besucher können römische Baderäume besichtigen. Sie erfahren auch, wie im Mittel- alter auf Burgen und in Städten Körperpflege betrieben und wie in Schlössern der Neuzeit gebadet wurde. Für Kinder ab 8 Jahren gibt es viel zu entdecken: Sie können die Ausstellung mithilfe eines Comics oder einer Museumsrallye erkunden. Multimediastationen führen spielerisch an die Geschichte des Badens heran, Museum der Badekultur Andreas-Bröicher-Platz 1 53909 Zülpich. Die Badsanierung steht vor der Tür? Dann besuchen Sie unsere große Bäderausstellung. Hier finden Sie Anregungen, können Marktneuheiten entdecken und sich von unseren Fachleuten beraten lassen. Über 50 Musterbäder warten darauf, von Ihnen erkundet zu werden. Besuchen Sie unsere Bäder- und Fliesemwelt und flanieren Sie in entspannter Atmosphäre durch unsere Schaubäder. Gemeinsam finden wir eine maßgeschneiderte Lösung für Sie! Dauerhafte Freude an Ihrem neuen Traumbad garantiert! Markus Köfer GmbH & Co. KG, Sanitär- und Heizungsfachhandlung, Georgstraße 3, 67059 Ludwigshafen Die Geschichte des Essens: Dessert jede Epoche hatte ihre eigenen Rezepte, Zu- taten und Techniken. Der Historiker und Ernäh- rungswissenschaftler Dr. Lukas Rombesheim stellt einige von ihnen in unserer Veranstaltungsreihe „Die Geschichte des Essens“ vor. Die Reihe berichtet Wissenswertes, Skurriles und Amüsantes aus den Küchen der Vergangenheit. Diesmal spricht er über Nachspeisen. Wir lernen unter anderem eines der ältesten erhaltenen Kuchenrezepte der Welt kennen, das um etwa 1400 vor Christus von den Sumerern in Keilschrift niedergeschrieben wurde. Mo, 8.10., 18:30 Uhr, Eintritt: 5 € Kulturhaus Landau, Speyerer Str. 10, 76829 Landau in Echt sizilianisch! Genießen wie auf Italiens sonnigster Insel Authentischer geht es nicht: 80 leckere Familienrezepte hat Stella Cascone aus der großen Sammlung ihrer Mutter Maria ausgewählt und in diesem außergewöhnlichen Kochbuch zusammengestellt. Vom Auberginenauflauf Parmigiana Catanese über die weltberühmte Torte Cassata bis zu den typischen Menüs für Familienfeiern und jahreszeitliche Feste hat Cascone – mit tatkräftiger Hilfe ihrer großen Familie – das Beste zusammengetragen, was die sizilianische Küche zu bieten hat. Viele Farbfotos machen das Buch zu einem wahren Augenschmaus. Genießen Sie die kulinarische Entdeckungsreise nach Sizilien! Sie planen ein neues Bad? In Ulrike Fergens Buch „Ein Bad fürs Leben“ finden Sie eine Fülle von Anregungen. Lösungen für die unterschiedlichsten Raumgrößen und Lebenssituationen werden präsentiert, Zahlreiche Bäder werden anhand von Grundrissen und Fotos anschaulich und detailliert vorgestellt. Außerdem ausführliche praktische Informationen zu: Planung und Ausführung • barrierefreien Bädern Licht • Farben, Materialien und Oberflächen Ausstattungslementen Installationen Gebundenes Buch, 29 € Ein Blick hinter die Kulissen Entdecken Sie die Welt von Alpen-Natur- kosmetik\"! Besichtigen Sie unsere Fabrik im Allgäu und erfahren Sie mehr über unsere Kosmetik bei einer Führung. Wir zeigen Ihnen die Labore, die Produktionsstätte bis hin zur Verpackung. Seit 1903 stellt Alpen- Naturkosmetik™ für hochwertige Seifen, Bade- zusätze und Cremes aus eigener Herstellung, die wir Ihnen durch Fabrikverkauf auch noch zu günstigen Preisen anbieten können. Jeder Gast erhält gratis ein Kosmetikprobenset zum Kennenlernen. Führungen jeden Freitag um 16 Uhr & Samstag um 13 Uhr (kostenfrei, ohne Alpen- Naturkosmetik, Memminger Str. 67, 87439 Kempten) Rom auf eigene Faust erkunden Wenn Sie alle Seiten der Tibermetropole selbstständig entdecken wollen, ist dieser Stadtführer Ihr idealer Begleiter. Sie finden: • Informationen über die wichtigsten Sehenswürdigkeiten und Museen der Stadt • vier abwechslungsreiche Stadtspaziergänge /Shoppingtipps vom traditionellen Markt bis zu den schönsten • die besten Lokale der Stadt und allerlei Wissenswertes über die römische Küche Außerdem: praktische Infos zu Anreise, Unterkünften, Preisen, Stadtverkehr, Touren, Hilfe im Notfall. Dazu: kostenlose Web-App für Smartphone, Tablet und PC mit Stadtplanansichten Taschenbuch, 220 Seiten, 19,90 € Rom bei Nacht Erleben Sie die Ewige Stadt nach Einbruch der Dunkelheit bei einer Besichtigungstour in einer kleinen Gruppe. Beginnen Sie Ihren Abend mit einer Pizza in einem klassischen römischen Restaurant und betrachten Sie die antiken Stätten und Monumente bei nächtlicher Beleuchtung. Besichtigen Sie das Kolosseum und spazieren Sie anschließend über die Piazza Navona. Vierstündige Tour zu den wichtigsten Sehenswürdigkeiten von Rom. Sehen Sie eine andere Seite der Stadt - genießen Sie einen Rundgang in den kühleren Abendstunden! Kleingruppentour im Kleinbus, Hoteltransfers inbegriffen Kontakt: info@rom-bei-nacht.de Sie kennen Berlin wie Ihre Westentasche? Dann bewerben Sie sich bei uns. Wir suchen ab sofort Stadtführer (m/w). Bei uns erwarten Sie eine familiäre, angenehme Arbeitsatmosphäre und eine gute Bezahlung. Voraussetzungen: Sie haben eine Prüfung als Stadtführer abgelegt und mindestens ein Jahr lang Touren geleitet. Sie können gut mit Menschen umgehen. Sie verfügen über gute Deutschkenntnisse, ein gepflegtes Erscheinungsbild und viel Humor? Dann schicken Sie uns Ihre Bewerbung. Wir freuen uns auf Sie! Stadtführungen Berlin GmbH E-Mail: bv@stadtführungen-berlin.net Was aßen die Kelten und Römer? Was stand vor knapp 2000 Jahren im Hunsrück auf dem Speiseplan? Darüber informiert die Ausstellung „Was aßen die Kelten und Römer?“ die am 12. Mai im Archäologiepark Belginum in Morbach-Wederath eröffnet wird. Der Archäologiepark Belginum ist ein an eine historischen Stätte erbautes Museum bei Wederath, das die Ergebnisse jahrzehntelanger archäologischer Ausgrabungen präsentiert. Die ehemals keltisch-römische Siedlung ist eine für Mitteleuropa einzigartige Fundstelle. Die Ausstellung ist bis zum 3. November zu sehen. Öffnungszeiten: 10 bis 17 Uhr, montags geschlossen Archäologiepark Belginum Keltentraße 2, 54497 Werden Sie Botschafter unserer Stadt/ Sie kennen sich gut in Koblenz aus, interessieren sich für die Geschichte von Stadt und Region und gehen gerne auf andere zu? Dann ist unsere Ausbildung zum Stadtführer das Richtige für Sie. Die Ausbildung umfasst 100 Stunden in Theorie und Praxis. Vorzugsweise suchen wir Teilnehmer, die eine Fremdsprache fließend beherrschen. Die Kosten liegen bei 400 € Die Teilnehmer können im Anschluss an diese Ausbildung als Stadtführer von der Koblenz-Tourismus GmbH gebucht werden. Neben den klassischen 1,5-stündigen Stadtführungen bieten wir auch eine Fülle von Themenführungen an Infos und Anmeldung: info@koblenz-tourismus.net Zwei Meister am Herd in der Filmkomödie „Zwei Meister am Herd dreht sich alles um Gourmets, Sterne und feinste Zutaten. Spitzenkoch Clement hat keine Freude mehr am Kochen - und zu seinem Unglück haben sich gerade Restaurant-Kritiker angekündigt. Da trifft es sich gut, dass es zufällig die Bekanntschaft von Oskar macht. Der ist Koch aus Leidenschaft, hält sich aber eher schlecht als recht mit Gelegenheitsjobs in Kneipen und Schnellimbissen über Wasser ... Werden die beiden zusammen die Kritik überzeugen?** Ein Feuerwerk aus Witz und Humor! Citykino, täglich",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Eine Bekannter möchte mit seiner zehnjährigen Tochter eine Ausstellung besuchen, es sollte h Angebot für Kinder geben."
      },
      {
        "num": 12,
        "answer": "k",
        "stem": "Eine Freundin würde gerne als Stadtführerin arbeiten, hat aber noch keine Berufserfahrung."
      },
      {
        "num": 13,
        "answer": "d",
        "stem": "Eine Freundin kocht gerne und sucht neue Anregungen."
      },
      {
        "num": 14,
        "answer": "j",
        "stem": "Ihr Bruder möchte einen Vortrag zu einem historischen Thema hören."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ihr Nachbar plant eine Reise nach Berlin und sucht einen Stadtführer."
      },
      {
        "num": 16,
        "answer": "e",
        "stem": "Ihre Schwester möchte bald ihr Bad renovieren lassen. Sie sucht Bilder von modernen dezimmern."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Ihre Tante möchte einen Vortrag über die Sehenswürdigkeiten Roms besuchen."
      },
      {
        "num": 18,
        "answer": "h",
        "stem": "Sie möchten im Urlaub an einer besonderen Stadtführung teilnehmen."
      },
      {
        "num": 19,
        "answer": "f",
        "stem": "Sie möchten wissen, wie Pflegeprodukte hergestellt werden."
      },
      {
        "num": 20,
        "answer": "l",
        "stem": "Sie mögen leichte Unterhaltung und würden gerne mal wieder richtig lachen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Baden wie vor 2000 Jahren Das Museum der Badekultur lädt große und kleine Besucher zu einer informativen und kurzweiligen Reise durch 2000 Jahre Badekultur ein. Die Besucher können römische Baderäume besichtigen. Sie erfahren auch, wie im Mittelalter auf Burgen und in Städten Körperpflege betrieben und wie in Schlössern der Neuzeit gebadet wurde. Für Kinder ab 8 Jahren gibt es viel zu entdecken: Sie können die Ausstellung mithilfe eines Comics oder einer Museumsrallye erkunden. Multimediastationen führen spielerisch an die Geschichte des Badens heran, Museum der Badekultur Andreas-Bröicher-Platz 1 53909 Zülpich."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Badsanierung steht vor der Tür? Dann besuchen Sie unsere große Bäderausstellung. Hier finden Sie Anregungen, können Marktneuheiten entdecken und sich von unseren Fachleuten beraten lassen. Über 50 Musterbäder warten darauf, von Ihnen erkundet zu werden. Besuchen Sie unsere Bäder- und Fliesemwelt und flanieren Sie in entspannter Atmosphäre durch unsere Schaubäder. Gemeinsam finden wir eine maßgeschneiderte Lösung für Sie! Dauerhafte Freude an Ihrem neuen Traumbad garantiert! Markus Köfer GmbH & Co. KG, Sanitär- und Heizungsfachhandlung, Georgstraße 3, 67059 Ludwigshafen"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Die Geschichte des Essens: Dessert jede Epoche hatte ihre eigenen Rezepte, Zutaten und Techniken. Der Historiker und Ernährungswissenschaftler Dr. Lukas Rombesheim stellt einige von ihnen in unserer Veranstaltungsreihe „Die Geschichte des Essens“ vor. Die Reihe berichtet Wissenswertes, Skurriles und Amüsantes aus den Küchen der Vergangenheit. Diesmal spricht er über Nachspeisen. Wir lernen unter anderem eines der ältesten erhaltenen Kuchenrezepte der Welt kennen, das um etwa 1400 vor Christus von den Sumerern in Keilschrift niedergeschrieben wurde. Mo, 8.10., 18:30 Uhr, Eintritt: 5 € Kulturhaus Landau, Speyerer Str. 10, 76829 Landau in der Pfalz"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Echt sizilianisch! Genießen wie auf Italiens sonnigster Insel Authentischer geht es nicht: 80 leckere Familienrezepte hat Stella Cascone aus der großen Sammlung ihrer Mutter Maria ausgewählt und in diesem außergewöhnlichen Kochbuch zusammengestellt. Vom Auberginenauflauf Parmigiana Catanese über die weltberühmte Torte Cassata bis zu den typischen Menüs für Familienfeiern und jahreszeitliche Feste hat Cascone – mit tatkräftiger Hilfe ihrer großen Familie – das Beste zusammengetragen, was die sizilianische Küche zu bieten hat. Viele Farbfotos machen das Buch zu einem wahren Augenschmaus. Genießen Sie die kulinarische Entdeckungsreise nach Sizilien!"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Ein Bad fürs Leben Sie planen ein neues Bad? In Ulrike Fergens Buch „Ein Bad fürs Leben“ finden Sie eine Fülle von Anregungen. Lösungen für die unterschiedlichsten Raumgrößen und Lebenssituationen werden präsentiert, Zahlreiche Bäder werden anhand von Grundrissen und Fotos anschaulich und detailliert vorgestellt. Außerdem ausführliche praktische Informationen zu: Planung und Ausführung • barrierefreien Bädern Licht • Farben, Materialien und Oberflächen Ausstattungslementen Installationen Gebundenes Buch, 29 €"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Ein Blick hinter die Kulissen Entdecken Sie die Welt von Alpen-Naturkosmetik\"! Besichtigen Sie unsere Fabrik im Allgäu und erfahren Sie mehr über unsere Kosmetik bei einer Führung. Wir zeigen Ihnen die Labore, die Produktionsstätte bis hin zur Verpackung. Seit 1903 stellt Alpen- Naturkosmetik™ für hochwertige Seifen, Badezusätze und Cremes aus eigener Herstellung, die wir Ihnen durch Fabrikverkauf auch noch zu günstigen Preisen anbieten können. Jeder Gast erhält gratis ein Kosmetikprobenset zum Kennenlernen. Führungen jeden Freitag um 16 Uhr & Samstag um 13 Uhr (kostenfrei, ohne Alpen- Naturkosmetik, Memminger Str. 67, 87439 Kempten)"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Rom auf eigene Faust erkunden",
          "Wenn Sie alle Seiten der Tibermetropole selbstständig entdecken wollen, ist dieser Stadtführer Ihr idealer Begleiter. Sie finden: « Informationen über die wichtigsten Sehenswürdigkeiten und Museen der Stadt",
          "« vier abwechslungsreiche Stadtspaziergänge /Shoppingtipps vom traditionellen Markt bis zu den schönsten Antiquitätengeschäften",
          "RR ae N a EN RENTEN nein"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Rom bei Nacht Erleben Sie die Ewige Stadt nach Einbruch der Dunkelheit bei einer Besichtigungstour in einer kleinen Gruppe. Beginnen Sie Ihren Abend mit einer Pizza in einem klassischen römischen Restaurant und betrachten Sie die antiken Stätten und Monumente bei nächtlicher Beleuchtung. Besichtigen Sie das Kolosseum und spazieren Sie anschließend über die Piazza Navona. Vierstündige Tour zu den wichtigsten Sehenswürdigkeiten von Rom. Sehen Sie eine andere Seite der Stadt - genießen Sie einen Rundgang in den kühleren Abendstunden! Kleingruppentour im Kleinbus, Hoteltransfers inbegriffen Kontakt: info@rom-bei-nacht.de"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Sie kennen Berlin wie Ihre Westentasche? Dann bewerben Sie sich bei uns. Wir suchen ab sofort Stadtführer (m/w). Bei uns erwarten Sie eine familiäre, angenehme Arbeitsatmosphäre und eine gute Bezahlung. Voraussetzungen: Sie haben eine Prüfung als Stadtführer abgelegt und mindestens ein Jahr lang Touren geleitet. Sie können gut mit Menschen umgehen. Sie verfügen über gute Deutschkenntnisse, ein gepflegtes Erscheinungsbild und viel Humor? Dann schicken Sie uns Ihre Bewerbung. Wir freuen uns auf Sie! Stadtführungen Berlin GmbH E-Mail: bv@stadtführungen-berlin.net"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Was aßen die Kelten und Römer? Was stand vor knapp 2000 Jahren im Hunsrück auf dem Speiseplan? Darüber informiert die Ausstellung „Was aßen die Kelten und Römer?“ die am 12. Mai im Archäologiepark Belginum in Morbach-Wederath eröffnet wird. Der Archäologiepark Belginum ist ein an eine historischen Stätte erbautes Museum bei Wederath, das die Ergebnisse jahrzehntelanger archäologischer Ausgrabungen präsentiert. Die ehemals keltisch-römische Siedlung ist eine für Mitteleuropa einzigartige Fundstelle. Die Ausstellung ist bis zum 3. November zu sehen. Öffnungszeiten: 10 bis 17 Uhr, montags geschlossen Archäologiepark Belginum Keltentraße 2, 54497 Morbach"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Werden Sie Botschafter unserer Stadt/ Sie kennen sich gut in Koblenz aus, interessieren sich für die Geschichte von Stadt und Region und gehen gerne auf andere zu? Dann ist unsere Ausbildung zum Stadtführer das Richtige für Sie. Die Ausbildung umfasst 100 Stunden in Theorie und Praxis. Vorzugsweise suchen wir Teilnehmer, die eine Fremdsprache fließend beherrschen. Die Kosten liegen bei 400 € Die Teilnehmer können im Anschluss an diese Ausbildung als Stadtführer von der Koblenz-Tourismus GmbH gebucht werden. Neben den klassischen 1,5-stündigen Stadtführungen bieten wir auch eine Fülle von Themenführungen an Infos und Anmeldung: info@koblenz-tourismus.net"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Zwei Meister am Herd in der Filmkomödie „Zwei Meister am Herd dreht sich alles um Gourmets, Sterne und feinste Zutaten. Spitzenkoch Clement hat keine Freude mehr am Kochen - und zu seinem Unglück haben sich gerade Restaurant-Kritiker angekündigt. Da trifft es sich gut, dass es zufällig die Bekanntschaft von Oskar macht. Der ist Koch aus Leidenschaft, hält sich aber eher schlecht als recht mit Gelegenheitsjobs in Kneipen und Schnellimbissen über Wasser ... Werden die beiden zusammen die Kritik überzeugen?** Ein Feuerwerk aus Witz und Humor! Citykino, täglich"
        ]
      }
    ]
  },
  {
    "id": "22a",
    "title": "Stadtführungen, Ausstellungen und Freizeit",
    "sourcePage": 295,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. ___11) Eine Frau möchte mit ihrem 10-jährigen Sohn eine Aktivität durchführen und erhält bei dieser Aktivität Ermäßigungen. ___12) Ihr Freund möchte als Stadtführer arbeiten und hat keine Erfahrungen. ___13) Ihr Bruder möchte etwas über historische Geschichten über Städte hören. ___14)Sie möchten Ihren Urlaub in Berlin verbringen und benötigen einen Stadtführer. ___15)Sie möchten irgendwo einen Urlaub mit besonderen Aktivitäten verbringen. ___16)Ihre Tante möchte bekannte Unterhaltungsmöglichkeiten in Rom besuchen oder sehen. ___17)Sie möchten wissen, wie man aus der Natur gewonnene Kosmetik zubereitet. ___18)Ihre Bekannte ist Köchin und sucht einen Job. ___19)Ihre Schwester erneuert ihr Badezimmer und sucht nach modernen Badezimmermodellen. ___20)Sie mögen leichte Unterhaltung und würden gerne mal wieder richtig lachen",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Eine Frau möchte mit ihrem 10-jährigen Sohn eine Aktivität durchführen und erhält bei ser Aktivität Ermäßigungen."
      },
      {
        "num": 12,
        "answer": "k",
        "stem": "Ihr Freund möchte als Stadtführer arbeiten und hat keine Erfahrungen."
      },
      {
        "num": 13,
        "answer": "j",
        "stem": "Ihr Bruder möchte etwas über historische Geschichten über Städte hören."
      },
      {
        "num": 14,
        "answer": "x",
        "stem": "Sie möchten Ihren Urlaub in Berlin verbringen und benötigen einen Stadtführer."
      },
      {
        "num": 15,
        "answer": "h",
        "stem": "Sie möchten irgendwo einen Urlaub mit besonderen Aktivitäten verbringen."
      },
      {
        "num": 16,
        "answer": "x",
        "stem": "Ihre Tante möchte bekannte Unterhaltungsmöglichkeiten in Rom besuchen oder sehen."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Sie möchten wissen, wie man aus der Natur gewonnene Kosmetik zubereitet."
      },
      {
        "num": 18,
        "answer": "d",
        "stem": "Ihre Bekannte ist Köchin und sucht einen Job."
      },
      {
        "num": 19,
        "answer": "e",
        "stem": "Ihre Schwester erneuert ihr Badezimmer und sucht nach modernen Badezimmermodellen."
      },
      {
        "num": 20,
        "answer": "l",
        "stem": "Sie mögen leichte Unterhaltung und würden gerne mal wieder richtig lachen"
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Baden wie vor 2000 Jahren Das Museum der Badekultur lädt große und kleine Besucher zu einer informativen und kurzweiligen Reise durch 2000 Jahre Badekultur ein. Die Besucher können römische Baderäume besichtigen. Sie erfahren auch, wie im Mittelalter auf Burgen und in Städten Körperpflege betrieben und wie in Schlössern der Neuzeit gebadet wurde. Für Kinder ab 8 Jahren gibt es viel zu entdecken: Sie können die Ausstellung mithilfe eines Comics oder einer Museumsrallye erkunden. Multimediastationen führen spielerisch an die Geschichte des Badens heran, Museum der Badekultur Andreas-Bröicher-Platz 1 53909 Zülpich."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Badsanierung steht vor der Tür? Dann besuchen Sie unsere große Bäderausstellung. Hier finden Sie Anregungen, können Marktneuheiten entdecken und sich von unseren Fachleuten beraten lassen. Über 50 Musterbäder warten darauf, von Ihnen erkundet zu werden. Besuchen Sie unsere Bäder- und Fliesemwelt und flanieren Sie in entspannter Atmosphäre durch unsere Schaubäder. Gemeinsam finden wir eine maßgeschneiderte Lösung für Sie! Dauerhafte Freude an Ihrem neuen Traumbad garantiert! Markus Köfer GmbH & Co. KG, Sanitär- und Heizungsfachhandlung, Georgstraße 3, 67059 Ludwigshafen"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Die Geschichte des Essens: Dessert jede Epoche hatte ihre eigenen Rezepte, Zutaten und Techniken. Der Historiker und Ernährungswissenschaftler Dr. Lukas Rombesheim stellt einige von ihnen in unserer Veranstaltungsreihe „Die Geschichte des Essens“ vor. Die Reihe berichtet Wissenswertes, Skurriles und Amüsantes aus den Küchen der Vergangenheit. Diesmal spricht er über Nachspeisen. Wir lernen unter anderem eines der ältesten erhaltenen Kuchenrezepte der Welt kennen, das um etwa 1400 vor Christus von den Sumerern in Keilschrift niedergeschrieben wurde. Mo, 8.10., 18:30 Uhr, Eintritt: 5 € Kulturhaus Landau, Speyerer Str. 10, 76829 Landau in der Pfalz"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Echt sizilianisch! Genießen wie auf Italiens sonnigster Insel Authentischer geht es nicht: 80 leckere Familienrezepte hat Stella Cascone aus der großen Sammlung ihrer Mutter Maria ausgewählt und in diesem außergewöhnlichen Kochbuch zusammengestellt. Vom Auberginenauflauf Parmigiana Catanese über die weltberühmte Torte Cassata bis zu den typischen Menüs für Familienfeiern und jahreszeitliche Feste hat Cascone – mit tatkräftiger Hilfe ihrer großen Familie – das Beste zusammengetragen, was die sizilianische Küche zu bieten hat. Viele Farbfotos machen das Buch zu einem wahren Augenschmaus. Genießen Sie die kulinarische Entdeckungsreise nach Sizilien!"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Ein Bad fürs Leben Sie planen ein neues Bad? In Ulrike Fergens Buch „Ein Bad fürs Leben“ finden Sie eine Fülle von Anregungen. Lösungen für die unterschiedlichsten Raumgrößen und Lebenssituationen werden präsentiert, Zahlreiche Bäder werden anhand von Grundrissen und Fotos anschaulich und detailliert vorgestellt. Außerdem ausführliche praktische Informationen zu: Planung und Ausführung • barrierefreien Bädern Licht • Farben, Materialien und Oberflächen Ausstattungslementen Installationen Gebundenes Buch, 29 €"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Ein Blick hinter die Kulissen Entdecken Sie die Welt von Alpen-Naturkosmetik\"! Besichtigen Sie unsere Fabrik im Allgäu und erfahren Sie mehr über unsere Kosmetik bei einer Führung. Wir zeigen Ihnen die Labore, die Produktionsstätte bis hin zur Verpackung. Seit 1903 stellt Alpen- Naturkosmetik™ für hochwertige Seifen, Badezusätze und Cremes aus eigener Herstellung, die wir Ihnen durch Fabrikverkauf auch noch zu günstigen Preisen anbieten können. Jeder Gast erhält gratis ein Kosmetikprobenset zum Kennenlernen. Führungen jeden Freitag um 16 Uhr & Samstag um 13 Uhr (kostenfrei, ohne Alpen- Naturkosmetik, Memminger Str. 67, 87439 Kempten)"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Rom auf eigene Faust erkunden",
          "Wenn Sie alle Seiten der Tibermetropole selbstständig entdecken wollen, ist dieser Stadtführer Ihr idealer Begleiter. Sie finden: « Informationen über die wichtigsten Sehenswürdigkeiten und Museen der Stadt",
          "« vier abwechslungsreiche Stadtspaziergänge /Shoppingtipps vom traditionellen Markt bis zu den schönsten Antiquitätengeschäften",
          "RR ae N a EN RENTEN nein"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Rom bei Nacht Erleben Sie die Ewige Stadt nach Einbruch der Dunkelheit bei einer Besichtigungstour in einer kleinen Gruppe. Beginnen Sie Ihren Abend mit einer Pizza in einem klassischen römischen Restaurant und betrachten Sie die antiken Stätten und Monumente bei nächtlicher Beleuchtung. Besichtigen Sie das Kolosseum und spazieren Sie anschließend über die Piazza Navona. Vierstündige Tour zu den wichtigsten Sehenswürdigkeiten von Rom. Sehen Sie eine andere Seite der Stadt - genießen Sie einen Rundgang in den kühleren Abendstunden! Kleingruppentour im Kleinbus, Hoteltransfers inbegriffen Kontakt: info@rom-bei-nacht.de"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Sie kennen Berlin wie Ihre Westentasche? Dann bewerben Sie sich bei uns. Wir suchen ab sofort Stadtführer (m/w). Bei uns erwarten Sie eine familiäre, angenehme Arbeitsatmosphäre und eine gute Bezahlung. Voraussetzungen: Sie haben eine Prüfung als Stadtführer abgelegt und mindestens ein Jahr lang Touren geleitet. Sie können gut mit Menschen umgehen. Sie verfügen über gute Deutschkenntnisse, ein gepflegtes Erscheinungsbild und viel Humor? Dann schicken Sie uns Ihre Bewerbung. Wir freuen uns auf Sie! Stadtführungen Berlin GmbH E-Mail: bv@stadtführungen-berlin.net"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Was aßen die Kelten und Römer? Was stand vor knapp 2000 Jahren im Hunsrück auf dem Speiseplan? Darüber informiert die Ausstellung „Was aßen die Kelten und Römer?“ die am 12. Mai im Archäologiepark Belginum in Morbach-Wederath eröffnet wird. Der Archäologiepark Belginum ist ein an eine historischen Stätte erbautes Museum bei Wederath, das die Ergebnisse jahrzehntelanger archäologischer Ausgrabungen präsentiert. Die ehemals keltisch-römische Siedlung ist eine für Mitteleuropa einzigartige Fundstelle. Die Ausstellung ist bis zum 3. November zu sehen. Öffnungszeiten: 10 bis 17 Uhr, montags geschlossen Archäologiepark Belginum Keltentraße 2, 54497 Morbach"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Werden Sie Botschafter unserer Stadt/ Sie kennen sich gut in Koblenz aus, interessieren sich für die Geschichte von Stadt und Region und gehen gerne auf andere zu? Dann ist unsere Ausbildung zum Stadtführer das Richtige für Sie. Die Ausbildung umfasst 100 Stunden in Theorie und Praxis. Vorzugsweise suchen wir Teilnehmer, die eine Fremdsprache fließend beherrschen. Die Kosten liegen bei 400 € Die Teilnehmer können im Anschluss an diese Ausbildung als Stadtführer von der Koblenz-Tourismus GmbH gebucht werden. Neben den klassischen 1,5-stündigen Stadtführungen bieten wir auch eine Fülle von Themenführungen an Infos und Anmeldung: info@koblenz-tourismus.net"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Zwei Meister am Herd in der Filmkomödie „Zwei Meister am Herd dreht sich alles um Gourmets, Sterne und feinste Zutaten. Spitzenkoch Clement hat keine Freude mehr am Kochen - und zu seinem Unglück haben sich gerade Restaurant-Kritiker angekündigt. Da trifft es sich gut, dass es zufällig die Bekanntschaft von Oskar macht. Der ist Koch aus Leidenschaft, hält sich aber eher schlecht als recht mit Gelegenheitsjobs in Kneipen und Schnellimbissen über Wasser ... Werden die beiden zusammen die Kritik überzeugen?** Ein Feuerwerk aus Witz und Humor! Citykino, täglich"
        ]
      }
    ]
  },
  {
    "id": "23",
    "title": "Autos, Finanzen und Versicherung",
    "sourcePage": 296,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11) Ein Bekannter interessiert sich für wertvolle alte Fahrzeuge. 12) Eine Nachbarin möchte für ihr neues Auto eine Versicherung abschließen. 13) Ihr Bruder möchte in einem Kurs sein Wissen über Finanzen erweitern. 14) Ihr Cousin würde gerne mal mit einem schnellen Sportwagen fahren. 15) Ihr Sohn interessiert sich für schnelle Autos. Sie suchen für ihn ein Buch mit Bildern. 16) Ihr Nachbar braucht einen neuen Kühlschrank und möchte sich über verschiedene Modelle 17) Ihre Schwester hat kein Auto. Für gelegentliche Fahrten sucht sie eine Alternative zu öffentlichen, Verkehrsmitteln. 18) Sie brauchen bald neue Haushaltsgeräte, haben aber noch nicht genug Geld gespart. 19) Sie möchten auf Ihren PKW verzichten und suchen Tipps. • Möglichkeiten der Budgetplanung • Einnahmen und Ausgaben erfassen und analysieren • Einsparpotenziale erkennen • Schuldenfallen vermeiden Samstag, 14.7 Der finanzielle Blick in die Zukunft • Finanzentscheidungen planen und umsetzen • Kreditentscheidungen bewusst treffen • Schulden aktiv angehen Referent: Diplom-Ökonom Martin Herges Uhrzeit: jeweils 10 bis 15 Uhr 20) Sie hatten eine hohe Stromrechnung und möchten wissen, wie viel Energie die Geräte in Ihrem Alles rund um das Thema Geld. Workshop für Verbraucherinnen und Verbraucher. Samstag, 7.7. Teilnahmegebühr: 50 € Akademie der DPV-Bank, Gustavstr. 12, 33659 Bielefeld Sparen–Steuern–Altersvorsorge Nehmen Sie Ihre Finanzen selbst in die Hand: Ob Sie für Ihre Rente vorsorgen wollen oder einfach mehr sparen wollen – das neue Buch des Finanzexperten Kai Mueggenburg liefert Ihnen wertvolle Informationen. Es stellt Ihnen ein umfangreiches Basiswissen zum Thema Geld zur Verfügung. Außerdem bekommen Sie Tipps, wie Sie Ihre eigene Spar- und Investitionsstrategie erarbeiten können. Das Buch zeigt auf leicht verständliche Weise, wie man sein Geld einfach und gut anlegen kann. Es enthält außerdem Checklisten, eine Liste mit wichtigen Adressen und ein umfangreiches Glossar. Energiesparen leicht gemacht Hohe Strompreise sind für viele eine Belastung. Wenn ein neues Gerät angeschafft werden muss, sollte man vor allem auf die Energiekosten achten: Denn ein billiges Gerät, das viel Strom verbraucht, wird mit der Zeit ziemlich teuer! Mit sparsamen Wäschetrocknern, Geschirrspülern etc. kann man dagegen die Kosten senken. Doch wie findet man die passenden Geräte? Wir haben die besten für Sie ausgewählt: Auf unserer Website finden Sie eine Liste und weiterführende Tipps. Dort können Sie kostenlos nach Geräten mit bestimmter Bauart, Größe oder Effizienz suchen. Entspannt unterwegs in der Stadt und auf dem Land Ohne Auto lebt man einfacher und glücklicher. Und zwar nicht nur als Großstadtsingle, sondern auch als Familie auf dem Land. Davon ist Susanne Sonnental jedenfalls überzeugt. Seit fünf Jahren lebt sie mit ihrer Familie auf dem Dorf und zwar ohne Auto. In dem Buch erzählt sie, wie ihr Alltag aussieht, und liefert viele nützliche Informationen. Sie zeigt jede Menge leicht umsetzbarer Alternativen. Sie planen ein neues Bad? In Ulrike Fergens Buch „Ein Bad fürs Leben“ finden Sie eine Fülle von Anregungen. Lösungen für die unterschiedlichsten Raumgrößen und Lebenssituationen werden präsentiert, Zahlreiche Bäder werden anhand von Grundrissen und Fotos anschaulich und detailliert vorgestellt. Außerdem ausführliche praktische Informationen zu: Planung und Ausführung • barrierefreien Bädern Licht • Farben, Materialien und Oberflächen Ausstattungslementen Installationen Gebundenes Buch, 29 € Entdeckungsreise in die Welt der Technik Willkommen im Technikmuseum Walldorf. Begeben Sie sich auf eine Zeitreise und entdecken Sie die Meilensteine der Technikgeschichte. Unsere Hauptattraktionen sind die beiden Überschallflugzeuge Concorde und Tupolew Tu-144. Außerdem: weitere Flugzeuge, Oldtimer, historische Luxusautomobile und Rennwagen, Motorräder, nostalgische Rennräder und Dampfklos. Mehr als 3.000 Exponate auf einer Fläche von über 50.000 m². Für Kinder: Spielplatz, Fahrsimulatoren und Spieleparadies mit fahrbaren Mini-Autos. Öffnungszeiten: täglich von 9 bis 18 Uhr Technikmuseum Walldorf, Schwetzinger Str. 23, 69190 Walldorf Mobilität in der Stadt von morgen Erstmals in der Weltgeschichte leben mehr Menschen in Städten als auf dem Lane. Welche Auswirkungen wird dieser Trend auf die Mobilität der Zukunft haben? Und welche Rolle wird das Auto dabei spielen? Über diese Fragen spricht Mobilitätsexperte Dr. Hans-Peter Grafemeyer. Fußgängerzonen, Fahrradfahren, öffentlicher Personennahverkehr, Bahn, Carsharing-Modelle – dies alles wird den Verkehr von morgen bestimmen. Der Vortrag bietet Informationen über innovative Technologien und neue Mobilitätsformen. Freiburgstr. 3, 64720 Michelstadt Ohne Versicherung geht es nicht... Auf Versicherungen kann niemand verzichten. Die Versicherungsbranche bietet Arbeitsplätze mit Zukunft und hervorragende Jobaussichten! Wir suchen eine/n Auszubildende/n zum Versicherungskaufmann/zur Versicherungskauffrau. Sind Sie aufgeschlossen gegenüber Kunden und gut im Umgang mit dem Computer? Arbeiten Sie gerne im Büro wie auch im Außendienst? Sind Sie fit in Mathe und bringen Verständnis für Zahlen mit? Dann bewerben Sie sich bei uns! Weitere Informationen hier: Liga-Versicherung Deutschland AG www.liga-versicherung.de/auszubildende Rasantes Abenteuer für Autofans Sie interessieren sich für Rennwagen und würden gerne selbst einmal mit Vollgas fahren? Unser Ferrari-Fahrtraining auf der Rollbahn eines Flugplatzes macht dies möglich. Vor dem Fahrtraining erläutern wir Ihnen die Sicherheitsregeln und geben Ihnen Hinweise für die Fahrt. Danach können Sie sich direkt ans Steuer setzen. Fahren Sie ein Traumauto ohne Geschwindigkeitsbegrenzung! Freuen Sie sich auf grenzenlosen Fahrspaß! Mindestalter 18 Jahre, gültiger Führerschein der Klasse B www.fahrtraining-flugplatz.net Unkompliziert und spontan unterwegs sein? Wir haben die Lösung für Sie: Mieten Sie einfach ein Fahrzeug in Ihrer Nähe. Ob Kleinwagen, Kombi, Cabrio, E-Auto, Bus oder Transporter – wir haben die größte Auswahl an Carsharing-Autos in Nürnberg. • günstiger als ein eigenes Fahrzeug • rund um die Uhr verfügbar • Kraftstoff, Wartung und Vollkasko inklusive • passendes Fahrzeug immer und jederzeit an Stationen in Ihrer Nähe verfügbar • einfache Online-Buchung • keine Grundkosten oder Mindestlaufzeit Registrieren Sie sich einfach über unsere Smartphone-App und fahren Sie los. Versteckte Kosten? Wollen Sie wissen, wie viel Strom Ihr Kühlschrank, Wasserkocher und Staubsauger benötigen? Haben Sie Stromfresser in Ihrer Wohnung, die die Kosten hochtreiben? Das Strommessgerät Smart Check 365 findet sie. Smart Check 365 misst zuverlässig den Verbrauch Ihrer Geräte und berechnet automatisch die Stromkosten. Auf dem hochauflösenden LCD-Display lassen sich alle Ergebnisse leicht ablesen. Einfach und sicher zu bedienen, aus sicherem und umweltfreundlichem Material. Ideal zur Überwachung des Stromverbrauchs in Ihrem Zuhause. 100 Prozent Zufriedenheitsgarantie! Smart Check 365, Preis: 17,99 € Warum noch länger warten? Eine neue Küche, eine berufliche Weiterbildung oder ein modernes Heimkino: Wenn keine Rücklagen da sind, hilft ein Verbraucherkredit der Vergobank weiter. Finanzieren Sie Ihre Wünsche einfach in festen monatlichen Raten. Flexibel von 1.000 Euro bis 50.000 Euro, schnell und sicher. • individuelle Laufzeit und Raten nach Ihren Bedürfnissen, schon ab 50 € im Monat • schnelle Online-Kreditentscheidung und Auszahlung Der günstige Weg, wie Sie sich Ihre Wünsche schnell erfüllen können. Sie haben Fragen? Vereinbaren Sie hier Ihren Beratungstermin.",
    "questions": [
      {
        "num": 11,
        "answer": "f",
        "stem": "Ein Bekannter interessiert sich für wertvolle alte Fahrzeuge."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Eine Nachbarin möchte für ihr neues Auto eine Versicherung abschließen."
      },
      {
        "num": 13,
        "answer": "a",
        "stem": "Ihr Bruder möchte in einem Kurs sein Wissen über Finanzen erweitern."
      },
      {
        "num": 14,
        "answer": "i",
        "stem": "Ihr Cousin würde gerne mal mit einem schnellen Sportwagen fahren."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ihr Sohn interessiert sich für schnelle Autos. Sie suchen für ihn ein Buch mit Bildern."
      },
      {
        "num": 16,
        "answer": "d",
        "stem": "Ihr Nachbar braucht einen neuen Kühlschrank und möchte sich über verschiedene Modelle informieren."
      },
      {
        "num": 17,
        "answer": "j",
        "stem": "Ihre Schwester hat kein Auto. Für gelegentliche Fahrten sucht sie eine Alternative zu öffentlichen, Verkehrsmitteln."
      },
      {
        "num": 18,
        "answer": "l",
        "stem": "Sie brauchen bald neue Haushaltsgeräte, haben aber noch nicht genug Geld gespart."
      },
      {
        "num": 19,
        "answer": "e",
        "stem": "Sie möchten auf Ihren PKW verzichten und suchen Tipps."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Sie hatten eine hohe Stromrechnung und möchten wissen, wie viel Energie die Geräte in Ihrem Haushalt verbrauchen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Alles rund um das Thema Geld. Workshop für Verbraucherinnen und Verbraucher. Samstag, 7.7. • Möglichkeiten der Budgetplanung • Einnahmen und Ausgaben erfassen und analysieren • Einsparpotenziale erkennen • Schuldenfallen vermeiden Samstag, 14.7 Der finanzielle Blick in die Zukunft • Finanzentscheidungen planen und umsetzen • Sparen und anlegen • Kreditentscheidungen bewusst treffen • Schulden aktiv angehen Referent: Diplom-Ökonom Martin Herges Uhrzeit: jeweils 10 bis 15 Uhr Teilnahmegebühr: 50 € Akademie der DPV-Bank, Gustavstr. 12, 33659 Bielefeld"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Die Geldschule: Sparen–Steuern–Altersvorsorge Nehmen Sie Ihre Finanzen selbst in die Hand: Ob Sie für Ihre Rente vorsorgen wollen oder einfach mehr sparen wollen – das neue Buch des Finanzexperten Kai Mueggenburg liefert Ihnen wertvolle Informationen. Es stellt Ihnen ein umfangreiches Basiswissen zum Thema Geld zur Verfügung. Außerdem bekommen Sie Tipps, wie Sie Ihre eigene Spar- und Investitionsstrategie erarbeiten können. Das Buch zeigt auf leicht verständliche Weise, wie man sein Geld einfach und gut anlegen kann. Es enthält außerdem Checklisten, eine Liste mit wichtigen Adressen und ein umfangreiches Glossar. Taschenbuch, 14,80 €"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Energiesparen leicht gemacht Hohe Strompreise sind für viele eine Belastung. Wenn ein neues Gerät angeschafft werden muss, sollte man vor allem auf die Energiekosten achten: Denn ein billiges Gerät, das viel Strom verbraucht, wird mit der Zeit ziemlich teuer! Mit sparsamen Wäschetrocknern, Geschirrspülern etc. kann man dagegen die Kosten senken. Doch wie findet man die passenden Geräte? Wir haben die besten für Sie ausgewählt: Auf unserer Website finden Sie eine Liste und weiterführende Tipps. Dort können Sie kostenlos nach Geräten mit bestimmter Bauart, Größe oder Effizienz suchen. www.tech-check.ne"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Entspannt unterwegs in der Stadt und auf dem Land Ohne Auto lebt man einfacher und glücklicher. Und zwar nicht nur als Großstadtsingle, sondern auch als Familie auf dem Land. Davon ist Susanne Sonnental jedenfalls überzeugt. Seit fünf Jahren lebt sie mit ihrer Familie auf dem Dorf und zwar ohne Auto. In dem Buch erzählt sie, wie ihr Alltag aussieht, und liefert viele nützliche Informationen. Sie zeigt jede Menge leicht umsetzbarer Alternativen. Taschenbuch, 12,90€"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Ein Bad fürs Leben Sie planen ein neues Bad? In Ulrike Fergens Buch „Ein Bad fürs Leben“ finden Sie eine Fülle von Anregungen. Lösungen für die unterschiedlichsten Raumgrößen und Lebenssituationen werden präsentiert, Zahlreiche Bäder werden anhand von Grundrissen und Fotos anschaulich und detailliert vorgestellt. Außerdem ausführliche praktische Informationen zu: Planung und Ausführung • barrierefreien Bädern Licht • Farben, Materialien und Oberflächen Ausstattungslementen Installationen Gebundenes Buch, 29 €"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Entdeckungsreise in die Welt der Technik Willkommen im Technikmuseum Walldorf. Begeben Sie sich auf eine Zeitreise und entdecken Sie die Meilensteine der Technikgeschichte. Unsere Hauptattraktionen sind die beiden Überschallflugzeuge Concorde und Tupolew Tu-144. Außerdem: weitere Flugzeuge, Oldtimer, historische Luxusautomobile und Rennwagen, Motorräder, nostalgische Rennräder und Dampfklos. Mehr als 3.000 Exponate auf einer Fläche von über 50.000 m². Für Kinder: Spielplatz, Fahrsimulatoren und Spieleparadies mit fahrbaren Mini-Autos. Öffnungszeiten: täglich von 9 bis 18 Uhr Technikmuseum Walldorf, Schwetzinger Str. 23, 69190 Walldorf"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Mobilität in der Stadt von morgen Erstmals in der Weltgeschichte leben mehr Menschen in Städten als auf dem Lane. Welche Auswirkungen wird dieser Trend auf die Mobilität der Zukunft haben? Und welche Rolle wird das Auto dabei spielen? Über diese Fragen spricht Mobilitätsexperte Dr. Hans-Peter Grafemeyer. Fußgängerzonen, Fahrradfahren, öffentlicher Personennahverkehr, Bahn, Carsharing-Modelle – dies alles wird den Verkehr von morgen bestimmen. Der Vortrag bietet Informationen über innovative Technologien und neue Mobilitätsformen. Mittwoch, 8.9., 19 Uhr"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Ohne Versicherung geht es nicht... Auf Versicherungen kann niemand verzichten. Die Versicherungsbranche bietet Arbeitsplätze mit Zukunft und hervorragende Jobaussichten! Wir suchen eine/n Auszubildende/n zum Versicherungskaufmann/zur Versicherungskauffrau. Sind Sie aufgeschlossen gegenüber Kunden und gut im Umgang mit dem Computer? Arbeiten Sie gerne im Büro wie auch im Außendienst? Sind Sie fit in Mathe und bringen Verständnis für Zahlen mit? Dann bewerben Sie sich bei uns! Weitere Informationen hier: Liga-Versicherung Deutschland AG www.liga-versicherung.de/auszubildende"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Rasantes Abenteuer für Autofans Sie interessieren sich für Rennwagen und würden gerne selbst einmal mit Vollgas fahren? Unser Ferrari-Fahrtraining auf der Rollbahn eines Flugplatzes macht dies möglich. Vor dem Fahrtraining erläutern wir Ihnen die Sicherheitsregeln und geben Ihnen Hinweise für die Fahrt. Danach können Sie sich direkt ans Steuer setzen. Fahren Sie ein Traumauto ohne Geschwindigkeitsbegrenzung! Freuen Sie sich auf grenzenlosen Fahrspaß! Mindestalter 18 Jahre, gültiger Führerschein der Klasse B Mehr Informationen hier: www.fahrtraining-flugplatz.net"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Unkompliziert und spontan unterwegs sein? Wir haben die Lösung für Sie: Mieten Sie einfach ein Fahrzeug in Ihrer Nähe. Ob Kleinwagen, Kombi, Cabrio, E-Auto, Bus oder Transporter – wir haben die größte Auswahl an Carsharing-Autos in Nürnberg. Ihre Vorteile: • günstiger als ein eigenes Fahrzeug • rund um die Uhr verfügbar • Kraftstoff, Wartung und Vollkasko inklusive • passendes Fahrzeug immer und jederzeit an Stationen in Ihrer Nähe verfügbar • einfache Online-Buchung • keine Grundkosten oder Mindestlaufzeit Registrieren Sie sich einfach über unsere Smartphone-App und fahren Sie los. www.auto-to-go.net"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Versteckte Kosten? Wollen Sie wissen, wie viel Strom Ihr Kühlschrank, Wasserkocher und Staubsauger benötigen? Haben Sie Stromfresser in Ihrer Wohnung, die die Kosten hochtreiben? Das Strommessgerät Smart Check 365 findet sie. Smart Check 365 misst zuverlässig den Verbrauch Ihrer Geräte und berechnet automatisch die Stromkosten. Auf dem hochauflösenden LCD-Display lassen sich alle Ergebnisse leicht ablesen. Einfach und sicher zu bedienen, aus sicherem und umweltfreundlichem Material. Ideal zur Überwachung des Stromverbrauchs in Ihrem Zuhause. 100 Prozent Zufriedenheitsgarantie! Smart Check 365, Preis: 17,99 €"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Warum noch länger warten? Eine neue Küche, eine berufliche Weiterbildung oder ein modernes Heimkino: Wenn keine Rücklagen da sind, hilft ein Verbraucherkredit der Vergobank weiter. Finanzieren Sie Ihre Wünsche einfach in festen monatlichen Raten. Flexibel von 1.000 Euro bis 50.000 Euro, schnell und sicher. Ihre Vorteile: • keine Anzahlung • günstige Zinssätze • individuelle Laufzeit und Raten nach Ihren Bedürfnissen, schon ab 50 € im Monat • schnelle Online-Kreditentscheidung und Auszahlung Der günstige Weg, wie Sie sich Ihre Wünsche schnell erfüllen können."
        ]
      }
    ]
  },
  {
    "id": "24",
    "title": "Museen, Tiere und Familienausflüge",
    "sourcePage": 299,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11) Ein Bekannter interessiert sich für Tierdokumentationen und würde gerne wissen, wie solche 12) Eine Bekannte würde gerne gemeinsam mit einer Gruppe im Wald wandern gehen 13) Ihr Onkel möchte sich eine Ausstellung mit Gemälden ansehen 14) Ihr siebenjähriger Neffe liebt Phantasievolle Geschichten. Sie wollen nachmittags etwas mit ihm 15) Ihr Sohn wird nächste Woche zehn Jahre alt. Sie möchten ihn mit einer besonderen Feier 16) Ihre 16 jährige Nichte interessiert sich für heimische Tierwelt und würde sich gerne einen Film 17) Ihre zehnjährige Tochter zeichnet viel und möchte ihre Fähigkeiten weiter verbessern. 18) Sie möchten einen Vortrag über bedrohte Tiere und Naturschutz besuchen. 19) Sie suchen ein Geschenk für einen Freund, der sich für Kunst interessiert. Auf den Spuren der Wildkatze Öffnungszeiten: täglich von 10 bis 18 Uhr 20) Sie würden gerne abends etwas mit Freunden draußen unternehmen und dabei sportlich aktiv Im Wildkatzendorf Hütscheroda, am National -Park Hainich gelegen, erfahren Sie alles über die scheuen Tiere hautnah beobachten können Sie sie in der Schauanlage \"Wildkatzenlichtung\" Hier wird auf Informationstafeln auch das „Rettungsnetz für die Wildkatze\" vorgestellt eines der größten Naturschutzprojekte Europas. Täglich finden Schaufütterungen statt, für die man sich telefonisch anmelden kann, für die Kleinen, haben wir ein spannendes Angebot: Das Wildkatzendorf bietet Kindergeburtstage mit einem bunten Programm an und bietet spezielle Ausstellung im Park Schon zum dritten Mal stellen am Pfingst-Wochenende Künstler aus der Region im Kurpark Bad Homburg ihre Exponate aus. Gezeigt werden Zeichnungen, Keramiken, Schmuck, Textilarbeiten sowie zahlreiche Holzskulpturen. Sie können mit den Künstlern ins Gespräch kommen und ihnen beim Arbeiten zusehen. Vor Ort über die Schulter blicken! Einen schön gestalteten Bildband mit Werken der ausstellenden Künstler erhalten Sie in der Buchhandlung am Park und der Touristeninformation für 30 €. Öffnungszeiten: 31. Mai und 1. Juni von 11 bis 19 Uhr Am 1. August zeigen wir den 90-minütigen Film „Der Natur auf der Spur“. Dieser begleitet fünf der besten und erfolgreichsten Tierfilmer der Welt auf ihren Reisen rund um den Globus. Sie alle versuchen, vor beeindruckenden Naturkulissen außergewöhnliche Tieraufnahmen einzufangen. Die Leidenschaft für ihre Filme lässt die Filmemacher große Anstrengungen und Gefahren in Kauf nehmen. In dem Film erfahren Sie nicht nur, wie Tierfilmer arbeiten, sondern auch, welche Ausstattung sie einsetzen und wie die Dreharbeiten vorbereitet werden. Filmabend der VHS Buchholz, 1.8., Beginn: 19 Uhr Eintritt: 5 € Entspannte Sommernächte Genießen Sie sechs Tage Filmvergüngen unter dem Sternenhimmel, in bequemen Liegestühlen vor einer nachtblauen Naturkulisse. Besuchen Sie unsere Open-Air-Filmfestival mitten im Wald: von Montag, 17.08., bis Samstag, 22.08. im Waldpark Schlosshofen. Wir präsentieren Ihnen Komödien, Science-Fiction und Abenteuerfilme für Erwachsene und Kinder ab 12 Jahren. Das Filmprogramm erhalten Sie an allen Informationsstellen der Stadt Schlosshofen und im City-Kino. Eintritt: 12 €, erma. Bigt 7 € Schon lange lebt Kaninchen Hoppi mit seiner Familie und vielen Freunden auf der Sonnenwiese. Doch eines Tages kauft der reiche Herr Großkopf die Wiese und will aus ihr einen Golfplatz machen ... Müssen die Kaninchen sich nun eine neue Heimat suchen? So schnell lassen sie sich jedenfalls nicht verjagen. Hoppi schmiedet einen Plan, damit die Kaninchen ihr Zuhause behalten können. „Hoppl_ gibt bicht auf ist ein Animationsfilm mit liebenswerten tierischen Helden, vielen originellen Ideen und 1 haarchenhaften Abenteuern für Kinder ab 6 Jahren. Stadtkino, täglich um 15 Uhr Du bist gern Kreativ und möchtest professionelle Mal- und Zeichentechniken erlernen? Dann haben wir genau das richtige Angebot für dich: „Junge Künstler\" - unser regula .Biger Kurs für Nachwuchskünstler ab 10 Jahren. In einer kleinen Gruppe konnt ihr gemeinsam zeichnen und malen. Dozentin Rebecca Kling ist freischaffende Künstlerin und leitet Kreativkurse für Kinder und Jugendliche. Kurszeiten: jeden Dienstag von 14 bis 16 Uhr Kunstatelier Rebecca Kling 53, 50767 Kolo Anmeldung und Infos: rebecca@kunstatelier-kling.net • Mit einem scharfen Blick fürs Detail gestaltete der deutsch-baltische Maler Jurgen Freiherr v. Wolffshausen seine Landschafts- und Tierbilder. Seine Liebe zur Natur, seine außergewöhnliche Beobachtungsgabe und seine präzise Maltechnik verleihen seinen Werken einen ganz besonderen Reiz. Sein Entdeckerdrang führte ihn u. a. nach Äthiopien. Die Ausstellung „Natur im Porträt“ präsentiert die Werke des Malers und seine Biogi.,aphie und gibt außerdem naturkundliche Informationen) Museum Luenburg, 19. Februar bis 10. Juni Eintritt 3 € Spiel, Spaß, Nervenkitzel Für alle Kinder und Jugendlichen, die am Ende der Ferien noch etwas erleben wollen. Sommerfest im Wildpark • Live-Musik Bogenschießen Axtwerfen Baumklettern bis zu Seilrutsche für Kinder Riesenschaukel Wettgasan Krauterbrot backen Basteln für Kinder ...und noch vieles mehr! Wildpark Rittersbach 12. und 13. September, von 10 bis 17 Uhr Noch nicht lange ist es her, dass Wildkatzen in Europa weitverbreitet waren. Heute sind sie fast überall verschwunden. Doch es gibt sie noch, auch wenn man sie nur selten zu Gesicht bekommt. Die fiktordokument Die Wildkatze in unseren Wäldern geht der Frage nach, ob das Tier bei uns überhaupt wieder heimisch werden kann. Hat es überhaupt eine Chance in unserer dicht besiedelten Landschaft? Und leben in unseren Wäldern noch echte Wildkatzen oder vielleicht nur verwilderte Hauskatzen? Denn äußerlich unterscheidet sich die Europäische Wildkatze kaum von einer getigerten Hauskatze. Der Film berichtet außerdem über ein Projekt zur Rettung der Wildkatze. Am 10.5. zeigen wir die Dokumentation in unserer Reihe „Filmabende im Rathaus“ um 19 Uhr. In der Dauerausstellung „Wege in die Natur“ erfahren Sie alles über den Nationalpark Bayerischer Wald, eine der größten zusammenhängenden Waldflächen Europas. Warum ist der Wald wichtig für uns? Und wer oder was lebt dort eigentlich? Über all das und noch viel mehr bekommen die Besucher beim Rundgang Informationen. In unserem Kino präsentieren wir außerdem ein abwechslungsreiches Filmprogramm. Ort: Besucherzentrum Nationalpark Bayerischer Wald Öffnungszeiten: täglich von 9 bis 17 Uhr Heiße Rhythmen und kühle Drinks Am Samstag, dem 3. August, erwartet Sie im Waldschwimmbad Hainichen bei Rock am Pool ein Feuerwerk aus Musik und Unterhaltung. Einlass zum Konzert ist ab 18:30 Uhr. Die Bands „Lion Poem“ und „Cosmos 1“ heizen den Besuchern ordentlich ein. Das Konzert endet um 0:30 Uhr Bis 23 Uhr können die Besucher baden oder Beach-Volleyball spielen. Das Jugendzentrum Hainichen hat ein Programm für Jugendliche mit Lagerfeuer und Spielen vorbereitet. Für Essen und Getränke zu moderaten Preisen ist gesorgt Die Eintrittspreise: Erwachsene 8 € Kinder und Jugendliche von 7 bis 14 Jahren 6 €. Vom Kreis zum Schaf, vom Strich zum Krokodil: Mit Bjorn Henkels Buch „Kinder zeichnen Tiere“ lernen die Kleinen, Schritt für Schritt ihre Lieblingstiere zu zeichnen. Aus einfachen Grundelementen entstehen lustige Tiereschaf, Katze und Wellensittich, Igel, Biber, Eichhörnchen und Waschbär. Erfolg und Spaß sind garantiert. Bjorn Henkel malt und zeichnet, seit er einen Stift halten kann. Nach seinem Studium der Kunstgeschichte lebt er heute als selbständiger Autor und Illustrator in Bochum. Das Buch ist geeignet für Kinder zwischen 4 und 6 J ahren.",
    "questions": [
      {
        "num": 11,
        "answer": "c",
        "stem": "Ein Bekannter interessiert sich für Tierdokumentationen und würde gerne wissen, wie solche Filme entstehen."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Eine Bekannte würde gerne gemeinsam mit einer Gruppe im Wald wandern gehen"
      },
      {
        "num": 13,
        "answer": "g",
        "stem": "Ihr Onkel möchte sich eine Ausstellung mit Gemälden ansehen"
      },
      {
        "num": 14,
        "answer": "e",
        "stem": "Ihr siebenjähriger Neffe liebt Phantasievolle Geschichten. Sie wollen nachmittags etwas mit ihm unternehmen."
      },
      {
        "num": 15,
        "answer": "a",
        "stem": "Ihr Sohn wird nächste Woche zehn Jahre alt. Sie möchten ihn mit einer besonderen Feier überraschen"
      },
      {
        "num": 16,
        "answer": "i",
        "stem": "Ihre 16 jährige Nichte interessiert sich für heimische Tierwelt und würde sich gerne einen Film ansehen."
      },
      {
        "num": 17,
        "answer": "f",
        "stem": "Ihre zehnjährige Tochter zeichnet viel und möchte ihre Fähigkeiten weiter verbessern."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Sie möchten einen Vortrag über bedrohte Tiere und Naturschutz besuchen."
      },
      {
        "num": 19,
        "answer": "b",
        "stem": "Sie suchen ein Geschenk für einen Freund, der sich für Kunst interessiert."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Sie würden gerne abends etwas mit Freunden draußen unternehmen und dabei sportlich aktiv sein"
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Auf den Spuren der Wildkatze Im Wildkatzendorf Hütscheroda, am National -Park Hainich gelegen, erfahren Sie alles über die scheuen Tiere hautnah beobachten können Sie sie in der Schauanlage \"Wildkatzenlichtung\" Hier wird auf Informationstafeln auch das „Rettungsnetz für die Wildkatze\" vorgestellt eines der größten Naturschutzprojekte Europas. Täglich finden Schaufütterungen statt, für die man sich telefonisch anmelden kann, für die Kleinen, haben wir ein spannendes Angebot: Das Wildkatzendorf bietet Kindergeburtstage mit einem bunten Programm an und bietet spezielle Kinderführungen an. Öffnungszeiten: täglich von 10 bis 18 Uhr"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Ausstellung im Park Schon zum dritten Mal stellen am Pfingst-Wochenende Künstler aus der Region im Kurpark Bad Homburg ihre Exponate aus. Gezeigt werden Zeichnungen, Keramiken, Schmuck, Textilarbeiten sowie zahlreiche Holzskulpturen. Sie können mit den Künstlern ins Gespräch kommen und ihnen beim Arbeiten zusehen. Vor Ort über die Schulter blicken! Einen schön gestalteten Bildband mit Werken der ausstellenden Künstler erhalten Sie in der Buchhandlung am Park und der Touristeninformation für 30 €. Öffnungszeiten: 31. Mai und 1. Juni von 11 bis 19 Uhr Der Eintritt ist frei!"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Am 1. August zeigen wir den 90-minütigen Film „Der Natur auf der Spur“. Dieser begleitet fünf der besten und erfolgreichsten Tierfilmer der Welt auf ihren Reisen rund um den Globus. Sie alle versuchen, vor beeindruckenden Naturkulissen außergewöhnliche Tieraufnahmen einzufangen. Die Leidenschaft für ihre Filme lässt die Filmemacher große Anstrengungen und Gefahren in Kauf nehmen. In dem Film erfahren Sie nicht nur, wie Tierfilmer arbeiten, sondern auch, welche technischen Ausstattung sie einsetzen und wie die Dreharbeiten vorbereitet werden. Filmabend der VHS Buchholz, 1.8., Beginn: 19 Uhr Eintritt: 5 €"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Entspannte Sommernächte Genießen Sie sechs Tage Filmvergüngen unter dem Sternenhimmel, in bequemen Liegestühlen vor einer nachtblauen Naturkulisse. Besuchen Sie unsere Open-Air-Filmfestival mitten im Wald: von Montag, 17.08., bis Samstag, 22.08. im Waldpark Schlosshofen. Wir präsentieren Ihnen Komödien, Science-Fiction und Abenteuerfilme für Erwachsene und Kinder ab 12 Jahren. Das Filmprogramm erhalten Sie an allen Informationsstellen der Stadt Schlosshofen und im City-Kino. Eintritt: 12 €, erma. Bigt 7 €"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Schon lange lebt Kaninchen Hoppi mit seiner Familie und vielen Freunden auf der Sonnenwiese. Doch eines Tages kauft der reiche Herr Großkopf die Wiese und will aus ihr einen Golfplatz machen ... Müssen die Kaninchen sich nun eine neue Heimat suchen? So schnell lassen sie sich jedenfalls nicht verjagen. Hoppi schmiedet einen Plan, damit die Kaninchen ihr Zuhause behalten können. „Hoppl_ gibt bicht auf ist ein Animationsfilm mit liebenswerten tierischen Helden, vielen originellen Ideen und 1 haarchenhaften Abenteuern für Kinder ab 6 Jahren. Stadtkino, täglich um 15 Uhr"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Du bist gern Kreativ und möchtest professionelle Mal- und Zeichentechniken erlernen? Dann haben wir genau das richtige Angebot für dich: „Junge Künstler\" - unser regula .Biger Kurs für Nachwuchskünstler ab 10 Jahren. In einer kleinen Gruppe konnt ihr gemeinsam zeichnen und malen. Dozentin Rebecca Kling ist freischaffende Künstlerin und leitet Kreativkurse für Kinder und Jugendliche. Kurszeiten: jeden Dienstag von 14 bis 16 Uhr Kunstatelier Rebecca Kling Pestalozzistr. 53, 50767 Kolo Anmeldung und Infos: rebecca@kunstatelier-kling.net"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "• Mit einem scharfen Blick fürs Detail gestaltete der deutsch-baltische Maler Jurgen Freiherr v. Wolffshausen seine Landschafts- und Tierbilder. Seine Liebe zur Natur, seine außergewöhnliche Beobachtungsgabe und seine präzise Maltechnik verleihen seinen Werken einen ganz besonderen Reiz. Sein Entdeckerdrang führte ihn u. a. nach Äthiopien. Die Ausstellung „Natur im Porträt“ präsentiert die Werke des Malers und seine Biogi.,aphie und gibt außerdem naturkundliche"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Spiel, Spaß, Nervenkitzel Für alle Kinder und Jugendlichen, die am Ende der Ferien noch etwas erleben wollen. Sommerfest im Wildpark • Live-Musik Bogenschießen Axtwerfen Baumklettern bis zu 20 Meter Höhe Seilrutsche für Kinder Riesenschaukel Wettgasan Krauterbrot backen Basteln für Kinder ...und noch vieles mehr! Wildpark Rittersbach 12. und 13. September, von 10 bis 17 Uhr"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Noch nicht lange ist es her, dass Wildkatzen in Europa weitverbreitet waren. Heute sind sie fast überall verschwunden. Doch es gibt sie noch, auch wenn man sie nur selten zu Gesicht bekommt. Die fiktordokument Die Wildkatze in unseren Wäldern geht der Frage nach, ob das Tier bei uns überhaupt wieder heimisch werden kann. Hat es überhaupt eine Chance in unserer dicht besiedelten Landschaft? Und leben in unseren Wäldern noch echte Wildkatzen oder vielleicht nur verwilderte Hauskatzen? Denn äußerlich unterscheidet sich die Europäische Wildkatze kaum von einer getigerten Hauskatze. Der Film berichtet außerdem über ein Projekt zur Rettung der Wildkatze. Am 10.5. zeigen wir die Dokumentation in unserer Reihe „Filmabende im Rathaus“ um 19 Uhr."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "In der Dauerausstellung „Wege in die Natur“ erfahren Sie alles über den Nationalpark Bayerischer Wald, eine der größten zusammenhängenden Waldflächen Europas. Warum ist der Wald wichtig für uns? Und wer oder was lebt dort eigentlich? Über all das und noch viel mehr bekommen die Besucher beim Rundgang Informationen. In unserem Kino präsentieren wir außerdem ein abwechslungsreiches Filmprogramm. Ort: Besucherzentrum Nationalpark Bayerischer Wald Öffnungszeiten: täglich von 9 bis 17 Uhr Der Eintritt ist frei"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Heiße Rhythmen und kühle Drinks Am Samstag, dem 3. August, erwartet Sie im Waldschwimmbad Hainichen bei Rock am Pool ein Feuerwerk aus Musik und Unterhaltung. Einlass zum Konzert ist ab 18:30 Uhr. Die Bands „Lion Poem“ und „Cosmos 1“ heizen den Besuchern ordentlich ein. Das Konzert endet um 0:30 Uhr Bis 23 Uhr können die Besucher baden oder Beach-Volleyball spielen. Das Jugendzentrum Hainichen hat ein Programm für Jugendliche mit Lagerfeuer und Spielen vorbereitet. Für Essen und Getränke zu moderaten Preisen ist gesorgt Die Eintrittspreise: Erwachsene 8 € Kinder und Jugendliche von 7 bis 14 Jahren 6 €."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Zeichenschule für Kinder Vom Kreis zum Schaf, vom Strich zum Krokodil: Mit Bjorn Henkels Buch „Kinder zeichnen Tiere“ lernen die Kleinen, Schritt für Schritt ihre Lieblingstiere zu zeichnen. Aus einfachen Grundelementen entstehen lustige Tiereschaf, Katze und Wellensittich, Igel, Biber, Eichhörnchen und Waschbär. Erfolg und Spaß sind garantiert. Bjorn Henkel malt und zeichnet, seit er einen Stift halten kann. Nach seinem Studium der Kunstgeschichte lebt er heute als selbständiger Autor und Illustrator in Bochum. Das Buch ist geeignet für Kinder zwischen 4 und 6 J ahren."
        ]
      }
    ]
  },
  {
    "id": "25",
    "title": "Fernsehdokumentationen und Krimis",
    "sourcePage": 302,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11. Sie möchten sich einen Dokumentarfilm über die Einwanderung nach Australien und über den damit verbundenen Prozess ansehen. 12. Ein junges Mädchen möchte später als Au-pair oder Austauschschülerin ins Ausland gehen und deshalb interessiert es sich für das Thema. 13. Ein Mann interessiert sich für die Aufdeckung von Verbrechen, die früher nicht gelöst werden 14. Sie schwärmen für Krimis, die auf Grund tatsächlicher Fälle rekonstruiert wurden. 15. Sie haben dafür großes Interesse, wie mithilfe von Computertechnik das Wetter an verschiedenen Orten der Welt vorhergesagt werden kann. 16. Ein Mann interessiert sich dafür, wie Wetterphänomene entstehen. 17. Sie suchen ein Gartenmagazin, aus dem Sie alles über den Anbau der Gemüse- und Obstsorten 18. Sie möchten sich eine Quizsendung ansehen, an der Familienmitglieder teilnehmen. 19. Eine Bekannte von Ihnen sucht eine Reisesendung, ähnlich der „Traumschiff“, in dem es während eines Urlaubs um eine Liebesgeschichte geht. 19/1 Ein Italiener zum Verlieben 20. Ein Mann interessiert sich für das Bauernleben und sucht deshalb eine passende Sendung. Jodi schwebt im siebten Himmel: Sie hat den char manten und gut aussehenden Italiener Alberto kennen gelernt und ihm auch gleich einen Job auf Drover’s Run verschafft. Meg ist die stürmische Bezie hung zwischen ihrer Tochter jedoch ein Dorn im Auge, als sie schließlich herausfindet, dass Alberto sich illegal in Australien aufhält. Sie zitiert ihn vor den Verdacht bestätigt: Alberto hat sich nur an ihre Tochter herangemacht, um an eine Aufenthaltsergenehmigung zu kommen. Um sicher zu gehen, soll Becky den ah nungslosen Alberto nun testen, doch der erweist sich als äußerst standfest. Es scheint, als würde er Jodi tatsächlich von ganzem Herzen lieben. Zu dumm, dass Jodis ihrer Freund nach dem Test aus Beckys Zimmer kommen sieht und ihn wutentbrannt bei der Einwan derungsbehörde anzeigt … auf und davon – Mein Auslands tagebuch Ein Jahr im Ausland – für junge Menschen ein großer Traum. Viele deutsche Jugendliche leben deshalb als Au-pair oder Austauschschüler in die Ferne. In der Dokumentation „auf und davon – Mein Auslandstagebuch“ begleitet VOX junge Menschen, die zum ersten Mal in ihrem Leben ihre Familien, ihre Freunde und ihre Heimat verlassen … Thema : Die Chemie des Todes – Mördersuche im Labor , Teil 3 Mord verjährt nie . Auch wenn der Täter nur wenige , unsichtbare Spuren hinterlässt und die Ermittlungsarbeit oft langwierig ist : Frontal ist die Mördersuche im Labor erfolgreich . Verbrechen , die noch vor wenigen Jahren zu den Akten gelegt werden mussten , werden heute von Forensikern mithilfe modernster Kriminaltechnik aufgeklärt . Oft genügen mikroskopisch kleine Partikel , um das brutale Geschehen zu rekonstruieren und den Täter zu überführen . Im Rahmen der dreiteiligen Reihe „ Die Chemie des Todes – Mördersuche im Labor “ werden wahre Fälle rekonstruiert . Ermittler , Rechtsmediziner und Profiler schildern , welche wissenschaftlichen und technischen Methoden sie anwenden , um auch die mysteriösesten Mordfälle zu lösen . Thema : Wildes Wetter , Teil 2 : Kälte und Hitze Das Wetter ist eines der wenigen Naturphänomene , das uns nach wie vor Rätsel aufgibt . Selbst mit modernster Wissenschaft lässt es sich nur bedingt voraussagen , selten beeinflussen und nie kontrollieren . Diese zweiteilige Dokumentation führt die Zuschauer zu den entlegensten Orten der Erde und zeigt , wie das Wetter funktioniert – aufregende Computeranimationen und seltenes Archivmaterial bieten einen neuen Blick auf die welt Jamie At Home ( RTL 2 ) Samstags Jamie Oliver ist zurück an Heim und Herd ! In den drei zehn neuen Folgen stellt er wie immer großartige Rezepte vor , bereitet die besten Zutaten für ein saisonales Menü zu , die er in seinem eigenen Garten angebaut hat – von perfekten Kartoffeln zu saftigen Erdbeeren , von leckeren Tomaten bis zum frisch geernteten Pizza belag . „ Jamie At Home “ ein unkomplizierter Ratgeber , wie man das Beste von Mutter Natur persönlich serviert bekommt : wie man dafür in den Bio - Supermarkt gehen muss . Mithilfe von Gärtner Brian hat er den Garten seines Hauses in Essex umgebaut und seine Leidenschaft , sein eigenes Essen anzubauen , entdeckt – und zeigt , wie einfach es ist , sich mit selber angebauten Produkten zu ernähren . In jeder Sendung wird eine andere Gemüsesorte vorgestellt . Selbst wenn man nur ein Fensterbrett , einen kleinen Balkon oder einen Hinterhof zur Verfügung hat : Jamie zeigt die simplen Tricks , wie man fantastisches Gemüse oder Früchte auch auf kleinstem Raum ziehen kann , und wie man sie in einfache , köstliche Gerichte verwandelt . Voll gepackt mit Dutzenden von neuen Rezepten , die Schritt für Schritt erklärt werden , wird es bei „ Jamie At Home “ jeden Hobbykoch im grünen Daumen jucken … Die Wahrheit und nichts als die Wahrheit Ab 28. Januar montags um 22:15 Uhr bei RTL II . Endlich eine Show , in der die Kandidaten nicht mit Allgemeinwissen brillieren müssen . Bei uns brauchen sie auch kein besonderes Talent oder Glück . Sie müssen die Wahrheit sagen . Und dazu gehört Mut – denn nichts kann bitterer sein als die Wahrheit und nichts als die Wahrheit ! Das unmoralische Angebot : Für 21 wahrheitsgemäß beantwortete Fragen gibt es 25.000 Euro ! Den Kandidaten werden zu Bergewohliche , intime und pikante Fragen gestellt . Natürlich alles in Anwesenheit ihrer Partner und Familien ! Und der Spieler muss immer wie der aufs Neue entscheiden : Wie viel ist der Familienfriede denn wert … ? Die wahren Antworten lassen die Kandidaten schmunzeln , vor Scham erröten oder in Erklärungsnöte stürzen . Jede unwahre Antwort wird von einem Polygraphen ( Lügendetektor ) schlüssig aufgedeckt und führt zum so fortigen Ende des Spiels . • RT1 The Bourne Identity Sonntag , 13. Januar Spielfilm , 130 Min . USA 2002 Irgendwo auf dem Mittelmeer treibt ein Fischerboot im Sturm . Nicht weit davon entfernt schwimmt ein Mann der , für tot gehalten wurde . Einmal geboren , entpuppt sich der vermeintlich Ertrunkene jedoch als lebendig , schwer verletzt . In annähernd kurzer Zeit kommt er zwar wieder zu Kräften , allein seine Erinnerung an die Nacht , in der er ins Wasser fiel und in der ihm zweimal in den Rücken geschossen wurde , kehrt nicht zurück . Der einzige Hinweis auf die wahre Identität ein in den Oberschenkel implantierter Code für ein Schweizer Nummernkonto ist , begibt sich der Unbekannte auf direktem Weg nach Zürich . Dort stellt er fest , dass sein Name Jason Bourne ist , er in Paris wohnt und jede Menge Geld auf seinem Konto hat . Im weiteren Verlauf des dramatischen dass Jason auch noch weitere eigene Identitäten vorfindet , je weils komplettiert mit Reisepass , Führerschein und anderen Do kumenten . Alsbald dämmert ihm , dass er zwar einerseits als Agent im Staats dienst , andererseits aber auch als Auftragskiller tätig .... ML Mona Lisa ( ZDF ) - Traumurlaub ganz anders Ärzteschiff für Menschen in Die Zahnärztin Marion Bösch aus München hat sich ihren Traum erfüllt . Sie sparte ihren Urlaub für vier Wochen Aufenthalt auf der „ Africa Mercy “ . Allerdings ist es kein Kreuzfahrtschiff und ein richtiger Urlaub ist es auch nicht , denn bei dem Schiff handelt es sich um die größte schwimmende Klinik der Etwa 40.000 Löwen leben in Af rika , rund die Hälfte von ihnen in Tansania . Trotz dieser großen Zahl kommt es in der Regel nur vereinzelt zu Angriffen auf Men schen . In den ersten Jahren des 21. Jahr hunderts ist die Zahl der Angriffsopfer jedoch sprunghaft angestiegen . Ein Team um den amerikanischen Löwenforscher Craig Packer sucht nach Ursa chen . Für Packer scheint es sich nicht um einzelne Löwen zu handeln , sondern um eine ganze Population . Um die Menschen besser schützen zu können und mehr über die Lebensweise der Löwen zu erfahren , versuchen Craig Packer und sein Team , ein zehne Raubkatzen mit GPS - Gerä ten auszustatten . Land . Tschüss Deutschland ! Neuer Start im fremden land Manche gehen aus Sehnsucht , andere aus Frust . Und von Jahr zu Jahr werden es mehr . Viele , vor allem gut ausgebildete Deutsche , ziehen auf der Suche nach lukrativen Jobs und besseren Le bensbedingungen in die Ferne . Dirk ( 40 ) und Birthe J. ( 38 ) aus Ockholm in Nordfriesland haben auf den ersten Blick alles , was sich nur wünschen kann . Ein reetge decktes altes Bauernhaus , ein großes Grundstück , zwei nette Kinder , viele Tiere , kurz : ein schönes Stück Heimat . Dirk ist Schreiner , er restauriert Antiquitäten , doch in den letzten Jahren liefen die Geschäfte eher schlecht . Dann fand Dirk im In ternet seinen Traumjob . Ein deutscher Unternehmer mehr , der alte Häuser in Irland restauriert , suchte händeringend einen Tischler : Nettogehalt 4500 Euro pro Monat ! Zunächst ging nur Dirk , doch die Familie wird folgen . Die Reportage begleitet ihn beim Start auf der grünen Insel und ist dabei , wenn die Familie endlich gemeinsam ihr erstes irisches Haus bezieht . Die ZDF Reportage zeigt mutige Menschen , die ihr Schicksal in die Hand nehmen und daran glauben , dass es ihn gibt : den Neustart in Episode : Folge 3, Sonntag , 13. Januar Auf dem Hof von Biobauer Olaf in Schleswig Holstein sorgt Katrin ( 32 ) für jede Menge Ac tion und gute Laune . Der Wirbelwind krempelt die Ärmel hoch und sorgt sowohl in den Wohn räumen als auch im Schweinestall für Ordnung . Olaf ist von Katrins Energie begeistert . Stellt sich nur die Frage , ob Olafs Eltern Rolf und Helga mit der neuen Frau an Olafs Seite auch zurechtkom men ? Tanja trifft auf dem Hof von Schweinebau er Stephan in Niedersachsen ebenfalls auf eine große Familie . Stephan lebt mit seinen Eltern Inge und Hans - Jürgen sowie den Großeltern und 630 Schweinen auf dem großen Bauernhof . Finden Stephans Eltern die quirlige 22 - House , M.D.Dr. Wilson kann House davon überzeugen , sich des Falles der neunjährigen Andie anzunehmen , die an einer tödlichen Krebserkrankung leidet und nicht mehr lan ge zu leben hat . House wehrt sich zunächst mit Händen und Füßen gegen eine emotionale Einbindung in die tragische Geschichte , kann aber dem scheinbar unerschütterlichen Mut der kleinen Patientin schließlich doch nichts mehr entgegensetzen . Die Situation spitzt sich drama tisch zu , als Andie plötzlich extrem zu halluzinieren beginnt - ein Symptom , dass in keiner Weise mit ihrem Krankheitsbild in Übereinstimmung gebracht werden kann . House vermutet , dass sich im Gehirn des Kindes ein Gerinnsel gebildet hat . Um das Gerinnsel finden zu können und damit Andie noch das Leben zu erhalten , müssen House und sein Team eine äußerst gefährliche Operation wagen .",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Sie möchten sich einen Dokumentarfilm über die Einwanderung nach Australien und über den damit verbundenen Prozess ansehen."
      },
      {
        "num": 12,
        "answer": "b",
        "stem": "Ein junges Mädchen möchte später als Au-pair oder Austauschschülerin ins Ausland gehen und deshalb interessiert es sich für das Thema."
      },
      {
        "num": 13,
        "answer": "c",
        "stem": "Ein Mann interessiert sich für die Aufdeckung von Verbrechen, die früher nicht gelöst werden konnten."
      },
      {
        "num": 14,
        "answer": "x",
        "stem": "Sie schwärmen für Krimis, die auf Grund tatsächlicher Fälle rekonstruiert wurden."
      },
      {
        "num": 15,
        "answer": "d",
        "stem": "Sie haben dafür großes Interesse, wie mithilfe von Computertechnik das Wetter an verschiedenen Orten der Welt vorhergesagt werden kann."
      },
      {
        "num": 16,
        "answer": "x",
        "stem": "Ein Mann interessiert sich dafür, wie Wetterphänomene entstehen."
      },
      {
        "num": 17,
        "answer": "e",
        "stem": "Sie suchen ein Gartenmagazin, aus dem Sie alles über den Anbau der Gemüse- und Obstsorten erfahren können."
      },
      {
        "num": 18,
        "answer": "f",
        "stem": "Sie möchten sich eine Quizsendung ansehen, an der Familienmitglieder teilnehmen."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Eine Bekannte von Ihnen sucht eine Reisesendung, ähnlich der „Traumschiff“, in dem es während eines Urlaubs um eine Liebesgeschichte geht."
      },
      {
        "num": 20,
        "answer": "k",
        "stem": "Ein Mann interessiert sich für das Bauernleben und sucht deshalb eine passende Sendung."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "McLeods Töchter 19/1 Ein Italiener zum Verlieben Jodi schwebt im siebten Himmel: Sie hat den char manten und gut aussehenden Italiener Alberto kennen gelernt und ihm auch gleich einen Job auf Drover’s Run verschafft. Meg ist die stürmische Bezie hung zwischen ihrer Tochter jedoch ein Dorn im Auge, als sie schließlich herausfindet, dass Alberto sich illegal in Australien aufhält. Sie zitiert ihn vor den Verdacht bestätigt: Alberto hat sich nur an ihre Tochter herangemacht, um an eine Aufenthaltsergenehmigung zu kommen. Um sicher zu gehen, soll Becky den ah nungslosen Alberto nun testen, doch der erweist sich als äußerst standfest. Es scheint, als würde er Jodi tatsächlich von ganzem Herzen lieben. Zu dumm, dass Jodis ihrer Freund nach dem Test aus Beckys Zimmer kommen sieht und ihn wutentbrannt bei der Einwan derungsbehörde anzeigt …"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "14.01. – 16:00 Uhr (VOX) auf und davon – Mein Auslands tagebuch Folge 88 Ein Jahr im Ausland – für junge Menschen ein großer Traum. Viele deutsche Jugendliche leben deshalb als Au-pair oder Austauschschüler in die Ferne. In der Dokumentation „auf und davon – Mein Auslandstagebuch“ begleitet VOX junge Menschen, die zum ersten Mal in ihrem Leben ihre Familien, ihre Freunde und ihre Heimat verlassen …"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "8.01 . – 22:45 Uhr SPIEGEL TV Thema Thema Die Chemie des Todes – Mördersuche im Labor , Teil 3 Mord verjährt nie . Auch wenn der Täter nur wenige , unsichtbare Spuren hinterlässt und die Ermittlungsarbeit oft langwierig ist Frontal ist die Mördersuche im Labor erfolgreich . Verbrechen , die noch vor wenigen Jahren zu den Akten gelegt werden mussten , werden heute von Forensikern mithilfe modernster Kriminaltechnik aufgeklärt . Oft genügen mikroskopisch kleine Partikel , um das brutale Geschehen zu rekonstruieren und den Täter zu überführen . Im Rahmen der dreiteiligen Reihe „ Die Chemie des Todes – Mördersuche im Labor “ werden wahre Fälle rekonstruiert . Ermittler , Rechtsmediziner und Profiler schildern , welche wissenschaftlichen und technischen Methoden sie anwenden , um auch die mysteriösesten Mordfälle zu lösen ."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "16.01.2008 – 22:50 Uhr BBC Exklusiv Thema Wildes Wetter , Teil 2 Kälte und Hitze Das Wetter ist eines der wenigen Naturphänomene , das uns nach wie vor Rätsel aufgibt . Selbst mit modernster Wissenschaft lässt es sich nur bedingt voraussagen , selten beeinflussen und nie kontrollieren . Diese zweiteilige Dokumentation führt die Zuschauer zu den entlegensten Orten der Erde und zeigt , wie das Wetter funktioniert – aufregende Computeranimationen und seltenes Archivmaterial bieten einen neuen Blick auf die welt"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Jamie At Home ( RTL 2 ) Samstags Jamie Oliver ist zurück an Heim und Herd ! In den drei zehn neuen Folgen stellt er wie immer großartige Rezepte vor , bereitet die besten Zutaten für ein saisonales Menü zu , die er in seinem eigenen Garten angebaut hat – von perfekten Kartoffeln zu saftigen Erdbeeren , von leckeren Tomaten bis zum frisch geernteten Pizza belag . „ Jamie At Home “ ein unkomplizierter Ratgeber , wie man das Beste von Mutter Natur persönlich serviert bekommt wie man dafür in den Bio - Supermarkt gehen muss . Mithilfe von Gärtner Brian hat er den Garten seines Hauses in Essex umgebaut und seine Leidenschaft , sein eigenes Essen anzubauen , entdeckt – und zeigt , wie einfach es ist , sich mit selber angebauten Produkten zu ernähren . In jeder Sendung wird eine andere Gemüsesorte vorgestellt . Selbst wenn man nur ein Fensterbrett , einen kleinen Balkon oder einen Hinterhof zur Verfügung hat Jamie zeigt die simplen Tricks , wie man fantastisches Gemüse oder Früchte auch auf kleinstem Raum ziehen kann , und wie man sie in einfache , köstliche Gerichte verwandelt . Voll gepackt mit Dutzenden von neuen Rezepten , die Schritt für Schritt erklärt werden , wird es bei „ Jamie At Home “ jeden Hobbykoch im grünen Daumen jucken …"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Die Wahrheit und nichts als die Wahrheit Ab 28. Januar montags um 22:15 Uhr bei RTL II . Endlich eine Show , in der die Kandidaten nicht mit Allgemeinwissen brillieren müssen . Bei uns brauchen sie auch kein besonderes Talent oder Glück . Sie müssen die Wahrheit sagen . Und dazu gehört Mut – denn nichts kann bitterer sein als die Wahrheit und nichts als die Wahrheit ! Das unmoralische Angebot Für 21 wahrheitsgemäß beantwortete Fragen gibt es 25.000 Euro ! Den Kandidaten werden zu Bergewohliche , intime und pikante Fragen gestellt . Natürlich alles in Anwesenheit ihrer Partner und Familien ! Und der Spieler muss immer wie der aufs Neue entscheiden Wie viel ist der Familienfriede denn wert … ? Die wahren Antworten lassen die Kandidaten schmunzeln , vor Scham erröten oder in Erklärungsnöte stürzen . Jede unwahre Antwort wird von einem Polygraphen ( Lügendetektor ) schlüssig aufgedeckt und führt zum so fortigen Ende des Spiels ."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "• RT1 The Bourne Identity Sonntag , 13. Januar Spielfilm , 130 Min . USA 2002 Irgendwo auf dem Mittelmeer treibt ein Fischerboot im Sturm . Nicht weit davon entfernt schwimmt ein Mann der , für tot gehalten wurde . Einmal geboren , entpuppt sich der vermeintlich Ertrunkene jedoch als lebendig , schwer verletzt . In annähernd kurzer Zeit kommt er zwar wieder zu Kräften , allein seine Erinnerung an die Nacht , in der er ins Wasser fiel und in der ihm zweimal in den Rücken geschossen wurde , kehrt nicht zurück . Der einzige Hinweis auf die wahre Identität ein in den Oberschenkel implantierter Code für ein Schweizer Nummernkonto ist , begibt sich der Unbekannte auf direktem Weg nach Zürich . Dort stellt er fest , dass sein Name Jason"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "ML Mona Lisa ( ZDF ) - Traumurlaub ganz anders Ärzteschiff für Menschen in Not Die Zahnärztin Marion Bösch aus München hat sich ihren Traum erfüllt . Sie sparte ihren Urlaub für vier Wochen Aufenthalt auf der „ Africa Mercy “ . Allerdings ist es kein Kreuzfahrtschiff und ein richtiger Urlaub ist es auch nicht , denn bei dem Schiff handelt es sich um die größte schwimmende Klinik der Welt ."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Löwenalarm ! Jagd auf Menschenfresser Etwa 40.000 Löwen leben in Af rika , rund die Hälfte von ihnen in Tansania . Trotz dieser großen Zahl kommt es in der Regel nur vereinzelt zu Angriffen auf Men schen . In den ersten Jahren des 21. Jahr hunderts ist die Zahl der Angriffsopfer jedoch sprunghaft angestiegen . Ein Team um den amerikanischen Löwenforscher Craig Packer sucht nach Ursa chen . Für Packer scheint es sich nicht um einzelne Löwen zu handeln , sondern um eine ganze Population . Um die Menschen besser schützen zu können und mehr über die Lebensweise der Löwen zu erfahren , versuchen Craig Packer und sein Team , ein zehne Raubkatzen mit GPS - Gerä ten auszustatten ."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Land . Tschüss Deutschland ! Neuer Start im fremden land Manche gehen aus Sehnsucht , andere aus Frust . Und von Jahr zu Jahr werden es mehr . Viele , vor allem gut ausgebildete Deutsche , ziehen auf der Suche nach lukrativen Jobs und besseren Le bensbedingungen in die Ferne . Dirk ( 40 ) und Birthe J. ( 38 ) aus Ockholm in Nordfriesland haben auf den ersten Blick alles , was sich nur wünschen kann . Ein reetge decktes altes Bauernhaus , ein großes Grundstück , zwei nette Kinder , viele Tiere , kurz ein schönes Stück Heimat . Dirk ist Schreiner , er restauriert Antiquitäten , doch in den letzten Jahren liefen die Geschäfte eher schlecht . Dann fand Dirk im In ternet seinen Traumjob . Ein deutscher Unternehmer mehr , der alte Häuser in Irland restauriert , suchte händeringend einen Tischler Nettogehalt 4500 Euro pro Monat ! Zunächst ging nur Dirk , doch die Familie wird folgen . Die Reportage begleitet ihn beim Start auf der grünen Insel und ist dabei , wenn die Familie endlich gemeinsam ihr erstes irisches Haus bezieht . Die ZDF Reportage zeigt mutige Menschen , die ihr Schicksal in die Hand nehmen und daran glauben , dass es ihn gibt den Neustart in einem fremden Land ."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Bauer sucht Frau Episode Folge 3, Sonntag , 13. Januar Serie , 60 Min . Auf dem Hof von Biobauer Olaf in Schleswig Holstein sorgt Katrin ( 32 ) für jede Menge Ac tion und gute Laune . Der Wirbelwind krempelt die Ärmel hoch und sorgt sowohl in den Wohn räumen als auch im Schweinestall für Ordnung . Olaf ist von Katrins Energie begeistert . Stellt sich nur die Frage , ob Olafs Eltern Rolf und Helga mit der neuen Frau an Olafs Seite auch zurechtkom men ? Tanja trifft auf dem Hof von Schweinebau er Stephan in Niedersachsen ebenfalls auf eine große Familie . Stephan lebt mit seinen Eltern Inge und Hans - Jürgen sowie den Großeltern und 630 Schweinen auf dem großen Bauernhof . Finden Stephans Eltern die quirlige 22 - Jährige sympathisch ?"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "episode Autopsie Mittwoch ‚09. Januar Serie, 50 Min . USA 2005 House, M.D.Dr. Wilson kann House davon überzeugen ‚ sich des Falles der neunjährigen Andie anzunehmen, die an einer tödlichen Krebserkrankung leidet und nicht mehr lan ge zu leben hat . House wehrt sich zunächst mit Händen und Füßen gegen eine emotionale Einbindung in die tragische Geschichte , kann aber dem scheinbar unerschütterlichen Mut der kleinen Patientin schließlich doch nichtsmehr entgegensetzen . Die Situation spitzt sich drama tisch zu ‚ als Andie plötzlich extrem zu halluzinieren beginnt - ein Symptom, dassin keiner Weise mit ihrem Krankheitsbild in Übereinstimmung gebracht werden kann . House vermutet , dass sich im Gehirn des Kindes ein Gerinnsel"
        ]
      }
    ]
  },
  {
    "id": "26",
    "title": "Kurse, Arbeitsorganisation und Beratung",
    "sourcePage": 305,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Eine Kollegen kann ihren Arbeitsbereich nicht gut strukturieren und hat deshalb Probleme, ihre Aufgaben rechtzeitig zu erledigen. 12 Ein Bekannter hat einen kranken Hund und sucht tierärztliche Hilfe. 13 Eine Bekannte möchte ihre Beziehung zur Mutter des Mannes verändern. 14 Ein Freund möchte etwas über Konfliktgespräche mit Frauen erfahren. 15 Eine Bekannte sucht einen Kurs, um in ihrer Freizeit aktiv etwas gegen ihren Stress tun zu 16 Eine Freundin schiebt Dinge, die ihr keinen Spaß machen, immer vor sich her. 17 Ein Bekannter möchte leichter Kontakt zu anderen Menschen finden. 18 Eine Freundin möchte den Führerschein machen. 19 Eine Freundin möchte Strategien erlernen, wie man wirkungsvoller argumentiert und dadurch leichter seine Ziele erreicht. übergreifen und diese belasten können. des Respekts voreinander zu finden. Samstag, 30.5., 10:00-20:00 Uhr 20 Ein Bekannter hat eine Hundepension. Er glaubt, dass er die ihm anvertrauten Tiere oft Schwiegermütter – Schwiegertöchter Problem oder Chance Der problemlose Umgang von Schwiegermüttern mit ihren Schwiegertöchtern ist nicht immer einfach. So entstehen zahlreiche Konflikte, die auf Beziehung zwischen Sohn und Schwiegertochter Mit Hilfe von anschaulichen Beispielen beschäftigen wir uns mit dem Spannungsfeld zwischen Schwiegermutter und Schwiegertochter und versuchen Wege des unkomplizierten Miteinanders und Mit Männern Gespräche führen Ein Seminar für Frauen Dass Männer von Mars und Frauen von Venus kommen, wissen wir schon. Doch wie redet Frau mit In diesem Seminar analysieren wir, inwiefern Männer anders denken als Frauen und wie wir diese Erkenntnisse ausnutzen können. Wir erarbeiten, wie wir z.B. Konfliktgespräche mit Männern optimal vorbereiten können und wie Frau sich gegen ihn im Gespräch behaupten kann. Samstag, 23.4., 9:00-17:00 Sonntag, 24.4., 9:00-17:00 Raum VII 78,- Euro Fühlen Sie sich im Gespräch unsicher? Möchten Sie lernen, wie Sie sich klarer und verständlicher Wie Sie Ihren Standpunkt angemessen vertreten? In diesem Seminar lernen Sie, Ihr eigenes Gesprächsverhalten zu erkennen und zu verbessern. Sie lernen, effektiver und zielgerichteter mit anderen Menschen zu reden und sich durchzusetzen. Mo-Fr, 9:00-16:00 Uhr Raum II 290,- Euro Wer flirten kann, kommt leicht in Kontakt mit anderen. Nicht nur für die Partnersuche, sondern auch für das freundliche Miteinander ist Flirten wichtig: Babys und kleine Kinder flirten ganz mühelos, doch Erwachsene haben vergessen, wie man Augen, Lächeln und passende Wörter benutzt, um das Miteinander angenehmer zu machen. In spielerischer Form haben Sie die Gelegenheit, Ihre verschwundenen Fähigkeiten zur Annäherung und Kontaktaufnahme wiederzuentdecken und anzuwenden. 5 Freitage ab 3.3., 18:00-21:00 Uhr Turmsaal 130,- Euro Über Stress und Zeitdruck klagt fast jeder. Doch das betrifft nicht nur den Arbeitsplatz, immer mehr Menschen spüren den Zeitdruck auch zu Hause. In diesem Seminar lernen wir, mit der Zeit “sparsam” umzugehen. Wir sprechen darüber, was uns wichtig ist, lernen Prioritäten zu setzen, Zeitdiebe zu erkennen und den Tagesablauf effektiv zu planen. Diese Schritte werden uns zu mehr Zufriedenheit und Ausgeglichenheit führen und am Arbeitsplatz wie im Alltag das Leben erleichtern. Samstag, 9:00-18:00 Uhr Raum IX 115,- Euro Tai Chi Chuan ist eine uralte chinesische Methode, um das seelische Gleichgewicht wiederzufinden. Die Kunst des Schattenboxens entwickelte sich zur Heilgymnastik. Langsam, weiche, fließende Bewegungen führen zu innerer Ruhe und Ausgeglichenheit. Stress wird abgebaut und sie werden wieder frei für Ruhe und Harmonie. Die Übungen sind für Jung und Alt geeignet. 15 Dienstage ab 7.3., 19:30-21:00 Uhr Akademie-Fitnessraum 63,- Euro • Keine Angst vorm Autofahren Für Teilnehmerinnen und Teilnehmer mit Führerschein, Klasse B • Haben Sie Ängste vor bestimmten Fahrsituationen, z.B. vor dem Einparken, Überholen oder • Wir wollen versuchen, Ihren Ängsten auf den Grund zu kommen und sie zu lösen. Es spielt keine Rolle, ob Sie Führerscheinneuling sind oder schon lange Auto fahren oder eine lange Fahrpause gemacht haben. • Fahrpraktischer Teil am Nachmittag. • Samstag, 30.5., 9:00–16:30 Uhr ADAC-Übungsplatz 80,- Euro Seit langer Zeit bemühen sich die Menschen, Hunden klarzumachen, was sie von ihnen erwarten. Der Hund folgt, nicht, was er tut. In diesem Seminar erlernen Sie die “Sprache der Hunde”. Anhand von Videoaufzeichnungen studieren Sie seine Körpersprache und seine Reaktionen. Wenn Hund und Mensch sich gegenseitig verstehen, wird Druck überflüssig. Freitag, 29.5., 17:30–21:30 Uhr Raum XII 26,- Euro Mitarbeiter- gespräche führen Seminar für Führungskraft Die Führung von Mitarbeitern bedeutet, mit den Mitarbeitern zu sprechen. Klare Worte sind der Schlüssel zu einer erfolgreichen Zusammenarbeit, egal, ob Sie Informationen weitergeben oder Konflikte zu lösen versuchen. Nur wenn Ihr Gesprächspartner weiß, was Sie meinen, wird er so reagieren, wie Sie es sich vorgestellt haben. Dazu gehören natürlich auch Feedback-Techniken, mit denen Sie überprüfen können, ob Sie richtig verstanden wurden. 2 Samstage ab 13.2., 12:30–20:30 Uhr Turmsaal 180,- Euro Hilfe mein Haustier ist krank! Was ist, wenn Ihr vierbeiniger Liebling krank wird? In diesem Seminar erlernen Sie, wie Sie Krankheiten beim Tier erkennen und wie Sie erste Hilfe leisten können. Sie bekommen Tipps zur Fütterung und Pflege des kleinen Patienten und lernen, wie Sie Ihren kranken Liebling am besten zum Tierarzt transportieren können. Praktische Übungen am Stofftier stehen auch auf dem Programm. Donnerstag, 17.6., 17:30–21:00 Uhr Raum III 12,- Euro Überwinde deinen inneren Schweinehund Gehören Sie auch zu denjenigen, die unangenehme Dinge lieber hinauszögern? Die bis kurz vor dem Abgabetermin mit ihrer Steuererklärung warten? Die immer Ausreden finden, wenn es darum geht, den Kleiderschrank aufzuräumen, einen wichtigen Anruf zu tätigen oder zum Arzt zu gehen? Probieren Sie in diesem Seminar Strategien aus, die Ihnen helfen, Unangenehmes sofort zu erledigen. Samstag, 12.5., 15:00–19:00 Uhr Sonntag, 13.5., 10:00–15:00 Uhr Raum VI 65,- Euro In diesem Kurs werden die Funktionen und die Handhabung der modernen kleinen Informationsgeräte vorgestellt und erklärt. Auf folgende Fragen wird eingegangen: – Was ist ein Vertrags- und was ein Kartenhandy? – Wie schalte ich das Gerät ein und aus? – Wie telefoniere ich – Wie versende und empfange ich eine SMS? – Wie kann ich ins Internet? – Wie benutzt man das integrierte Telefonbuch?3",
    "questions": [
      {
        "num": 11,
        "answer": "e",
        "stem": "Eine Kollegen kann ihren Arbeitsbereich nicht gut strukturieren und hat deshalb Probleme, ihr Aufgaben rechtzeitig zu erledigen."
      },
      {
        "num": 12,
        "answer": "j",
        "stem": "Ein Bekannter hat einen kranken Hund und sucht tierärztliche Hilfe."
      },
      {
        "num": 13,
        "answer": "a",
        "stem": "Eine Bekannte möchte ihre Beziehung zur Mutter des Mannes verändern."
      },
      {
        "num": 14,
        "answer": "b",
        "stem": "Ein Freund möchte etwas über Konfliktgespräche mit Frauen erfahren."
      },
      {
        "num": 15,
        "answer": "f",
        "stem": "Eine Bekannte sucht einen Kurs, um in ihrer Freizeit aktiv etwas gegen ihren Stress tun zu können."
      },
      {
        "num": 16,
        "answer": "k",
        "stem": "Eine Freundin schiebt Dinge, die ihr keinen Spaß machen, immer vor sich her."
      },
      {
        "num": 17,
        "answer": "d",
        "stem": "Ein Bekannter möchte leichter Kontakt zu anderen Menschen finden."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Eine Freundin möchte den Führerschein machen."
      },
      {
        "num": 19,
        "answer": "c",
        "stem": "Eine Freundin möchte Strategien erlernen, wie man wirkungsvoller argumentiert und dadurch leichter seine Ziele erreicht."
      },
      {
        "num": 20,
        "answer": "h",
        "stem": "Ein Bekannter hat eine Hundepension. Er glaubt, dass er die ihm anvertrauten Tiere oft missversteht."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Schwiegermütter – Schwiegertöchter Problem oder Chance Der problemlose Umgang von Schwiegermüttern mit ihren Schwiegertöchtern ist nicht immer einfach. So entstehen zahlreiche Konflikte, die auf Beziehung zwischen Sohn und Schwiegertochter übergreifen und diese belasten können. Mit Hilfe von anschaulichen Beispielen beschäftigen wir uns mit dem Spannungsfeld zwischen Schwiegermutter und Schwiegertochter und versuchen Wege des unkomplizierten Miteinanders und des Respekts voreinander zu finden. Samstag, 30.5., 10:00-20:00 Uhr Turmsaal 31,- Euro"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Mit Männern Gespräche führen Ein Seminar für Frauen Dass Männer von Mars und Frauen von Venus kommen, wissen wir schon. Doch wie redet Frau mit ihm? In diesem Seminar analysieren wir, inwiefern Männer anders denken als Frauen und wie wir diese Erkenntnisse ausnutzen können. Wir erarbeiten, wie wir z.B. Konfliktgespräche mit Männern optimal vorbereiten können und wie Frau sich gegen ihn im Gespräch behaupten kann. Samstag, 23.4., 9:00-17:00 Sonntag, 24.4., 9:00-17:00 Raum VII 78,- Euro"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Kommunikation Fühlen Sie sich im Gespräch unsicher? Möchten Sie lernen, wie Sie sich klarer und verständlicher ausdrücken können? Wie Sie Ihren Standpunkt angemessen vertreten? In diesem Seminar lernen Sie, Ihr eigenes Gesprächsverhalten zu erkennen und zu verbessern. Sie lernen, effektiver und zielgerichteter mit anderen Menschen zu reden und sich durchzusetzen. Mo-Fr, 9:00-16:00 Uhr Raum II 290,- Euro"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Flirten leicht gemacht Wer flirten kann, kommt leicht in Kontakt mit anderen. Nicht nur für die Partnersuche, sondern auch für das freundliche Miteinander ist Flirten wichtig: Babys und kleine Kinder flirten ganz mühelos, doch Erwachsene haben vergessen, wie man Augen, Lächeln und passende Wörter benutzt, um das Miteinander angenehmer zu machen. In spielerischer Form haben Sie die Gelegenheit, Ihre verschwundenen Fähigkeiten zur Annäherung und Kontaktaufnahme wiederzuentdecken und anzuwenden. 5 Freitage ab 3.3., 18:00-21:00 Uhr Turmsaal 130,- Euro"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Zeitmanagement Über Stress und Zeitdruck klagt fast jeder. Doch das betrifft nicht nur den Arbeitsplatz, immer mehr Menschen spüren den Zeitdruck auch zu Hause. In diesem Seminar lernen wir, mit der Zeit “sparsam” umzugehen. Wir sprechen darüber, was uns wichtig ist, lernen Prioritäten zu setzen, Zeitdiebe zu erkennen und den Tagesablauf effektiv zu planen. Diese Schritte werden uns zu mehr Zufriedenheit und Ausgeglichenheit führen und am Arbeitsplatz wie im Alltag das Leben erleichtern. Samstag, 9:00-18:00 Uhr Raum IX 115,- Euro"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Tai Chi Chuan Tai Chi Chuan ist eine uralte chinesische Methode, um das seelische Gleichgewicht wiederzufinden. Die Kunst des Schattenboxens entwickelte sich zur Heilgymnastik. Langsam, weiche, fließende Bewegungen führen zu innerer Ruhe und Ausgeglichenheit. Stress wird abgebaut und sie werden wieder frei für Ruhe und Harmonie. Die Übungen sind für Jung und Alt geeignet. 15 Dienstage ab 7.3., 19:30-21:00 Uhr Akademie-Fitnessraum 63,- Euro"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "• Keine Angst vorm Autofahren Für Teilnehmerinnen und Teilnehmer mit Führerschein, Klasse B • Haben Sie Ängste vor bestimmten Fahrsituationen, z.B. vor dem Einparken, Überholen oder Fahrstreifenwechsel? • Wir wollen versuchen, Ihren Ängsten auf den Grund zu kommen und sie zu lösen. Es spielt keine Rolle, ob Sie Führerscheinneuling sind oder schon lange Auto fahren oder eine lange Fahrpause gemacht haben."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Mit Hunden sprechen Seit langer Zeit bemühen sich die Menschen, Hunden klarzumachen, was sie von ihnen erwarten. Der Hund folgt, nicht, was er tut. In diesem Seminar erlernen Sie die “Sprache der Hunde”. Anhand von Videoaufzeichnungen studieren Sie seine Körpersprache und seine Reaktionen. Wenn Hund und Mensch sich gegenseitig verstehen, wird Druck überflüssig. Freitag, 29.5., 17:30–21:30 Uhr Raum XII 26,- Euro"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Mitarbeitergespräche führen Seminar für Führungskraft Die Führung von Mitarbeitern bedeutet, mit den Mitarbeitern zu sprechen. Klare Worte sind der Schlüssel zu einer erfolgreichen Zusammenarbeit, egal, ob Sie Informationen weitergeben oder Konflikte zu lösen versuchen. Nur wenn Ihr Gesprächspartner weiß, was Sie meinen, wird er so reagieren, wie Sie es sich vorgestellt haben. Dazu gehören natürlich auch Feedback-Techniken, mit denen Sie überprüfen können, ob Sie richtig verstanden wurden. 2 Samstage ab 13.2., 12:30–20:30 Uhr Turmsaal 180,- Euro"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Hilfe mein Haustier ist krank! Was ist, wenn Ihr vierbeiniger Liebling krank wird? In diesem Seminar erlernen Sie, wie Sie Krankheiten beim Tier erkennen und wie Sie erste Hilfe leisten können. Sie bekommen Tipps zur Fütterung und Pflege des kleinen Patienten und lernen, wie Sie Ihren kranken Liebling am besten zum Tierarzt transportieren können. Praktische Übungen am Stofftier stehen auch auf dem Programm. Donnerstag, 17.6., 17:30–21:00 Uhr Raum III 12,- Euro"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Überwinde deinen inneren Schweinehund Gehören Sie auch zu denjenigen, die unangenehme Dinge lieber hinauszögern? Die bis kurz vor dem Abgabetermin mit ihrer Steuererklärung warten? Die immer Ausreden finden, wenn es darum geht, den Kleiderschrank aufzuräumen, einen wichtigen Anruf zu tätigen oder zum Arzt zu gehen? Probieren Sie in diesem Seminar Strategien aus, die Ihnen helfen, Unangenehmes sofort zu erledigen. Samstag, 12.5., 15:00–19:00 Uhr Sonntag, 13.5., 10:00–15:00 Uhr Raum VI 65,- Euro"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Handykurs für Senioren In diesem Kurs werden die Funktionen und die Handhabung der modernen kleinen Informationsgeräte vorgestellt und erklärt. Auf folgende Fragen wird eingegangen: – Was ist ein Vertrags- und was ein Kartenhandy? – Wie schalte ich das Gerät ein und aus? – Wie telefoniere ich damit? – Wie versende und empfange ich eine SMS? – Wie kann ich ins Internet? – Wie benutzt man das integrierte Telefonbuch?3 Mittwoche ab 30.5."
        ]
      }
    ]
  },
  {
    "id": "27",
    "title": "Kleidung, Einrichtung und Musik",
    "sourcePage": 308,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 – Eine Bekannte sucht Möbel für ihre neue Wohnung und wünscht sich viel Platz für ihre Kleidung. 12 – Eine Freundin hat viele Sachen zum Anziehen, die sie nie trägt. Sie möchte einen guten Kleidungsstil entwickeln. 13 – Eine Nachbarin ist sehr kreativ und stellt Kleidung selbst her. Sie überlegt, ob sie diese auch 14 – Ihr 18-jähriger Bruder singt gerne in seiner Freizeit und träumt davon, mal auf der Bühne stehen. 15 – Ihr Sohn interessiert sich für die Gestaltung von Räumen und Möbeln und sucht einen Ausbildungsplatz oder einen passenden Studiengang. 16 – Ihre Cousine schaut sich gerne Bühnenshows an und möchte hensho wissen, welche Arbeiten hinter den Kulissen erledigt werden. 17 – Ihre Schwester studiert Geschichte und interessiert sich für Zeitschriften von früher. Erfahrungen in diesem Beruf sammeln. 18 – Ihre Tochter ist Studentin und würde gerne Moderedakteurin werden. Sie möchte erste 19 – Sie interessieren sich für antike Möbel und möchten eine Ausstellung im Museum besuchen. 20 – Sie möchten sich eine unterhaltsame Bühnenshow ansehen. Wir feiern Geburtstag: 25 Jahre voller Emotionen und atemberaubender Musik! Am 2.12. wird „Die Dschungelsaga“ ein Vierteljahrhundert alt. Während die Zuschauer sich von der Welt der wilden Tiere begeistern lassen, sorgen rund 200 Mitarbeiter dafür, dass jede Vorstellung einzigartig ist. Wir laden Sie deshalb ein, einen Blick hinter die Bühne zu werfen. Unsere Mitarbeiter zeigen, wie die Show entsteht und erklären Ihnen ihre Aufgaben. Freuen Sie sich auf ganz besondere Einblicke in ein Erfolgsmusical! www.dschungelsaga-wird-25.de Das neue Palais – Möbel, Schmuck und Kunst Das Designkaufhaus „Das neue Palais“ ist eine einzigartige Ausstellungs- und Verkaufsplattform für junge Designer, innovative Labels und kreative Manufakturen. Auf rund 4.000 m² präsentieren sich Hersteller von Design-Unikaten und Kleinserien, Möbel- und Modelabels. Erlesene Manufakturen, kleine traditionelle Familienbetriebe, spezialisierte Händler und vielversprechende Newcomer bereichern das vielfältige Angebot. Bergmannstr. 8, 34121 Kassel Der perfekte Kleiderschrank Ihr Kleiderschrank ist voll und trotzdem wissen Sie nicht, was zusammenpasst? Modetrends wechseln schnell, und es ist schwer, die Kleidung zu finden, die perfekt den eigenen Typ unterstreicht. Autorin Miriam Lund hilft Ihnen herauszufinden, was Sie wirklich brauchen – und was nicht. Sie zeigt Ihnen, was Ihnen steht und wie man erfolgreich, ausstrahlend, bewusst konsumiert und herausragende Qualität erkennt. Der perfekte Kleiderschrank hilft Ihnen, Schritt für Schritt eine Garderobe zusammenzustellen, die genau zu Ihnen passt. Filmhit als Musikspektakel Die erfolgreiche Komödie „Eine Chefin zum Fürchten“ kehrt zurück – doch nicht ins Kino, sondern als Musical. Niemand Geringerer als Pop-Weltstar Sir Winston Ryan hat die Geschichte um die Chefredakteurin einer Modezeitschrift, die ihrer Assistentin das Leben schwer macht, musikalisch umgesetzt. „Ich bin ein großer Fan des Films“, erzählt der Brite. Die Geschichte blieb bei dieser Adaption unverändert: Nach dem Studium will die verträumte Amy als Journalistin in New York arbeiten und landet bei dem Mode magazin „Classy“, dort muss sie sich gegen ihre launischen Chefredakteurin Daphne Harris durchsetzen. Noch bis zum 15.4. im Frankfurter www.showtime.biz oder an der Abendkasse www.selbstgemacht-info.net Geld mit dem eigenen Hobby verdienen Sie stricken, nähen oder basteln gerne und haben schon oft Ihre Freunde mit Ihren Kreationen begeistert? Dann sollten Sie den nächsten Schritt unternehmen: Selbstgemachtes kann man online perfekt vermarkten. Auf unserer Website, stellen wir Ihnen die besten Internetplattformen für handgefertigte Produkte vor, erfahren Sie, wann es sich lohnt, einen eigenen Online-Shop zu eröffnen, informieren wir Sie über rechtliche Ihr Kleiderschrank platzt aus allen Nähten? Kein Problem! Wir haben die Lösung: ein begehbarer Kleiderschrank. Dort können Sie alles unterbringen. Und das Beste: Ihr Schrank kann sich verändern – genau wie Ihre Garderobe: Mit unserem flexiblen Schranksystem können Sie jederzeit die Innenausstattung erweitern. Um Ihren Kleiderschrank zu planen, kommen wir gerne zu Ihnen nach Hause. Gestalten Sie Ihr neues Möbelstück ganz nach Ihren Vorstellungen. Beratungstermin: kostenlos! www.flex-meubelsysteme.net Minimalismus im Kleiderschrank Keine Lust mehr auf teure Kleiderkäufe? Dann nähen Sie Ihre Basisgarderobe einfach selbst. Sie besteht aus nur 10 Teilen, die sich schnell anfertigen lassen: Ob Rock, T-Shirt, Bluse, Hose oder Jacke – alles lässt sich perfekt miteinander kombinieren, mal elegant, mal lässig, fürs Büro. Mit Schritt-für-Schritt-Anleitungen. Auch für Nähanfänger geeignet, Größe 32 bis 50, mit Schnittmusterbogen. Regionale Musicalstars gesucht Das Team des Erfolgskomponisten Mirko Graafe sucht Profis und talentierte Anfänger im Alter von 15 bis 60 Jahren für das neue Musical „Fashion“, das dieses Jahr in Bad Honnef Premiere feiern wird. An drei Casting-Terminen können Darsteller für Tanz, Gesang und Schauspiel zeigen, was sie können. Graafe sucht neben Profis auch noch unentdeckte Talente, die mit diesem Projekt gefördert Castings finden am 25. April in Köln, am 2. Mai in Bonn und am 23. Mai in Koblenz statt. Infos: www.fashion-musical.de/casting Ob in New York, Paris oder Mailand: Wenn es um Trends aus der Modewelt geht, sind wir dabei! Wir sind ständig auf der Suche nach Neuigkeiten für unsere Leser. Du möchtest die Medien arbeiten und den Arbeitsalltag bei einem internationalen Magazin kennenlernen? Dann ist ein Praktikum bei uns der beste Start in deine Das solltest du mitbringen: • mindestens Abitur, optimal: einige Semester Studium • selbstverfasste Artikel • Gespür für Mode und Trends • Teamfähigkeit und Aufgeschlossenheit Schick deine Bewerbung einfach an: info@trendy.com – wir freuen uns auf dich! Streifzug durch die Modewelt Paris war um 1900 das inspirierende Zentrum von Kunst, Mode und Lebensart und zog Künstler magisch an. Modeschöpfer kreierten zahlreiche Neuerungen in der Damenmode, und von der französischen Metropole aus verbreiteten sich die Trends. Ab Donnerstag ist Pariser Mode aus dieser Epoche im Museum für Angewandte Kunst in Rostock zu sehen. Gezeigt werden historische Kleidungsstücke und Accessoires. In Vitrinen werden außerdem Modeartikel der Zeit gezeigt sowie die Gegenstände, Tonaufnahmen und Dokumente. Diese zeigen nicht nur aktuelle Mode, sondern enthielten auch Artikel zu Kunst, Musik und Literatur. Täglich bis Sonntag von 10 bis 18 Uhr, Eintritt: 8 €, ermäßigt 5 € Traumberuf Moderedakteurin Wenn Sie ihren Beruf nennt, bekommen viele ein leuchtenden Augen. Kein Wunder: Gigantische Modenschauen in der ersten Reihe, USA-Trips und luxuriöse Designerroben sind für Alexa Chen Alltag. Die Hamburgerin ist Chefredakteurin der Zeitschrift „Fashion & Style“. Als Modejournalistin ist sie immer auf der Suche nach Trends – und ganz vorne dabei. Doch was tatsächlich alles zu ihrem Beruf gehört, das weiß kaum jemand. Alexa Chen persönlich: Am 30.9. ist sie zu Gast in einer Talkrunde und erzählt von ihrem Berufsweg und dem Redaktionsalltag. Beginn: 19 Uhr, Ort: Rathaus, Blauer Saal, Student/-in Innenarchitektur/Möbeldesign Du hast eine Leidenschaft für Inneneinrichtung und möchtest mit deinen Entwürfen unser neues Programm im Bereich DIY-Parcs für Möbeldesign erweitern? Du entwickelst neue Ideen für Möbelstücke und planst, wie sie aus Holz, Metall und Kunststoff aufgebaut werden können. Dein Profil: Gestaltung im Handwerk bzw. vergleichbare kreative Ausbildung. Wir bieten dir ein Praktikum im Bereich Produktentwicklung oder handwerkliche Produktion mit kreativer Verantwortung. Bewerbung mit Kreativität und Eigeninitiative bitte an:",
    "questions": [
      {
        "num": 11,
        "answer": "f",
        "stem": "– Eine Bekannte sucht Möbel für ihre neue Wohnung und wünscht sich viel Platz für ihre Kleidung."
      },
      {
        "num": 12,
        "answer": "c",
        "stem": "– Eine Freundin hat viele Sachen zum Anziehen, die sie nie trägt. Sie möchte einen guten Kleidungsstil entwickeln."
      },
      {
        "num": 13,
        "answer": "e",
        "stem": "– Eine Nachbarin ist sehr kreativ und stellt Kleidung selbst her. Sie überlegt, ob sie diese auch verkaufen könnte."
      },
      {
        "num": 14,
        "answer": "h",
        "stem": "– Ihr 18-jähriger Bruder singt gerne in seiner Freizeit und träumt davon, mal auf der Bühne stehen."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "– Ihr Sohn interessiert sich für die Gestaltung von Räumen und Möbeln und sucht einen Ausbildungsplatz oder einen passenden Studiengang."
      },
      {
        "num": 16,
        "answer": "a",
        "stem": "– Ihre Cousine schaut sich gerne Bühnenshows an und möchte hensho wissen, welche Arbeiten hinter den Kulissen erledigt werden."
      },
      {
        "num": 17,
        "answer": "j",
        "stem": "– Ihre Schwester studiert Geschichte und interessiert sich für Zeitschriften von früher."
      },
      {
        "num": 18,
        "answer": "i",
        "stem": "– Ihre Tochter ist Studentin und würde gerne Moderedakteurin werden. Sie möchte erste Erfahrungen in diesem Beruf sammeln."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "– Sie interessieren sich für antike Möbel und möchten eine Ausstellung im Museum besuchen."
      },
      {
        "num": 20,
        "answer": "d",
        "stem": "Sie möchten sich eine unterhaltsame Bühnenshow ansehen. RE:"
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "25 Jahre in Hamburg Wir feiern Geburtstag: 25 Jahre voller Emotionen und atemberaubender Musik! Am 2.12. wird „Die Dschungelsaga“ ein Vierteljahrhundert alt. Während die Zuschauer sich von der Welt der wilden Tiere begeistern lassen, sorgen rund 200 Mitarbeiter dafür, dass jede Vorstellung einzigartig ist. Wir laden Sie deshalb ein, einen Blick hinter die Bühne zu werfen. Unsere Mitarbeiter zeigen, wie die Show entsteht und erklären Ihnen ihre Aufgaben. Freuen Sie sich auf ganz besondere Einblicke in ein Erfolgsmusical! Jetzt Tickets buchen: www.dschungelsaga-wird-25.de"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Das neue Palais – Möbel, Schmuck und Kunst Das Designkaufhaus „Das neue Palais“ ist eine einzigartige Ausstellungs- und Verkaufsplattform für junge Designer, innovative Labels und kreative Manufakturen. Auf rund 4.000 m² präsentieren sich Hersteller von Design-Unikaten und Kleinserien, Möbel- und Modelabels. Erlesene Manufakturen, kleine traditionelle Familienbetriebe, spezialisierte Händler und vielversprechende Newcomer bereichern das vielfältige Angebot. Das neue Palais Bergmannstr. 8, 34121 Kassel"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Der perfekte Kleiderschrank Ihr Kleiderschrank ist voll und trotzdem wissen Sie nicht, was zusammenpasst? Modetrends wechseln schnell, und es ist schwer, die Kleidung zu finden, die perfekt den eigenen Typ unterstreicht. Autorin Miriam Lund hilft Ihnen herauszufinden, was Sie wirklich brauchen – und was nicht. Sie zeigt Ihnen, was Ihnen steht und wie man erfolgreich, ausstrahlend, bewusst konsumiert und herausragende Qualität erkennt. Der perfekte Kleiderschrank hilft Ihnen, Schritt für Schritt eine Garderobe zusammenzustellen, die genau zu Ihnen passt. Gebundenes Buch, 19 €"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Filmhit als Musikspektakel Die erfolgreiche Komödie „Eine Chefin zum Fürchten“ kehrt zurück – doch nicht ins Kino, sondern als Musical. Niemand Geringerer als Pop-Weltstar Sir Winston Ryan hat die Geschichte um die Chefredakteurin einer Modezeitschrift, die ihrer Assistentin das Leben schwer macht, musikalisch umgesetzt. „Ich bin ein großer Fan des Films“, erzählt der Brite. Die Geschichte blieb bei dieser Adaption unverändert: Nach dem Studium will die verträumte Amy als Journalistin in New York arbeiten und landet bei dem Mode magazin „Classy“, dort muss sie sich gegen ihre launischen Chefredakteurin Daphne Harris durchsetzen. Noch bis zum 15.4. im Frankfurter www.showtime.biz oder an der Abendkasse"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "www.selbstgemacht-info.net Geld mit dem eigenen Hobby verdienen Sie stricken, nähen oder basteln gerne und haben schon oft Ihre Freunde mit Ihren Kreationen begeistert? Dann sollten Sie den nächsten Schritt unternehmen: Selbstgemachtes kann man online perfekt vermarkten. Auf unserer Website, stellen wir Ihnen die besten Internetplattformen für handgefertigte Produkte vor, erfahren Sie, wann es sich lohnt, einen eigenen Online-Shop zu eröffnen, informieren wir Sie über rechtliche Bestimmungen."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Ihr Kleiderschrank platzt aus allen Nähten? Kein Problem! Wir haben die Lösung: ein begehbarer Kleiderschrank. Dort können Sie alles unterbringen. Und das Beste: Ihr Schrank kann sich verändern – genau wie Ihre Garderobe: Mit unserem flexiblen Schranksystem können Sie jederzeit die Innenausstattung erweitern. Um Ihren Kleiderschrank zu planen, kommen wir gerne zu Ihnen nach Hause. Gestalten Sie Ihr neues Möbelstück ganz nach Ihren Vorstellungen. Beratungstermin: kostenlos! www.flex-meubelsysteme.net"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Minimalismus im Kleiderschrank Keine Lust mehr auf teure Kleiderkäufe? Dann nähen Sie Ihre Basisgarderobe einfach selbst. Sie besteht aus nur 10 Teilen, die sich schnell anfertigen lassen: Ob Rock, T-Shirt, Bluse, Hose oder Jacke – alles lässt sich perfekt miteinander kombinieren, mal elegant, mal lässig, fürs Büro. Mit Schritt-für-Schritt-Anleitungen. Auch für Nähanfänger geeignet, Größe 32 bis 50, mit Schnittmusterbogen."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Regionale Musicalstars gesucht Das Team des Erfolgskomponisten Mirko Graafe sucht Profis und talentierte Anfänger im Alter von 15 bis 60 Jahren für das neue Musical „Fashion“, das dieses Jahr in Bad Honnef Premiere feiern wird. An drei Casting-Terminen können Darsteller für Tanz, Gesang und Schauspiel zeigen, was sie können. Graafe sucht neben Profis auch noch unentdeckte Talente, die mit diesem Projekt gefördert werden könnten. Castings finden am 25. April in Köln, am 2. Mai in Bonn und am 23. Mai in Koblenz statt. Infos: www.fashion-musical.de/casting"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Mode, Stars, Lifestyle Ob in New York, Paris oder Mailand: Wenn es um Trends aus der Modewelt geht, sind wir dabei! Wir sind ständig auf der Suche nach Neuigkeiten für unsere Leser. Du möchtest die Medien arbeiten und den Arbeitsalltag bei einem internationalen Magazin kennenlernen? Dann ist ein Praktikum bei uns der beste Start in deine Karriere. Das solltest du mitbringen: • mindestens Abitur, optimal: einige Semester Studium • selbstverfasste Artikel • Gespür für Mode und Trends • Teamfähigkeit und Aufgeschlossenheit Schick deine Bewerbung einfach an: info@trendy.com – wir freuen uns auf dich!"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Streifzug durch die Modewelt Paris war um 1900 das inspirierende Zentrum von Kunst, Mode und Lebensart und zog Künstler magisch an. Modeschöpfer kreierten zahlreiche Neuerungen in der Damenmode, und von der französischen Metropole aus verbreiteten sich die Trends. Ab Donnerstag ist Pariser Mode aus dieser Epoche im Museum für Angewandte Kunst in Rostock zu sehen. Gezeigt werden historische Kleidungsstücke und Accessoires. In Vitrinen werden außerdem Modeartikel der Zeit gezeigt sowie die Gegenstände, Tonaufnahmen und Dokumente. Diese zeigen nicht nur aktuelle Mode, sondern enthielten auch Artikel zu Kunst, Musik und Literatur. Täglich bis Sonntag von 10 bis 18 Uhr, Eintritt: 8 €, ermäßigt 5 €"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Traumberuf Moderedakteurin Wenn Sie ihren Beruf nennt, bekommen viele ein leuchtenden Augen. Kein Wunder: Gigantische Modenschauen in der ersten Reihe, USA-Trips und luxuriöse Designerroben sind für Alexa Chen Alltag. Die Hamburgerin ist Chefredakteurin der Zeitschrift „Fashion & Style“. Als Modejournalistin ist sie immer auf der Suche nach Trends – und ganz vorne dabei. Doch was tatsächlich alles zu ihrem Beruf gehört, das weiß kaum jemand. Alexa Chen persönlich: Am 30.9. ist sie zu Gast in einer Talkrunde und erzählt von ihrem Berufsweg und dem Redaktionsalltag. Beginn: 19 Uhr, Ort: Rathaus, Blauer Saal, Eintritt kostenlos"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Wir suchen Student/-in Innenarchitektur/Möbeldesign Du hast eine Leidenschaft für Inneneinrichtung und möchtest mit deinen Entwürfen unser neues Programm im Bereich DIY-Parcs für Möbeldesign erweitern? Du entwickelst neue Ideen für Möbelstücke und planst, wie sie aus Holz, Metall und Kunststoff aufgebaut werden können. Dein Profil: Gestaltung im Handwerk bzw. vergleichbare kreative Ausbildung. Wir bieten dir ein Praktikum im Bereich Produktentwicklung oder handwerkliche Produktion mit kreativer Verantwortung. Bewerbung mit Kreativität und Eigeninitiative bitte an: Construct Baumarkt"
        ]
      }
    ]
  },
  {
    "id": "28",
    "title": "Kunst, Geschenke und Einkaufen",
    "sourcePage": 311,
    "keywords": "Lesen Sie zuerst die zehn Situationen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Sie möchten einem Verwandten eine Lampe aus der ersten Hälfte des 20. Jahrhunderts schenken. Sie können dafür aber höchstens 100 Euro ausgeben. 12 Sie suchen für ihre Kollegin eine aktuelle CD als Geburtstagsgeschenk. 13 Gemeinsam mit anderen Verwandten möchten Sie Ihren kunstbegeisterten Großeltern ein besonderes Wochenende schenken. 14 Ihre Freundin fährt nicht gern Auto und möchte eine Ausstellung bekannter Malerinnen 15 Ihre Chefin sucht für ihre Dienstreisen einen leistungsfähigen, gut zu transportierenden leichten Computer, mit dem sie überall ihre Präsentationen zeigen kann. 19 Ihr Nachbar braucht ein neues Bad. Eine befreundete Familie möchte einen autofreien Urlaub am Meer verbringen. Ein Freund möchte lernen, wie man Computerspiele entwickelt. Eine Bekannte möchte wetterfeste Möbel für ihre Terrasse kaufen. Sie möchten mit Bekannten am Wochenende Bayern per Bahn erleben. Möbelberatung und -verkauf Das Möbelhaus Hartmann ist seit 20 Jahren bemüht; den Kunden den größtmöglichen Service zu bieten. Im Bettenstudio erhalten Kunden kompetente Fachbe- ratung für den individuellen Schlafkomfort, für ausführ- liche Fachberatung im Lichtstudio steht ein erfahrener Lichtplaner zur Verfügung. Speziell in den Bereichen Bestuhlung, Tische und Bänke, Beleuchtung und Innen- einrichtung ist Möbel Hartmann Ihr kompetenter An- sprechpartner. Auch in Sachen außergewöhnliche und exklusive Gartenmöbel, die Wind und Wetter aushalten, ist das Möbelhaus Hartmann die erste Adresse für stilbe- Der Mac-Spezialist SBS-Compu- www.moebel-hartmann.de. Telefon: 089 / 623 0 743–7 ter in der Wasserburgstraße 32 hat viel zu bieten: Hier kann man die begehrten Produkte von Mac mit dazugehöriger Soft- und Hardware nicht nur kaufen, man freundlich beraten. Außerdem unterhält SBS-Computer eine ENGELBERGER WOHNKULTUR steht für eine Support-Abteilung, die etwaige anspruchsvolle Auswahl an Produkten höchster Garantiefälle Ihres Apple-Com- handwerklicher Perfektion und die Zu sammen- arbeit mit den führenden Werkstätten der Einrich- tungsbranche. Was 1956 als Ein-Mann-Betrieb begann, entwickelte sich bis heute zu einem florierenden Familienunternehmen, das sich auf Gesamtplanungen für Privathäuser und Woh- nungen, für Büros und Objekte spezialisiert hat. Die Geschäftsführer sehen ihre Haupttätigkeits- felder in folgenden Bereichen: Einrichtungsbera- tung, -planung und -realisierung aus einer Hand, Innenausbau, Badplanung und -realisierung, Texti lien und Kunstgewerbe. Kennerschaft, Kompetenz und Vertrauen bilden die Unternehmensphilosophie des Auktionshauses von Marianne Pater. Bei ihren Auktionen werden Kunstgegenstände und Sammlerstücke wie Ge- mälde, Bilderrahmen, Silber und Schmuck, aber auch Gegenstände des täglichen Lebens wie Möbel, Lampen und Teppiche sowie verschiedene Kuriositäten angeboten. Hier können Sie, wenn Sie Glück haben, schöne Stücke wirklich günstig bekommen! Ein besonderer Schwerpunkt des Auktionshauses liegt auf dem Gebiet von hochwertigem Marken- porzellan. Marianne Pater appelliert an die Kunden, ihre Objekte kostenfrei zur Begutachtung und Beratung vorzulegen. Eine Auktion gilt als gute Möglichkeit, Kunstgegenstände zu veräußern und auch zu erwerben, wobei der Markt den Preis bestimmt. Hier kann man außerdem Ersatz- teile bestellen oder auch Tipps und Tricks zur Bedienung des Mehr Infos findet man unter www.sbs-computer.de oder direkt in der Wasserburgstraße 32. Ein Kopierer im echten Westen- taschenformat, der die einge- scannten Dokumente sofort in Computerspiele selbst entwickeln Textdateien zum Weiterverar- beiten umwandelt – diese prak- Die Freie Computerschule startet am 8. Februar tische Idee hat Minimal Solutions eine Fortbildungsreihe zur Entwicklung von Compu- mit dem MiniScan 2 jetzt um- terspielen. Unter dem Motto „BreakOut Computer- gesetzt. So groß wie ein dicker spiele“ werden insgesamt zwölf Fortbildungen an- Kugelschreiber kann das Gerät geboten, die das Know-how für die wesentlichen problemlos in der Tasche mitge- Herausforderungen bei der Entwicklung von Com- nommen werden. Textpassagen lassen sich damit einlesen, indem Die Seminare finden alle zwei Wochen jeweils frei- wie mit einem Markierstift Zeile tags halbtags (13–18 Uhr) und samstags ganztags für Zeile damit abgefahren wird. (10–19 Uhr) statt. Weitere Informationen und Wieder im Büro wird das Gerät mit dem Computer verbunden, wo die Dateien abgespeichert http://computerspiele-selbstgemacht.de und dann in allen gängigen Programmen verwendet werden können. Im Fachhandel kostet der MiniScan 2 knapp 140 Euro. ganze Strecke einschließlich Bus, Fähre und Inselbahn ausgestellt. Ihr Vorteil: Kinder unter 15 Jahren, die auf der Fahrkarte eines Eltern-/ Großelternteils eingetragen sind, fahren bei der Bahn kostenlos mit. Sie brauchen also nur noch Unter www.bahn.de/nordseeinseln finden Sie viele Infos zu Sehenswürdigkeiten, Veranstal- tungen, zur Anreise und Übernachtung. Insel- prospekte unter Info-Hotline 0180 5 202096. Ein richtiges Notebook ist Ihnen für unterwegs zu schwer? Dann ist der Office-Mobil genau das Richtige für Sie! Er ist um einiges kleiner als ein Laptop, lässt sich aber genauso wie die großen Brüder über ein Kabel an den Beamer anschließen – und Sie können überall Ihre Und natürlich bietet Ihnen Office-Mobil auch alles, was Sie zum schnellen Surfen im Internet brauchen. Die Festplatte fasst acht Gigabyte und genügt damit für zahlreiche Dokumente oder Präsentationen. Schon die Namen der 13 Nordseeinseln ma- chen Lust auf Wind, Wellen, Sommer und Strand: Borkum, Juist, Norderney, Baltrum, Langeoog, Spiekeroog, Wange rooge, Helgo- land, Pellworm, Hallig Hooge, Amrum, Föhr und Sylt. Jede der Inseln ist ein kleines Paradies für sich. Das Urlaubsvergnügen beginnt bereits mit der Bahnfahrt und setzt sich fort beim Um- steigen auf eines der weißen Fährschiffe. Sie können Ihre Reise übrigens in einem Stück buchen, denn Ihre DB-Fahrkarte wird für die Frauen künstlerisch aktiv halle Frankfurt präsentiert klusiv für Europa „lmpres- Bahn bietet zur Ausstellung Kultur-Ticket-Spezial an. Das DB-Angebot ist im Um- kreis von 300 km gültig für die Hin- und Rückfahrt zum Ausstellungsort und kostet in der 2. Klasse 39 Euro / 1. Klasse 59 Euro pro Per- Durch Hessen mit dem Hessenticket! Schon ab 6 Euro pro Person mit Bus und Bahn unbegrenzt fahren! Und damit das Reisen einfach wird und vor allem preiswert, bietet die Bahn für 30 Euro das Hessenticket an. Am Gültigkeitstag fahren bis zu fünf Personen ohne Kilometerbegrenzung, so oft sie wollen, in allen Ver- kehrsmitteln, neben Bus und Bahn auch in der Stra- ßen- oder der U-Bahn. Nur ICE-, EC/IC- und D-Züge sind ausgeschlossen. Das Hessenticket gilt an Werkta- gen (Mo. bis Fr.) von 9.00 Uhr bis 3.00 Uhr des Folge- tages, an Samstagen, Sonntagen und Feiertagen von 0.00 Uhr bis 3.00 Uhr des Folgetages. Als »Kommissarleuchte« wurde die seriöse Lampe mit dem gewissen Etwas in den 50er-Jahren berühmt, weil sie eine beliebte Requisite in den deutschen Fernseh- krimis war. Doch eigentlich ist sie ein echter Klassiker: Der Bauhaus-Gestalter Christian Dell entwarf den Schreibtischstrahler bereits in den 30er-Jahren für die nordrhein-westfälische Lampenfabrik »Gebrüder Kaiser & Co.«. Der Urenkel des Firmengründers hat die luxuriöse Neu-Edition veranlasst, sie kostet 590 €. Wenn die Nacht hereinbricht über Burg Wern- berg, gehen viele der Touristen schlafen – einige von ihnen tun das an Ort und Stelle: In der Herzoginsuite mit Blick auf die Burgkapelle zum Beispiel, oder in der Fürstensuite, wo Naturstein- wände und antike Möbel den staunenden Gast vom Schlaf abhalten. Das ist vielleicht der Nach- teil, wenn man in einem Hotel nächtigt, das zu- gleich Sehenswürdigkeit ist, wie die 1280 urkund- lich erwähnte und 1998 komplett res taurierte Burg am Rande des Oberpfälzer Waldes. So gehört bei 20 Ausflugzielen in Bayern die Übernachtung zum Kunstgenuss dazu: Nach „Sightseeing\" kommt „Sightsleeping\". So heißt die junge Hotelmarke, die kunst- und kultur- begeisterte Reisende anlocken soll. Überblick der Hotels unter www.sightsleeping.by",
    "questions": [
      {
        "num": 11,
        "answer": "d",
        "stem": "Sie möchten einem Verwandten eine Lampe aus der ersten Hälfte des 20. Jahrhunderts schenken. Sie können dafür aber höchstens 100 Euro ausgeben."
      },
      {
        "num": 12,
        "answer": "x",
        "stem": "Sie suchen für ihre Kollegin eine aktuelle CD als Geburtstagsgeschenk."
      },
      {
        "num": 13,
        "answer": "l",
        "stem": "Gemeinsam mit anderen Verwandten möchten Sie Ihren kunstbegeisterten Großeltern ein besonderes Wochenende schenken."
      },
      {
        "num": 14,
        "answer": "i",
        "stem": "Ihre Freundin fährt nicht gern Auto und möchte eine Ausstellung bekannter Malerinnen besuchen."
      },
      {
        "num": 15,
        "answer": "h",
        "stem": "Ihre Chefin sucht für ihre Dienstreisen einen leistungsfähigen, gut zu transportierenden leichten Computer, mit dem sie überall ihre Präsentationen zeigen kann."
      },
      {
        "num": 16,
        "answer": "g",
        "stem": "Eine befreundete Familie möchte einen autofreien Urlaub am Meer verbringen."
      },
      {
        "num": 17,
        "answer": "e",
        "stem": "Ein Freund möchte lernen, wie man Computerspiele entwickelt."
      },
      {
        "num": 18,
        "answer": "a",
        "stem": "Eine Bekannte möchte wetterfeste Möbel für ihre Terrasse kaufen."
      },
      {
        "num": 19,
        "answer": "c",
        "stem": "Ihr Nachbar braucht ein neues Bad."
      },
      {
        "num": 20,
        "answer": "x",
        "stem": "Sie möchten mit Bekannten am Wochenende Bayern per Bahn erleben."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Möbelberatung und -verkauf Das Möbelhaus Hartmann ist seit 20 Jahren bemüht; den Kunden den größtmöglichen Service zu bieten. Im Bettenstudio erhalten Kunden kompetente Fachberatung für den individuellen Schlafkomfort, für ausführliche Fachberatung im Lichtstudio steht ein erfahrener Lichtplaner zur Verfügung. Speziell in den Bereichen Bestuhlung, Tische und Bänke, Beleuchtung und Inneneinrichtung ist Möbel Hartmann Ihr kompetenter Ansprechpartner. Auch in Sachen außergewöhnliche und exklusive Gartenmöbel, die Wind und Wetter aushalten, ist das Möbelhaus Hartmann die erste Adresse für stilbewusste Kunden. www.moebel-hartmann.de. Telefon: 089 / 623 0 743–7"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Mac-Beratung und -Verkauf Der Mac-Spezialist SBS-Computer in der Wasserburgstraße 32 hat viel zu bieten: Hier kann man die begehrten Produkte von Mac mit dazugehöriger Soft- und Hardware nicht nur kaufen, man wird auch kompetent und freundlich beraten. Außerdem unterhält SBS-Computer eine Support-Abteilung, die etwaige Garantiefälle Ihres Apple-Computers abwickelt. Hier kann man außerdem Ersatzteile bestellen oder auch Tipps und Tricks zur Bedienung des Mac einholen. Mehr Infos findet man unter www.sbs-computer.de oder direkt in der Wasserburgstraße 32."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Handwerkliche Perfektion ENGELBERGER WOHNKULTUR steht für eine anspruchsvolle Auswahl an Produkten höchster handwerklicher Perfektion und die Zus ammenarbeit mit den führenden Werkstätten der Einrichtungsbranche. Was 1956 als Ein-Mann-Betrieb begann, entwickelte sich bis heute zu einem florierenden Familienunternehmen, das sich auf Gesamtplanungen für Privathäuser und Wohnungen, für Büros und Objekte spezialisiert hat. Die Geschäftsführer sehen ihre Haupttätigkeitsfelder in folgenden Bereichen: Einrichtungsberatung, -planung und -realisierung aus einer Hand, Innenausbau, Badplanung und -realisierung, Textil ien und Kunstgewerbe."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Auktionshaus Pater Kennerschaft, Kompetenz und Vertrauen bilden die Unternehmensphilosophie des Auktionshauses von Marianne Pater. Bei ihren Auktionen werden Kunstgegenstände und Sammlerstücke wie Gemälde, Bilderrahmen, Silber und Schmuck, aber auch Gegenstände des täglichen Lebens wie Möbel, Lampen und Teppiche sowie verschiedene Kuriositäten angeboten. Hier können Sie, wenn Sie Glück haben, schöne Stücke wirklich günstig bekommen! Ein besonderer Schwerpunkt des Auktionshauses liegt auf dem Gebiet von hochwertigem Markenporzellan. Marianne Pater appelliert an die Kunden, ihre Objekte kostenfrei zur Begutachtung und Beratung vorzulegen. Eine Auktion gilt als gute Möglichkeit, Kunstgegenstände zu veräußern und auch zu erwerben, wobei der Markt den Preis bestimmt."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Computerspiele selbst entwickeln Die Freie Computerschule startet am 8. Februar eine Fortbildungsreihe zur Entwicklung von Computerspielen. Unter dem Motto „BreakOut Computerspiele“ werden insgesamt zwölf Fortbildungen angeboten, die das Know-how für die wesentlichen Herausforderungen bei der Entwicklung von Computerspielen vermitteln. Die Seminare finden alle zwei Wochen jeweils freitags halbtags (13–18 Uhr) und samstags ganztags (10–19 Uhr) statt. Weitere Informationen und Anmeldung unter: http://computerspiele-selbstgemacht.de"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Ein Kopierer im echten Westentaschenformat, der die eingescannten Dokumente sofort in Textdateien zum Weiterverarbeiten umwandelt – diese praktische Idee hat Minimal Solutions mit dem MiniScan 2 jetzt umgesetzt. So groß wie ein dicker Kugelschreiber kann das Gerät problemlos in der Tasche mitgenommen werden. Textpassagen lassen sich damit einlesen, indem wie mit einem Markierstift Zeile für Zeile damit abgefahren wird. Wieder im Büro wird das Gerät mit dem Computer verbunden, wo die Dateien abgespeichert und dann in allen gängigen Programmen verwendet werden können. Im Fachhandel kostet der MiniScan 2 knapp 140 Euro."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Schon die Namen der 13 Nordseeinseln machen Lust auf Wind, Wellen, Sommer und Strand: Borkum, Juist, Norderney, Baltrum, Langeoog, Spiekeroog, Wangerooge, Helgoland, Pellworm, Hallig Hooge, Amrum, Föhr und Sylt. Jede der Inseln ist ein kleines Paradies für sich. Das Urlaubsvergnügen beginnt bereits mit der Bahnfahrt und setzt sich fort beim Umsteigen auf eines der weißen Fährschiffe.",
          "Sie können Ihre Reise übrigens in einem Stück buchen, denn Ihre DB-Fahrkarte wird für die",
          "ganze Strecke einschließlich Bus, Fähre und Inselbahn ausgestellt. Ihr Vorteil: Kinder unter 15 Jahren, die auf der Fahrkarte eines Eltern-/ Großelternteils eingetragen sind, fahren bei der Bahn kostenlos mit. Sie brauchen also nur noch das Schiffsticket.",
          "Unter www.bahn.de/nordseeinseln finden Sie viele Infos zu Sehenswürdigkeiten, Veranstaltungen, zur Anreise und Übernachtung. Inselprospekte unter Info-Hotline 0180 5 202096."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Ein richtiges Notebook ist Ihnen für unterwegs zu schwer? Dann ist der Office-Mobil genau das Richtige für Sie! Er ist um einiges kleiner als ein Laptop, lässt sich aber genauso wie die großen Brüder über ein Kabel an den Beamer anschließen – und Sie können überall Ihre Dateien projizieren. Und natürlich bietet Ihnen Office-Mobil auch alles, was Sie zum schnellen Surfen im Internet brauchen. Die Festplatte fasst acht Gigabyte und genügt damit für zahlreiche Dokumente oder Präsentationen."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Die weiblichen Stars des 19. Jahrhunderts – die Bahn bietet ein Kultur- Ticket-S pezial an: Sie sind die Weggefährtinnen von Monet, Manet und Renoir. Und sie beweisen, dass Ende des 19. Jahrhunderts mehr Frauen künstlerisch aktiv waren als bislang bekannt. Die Schirn Kunsthalle Frankfurt präsentiert noch bis zum 1. Juni exklusiv für Europa „lmpressionistinnen”. Die rund 150 Meisterwerke der Künst lerinnen stammen aus der ganzen Welt. Die Bahn bietet zur Ausstellung „lmpressionistinnen” ein Kultur-Ticket-Spezial an. Das DB-Angebot ist im Umkreis von 300 km gültig für die Hin- und Rückfahrt zum Ausstellungsort und kostet in der 2. Klasse 39 Euro / 1. Klasse 59 Euro pro Person."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Durch Hessen mit dem Hessenticket! Schon ab 6 Euro pro Person mit Bus und Bahn unbegrenzt fahren! Und damit das Reisen einfach wird und vor allem preiswert, bietet die Bahn für 30 Euro das Hessenticket an. Am Gültigkeitstag fahren bis zu fünf Personen ohne Kilometerbegrenzung, so oft sie wollen, in allen Verkehrsmitteln, neben Bus und Bahn auch in der Straßen- oder der U-Bahn. Nur ICE-, EC/IC- und D-Züge sind ausgeschlossen. Das Hessenticket gilt an Werktagen (Mo. bis Fr.) von 9.00 Uhr bis 3.00 Uhr des Folgetages, an Samstagen, Sonntagen und Feiertagen von 0.00 Uhr bis 3.00 Uhr des Folgetages."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "„Weimarer Klassik“ Als »Kommissarleuchte« wurde die seriöse Lampe mit dem gewissen Etwas in den 50er-Jahren berühmt, weil sie eine beliebte Requisite in den deutschen Fernsehkrimis war. Doch eigentlich ist sie ein echter Klassiker: Der Bauhaus-Gestalter Christian Dell entwarf den Schreibtischstrahler bereits in den 30er-Jahren für die nordrhein-westfälische Lampenfabrik »Gebrüder Kaiser & Co.«. Der Urenkel des Firmengründers hat die luxuriöse Neu-Edition veranlasst, sie kostet 590 €. www.kaiseridell.de"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Wenn die Nacht hereinbricht über Burg Wernberg, gehen viele der Touristen schlafen - einige von ihnen tun das an Ort und Stelle: In der Herzoginsuite mit Blick auf die Burgkapelle zum Beispiel, oder in der Fürstensuite, wo Natursteinwände und antike Möbel den staunenden Gast vom Schlaf abhalten. Das ist vielleicht der Nachteil, wenn man in einem Hotel nächtigt, das zugleich Schenswürdigkeitist, wie die 1280 urkund-",
          "lich erwähnte und 1998 komplett restaurierte Burg am Rande des Oberpfälzer Waldes.",
          "So gehört bei 20 Ausflugzielen in Bayern die Übernachtung zum Kunstgenuss dazu: Nach „Sightsceing\" kommt „Sightsleeping”. So heißt die junge Hotelmarke, die kunst- und kulturbegeisterte Reisende anlocken soll.",
          "Überblick der Hotels unter www.sightsleeping.by"
        ]
      }
    ]
  },
  {
    "id": "29",
    "title": "Inline-Skaten und Auslandsreisen",
    "sourcePage": 315,
    "keywords": "0 90 Minuten Leseverstehen und Ein Freund möchte sich im Inline-Skaten Eine Bekannte möchte einen Kurs über Naturkosmetik Eine 17-jährige Freundin würde gerne armen Menschen in anderen Ländern Ihr Nachbar möchte sich im Sommerurlaub sportlich Lesen Sie zuerst die zehn Situationen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben 11– Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Ein Bekannter möchte Schweden per Schiff Ein Kollege möchte sich über Gesundheitsrisiken in Ägypten Ihre Freundin möchte gerne bei der Organisation einer Inline-Skate-Veranstaltung 18 Sie möchten das Inline-Skaten erlernen und suchen 20 Sie müssen kurzfristig für Ihren Chef Reisepapiere für Ägypten Sie möchten herausfinden, wo es in Deutschland Skate- © telc gGmbH, Frankfurt a. M., telc Deutsch B2, 2019 © telc gGmbH, Frankfurt a. M., telc Deutsch B2, 2019 90 Minuten Leseverstehen und a Auf dem Göta-Kanal sind drei histo rische b Skating für Fortgeschrittene Schiffe unterwegs: „Juno“, „Wilhelm Tham“ und „Diana“. Die um die Jahrhundertwende gebauten Dampfer sind restauriert und auf Verkehrsschild oder eine Ampel in der Nähe ist? Vielleicht ist ein Wochenend- Unterkunft an Bord: in Doppelkabinen mit Etagen-betten, Dusche und WC. Kurs beim Starnberger Rollschuh-Club Reiseverlauf: Reiseantritt in Stockholm oder genau das Richtige für Sie. Göteborg. Aktivitäten: tägliche Ausflüge zu Trainer vermitteln effektives Gleiten, verschie-denen Sehenswürdigkeiten, Brem-sen, Kurvenfahren, Fallen – alles Spaziergänge auf dem Treidelweg, baden, lesen, für fortge-schrittene Skater, die ihre Karten spielen, die Stim-mung an Deck Technik verbes-sern wollen. Reisetermine: von Mai bis September. Wer in Göteborg oder Stockholm bleiben will, kann weitere Übernachtungen buchen. Fr 17 Uhr bis So 19 Uhr, Ü/F, ab 160 Euro, Weitere Infos: Schweden-Werbung, Lilienstr. Infos: 0800 / 100 88 00 (Ortstarif). 19, D-20095 Hamburg, Tel. 040 / 32 55 13 55. Web: www.gotacanal.se (Reederei). d LAUFEN FÜR DIE FORSCHUNG Skater gelten verkehrsrechtlich als Fußgänger und Straßenlauf in Frankfurt am Main: Alle dürfen eigentlich nur auf Gehwegen oder in Teilnehmer haben ihren Sponsor; das Geld stiften sie für Aufklärung und verkehrsberuhigten Zonen fahren. Gar nicht einfach, Forschung zum Thema Brustkrebs. eine schöne, freie Piste auf glattem Asphalt zu Gestartet wird am 13. August um zehn finden! In unseren Reiseführern für Skater stellen wir Uhr morgens am Frankfurter Römer. Die Idee für diese Aktion stammt aus den ausgewählte Strecken für Touren vor: in USA: Dort organi-siert die „Breast verschiedenen Großstädten und Regionen in Cancer Foundation“ seit fast Deutschland, von der kleinen Abend- bis zur großen Tagestour. (Klartext Verlag Essen, ab ca. 7 Euro im Wichtige Infos zu Skate-Hallen und -Bahnen, Veranstaltun-gen, zu regelmäßigen Inline- Treffpunkten von Flensburg bis Passau enthält der „ActionGuide Inline-Skating“ (BLV Verlag, 14,80 Russland, China, Kamerun, Venezuela – er binnen weniger Tage in ein Land jenseits der EU-Grenzen aufbrechen muss, verliert eine Menge Zeit bei der Beschaffung von Einreisepa-pieren. Inzwischen holen Agenturen die Visa kurzfristig ein, überbringen sie persönlich oder hinterlegen sie am Flughafen. So geht’s: Sie las-sen sich vom Visumservice beraten, füllen einen Antrag aus, die Unterlagen werden überprüft und beim zuständigen Konsulat eingereicht. Kosten für ein Visum innerhalb von fünf Auslandsreisen zu Hilfsprojekten in anderen Ländern (mit sozialer Tätigkeit, z. B. Hilfe in Schulen o. Ä.) – Reisen, Arbeits-tagen: 85 Euro; 24-Stunden-Service: Infos: Tel. 069/69 07 22 32, Können Sie bremsen? Oder nur wenn ein Dazu: neueste Skate-Modelle zum Üben: 20 Jahren solche gesponserten Läufe. Wer mitlaufen und/oder sponsern will, kann sich per E-Mail anmelden. E-Mail: raceforthecure@arcormail.de f MÖWE E. V. – Kinder- und Jugendfreizeiten Wir bieten: Campen, Kanufahren, Wandern, Klettern, Geländespiele usw. • Für Kinder und Jugendliche zwischen 7 und 18 Jahren. Alle Aktivitäten werden von erfahrenen Pädagogen betreut und begleitet! Elternbegleitung möglich. • Integrativer Ansatz: auch für Kinder und Betreuungsbedarf. • Jetzt neu: Lernen, Gutes tun! Für Jugendliche ab Weitere Infos: Möwe e. V., Esslinger str. 7, © telc gGmbH, Frankfurt a. M., telc Deutsch B2, 2019 © telc gGmbH, Frankfurt a. M., telc Deutsch B2, 2019 90 Minuten Leseverstehen und Sprachbausteine g Sie wollen bald zu Ihrer ersten Inliner-Tour starten? Anfänger sollten die wichtigsten Techniken (beim Gleiten, Bremsen und Fallen) vorher üben und Körperhaltung und Balance trainieren. Infos zu Kursen gibt es beim Deutschen Inline-Skate-Verband. Auch Skate Nights vom 5. bis 9. August Sportartikelfirmen bieten Kurse an, z. B. das mobile „K2 Skate College“ in ca. 100 deut- schen Städten (Tel. 0190 / 57 55 55; 2 Stunden 25 Euro). sucht die Stadt Mainz Helfer. Engagierte Skater werden benötigt, die Ska- ting-Regeln erklären oder bei der Verkehrs- In kleinen Gruppen lernen Sie die richtige Technik beim Gleiten, Bremsen und Fallen, regelung helfen. An allen Tagen dürfen Skater von 20.30 bis 22.30 Uhr durch die Innenstadt trainieren Körperhaltung und Balance. Skate-Unterricht für Einsteiger gibt es auch per Video (z. B. GoInline!; ca. 15 Euro, in Buch- und Sport geschäften) oder als Buch (z. B. Richtig Inline-Skaten, BLV Verlag, 9,90 Euro). fahren – auf einem Rundkurs über Hauptstra- Anmeldung für die Helfer und Inline-Skater beim Sportamt der Stadt Mainz, Tel.: 06131-12 i B ä c h e , S e e n , W ä l d e r u n d W i e s e n Für Feriengenießer haben wir viel zu bieten: Wichtige Hinweise für Ihre Reise nach Ägyp- herrliche Natur, ein bisschen Luxus, komfor- ten. Sicherheit: Die Hauptattraktionen des Landes werden bewacht. Verhalten Sie sich table Zimmer und Suiten, gemütliche Restau- respektvoll dem kulturellen Erbe und den rants mit dem Besten aus Küche und Keller. Einheimischen gegenüber. Passen Sie Ihre Und dazu ein großes Angebot für alle, die im Kleidung wie bei jeder Reise den Gepflogen- Urlaub aktiv werden wollen: geführte Wande- heiten des Landes an. Gesundheit: Wasser, rungen im Tannheimer Tal, Radeln, Mountain- auch zum Zähneputzen, sollten Sie nur aus verschlossenen Flaschen benutzen. biken, Surfen, Bootsfahrten und Baden am klaren Haldensee, Tennisspielen und dann Welche Impfung nötig ist, erfahren Sie am Relaxen im Wellness-Bereich – Entspannung Impftelefon: 0 40 / 42 81 88 00. Beste Rei- pur! Schöner kann Urlaub nicht sein! Hotel Waldruhe, A-6673 Haldensee, Bergweg 12, Tel.: 0043-56 75 31 62; E-Mail: hoteltyrol@netway.at Früher schnitt man hier das Rohr für die Flo- rentinerhüte, heute ist der winzige, von grünen Wiesen umgebene See an der Grenze zu Lati- um ein Geheimtipp für Liebhaber der Gemäch- lichkeit. Zeitloses Italien: ein windschiefer Holz- steg, morsche bunte Boote, ein paar Angler, ein paar Enten auf sattem Grün und der würzige Geruch von Seefischen, die „alla etrusca“ über Schilf gebraten werden. Zum Beispiel bei Gino: Filets von Forelle, Felchen und Hecht, ein paar Spritzer Olivenöl und Zitronensaft. sezeit: Oktober bis April. Touren: Alle großen deutschen Veranstalter bieten auch Rund- reisen sowie Kreuzfahrten auf dem Nil an. Weitere Informationen finden Sie im Internet unter www.reise-tipps.eu. KRÄUTERCREME UND ÖKO-SEI FE Viele Beauty-Produkte schmücken sich mit dem Begriff „Naturkosmetik“. Bisher gab es dafür keine festen Prüf kriterien, doch jetzt kommt das Gütezeichen „Kontrollierte Natur-Kosmetik BDHI“, das vom Bundesverband Deutscher Industrie- und Handelsunternehmen (BDHI) vergeben wird. Damit können Sie sicher sein: Wo Natur draufsteht, ist auch Natur drin. Infos gibt’s beim BDHI unter: Telefon 06 21/1 © telc gGmbH, Frankfurt a. M., telc Deutsch B2, 2019",
    "questions": [
      {
        "num": 11,
        "answer": "a",
        "stem": "Ein Bekannter möchte Schweden per Schiff kennenlernen."
      },
      {
        "num": 12,
        "answer": "b",
        "stem": "Ein Freund möchte sich im Inline-Skaten perfektionieren."
      },
      {
        "num": 13,
        "answer": "j",
        "stem": "Ein Kollege möchte sich über Gesundheitsrisiken in Ägypten informieren."
      },
      {
        "num": 14,
        "answer": "x",
        "stem": "Eine Bekannte möchte einen Kurs über Naturkosmetik besuchen."
      },
      {
        "num": 15,
        "answer": "f",
        "stem": "Eine 17-jährige Freundin würde gerne armen Menschen in anderen Ländern helfen."
      },
      {
        "num": 16,
        "answer": "i",
        "stem": "Ihr Nachbar möchte sich im Sommerurlaub sportlich betätigen."
      },
      {
        "num": 17,
        "answer": "h",
        "stem": "Ihre Freundin möchte gerne bei der Organisation einer Inline-Skate-Veranstaltung mitwirken."
      },
      {
        "num": 18,
        "answer": "g",
        "stem": "Sie möchten das Inline-Skaten erlernen und suchen Informationen."
      },
      {
        "num": 19,
        "answer": "c",
        "stem": "Sie möchten herausfinden, wo es in Deutschland Skate- Veranstaltungen gibt."
      },
      {
        "num": 20,
        "answer": "e",
        "stem": "Sie müssen kurzfristig für Ihren Chef Reisepapiere für Ägypten besorgen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Auf dem Göta-Kanal sind drei histor ische Schiffe unterwegs: „Juno“, „Wilhelm Tham“ und „Diana“. Die um die Jahrhundertwende gebauten Dampfer sind restauriert und auf umgerüstet. Unterkunft an Bord: in Doppelkabinen mit Etagen-betten, Dusche und WC. Reiseverlauf: Reiseantritt in Stockholm oder Göteborg. Aktivitäten: tägliche Ausflüge zu verschie-denen Sehenswürdigkeiten, Spaziergänge auf dem Treidelweg, baden, lesen, Karten spielen, die Stim-mung an Deck genießen. Reisetermine: von Mai bis September. Wer in Göteborg oder Stockholm b leiben will, kann weitere Übernachtungen buchen. Weitere Infos: Schweden-Werbung, Lilienstr. 19, D-20095 Hamburg, Tel. 040 / 32 55 13 55. Web: www.gotacanal.se (Reederei)."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Skating für Fortgeschrittene Können Sie bremsen? Oder nur wenn ein Verkehrsschild oder eine Ampel in der Nähe ist? Vielleicht ist ein Wochenend- Kurs beim Starnberger Rollschuh-Club genau das Richtige für Sie. Trainer vermitteln effektives Gleiten, Brem-sen, Kurvenfahren, Fallen – alles für fortge-schrittene Skater, die ihre Technik verbes-sern wollen. Dazu: neueste Skate-Modelle zum Üben: Fr 17 Uhr bis So 19 Uhr, Ü/F, ab 160 Euro, Infos: 0800 / 100 88 00 (Ortstarif)."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Skater gelten verkehrsrechtlich als Fußgänger und dürfen eigentlich nur auf Gehwegen oder in verkehrsberuhigten Zonen fahren. Gar nicht einfach, eine schöne, freie Piste auf glattem Asphalt zu finden! In unseren Reiseführern für Skater stellen wir ausgewählte Strecken für Touren vor: in verschiedenen Großstädten und Regionen in Deutschland, von der kleinen Abend- bis zur großen Tagestour. (Klartext Verlag Essen, ab ca. 7 Euro im Buchhandel). Wichtige Infos zu Skate-Hallen und -Bahnen, Veranstaltun-gen, zu regelmäßigen Inline- Treffpunkten von Flensburg bis Passau enthält der „ActionGuide Inline-Skating“ (BLV Verlag, 14,80 Euro)."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "LAUFEN FÜR DIE FORSCHUNG Straßenlauf in Frankfurt am Main: Alle Teilnehmer haben ihren Sponsor; das Geld stiften sie für Aufklärung und Forschung zum Thema Brustkrebs. Gestartet wird am 13. August um zehn Uhr morgens am Frankfurter Römer. Die Idee für diese Aktion stammt aus den USA: Dort organi-siert die „Breast Cancer Foundation“ seit fast 20 Jahren solche gesponserten Läufe. Wer mitlaufen und/oder sponsern will, kann sich per E-Mail anmelden. Info: Race for the Cure E-Mail: raceforthecure@arcormail.de www. raceforthecure.de"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Euro). Russland, China, Kamerun, Venezuela – er binnen weniger Tage in ein Land jenseits der EU-Grenzen aufbrechen muss, verliert eine Menge Zeit bei der Beschaffung von Einreisepa-pieren. Inzwischen holen Agenturen die Visa kurzfristig ein, überbringen sie persönlich oder hinterlegen sie am Flughafen. So geht’s: Sie las-sen sich vom Visumservice beraten, füllen einen Antrag aus, die Unterlagen werden überprüft und beim zuständigen Konsulat eingereicht. Kosten für ein Visum innerhalb von fünf Arbeits-tagen: 85 Euro; 24-Stunden-Service: 140 Euro. Infos: Tel. 069/69 07 22 32, www.visumservice.de 9102 ,2B hcstueD clet ,.M .a trufknarF ,HbmGg clet"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "MÖWE E. V. – Kinder- und Jugendfreizeiten Wir bieten: Campen, Kanufahren, Wandern, Klettern, Geländespiele usw. • Für Kinder und Jugendliche zwischen 7 und 18 Jahren. Alle Aktivitäten werden von erfahrenen Pädagogen betreut und begleitet! Elternbegleitung möglich. • Integrativer Ansatz: auch für Kinder und Jugendliche mit erhöhtem Betreuungsbedarf. • Jetzt neu: Auslandsreisen zu Hilfsprojekten in anderen Ländern (mit sozialer Tätigkeit, z. B. Hilfe in Schulen o. Ä.) – Reisen, Lernen, Gutes tun! Für Jugendliche ab D15-7 J2a6h4re9n W. olfschlugen Telefon: 0800 / 5959219 WE-eMitaeirle: Infos: Möwe e. V., Esslingers tr. 7, Petra. Schrei@moewe.eu"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Sie wollen bald zu Ihrer ersten Inliner-Tour starten? Anfänger sollten die wichtigsten Techniken (beim Gleiten, Bremsen und Fallen) vorher üben und Körperhaltung und Balance trainieren. Infos zu Kursen gibt es beim Deutschen Inline-Skate-Verband. Auch Sportartikelfirmen bieten Kurse an, z. B. das mobile „K2 Skate College“ in ca. 100 deutschen Städten (Tel. 0190 / 57 55 55; 2 Stunden 25 Euro). In kleinen Gruppen lernen Sie die richtige Technik beim Gleiten, Bremsen und Fallen, trainieren Körperhaltung und Balance. Skate-Unterricht für Einsteiger gibt es auch per Video (z. B. GoInline!; ca. 15 Euro, in Buch- und Sportg eschäften) oder als Buch (z. B. Richtig Inline-Skaten, BLV Verlag, 9,90 Euro)."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "MAINZ. Für die Skate Nights vom 5. bis 9. August sucht die Stadt Mainz Helfer. Engagierte Skater werden benötigt, die Skating-Regeln erklären oder bei der Verkehrsregelung helfen. An allen Tagen dürfen Skater von 20.30 bis 22.30 Uhr durch die Innenstadt fahren – auf einem Rundkurs über Hauptstraßen und den Markt. Anmeldung für die Helfer und Inline-Skater beim Sportamt der Stadt Mainz, Tel.: 06131-12 43 21."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Bäche, Seen, Wälder und Wiesen Für Feriengenießer haben wir viel zu bieten: herrliche Natur, ein bisschen Luxus, komfortable Zimmer und Suiten, gemütliche Restaurants mit dem Besten aus Küche und Keller. Und dazu ein großes Angebot für alle, die im Urlaub aktiv werden wollen: geführte Wanderungen im Tannheimer Tal, Radeln, Mountainbiken, Surfen, Bootsfahrten und Baden am klaren Haldensee, Tennisspielen und dann Relaxen im Wellness-Bereich – Entspannung pur! Schöner kann Urlaub nicht sein! Hotel Waldruhe, A-6673 Haldensee, Bergweg 12, Tel.: 0043-56 75 31 62; E-Mail: hoteltyrol@netway.at"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Reisetipps Wichtige Hinweise für Ihre Reise nach Ägypten. Sicherheit: Die Hauptattraktionen des Landes werden bewacht. Verhalten Sie sich respektvoll dem kulturellen Erbe und den Einheimischen gegenüber. Passen Sie Ihre Kleidung wie bei jeder Reise den Gepflogenheiten des Landes an. Gesundheit: Wasser, auch zum Zähneputzen, sollten Sie nur aus verschlossenen Flaschen benutzen. Welche Impfung nötig ist, erfahren Sie am Impftelefon: 0 40 / 42 81 88 00. Beste Reisezeit: Oktober bis April. Touren: Alle großen deutschen Veranstalter bieten auch Rundreisen sowie Kreuzfahrten auf dem Nil an. Weitere Informationen finden Sie im Internet unter www.reise-tipps.eu."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "LAGO DI CHIUSI: EINFACH HERRLICH Früher schnitt man hier das Rohr für die Florentinerhüte, heute ist der winzige, von grünen Wiesen umgebene See an der Grenze zu Latium ein Geheimtipp für Liebhaber der Gemächlichkeit. Zeitloses Italien: ein windschiefer Holzsteg, morsche bunte Boote, ein paar Angler, ein paar Enten auf sattem Grün und der würzige Geruch von Seefischen, die „alla etrusca“ über Schilf gebraten werden. Zum Beispiel bei Gino: Filets von Forelle, Felchen und Hecht, ein paar Spritzer Olivenöl und Zitronensaft. Buon appetito!"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "KRÄUTERCREME UND ÖKO-SEI FE Viele Beauty-Produkte schmücken sich mit dem Begriff „Naturkosmetik“. Bisher gab es dafür keine festen Prüf kriterien, doch jetzt kommt das Gütezeichen „Kontrollierte Natur-Kosmetik BDHI“, das vom Bundesverband Deutscher Industrie- und Handelsunternehmen (BDHI) vergeben wird. Damit können Sie sicher sein: Wo Natur draufsteht, ist auch Natur drin. Infos gibt’s beim BDHI unter: Telefon 06 21/1 29 43 30."
        ]
      }
    ]
  },
  {
    "id": "29a",
    "title": "Inline-Skaten und Auslandsreisen",
    "sourcePage": 318,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11. Ihre Freundin möchte gerne bei der Organisation einer Inline-Skate-Veranstaltung mitwirken. 12. Eine 17-jährige Freundin würde gerne in Afrika armen Menschen helfen. 13. Sie möchten das Inline-Skaten erlernen und suchen Informationen. 14. Ein Freund möchte sich im Inline-Skaten perfektionieren. 15. Sie möchten herausfinden, wo es in Deutschland Skate-Veranstaltungen gibt. 16. Eine Bekannte möchte einen Kurs über Naturkosmetik besuchen. 17. Ihr Nachbar möchte sich im Sommerurlaub sportlich betätigen. 18. Ein Bekannter möchte Schweden per Schiff kennen lernen. 19. Ein Kollege möchte sich über Gesundheitsrisiken in Ägypten informieren. 20. Sie müssen kurzfristig für Ihren Chef die Papiere für Ägypten besorgen.",
    "questions": [
      {
        "num": 11,
        "answer": "h",
        "stem": "Ihre Freundin möchte gerne bei der Organisation einer Inline-Skate-Veranstaltung mitwirken."
      },
      {
        "num": 12,
        "answer": "f",
        "stem": "Eine 17-jährige Freundin würde gerne in Afrika armen Menschen helfen."
      },
      {
        "num": 13,
        "answer": "g",
        "stem": "Sie möchten das Inline-Skaten erlernen und suchen Informationen."
      },
      {
        "num": 14,
        "answer": "b",
        "stem": "Ein Freund möchte sich im Inline-Skaten perfektionieren."
      },
      {
        "num": 15,
        "answer": "c",
        "stem": "Sie möchten herausfinden, wo es in Deutschland Skate-Veranstaltungen gibt."
      },
      {
        "num": 16,
        "answer": "x",
        "stem": "Eine Bekannte möchte einen Kurs über Naturkosmetik besuchen."
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "Ihr Nachbar möchte sich im Sommerurlaub sportlich betätigen."
      },
      {
        "num": 18,
        "answer": "a",
        "stem": "Ein Bekannter möchte Schweden per Schiff kennen lernen."
      },
      {
        "num": 19,
        "answer": "j",
        "stem": "Ein Kollege möchte sich über Gesundheitsrisiken in Ägypten informieren."
      },
      {
        "num": 20,
        "answer": "e",
        "stem": "Sie müssen kurzfristig für Ihren Chef die Papiere für Ägypten besorgen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Auf dem Göta-Kanal sind drei histor ische Schiffe unterwegs: „Juno“, „Wilhelm Tham“ und „Diana“. Die um die Jahrhundertwende gebauten Dampfer sind restauriert und auf umgerüstet. Unterkunft an Bord: in Doppelkabinen mit Etagen-betten, Dusche und WC. Reiseverlauf: Reiseantritt in Stockholm oder Göteborg. Aktivitäten: tägliche Ausflüge zu verschie-denen Sehenswürdigkeiten, Spaziergänge auf dem Treidelweg, baden, lesen, Karten spielen, die Stim-mung an Deck genießen. Reisetermine: von Mai bis September. Wer in Göteborg oder Stockholm b leiben will, kann weitere Übernachtungen buchen. Weitere Infos: Schweden-Werbung, Lilienstr. 19, D-20095 Hamburg, Tel. 040 / 32 55 13 55. Web: www.gotacanal.se (Reederei)."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Skating für Fortgeschrittene Können Sie bremsen? Oder nur wenn ein Verkehrsschild oder eine Ampel in der Nähe ist? Vielleicht ist ein Wochenend- Kurs beim Starnberger Rollschuh-Club genau das Richtige für Sie. Trainer vermitteln effektives Gleiten, Brem-sen, Kurvenfahren, Fallen – alles für fortge-schrittene Skater, die ihre Technik verbes-sern wollen. Dazu: neueste Skate-Modelle zum Üben: Fr 17 Uhr bis So 19 Uhr, Ü/F, ab 160 Euro, Infos: 0800 / 100 88 00 (Ortstarif)."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Skater gelten verkehrsrechtlich als Fußgänger und dürfen eigentlich nur auf Gehwegen oder in verkehrsberuhigten Zonen fahren. Gar nicht einfach, eine schöne, freie Piste auf glattem Asphalt zu finden! In unseren Reiseführern für Skater stellen wir ausgewählte Strecken für Touren vor: in verschiedenen Großstädten und Regionen in Deutschland, von der kleinen Abend- bis zur großen Tagestour. (Klartext Verlag Essen, ab ca. 7 Euro im Buchhandel). Wichtige Infos zu Skate-Hallen und -Bahnen, Veranstaltun-gen, zu regelmäßigen Inline- Treffpunkten von Flensburg bis Passau enthält der „ActionGuide Inline-Skating“ (BLV Verlag, 14,80 Euro)."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "LAUFEN FÜR DIE FORSCHUNG Straßenlauf in Frankfurt am Main: Alle Teilnehmer haben ihren Sponsor; das Geld stiften sie für Aufklärung und Forschung zum Thema Brustkrebs. Gestartet wird am 13. August um zehn Uhr morgens am Frankfurter Römer. Die Idee für diese Aktion stammt aus den USA: Dort organi-siert die „Breast Cancer Foundation“ seit fast 20 Jahren solche gesponserten Läufe. Wer mitlaufen und/oder sponsern will, kann sich per E-Mail anmelden. Info: Race for the Cure E-Mail: raceforthecure@arcormail.de www. raceforthecure.de"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Euro). Russland, China, Kamerun, Venezuela – er binnen weniger Tage in ein Land jenseits der EU-Grenzen aufbrechen muss, verliert eine Menge Zeit bei der Beschaffung von Einreisepa-pieren. Inzwischen holen Agenturen die Visa kurzfristig ein, überbringen sie persönlich oder hinterlegen sie am Flughafen. So geht’s: Sie las-sen sich vom Visumservice beraten, füllen einen Antrag aus, die Unterlagen werden überprüft und beim zuständigen Konsulat eingereicht. Kosten für ein Visum innerhalb von fünf Arbeits-tagen: 85 Euro; 24-Stunden-Service: 140 Euro. Infos: Tel. 069/69 07 22 32, www.visumservice.de 9102 ,2B hcstueD clet ,.M .a trufknarF ,HbmGg clet"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "MÖWE E. V. – Kinder- und Jugendfreizeiten Wir bieten: Campen, Kanufahren, Wandern, Klettern, Geländespiele usw. • Für Kinder und Jugendliche zwischen 7 und 18 Jahren. Alle Aktivitäten werden von erfahrenen Pädagogen betreut und begleitet! Elternbegleitung möglich. • Integrativer Ansatz: auch für Kinder und Jugendliche mit erhöhtem Betreuungsbedarf. • Jetzt neu: Auslandsreisen zu Hilfsprojekten in anderen Ländern (mit sozialer Tätigkeit, z. B. Hilfe in Schulen o. Ä.) – Reisen, Lernen, Gutes tun! Für Jugendliche ab D15-7 J2a6h4re9n W. olfschlugen Telefon: 0800 / 5959219 WE-eMitaeirle: Infos: Möwe e. V., Esslingers tr. 7, Petra. Schrei@moewe.eu"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Sie wollen bald zu Ihrer ersten Inliner-Tour starten? Anfänger sollten die wichtigsten Techniken (beim Gleiten, Bremsen und Fallen) vorher üben und Körperhaltung und Balance trainieren. Infos zu Kursen gibt es beim Deutschen Inline-Skate-Verband. Auch Sportartikelfirmen bieten Kurse an, z. B. das mobile „K2 Skate College“ in ca. 100 deutschen Städten (Tel. 0190 / 57 55 55; 2 Stunden 25 Euro). In kleinen Gruppen lernen Sie die richtige Technik beim Gleiten, Bremsen und Fallen, trainieren Körperhaltung und Balance. Skate-Unterricht für Einsteiger gibt es auch per Video (z. B. GoInline!; ca. 15 Euro, in Buch- und Sportg eschäften) oder als Buch (z. B. Richtig Inline-Skaten, BLV Verlag, 9,90 Euro)."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "MAINZ. Für die Skate Nights vom 5. bis 9. August sucht die Stadt Mainz Helfer. Engagierte Skater werden benötigt, die Skating-Regeln erklären oder bei der Verkehrsregelung helfen. An allen Tagen dürfen Skater von 20.30 bis 22.30 Uhr durch die Innenstadt fahren – auf einem Rundkurs über Hauptstraßen und den Markt. Anmeldung für die Helfer und Inline-Skater beim Sportamt der Stadt Mainz, Tel.: 06131-12 43 21."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Bäche, Seen, Wälder und Wiesen Für Feriengenießer haben wir viel zu bieten: herrliche Natur, ein bisschen Luxus, komfortable Zimmer und Suiten, gemütliche Restaurants mit dem Besten aus Küche und Keller. Und dazu ein großes Angebot für alle, die im Urlaub aktiv werden wollen: geführte Wanderungen im Tannheimer Tal, Radeln, Mountainbiken, Surfen, Bootsfahrten und Baden am klaren Haldensee, Tennisspielen und dann Relaxen im Wellness-Bereich – Entspannung pur! Schöner kann Urlaub nicht sein! Hotel Waldruhe, A-6673 Haldensee, Bergweg 12, Tel.: 0043-56 75 31 62; E-Mail: hoteltyrol@netway.at"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Reisetipps Wichtige Hinweise für Ihre Reise nach Ägypten. Sicherheit: Die Hauptattraktionen des Landes werden bewacht. Verhalten Sie sich respektvoll dem kulturellen Erbe und den Einheimischen gegenüber. Passen Sie Ihre Kleidung wie bei jeder Reise den Gepflogenheiten des Landes an. Gesundheit: Wasser, auch zum Zähneputzen, sollten Sie nur aus verschlossenen Flaschen benutzen. Welche Impfung nötig ist, erfahren Sie am Impftelefon: 0 40 / 42 81 88 00. Beste Reisezeit: Oktober bis April. Touren: Alle großen deutschen Veranstalter bieten auch Rundreisen sowie Kreuzfahrten auf dem Nil an. Weitere Informationen finden Sie im Internet unter www.reise-tipps.eu."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "LAGO DI CHIUSI: EINFACH HERRLICH Früher schnitt man hier das Rohr für die Florentinerhüte, heute ist der winzige, von grünen Wiesen umgebene See an der Grenze zu Latium ein Geheimtipp für Liebhaber der Gemächlichkeit. Zeitloses Italien: ein windschiefer Holzsteg, morsche bunte Boote, ein paar Angler, ein paar Enten auf sattem Grün und der würzige Geruch von Seefischen, die „alla etrusca“ über Schilf gebraten werden. Zum Beispiel bei Gino: Filets von Forelle, Felchen und Hecht, ein paar Spritzer Olivenöl und Zitronensaft. Buon appetito!"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "KRÄUTERCREME UND ÖKO-SEI FE Viele Beauty-Produkte schmücken sich mit dem Begriff „Naturkosmetik“. Bisher gab es dafür keine festen Prüf kriterien, doch jetzt kommt das Gütezeichen „Kontrollierte Natur-Kosmetik BDHI“, das vom Bundesverband Deutscher Industrie- und Handelsunternehmen (BDHI) vergeben wird. Damit können Sie sicher sein: Wo Natur draufsteht, ist auch Natur drin. Infos gibt’s beim BDHI unter: Telefon 06 21/1 29 43 30."
        ]
      }
    ]
  },
  {
    "id": "30",
    "title": "Bücher, Schreiben und Vorträge",
    "sourcePage": 319,
    "keywords": "Lesen Sie zuerst die Situationen (11-20) und dann die zwölf Texte (a-l). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben 11-20. Manchmal gibt es keine Lösung. Markieren Sie dann x. Eine Bekannte interessiert sich dafür, wie Romane entstehen. Ein Bekannter hat Schwierigkeiten, seine Ideen geordnet und gezielt in Eine Freundin sucht ein Buch zum Thema Energie. Ein Freund möchte lernen, schwierige Aufgaben sofort zu erledigen. Eine Bekannte möchte für ihre Arbeit lernen, gute Vorträge ohne Eine Bekannte möchte die orthografischen Regeln (Rechtschreibung) der deutschen Sprache beherrschen. Ein Bekannter möchte seine Termine endlich besser organisieren. Eine Freundin möchte lernen, bessere Geschäftsbriefe zu schreiben. Ein Freund sucht ein Buch zum Thema Partnerschaft. Ein Bekannter hat viel Stress. Konzentrationsübungen entspannen lernen. Aufgabe 11 12 13 14 15 16 17 18 19 20 Prüfungsvorbereitung B2 Stephan Sutor a Frieder Höft, Denken in Strukturen Heutzutage finden im Berufs- wie im Privatleben ständig Verhandlungen statt. Jeder Verhandlungspartner möchte sich gegen den anderen durchsetzen. Denken in Strukturen eröffnet Ihnen die Möglichkeit zu lernen, mit Ideen und Argumenten systematisch zu überzeugen. Verhandlungspartners in das eigene Schema aufzugreifen und gewinnbringend auszunutzen. Denken in Strukturen macht Sie in Verhandlungen unschlagbar und Dr. Christine Freitag, Nur Mut! Entspannungs-CD. Wird Ihnen angst und bange, wenn Sie vor vielen Leuten stehen und einen Vortrag halten müssen? Wollen Sie diese Situation ändern? Nur Mut! hilft Ihnen durch sein Selbsthilfe-Trainingsprogramm, Ihre Unsicherheit zu überwinden und mit den Mitteln des autogenen Trainings Ihre blockierten Fähigkeiten freizusetzen. Finden Sie zu innerer Gelassenheit und damit zu beruflichem Erfolg und Anerkennung. c Gerhard Mumbächer, Formulieren mit d Prof. Dr. med. Udo Kurz, Autogenes Tagtäglich kommt es im Schriftverkehr zu Dieser Ratgeber stellt Ihnen die uralte ostasiatische Technik der Informationslücken. Diese führen nicht konzentrativen Selbstentspannung selten zu negativen Folgen im vor. In mehreren Schritten lernen Sie, Geschäftsleben. Das Verfassen von zu mehr Ruhe und Gelassenheit im Geschäftsbriefen, Mails und Alltag zu gelangen. Sie trainieren Informationstexten lässt sich nur mit handwerklichem Können meistern. Dieses praxisorientierte Trainingsbuch hilft Ihnen, die Regeln und Techniken dieses Handwerks zu erlernen und erfolgreich e Arno Baumann, Zeitmanagement Termine, Telefon, unvorhergesehene Ereignisse erzeugen nicht unerheblichen Stress im Arbeitsleben. Durch eine bessere Strukturierung der Zeit, das Setzen von Prioritäten und die Fähigkeit, zwischen Wichtigem und Unwichtigem zu unterscheiden, bekommen Stressgeplagte ihren Zeitplan wieder in den Griff und können sich wieder auf die Aufgaben konzentrieren, die für sie am wichtigsten sind. Mit praktischem Trainingsteil. Prüfungsvorbereitung B2 Stephan Sutor abzuschalten und sich zu erholen, um daraus neue Kraft zu schöpfen. Das Programm führ Sie durch Übungen zur Ruhe, Schwere, Wärme und Atmung. Körper und Seele werden wieder eine Einheit. Inklusive Doppel-CD mit angeleiteten Entspannungsübungen. f Prof. Dr. Ernst Desselmann, Bausteine Dieses Buch zeigt die Bausteine, aus denen Literaten ihre Werke zusammenbauen. Wodurch erzeugen sie Spannung? Wodurch Ironie? Welche Bausteine machen aus einem literarischen Werk große Literatur? Diesen Fragen geht Prof. Desselmann auf leicht verständliche und humorvolle Weise nach und führt so in g Karin Nobel-Struck, Die neue Daß oder dass, Filosofie oder Philosophie, Gemse oder Gämse? Jahre nach der Einführung der neuen Rechtschreibung sind viele noch unsicher, wie sie jetzt richtigschreiben. Dieses Handbuch bietet Ihnen zum Nachschlagen die amtliche Wortliste zur neuen Rechtschreibung und einen ausführlichen Regelteil mit praktischen Übungen zu Orthografie und h Lothar Zimmermann, Wie eine In dem neusten Buch von Lothar Zimmermann erfahren Sie, wie schon vom Kindesalter an durch die Informationen, die wir von Eltern, Erziehern oder in der Schule präsentiert bekommen, Meinungen gebildet werden. Meinungen, die oft unbewusst das ganze Leben eines Menschen begleiten oder sogar bestimmen können. Das Buch befasst sich auch mit dem Erkennen festgefahrener Meinungsstrukturen und damit, wie man Meinungen ändern kann. Bestellnr. YM 738962 i Hans Schneider, Gespräche mit j Ursula Pieck, Lebensenergie gegen Menschen führen heißt mit Lebensenergie gibt Kraft und hält gesund. Menschensprechen. Mit diesem Kernsatz zeigt Stress nimmt uns Kraft und macht krank. Hans Schneider, wie wichtig eine gute Mit Hilfe der Kinesiologie werden Gesprächsführung für das Gelingen einer Stressoren aufgespürt und durch guten Zusammenarbeit ist. Anhand von wirksame Übungen beseitigt. Das Buch praktischen Beispielen führt er vor, wie besteht aus einem Theorie- und einem unstrukturiertes Reden Missverständnisse Übungsteil. Im Theorieteil werden Sie in erzeugt, die negative Auswirkungen auf die Arbeitsatmosphäre haben können. Im Praxisteil zeigt Hans Schneider Wege zu einem partnerschaftlichen Gesprächsstil auf, von dem alle Seiten profitieren. k Irmgard Pudel, Weg mit dem inneren Gehören Sie auch zu denen, die unangenehme Dinge lieber später erledigen als sofort? Dann haben Sie auch einen inneren Schweinehund, den Sie überwinden müssen. Wie Sie das schaffen können und wieder frei werden für das, was Ihnen Spaß macht, wie Sie mit Unangenehmem schnell und zielgerichtet fertig werden, das beschreibt Irmgard Pudel in Prüfungsvorbereitung B2 Stephan Sutor das Wesen der Kinesiologie eingeführt. Im Übungsteil finden Sie sofort einsetzbare Verspannungen gelockert und wieder Harmonie zwischen Geist und Körper l Hildegard Schrammel-Hochhuth, Frauen benutzen oft unbewusst eine andere Sprache als Männer. Das führt im Privat- und im Berufsleben oft zu Missverständnissen und Streit. Hildegard Schrammel-Hochhuth hat die „Frauensprache\" analysiert und zeigt anhand von Beispielen, wie sich das Denken und das Reden von Männern und Frauen unterscheiden. Wie Frauen Ihre „Frauensprache\" gezielt einsetzen können, um erfolgreich durch das Berufs- und Privatleben zu kommen, schildert die Autorin leicht verständlich und mit viel",
    "questions": [
      {
        "num": 11,
        "answer": "f",
        "stem": "Eine Bekannte interessiert sich dafür, wie Romane entstehen."
      },
      {
        "num": 12,
        "answer": "a",
        "stem": "Ein Bekannter hat Schwierigkeiten, seine Ideen geordnet und gezielt in Gespräche einzubringen."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Eine Freundin sucht ein Buch zum Thema Energie."
      },
      {
        "num": 14,
        "answer": "k",
        "stem": "Ein Freund möchte lernen, schwierige Aufgaben sofort zu erledigen."
      },
      {
        "num": 15,
        "answer": "b",
        "stem": "Eine Bekannte möchte für ihre Arbeit lernen, gute Vorträge ohne Nervosität zu halten."
      },
      {
        "num": 16,
        "answer": "g",
        "stem": "Eine Bekannte möchte die orthografischen Regeln (Rechtschreibung) der deutschen Sprache beherrschen."
      },
      {
        "num": 17,
        "answer": "e",
        "stem": "Ein Bekannter möchte seine Termine endlich besser organisieren."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "Eine Freundin möchte lernen, bessere Geschäftsbriefe zu schreiben."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Ein Freund sucht ein Buch zum Thema Partnerschaft."
      },
      {
        "num": 20,
        "answer": "d",
        "stem": "Ein Bekannter hat viel Stress. Er möchte sich mit Konzentrationsübungen entspannen lernen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "a Frieder Höft, Denken in Strukturen b Heutzutage finden im Berufs- wie im Privatleben ständig Verhandlungen statt. Jeder Verhandlungspartner möchte sich gegen den anderen durchsetzen. Denken in Strukturen eröffnet Ihnen die Möglichkeit zu lernen, mit Ideen und Argumenten systematisch zu überzeugen. Gegenargumente des Verhandlungspartners in das eigene Schema aufzugreifen und gewinnbringend auszunutzen. Denken in Strukturen macht Sie in Verhandlungen unschlagbar und erfolgreich. Bestellnr. XS 335703"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "B2 b Dr. Christine Freitag, Nur Mut! Ein Trainingsprogramm zum angstfreien Sprechen mit Entspannungs-CD. Wird Ihnen angst und bange, wenn Sie vor vielen Leuten stehen und einen Vortrag halten müssen? Wollen Sie diese Situation ändern? Nur Mut! hilft Ihnen durch sein Selbsthilfe-Trainingsprogramm, Ihre Unsicherheit zu überwinden und mit den Mitteln des autogenen Trainings Ihre blockierten Fähigkeiten freizusetzen. Finden Sie zu innerer Gelassenheit und damit zu beruflichem Erfolg und Anerkennung. Bestellnr. XR 831112"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "c Gerhard Mumbächer, Formulieren mit d Wirkung Tagtäglich kommt es im Schriftverkehr zu Missverständnissen und Informationslücken. Diese führen nicht selten zu negativen Folgen im Geschäftsleben. Das Verfassen von Geschäftsbriefen, Mails und Informationstexten lässt sich nur mit handwerklichem Können meistern. Dieses praxisorientierte Trainingsbuch hilft Ihnen, die Regeln und Techniken dieses Handwerks zu erlernen und erfolgreich einzusetzen. Bestellnr. XX 952447"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Bestellnr. XR 831112 d Prof. Dr. med. Udo Kurz, Autogenes Training Dieser Ratgeber stellt Ihnen die uralte ostasiatische Technik der konzentrativen Selbstentspannung vor. In mehreren Schritten lernen Sie, zu mehr Ruhe und Gelassenheit im Alltag zu gelangen. Sie trainieren abzuschalten und sich zu erholen, um daraus neue Kraft zu schöpfen. Das Programm führ Sie durch Übungen zur Ruhe, Schwere, Wärme und Atmung. Körper und Seele werden wieder eine Einheit. Inklusive Doppel-CD mit angeleiteten Entspannungsübungen. Bestellnr. XA 665000"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "e Arno Baumann, Zeitmanagement f Termine, Telefon, unvorhergesehene Ereignisse erzeugen nicht unerheblichen Stress im Arbeitsleben. Durch eine bessere Strukturierung der Zeit, das Setzen von Prioritäten und die Fähigkeit, zwischen Wichtigem und Unwichtigem zu unterscheiden, bekommen Stressgeplagte ihren Zeitplan wieder in den Griff und können sich wieder auf die Aufgaben konzentrieren, die für sie am wichtigsten sind. Mit praktischem Trainingsteil. Bestellnr. XZ 639812"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "f Prof. Dr. Ernst Desselmann, Bausteine des Erzählens Dieses Buch zeigt die Bausteine, aus denen Literaten ihre Werke zusammenbauen. Wodurch erzeugen sie Spannung? Wodurch Ironie? Welche Bausteine machen aus einem literarischen Werk große Literatur? Diesen Fragen geht Prof. Desselmann auf leicht verständliche und humorvolle Weise nach und führt so in die Geheimnisse der Literaturschöpfung ein. Bestellnr. XL 535352"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "g Karin Nobel-Struck, Die neue h Rechtschreibung Daß oder dass, Filosofie oder Philosophie, Gemse oder Gämse? Jahre nach der Einführung der neuen Rechtschreibung sind viele noch unsicher, wie sie jetzt richtigschreiben. Dieses Handbuch bietet Ihnen zum Nachschlagen die amtliche Wortliste zur neuen Rechtschreibung und einen ausführlichen Regelteil mit praktischen Übungen zu Orthografie und Zeichensetzung. Bestellnr. XR 081500"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "B2 h Lothar Zimmermann, Wie eine Meinung entsteht In dem neusten Buch von Lothar Zimmermann erfahren Sie, wie schon vom Kindesalter an durch die Informationen, die wir von Eltern, Erziehern oder in der Schule präsentiert bekommen, Meinungen gebildet werden. Meinungen, die oft unbewusst das ganze Leben eines Menschen begleiten oder sogar bestimmen können. Das Buch befasst sich auch mit dem Erkennen festgefahrener Meinungsstrukturen und damit, wie man Meinungen ändern kann. Bestellnr. YM 738962"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "i Hans Schneider, Gespräche mit j Mitarbeitern Menschen führen heißt mit Menschensprechen. Mit diesem Kernsatz zeigt Hans Schneider, wie wichtig eine gute Gesprächsführung für das Gelingen einer guten Zusammenarbeit ist. Anhand von praktischen Beispielen führt er vor, wie unstrukturiertes Reden Missverständnisse erzeugt, die negative Auswirkungen auf die Arbeitsatmosphäre haben können. Im Praxisteil zeigt Hans Schneider Wege zu einem partnerschaftlichen Gesprächsstil auf, von dem alle Seiten profitieren. Bestellnr. YS 733965"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "j Ursula Pieck, Lebensenergie gegen Stress Lebensenergie gibt Kraft und hält gesund. Stress nimmt uns Kraft und macht krank. Mit Hilfe der Kinesiologie werden Stressoren aufgespürt und durch wirksame Übungen beseitigt. Das Buch besteht aus einem Theorie- und einem Übungsteil. Im Theorieteil werden Sie in das Wesen der Kinesiologie eingeführt. Im Übungsteil finden Sie sofort einsetzbare Körperübungen, mit denen Verspannungen gelockert und wieder Harmonie zwischen Geist und Körper hergestellt wird. Bestellnr. XS 123009"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "k Irmgard Pudel, Weg mit dem inneren l Schweinehund Gehören Sie auch zu denen, die unangenehme Dinge lieber später erledigen als sofort? Dann haben Sie auch einen inneren Schweinehund, den Sie überwinden müssen. Wie Sie das schaffen können und wieder frei werden für das, was Ihnen Spaß macht, wie Sie mit Unangenehmem schnell und zielgerichtet fertig werden, das beschreibt Irmgard Pudel in ihrem neuen Bestseller. Bestellnr. XS 339001"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "l Hildegard Schrammel-Hochhuth, Wenn Frauen sprechen Frauen benutzen oft unbewusst eine andere Sprache als Männer. Das führt im Privat- und im Berufsleben oft zu Missverständnissen und Streit. Hildegard Schrammel-Hochhuth hat die „Frauensprache\" analysiert und zeigt anhand von Beispielen, wie sich das Denken und das Reden von Männern und Frauen unterscheiden. Wie Frauen Ihre „Frauensprache\" gezielt einsetzen können, um erfolgreich durch das Berufsund Privatleben zu kommen, schildert die Autorin leicht verständlich und mit viel Humor. Bestellnr. YF 007007"
        ]
      }
    ]
  },
  {
    "id": "31",
    "title": "Finanzen, Familie und soziale Netzwerke",
    "sourcePage": 322,
    "keywords": "Übungstest telc Deutsch B2 L esen Sie zuerst die zehn Situationen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Sie möchten lernen, Ihre Firma in sozialen Netzwerken vielseitig zu präsentieren. 12 Ein Bekannter möchte zusammen mit seinem vierjährigen Sohn etwas Kreatives machen. 13 Ihr 22-jähriger Nachbar will jederzeit wissen, wie viel Geld er noch zur Verfügung hat. 14 Sie möchten herausfinden, welche Bank die beste für Sie ist. 15 Eine Freundin von Ihnen möchte ihr Hobby zum Beruf machen. Sie möchten praktische Tipps, wie man den Alltag mit Kindern meistert. Ein Bekannter hat eine Ausbildung zum Altenpfleger gemacht und sucht einen Job. Ihre Freundin möchte etwas darüber lesen, wie man langfristig Geld ansparen kann. Ihre Nachbarin, eine junge Mutter, möchte die Entwicklung ihres Babys fördern. Ihr Cousin möchte ein paar Tipps, wie er seinen Kindern den Umgang mit Geld beibringen kann. Neue berufliche Perspektiven Sie machen leidenschaftlich gern Musik? Es macht Ihnen Freude, Kinderkleidung zu nähen oder leckere Marmeladen herzustellen? Vielleicht fotografieren Sie auch gerne oder sind handwerk- lich geschickt? Was immer es auch sein mag: Wäre es nicht schön, wenn Sie mit dem, was Sie in Ihrer Freizeit gerne tun, Ihr Geld verdienen könn- ten? Wir stellen Ihnen in unserem Tagesseminar einen Fünf-Schritte-Plan vor, der Ihnen dabei hilft, diesen Traum in die Realität umzusetzen. Das Seminar findet jeweils am ersten Samstag im Monat in der Volkshochschule statt und kostet 130 Euro. Anmeldung: 0180-775 30 07. Die meisten Menschen kümmern sich wenig bis gar nicht um finan- zielle Fragen. Das führt dazu, dass Aufgepasst! Am Samstag können Väter mit ihren sie oft weniger Geld in Tasche Kindern toben und jede Menge Spaß haben. Von haben, als sie eigentlich müss- 14 bis 18 Uhr haben Kinder im Alter von drei bis ten. In ihrem Buch Perfekt geplant sechs Jahren die Möglichkeit, sich in der Turn- erklärt die ehemalige Investment- halle der Schillerschule sportlich auszuprobieren. bankerin Jessica Brunner, wie es Auf dem Programm stehen klettern, hüpfen, ren- nen und balancieren – natürlich alles mit Papa zusammen. Die Veranstaltung wird vom städti- schen Sportklub organisiert und ist kostenlos. Für das leibliche Wohl ist natürlich auch gesorgt. Es gibt Würstchen, Pommes und Pfannkuchen für den kleinen Hunger zwischendurch. Basteln – kinderleicht gemacht! Viermal im Jahr lädt die Kunstwerkstatt Eltern und Kinder ein, gemeinsam jahreszeitliche Dekorationen zu gestalten. Am kommenden Wochenende ist es wieder so weit: Der Frühling steht vor der Tür und wir haben tolle Bastelideen für Kinder im Alter von 3 bis 8 Jahren. Ob Blumen aus Papier, Schmetterlinge aus Filz oder Osterhasen aus alten (natürlich gewaschenen!) Socken. Es wird gemalt, geklebt und gewerkelt, und unter fachkundiger Anleitung entstehen so schnell kleine Kunstwerke. Lassen Sie sich überraschen! Die Teilnahmegebühr beträgt inklusive Material 3 Euro. Ihnen gelingt, nach und nach ein Vermögen aufzubauen. Die Auto- rin beschreibt leicht verständlich, worauf es dabei ankommt und wie auch Menschen mit geringem Ein- kommen es schaffen, regelmäßig Die sozialen Medien sind eine wunderbare Medien Schritt für Schritt zu erkunden und Möglichkeit, sich mit anderen Menschen zeigt ihnen, wie sie diese im Alltag nutzen auszutauschen. Wer wenig Erfahrung mit können, zum Beispiel, um mit Familienmit- Computern, Smartphones oder dem Internet gliedern und Freunden in Kontakt zu bleiben hat, traut sich jedoch oft nicht so recht oder um Informationen über aktuelle Themen an die sozialen Medien heran. Dieser Kurs hilft Senior*innen, die Welt der sozialen Anmeldung unter 0180-34 33 26. Der Monat ist noch nicht zu Jeden Donnerstag bietet das FamilienEnde, aber das Geld ist schon den „Mini­Treff“ für die Allerweg. Viele von euch kennen diese Situation vielleicht und an. Hier haben Babys ab der wissen, wie unangenehm sie ist. 12.2. Lebenswoche die Möglichkeit, Die neue Finanz-App hilft dir, anderen Babys in Kontakt zu kommen. deine Finanzen jederzeit im Eltern tauschen sich mit anderen Eltern Blick zu behalten. Sie zeigt dir aus oder lernen auf Wunsch, wie sie durch sanfte Babygymnastik die natürliche Beweglichkeit ihres Kindes unterstützen oder durch spielerische Impulse die Sinneswahrnehmung an regen können. Außerdem haben wir hilfreiche Entspannungstipps, die das Wohlbefinden von Eltern und Babys steigern. Machen Sie Ihr Unternehmen fit Social-Media-Marketing ist eine Form des Online-Marketings. In dieser ein- wöchigen Weiterbildung lernen Sie, soziale Medien gezielt für Ihr Unternehmen einzusetzen, zum Beispiel, um Werbung für Ihre Produkte oder Dienstleistungen zu machen. Am ersten Kurstag verschaffen Sie sich zunächst einen Überblick über die wichtigsten sozialen Medien und deren Vor- und Nachteile. Im Anschluss lernen Sie, wie Sie Ihren eigenen Social-Media-Auftritt selbstständig auf- und ausbauen können. Alle Kursinhalte werden durch zahlreiche praktische Beispiele veranschaulicht und es gibt ausreichend Raum für individuelle Fragen. detailliert deine Einnahmen und Ausgaben an, sodass du immer weißt, wie viel Geld noch übrig ist. Außerdem kannst du deine Ausgaben in Kategorien einteilen, z. B. Lebensmittel, Elektro nik- artikel oder Kleidung. So siehst du genau, wofür du am meisten Geld ausgibst – und wo du vielleicht noch den einen oder anderen Euro sparen kannst. Wer die Bank wechseln möchte, steht vor keiner leichten Aufgabe, denn die Auswahl auf dem deutschen Markt ist riesig. In einem 90-minütigen Vortrag stellt Finanz- experte Dr. Thomas Fritz die wichtigsten Produkte der Banken vor und erläutert, wel- che Auswahlkriterien Sie beachten sollten. Themen, die angesprochen werden, sind unter anderem: Kontogebühren, persönliche Beratung in den Filialen, Bargeld abheben im Ausland, Kreditkarten und spezielle Angebote für junge Leute. Am Ende des Vortrags können Fragen Donnerstag, 17 Uhr, Stadtbibliothek. Info-Nachmittag bei der Bank Wer sich frühzeitig mit dem Thema „Geld“ beschäftigt, die Bedeutung von Scheinen und Münzen kennenlernt und ver- steht, dass Geld nicht einfach da ist, wird es im späteren Leben leichter haben. Eltern haben hier eine große Verantwortung, sind sich aber oft unsicher, was sie ihren Kindern über Geld beibrin- gen sollen – und vor allem wie. Am Dienstagnachmittag findet bei der Stadtbank die Info- Veranstaltung „Kleine Finanz- experten“ statt, bei der Eltern lernen, ihr Kind im Alltag mit Geld vertraut zu machen und kindgerecht über Finanzen zu sprechen. Außerdem werden „Taschengeld“ beantwortet. Berufliche Neuorientierung Immer mehr ältere Menschen benötigen Hilfe im Alltag. Entsprechend wächst auch der Bedarf nach Pflegekräften. Wenn Sie sich für eine Tätigkeit in der Altenpflege interessieren, aber noch unsicher sind, ob dieser Berufsweg wirklich der richtige für Sie ist, kann Ihnen dieses Wochenendseminar als Entscheidungshilfe dienen. Wir geben Ihnen einen Überblick über berufliche Perspektiven in der Seniorenbetreuung, verschiedene Ausbildungsmöglichkeiten und den Arbeitsalltag in Pflegeeinrichtungen. Die Teilnahme ist kostenlos. Anmeldung unter Zähne putzen, Windeln wechseln, Schuhe an- ziehen, Haare kämmen. Wer kleine Kinder hat, weiß, dass all diese Dinge zu einer echten Herausforderung werden können. In ihrem Buch Der tägliche Wahnsinn erklärt die Psy- chologin Hanna Gerlach – selbst Mutter von sechs Kindern – auf humorvolle Weise, wie man gelassen bleibt, wenn die Kleinen mal wieder nerven. Eltern finden hier viele nütz- liche Ideen und Anregungen, wie sie mit Stresssituationen umgehen können – damit alle entspannter durch den Tag kommen.",
    "questions": [
      {
        "num": 11,
        "answer": "h",
        "stem": "Sie möchten lernen, Ihre Firma in sozialen Netzwerken vielseitig zu präsentieren."
      },
      {
        "num": 12,
        "answer": "b",
        "stem": "Ein Bekannter möchte zusammen mit seinem vierjährigen Sohn etwas Kreatives machen."
      },
      {
        "num": 13,
        "answer": "g",
        "stem": "Ihr 22-jähriger Nachbar will jederzeit wissen, wie viel Geld er noch zur Verfügung hat."
      },
      {
        "num": 14,
        "answer": "k",
        "stem": "Sie möchten herausfinden, welche Bank die beste für Sie ist."
      },
      {
        "num": 15,
        "answer": "a",
        "stem": "Eine Freundin von Ihnen möchte ihr Hobby zum Beruf machen."
      },
      {
        "num": 16,
        "answer": "l",
        "stem": "Sie möchten praktische Tipps, wie man den Alltag mit Kindern meistert."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Ein Bekannter hat eine Ausbildung zum Altenpfleger gemacht und sucht einen Job."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "Ihre Freundin möchte etwas darüber lesen, wie man langfristig Geld ansparen kann."
      },
      {
        "num": 19,
        "answer": "f",
        "stem": "Ihre Nachbarin, eine junge Mutter, möchte die Entwicklung ihres Babys fördern."
      },
      {
        "num": 20,
        "answer": "i",
        "stem": "Ihr Cousin möchte ein paar Tipps, wie er seinen Kindern den Umgang mit Geld beibringen kann."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Neue berufliche Perspektiven $ie machen leidenschaftlich gern Musik? Es macht Ihnen Freude, Kinderkleidung zu nähen oder leckere Marmeladen herzustellen? Vielleicht fotografieren Sie auch gerne oder sind handwerklich geschickt? Was immer es auch sein mag: Wäre es nicht schön, wenn Sie mit dem, was Sie in Ihrer Freizeit gerne tun, Ihr Geld verdienen könn-",
          "ten? Wir stellen Ihnen in unserem Tagesseminar einen Fünf-Schritte-Plan vor, der Ihnen dabei hilft, diesen Traum in die Realität umzusetzen.",
          "Das Seminar findet jeweils am ersten Samstag im Monat in der Volkshochschule statt und kostet 130 Euro, Anmeldung: 0180-775 30 07."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Vater-Kind-Aktion Aufgepasst! Am Samstag können Väter mit ihren Kindern toben und jede Menge Spaß haben. Von 14 bis 18 Uhr haben Kinder im Alter von drei bis sechs Jahren die Möglichkeit, sich in der Turnhalle der Schillerschule sportlich auszuprobieren. Auf dem Programm stehen klettern, hüpfen, rennen und balancieren – natürlich alles mit Papa zusammen. Die Veranstaltung wird vom städtischen Sportklub organisiert und ist kostenlos. Für das leibliche Wohl ist natürlich auch gesorgt. Es gibt Würstchen, Pommes und Pfannkuchen für den kleinen Hunger zwischendurch."
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "NEUER FINANZRATGEBER Die meisten Menschen kümmern sich wenig bis gar nicht um finanzielle Fragen. Das führt dazu, dass sie oft weniger Geld in Tasche haben, als sie eigentlich müssten. In ihrem Buch Perfekt geplant erklärt die ehemalige Investmentbankerin Jessica Brunner, wie es Ihnen gelingt, nach und nach ein Vermögen aufzubauen. Die Autorin beschreibt leicht verständlich, worauf es dabei ankommt und wie auch Menschen mit geringem Einkommen es schaffen, regelmäßig Geld beiseitezulegen."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Basteln – kinderleicht gemacht! Viermal im Jahr lädt die Kunstwerkstatt Eltern und Kinder ein, gemein sam jahreszeitliche Dekorationen zu gestalten. Am kommenden Wochen ende ist es wieder so weit: Der Frühling steht vor der Tür und wir haben tolle Bastelideen für Kinder im Alter von 3 bis 8 Jahren. Ob Blumen aus Papier, Schmetterlinge aus Filz oder Osterhasen aus alten (natürlich gewaschenen!) Socken. Es wird gemalt, geklebt und gewerkelt, und unter fachkundiger Anleitung entstehen so schnell kleine Kunstwerke. Lassen Sie sich überraschen! Die Teilnahmegebühr beträgt inklusive Material 3 Euro."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "GUT VERNETZT",
          "Die sozialen Medien sind eine wunderbare Möglichkeit, sich mit anderen Menschen auszutauschen. Wer wenig Erfahrung mit Computern, Smartphones oder dem Internet hat, traut sich jedoch oft nicht so recht",
          "an die sozialen Medien heran. Dieser Kurs hilft Senior*innen, die Welt der sozialen",
          "Medien Schritt für Schritt zu erkunden und zeigt ihnen, wie sie diese im Alltag nutzen können, zum Beispiel, um mit Familienmitgliedern und Freunden in Kontakt zu bleiben oder um Informationen über aktuelle Themen zu finden.",
          "Anmeldung unter 0180-34 33 26."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "ELTERN-KIND-TREFF Jeden Donnerstag bietet das Familien zentrum den „MiniTreff“ für die Aller kleinsten an. Hier haben Babys ab der 122.. Lebenswoche die Möglichkeit, anderen Babys in Kontakt zu kommen. Eltern tauschen sich mit anderen Eltern aus oder lernen auf Wunsch, wie sie durch sanfte Babygymnastik die natür liche Beweglichkeit ihres Kindes unter stützen oder durch spielerische Impulse die Sinneswahrnehmung an regen kön nen. Außerdem haben wir hilfreiche Entspannungstipps, die das Wohlbefin den von Eltern und Babys steigern."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Kostenlose App Der Monat ist noch nicht zu Ende, aber das Geld ist schon weg. Viele von euch kennen diese Situation vielleicht und wissen, wie unangenehm sie ist. Die neue Finanz-App hilft dir, deine Finanzen jederzeit im Blick zu behalten. Sie zeigt dir detailliert deine Einnahmen und Ausgaben an, sodass du immer weißt, wie viel Geld noch übrig ist. Außerdem kannst du deine Ausgaben in Kategorien einteilen, z. B. Lebensmittel, Elektron ikartikel oder Kleidung. So siehst du genau, wofür du am meisten Geld ausgibst – und wo du vielleicht noch den einen oder anderen Euro sparen kannst."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Machen Sie Ihr Unternehmen fit Social-Media-Marketing ist eine Form des Online-Marketings. In dieser einwöchigen Weiterbildung lernen Sie, soziale Medien gezielt für Ihr Unternehmen einzusetzen, zum Beispiel, um Werbung für Ihre Produkte oder Dienstleistungen zu machen. Am ersten Kurstag verschaffen Sie sich zunächst einen Überblick über die wichtigsten sozialen Medien und deren Vor- und Nachteile. Im Anschluss lernen Sie, wie Sie Ihren eigenen Social-Media-Auftritt selbstständig auf- und ausbauen können. Alle Kursinhalte werden durch zahlreiche praktische Beispiele veranschaulicht und es gibt ausreichend Raum für individuelle Fragen."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Info-Nachmittag bei der Bank",
          "Wer sich frühzeitig mit dem Thema „Geld' beschäftigt, die Bedeutung von Scheinen und Münzen kennenlernt und versteht, dass Geld nicht einfach da ist, wird es im späteren Leben leichter haben. Eltern haben hier eine große Verantwortung, sind sich aber oft unsicher, was sie ihren Kindern über Geld beibringen sollen - und vor allem wie.",
          "‚Am Dienstagnachmittag findet bei der Stadtbank die Info- Veranstaltung „Kleine Finanzexperten‘ statt, bei der Eltern lernen, ihr Kind im Alltag mit Geld vertraut zu machen und kindgerecht über Finanzen zu sprechen. Außerdem werden Fragen rund um das Thema „Taschengeld\" beantwortet."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Berufliche Neuorientierung Immer mehr ältere Menschen benötigen Hilfe im Alltag. Entsprechend wächst auch der Bedarf nach Pflegekräften. Wenn Sie sich für eine Tätigkeit in der Altenpflege interessieren, aber noch unsicher sind, ob dieser Berufsweg wirklich der richtige für Sie ist, kann Ihnen dieses Wochenendseminar als Entscheidungshilfe dienen. Wir geben Ihnen einen Überblick über berufliche Perspektiven in der Seniorenbetreuung, verschiedene Ausbildungsmöglichkeiten und den Arbeitsalltag in Pflegeeinrichtungen. Die Teilnahme ist kostenlos. Anmeldung unter www.pflege-berufe.de."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "k l Kostenloser Vortrag Wer die Bank wechseln möchte, steht vor keiner leichten Aufgabe, denn die Auswahl auf dem deutschen Markt ist riesig. In einem 90-minütigen Vortrag stellt Finanzexperte Dr. Thomas Fritz die wichtigsten Produkte der Banken vor und erläutert, welche Auswahlkriterien Sie beachten sollten. Themen, die angesprochen werden, sind unter anderem: Kontogebühren, persönliche Beratung in den Filialen, Bargeld abheben im Ausland, Kreditkarten und spezielle Angebote für junge Leute. Am Ende des Vortrags können Fragen gestellt werden."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "„Der tägliche Wahnsinn“ Zähne putzen, Windeln wechseln, Schuhe anziehen, Haare kämmen. Wer kleine Kinder hat, weiß, dass all diese Dinge zu einer echten Herausforderung werden können. In ihrem Buch Der tägliche Wahnsinn erklärt die Psychologin Hanna Gerlach – selbst Mutter von sechs Kindern – auf humorvolle Weise, wie man gelassen bleibt, wenn die Kleinen mal wieder nerven. Eltern finden hier viele nützliche Ideen und Anregungen, wie sie mit Stresssituationen umgehen können – damit alle entspannter durch den Tag kommen."
        ]
      }
    ]
  },
  {
    "id": "32",
    "title": "Versicherungen, Reisen und Geldanlage",
    "sourcePage": 326,
    "keywords": "Lesen Sie zuerst die zehn Situaonen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situaon? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwobogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Ein Bekannter möchte auf seinen Geschäftsreisen mit seinem Auto immer schnell 12 Eine bekannte Familie sucht eine leistungsstarke Krankenversicherung. 13 Ein Bekannter sucht eine private Rentenversicherung, die ihm etwas auszahlt, wenn er 50 ist. 14 Eine Bekannte möchte sich über Urlaubsangebote informieren, hat aber keine Zeit, in ein 15 Ihre Eltern möchten eine Kreuzfahrt im Mittelmeer unternehmen. 16 Ein Bekannter sucht für seine Cousine einen Sportverein, in dem junge Talente gefördert 17 Ein Bekannter interessiert sich für Geschichte sowie Kultur und möchte Urlaub in einer deutschen Weinregion machen. 18 Sie suchen ein Auto mit Platz für bis zu 5 Personen, aber einem möglichst geringen Sicherheit heißt, Risiken zu vermeiden. 19 Sie möchten vor einer Auslandsreise eine Auslandskrankenversicherung für die ganze Familie 20 Eine bekannte Familie möchte einen Urlaub machen, der auch für ihre 3- und 5-jährigen Wir setzen noch einen Schritt davor an: Risiken sollten gar nicht erst entstehen. Dafür arbeiten wir in unserem Allianz-Zentrum für Technik. Und wenn doch etwas passiert: Ein Anruf genügt und wir helfen schnell und unbürokratisch, rund um die Uhr. Denn in der Allianz AutoPlus- Versicherung ist der Schutzbrief gleich mit drin. Und der Auslandsschadenschutz hilft Ihnen in vielen Ländern Europas zusätzlich, wenn Sie unverschuldet in einen Verkehrsunfall verwickelt Nähere Informationen erhalten Sie im Internet unter www.allianz.de und bei einem Allianz- Bleiben Sie sich in den besten Jahren Ihres Lebens mit einer traumhaften Reise. Luxus ist, was man daraus macht! Und bei uns heißt das: eine Schiffsreise der absoluten Extraklasse – so traumhaft, wie man es sich immer gewünscht hat. Bereisen Sie damit die ganze Welt oder einen kleinen Teil von ihr – wählen Sie Ihr Lieblingsziel aus unserer vielfältigen Angebot. Natürlich inklusive Spitzengastronomie, Kino, Theater und Wellnessbereich – und das auf Flüssen sowie Meeren. Ganz locker und selbstverständlich ohne Kleiderzwang. Trigana bietet die komplette Reisewelt auf einen Klick! Von der Pauschalreise oder attraktiven Last-Minute-Angeboten bis hin zu Flügen, Hotels und Mietwagen: einfach online vergleichen, nach Belieben kombinieren und direkt buchen. Bequem von zu Hause aus – rund um die Uhr. Natürlich erfahren Sie bei Trigana auch alles Wissenswerte zu Ihrem Urlaubsziel: das Wetter, die schönsten Sehenswürdigkeiten, beste Restaurants und vieles mehr. Reisen Sie nicht auf gut Glück, sondern mit Trigana. EINFACH GUT STATT NUR GÜNSTIG. Was passiert, wenn sich Ihr Kind beim Spielen verletzt und zum Arzt muss, vielleicht sogar ins Krankenhaus? Selbstverständlich nicht die Krankenkasse die Kosten. Aber Sie möchten mehr – eine optimale Versorgung nicht nur für sich selbst, sondern die ganze Familie. Dann wählen Sie die Fürther Allgemeine als Ihre neue Die Fürther Allgemeine mit dem Rundum-sorglos-Paket für die ganze Familie. Bleiben Sie bei Ihrem Kind, wenn es ins Krankenhaus muss – wir stehen Ihnen auch 24 Stunden am Tag unterstützend zur Seite – das und vieles mehr leistet die Fürther Allgemeine. Bei uns erhalten Sie nicht den günstigsten Tarif, sondern die beste www.fuerther-allgemeine.org Leb wohl, Stau. Leb wohl, erfolglose Hotelsuche. Leb wohl, schlechter Restaurant-Tipp. Denn dank der aktiven Unterstützung von Assist müssen Sie als Fahrer viele unerfreuliche Seiten der Mobilität nicht mehr erleben. Assist informiert über aktuelle Verkehrssituation, gibt Stauwarnungen und empfiehlt Alternativrouten. Mit dem Mobilfunknetz ermittelt das System sogar Ihren Standort und leistet automatisch Hilfe. Gewünschte Informationen wie z. B. 3 Multirouten-Vergleiche mit aktueller Stauwarnung oder Branchenbuchs werden Ihnen per Datenübertragung direkt in Ihr Navigationssystem gesendet. Sie sehen: Als Fahrer auf das Wesentliche konzentrieren – mit Assist – jetzt bei Ihrem Autohändler. SCHIFFSREISE … mal anders! Entdecken Sie mit der ganzen Familie Deutschland neu. Auf unserem modernen Ausflugsschiff „Pippi Langstrumpf“ gibt es kleine wie große Tanzeinlagen, Restaurants, in denen man Anzug tragen muss – nein, das müssen Sie sich nicht vorstellen! Sie schippern ganz locker auf einem Schiff, ein Entdeckermuseum, in dem die Kleinen alles selbst machen können und Flüsse in Deutschland entdecken, während Sie sich eine echte Piratenrestaurant, in dem die kleinen Seeräuber kochen können. Da wird es nie langweilig! Und während sich unsere erfahrenen Betreuer um Ihre kleinen kümmern, können die Eltern ganz entspannt die Landschaft bewundern – oder doch mal einen Tee trinken. Nehmen Sie über Ihre Reisen mit der „Pippi Langstrumpf“ in Ihrem Reisebüro! Bundeswertpapiere helfen in den Sattel. Ob große Dressurhoffnung, Tennistalent oder begabter Kicker: Damit Ihr Nachwuchs später auf dem Siegertreppchen landet, sollten Sie ihre familiären Förderung früh genug mit Bundeswertpapieren auf Trab bringen. Bundeswertpapiere mit Laufzeiten von ein bis zehn Jahren – jetzt umsteigen auf Bundeswertpapiere mit jährlicher Zinszahlung und absoluter Sicherheit abgesichert ist. Bundeswertpapiere erhalten Sie bei Kreditinstituten und allen Landeszentralbanken. Statistisch gesehen arbeitet ein Mensch 35,7 Jahre seines Lebens. Für uns ist Ihr Leben schon ein Startwerk. Es ist einzigartig. Daher bieten wir Ihnen eine Altersvorsorge, die sich persönlich auf Ihr Leben abgestimmt ist. Gehen Sie an den Ruhestand wie Sie es wollen. Bauen Sie jederzeit Vermögen nach Ihren Vorstellungen auf. Sprechen Sie mit unseren kompetenten Partnern und entscheiden Sie selbst, wie lange Sie arbeiten wollen. Wir begleiten Sie. Wir sichern Sie. Für alle, die in Kellern nicht nur Discos suchen. Tauchen Sie dann doch einfach mal zur Historie von Speyer im Keller des Speyrer Doms. Oder besuchen Sie einer der zahlreichen Weinkeller, um ein gutes Glas zu www.suedlicheweinstrasse.de Die Welt mitgestalten. Neue Möbel kaufen, Material für den Umbau in der Wohnung transportieren – das können die meisten Heimwerker und Familien mit dem richtigen Fahrzeug fahren, nämlich jetzt mit dem Vaneo. Mit bis zu 3.000 Litern Laderaum, zwei Schiebetüren und zahlreichen Sicherheitsmerkmalen ausgestattet. Und natürlich mit Platz für Sie und eine ganze Entdecken Sie Ihren Vaneo. Was immer Sie von einem kompakten Automobil erwarten – der Jazz übertrifft Ihre Vorstellungen. Angefangen bei seinem neuen 1.4 i-DSI-Motor, der auch äußerst niedrigen Kraftstoffverbrauch aufweist. Deshalb könnte der Tank besonders flach ausfallen – das bedeutet: weniger Gewicht, wo man ihn wohl am wenigsten erwartet: unter dem Fahrersitz. So gewinnen Sie enorm viel Platz spart. Und das ist der Grund, warum Ihnen der neue Jazz den größten und flexibelsten Innenraum seiner Klasse bietet – nicht nur für Sie selbst, sondern für die ganze Familie. Mehr Informationen dürfen Sie unter www.jazz.de erwarten. „Die WK weiß, wie Vater Staat meine Rente fördert.“ Und das ist auch gut so, denn die Rentenreform lässt mehr Fragen offen, als sie beantwortet. Mit der Förder-Invest-Rente der WK können Sie das Beste aus dieser Reform machen. Wir sagen Ihnen, wie Sie heute Ihre gesetzliche Rente ergänzen, damit Sie nach Ihrem Arbeitsleben mit Mitte sechzig eine optimale Rente erhalten. Jahr für Jahr erhalten Sie außerdem Zulagen von Vater Staat. Viele Arbeitnehmer in der gesetzlichen Rentenversicherung können die staatliche Förderung in Anspruch nehmen – und sie sollten es, damit private Vorsorge nicht nur auf dem Papier Zukunft hat.",
    "questions": [
      {
        "num": 11,
        "answer": "e",
        "stem": "Ein Bekannter möchte auf seinen Geschäftsreisen mit seinem Auto immer schnell vorankommen."
      },
      {
        "num": 12,
        "answer": "d",
        "stem": "Eine bekannte Familie sucht eine leistungsstarke Krankenversicherung."
      },
      {
        "num": 13,
        "answer": "h",
        "stem": "Ein Bekannter sucht eine private Rentenversicherung, die ihm etwas auszahlt, wenn er 50 ist."
      },
      {
        "num": 14,
        "answer": "c",
        "stem": "Eine Bekannte möchte sich über Urlaubsangebote informieren, hat aber keine Zeit, in ein Reisebüro zu gehen."
      },
      {
        "num": 15,
        "answer": "b",
        "stem": "Ihre Eltern möchten eine Kreuzfahrt im Mittelmeer unternehmen."
      },
      {
        "num": 16,
        "answer": "x",
        "stem": "Ein Bekannter sucht für seine Cousine einen Sportverein, in dem junge Talente gefördert werden."
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "Ein Bekannter interessiert sich für Geschichte sowie Kultur und möchte Urlaub in einer deutschen Weinregion machen."
      },
      {
        "num": 18,
        "answer": "k",
        "stem": "Sie suchen ein Auto mit Platz für bis zu 5 Personen, aber einem möglichst geringen Benzinverbrauch."
      },
      {
        "num": 19,
        "answer": "x",
        "stem": "Sie möchten vor einer Auslandsreise eine Auslandskrankenversicherung für die ganze Familie abschließen."
      },
      {
        "num": 20,
        "answer": "f",
        "stem": "Eine bekannte Familie möchte einen Urlaub machen, der auch für ihre 3- und 5-jährigen Kinder interessant ist."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Sicherheit heißt, Risiken zu vermeiden. Wir setzen noch einen Schritt davor an: Risiken sollten gar nicht erst entstehen. Dafür arbeiten wir in unserem Allianz-Zentrum für Technik. Und wenn doch etwas passiert: Ein Anruf genügt und wir helfen schnell und unbürokratisch, rund um die Uhr. Denn in der Allianz AutoPlus- Versicherung ist der Schutzbrief gleich mit drin. Und der Auslandsschadenschutz hilft Ihnen in vielen Ländern Europas zusätzlich, wenn Sie unverschuldet in einen Verkehrsunfall verwickelt werden. Nähere Informationen erhalten Sie im Internet unter www.allianz.de und bei einem Allianz- Fachmann in Ihrer Nähe."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Ein Fest für die Sinne! Bleiben Sie sich in den besten Jahren Ihres Lebens mit einer traumhaften Reise. Luxus ist, was man daraus macht! Und bei uns heißt das: eine Schiffsreise der absoluten Extraklasse – so traumhaft, wie man es sich immer gewünscht hat. Bereisen Sie damit die ganze Welt oder einen kleinen Teil von ihr – wählen Sie Ihr Lieblingsziel aus unserer vielfältigen Angebot. Natürlich inklusive Spitzengastronomie, Kino, Theater und Wellnessbereich – und das auf Flüssen sowie Meeren. Ganz locker und selbstverständlich ohne Kleiderzwang. www.a-rosa.de"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Trigana bietet die komplette Reisewelt auf einen Klick! Von der Pauschalreise oder attraktiven Last-Minute-Angeboten bis hin zu Flügen, Hotels und Mietwagen: einfach online vergleichen, nach Belieben kombinieren und direkt buchen. Bequem von zu Hause aus – rund um die Uhr. Natürlich erfahren Sie bei Trigana auch alles Wissenswerte zu Ihrem Urlaubsziel: das Wetter, die schönsten Sehenswürdigkeiten, beste Restaurants und vieles mehr. Reisen Sie nicht auf gut Glück, sondern mit Trigana. Infos: www.trigana.de"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "EINFACH GUT STATT NUR GÜNSTIG. Was passiert, wenn sich Ihr Kind beim Spielen verletzt und zum Arzt muss, vielleicht sogar ins Krankenhaus? Selbstverständlich nicht die Krankenkasse die Kosten. Aber Sie möchten mehr – eine optimale Versorgung nicht nur für sich selbst, sondern die ganze Familie. Dann wählen Sie die Fürther Allgemeine als Ihre neue Krankenversicherung. Die Fürther Allgemeine mit dem Rundum-sorglos-Paket für die ganze Familie. Bleiben Sie bei Ihrem Kind, wenn es ins Krankenhaus muss – wir stehen Ihnen auch 24 Stunden am Tag unterstützend zur Seite – das und vieles mehr leistet die Fürther Allgemeine. Bei uns erhalten Sie nicht den günstigsten Tarif, sondern die beste Versorgung. www.fuerther-allgemeine.org"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Leb wohl, Stau. Leb wohl, erfolglose Hotelsuche. Leb wohl, schlechter Restaurant-Tipp. Denn dank der aktiven Unterstützung von Assist müssen Sie als Fahrer viele unerfreuliche Seiten der Mobilität nicht mehr erleben. Assist informiert über aktuelle Verkehrssituation, gibt Stauwarnungen und empfiehlt Alternativrouten. Mit dem Mobilfunknetz ermittelt das System sogar Ihren Standort und leistet automatisch Hilfe. Gewünschte Informationen wie z. B. 3 Multirouten-Vergleiche mit aktueller Stauwarnung oder Branchenbuchs werden Ihnen per Datenübertragung direkt in Ihr Navigationssystem gesendet. Sie sehen: Als Fahrer auf das Wesentliche konzentrieren – mit Assist – jetzt bei Ihrem Autohändler."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "SCHIFFSREISE … mal anders! Entdecken Sie mit der ganzen Familie Deutschland neu. Auf unserem modernen Ausflugsschiff „Pippi Langstrumpf“ gibt es kleine wie große Tanzeinlagen, Restaurants, in denen man Anzug tragen muss – nein, das müssen Sie sich nicht vorstellen! Sie schippern ganz locker auf einem Schiff, ein Entdeckermuseum, in dem die Kleinen alles selbst machen können und Flüsse in Deutschland entdecken, während Sie sich eine echte Piratenrestaurant, in dem die kleinen Seeräuber kochen können. Da wird es nie langweilig! Und während sich unsere erfahrenen Betreuer um Ihre kleinen kümmern, können die Eltern ganz entspannt die Landschaft bewundern – oder doch mal einen Tee trinken. Nehmen Sie über Ihre Reisen mit der „Pippi Langstrumpf“ in Ihrem Reisebüro!"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Bundeswertpapiere helfen in den Sattel. Ob große Dressurhoffnung, Tennistalent oder begabter Kicker: Damit Ihr Nachwuchs später auf dem Siegertreppchen landet, sollten Sie ihre familiären Förderung früh genug mit Bundeswertpapieren auf Trab bringen. Bundeswertpapiere mit Laufzeiten von ein bis zehn Jahren – jetzt umsteigen auf Bundeswertpapiere mit jährlicher Zinszahlung und absoluter Sicherheit abgesichert ist."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Statistisch gesehen arbeitet ein Mensch 35,7 Jahre seines Lebens. Für uns ist Ihr Leben schon ein Startwerk. Es ist einzigartig. Daher bieten wir Ihnen eine Altersvorsorge, die sich persönlich auf Ihr Leben abgestimmt ist. Gehen Sie an den Ruhestand wie Sie es wollen. Bauen Sie jederzeit Vermögen nach Ihren Vorstellungen auf. Sprechen Sie mit unseren kompetenten Partnern und entscheiden Sie selbst, wie lange Sie arbeiten wollen. Wir begleiten Sie. Wir sichern Sie. Ein Leben lang. www.AXIS.de"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Für alle, die in Kellern nicht nur Discos suchen. Tauchen Sie dann doch einfach mal zur Historie von Speyer im Keller des Speyrer Doms. Oder besuchen Sie einer der zahlreichen Weinkeller, um ein gutes Glas zu trinken. Die Pfalz. www.suedlicheweinstrasse.de"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Nicht genug Platz? Die Welt mitgestalten. Neue Möbel kaufen, Material für den Umbau in der Wohnung transportieren – das können die meisten Heimwerker und Familien mit dem richtigen Fahrzeug fahren, nämlich jetzt mit dem Vaneo. Mit bis zu 3.000 Litern Laderaum, zwei Schiebetüren und zahlreichen Sicherheitsmerkmalen ausgestattet. Und natürlich mit Platz für Sie und eine ganze Familie. Entdecken Sie Ihren Vaneo. www.autohaus-miltner.de"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Was immer Sie von einem kompakten Automobil erwarten – der Jazz übertrifft Ihre Vorstellungen. Angefangen bei seinem neuen 1.4 i-DSI-Motor, der auch äußerst niedrigen Kraftstoffverbrauch aufweist. Deshalb könnte der Tank besonders flach ausfallen – das bedeutet: weniger Gewicht, wo man ihn wohl am wenigsten erwartet: unter dem Fahrersitz. So gewinnen Sie enorm viel Platz spart. Und das ist der Grund, warum Ihnen der neue Jazz den größten und flexibelsten Innenraum seiner Klasse bietet – nicht nur für Sie selbst, sondern für die ganze Familie. Mehr Informationen dürfen Sie unter www.jazz.de erwarten."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "„Die WK weiß, wie Vater Staat meine Rente fördert.“ Und das ist auch gut so, denn die Rentenreform lässt mehr Fragen offen, als sie beantwortet. Mit der Förder-Invest-Rente der WK können Sie das Beste aus dieser Reform machen. Wir sagen Ihnen, wie Sie heute Ihre gesetzliche Rente ergänzen, damit Sie nach Ihrem Arbeitsleben mit Mitte sechzig eine optimale Rente erhalten. Jahr für Jahr erhalten Sie außerdem Zulagen von Vater Staat. Viele Arbeitnehmer in der gesetzlichen Rentenversicherung können die staatliche Förderung in Anspruch nehmen – und sie sollten es, damit private Vorsorge nicht nur auf dem Papier Zukunft hat."
        ]
      }
    ]
  },
  {
    "id": "33",
    "title": "Sprache, Kommunikation und Einkaufen",
    "sourcePage": 329,
    "keywords": "____11. Ihre Kinder sollen in ihrer Herkunftssprache gefördert werden. ____12. Sie vergessen immer etwas, wenn Sie Lebensmittel besorgen, und wollen dem ____13. Sie möchte zu Übungszwecken ein Grammatikwerk erwerben. ____14. Sie wollen auch bei größeren Einkäufen auf das Auto verzichten. ____15. Durch geeignete Kommunikationsstrategien möchten Sie den Absatz Ihrer Produkte ____16. Sie wünschen sich, dass Ihre Lieblingsprodukte zu jeder Tages- und Nachtzeit ____17. Sie sind immer gerne bereit, neue Nahrungsmittel auszuprobieren. ____18. Beim Einkaufen erwarten Sie freundlichen Service durch kompetentes Personal. ____19. Ihre sprachbegabte Freundin war im Bereich Produktreklame tätig und sucht eine ____20. Sie ärgern sich über eine falsche Produktangabe und möchten das melden. Sie möchten Ihre Erledigungen ohne Stress und Verkehrsstaus absolvieren und stattdessen die frische Luft genießen? Und dabei vielleicht neue Läden kennenlernen, die Ihnen bisher verborgen geblieben sind? Für Grazerinnen und Grazer wird dieser Traum jetzt Wirklichkeit. Ab Anfang März besteht die Möglichkeit, völlig kostenlos ein Lastenrad zu reservieren, mit dem Sie bequem auch umfangreichere Besorgungen transportieren können. Eine Liste der Stationen, wo diese mit einer großen Ladefläche ausgestatteten Fahrräder abholbereit sind, ist unter der Internetadresse www.lastenfrei.com einsehbar. Ihren PKW können Sie getrost stehen lassen! Schon lange fragen Sie sich, was der Sinn von Satzbauregeln ist und wieso die deutsche Sprache so kompliziert ist? Dann sollten Sie sich den folgenden Termin in Ihren Kalender eintragen: Das Grazer Kulturhaus lädt am Mittwoch um 18:00 Uhr zu einem Vortrag der Sprachwissenschaftlerin und Autorin Margarita Hellig über ihr neuestes Buch ein, in dem sie mit Grammatik als Grundvoraussetzung für die Kommunikation ohne Missverständnisse sowie mit deren Bedeutung im Spracherwerb auseinandersetzt. Dabei sorgen praktische Beispiele garantiert für Spaß! Die Mehrzahl österreichischer Konsumenten achten beim Lebensmitteleinkauf sehr genau auf Qualität, Herkunft und eine übersichtliche Auflistung der Inhaltsstoffe. Für Kritik sorgen neben kaum lesbaren Aufschriften etwa irreführende Abbildungen auf der Verpackung. Das Gefühl, getäuscht zu werden, ist dann besonders stark, wenn die Packungsgröße zwar unverändert bleibt, die enthaltene Menge aber verringert wird und damit eine versteckte Teuerung einhergeht. Haben Sie eine derartige Beschwerde einzubringen, wenden Sie sich über unsere Website www.konsumentschutz.at an den Konsumentenschutzverband. Wir setzen uns für Ihre Rechte ein! Sie haben eine eigene Firma gegründet und möchten Ihre Erzeugnisse oder Dienstleistungen überzeugend vermarkten? Dann ist es ratsam nachzuforschen, welche Ausdrucksweise potenzielle Kunden besonders anspricht. Um Ihr Gegenüber bestmöglich zu erreichen, muss Ihre Botschaft klar und störungsfrei ankommen. Wir stellen hierfür beraten und verkaufen will, sollte seine Sprache daher an jene des Kunden auswirken. Wir unterstützen Sie dabei, Sprachmuster zu erlernen, die sich vorteilhaft auf Ihren Betrieb auswirken. Unsere Seminarreihe „Sprechen Sie kundisch?“ startet am 5.10., die genauen Termine entnehmen Sie bitte unserer Homepage www.profkomm.at Im Rahmen des Projekts „Sprache auch ist Kommunikation“ leisten nun auch die österreichischen Museen ihren Beitrag zur Vermittlung und Festigung der deutschen Sprache. Sprachkenntnisse lassen sich nämlich wunderbar üben und ausbauen, indem man Bildinhalte betrachtet und beschreibt oder gemeinsam überlegt, welche Geschichten hinter einem Kunstwerk stecken. Das kostenlose Angebot richtet sich an Kinder, Jugendliche und Erwachsene mit nichtdeutscher Erstsprache. Auf der Homepage www.museen-sprachen.at können Sie eine Liste aller am Projekt beteiligten Museen finden und sich für Führungen mit speziell ausgebildeten Sprachtrainern Bereits seit mehreren Jahren sind wir an unserer Schule in der glücklichen Lage, uns mit einem besonders wertvollen pädagogischen Angebot an eine bestimmte Zielgruppe wenden zu können: Für jene Schüler, die eine andere Erstsprache als Deutsch haben oder im Familienverband zweisprachig aufwachsen, besteht die Möglichkeit, muttersprachlichen Unterricht zu besuchen. Dieser kann grundsätzlich in jeder Sprache erfolgen, sofern Bedarf angemeldet wird und die personellen Ressourcen vorhanden sind. Wir möchten Sie daher zu einer Anmeldung ermutigen, wenn eines der genannten Kriterien zutrifft. Verfügen Sie über Marketingkenntnisse und zählt eine ausgezeichnete Ausdrucksfähigkeit zu Ihren Stärken? Dann bringen Sie die idealen Voraussetzungen mit, um als Werbetexter/in Teil unseres Teams zu werden. In unserem Innsbrucker Büro haben Sie Ihren persönlichen Arbeitsplatz, den Sie ganz nach Ihren Wünschen gestalten können. Außerdem bieten wir Ihnen die Möglichkeit, Ihrer Tätigkeit online von zu Hause aus nachzugehen. Wenn Sie Freude am kreativer Textarbeit haben und bereits erste Erfahrungen sammeln konnten, senden Sie Ihre vollständigen Bewerbungsunterlagen (Bewerbungsschreiben sowie Lebenslauf) direkt an susan.lloyd@transaustria.at. Eingeschränkte Öffnungszeiten müssen Kunden von Commodo-Supermärkten nun nicht mehr hinnehmen. Wir haben unseren Service nämlich in der vergangenen Woche ausgeweitet und direkt vor den Filialen Lebensmittelautomaten aufgestellt. Angefangen von frischen Milchprodukten und Wurstwaren bis hin zu Bio-Fertiggerichten ist unser Angebot – im Gegensatz zu den üblichen Snackautomaten – äußerst umfangreich. Zweimal am Tag füllen unsere Mitarbeiter Produkte nach, und das Sortiment wird der Nachfrage entsprechend angepasst. Sind Sie von den vielen Zettelnchen, die sich in Ihrer Jackentasche oft nicht wiederfinden lassen, auch schon so genervt? Mit unserer neuen, kostenlosen und einfach zu bedienenden Handy-App können Sie sich Ihren Alltag nun erleichtern und durch Sprachausgabe Ihre Einkaufsliste anlegen, umständliches Eintippen ist nicht nötig. Jederzeit können Sie Ihren Merkzettel nach Belieben neu gliedern und ändern. Richten Sie gleich unter www.einkaufsapp.at Ihr eigenes Zugangskonto ein – dann heißt es nie wieder: „Oje, jetzt hab ich wieder kein Salz!“ Essen ist kein Müll! Auf dieses Motto ist die Gründung unseres Vereins „Elementar“ zurückzuführen, der es sich zum Ziel gesetzt hat, abgelaufene, aber nach wie vor genießbare, Lebensmittel vor der Mülltonne zu bewahren. Aus diesen zaubern wir köstliche Klassiker wie Sugos, Suppen, Säfte und Aufstriche und bieten sie zum Verkauf an. Anlässlich der Neueröffnung unseres Ladens in der Seegasse 17 lädt das Team um Ingrid Brandstätter zu einem Tag der offenen Tür. Bringen Sie gerne auch nicht mehr benötigte Nahrungsmittel, Obst oder Gemüse vorbei. Stumme Geistersupermärkte ohne Angestellte sollen die Zukunft sein? Die Anzahl jener Läden, die zumindest teilweise auf digital gesteuerte Selbstbedienung umrüsten, steigt. Doch eine jüngst veröffentlichte Studie weist klar darauf hin, dass die meisten Menschen dieser Idee ablehnend gegenüberstehen. Auch der Großteil unserer Kunden wünscht sich nicht nur professionelle Beratung von unseren Mitarbeitern, sondern generell sozialen Kontakt. Deshalb haben wir uns bewusst dazu entschlossen, Ihnen weiterhin persönlichen Umgang zu bieten. Unsere Emporio-Filialen stehen für Kaffee mit Fruchtgeschmack, Anti-Energydrinks oder Bratapfelgewürz sind Ihnen im Supermarkt noch nicht aufgefallen? Das liegt daran, dass diese Erzeugnisse regulär noch gar nicht erhältlich sind. Lediglich in unserem Futura-Marktforschungssupermarkt haben Sie die spannende Gelegenheit, Neuentwicklungen kennenzulernen. Wenn Sie den Wunsch haben mitzuentscheiden, welche Lebensmittel das Potenzial haben, österreichische Konsumenten anzusprechen, registrieren Sie sich auf unserer Homepage www.futurafood.at. Die Mitgliedschaft beträgt 12 Euro pro Jahr, jedoch erhalten Sie dafür ein Einkaufsguthaben von 55 Euro, das sich durch die Teilnahme an unseren Umfragen noch erhöhen lässt.",
    "questions": [
      {
        "num": 11,
        "answer": "f",
        "stem": "Ihre Kinder sollen in ihrer Herkunftssprache gefördert werden."
      },
      {
        "num": 12,
        "answer": "i",
        "stem": "Sie vergessen immer etwas, wenn Sie Lebensmittel besorgen, und wollen dem hilfe schaffen."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Sie möchte zu Übungszwecken ein Grammatikwerk erwerben."
      },
      {
        "num": 14,
        "answer": "a",
        "stem": "Sie wollen auch bei größeren Einkäufen auf das Auto verzichten."
      },
      {
        "num": 15,
        "answer": "d",
        "stem": "Durch geeignete Kommunikationsstrategien möchten Sie den Absatz Ihrer Produkte steigern."
      },
      {
        "num": 16,
        "answer": "h",
        "stem": "Sie wünschen sich, dass Ihre Lieblingsprodukte zu jeder Tages- und Nachtzeit hältlich sind."
      },
      {
        "num": 17,
        "answer": "l",
        "stem": "Sie sind immer gerne bereit, neue Nahrungsmittel auszuprobieren."
      },
      {
        "num": 18,
        "answer": "k",
        "stem": "Beim Einkaufen erwarten Sie freundlichen Service durch kompetentes Personal."
      },
      {
        "num": 19,
        "answer": "g",
        "stem": "Ihre sprachbegabte Freundin war im Bereich Produktreklame tätig und sucht eine ue Stelle."
      },
      {
        "num": 20,
        "answer": "c",
        "stem": "Sie ärgern sich über eine falsche Produktangabe und möchten das melden."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Sie möchten Ihre Erledigungen ohne Stress und Verkehrsstaus absolvieren und stattdessen die frische Luft genießen? Und dabei vielleicht neue Läden kennenlernen, die Ihnen bisher verborgen geblieben sind? Für Grazerinnen und Grazer wird dieser Traum jetzt Wirklichkeit. Ab Anfang März besteht die Möglichkeit, völlig kostenlos ein Lastenrad zu reservieren, mit dem Sie bequem auch umfangreichere Besorgungen transportieren können. Eine Liste der Stationen, wo diese mit einer großen Ladefläche ausgestatteten Fahrräder abholbereit sind, ist unter der Internetadresse www.lastenfrei.com einsehbar. Ihren PKW können Sie getrost stehen lassen!"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Schon lange fragen Sie sich, was der Sinn von Satzbauregeln ist und wieso die deutsche Sprache so kompliziert ist? Dann sollten Sie sich den folgenden Termin in Ihren Kalender eintragen: Das Grazer Kulturhaus lädt am Mittwoch um 18:00 Uhr zu einem Vortrag der Sprachwissenschaftlerin und Autorin Margarita Hellig über ihr neuestes Buch ein, in dem sie mit Grammatik als Grundvoraussetzung für die Kommunikation ohne Missverständnisse sowie mit deren Bedeutung im Spracherwerb auseinandersetzt. Dabei sorgen praktische Beispiele garantiert für Spaß!"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Die Mehrzahl österreichischer Konsumenten achten beim Lebensmitteleinkauf sehr genau auf Qualität, Herkunft und eine übersichtliche Auflistung der Inhaltsstoffe. Für Kritik sorgen neben kaum lesbaren Aufschriften etwa irreführende Abbildungen auf der Verpackung. Das Gefühl, getäuscht zu werden, ist dann besonders stark, wenn die Packungsgröße zwar unverändert bleibt, die enthaltene Menge aber verringert wird und damit eine versteckte Teuerung einhergeht. Haben Sie eine derartige Beschwerde einzubringen, wenden Sie sich über unsere Website www.konsumentschutz.at an den Konsumentenschutzverband. Wir setzen uns für Ihre Rechte ein!"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Sie haben eine eigene Firma gegründet und möchten Ihre Erzeugnisse oder Dienstleistungen überzeugend vermarkten? Dann ist es ratsam nachzuforschen, welche Ausdrucksweise potenzielle Kunden besonders anspricht. Um Ihr Gegenüber bestmöglich zu erreichen, muss Ihre Botschaft klar und störungsfrei ankommen. Wir stellen hierfür beraten und verkaufen will, sollte seine Sprache daher an jene des Kunden auswirken. Wir unterstützen Sie dabei, Sprachmuster zu erlernen, die sich vorteilhaft auf Ihren Betrieb auswirken. Unsere Seminarreihe „Sprechen Sie kundisch?“ startet am 5.10., die genauen Termine entnehmen Sie bitte unserer Homepage www.profkomm.at"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Im Rahmen des Projekts „Sprache auch ist Kommunikation“ leisten nun auch die österreichischen Museen ihren Beitrag zur Vermittlung und Festigung der deutschen Sprache. Sprachkenntnisse lassen sich nämlich wunderbar üben und ausbauen, indem man Bildinhalte betrachtet und beschreibt oder gemeinsam überlegt, welche Geschichten hinter einem Kunstwerk stecken. Das kostenlose Angebot richtet sich an Kinder, Jugendliche und Erwachsene mit nichtdeutscher Erstsprache. Auf der Homepage www.museen-sprachen.at können Sie eine Liste aller am Projekt beteiligten Museen finden und sich für Führungen mit speziell ausgebildeten Sprachtrainern anmelden."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Bereits seit mehreren Jahren sind wir an unserer Schule in der glücklichen Lage, uns mit einem besonders wertvollen pädagogischen Angebot an eine bestimmte Zielgruppe wenden zu können: Für jene Schüler, die eine andere Erstsprache als Deutsch haben oder im Familienverband zweisprachig aufwachsen, besteht die Möglichkeit, muttersprachlichen Unterricht zu besuchen. Dieser kann grundsätzlich in jeder Sprache erfolgen, sofern Bedarf angemeldet wird und die personellen Ressourcen vorhanden sind. Wir möchten Sie daher zu einer Anmeldung ermutigen, wenn eines der genannten Kriterien zutrifft."
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Verfügen Sie über Marketingkenntnisse und zählt eine ausgezeichnete Ausdrucksfähigkeit zu Ihren Stärken? Dann bringen Sie die idealen Voraussetzungen mit, um als Werbetexter/in Teil unseres Teams zu werden. In unserem Innsbrucker Büro haben Sie Ihren persönlichen Arbeitsplatz, den Sie ganz nach Ihren Wünschen gestalten können. Außerdem bieten wir Ihnen die Möglichkeit, Ihrer Tätigkeit online von zu Hause aus nachzugehen. Wenn Sie Freude am kreativer Textarbeit haben und bereits erste Erfahrungen sammeln konnten, senden Sie Ihre vollständigen Bewerbungsunterlagen (Bewerbungsschreiben sowie Lebenslauf) direkt an susan.lloyd@transaustria.at."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Eingeschränkte Öffnungszeiten müssen Kunden von Commodo-Supermärkten nun nicht mehr hinnehmen. Wir haben unseren Service nämlich in der vergangenen Woche ausgeweitet und direkt vor den Filialen Lebensmittelautomaten aufgestellt. Angefangen von frischen Milchprodukten und Wurstwaren bis hin zu Bio-Fertiggerichten ist unser Angebot – im Gegensatz zu den üblichen Snackautomaten – äußerst umfangreich. Zweimal am Tag füllen unsere Mitarbeiter Produkte nach, und das Sortiment wird der Nachfrage entsprechend angepasst."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Sind Sie von den vielen Zettelnchen, die sich in Ihrer Jackentasche oft nicht wiederfinden lassen, auch schon so genervt? Mit unserer neuen, kostenlosen und einfach zu bedienenden Handy-App können Sie sich Ihren Alltag nun erleichtern und durch Sprachausgabe Ihre Einkaufsliste anlegen, umständliches Eintippen ist nicht nötig. Jederzeit können Sie Ihren Merkzettel nach Belieben neu gliedern und ändern. Richten Sie gleich unter www.einkaufsapp.at Ihr eigenes Zugangskonto ein – dann heißt es nie wieder: „Oje, jetzt hab ich wieder kein Salz!“"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Essen ist kein Müll! Auf dieses Motto ist die Gründung unseres Vereins „Elementar“ zurückzuführen, der es sich zum Ziel gesetzt hat, abgelaufene, aber nach wie vor genießbare, Lebensmittel vor der Mülltonne zu bewahren. Aus diesen zaubern wir köstliche Klassiker wie Sugos, Suppen, Säfte und Aufstriche und bieten sie zum Verkauf an. Anlässlich der Neueröffnung unseres Ladens in der Seegasse 17 lädt das Team um Ingrid Brandstätter zu einem Tag der offenen Tür. Bringen Sie gerne auch nicht mehr benötigte Nahrungsmittel, Obst oder Gemüse vorbei."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Stumme Geistersupermärkte ohne Angestellte sollen die Zukunft sein? Die Anzahl jener Läden, die zumindest teilweise auf digital gesteuerte Selbstbedienung umrüsten, steigt. Doch eine jüngst veröffentlichte Studie weist klar darauf hin, dass die meisten Menschen dieser Idee ablehnend gegenüberstehen. Auch der Großteil unserer Kunden wünscht sich nicht nur professionelle Beratung von unseren Mitarbeitern, sondern generell sozialen Kontakt. Deshalb haben wir uns bewusst dazu entschlossen, Ihnen weiterhin persönlichen Umgang zu bieten. Unsere Emporio-Filialen stehen für menschliche Nähe. Wir freuen uns auf Sie!"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Kaffee mit Fruchtgeschmack, Anti-Energydrinks oder Bratapfelgewürz sind Ihnen im Supermarkt noch nicht aufgefallen? Das liegt daran, dass diese Erzeugnisse regulär noch gar nicht erhältlich sind. Lediglich in unserem Futura-Marktforschungssupermarkt haben Sie die spannende Gelegenheit, Neuentwicklungen kennenzulernen. Wenn Sie den Wunsch haben mitzuentscheiden, welche Lebensmittel das Potenzial haben, österreichische Konsumenten anzusprechen, registrieren Sie sich auf unserer Homepage www.futurafood.at. Die Mitgliedschaft beträgt 12 Euro pro Jahr, jedoch erhalten Sie dafür ein Einkaufsguthaben von 55 Euro, das sich durch die Teilnahme an unseren Umfragen noch erhöhen lässt."
        ]
      }
    ]
  },
  {
    "id": "34",
    "title": "Fotografie, Museen und Familienfreizeit",
    "sourcePage": 332,
    "keywords": "Lesen Sie zuerst die Situationen (11-20) und dann die zwölf Texte (a-1). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Die Tochter einer Bekannten wird vier Jahre alt. Sie möchten ihr etwas zum Geburtstag mitbringen. 12 Ein Bekannter hat sich einen Fotoapparat gekauft und möchte die Grundlagen der Fotografie erlernen. 13 Ein Bekannter möchte eine mehrtägige Reise unternehmen und dabei einen Fotokurs machen. 14 Eine Bekannte kann gut fotografieren und hat bereits einige Kurse gemacht. Sie würde gerne neue kreative Techniken kennenlernen. 15 Ein Freund würde gerne im Winter verreisen. Er möchte viel Zeit an der frischen Luft verbringen und sich bewegen. 16 Eine Freundin hat viele Kleidungsstücke, die sie nicht mehr trägt. Sie sucht Anregungen, was sie damit machen könnte. 17 Sie besuchen einen Freund, der sich für Malerei interessiert. Sie möchten ihm ein passendes Geschenk mitbringen. 18 Sie fahren gerne Ski und möchten mit Ihrer Familie Wintersport 19 Sie möchten mit Ihrem zwölfjährigen Sohn eine Ausstellung besuchen. Er interessiert sich für Tiere.ie 20 Sie treffen sich an einem Sonntagnachmittag mit einer Freundin, die sich gerne mit Mode und ihrer Geschichte beschäftigt. Sie möchten mit A- Expedition ins Reich der Schneeleoparden Schneeleoparden zählen zu den seltensten Großkatzen der Erde. Weltweit leben nur noch 4000 bis 6400 dieser Tiere in freier Wildbahn. Welchen Gefahren sind sie ausgesetzt? Und wie können wir sie schützen? Die interaktive Ausstellung „Expedition Schneeleopard“ nimmt die Besucher mit auf eine Reise in das Reich der seltenen Großkatzen. Mitmach-Aktionen machen die Ausstellung zu einem Erlebnis für Groß und Klein. Die Ausstellung ist bis zum 23. Januar im Zoologischen Forschungsmuseum Bonn, Di bis So von 10 B- Alte Jeans, Blusen oder Kleider – jeder hat sie im Schrank. Ob das gute Stück zu eng, zu weit oder aus der Mode gekommen ist – wegwerfen muss man es deshalb noch lange nicht. Denn aus alten Sachen lässt sich wunderbar Neues kreieren: Vom Stuhlüberzug bis zur Umhängetasche werden in diesem Ratgeber viele Nähprojekte Schritt für Schritt erklärt. So werden aus alten Jeans ganz schnell ein neues Lieblingsstück. Autorin Amélie Betker entwirft seit über fünfzehn Jahren Mode-Accessoires und liebt es, ihr Wissen und ihre Begeisterung fürs Nähen weiterzugeben. Amélie Betker: Aus alt mach neu! Kreative Nähprojekte für ausgediente Kleidungsstücke, Paperback, 144 C- Blauer Stoff mit Historie Am 20. Mai 1873 meldete der Amerikaner Levi Strauss das Patent auf die Blue Jeans an. Die Ausstellung „Blue Jeans – von der Arbeitskleidung zum Laufsteg“ zeigt, wie sich die weltberühmte Hose im Laufe der Zeit entwickelte. Präsentiert werden Fotos, Filme und Zeitschriften, alte Jeans-Originale und 24. November bis 10. März Dienstag bis Sonntag von 10 bis 19 Uhr Kinder und Jugendliche: 5 Euro D- Es ist ein sonniger Herbsttag, doch plötzlich fällt im Zauberland unerwartet Schnee. Während sich ihre Freunde in das Schneegestöber stürzen, wundert sich Prinzessin Mina: Woher kommt der viele Schnee bloß? Und was ist das für ein kleiner Schneefuchs, den sie am Waldrand gesehen hat? Kurz entschlossen macht sich Prinzessin Mina auf die Suche nach dem kleinen Fuchs. Eine warmherzig erzählte und stimmungsvoll illustrierte Wintergeschichte für kleine und große Prinzessinnen und Prinzen! Elisabeth Heller: Schnee im Zauberland. Für Kinder ab drei Jahren, gebundenes Buch, 52 Seiten, 17,90 € Ein Muss für alle Schneeliebhaber: Der Band zeigt, wie sich Künstler von 1800 bis heute vom Schnee inspirieren ließen. Künstlerischer Ausdruck findet der Schnee in Gemälden der Romantik, des Impressionismus, Symbolismus, Expressionismus und der Neuen Sachlichkeit. Schneefotos von der Frühzeit der Fotografie bis heute sowie ausgewählte Texte zur zeitgenössischen Kunst spannen den Bogen bis in die Gegenwart. Schnee in der Kunst, hrsg. von Nadja Schwenzer, 312 Seiten, 200 Abbildungen, gebunden mit F- Märchenlandschaft aus Schnee und Eis Der beliebte Kurort Oberstdorf liegt am Fuße der Allgäuer Hochalpen. Winterwanderer kommen hier auf ihre Kosten: Auf den Wanderwegen gelangt man schnell in stille, verschneite Landschaften. Wir bieten an: Wanderurlaub in der Gruppe mit fünf leichten bis moderaten Winterwanderungen rund um Übernachtung in einem komfortablen Vier-Sterne-Hotel mit Wellnessbereich und Innenpool, 8 Tage mit Halbpension ab 988 € www.winterwanderwoche-oberstdorf.net G- Wintersport im Wandel der Zeit Ob auf Schlitten, Schlittschuhen oder Skiern, von der Haustür oder im Winterurlaub in den Alpen: Sport und Spiel im Schnee und auf dem Eis gehören für viele zu den größten Freizeitfreuden. Die Ausstellung zeigt Winterfotos, die illustrieren, wie sich der Wintersport im letzten Jahrhundert verändert hat. Historische Jahrhunderte zeigen und Dokumente erzählen die Schau, die die kalte Jahreszeit einmal spielerisch zeigt. Erlebnis-Ausstellung für die ganze Familie. Termin: vom 27.11. bis zum 27.02., Dienstag bis Sonntag, von 11 bis 17 Uhr Historisches Museum Prenzlau H- Atemberaubende Fotos leicht gemacht Sie möchten fotografieren lernen? Wir zeigen Ihnen in unserem Online-Fotokurs, dass es gar nicht so schwierig ist, gelungene Fotos zu schießen. In leicht verständlichen Texten und Videos erhalten Sie in unserem Kurs für Anfänger das komplette Basiswissen der Fotografie. Einmalige Zahlung von 147 € für einen unbegrenzten Zugang zum Online-Fotokurs!Zahlung per Lastschrift, Sofortüberweisung, Kreditkarte oder PayPal. Jetzt anmelden: www.nt-pictures.net İ - Nähen statt Einkaufsstress Die Suche nach einer perfekt sitzenden Jeans kann manchmal zum Albtraum werden: Stundenlang zieht man durch die Geschäfte, probiert eine Hose nach der anderen an ... Warum also nicht einfach Jeans selbst nähen? Das ist einfacher, als Sie denken! Buchen Sie unseren Online-Nähkurs für alle. Sie werden überrascht sein, wie viel Freude das Nähen machen kann, wenn Sie Ihre neue Hose in der Hand halten. Infos hier: www.jeans-naehen.net J- Tolle Aufnahmen in einer spektakulären Landschaft – mit etwas technischem Können, viel Feingefühl und – mit ein wenig Glück – ein halbblauer Himmel. Diesen Traum finden Sie an der südlichsten Spitze Deutschlands: Die Rede ist vom Königssee in Bayern – der ideale Ort für unseren Workshop Kurs für Fortgeschrittene, maximal 5 Teilnehmer Leitung: Jenny Holzhausen, Landschaftsfotografin und Buchautorin Termin: Samstag, 04.06.2022, von 9 Uhr bis 17 Uhr, Treffpunkt: Seestraße 3, 83471 Schönau am Königssee ● Hinführung zur Landschaftsfotografie ● Hinführung zur Landschaftsfotografie ● Fotografieren mit natürlichem Licht ● Persönliches Feedback zu den Fotos Es ist ein kalter, verschneiter Wintertag. Da bekommt der junge Kai Besuch von der Schneekönigin, die ihn in ihr eisiges Reich führt. Doch die mutige Gerda versucht alles, um Kai zu retten. Das Familien-Musical Die Schneekönigin basiert auf dem bekannten Märchen von Hans-Christian Andersen. Unter der Regie von Bastian Niemeyer ist eine aufwendige Bühnen-Show entstanden. Kinder ab 5 Jahren und Erwachsene tauchen ein in eine magische Welt und sehen, wie Freundschaft sogar Eis zum Die Schneekönigin – das Musical Der Eiffelturm in Paris, Urlaubsorte der Kindheit, der Wald hinter dem Haus oder das Sofa daheim: An Lieblingsorten fühlt man sich wohl und man besucht diese gerne. Sie inspirieren aber auch Maler, Schriftsteller und Fotografen. Und vielleicht auch Sie? Bei diesem Fotowettbewerb suchen wir Ihre Aufnahmen von besonderen Orten. Belohnt werden die besten Fotos mit tollen Preisen und einer Veröffentlichung in unserem Magazin. Jetzt mitmachen und gewinnen! Einsendeschluss am 30. Juni. Mehr Infos: www.fotomagazin-linse.net",
    "questions": [
      {
        "num": 11,
        "answer": "d",
        "stem": "Die Tochter einer Bekannten wird vier Jahre alt. Sie möchten ihr etwas zum Geburtstag mitbringen."
      },
      {
        "num": 12,
        "answer": "h",
        "stem": "Ein Bekannter hat sich einen Fotoapparat gekauft und möchte die Grundlagen der Fotografie erlernen."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Ein Bekannter möchte eine mehrtägige Reise unternehmen und dabei einen Fotokurs machen."
      },
      {
        "num": 14,
        "answer": "j",
        "stem": "Eine Bekannte kann gut fotografieren und hat bereits einige Kurse gemacht. Sie würde gerne neue kreative Techniken kennenlernen."
      },
      {
        "num": 15,
        "answer": "f",
        "stem": "Ein Freund würde gerne im Winter verreisen. Er möchte viel Zeit an der frischen Luft verbringen und sich bewegen."
      },
      {
        "num": 16,
        "answer": "b",
        "stem": "Eine Freundin hat viele Kleidungsstücke, die sie nicht mehr trägt. Sie sucht Anregungen, was sie damit machen könnte."
      },
      {
        "num": 17,
        "answer": "e",
        "stem": "Sie besuchen einen Freund, der sich für Malerei interessiert. Sie möchten ihm ein passendes Geschenk mitbringen."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Sie fahren gerne Ski und möchten mit Ihrer Familie Wintersport machen."
      },
      {
        "num": 19,
        "answer": "a",
        "stem": "Sie möchten mit Ihrem zwölfjährigen Sohn eine Ausstellung besuchen. Er interessiert sich für Tiieere."
      },
      {
        "num": 20,
        "answer": "c",
        "stem": "Sie treffen sich an einem Sonntagnachmittag mit einer Freundin, die sich gerne mit Mode und ihrer Geschichte beschäftigt. Sie möchten mit ihr etwas unternehmen"
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Expedition ins Reich der Schneeleoparden Schneeleoparden zählen zu den seltensten Großkatzen der Erde. Weltweit leben nur noch 4000 bis 6400 dieser Tiere in freier Wildbahn. Welchen Gefahren sind sie ausgesetzt? Und wie können wir sie schützen? Die interaktive Ausstellung „Expedition Schneeleopard“ nimmt die Besucher mit auf eine Reise in das Reich der seltenen Großkatzen. Mitmach-Aktionen machen die Ausstellung zu einem Erlebnis für Groß und Klein. Die Ausstellung ist bis zum 23. Januar im Zoologischen Forschungsmuseum Bonn, Di bis So von 10 bis 18 Uhr, zu sehen."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Alte Jeans, Blusen oder Kleider – jeder hat sie im Schrank. Ob das gute Stück zu eng, zu weit oder aus der Mode gekommen ist – wegwerfen muss man es deshalb noch lange nicht. Denn aus alten Sachen lässt sich wunderbar Neues kreieren: Vom Stuhlüberzug bis zur Umhängetasche werden in diesem Ratgeber viele Nähprojekte Schritt für Schritt erklärt. So werden aus alten Jeans ganz schnell ein neues Lieblingsstück. Autorin Amélie Betker entwirft seit über fünfzehn Jahren Mode-Accessoires und liebt es, ihr Wissen und ihre Begeisterung fürs Nähen weiterzugeben. Amélie Betker: Aus alt mach neu! Kreative Nähprojekte für ausgediente Kleidungsstücke, Paperback, 144 Seiten, 14,99 €"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Blauer Stoff mit Historie Am 20. Mai 1873 meldete der Amerikaner Levi Strauss das Patent auf die Blue Jeans an. Die Ausstellung „Blue Jeans – von der Arbeitskleidung zum Laufsteg“ zeigt, wie sich die weltberühmte Hose im Laufe der Zeit entwickelte. Präsentiert werden Fotos, Filme und Zeitschriften, alte Jeans-Originale und neue Designerstücke. Modemuseum Düsseldorf 24. November bis 10. März Dienstag bis Sonntag von 10 bis 19 Uhr Eintritt: Erwachsene: 9 Euro Kinder und Jugendliche: 5 Euro"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Es ist ein sonniger Herbsttag, doch plötzlich fällt im Zauberland unerwartet Schnee. Während sich 34 ihre Freunde in das Schneegestöber stürzen, wundert sich Prinzessin Mina: Woher kommt der viele Schnee bloß? Und was ist das für ein kleiner Schneefuchs, den sie am Waldrand gesehen hat? Kurz entschlossen macht sich Prinzessin Mina auf die Suche nach dem kleinen Fuchs. Eine warmherzig erzählte und stimmungsvoll illustrierte Wintergeschichte für kleine und große Prinzessinnen und Prinzen! Elisabeth Heller: Schnee im Zauberland. Für Kinder ab drei Jahren, gebundenes Buch, 52 Seiten, 17,90 €"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Schnee in der Kunst Ein Muss für alle Schneeliebhaber: Der Band zeigt, wie sich Künstler von 1800 bis heute vom Schnee inspirieren ließen. Künstlerischer Ausdruck findet der Schnee in Gemälden der Romantik, des Impressionismus, Symbolismus, Expressionismus und der Neuen Sachlichkeit. Schneefotos von der Frühzeit der Fotografie bis heute sowie ausgewählte Texte zur zeitgenössischen Kunst spannen den Bogen bis in die Gegenwart. Schnee in der Kunst, hrsg. von Nadja Schwenzer, 312 Seiten, 200 Abbildungen, gebunden mit Schutzumschlag, 39,80 €"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Märchenlandschaft aus Schnee und Eis Der beliebte Kurort Oberstdorf liegt am Fuße der Allgäuer Hochalpen. Winterwanderer kommen hier auf ihre Kosten: Auf den Wanderwegen gelangt man schnell in stille, verschneite Landschaften. Wir bieten an: Wanderurlaub in der Gruppe mit fünf leichten bis moderaten Winterwanderungen rund um Oberstdorf. Übernachtung in einem komfortablen Vier-Sterne-Hotel mit Wellnessbereich und Innenpool, 8 Tage mit Halbpension ab 988 € Infos unter: www.winterwanderwoche-oberstdorf.net"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Wintersport im Wandel der Zeit Ob auf Schlitten, Schlittschuhen oder Skiern, von der Haustür oder im Winterurlaub in den Alpen: Sport und Spiel im Schnee und auf dem Eis gehören für viele zu den größten Freizeitfreuden. Die Ausstellung zeigt Winterfotos, die illustrieren, wie sich der Wintersport im letzten Jahrhundert verändert hat. Historische Jahrhunderte zeigen und Dokumente erzählen die Schau, die die kalte Jahreszeit einmal spielerisch zeigt. Erlebnis-Ausstellung für die ganze Familie. Termin: vom 27.11. bis zum 27.02., Dienstag bis Sonntag, von 11 bis 17 Uhr Historisches Museum Prenzlau"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Atemberaubende Fotos leicht gemacht Sie möchten fotografieren lernen? Wir zeigen Ihnen in unserem Online-Fotokurs, dass es gar nicht so schwierig ist, gelungene Fotos zu schießen. In leicht verständlichen Texten und Videos erhalten Sie in unserem Kurs für Anfänger das komplette Basiswissen der Fotografie. Einmalige Zahlung von 147 € für einen unbegrenzten Zugang zum Online-Fotokurs! Zahlung per Lastschrift, Sofortüberweisung, Kreditkarte oder PayPal. Jetzt anmelden: www.nt-pictures.net"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Nähen statt Einkaufsstress Die Suche nach einer perfekt sitzenden Jeans kann manchmal zum Albtraum werden: Stundenlang zieht man durch die Geschäfte, probiert eine Hose nach der anderen an ... Warum also nicht einfach Jeans selbst nähen? Das ist einfacher, als Sie denken! Buchen Sie unseren Online-Nähkurs für alle. Sie werden überrascht sein, wie viel Freude das Nähen machen kann, wenn Sie Ihre neue Hose in der Hand halten. Jetzt anmelden! Infos hier: www.jeans-naehen.net"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Tolle Aufnahmen in einer spektakulären Landschaft – mit etwas technischem Können, viel Feingefühl und – mit ein wenig Glück – ein halbblauer Himmel. Diesen Traum finden Sie an der südlichsten Spitze Deutschlands: Die Rede ist vom Königssee in Bayern – der ideale Ort für unseren Workshop Landschaftsfotografie. Programmpunkte: ● Hinführung zur Landschaftsfotografie ● Hinführung zur Landschaftsfotografie ● Fotografieren mit natürlichem Licht ● Bildkomposition ● Persönliches Feedback zu den Fotos Kurs für Fortgeschrittene, maximal 5 Teilnehmer Leitung: Jenny Holzhausen, Landschaftsfotografin und Buchautorin Termin: Samstag, 04.06.2022, von 9 Uhr bis 17 Uhr, Preis: 99 € Treffpunkt: Seestraße 3, 83471 Schönau am Königssee"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Die Schneekönigin Es ist ein kalter, verschneiter Wintertag. Da bekommt der junge Kai Besuch von der Schneekönigin, die ihn in ihr eisiges Reich führt. Doch die mutige Gerda versucht alles, um Kai zu retten. Das Familien-Musical Die Schneekönigin basiert auf dem bekannten Märchen von Hans-Christian Andersen. Unter der Regie von Bastian Niemeyer ist eine aufwendige Bühnen-Show entstanden. Kinder ab 5 Jahren und Erwachsene tauchen ein in eine magische Welt und sehen, wie Freundschaft sogar Eis zum Schmelzen bringt. Die Schneekönigin – das Musical Konzerthaus Jena Sonntag, 4.12., 15 Uhr Tickets ab 19,95 €"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Lieblingsorte Der Eiffelturm in Paris, Urlaubsorte der Kindheit, der Wald hinter dem Haus oder das Sofa daheim: An Lieblingsorten fühlt man sich wohl und man besucht diese gerne. Sie inspirieren aber auch Maler, Schriftsteller und Fotografen. Und vielleicht auch Sie? Bei diesem Fotowettbewerb suchen wir Ihre Aufnahmen von besonderen Orten. Belohnt werden die besten Fotos mit tollen Preisen und einer Veröffentlichung in unserem Magazin. Jetzt mitmachen und gewinnen! Einsendeschluss am 30. Juni. Mehr Infos: www.fotomagazin-linse.net"
        ]
      }
    ]
  },
  {
    "id": "35",
    "title": "Berlin, Kultur und Film",
    "sourcePage": 337,
    "keywords": "Lesen Sie zuerst die Situationen (11-20) und dann die zwölf Texte (a-1). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Ein Bekannter ist ein paar Tage in Berlin und würde sich gerne verschiedene Kunstausstellungen ansehen. 12 Eine Bekannte träumt davon, selbst einmal bei einem Film Ein Freund würde sich gerne einen Dokumentarfilm über Tiere 14 Eine Freundin sucht einen Nebenjob. Sie würde dabei gerne viel Zeit draußen verbringen. Ihr Cousin ist Student und sucht für die Sommermonate einen 16 Ihre achtjährige Nichte interessiert sich für Tiere und Natur. Sie möchten ihr zum Geburtstag ein Buch schenken. 17 Sie möchten eine besondere Stadtführung in Berlin buchen. Sie möchten mit Freunden einen unterhaltsamen Film 19 Sie sind zu einer Kostüm-Party eingeladen und brauchen dafür 20 Sie würden gerne mit Freunden eine mehrtägige Städtetour machen und suchen ein Angebot. A- Das Comedy Filmfest tourt auch dieses Jahr durch Deutschland. In Berlin startet es am 14. August mit der belgischen Produktion „Schokolade und Pommes frites“. In dieser romantischen Komödie treffen zwei Charaktere aufeinander, die unterschiedlicher kaum sein könnten: Die zielstrebige, doch ein wenig schüchterne Marie hat sich mit einem kleinen Schokoladengeschäft ihren größten Traum verwirklicht. Alles läuft gut, bis auf der anderen Straßenseite der chaotische Lebenskünstler Michel einen Schnellimbiss eröffnet und Maries Leben reichlich durcheinanderwirbelt. „Schokolade und Pommes frites“, 14. August, 20 Uhr, Filmtheater Friedrichshain B- Als die Bilder laufen lernten Dieser Band lädt Sie ein, eine bewegte Kinogeschichte zu entdecken. In den Jahren von 1895 bis 1930 entwickelte sich das Kino in atemberaubendem Tempo zur Unterhaltungsmedien schlechthin. Autorin Greta Valentino geht zurück bis zu den ersten Filmen der Brüder Lumière und den Anfängen des Westerns und taucht anschließend ein in das aufregende 1920er Jahre, als der Stummfilm seine goldene Ära feierte und Filmpaläste wie Pilze aus dem Boden schossen. Die Autorin studierte Kunstgeschichte in Paris und Amsterdam. Sie veröffentlichte Bücher sowie zahlreiche Artikel über Kunst und Kino. Greta Valentino: Die Geburt des Kinos: Von der Erfindung des Films zum frühen Tonfilm, 220 Unsere Reise führt Sie in eine der abwechslungsreichsten Städte Deutschlands: Berlin. Mit historischen Bauwerken und Museen, breiten Prachtstraßen und Einkaufstempeln sowie vielfältigeren Parks und Gärten hat die Hauptstadt für jeden etwas zu bieten. Sie bequem mit der Deutschen Bahn und verbringen Sie aufregende Tage in Berlin. Übernachtung mit Frühstück im Hotel. Dauer: ab 4 Tage (Verlängerung möglich) Preis: ab 437 Euro pro Person im Doppelzimmer inklusive An- und Abreise mit der Im März beginnen die Dreharbeiten für den Film „Berlin Gendarmenmarkt“. Erzählt wird die Geschichte der sechzehnjährigen Ida, die Jugend und Erwachsenwerden im Berlin der Goldenen Zwanziger erlebt und von einer großen Karriere auf der Theaterbühne träumt. Die Romanvorlage für den Film lieferte die Schriftstellerin Marie Franck. Für kleinere Filmrollen oder als Komparsen werden noch Mitwirkende jeden Alters gesucht. Die Gage beträgt 75 € pro Drehtag. Bewerbungsschluss ist der 16. November. Infos und Bewerbung unter: www.film-gendarmenmarkt.info/casting E-Berlin in den Zwanziger Jahren Dreigroschenoper, Bubikopf, Dada, Bauhausarchitektur: Dieser Bildband erweckt das Berlin in den 1920ern wieder zum Leben. In dieser Dekade war Berlin eine moderne, von Fortschritt und Freiheit berauschte Weltstadt, die für Künstler und Intellektuelle zum Sehnsuchtsort wurde. Autor Gereon Kutscher nimmt Sie mit auf einen Streifzug durch eine Epoche der kulturellen Blüte und der Lebenslust. Gereon Kutscher: Berlin in den Zwanziger Jahren, Hardcover, 126 Seiten, 28 € Ob Meisterwerke der Kunst, archäologische Schätze aus sechs Jahrtausenden oder technische Errungenschaften – das alles finden Sie in den Berliner Museen. Mit dem Museumspass öffnen sich Ihnen die Türen von über 30 Häusern, darunter die Alte Nationalgalerie, das Pergamonmuseum, das Museum für Naturkunde und die Neue Nationalgalerie. An drei aufeinanderfolgenden Tagen haben Sie damit freien Eintritt. Preis: 29 €, ermäßigt 14,50 € Ticket hier online kaufen: Entdecken Sie bei einem Rundgang, wie sich das Leben auf unserem Planeten entwickelt hat. Staunen Sie über Urzeitrieder, das weltweit größte Skelett eines Dinosauriers und eines Eisbären. Doch im Museum für Naturkunde in Berlin gibt es noch viele weitere spannende Exponate zu Für Kinder ab 5 Jahren, Jugendliche und Erwachsene bieten wir Führungen zu verschiedenen Eintritt: 8 €, ermäßigt 5 € Öffnungszeiten: Di bis Fr: 9:30 – 18 Uhr, Samstag, Sonntag und Feiertage 10 – 18 Uhr Museum für Naturkunde Berlin, Invalidenstr. 43, 10115 Berlin H- Stadtführungen in Berlin Sie erzählen gerne spannende Geschichten, sind gut zu Fuß und lieben es, andere für besondere Orte zu begeistern? Dann sind Sie bei uns richtig. Wir bieten Stadtführungen in Berlin an und suchen für eine langfristige Zusammenarbeit (mindestens ein Jahr) neue Kollegen und Kolleginnen! Wenn Sie gut mit Menschen umgehen können und kommunikativ sind, können Sie direkt bei uns als Stadtführer anfangen. Job auf 450-€-Basis, freie Zeiteinteilung, auch für Freelancer möglich. Interesse? Bewerben Sie sich hier: info@berlintouren-kraemer.net İ - Feiern wie in den Goldenen Zwanzigern Ein ausgelassenes Lebensgefühl und rauschende Nächte: So stellt man sich die 1920er Jahre vor, in die Filme wie „Der große Gatsby“ und Serien wie „Babylon Berlin“ immer wieder einladen. Erleben Sie die glamouröse Zeitreise und lassen Sie die 1920er Jahre als Wiederaufleben. Wir haben einen Online-Shop finden Sie alles, was Sie für ein glänzendes Auftreten auf Ihrer Feier und im Alltag brauchen: Pailettenkleider und Kopfschmuck für Damen, Westen und Anzüge für Herren und Accessoires sowie Dekorartikel. J- Das etwas gemütlichere Berlin Der wenig bekannte Berliner Stadtteil Friedenau ist bis heute eher ein Geheimtipp: Das Viertel besteht durch prächtige geschmackvolle Wohnhäuser, kleine Villen und eine bunt gelebte Gastronomie. Kommen Sie mit auf eine kulinarisch-kulturelle Führung durch das charmante, ruhige Friedenau. Erfahren Sie mehr über die berühmten Geschlechter dieses Stadtviertels, entdecken Sie wunderschöne Altbauwohnungen und lernen Sie die beeindruckendsten Café-Häuser kennen. Unsere erfahrenen Stadtführer zeigen Ihnen die spannenden Orte zum Genießen, zum Beispiel ein kleines italienisches Café, eine koreanische Snack-Bar und ein marokkanisches Bistro. 3 Stunden, ca. 3 km zu Fuß Preis: 39 €, ermäßigt 20 € Anmeldung unter: www.friedenau-touren.net Dann machen Sie doch das Kino zu Ihrem Arbeitsplatz! Sie sind ein echter Filmfan und lieben Teamarbeit? Das Metropolis Filmtheater Altenberg sucht eine Aushilfe als Urlaubsvertretung für die Monate Juli und August, 25 Stunden pro Woche. Zu Ihren Aufgaben gehören u. a. der Verkauf von Kinokarten, Popcorn und Getränken sowie die Eintrittskontrolle und die Vorbereitung der Sale. Sie sind volljährig, zuverlässig und bereit, auch am Abend oder Wochenende zu arbeiten? Dann freuen wir uns auf Ihre Bewerbung mit kurzem Anschreiben und Lebenslauf per E-Mail. Metropolis Kino Altenberg info@metropolis-altenberg.net L- Wer hat die Kokosnuss geklaut? Bei dieser Tour geht es ins Affenhaus! Beobachten Sie Gorillas, Paviane und Co. bei der Futterzeit und finde heraus, was sie am liebsten fressen. Natürlich bleibt noch Zeit, bei anderen Zoo-Bewohnern vorbeizuschauen. Geh zusammen mit einem Guide auf eine besondere Entdeckungstour durch den Zoo Berlin. Spannende Tier-Fakten und exklusive Einblicke in den Zoo-Alltag warten auf dich! Führung für Kinder ab 8 Jahren. Zoologischer Garten Berlin, Hardenbergplatz 8, 10787 Berlin Eintritt: Erwachsene 17,50 €, Kinder 9 €",
    "questions": [
      {
        "num": 11,
        "answer": "f",
        "stem": "Ein Bekannter ist ein paar Tage in Berlin und würde sich gerne verschiedene Kunstausstellungen ansehen."
      },
      {
        "num": 12,
        "answer": "d",
        "stem": "Eine Bekannte träumt davon, selbst einmal bei einem Film mitzuspielen."
      },
      {
        "num": 13,
        "answer": "x",
        "stem": "Ein Freund würde sich gerne einen Dokumentarfilm über Tiere ansehen."
      },
      {
        "num": 14,
        "answer": "h",
        "stem": "Eine Freundin sucht einen Nebenjob. Sie würde dabei gerne viel Zeit draußen verbringen."
      },
      {
        "num": 15,
        "answer": "k",
        "stem": "Ihr Cousin ist Student und sucht für die Sommermonate einen Nebenjob."
      },
      {
        "num": 16,
        "answer": "x",
        "stem": "Ihre achtjährige Nichte interessiert sich für Tiere und Natur. Sie möchten ihr zum Geburtstag ein Buch schenken."
      },
      {
        "num": 17,
        "answer": "j",
        "stem": "Sie möchten eine besondere Stadtführung in Berlin buchen."
      },
      {
        "num": 18,
        "answer": "a",
        "stem": "Sie möchten mit Freunden einen unterhaltsamen Film anschauen."
      },
      {
        "num": 19,
        "answer": "i",
        "stem": "Sie sind zu einer Kostüm-Party eingeladen und brauchen dafür etwas zum Anziehen."
      },
      {
        "num": 20,
        "answer": "c",
        "stem": "Sie würden gerne mit Freunden eine mehrtägige Städtetour machen und suchen ein Angebot."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Das Comedy Filmfest tourt auch dieses Jahr durch Deutschland. In Berlin startet es am 14. August mit der belgischen Produktion „Schokolade und Pommes frites“. In dieser romantischen Komödie treffen zwei Charaktere aufeinander, die unterschiedlicher kaum sein könnten: Die zielstrebige, doch ein wenig schüchterne Marie hat sich mit einem kleinen Schokoladengeschäft ihren größten Traum verwirklicht. Alles läuft gut, bis auf der anderen Straßenseite der chaotische Lebenskünstler Michel einen Schnellimbiss eröffnet und Maries Leben reichlich durcheinanderwirbelt. „Schokolade und Pommes frites“, 14. August, 20 Uhr, Filmtheater Friedrichshain"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Als die Bilder laufen lernten Dieser Band lädt Sie ein, eine bewegte Kinogeschichte zu entdecken. In den Jahren von 1895 bis 1930 entwickelte sich das Kino in atemberaubendem Tempo zur Unterhaltungsmedien schlechthin. Autorin Greta Valentino geht zurück bis zu den ersten Filmen der Brüder Lumière und den Anfängen des Westerns und taucht anschließend ein in das aufregende 1920er Jahre, als der Stummfilm seine goldene Ära feierte und Filmpaläste wie Pilze aus dem Boden schossen. Die Autorin studierte Kunstgeschichte in Paris und Amsterdam. Sie veröffentlichte Bücher sowie zahlreiche Artikel über Kunst und Kino. Greta Valentino: Die Geburt des Kinos: Von der Erfindung des Films zum frühen Tonfilm, 220 Seiten, 24 €"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Berlin erleben Unsere Reise führt Sie in eine der abwechslungsreichsten Städte Deutschlands: Berlin. Mit historischen Bauwerken und Museen, breiten Prachtstraßen und Einkaufstempeln sowie vielfältigeren Parks und Gärten hat die Hauptstadt für jeden etwas zu bieten. Sie bequem mit der Deutschen Bahn und verbringen Sie aufregende Tage in Berlin. Übernachtung mit Frühstück im Hotel. Dauer: ab 4 Tage (Verlängerung möglich) Preis: ab 437 Euro pro Person im Doppelzimmer inklusive An- und Abreise mit der Deutschen Bahn Mehr Infos unter: www.bergmann-reisen.info"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Berlin Gendarmenmarkt Im März beginnen die Dreharbeiten für den Film „Berlin Gendarmenmarkt“. Erzählt wird die Geschichte der sechzehnjährigen Ida, die Jugend und Erwachsenwerden im Berlin der Goldenen Zwanziger erlebt und von einer großen Karriere auf der Theaterbühne träumt. Die Romanvorlage für den Film lieferte die Schriftstellerin Marie Franck. Für kleinere Filmrollen oder als Komparsen werden noch Mitwirkende jeden Alters gesucht. Die Gage beträgt 75 € pro Drehtag. Bewerbungsschluss ist der 16. November. Infos und Bewerbung unter: www.film-gendarmenmarkt.info/casting"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Berlin in den Zwanziger Jahren Dreigroschenoper, Bubikopf, Dada, Bauhausarchitektur: Dieser Bildband erweckt das Berlin in den 1920ern wieder zum Leben. In dieser Dekade war Berlin eine moderne, von Fortschritt und Freiheit berauschte Weltstadt, die für Künstler und Intellektuelle zum Sehnsuchtsort wurde. Autor Gereon Kutscher nimmt Sie mit auf einen Streifzug durch eine Epoche der kulturellen Blüte und der Lebenslust. Gereon Kutscher: Berlin in den Zwanziger Jahren, Hardcover, 126 Seiten, 28 €"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Eine Karte, 30 Häuser Ob Meisterwerke der Kunst, archäologische Schätze aus sechs Jahrtausenden oder technische Errungenschaften – das alles finden Sie in den Berliner Museen. Mit dem Museumspass öffnen sich Ihnen die Türen von über 30 Häusern, darunter die Alte Nationalgalerie, das Pergamonmuseum, das Museum für Naturkunde und die Neue Nationalgalerie. An drei aufeinanderfolgenden Tagen haben Sie damit freien Eintritt. Preis: 29 €, ermäßigt 14,50 € Ticket hier online kaufen: https://shop.nmg.museum"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Museum für Naturkunde Entdecken Sie bei einem Rundgang, wie sich das Leben auf unserem Planeten entwickelt hat. Staunen Sie über Urzeitrieder, das weltweit größte Skelett eines Dinosauriers und eines Eisbären. Doch im Museum für Naturkunde in Berlin gibt es noch viele weitere spannende Exponate zu entdecken. Für Kinder ab 5 Jahren, Jugendliche und Erwachsene bieten wir Führungen zu verschiedenen Themen an. Eintritt: 8 €, ermäßigt 5 € Öffnungszeiten: Di bis Fr: 9:30 – 18 Uhr, Samstag, Sonntag und Feiertage 10 – 18 Uhr Museum für Naturkunde Berlin, Invalidenstr. 43, 10115 Berlin"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Stadtführungen in Berlin Sie erzählen gerne spannende Geschichten, sind gut zu Fuß und lieben es, andere für besondere Orte zu begeistern? Dann sind Sie bei uns richtig. Wir bieten Stadtführungen in Berlin an und suchen für eine langfristige Zusammenarbeit (mindestens ein Jahr) neue Kollegen und Kolleginnen! Wenn Sie gut mit Menschen umgehen können und kommunikativ sind, können Sie direkt bei uns als Stadtführer anfangen. Job auf 450-€-Basis, freie Zeiteinteilung, auch für Freelancer möglich. Interesse? Bewerben Sie sich hier: info@berlintouren-kraemer.net"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Feiern wie in den Goldenen Zwanzigern Ein ausgelassenes Lebensgefühl und rauschende Nächte: So stellt man sich die 1920er Jahre vor, in die Filme wie „Der große Gatsby“ und Serien wie „Babylon Berlin“ immer wieder einladen. Erleben Sie die glamouröse Zeitreise und lassen Sie die 1920er Jahre als Wiederaufleben. Wir haben einen Online-Shop finden Sie alles, was Sie für ein glänzendes Auftreten auf Ihrer Feier und im Alltag brauchen: Pailettenkleider und Kopfschmuck für Damen, Westen und Anzüge für Herren und Accessoires sowie Dekorartikel. www.golden20.com"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Das etwas gemütlichere Berlin Der wenig bekannte Berliner Stadtteil Friedenau ist bis heute eher ein Geheimtipp: Das Viertel besteht durch prächtige geschmackvolle Wohnhäuser, kleine Villen und eine bunt gelebte Gastronomie. Kommen Sie mit auf eine kulinarisch-kulturelle Führung durch das charmante, ruhige Friedenau. Erfahren Sie mehr über die berühmten Geschlechter dieses Stadtviertels, entdecken Sie wunderschöne Altbauwohnungen und lernen Sie die beeindruckendsten Café-Häuser kennen. Unsere erfahrenen Stadtführer zeigen Ihnen die spannenden Orte zum Genießen, zum Beispiel ein kleines italienisches Café, eine koreanische Snack-Bar und ein marokkanisches Bistro. 3 Stunden, ca. 3 km zu Fuß Preis: 39 €, ermäßigt 20 € Anmeldung unter: www.friedenau-touren.net"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Sie lieben Filme? Dann machen Sie doch das Kino zu Ihrem Arbeitsplatz! Sie sind ein echter Filmfan und lieben Teamarbeit? Das Metropolis Filmtheater Altenberg sucht eine Aushilfe als Urlaubsvertretung für die Monate Juli und August, 25 Stunden pro Woche. Zu Ihren Aufgaben gehören u. a. der Verkauf von Kinokarten, Popcorn und Getränken sowie die Eintrittskontrolle und die Vorbereitung der Sale. Sie sind volljährig, zuverlässig und bereit, auch am Abend oder Wochenende zu arbeiten? Dann freuen wir uns auf Ihre Bewerbung mit kurzem Anschreiben und Lebenslauf per E-Mail. Metropolis Kino Altenberg info@metropolis-altenberg.net"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Wer hat die Kokosnuss geklaut? Bei dieser Tour geht es ins Affenhaus! Beobachten Sie Gorillas, Paviane und Co. bei der Futterzeit und finde heraus, was sie am liebsten fressen. Natürlich bleibt noch Zeit, bei anderen Zoo-Bewohnern vorbeizuschauen. Geh zusammen mit einem Guide auf eine besondere Entdeckungstour durch den Zoo Berlin. Spannende Tier-Fakten und exklusive Einblicke in den Zoo-Alltag warten auf dich! Führung für Kinder ab 8 Jahren. Zoologischer Garten Berlin, Hardenbergplatz 8, 10787 Berlin Eintritt: Erwachsene 17,50 €, Kinder 9 €"
        ]
      }
    ]
  },
  {
    "id": "36",
    "title": "Umzug, Jobs und Alltag in Wien",
    "sourcePage": 342,
    "keywords": "90 Minuten Lesen und Sprachbausteine Lesen Sie zuerst die zehn Situationen (11–20) und dann die zwölf Infotexte (a–l). Welcher Infotext passt zu welcher Situation? Sie können jeden Infotext nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 Sie ziehen um und brauchen Hilfe, weil Sie ein Klavier haben. 12 Ihr Sohn sucht eine Tätigkeit in Wien. Sie kann auch unentgeltlich sein. 13 Für den Geburtstag eines Freundes suchen Sie Musiker, die aktuelle Hits spielen. 14 Sie möchten Ihre Heizkosten reduzieren. 15 Ihre Tochter möchte in Wien Geld verdienen. 16 Sie sind umweltbewusst, möchten aber nicht aufs Auto verzichten, und suchen Informationen. 17 Sie möchten sich über Energie sparende Haushaltsgeräte informieren. 18 Sie möchten Klavier studieren und suchen nach Informationen. 19 Sie möchten Ihren alten Kühlschrank entsorgen. Sie hatten vor kurzem einen Stromausfall und möchten wissen, ob es an den Anschlüssen in 90 Minuten Lesen und Sprachbausteine „Mobilität der Zukunft“ lautet der Titel eines The- menabends an der Universität Wien, den alle inte- ressierten Bürgerinnen und Bürger kostenlos be- suchen können. Mehrere Vorträge sowie eine Ausstellung befassen sich damit, wie wir uns in einhundert Jahren fortbewegen werden. Mobilität vorbei und lassen Sie sich überraschen! wird immer wichtiger, sowohl im Beruf als auch pri- Oft sind in den Häusern noch alte Leitungen und Anschlüsse verbaut, die eine ständige Gefahren- quelle darstellen. Dabei entsteht nicht nur materi- diese überhaupt noch zeitgemäß sind. Denken Sie daran: Ohne Überprüfung kann es Probleme ge- eller Verlust; bei Brandfällen sind oft Leib und Le- ben gefährdet. Wir prüfen die Leitungen und Anschlüsse für Strom oder Gas in Ihrem Haushalt Ihr neues Energie sparendes Gerät ist bestellt, doch wohin mit dem alten Strom-Fresser? Reparieren statt Wegwerfen ist die erste Möglichkeit, die um- weltfreundliche Entsorgung die zweite. Dass große Elektrogeräte nichts im Hausmüll verloren haben und schon gar nichts in der freien Natur, ist klar. Alte Ge- räte sind in Wahrheit wichtige Rohstofflieferanten, die gesammelt und danach verwertet werden müs- sen. Geräte, deren Seitenlänge länger als 50 cm ist, chen Sammelstellen abgegeben werden. Die breite und gute Klavierausbildung hat an unserer Hochschule langjährige Tradition. Grundstock der Ausbildung ist ein hervorragender Lehrkörper von internationalem Ruf genauso wie optimale Studien- Der neue Bachelorstudiengang Klavier vereint ab dem Wintersemester die alten Ausbildungswege „Musikerziehung“ und „Künstlerische Ausbildung“ in einem Y-Modell. An der außerordentlichen Qualität Sie mögen Jazz, Rock, Pop? Livemusik hat Sie schon immer begeistert und Sie mögen die ange- sagten Songs von heute? Dann haben wir vielleicht das richtige Angebot für Sie: Junge und jung ge- bliebene Musiker spielen bei Ihrer Firmenfeier oder Das Klima ändert sich und die Winter werden im- mer milder – dennoch zahlen Sie immer mehr für das Heizen Ihrer Wohnung oder Ihres Hauses? Ihnen gegen geringes Entgelt einen umfassenden Vergleich unter zahlreichen Anbietern aus ganz Ös- Das Problem könnten zwar veraltete oder auch de- fekte Geräte sein, aber meist scheuen Verbraucher einfach den Vergleich unter vielen Anbietern und vat, und es stellen sich verschiedene Fragen: Wird es überhaupt noch Fahrräder geben? Besitzt viel- leicht jeder ein kleines Flugzeug oder einen Heli- kopter? Und wird der Weltraum das neue Urlaubs- ziel für die breite Bevölkerung sein? Kommen Sie sorgfältig und informieren Sie auch darüber, ob ben und plötzlich haben Sie keinen Strom mehr in Ihrer Wohnung oder Ihrem Haus. Handeln Sie jetzt! also beispielsweise Waschmaschinen, E-Herde, Bildschirmgeräte, Kühlschränke, Geschirrspüler etc., werden meist bestellt und dann vom Händler geliefert. Jeder Händler oder Lieferant ist bei Liefe- rung verpflichtet, die entsprechenden alten Geräte kostenlos mitzunehmen und zu verwerten. Wenn Geräte übers Internet bestellt werden oder über den Versandhandel, können sie kostenfrei bei öffentli- der Lehre im Einzel- und Gruppenunterricht wird sich dabei nichts ändern. Ein weiterführender Masterstu- diengang wird zum Wintersemester angeboten wer- Weiterführende Informationen zum Studienangebot erhalten Sie zunächst beim Immatrikulationsamt oder bei den Lehrenden des Faches Klavier. auch auf privaten Festen. Sie teilen uns mit, welche Musikrichtung Sie wünschen, um alles andere kümmern wir uns dann – gute Laune inklusive! Wir vermitteln einzelne Musiker/Musikerinnen sowie zahlen dadurch mehr, als sie müssten. Wir bieten terreich an, zugeschnitten auf Ihre persönlichen Bedürfnisse. Investieren Sie nur wenige Euro und sparen Sie dafür in den nächsten Jahren dauerhaft! 90 Minuten Lesen und Sprachbausteine Mit Musik geht vieles leichter! Wenn Sie diese An- ein Chor aus netten Menschen aller Altersgruppen sicht teilen und ebenso wie wir Freude am Musizie- und wir singen sowohl klassische als auch moder- ren haben, sind Sie herzlich eingeladen, bei einer ne Lieder. Proben sind jeden Mittwoch und Sonn- unserer Proben vorbeizuschauen. Vielleicht möch- ten Sie ja dann auch gleich mitmachen? Wir sind Sie sind häufig ohne Energie? Sie fühlen sich kraft- Sie Energie „auftanken“? Wir geben Ihnen in Se- los, müde, möchten nur noch schlafen? Wir bieten minaren praktische Tipps für Ihren Alltag, sowohl eine umfassende Energieberatung an, bei der der für das Arbeits- als auch das Privatleben. Unsere Mensch im Mittelpunkt steht: Welche Tätigkeiten Unterlagen sind auch als Buch in jeder guten Buch- rauben Ihnen besonders viel Energie? Wo können Verstärker, Orgel, Klavier, Schlagzeug oder andere len namhafte Orchester und Opernhäuser ebenso große Instrumente sind für Sie ein Problem? Für wie Musikhandel und Messeveranstalter. Aber uns nicht! Seit über fünf Jahrzehnten transportieren auch für Privatkunden haben wir immer das pas- wir große Musikinstrumente zuverlässig und sicher innerhalb von Österreich. Zu unseren Kunden zäh- sende Angebot, sprechen Sie uns an! Musik ist Ihr Hobby oder vielleicht sogar Ihr Beruf? terricht für alle Altersstufen an. Hilfe brauchen wir z. Wenn Sie sich für Musik interessieren, sollten wir B. bei der Organisation und Betreuung von Som- uns kennenlernen: Die neue Wiener Musikschule merkursen für Kinder, beim Verteilen von Werbe- „Mandoline“ sucht ehrenamtliche Helfer in ver- material, bei der Pflege von Instrumenten oder auch schiedenen Bereichen. Wir sind ein junges, dyna- mal im Unterricht. Vorkenntnisse sind nicht erfor- misches, freundliches Team und bieten Musikun- Einzelne Busse in Wien fahren bald mit Elektroan- trieb und sind dann noch umweltfreundlicher. Die Verkehrsbetriebe arbeiten nun mit Hochdruck an einem neuen Konzept für alle, die nicht vom Auto auf den Bus oder die Tram umsteigen möchten: Schon in wenigen Monaten soll es möglich sein, sich an vielen Orten in Wien und später auch in anderen österreichischen Städten Elektroautos zu Klavier, sehr günstig! Aufgrund eines Umzugs ins Ausland gebe ich mein gut erhaltenes Klavier (ca. 10 Jahre) ab. Farbe schwarz (Lack), Zustand sehr gut. Mein Umzugsunternehmen könnte das Klavier auch gegen einen geringen Aufpreis zu Ihnen nach (Quellen der Anzeigen a-l: österreichische Tageszeitungen, zu Prüfungszwecken bearbeitet) derlich, wichtig sind Freundlichkeit und Offenheit. leihen – und zwar auch nur für eine halbe Stunde. So können Sie Ihren Einkauf rasch erledigen und tun gleichzeitig noch etwas für die Umwelt. Das neue Konzept soll eine echte Alternative zum Kauf eines Elektroautos sein, denn diese sind nach wie vor sehr teuer. Weitere Informationen erhalten Sie auch bei den Verkehrsbetrieben oder der Stadt Hause bringen (nur innerhalb von Wien möglich). Besichtigung und Probespielen gerne jeden Tag ab ca. 18 Uhr, eine telefonische Terminvereinba- rung wäre schön. Natürlich beantworte ich auch",
    "questions": [
      {
        "num": 11,
        "answer": "i",
        "stem": "Sie ziehen um und brauchen Hilfe, weil Sie ein Klavier haben."
      },
      {
        "num": 12,
        "answer": "j",
        "stem": "Ihr Sohn sucht eine Tätigkeit in Wien. Sie kann auch unentgeltlich sein."
      },
      {
        "num": 13,
        "answer": "e",
        "stem": "Für den Geburtstag eines Freundes suchen Sie Musiker, die aktuelle Hits spielen."
      },
      {
        "num": 14,
        "answer": "f",
        "stem": "Sie möchten Ihre Heizkosten reduzieren."
      },
      {
        "num": 15,
        "answer": "x",
        "stem": "Ihre Tochter möchte in Wien Geld verdienen."
      },
      {
        "num": 16,
        "answer": "k",
        "stem": "Sie sind umweltbewusst, möchten aber nicht aufs Auto verzichten, und suchen Informationen."
      },
      {
        "num": 17,
        "answer": "x",
        "stem": "Sie möchten sich über Energie sparende Haushaltsgeräte informieren."
      },
      {
        "num": 18,
        "answer": "d",
        "stem": "Sie möchten Klavier studieren und suchen nach Informationen."
      },
      {
        "num": 19,
        "answer": "c",
        "stem": "Sie möchten Ihren alten Kühlschrank entsorgen."
      },
      {
        "num": 20,
        "answer": "b",
        "stem": "Sie hatten vor kurzem einen Stromausfall und möchten wissen, ob es an den Anschlüssen in Ihrer Wohnung lag."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "„Mobilität der Zukunft“ lautet der Titel eines Themenabends an der Universität Wien, den alle interessierten Bürgerinnen und Bürger kostenlos besuchen können. Mehrere Vorträge sowie eine Ausstellung befassen sich damit, wie wir uns in einhundert Jahren fortbewegen werden. Mobilität wird immer wichtiger, sowohl im Beruf als auch pri-",
          "vat, und es stellen sich verschiedene Fragen: Wird es überhaupt noch Fahrräder geben? Besitzt vielleicht jeder ein kleines Flugzeug oder einen Helikopter? Und wird der Weltraum das neue Urlaubsziel für die breite Bevölkerung sein? Kommen Sie vorbei und lassen Sie sich überraschen!"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Oft sind in den Häusern noch alte Leitungen und Anschlüsse verbaut, die eine ständige Gefahrenquelle darstellen. Dabei entsteht nicht nur materieller Verlust; bei Brandfällen sind oft Leib und Leben gefährdet. Wir prüfen die Leitungen und Anschlüsse für Strom oder Gas in Ihrem Haushalt",
          "sorgfältig und informieren Sie auch darüber, ob diese überhaupt noch zeitgemäß sind. Denken Sie daran: Ohne Überprüfung kann es Probleme geben und plötzlich haben Sie keinen Strom mehr in Ihrer Wohnung oder Ihrem Haus. Handeln Sie jetzt!",
          "Lesen"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "Ihr neues Energie sparendes Gerät ist bestellt, doch wohin mit dem alten Strom-Fresser? Reparieren statt Wegwerfen ist die erste Möglichkeit, die umweltfreundliche Entsorgung die zweite. Dass große Elektrogeräte nichts im Hausmüll verloren haben und schon gar nichts in der freien Natur, ist klar. Alte Geräte sind in Wahrheit wichtige Rohstofflieferanten, die gesammelt und danach verwertet werden müssen. Geräte, deren Seitenlänge länger als 50 cm ist,",
          "also beispielsweise Waschmaschinen, E-Herde, Bildschirmgeräte, Kühlschränke, Geschirrspüler etc., werden meist bestellt und dann vom Händler geliefert. Jeder Händler oder Lieferant ist bei Lieferung verpflichtet, die entsprechenden alten Geräte kostenlos mitzunehmen und zu verwerten. Wenn Geräte übers Internet bestellt werden oder über den Versandhandel, können sie kostenfrei bei öffentlichen Sammelstellen abgegeben werden."
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Die breite und gute Klavierausbildung hat an unserer Hochschule langjährige Tradition. Grundstock der Ausbildung ist ein hervorragender Lehrkörper von internationalem Ruf genauso wie optimale Studienbedingungen.",
          "Der neue Bachelorstudiengang Klavier vereint ab dem Wintersemester die alten Ausbildungswege „Musikerziehung“ und „Künstlerische Ausbildung“ in einem Y-Modell. An der außerordentlichen Qualität",
          "der Lehre im Einzel- und Gruppenunterricht wird sich dabei nichts ändern. Ein weiterführender Masterstudiengang wird zum Wintersemester angeboten werden.",
          "Weiterführende Informationen zum Studienangebot erhalten Sie zunächst beim Immatrikulationsamt oder bei den Lehrenden des Faches Klavier."
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Sie mögen Jazz, Rock, Pop? Livemusik hat Sie schon immer begeistert und Sie mögen die angesagten Songs von heute? Dann haben wir vielleicht das richtige Angebot für Sie: Junge und jung gebliebene Musiker spielen bei Ihrer Firmenfeier oder",
          "auch auf privaten Festen. Sie teilen uns mit, welche Musikrichtung Sie wünschen, um alles andere kümmern wir uns dann - gute Laune inklusive! Wir vermitteln einzelne Musiker/Musikerinnen sowie Musikgruppen."
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Das Klima ändert sich und die Winter werden immer milder - dennoch zahlen Sie immer mehr für das Heizen Ihrer Wohnung oder Ihres Hauses? Das Problem könnten zwar veraltete oder auch defekte Geräte sein, aber meist scheuen Verbraucher einfach den Vergleich unter vielen Anbietern und",
          "zahlen dadurch mehr, als sie müssten. Wir bieten Ihnen gegen geringes Entgelt einen umfassenden Vergleich unter zahlreichen Anbietern aus ganz Österreich an, zugeschnitten auf Ihre persönlichen Bedürfnisse. Investieren Sie nur wenige Euro und sparen Sie dafür in den nächsten Jahren dauerhaft!"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "Mit Musik geht vieles leichter! Wenn Sie diese Ansicht teilen und ebenso wie wir Freude am Musizieren haben, sind Sie herzlich eingeladen, bei einer unserer Proben vorbeizuschauen. Vielleicht möchten Sie ja dann auch gleich mitmachen? Wir sind",
          "ein Chor aus netten Menschen aller Altersgruppen und wir singen sowohl klassische als auch moderne Lieder. Proben sind jeden Mittwoch und Sonntag, jeweils ab 19 Uhr."
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Sie sind häufig ohne Energie? Sie fühlen sich kraft- Ios, müde, möchten nur noch schlafen? Wir bieten eine umfassende Energieberatung an, bei der der Mensch im Mittelpunkt steht: Welche Tätigkeiten rauben Ihnen besonders viel Energie? Wo können",
          "Sie Energie „auftanken“? Wir geben Ihnen in Seminaren praktische Tipps für Ihren Alltag, sowohl für das Arbeits- als auch das Privatleben. Unsere Unterlagen sind auch als Buch in jeder guten Buchhandlung erhältlich."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Verstärker, Orgel, Klavier, Schlagzeug oder andere große Instrumente sind für Sie ein Problem? Für uns nicht! Seit über fünf Jahrzehnten transportieren wir große Musikinstrumente zuverlässig und sicher innerhalb von Österreich. Zu unseren Kunden zäh-",
          "len namhafte Orchester und Opernhäuser ebenso wie Musikhandel und Messeveranstalter. Aber auch für Privatkunden haben wir immer das passende Angebot, sprechen Sie uns an!"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Musik ist Ihr Hobby oder vielleicht sogar Ihr Beruf? Wenn Sie sich für Musik interessieren, sollten wir uns kennenlernen: Die neue Wiener Musikschule „Mandoline“ sucht ehrenamtliche Helfer in verschiedenen Bereichen. Wir sind ein junges, dynamisches, freundliches Team und bieten Musikun-",
          "terricht für alle Altersstufen an. Hilfe brauchen wir z. B. bei der Organisation und Betreuung von Sommerkursen für Kinder, beim Verteilen von Werbematerial, bei der Pflege von Instrumenten oder auch mal im Unterricht. Vorkenntnisse sind nicht erforderlich, wichtig sind Freundlichkeit und Offenheit."
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Einzelne Busse in Wien fahren bald mit Elektroantrieb und sind dann noch umweltfreundlicher. Die Verkehrsbetriebe arbeiten nun mit Hochdruck an einem neuen Konzept für alle, die nicht vom Auto auf den Bus oder die Tram umsteigen möchten: Schon in wenigen Monaten soll es möglich sein, sich an vielen Orten in Wien und später auch in anderen österreichischen Städten Elektroautos zu",
          "leihen - und zwar auch nur für eine halbe Stunde. So können Sie Ihren Einkauf rasch erledigen und tun gleichzeitig noch etwas für die Umwelt. Das neue Konzept soll eine echte Alternative zum Kauf eines Elektroautos sein, denn diese sind nach wie vor sehr teuer. Weitere Informationen erhalten Sie auch bei den Verkehrsbetrieben oder der Stadt Wien."
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Klavier, sehr günstig! Aufgrund eines Umzugs ins Hause bringen (nur innerhalb von Wien möglich). Ausland gebe ich mein gut erhaltenes Klavier (ca. Besichtigung und Probespielen gerne jeden Tag 10 Jahre) ab. Farbe schwarz (Lack), Zustand sehr ab ca. 18 Uhr, eine telefonische Terminvereinbagut. Mein Umzugsunternehmen könnte das Klavier rung wäre schön. Natürlich beantworte ich auch auch gegen einen geringen Aufpreiszu Ihnennach vorab weitere Fragen.",
          "österreichische Tageszeitungen, zu Prüfungszwecken bearbeitet)",
          "(Quellen der Anzeigen a-ı"
        ]
      }
    ]
  },
  {
    "id": "37",
    "title": "Nachhaltigkeit, Weiterbildung und Beruf",
    "sourcePage": 345,
    "keywords": "lesen und sprachbausteine Lesen Sie zuerst die zehn Situationen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 sie möchten mehr über Naturkosmetik erfahren. 12 sie möchten mehr über richtiges kompostieren erfahren. 13 sie interessieren sich für einen Bio-Urlaub in Österreich. 14 sie wollen ihren arbeitsplatz in Zukunft umweltfreundlicher gestalten. 15 sie interessieren sich für die ausbildung zum sakralenergetiker. 16 eine Bekannte sucht für ihren Job ein seminar, um ihr lesetempo zu verbessern und ihre gedächtnisleistungen zu trainieren. 17 ihr guter Freund möchte sich über einen möglichen Berufswechsel informieren. 18 sie planen einen vegetarischen tag in der schulkantine und suchen nach guten vegetarischen Rezepten. 19 sie möchten einen Verein gründen und suchen nach informationen. 20 Nach ihrem studium würden sie gerne ein Jahr auslandserfahrungen sammeln. lesen und sprachbausteine er ist wertvoll für ihren garten und für die Umwelt. sie suchen nach einer möglichkeit, neue merk- und pflanzen benötigen einen lockeren, humusreichen Bo- gedächtnismethoden kennenzulernen, kosten und Zeit den mit ausreichend kohlenstoff, phosphor und stick- zu sparen und neue impulse für gehirn- und persön- stoff. Diese Nährstoffe können durch kompostierung lichkeitsgerechtes arbeiten zu finden? in unserem dem gartenboden auf natürliche Weise zurückgegeben seminar für mind mapping und speed Reading können sie das alles lernen. Das seminar ist ein angebot für Durch richtige kompostierung wird co2 im Boden Führungs- und Fachkräfte, projektleiter, mitarbeiter und gebunden und kann nicht in die atmosphäre entwei- mitarbeiterinnen aus allen Branchen und Bereichen, die chen. ein echter Beitrag zum klimaschutz! Jetzt mehr mit visuell-strukturierendem arbeiten mehr Überblick, schnelles erfassen und erinnern anstreben. (zu Übungszwecken bearbeitet, Quelle: www.umweltprofis.at/ (zu Übungszwecken bearbeitet, Quelle: www.seminus.de/ fileadmin/archiv/LAV/Downloads/Kompostfolder_FERTIG_PFADE1.pdf, datenbanken/seminare/kategorie.cfm?id=116&oid=114, 2013-10-01) Die schwerpunkte der ausbildung werden in 4 haupt- Wir atmen durch sie und sie schützt uns. sie zeigt, ob bereiche unterteilt: lendenwirbel-, Brustwirbel-, wir uns wohl fühlen. Das wichtigste organ unseres halswirbel- und Bewegungssystem. Vermittelt werden körpers: Unsere haut ist ein einmaliges sinnesorgan, die inhalte der hauptbereiche in Form eines modulsys- das Belastungen und gifte, die sich in unserem körper befinden, aufnimmt und ausscheidet. als Filterorgan arbeitet unsere haut aber nicht nur von innen nach außen, sondern übernimmt auch von außen nach innen eine wichtige aufgabe im transport von stoffen. Deshalb sollten alle produkte und substanzen, die mit unserer haut in Berührung kommen, ganz genau auf ihre inhalte geprüft werden. erfahren sie jetzt mehr über unsere pflegeprodukte, die auf Rohstoffen aus der schatzkammer der Natur basieren. (zu Übungszwecken bearbeitet, Quelle: www.kontrollierte- naturkosmetik.de/prolog.htm, 2013-10-01) genießen ohne Fleisch leicht gemacht mit unserer sammlung von vegetarischen Rezepten - Rezepte ohne Fleisch. Fleischloses von gemüsesuppen, über frische salate bis hin zu leckeren tofu-gerichten - vegetarische gerichte mit einfachen und schnellen Rezepten. Bei uns finden alle, die sich vegetarisch ernähren wollen, ihr liebstes vegetarisches Rezept! (zu Übungszwecken bearbeitet, Quelle: www.ichkoche.at/ vegetarische-rezepte/, 2013-10-01) tems. im Zentrum der ausbildung stehen 5 module, die einander ergänzen und teilweise aufeinander aufbau- en. Vermittelt wird ein grundlegendes Verständnis der leitlinien (energiebahnen) und das Zusammenspiel der einzelnen muskelsysteme sowie grundzüge der prakti- schen arbeit, um den Fluss der energie auszugleichen. ergänzt werden diese ausbildungsschwerpunkte durch vertiefende und ergänzende Workshops. Die grund- ausbildung in sakralenergetik dauert 12 tage, die in mehrtägigen intensivseminaren angeboten werden. (zu Übungszwecken bearbeitet, Quelle: www.sakralenergetik- ausbildung.at/index.php/ausbildungsinhalte, 2013-10-01) eine umweltfreundliche geschäftsstrategie kommt nicht nur der Umwelt zugute, sondern auch ihrem end- ergebnis, da die Bewahrung der Ressourcen und eine Reduzierung des abfalls letztendlich geld sparen. Die gute Nachricht ist: ob sie nun eine home-office tä- tigkeit ausüben oder ein externes Unternehmen leiten, es gibt einige simple Dinge, die sie tun können, um ihr geschäft umweltfreundlicher zu machen. Wir verraten ihnen 10 hilfreiche tipps von „Verwenden sie alte materialien wieder“ bis zu „geben sie ihr Wis- (zu Übungszwecken bearbeitet, Quelle: www.avery-zweckform.com/avery/ de_de/Ideen-und-Anwendungen/Nachhaltigkeit/10-Wege-Ihr- Buero-umweltfreundlicher-zu-machen.htm, 2013-10-01) lesen und sprachbausteine es gibt viele gründe für eine Umschulung oder einen neuen Beruf zu erlernen: Unzufriedenheit im eigenen verfahrens darf der Verein seine tätigkeit aufnehmen. Job, längere arbeitslosigkeit, kindererziehung, krank- heit, Berufskrankheit, ungenügende Nachfrage für den hlpd/public/content/22/Seite.220300.html#AllgemeineInformationen, eigenen Job, zur Rehabilitation, oder auch die eigene Neuorientierung. Quereinsteiger, meist auch seitenein- steiger genannt, hatten in Zeiten des it Booms gro- ße chancen, neu Fuß zu fassen. mittlerweile ist diese marktlücke fast gesättigt, was aber nicht heißt, dass haben sie interesse daran, es dort keine möglichkeiten mehr zur Neuorientierung • Unterrichtserfahrung im ausland zu sammeln? gibt. Welcher Beruf wirklich zu ihnen passt? – infos und • in ein anderes schulsystem eingebunden zu sein? • ihre sprachkenntnisse zu erweitern? (zu Übungszwecken bearbeitet, Quelle: www.blog.de/tb/a/r/ arbeit-quereinsteiger/welcher-beruf-passt-zu-mir-umschulung/4464911/) tionen über die internationalen mobilitätsprogramme Was mit essen und trinken begonnen hat, wurde mit des Bundesministeriums für Bildung und Frauen. der Zeit z.B. in der gruppe der Bio-hotels um viele Bereiche erweitert (kosmetik, Ressourcenverbrauche, Die neue plattform für österreichische hotels mit zerti- fiziert biologischem angebot ist nun online. Wir freuen uns über die neue initiative für alle umweltbewussten Zum start der plattform sind nach wenigen monaten schon mehr als 70 Betriebe in allen Bundesländern in Österreich vereint: Vom stadthotel über den Wellnes- stempel, vom Fastenhotel bis zum tagungsprofi und vom Bauernhofurlaub bis zum ausflugsziel reicht das angebot der zertifizierten Bioanbieter. (zu Übungszwecken bearbeitet, Quelle: www.adamah.at/aktuelles/bioferien. at-das-oesterreichische-bioferien-portal.html, 2013-10-01) Das gesetz unterteilt die Vereinsgründung in zwei pha- sen: die errichtung und die entstehung des Vereins. ein Verein wird durch die Vereinbarung von statuten (gründungsvereinbarung) errichtet. Die gründerinnen/ gründer oder die bereits bestellten organschaftlichen Vertreterinnen/organschaftlichen Vertreter müssen die errichtung des Vereins der Vereinsbehörde schriftlich anschließend prüft die Behörde die statuten auf ihre ge- setzeskonformität. Bei positivem abschluss des prüfungs- (zu Übungszwecken bearbeitet, Quelle: https://www.help.gv.at/Portal.Node/ • landeskunde hautnah zu erleben und interkulturelle auf unserer Website finden sie alle wichtigen informa- (zu Übungszwecken bearbeitet, Quelle: https://www.weltweitunterrichten.at/, 2015-04-30) Bei dem Versuch, einen anderen menschen zum Rauch- stopp zu motivieren, kann es hilfreich sein, sich vorher über das thema tabakkonsum informiert zu haben und außerdem Verständnis für die situation des Rauchen- den zu entwickeln. lesen sie mehr auf unserer seite: (zu Übungszwecken bearbeitet, Quelle: www.rauchfrei-info.de/ informieren/news/detail/news/anderen-beim-rauchstopp-helfen-2/, Die esoteRik-tage Wien sind eine Bewusstseinsmesse mit vielseitigen produkt- und Beratungsangeboten zu spiritualität und sanfter medizin. Die Wiener esoteRik-tage gliedern sich in zwei Be- reiche – die Verkaufsausstellung und das Vortragspro- gramm. in der Verkaufsausstellung zeigen aussteller aus unterschiedlichsten Branchen ihre Waren- und Dienstleistungsangebote und das Vortragsprogramm begleitet die messe mit Vorträgen, sonderveranstaltun- (zu Übungszwecken bearbeitet, Quelle: www.messen.de/de/ 3536/in/Wien/ESOTERIK-Tage%20Wien/info.html, 2015-04-30)",
    "questions": [
      {
        "num": 11,
        "answer": "b",
        "stem": "sie möchten mehr über Naturkosmetik erfahren."
      },
      {
        "num": 12,
        "answer": "a",
        "stem": "sie möchten mehr über richtiges kompostieren erfahren."
      },
      {
        "num": 13,
        "answer": "h",
        "stem": "sie interessieren sich für einen Bio-Urlaub in Österreich."
      },
      {
        "num": 14,
        "answer": "f",
        "stem": "sie wollen ihren arbeitsplatz in Zukunft umweltfreundlicher gestalten."
      },
      {
        "num": 15,
        "answer": "e",
        "stem": "sie interessieren sich für die ausbildung zum sakralenergetiker."
      },
      {
        "num": 16,
        "answer": "d",
        "stem": "eine Bekannte sucht für ihren Job ein seminar, um ihr lesetempo zu verbessern und ihre gedächtnisleistungen zu trainieren."
      },
      {
        "num": 17,
        "answer": "g",
        "stem": "ihr guter Freund möchte sich über einen möglichen Berufswechsel informieren."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "sie planen einen vegetarischen tag in der schulkantine und suchen nach guten vegetarischen Rezepten."
      },
      {
        "num": 19,
        "answer": "i",
        "stem": "sie möchten einen Verein gründen und suchen nach informationen."
      },
      {
        "num": 20,
        "answer": "j",
        "stem": "Nach ihrem studium würden sie gerne ein Jahr auslandserfahrungen sammeln."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "er ist wertvoll für ihren garten und für die Umwelt. pflanzen benötigen einen lockeren, humusreichen Boden mit ausreichend kohlenstoff, phosphor und stickstoff. Diese Nährstoffe können durch kompostierung dem gartenboden auf natürliche Weise zurückgegeben werden. Durch richtige kompostierung wird co im Boden gebunden und kann nicht in die atmosphäre entweichen. ein echter Beitrag zum klimaschutz! Jetzt mehr in unserer Broschüre! (zu Übungszwecken bearbeitet, Quelle: www.umweltprofis.at/ fileadmin/archiv/LAV/Downloads/Kompostfolder_FERTIG_PFADE1.pdf, 2013-10-01)"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Wir atmen durch sie und sie schützt uns. sie zeigt, ob wir uns wohl fühlen. Das wichtigste organ unseres körpers: Unsere haut ist ein einmaliges sinnesorgan, das Belastungen und gifte, die sich in unserem körper befinden, aufnimmt und ausscheidet. als Filterorgan arbeitet unsere haut aber nicht nur von innen nach außen, sondern übernimmt auch von außen nach innen eine wichtige aufgabe im transport von stoffen. Deshalb sollten alle produkte und substanzen, die mit unserer haut in Berührung kommen, ganz genau auf ihre inhalte geprüft werden. erfahren sie jetzt mehr über unsere pflegeprodukte, die auf Rohstoffen aus der schatzkammer der Natur basieren. (zu Übungszwecken bearbeitet, Quelle: www.kontrolliertenaturkosmetik.de/prolog.htm, 2013-10-01)"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "genießen ohne Fleisch leicht gemacht mit unserer sammlung von vegetarischen Rezepten - Rezepte ohne Fleisch. Fleischloses von gemüsesuppen, über frische salate bis hin zu leckeren tofu-gerichten - vegetarische gerichte mit einfachen und schnellen Rezepten. Bei uns finden alle, die sich vegetarisch ernähren wollen, ihr liebstes vegetarisches Rezept! (zu Übungszwecken bearbeitet, Quelle: www.ichkoche.at/ vegetarische-rezepte/, 2013-10-01)"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "sie suchen nach einer möglichkeit, neue merk- und gedächtnismethoden kennenzulernen, kosten und Zeit zu sparen und neue impulse für gehirn- und persönlichkeitsgerechtes arbeiten zu finden? in unserem seminar für mind mapping und speed Reading können sie das alles lernen. Das seminar ist ein angebot für Führungs- und Fachkräfte, projektleiter, mitarbeiter und mitarbeiterinnen aus allen Branchen und Bereichen, die mit visuell-strukturierendem arbeiten mehr Überblick, schnelles erfassen und erinnern anstreben. (zu Übungszwecken bearbeitet, Quelle: www.seminus.de/ datenbanken/seminare/kategorie.cfm?id=116&oid=114, 2013-10-01)"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "Die schwerpunkte der ausbildung werden in 4 hauptbereiche unterteilt: lendenwirbel-, Brustwirbel-, halswirbel- und Bewegungssystem. Vermittelt werden die inhalte der hauptbereiche in Form eines modulsystems. im Zentrum der ausbildung stehen 5 module, die einander ergänzen und teilweise aufeinander aufbauen. Vermittelt wird ein grundlegendes Verständnis der leitlinien (energiebahnen) und das Zusammenspiel der einzelnen muskelsysteme sowie grundzüge der praktischen arbeit, um den Fluss der energie auszugleichen. ergänzt werden diese ausbildungsschwerpunkte durch vertiefende und ergänzende Workshops. Die grundausbildung in sakralenergetik dauert 12 tage, die in mehrtägigen intensivseminaren angeboten werden. (zu Übungszwecken bearbeitet, Quelle: www.sakralenergetikausbildung.at/index.php/ausbildungsinhalte, 2013-10-01)"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "eine umweltfreundliche geschäftsstrategie kommt nicht nur der Umwelt zugute, sondern auch ihrem endergebnis, da die Bewahrung der Ressourcen und eine Reduzierung des abfalls letztendlich geld sparen. Die gute Nachricht ist: ob sie nun eine home-office tätigkeit ausüben oder ein externes Unternehmen leiten, es gibt einige simple Dinge, die sie tun können, um ihr geschäft umweltfreundlicher zu machen. Wir verraten ihnen 10 hilfreiche tipps von „Verwenden sie alte materialien wieder“ bis zu „geben sie ihr Wissen weiter“. (zu Übungszwecken bearbeitet, Quelle: www.avery-zweckform.com/avery/ de_de/Ideen-und-Anwendungen/Nachhaltigkeit/10-Wege-Ihr- Buero-umweltfreundlicher-zu-machen.htm, 2013-10-01)"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "es gibt viele gründe für eine Umschulung oder einen neuen Beruf zu erlernen: Unzufriedenheit im eigenen Job, längere arbeitslosigkeit, kindererziehung, krankheit, Berufskrankheit, ungenügende Nachfrage für den eigenen Job, zur Rehabilitation, oder auch die eigene Neuorientierung. Quereinsteiger, meist auch seiteneinsteiger genannt, hatten in Zeiten des it Booms große chancen, neu Fuß zu fassen. mittlerweile ist diese marktlücke fast gesättigt, was aber nicht heißt, dass es dort keine möglichkeiten mehr zur Neuorientierung gibt. Welcher Beruf wirklich zu ihnen passt? – infos und tipps finden sie online! (zu Übungszwecken bearbeitet, Quelle: www.blog.de/tb/a/r/ arbeit-quereinsteiger/welcher-beruf-passt-zu-mir-umschulung/4464911/)"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Was mit essen und trinken begonnen hat, wurde mit der Zeit z.B. in der gruppe der Bio-hotels um viele Bereiche erweitert (kosmetik, Ressourcenverbrauche, Ökostrom etc.). Die neue plattform für österreichische hotels mit zertifiziert biologischem angebot ist nun online. Wir freuen uns über die neue initiative für alle umweltbewussten „Urlauberinnen“. Zum start der plattform sind nach wenigen monaten schon mehr als 70 Betriebe in allen Bundesländern in Österreich vereint: Vom stadthotel über den Wellnesstempel, vom Fastenhotel bis zum tagungsprofi und vom Bauernhofurlaub bis zum ausflugsziel reicht das angebot der zertifizierten Bioanbieter. (zu Übungszwecken bearbeitet, Quelle: www.adamah.at/aktuelles/bioferien. at-das-oesterreichische-bioferien-portal.html, 2013-10-01)"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Allgemeine Informationen Das gesetz unterteilt die Vereinsgründung in zwei phasen: die errichtung und die entstehung des Vereins. ein Verein wird durch die Vereinbarung von statuten (gründungsvereinbarung) errichtet. Die gründerinnen/ gründer oder die bereits bestellten organschaftlichen Vertreterinnen/organschaftlichen Vertreter müssen die errichtung des Vereins der Vereinsbehörde schriftlich anzeigen."
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "haben sie interesse daran, • Unterrichtserfahrung im ausland zu sammeln? • in ein anderes schulsystem eingebunden zu sein? • ihre sprachkenntnisse zu erweitern? • landeskunde hautnah zu erleben und interkulturelle erfahrungen zu machen? auf unserer Website finden sie alle wichtigen informationen über die internationalen mobilitätsprogramme des Bundesministeriums für Bildung und Frauen. (zu Übungszwecken bearbeitet, Quelle: https://www.weltweitunterrichten.at/, 2015-04-30)"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Bei dem Versuch, einen anderen menschen zum Rauchstopp zu motivieren, kann es hilfreich sein, sich vorher über das thema tabakkonsum informiert zu haben und außerdem Verständnis für die situation des Rauchenden zu entwickeln. lesen sie mehr auf unserer seite: Rauchfrei-iNFo (zu Übungszwecken bearbeitet, Quelle: www.rauchfrei-info.de/ informieren/news/detail/news/anderen-beim-rauchstopp-helfen-2/, 2015-04-30)"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Die esoteRik-tage Wien sind eine Bewusstseinsmesse mit vielseitigen produkt- und Beratungsangeboten zu spiritualität und sanfter medizin. Die Wiener esoteRik-tage gliedern sich in zwei Bereiche – die Verkaufsausstellung und das Vortragsprogramm. in der Verkaufsausstellung zeigen aussteller aus unterschiedlichsten Branchen ihre Waren- und Dienstleistungsangebote und das Vortragsprogramm begleitet die messe mit Vorträgen, sonderveranstaltungen und Workshops. (zu Übungszwecken bearbeitet, Quelle: www.messen.de/de/ 3536/in/Wien/ESOTERIK-Tage%20Wien/info.html, 2015-04-30)"
        ]
      }
    ]
  },
  {
    "id": "38",
    "title": "Biologie, Natur und Berufsangebote",
    "sourcePage": 348,
    "keywords": "lesen und sprachbausteine Lesen Sie zuerst die zehn Situationen (11–20) und dann die zwölf Info-Texte (a–l). Welcher Info-Text passt zu welcher Situation? Sie können jeden Info-Text nur einmal verwenden. Markieren Sie Ihre Lösungen auf dem Antwortbogen bei den Aufgaben 11–20. Manchmal gibt es keine Lösung. Markieren Sie dann x. 11 ihre tochter hat eine Nachprüfung in Biologie und braucht hilfe bei der Vorbereitung. 12 ein guter Freund möchte endlich die richtige Frau kennen lernen. 13 sie möchten wissen, ob ihre lebensmittel aus biologischer landwirtschaft stammen. 14 sie interessieren sich für den lehrberuf Florist/Floristin und möchten sich informieren. 15 sie haben sich erkältet und möchten Naturheilmittel anwenden. 16 sie wollen in einem Jahr heiraten und möchten sich erste ideen holen. 17 sie sind von Beruf architekt, wollen jetzt aber die landwirtschaft von ihrem onkel übernehmen und wissen noch wenig darüber. 18 ihre mutter hat geburtstag und sie möchten ihr aus dem ausland einen Blumenstrauß zukommen lassen. 19 sie möchten nützliche von unnützen pflanzen auf der Wiese unterscheiden können. ein guter Freund sucht dringend arbeit für die nächsten monate. lesen und sprachbausteine Für eine perfekte hochzeit braucht es eine perfekte Wie heißt es so schön: „lass´ Blumen sprechen!“ Und planung. aber wo fängt man an? soll man ein motto möglichkeiten, sie zu verschenken, gibt es mehr als wählen? Welche Blumen passen am besten zu einem, genug. Doch neben der roten Rose, die als bekanntes welcher Fotograf soll den großen tag festhalten? Wie symbol für die wahre liebe steht, wissen die wenigs- soll ich die einladungen gestalten und wie finde ich den ten, dass fast alle Blumen eine Bedeutung haben. Diese richtigen Veranstaltungsort? Wir helfen ihnen bei der symbolik entsteht oftmals durch ihr aussehen und ihre Beantwortung dieser Fragen. kommen sie einfach zur Wirkung aber auch die Farbe ist dafür entscheidend. hochzeitsmesse am messegelände in Wels vom 3.10.- Wir sagen ihnen, welche Blumen bei uns am liebsten verschenkt werden und welche Bedeutung sie haben. Zusätzlich erfahren sie bei uns, welche symbolik hinter sie sind gern an der frischen luft? sie haben zwei geschickte hände und können gut feine arbeiten aus- (zu Übungszwecken bearbeitet: Quelle: http://sprache-der-blumen.de/; führen, sind aber auch stark? sie sind naturverbunden und lieben Blumen, sträucher, Farne & co? sie haben keine angst, sich dabei auch einmal schmutzig zu machen? Dann sind sie genau die person, die wir brau- ihr kind kann Fische von Fröschen nicht unterschei- chen! gärtnerei „immergrün“ sucht einen verlässlichen den? es glaubt, steine sind auch Blumen und gregor Vollzeit-mitarbeiter für die nächste saison. schicken sie mendel war ein österreichischer Bundespräsident? Bei bitte ihre Bewerbung inklusive lebenslauf und Foto an: mit frischen Blumen von erfahrenen Floristen machen sie ihre lieben glücklich und sorgen für den richti- gen Wow-effekt. Wenn sie bei festlichen anlässen nicht persönlich dabei sein können, steht ihnen unser Blumenversand zur seite: Wählen sie einen passen- den strauß aus und fügen sie noch eine grußkarte mit persönlichen Worten hinzu. Nach ein paar mausklicks ist ihr Blumenstrauß schon unterwegs zum glücklichen (zu Übungszwecken bearbeitet: Quelle: http://www.euroflorist.at/; 2015-11-23) mir sind sie richtig! pensionierter Biologie-lehrer gibt Nachhilfe für alle schulstufen. einfach 0680/1277600 wählen und ich komme zu ihnen nach hause! Woher der spruch „liebe geht durch den magen“ kommt und was genau er bedeutet, ist nicht eindeutig geklärt. ob damit das gefühl von schmetterlingen im Bauch gemeint ist, wenn man verliebt ist, oder aber das Wohlgefühl bei einem guten essen, das ein glücks- gefühl hervorruft; sicher ist, dass über 90 prozent der Frauen sich von ihrem traummann wünschen, dass er kochen kann! Was eignet sich da besser als ein roman- tisches candle-light-Dinner? Wir haben drei menüvor- schläge für das candle-light-Dinner zusammengestellt, mit denen sie bei ihrer liebsten garantiert punkten (zu Übungszwecken bearbeitet: Quelle: http://www.chefkoch.de/ magazin/artikel/1920,0/Chefkoch/Denn-Liebe-geht-tatsaechlich- durch-den-Magen.htm - 2015-11-23) lesen und sprachbausteine immer mehr leute greifen im geschäft nach Bio-pro- es ist sommer, überall wird geheiratet, doch sie sitzen dukten. aber was bedeutet Bio eigentlich? Der Bio- abends allein vorm Fernseher, weil sie den mann oder landbau ist europaweit reglementiert. Die gesetzli- die Frau fürs leben noch nicht gefunden haben. Falls che grundlage besagt, dass lebensmittel, die einen ihnen das bekannt vorkommt, ist es trotzdem kein Bio-hinweis tragen, auch tatsächlich entsprechend der grund zur Verzweiflung. Die lösung kann ganz einfach Richtlinien für die biologische landwirtschaft erzeugt sein. Bei uns finden sie profile von über 20.000 sing- werden müssen. kontrollierte Bioprodukte werden les, die auch auf der suche nach einem leben zu zweit zertifiziert und sind speziell gekennzeichnet. in diesem sind. einfach kostengünstig registrieren, durchklicken, Folder finden sie die erklärung für alle kennzeichnun- kontaktieren und… Wer weiß, vielleicht ist ihr traum- partner ja gerade online! (zu Übungszwecken bearbeitet: Quelle: http://www.abg.at/de/ konsumenten-infos/wasistbio; 2015-11-23) (zu Übungszwecken bearbeitet: Quelle: www.partnerboerse-zweiherzen.at; erst kratzt es im hals, dann ist die Nase verstopft, der im sagenumwobenen ausseerland wächst eine beson- kopf brummt, und der ganze körper fühlt sich an wie dere Blume: Die weiße sternblütige Narzisse. Die wild Blei. Die erste erkältung der saison ist da. so unan- wachsenden Narzissen schmücken von mai bis Juni genehm das ist, sollte man die Beschwerden dennoch nicht mit medikamenten wegbügeln. Viele menschen schwören stattdessen auf hausmittel. Die 10 besten tipps zur natürlichen Bekämpfung von husten und schnupfen finden sie hier! (zu Übungszwecken bearbeitet: Quelle: http://www.spiegel.de/ gesundheit/diagnose/erkaeltung-hausmittel-gegen-husten- schnupfen-und-halsschmerzen-a-993444.html; 2015-11-23) es ist harte arbeit, erfordert viel Verantwortung und ist mit sicherheit auch kein Vorhaben, mit dem man schnelles geld verdient. große teile des sektors ste- cken in alten traditionen fest. Wenn du noch nie in deinem leben erfahrungen mit der landwirtschaft gesammelt hast, musst du davon ausgehen, dass sich Bauern und Nicht-Bauern gleichermaßen über dich wundern werden. Die Frage „Warum willst du in die landwirtschaft gehen?“ solltest du mit selbstvertrauen beantworten können. Dieses Buch begleitet dich auf den ersten schritten zu deinem traumberuf Bauer. (zu Übungszwecken bearbeitet: Quelle: http://de.wikihow.com/ Ohne-Erfahrung-Bauer-werden; 2015-11-23) die Region ausseerland im salzkammergut. Jedes Jahr im Juni findet das Narzissenfest – Österreichs größtes Blumenfest – im ausseerland statt. highlight des Festes sind die fantasievollen, von hand gesteckten Narzis- sen-Figuren. Das Narzissenfest ist ein echtes highlight im Bad ausseer Veranstaltungskalender und ein herrli- ches ausflugsziel für ihren sommerurlaub im salzkam- mergut. lassen sie es sich deshalb nicht entgehen und buchen sie schon jetzt ihren aufenthalt für nächstes Jahr mit „steiermark Reisen“! www.steiermark-reisen.at (zu Übungszwecken bearbeitet: Quelle: https://www.ebners-waldhof.at/ narzissenfest-bad-aussee; 2015-11-23) Bei spaziergängen und Radtouren begleiten sie uns fast durchs ganze Jahr: Wiesenblumen. aber was wis- sen sie schon über ihr Vorkommen und ihre Verwend- barkeit? Welche dieser Blumen sind giftig und welche sind sogar für medizinische Zwecke nutzbar? hier finden sie die merkmale, standorte und Blütezeit der wichtigsten Wiesenblumen. anleitungen zum fachge- rechten sammeln, lagern und Zubereiten von essbaren pflanzen und heilpflanzen machen diesen handlichen Führer zu einem zuverlässigen Begleiter für Naturlieb- (zu Übungszwecken bearbeitet: Quelle: http://www.amazon.de/ Bestimmungsbuch-Wald-und-Wiesenpflanzen/dp/3778750488; 2015-11-23)",
    "questions": [
      {
        "num": 11,
        "answer": "e",
        "stem": "ihre tochter hat eine Nachprüfung in Biologie und braucht hilfe bei der Vorbereitung."
      },
      {
        "num": 12,
        "answer": "j",
        "stem": "ein guter Freund möchte endlich die richtige Frau kennen lernen."
      },
      {
        "num": 13,
        "answer": "g",
        "stem": "sie möchten wissen, ob ihre lebensmittel aus biologischer landwirtschaft stammen."
      },
      {
        "num": 14,
        "answer": "x",
        "stem": "sie interessieren sich für den lehrberuf Florist/Floristin und möchten sich informieren."
      },
      {
        "num": 15,
        "answer": "h",
        "stem": "sie haben sich erkältet und möchten Naturheilmittel anwenden."
      },
      {
        "num": 16,
        "answer": "a",
        "stem": "sie wollen in einem Jahr heiraten und möchten sich erste ideen holen."
      },
      {
        "num": 17,
        "answer": "i",
        "stem": "sie sind von Beruf architekt, wollen jetzt aber die landwirtschaft von ihrem onkel übernehmen und wissen noch wenig darüber."
      },
      {
        "num": 18,
        "answer": "c",
        "stem": "ihre mutter hat geburtstag und sie möchten ihr aus dem ausland einen Blumenstrauß zukommen lassen."
      },
      {
        "num": 19,
        "answer": "l",
        "stem": "sie möchten nützliche von unnützen pflanzen auf der Wiese unterscheiden können."
      },
      {
        "num": 20,
        "answer": "b",
        "stem": "ein guter Freund sucht dringend arbeit für die nächsten monate."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "Für eine perfekte hochzeit braucht es eine perfekte planung. aber wo fängt man an? soll man ein motto wählen? Welche Blumen passen am besten zu einem, welcher Fotograf soll den großen tag festhalten? Wie soll ich die einladungen gestalten und wie finde ich den richtigen Veranstaltungsort? Wir helfen ihnen bei der Beantwortung dieser Fragen. kommen sie einfach zur hochzeitsmesse am messegelände in Wels vom 3.10.- 5.10. eintritt 4€."
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "sie sind gern an der frischen luft? sie haben zwei geschickte hände und können gut feine arbeiten ausführen, sind aber auch stark? sie sind naturverbunden und lieben Blumen, sträucher, Farne & co? sie haben keine angst, sich dabei auch einmal schmutzig zu machen? Dann sind sie genau die person, die wir brauchen! gärtnerei „immergrün“ sucht einen verlässlichen Vollzeit-mitarbeiter für die nächste saison. schicken sie bitte ihre Bewerbung inklusive lebenslauf und Foto an: office@immergruen.at"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "mit frischen Blumen von erfahrenen Floristen machen sie ihre lieben glücklich und sorgen für den richtigen Wow-effekt. Wenn sie bei festlichen anlässen nicht persönlich dabei sein können, steht ihnen unser Blumenversand zur seite: Wählen sie einen passenden strauß aus und fügen sie noch eine grußkarte mit persönlichen Worten hinzu. Nach ein paar mausklicks ist ihr Blumenstrauß schon unterwegs zum glücklichen empfänger! (zu Übungszwecken bearbeitet: Quelle: http://www.euroflorist.at/; 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Wie heißt es so schön: „lass´ Blumen sprechen!“ Und möglichkeiten, sie zu verschenken, gibt es mehr als genug. Doch neben der roten Rose, die als bekanntes symbol für die wahre liebe steht, wissen die wenigsten, dass fast alle Blumen eine Bedeutung haben. Diese symbolik entsteht oftmals durch ihr aussehen und ihre Wirkung aber auch die Farbe ist dafür entscheidend. Wir sagen ihnen, welche Blumen bei uns am liebsten verschenkt werden und welche Bedeutung sie haben. Zusätzlich erfahren sie bei uns, welche symbolik hinter welcher Farbe steht. (zu Übungszwecken bearbeitet: Quelle: http://sprache-der-blumen.de/; 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "ihr kind kann Fische von Fröschen nicht unterscheiden? es glaubt, steine sind auch Blumen und gregor mendel war ein österreichischer Bundespräsident? Bei mir sind sie richtig! pensionierter Biologie-lehrer gibt Nachhilfe für alle schulstufen. einfach 0680/1277600 wählen und ich komme zu ihnen nach hause!"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "Woher der spruch „liebe geht durch den magen“ kommt und was genau er bedeutet, ist nicht eindeutig geklärt. ob damit das gefühl von schmetterlingen im Bauch gemeint ist, wenn man verliebt ist, oder aber das Wohlgefühl bei einem guten essen, das ein glücksgefühl hervorruft; sicher ist, dass über 90 prozent der Frauen sich von ihrem traummann wünschen, dass er kochen kann! Was eignet sich da besser als ein romantisches candle-light-Dinner? Wir haben drei menüvorschläge für das candle-light-Dinner zusammengestellt, mit denen sie bei ihrer liebsten garantiert punkten können. (zu Übungszwecken bearbeitet: Quelle: http://www.chefkoch.de/ magazin/artikel/1920,0/Chefkoch/Denn-Liebe-geht-tatsaechlichdurch-den-Magen.htm - 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "immer mehr leute greifen im geschäft nach Bio-produkten. aber was bedeutet Bio eigentlich? Der Biolandbau ist europaweit reglementiert. Die gesetzliche grundlage besagt, dass lebensmittel, die einen Bio-hinweis tragen, auch tatsächlich entsprechend der Richtlinien für die biologische landwirtschaft erzeugt werden müssen. kontrollierte Bioprodukte werden zertifiziert und sind speziell gekennzeichnet. in diesem Folder finden sie die erklärung für alle kennzeichnungen. (zu Übungszwecken bearbeitet: Quelle: http://www.abg.at/de/ konsumenten-infos/wasistbio; 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "erst kratzt es im hals, dann ist die Nase verstopft, der kopf brummt, und der ganze körper fühlt sich an wie Blei. Die erste erkältung der saison ist da. so unangenehm das ist, sollte man die Beschwerden dennoch nicht mit medikamenten wegbügeln. Viele menschen schwören stattdessen auf hausmittel. Die 10 besten tipps zur natürlichen Bekämpfung von husten und schnupfen finden sie hier! (zu Übungszwecken bearbeitet: Quelle: http://www.spiegel.de/ gesundheit/diagnose/erkaeltung-hausmittel-gegen-hustenschnupfen-und-halsschmerzen-a-993444.html; 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "es ist harte arbeit, erfordert viel Verantwortung und ist mit sicherheit auch kein Vorhaben, mit dem man schnelles geld verdient. große teile des sektors stecken in alten traditionen fest. Wenn du noch nie in deinem leben erfahrungen mit der landwirtschaft gesammelt hast, musst du davon ausgehen, dass sich Bauern und Nicht-Bauern gleichermaßen über dich wundern werden. Die Frage „Warum willst du in die landwirtschaft gehen?“ solltest du mit selbstvertrauen beantworten können. Dieses Buch begleitet dich auf den ersten schritten zu deinem traumberuf Bauer. (zu Übungszwecken bearbeitet: Quelle: http://de.wikihow.com/ Ohne-Erfahrung-Bauer-werden; 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "es ist sommer, überall wird geheiratet, doch sie sitzen abends allein vorm Fernseher, weil sie den mann oder die Frau fürs leben noch nicht gefunden haben. Falls ihnen das bekannt vorkommt, ist es trotzdem kein grund zur Verzweiflung. Die lösung kann ganz einfach sein. Bei uns finden sie profile von über 20.000 singles, die auch auf der suche nach einem leben zu zweit sind. einfach kostengünstig registrieren, durchklicken, kontaktieren und… Wer weiß, vielleicht ist ihr traumpartner ja gerade online! (zu Übungszwecken bearbeitet: Quelle: www.partnerboerse-zweiherzen.at; 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "im sagenumwobenen ausseerland wächst eine besondere Blume: Die weiße sternblütige Narzisse. Die wild wachsenden Narzissen schmücken von mai bis Juni die Region ausseerland im salzkammergut. Jedes Jahr im Juni findet das Narzissenfest – Österreichs größtes Blumenfest – im ausseerland statt. highlight des Festes sind die fantasievollen, von hand gesteckten Narzissen-Figuren. Das Narzissenfest ist ein echtes highlight im Bad ausseer Veranstaltungskalender und ein herrliches ausflugsziel für ihren sommerurlaub im salzkammergut. lassen sie es sich deshalb nicht entgehen und buchen sie schon jetzt ihren aufenthalt für nächstes Jahr mit „steiermark Reisen“! www.steiermark-reisen.at (zu Übungszwecken bearbeitet: Quelle: https://www.ebners-waldhof.at/ narzissenfest-bad-aussee; 2015-11-23)"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Bei spaziergängen und Radtouren begleiten sie uns fast durchs ganze Jahr: Wiesenblumen. aber was wissen sie schon über ihr Vorkommen und ihre Verwendbarkeit? Welche dieser Blumen sind giftig und welche sind sogar für medizinische Zwecke nutzbar? hier finden sie die merkmale, standorte und Blütezeit der wichtigsten Wiesenblumen. anleitungen zum fachgerechten sammeln, lagern und Zubereiten von essbaren pflanzen und heilpflanzen machen diesen handlichen Führer zu einem zuverlässigen Begleiter für Naturliebhaber. (zu Übungszwecken bearbeitet: Quelle: http://www.amazon.de/ Bestimmungsbuch-Wald-und-Wiesenpflanzen/dp/3778750488; 2015-11-23)"
        ]
      }
    ]
  },
  {
    "id": "39",
    "title": "Partnersuche, Garten und Nebenjobs",
    "sourcePage": 351,
    "keywords": "____11. Ihre Bekannte ist Mitte dreißig und sucht einen Partner, mit dem sie regelmäßig ins Kino gehen kann. ____12.Sie wollen Ihren Garten verändern und suchen Beratung/Tipps. ____13. Der Sohn Ihrer Freunde hat gerade das Abitur gemacht und sucht im Sommer für zwei Monate einen Job. ____14. Ihr Freund möchte im Nebenjob Gartenarbeiten übernehmen. ____15. Ihr 45-jähriger Onkel sucht eine Partnerin, mit der er zusammen ____16. Sie möchten gern bei einem Film mitspielen und etwas Geld ____17. Der Sohn Ihrer Freunde interessiert sich für die Geschichte des Autos. Am Sonntag wollen Sie ihm etwas Interessantes machen. ____18.Sie suchen eine Stelle und brauchen Tipps für ihre Bewerbungen. ____19. Im Urlaub wollen Sie mit dem Auto eine Reise durch Deutschland machen und suchen ein passendes Angebot. ____20. Ihre Bekannte möchte lernen, wie sie kleinere Reparaturen an ihrem Wagen selbst machen. Für den Fernsehfilm \"Die Schönheit von Bitterfeld\" suchen wir für einige Nebenrollen Laienschauspieler und Statisten. Drehzeit: 18.03-25.03., Gage: 40 Euro/Tag Casting: Mi, 19.02. 10-20 Uhr im Hotel Lindner oder schriftliche Bewerbung mit Rheinfilm/Bam, c/a Hotel Lindner, Hans-Driesch-Str. 27, 04179 Leipzig Wie funktioniert ein Ottomotor? Wie klingt ein Benz Motorwagen? Warum sind Autos auch Designobjekte? Von den ersten Schlittschuhen bis zum neuesten Formel-1-Fahrzeug präsentiert das Verkehrsmuseum unter dem Thema \"Mobilität und Technik\" die Lust an der Fortbewegung und ihre Grenzen. Täglich 9-17 Uhr, Donnerstag 9-20 Uhr Verkehrsmuseum Erfurt, August-Bebel-Str. 14a, 99084 Erfurt, Tel 500806-14 (www.verkehrsmuseumefurt.de) Bummeln und Genießen, Shoppen und Nightlife! 3 Tage lang liegt Ihnen Berlin zu Füßen. Anschließend starten Sie Ihre Autotour. Sie erleben die Vielfältigkeit deutscher Landschaften von der Nordseeküste bis zu 3 Nächte in Berlin plus 10 Übernachtungen in Hotels Ihrer Wahl (3 Sterne), Parken in den Hotels, individueller ADAC-Planer. Pro Person im Doppelzimmer 589 € Mietwagen zur Tour inkl. Tickets 152 € Jung gebliebener Rentner, unkompliziert und gut aussehend, mit Verbundenheit zur Natur sucht Freizeitpartnerin (bis 40) für gemeinsame Aktivitäten: Kunst, Kultur, Kino, Wanderungen, Einladungen, gesellige Abende. Zuschriften unter LA 10/14-83/L3, Postf. 84, 04181 Leipzig. Wie sollen Wege im Garten geführt werden? In welcher Form können Teich oder Brunnen die Lebensenergie stärken? Wann bereichern uns Blumen, wann nicht? Wie kann man einen Garten auf die Bewohner des Hauses abstimmen? Mit Feng Shui können Sie Ihren Garten harmonisch gestalten. Ökologisches Bildungszentrum Dresden Wochenendseminar mit Elisabeth Kislinger, Landschaftsarchitektin, Sa/So. 28./29.01, jeweils 10-17 Uhr Studentinnen/Schülerinnen gesucht (ab-18 J.) für Betreuertätigkeit im Kinderferienlager Juli-August für Kinder zw. 6 Wir bieten Fahrtkosten, Unterkunft, Verpflegung und Taschengeld 125,-€. Weitere Infos: Jugendtours, Hebelstr. 32, 04177 Leipzig, 0341/4809194, [www.jutou.de](http://www.jutou.de) Gemeinsam schöne Dinge genießen Akademikerin, 38 J, mit Phantasie und Leidenschaft für Musik und Kunst, Italien und das Meer, sucht sportlich-eleganten Partner, mit dem sie Konzerte besuchen, ausgehen, und ferne Länder genießen kann. Zuschriften an: Neue Presse, Chiffre CFR-107 Kursinhalt: Aufbau des Autos, Störungen und Möglichkeiten zur Behebung, Wartungsarbeiten und Pflege. Tipps zum Gebrauchtwagenkauf. Die theoretischen Ausführungen werden in unserer Kfz-Werkstatt in die Praxis umgesetzt. Bitte Arbeitskleidung mitbringen. Winfried Mohr, A24 Autowerkstatt, Aidenbachstr. 36, 07743 Jena Sa 14.10 von 9–16 Uhr, Tel: 34 10 44 14",
    "questions": [
      {
        "num": 11,
        "answer": "h",
        "stem": "Ihre Bekannte ist Mitte dreißig und sucht einen Partner, mit dem sie regelmäßig ins Kino gehen kann."
      },
      {
        "num": 12,
        "answer": "i",
        "stem": "Sie wollen Ihren Garten verändern und suchen Beratung/Tipps."
      },
      {
        "num": 13,
        "answer": "j",
        "stem": "Der Sohn Ihrer Freunde hat gerade das Abitur gemacht und sucht im Sommer für zwei Monate einen Job."
      },
      {
        "num": 14,
        "answer": "x",
        "stem": "Ihr Freund möchte im Nebenjob Gartenarbeiten übernehmen."
      },
      {
        "num": 15,
        "answer": "k",
        "stem": "Ihr 45-jähriger Onkel sucht eine Partnerin, mit der er zusammen verreisen kann."
      },
      {
        "num": 16,
        "answer": "b",
        "stem": "Sie möchten gern bei einem Film mitspielen und etwas Geld verdienen."
      },
      {
        "num": 17,
        "answer": "d",
        "stem": "Der Sohn Ihrer Freunde interessiert sich für die Geschichte des Autos. Am Sonntag wollen Sie ihm etwas Interessantes machen."
      },
      {
        "num": 18,
        "answer": "x",
        "stem": "Sie suchen eine Stelle und brauchen Tipps für ihre Bewerbungen."
      },
      {
        "num": 19,
        "answer": "e",
        "stem": "Im Urlaub wollen Sie mit dem Auto eine Reise durch Deutschland machen und suchen ein passendes Angebot."
      },
      {
        "num": 20,
        "answer": "l",
        "stem": "Ihre Bekannte möchte lernen, wie sie kleinere Reparaturen an ihrem Wagen selbst machen."
      }
    ],
    "ads": [
      {
        "label": "Info-Text A",
        "paragraphs": [
          "(Kein Text)"
        ]
      },
      {
        "label": "Info-Text B",
        "paragraphs": [
          "Für den Fernsehfilm \"Die Schönheit von Bitterfeld\" suchen wir für einige Nebenrollen Laienschauspieler und Statisten. Drehzeit: 18.03-25.03., Gage: 40 Euro/Tag Casting: Mi, 19.02. 10-20 Uhr im Hotel Lindner oder schriftliche Bewerbung mit Foto und Tel.-Nr. an: Rheinfilm/Bam, c/a Hotel Lindner, Hans-Driesch-Str. 27, 04179 Leipzig"
        ]
      },
      {
        "label": "Info-Text C",
        "paragraphs": [
          "(Kein Text)"
        ]
      },
      {
        "label": "Info-Text D",
        "paragraphs": [
          "Verkehrsmuseum Erfurt Wie funktioniert ein Ottomotor? Wie klingt ein Benz Motorwagen? Warum sind Autos auch Designobjekte? Von den ersten Schlittschuhen bis zum neuesten Formel-1-Fahrzeug präsentiert das Verkehrsmuseum unter dem Thema \"Mobilität und Technik\" die Lust an der Fortbewegung und ihre Grenzen. Täglich 9-17 Uhr, Donnerstag 9-20 Uhr Verkehrsmuseum Erfurt, August-Bebel-Str. 14a, 99084 Erfurt, Tel 500806-14 (www.verkehrsmuseumefurt.de)"
        ]
      },
      {
        "label": "Info-Text E",
        "paragraphs": [
          "ADAC Urlaub mobil Bummeln und Genießen, Shoppen und Nightlife! 3 Tage lang liegt Ihnen Berlin zu Füßen. Anschließend starten Sie Ihre Autotour. Sie erleben die Vielfältigkeit deutscher Landschaften von der Nordseeküste bis zu den Alpen. 3 Nächte in Berlin plus 10 Übernachtungen in Hotels Ihrer Wahl (3 Sterne), Parken in den Hotels, individueller ADAC-Planer. Pro Person im Doppelzimmer 589 € Mietwagen zur Tour inkl. Tickets 152 €"
        ]
      },
      {
        "label": "Info-Text F",
        "paragraphs": [
          "(Kein Text)"
        ]
      },
      {
        "label": "Info-Text G",
        "paragraphs": [
          "(Kein Text)"
        ]
      },
      {
        "label": "Info-Text H",
        "paragraphs": [
          "Jung gebliebener Rentner, unkompliziert und gut aussehend, mit Verbundenheit zur Natur sucht Freizeitpartnerin (bis 40) für gemeinsame Aktivitäten: Kunst, Kultur, Kino, Wanderungen, Einladungen, gesellige Abende. Zuschriften unter LA 10/14-83/L3, Postf. 84, 04181 Leipzig."
        ]
      },
      {
        "label": "Info-Text I",
        "paragraphs": [
          "Feng Shui für den Garten Wie sollen Wege im Garten geführt werden? In welcher Form können Teich oder Brunnen die Lebensenergie stärken? Wann bereichern uns Blumen, wann nicht? Wie kann man einen Garten auf die Bewohner des Hauses abstimmen? Mit Feng Shui können Sie Ihren Garten harmonisch gestalten. Ökologisches Bildungszentrum Dresden Wochenendseminar mit Elisabeth Kislinger, Landschaftsarchitektin, Sa/So. 28./29.01, jeweils 10-17 Uhr Info: 0351 254400"
        ]
      },
      {
        "label": "Info-Text J",
        "paragraphs": [
          "Studentinnen/Schülerinnen gesucht (ab-18 J.) für Betreuertätigkeit im Kinderferienlager Juli-August für Kinder zw. 6 und 12 J. Wir bieten Fahrtkosten, Unterkunft, Verpflegung und Taschengeld 125,-€. Weitere Infos: Jugendtours, Hebelstr. 32, 04177 Leipzig, 0341/4809194, [www.jutou.de](http://www.jutou.de)"
        ]
      },
      {
        "label": "Info-Text K",
        "paragraphs": [
          "Gemeinsam schöne Dinge genießen Akademikerin, 38 J, mit Phantasie und Leidenschaft für Musik und Kunst, Italien und das Meer, sucht sportlich-eleganten Partner, mit dem sie Konzerte besuchen, ausgehen, und ferne Länder genießen kann. Zuschriften an: Neue Presse, Chiffre CFR-107"
        ]
      },
      {
        "label": "Info-Text L",
        "paragraphs": [
          "Samstagswerkstatt Kursinhalt: Aufbau des Autos, Störungen und Möglichkeiten zur Behebung, Wartungsarbeiten und Pflege. Tipps zum Gebrauchtwagenkauf. Die theoretischen Ausführungen werden in unserer Kfz-Werkstatt in die Praxis umgesetzt. Bitte Arbeitskleidung mitbringen. Winfried Mohr, A24 Autowerkstatt, Aidenbachstr. 36, 07743 Jena Sa 14.10 von 9–16 Uhr, Tel: 34 10 44 14"
        ]
      }
    ]
  }
];
