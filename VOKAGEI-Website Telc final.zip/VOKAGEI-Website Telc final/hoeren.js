const MODULE_NAME = "hoeren";
const partLinks = [...document.querySelectorAll(".reading-parts a")];
const topicPicker = document.querySelector(".topic-panel");
const topicSearch = document.querySelector("#topic-search");
const topicList = document.querySelector("#topic-list");
const topicCount = document.querySelector("#topic-count");
const topicEmpty = document.querySelector("#topic-empty");
const exercise = document.querySelector("#reading-exercise");
const narrowScreen = window.matchMedia("(max-width: 920px)");

const parts = hoerenData;
const descriptions = {
  1: "Hörverstehen Teil 1 (41–45): Entscheide für jede Aussage, ob sie richtig (+) oder falsch (–) ist.",
  2: "Hörverstehen Teil 2 (46–55): Entscheide für jede Aussage, ob sie richtig (+) oder falsch (–) ist.",
  3: "Hörverstehen Teil 3 (56–60): Entscheide für jede Aussage, ob sie richtig (+) oder falsch (–) ist.",
};
const selections = new Map();
const drafts = new Map();
let currentPart;
let currentTopic;

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function normalize(text) {
  return text.toLocaleLowerCase("de").replace(/ß/g, "ss")
    .normalize("NFD").replace(/\p{Diacritic}/gu, "");
}

function topicTitle(topic) {
  return topic.title.replace(/^Test\s+\S+\s*[–-]\s*/i, "");
}

function topicHash(part, id) {
  return `#teil-${part}/${id}`;
}

function topicQuestionCount(topic) {
  return topic.questions.length;
}

function updatePartProgressBars() {
  for (const link of partLinks) {
    const p = Number(link.hash.replace("#teil-", ""));
    const pct = VokageiProgress.getPartProgressPercent(MODULE_NAME, p, parts[p], topicQuestionCount);
    link.style.setProperty("--progress", `${pct}%`);
  }
}

function renderTopics() {
  const terms = normalize(topicSearch.value.trim()).split(/\s+/).filter(Boolean);
  const allTopics = parts[currentPart];
  const matches = allTopics.filter((topic) => {
    const searchText = normalize(`${topic.id} ${topic.title} ${topic.note ?? ""} ${topic.code ?? ""}`);
    return terms.every((word) => /^\d+[a-z]?$/.test(word)
      ? topic.id.startsWith(word) || searchText.includes(word)
      : searchText.includes(word));
  });
  const entries = matches.map((topic) => {
    const entry = element("li");
    const link = element("a");
    link.href = topicHash(currentPart, topic.id);
    link.dataset.topicId = topic.id;
    const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, topic.id, topicQuestionCount(topic));
    link.style.setProperty("--progress", `${pct}%`);
    if (topic.id === currentTopic.id) link.setAttribute("aria-current", "location");
    link.append(element("span", "topic-number", topic.id), element("span", "", topicTitle(topic)));
    entry.append(link);
    return entry;
  });
  topicList.replaceChildren(...entries);
  topicCount.textContent = `${matches.length} von ${allTopics.length} Themen`;
  topicEmpty.hidden = matches.length > 0;
  updatePartProgressBars();
}

function updateCurrentTopicProgressUI(draft) {
  const total = topicQuestionCount(currentTopic);
  VokageiProgress.saveDraft(MODULE_NAME, currentPart, currentTopic.id, draft, total);
  const pct = VokageiProgress.getTestProgressPercent(MODULE_NAME, currentPart, currentTopic.id, total);
  const activeLink = topicList.querySelector(`a[data-topic-id="${CSS.escape(currentTopic.id)}"]`);
  if (activeLink) activeLink.style.setProperty("--progress", `${pct}%`);
  updatePartProgressBars();
  return pct;
}

function getDraft() {
  const key = topicHash(currentPart, currentTopic.id);
  if (!drafts.has(key)) {
    drafts.set(key, VokageiProgress.getDraft(MODULE_NAME, currentPart, currentTopic.id));
  }
  return drafts.get(key);
}

function renderQuestion(question, draft) {
  const fieldset = element("fieldset", "question");
  fieldset.append(element("legend", "", `${question.num}. ${question.text}`));

  const choices = [
    ["+", "Richtig (+)"],
    ["-", "Falsch (–)"],
  ];
  const selected = draft.answers.get(question.num) ?? "";
  const inputs = [];
  for (const [key, labelText] of choices) {
    const optionLabel = element("label");
    const input = element("input");
    input.type = "radio";
    input.name = String(question.num);
    input.value = key;
    input.checked = selected === key;
    inputs.push(input);
    optionLabel.append(input, element("span", "", labelText));
    fieldset.append(optionLabel);
  }
  const feedback = element("p", "answer-result");
  fieldset.append(feedback);
  return { fieldset, question, feedback, inputs };
}

function renderTest(topic) {
  const draft = getDraft();
  const form = element("form", "answer-panel");
  const questionList = element("div", "answer-scroll");
  questionList.tabIndex = 0;
  questionList.setAttribute("aria-label", "Aufgaben");
  const questions = topic.questions.map((q) => renderQuestion(q, draft));
  questionList.append(...questions.map(({ fieldset }) => fieldset));

  if (topic.note || topic.code) {
    const noteWrap = element("div", "passage-entry");
    const details = element("details");
    const summary = element("summary", "", "Deckblatt-Hinweis & Lösungscode anzeigen");
    summary.style.cursor = "pointer";
    summary.style.fontWeight = "700";
    details.append(summary);
    if (topic.code) {
      const codeP = element("p", "", `Deckblatt-Code (Richtig [+]): ${topic.code}`);
      codeP.style.marginTop = ".5rem";
      codeP.style.fontWeight = "700";
      details.append(codeP);
    }
    if (topic.note) {
      const noteP = element("p", "", topic.note);
      noteP.style.marginTop = ".35rem";
      details.append(noteP);
    }
    noteWrap.append(details);
    questionList.append(noteWrap);
  }

  const controls = element("div", "answer-controls");
  const submit = element("button", "cta model-cta", "Antworten prüfen");
  submit.type = "submit";
  const resetBtn = element("button", "secondary-cta", "Zurücksetzen");
  resetBtn.type = "button";
  const result = element("p", "set-result");
  result.setAttribute("role", "status");
  controls.append(submit, resetBtn, result);
  form.append(questionList, controls);

  function updateResult() {
    let correctCount = 0;
    for (const { question, feedback } of questions) {
      const chosen = draft.answers.get(question.num);
      const correct = chosen === question.answer;
      if (correct) correctCount += 1;
      if (!draft.graded) {
        feedback.textContent = "";
        delete feedback.dataset.state;
      } else if (!chosen) {
        feedback.textContent = "Noch unbeantwortet.";
        delete feedback.dataset.state;
      } else {
        feedback.dataset.state = correct ? "correct" : "incorrect";
        const solText = question.answer === "+" ? "+ · Richtig" : "– · Falsch";
        feedback.textContent = correct
          ? `Richtig! (${solText})`
          : `Richtige Antwort: ${solText}`;
      }
    }
    const pct = updateCurrentTopicProgressUI(draft);
    controls.style.setProperty("--progress", `${pct}%`);
    result.textContent = draft.graded
      ? `${correctCount} von ${questions.length} richtig · ${questions.length - draft.answers.size} offen`
      : `${draft.answers.size} von ${questions.length} beantwortet`;
  }

  form.addEventListener("change", (event) => {
    const number = Number(event.target.name);
    if (event.target.value) draft.answers.set(number, event.target.value);
    else draft.answers.delete(number);
    draft.graded = false;
    updateResult();
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    draft.graded = true;
    updateResult();
  });
  resetBtn.addEventListener("click", () => {
    draft.answers.clear();
    draft.graded = false;
    VokageiProgress.clearDraft(MODULE_NAME, currentPart, currentTopic.id);
    for (const { inputs } of questions) {
      for (const inp of inputs) inp.checked = false;
    }
    updateResult();
  });
  updateResult();

  const layout = element("div", "exercise-layout single-col");
  layout.append(form);
  return layout;
}

function renderExercise(focusHeading) {
  const header = element("header", "exercise-heading");
  const titleWrap = element("div");
  const heading = element("h2", "", `Test ${currentTopic.id} – ${topicTitle(currentTopic)}`);
  heading.tabIndex = -1;
  titleWrap.append(heading, element("p", "", descriptions[currentPart]));
  header.append(titleWrap);
  exercise.replaceChildren(header, renderTest(currentTopic));
  if (focusHeading) heading.focus({ preventScroll: true });
}

function showLocation(focusHeading = false) {
  const route = location.hash.match(/^#teil-([123])(?:\/([a-z0-9]+))?$/i);
  const part = Number(route?.[1] ?? 1);
  const id = route?.[2]?.toLowerCase() ?? selections.get(part);
  const topic = parts[part].find((candidate) => candidate.id.toLowerCase() === id) ?? parts[part][0];
  if (part !== currentPart) {
    topicSearch.value = "";
    topicList.scrollTop = 0;
    for (const link of partLinks) {
      if (link.hash === `#teil-${part}`) link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    }
  }
  if (part === currentPart && topic === currentTopic) {
    if (focusHeading) exercise.querySelector("h2").focus({ preventScroll: true });
    return;
  }
  currentPart = part;
  currentTopic = topic;
  selections.set(part, topic.id.toLowerCase());
  renderTopics();
  renderExercise(focusHeading);
  window.scrollTo({ top: 0, behavior: "instant" });
}

function navigate(event) {
  const link = event.target.closest("a");
  if (!link || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  const fromPicker = topicList.contains(link);
  if (location.hash !== link.hash) history.pushState(null, "", link.hash);
  if (fromPicker && narrowScreen.matches) topicPicker.open = false;
  showLocation(fromPicker);
}

if (narrowScreen.matches) topicPicker.open = false;
document.querySelector(".reading-parts").addEventListener("click", navigate);
topicList.addEventListener("click", navigate);
topicSearch.addEventListener("input", renderTopics);
window.addEventListener("hashchange", () => showLocation());
window.addEventListener("popstate", () => showLocation());
showLocation();
