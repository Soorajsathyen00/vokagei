const MODULE_NAME = "schreiben";
const topicPicker = document.querySelector(".topic-panel");
const topicSearch = document.querySelector("#topic-search");
const topicList = document.querySelector("#topic-list");
const topicCount = document.querySelector("#topic-count");
const topicEmpty = document.querySelector("#topic-empty");
const exercise = document.querySelector("#reading-exercise");
const narrowScreen = window.matchMedia("(max-width: 920px)");

const topics = schreibenData["1"];
const masterLines = schreibenData["2"].find((x) => x.type === "master")?.master_lines ?? [];

let showEnglish = true;
let coverComplaints = false;
let activeId = topics[0].id;

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function normalize(text) {
  return text.toLocaleLowerCase("de").replace(/ß/g, "ss")
    .normalize("NFD").replace(/\p{Diacritic}/gu, "");
}

function topicTitle(topic) {
  return topic.title.replace(/^Test\s+\S+\s*[–-]\s*/i, "");
}

function isDone(id) {
  const d = VokageiProgress.getDraft(MODULE_NAME, 1, id);
  return d.answers.get("done") === "1";
}

function toggleDone(id, doneVal) {
  const d = VokageiProgress.getDraft(MODULE_NAME, 1, id);
  if (doneVal) d.answers.set("done", "1");
  else d.answers.delete("done");
  d.graded = doneVal;
  VokageiProgress.saveDraft(MODULE_NAME, 1, id, d, 1);
  renderSidebar();
}

function renderSidebar() {
  const terms = normalize(topicSearch.value.trim()).split(/\s+/).filter(Boolean);
  const matches = topics.filter((topic) => {
    const extra = `${topic.ziel.de} ${topic.ziel.en} ${topic.vorteil.de} ${topic.items.map((i) => `${i.promise.de} ${i.complaint.de}`).join(" ")}`;
    const searchText = normalize(`${topic.id} ${topic.title} ${extra}`);
    return terms.every((w) => /^\d+$/.test(w) ? topic.id.startsWith(w) : searchText.includes(w));
  });

  const entries = matches.map((t) => {
    const li = element("li");
    const a = element("a");
    a.href = `#thema-${t.id}`;
    a.dataset.topicId = t.id;
    a.style.setProperty("--progress", isDone(t.id) ? "100%" : "0%");
    if (t.id === activeId) a.setAttribute("aria-current", "location");
    a.append(element("span", "topic-number", t.id), element("span", "", topicTitle(t)));
    a.addEventListener("click", (e) => {
      e.preventDefault();
      activeId = t.id;
      renderSidebar();
      const card = document.getElementById(`beschwerde-card-${t.id}`);
      if (card) {
        card.open = true;
        card.scrollIntoView({ behavior: "smooth", block: "start" });
      }
      if (narrowScreen.matches) topicPicker.open = false;
    });
    li.append(a);
    return li;
  });

  topicList.replaceChildren(...entries);
  topicCount.textContent = `${matches.length} von ${topics.length} Themen`;
  topicEmpty.hidden = matches.length > 0;
}

function renderPage() {
  exercise.replaceChildren();

  // Sticky topic name bar
  const header = element("header", "exercise-heading");
  const titleWrap = element("div");
  const h2 = element("h2", "", "Beschwerde-Themen (40 Schreibaufgaben)");
  const sub = element("p", "", "Quelle: „Schreiben telk.pdf“ (109 Seiten) · Deutsch mit englischen Übersetzungen");
  titleWrap.append(h2, sub);

  const tools = element("div", "heading-tools");
  const enBtn = element("button", "tool-pill", showEnglish ? "English: an" : "English: aus");
  enBtn.type = "button";
  enBtn.setAttribute("aria-pressed", String(showEnglish));
  const coverBtn = element("button", "tool-pill", coverComplaints ? "Beschwerden zeigen" : "Beschwerden verdecken");
  coverBtn.type = "button";
  coverBtn.setAttribute("aria-pressed", String(coverComplaints));
  tools.append(enBtn, coverBtn);
  header.append(titleWrap, tools);
  exercise.append(header);

  // Guide card ("So verwendest du die Bausteine")
  const guide = element("section", "notes-guide-card");
  if (!showEnglish) guide.classList.add("hide-en");
  guide.append(
    element("h3", "", "So verwendest du die Bausteine"),
    element("p", "", "In deiner Vorlage passt das Ziel in den Satz „Ich habe mich dafür entschieden, weil ich mir davon … versprochen hatte.“ Ergänze danach einen konkreten Vorteil aus der Anzeige. Bei einer Beschwerde nimmst du den positiven Anzeigensatz und drehst ihn direkt um. Passe Zahlen, Zeiten und persönliche Umstände an die Aufgabe an."),
    element("p", "en-translation", "In your template, the goal fits into the sentence “I chose this because I expected … from it.” Then add one concrete advantage from the ad. For a complaint, take the positive ad statement and turn it around directly. Adapt numbers, times and personal details to the task.")
  );
  const exGrid = element("div", "notes-ex-grid");
  const exP = element("div", "notes-ex-p");
  exP.innerHTML = "<strong>Versprechen:</strong> moderne Fahrzeuge";
  const exC = element("div", "notes-ex-c");
  exC.innerHTML = "<strong>Beschwerde:</strong> Das Fahrzeug war alt und nicht modern.";
  exGrid.append(exP, exC);
  guide.append(
    exGrid,
    element("p", "", "Hinweis: Die Beschwerden sind plausible Beispielideen zum Üben, keine Tatsachen aus den Anzeigen. Beim Spielplatz (20) und beim Gemeinschaftsgarten (40) gibt es keine Anzeige; dort steht eine Aussage aus dem Schreiben.")
  );
  exercise.append(guide);

  // Tools bar (Search + Alle öffnen / Alle schließen)
  const toolsBar = element("div", "notes-tools-bar");
  const qInput = element("input", "notes-search");
  qInput.type = "search";
  qInput.placeholder = "Thema oder Stichwort suchen (z. B. Hotel, Kurs, Lieferung) …";
  const btnOpenAll = element("button", "secondary-cta", "Alle öffnen");
  btnOpenAll.type = "button";
  const btnCloseAll = element("button", "secondary-cta", "Alle schließen");
  btnCloseAll.type = "button";
  const countSpan = element("span", "", `${topics.length} / ${topics.length} Themen`);
  countSpan.style.fontSize = ".88rem";
  countSpan.style.color = "#4d5a69";
  toolsBar.append(qInput, btnOpenAll, btnCloseAll, countSpan);
  exercise.append(toolsBar);

  // Topics container
  const topicsWrap = element("div");
  if (!showEnglish) topicsWrap.classList.add("hide-en");
  if (coverComplaints) topicsWrap.classList.add("cover-complaints");

  function renderCards(filterText = "") {
    const terms = normalize(filterText.trim()).split(/\s+/).filter(Boolean);
    const filtered = topics.filter((t) => {
      const hay = normalize(`${t.id} ${t.title} ${t.ziel.de} ${t.ziel.en} ${t.vorteil.de} ${t.items.map((i) => `${i.promise.de} ${i.complaint.de}`).join(" ")}`);
      return terms.every((w) => hay.includes(w));
    });
    countSpan.textContent = `${filtered.length} / ${topics.length} Themen`;

    const nodes = filtered.map((t) => {
      const det = element("details", "beschwerde-details");
      det.id = `beschwerde-card-${t.id}`;
      det.style.scrollMarginTop = "9.5rem";

      const sum = element("summary");
      const titleSpan = element("span", "", `${t.id}. ${topicTitle(t)} (S. ${t.page})`);
      const doneBadge = element("span", "", isDone(t.id) ? "✓ Geübt" : "Offen");
      doneBadge.style.fontSize = ".8rem";
      doneBadge.style.opacity = ".85";
      sum.append(titleSpan, doneBadge);

      const body = element("div", "beschwerde-body");

      // Done toggle button
      const doneBtn = element("button", isDone(t.id) ? "cta model-cta" : "secondary-cta", isDone(t.id) ? "✓ Als geübt markiert" : "Als geübt markieren");
      doneBtn.type = "button";
      doneBtn.style.marginBottom = ".85rem";
      doneBtn.addEventListener("click", () => {
        const next = !isDone(t.id);
        toggleDone(t.id, next);
        doneBadge.textContent = next ? "✓ Geübt" : "Offen";
        doneBtn.className = next ? "cta model-cta" : "secondary-cta";
        doneBtn.textContent = next ? "✓ Als geübt markiert" : "Als geübt markieren";
      });
      body.append(doneBtn);

      const zDiv = element("div", "passage-entry");
      zDiv.append(
        element("h4", "", "1. Ziel"),
        element("p", "", t.ziel.de),
        element("p", "en-translation", t.ziel.en)
      );
      const vDiv = element("div", "passage-entry");
      vDiv.append(
        element("h4", "", "2. Vorteil aus der Anzeige"),
        element("p", "", t.vorteil.de),
        element("p", "en-translation", t.vorteil.en)
      );
      const pDiv = element("div", "passage-entry");
      pDiv.append(element("h4", "", "3. Vier mögliche Beschwerden (Ankündigung → Beschwerde)"));
      t.items.forEach((it, idx) => {
        const pairBox = element("div", "pair-box");
        const prom = element("div", "pair-promise");
        prom.append(element("strong", "", `Versprechen ${idx + 1}: `), element("span", "", it.promise.de), element("p", "en-translation", it.promise.en));
        const comp = element("div", "pair-complaint complaint-reveal");
        comp.tabIndex = 0;
        comp.append(element("strong", "", `Beschwerde ${idx + 1}: `), element("span", "", it.complaint.de), element("p", "en-translation", it.complaint.en));
        pairBox.append(prom, comp);
        pDiv.append(pairBox);
      });

      body.append(zDiv, vDiv, pDiv);
      det.append(sum, body);
      return det;
    });
    topicsWrap.replaceChildren(...nodes);
  }

  renderCards();
  exercise.append(topicsWrap);

  // Master Prompt card at bottom
  if (masterLines.length) {
    const masterCard = element("section", "notes-guide-card");
    masterCard.style.marginTop = "1.5rem";
    const mHead = element("div", "heading-tools");
    mHead.style.justifyContent = "space-between";
    mHead.style.marginBottom = ".5rem";
    mHead.append(element("h3", "", masterLines[0] || "Master Prompt zum Wiederverwenden"));
    const copyBtn = element("button", "secondary-cta", "Prompt kopieren");
    copyBtn.type = "button";
    const masterText = masterLines.slice(2).join("\n");
    copyBtn.addEventListener("click", () => {
      navigator.clipboard?.writeText(masterText);
      copyBtn.textContent = "Kopiert!";
      setTimeout(() => { copyBtn.textContent = "Prompt kopieren"; }, 1800);
    });
    mHead.append(copyBtn);
    masterCard.append(mHead, element("p", "", masterLines[1] || ""), element("pre", "master-pre", masterText));
    exercise.append(masterCard);
  }

  enBtn.addEventListener("click", () => { showEnglish = !showEnglish; renderPage(); });
  coverBtn.addEventListener("click", () => { coverComplaints = !coverComplaints; renderPage(); });
  qInput.addEventListener("input", () => renderCards(qInput.value));
  btnOpenAll.addEventListener("click", () => topicsWrap.querySelectorAll("details").forEach((d) => { d.open = true; }));
  btnCloseAll.addEventListener("click", () => topicsWrap.querySelectorAll("details").forEach((d) => { d.open = false; }));
}

if (narrowScreen.matches) topicPicker.open = false;
topicSearch.addEventListener("input", renderSidebar);
renderSidebar();
renderPage();
